// Copyright 2012 the V8 project authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// This file defines all of the flags.  It is separated into different section,
// for Debug, Release, Logging and Profiling, etc.  To add a new flag, find the
// correct section, and use one of the DEFINE_ macros, without a trailing ';'.
//
// This include does not have a guard, because it is a template-style include,
// which can be included multiple times in different modes.  It expects to have
// a mode defined before it's included.  The modes are FLAG_MODE_... below:
//
// PRESUBMIT_INTENTIONALLY_MISSING_INCLUDE_GUARD

#define DEFINE_IMPLICATION(cond, thenflag) \
  DEFINE_VALUE_IMPLICATION(cond, thenflag, true)

// A weak implication will be overwritten by a normal implication or by an
// explicit flag.
#define DEFINE_WEAK_IMPLICATION(cond, thenflag) \
  DEFINE_WEAK_VALUE_IMPLICATION(cond, thenflag, true)

#define DEFINE_WEAK_NEG_IMPLICATION(cond, thenflag) \
  DEFINE_WEAK_VALUE_IMPLICATION(cond, thenflag, false)

#define DEFINE_NEG_IMPLICATION(cond, thenflag) \
  DEFINE_VALUE_IMPLICATION(cond, thenflag, false)

#define DEFINE_NEG_NEG_IMPLICATION(whenflag, thenflag) \
  DEFINE_NEG_VALUE_IMPLICATION(whenflag, thenflag, false)

// With FLAG_MODE_DECLARE we declare the fields in the {FlagValues} struct.
// Read-only flags are static constants instead of fields.
#if defined(FLAG_MODE_DECLARE)
#define FLAG_FULL(ftype, ctype, nam, def, cmt) FlagValue<ctype> nam{def};
#define FLAG_READONLY(ftype, ctype, nam, def, cmt) \
  static constexpr FlagValue<ctype> nam{def};

// We need to define all of our default values so that the Flag structure can
// access them by pointer.  These are just used internally inside of one .cc,
// for MODE_META, so there is no impact on the flags interface.
#elif defined(FLAG_MODE_DEFINE_DEFAULTS)
#define FLAG_FULL(ftype, ctype, nam, def, cmt) \
  static constexpr ctype FLAGDEFAULT_##nam{def};
#define FLAG_READONLY(ftype, ctype, nam, def, cmt) \
  static constexpr ctype FLAGDEFAULT_##nam{def};

// We want to write entries into our meta data table, for internal parsing and
// printing / etc in the flag parser code.
#elif defined(FLAG_MODE_META)
#define FLAG_FULL(ftype, ctype, nam, def, cmt) \
  {Flag::TYPE_##ftype, &v8_flags.nam, &FLAGDEFAULT_##nam, false},
// Readonly flags don't pass the value pointer since the struct expects a
// mutable value. That's okay since the value always equals the default.
#define FLAG_READONLY(ftype, ctype, nam, def, cmt) \
  {Flag::TYPE_##ftype, nullptr, &FLAGDEFAULT_##nam, false},
// Aliases are not allocated in the meta data table.
#define FLAG_ALIAS_WITH_COMMENT(ftype, ctype, alias, nam, cmt)

// We produce the code to set flags when it is implied by another flag.
#elif defined(FLAG_MODE_DEFINE_IMPLICATIONS)
#define DEFINE_VALUE_IMPLICATION(cond, thenflag, value)                     \
  changed |= TriggerImplication(cond, #cond, &v8_flags.thenflag, #thenflag, \
                                value, false);

// A weak implication will be overwritten by a normal implication or by an
// explicit flag.
#define DEFINE_WEAK_VALUE_IMPLICATION(cond, thenflag, value)                \
  changed |= TriggerImplication(cond, #cond, &v8_flags.thenflag, #thenflag, \
                                value, true);

#define DEFINE_GENERIC_IMPLICATION(cond, statement) \
  if (cond) statement;

#define DEFINE_REQUIREMENT(statement) \
  do {                                \
    if (V8_UNLIKELY(!(statement))) {  \
      FlagError{} << #statement;      \
      UNREACHABLE();                  \
    }                                 \
  } while (false);

// Enforce that a flag was not explicitly set via command line. Setting a value
// via implications is still allowed.
#define DEFINE_NOT_EXPLICITLY_SET_IMPLICATION(cond, thenflag) \
  TriggerNotExplicitlySetImplication(cond, #cond, #thenflag);

#define DEFINE_NEG_VALUE_IMPLICATION(whenflag, thenflag, value) \
  changed |= TriggerImplication(!(whenflag), "!" #whenflag,     \
                                &v8_flags.thenflag, #thenflag, value, false);

#define DEFINE_NEG_VALUE_VALUE_IMPLICATION(whenflag, whenvalue, thenflag, \
                                           thenvalue)                     \
  changed |=                                                              \
      TriggerImplication(v8_flags.whenflag != whenvalue, #whenflag,       \
                         &v8_flags.thenflag, #thenflag, thenvalue, false);

#define DEFINE_MIN_VALUE_IMPLICATION(flag, min_value)                     \
  changed |=                                                              \
      TriggerImplication(v8_flags.flag < min_value, #flag "<" #min_value, \
                         &v8_flags.flag, #flag, min_value, false);

#define DEFINE_MAX_VALUE_IMPLICATION(flag, max_value)                     \
  changed |=                                                              \
      TriggerImplication(v8_flags.flag > max_value, #max_value "<" #flag, \
                         &v8_flags.flag, #flag, max_value, false);

#define DEFINE_DISABLE_FLAG_IMPLICATION(whenflag, thenflag) \
  if (whenflag && thenflag) {                               \
    PrintF(stderr, "Warning: disabling flag --" #thenflag   \
                   " due to conflicting flags\n");          \
  }                                                         \
  DEFINE_VALUE_IMPLICATION(whenflag, thenflag, false)

// We apply a generic macro to the flags.
#elif defined(FLAG_MODE_APPLY)

#define FLAG_FULL(ftype, ctype, nam, def, cmt) \
  FLAG_MODE_APPLY(ctype, nam, , cmt)

#if defined(FLAG_MODE_INCLUDE_READONLY)
#define FLAG_READONLY(ftype, ctype, nam, def, cmt) \
  FLAG_MODE_APPLY(ctype, nam, , cmt)
#endif

#if defined(FLAG_MODE_INCLUDE_ALIASES)
#define FLAG_ALIAS_WITH_COMMENT(ftype, ctype, alias, nam, cmt) \
  FLAG_MODE_APPLY(ctype, alias, nam, cmt)
#endif

#else
#error No mode supplied when including flags.defs
#endif

// Dummy defines for modes where it is not relevant.
#ifndef FLAG_FULL
#define FLAG_FULL(ftype, ctype, nam, def, cmt)
#endif

#ifndef FLAG_READONLY
#define FLAG_READONLY(ftype, ctype, nam, def, cmt)
#endif

#ifndef FLAG_ALIAS_WITH_COMMENT
#define FLAG_ALIAS_WITH_COMMENT(ftype, ctype, alias, nam, cmt)
#endif

#ifndef FLAG_ALIAS
#define FLAG_ALIAS(ftype, ctype, alias, nam) \
  FLAG_ALIAS_WITH_COMMENT(ftype, ctype, alias, nam, nullptr)
#endif

#ifndef DEFINE_VALUE_IMPLICATION
#define DEFINE_VALUE_IMPLICATION(whenflag, thenflag, value)
#endif

#ifndef DEFINE_WEAK_VALUE_IMPLICATION
#define DEFINE_WEAK_VALUE_IMPLICATION(whenflag, thenflag, value)
#endif

#ifndef DEFINE_GENERIC_IMPLICATION
#define DEFINE_GENERIC_IMPLICATION(whenflag, statement)
#endif

#ifndef DEFINE_NEG_VALUE_IMPLICATION
#define DEFINE_NEG_VALUE_IMPLICATION(whenflag, thenflag, value)
#endif

#ifndef DEFINE_MIN_VALUE_IMPLICATION
#define DEFINE_MIN_VALUE_IMPLICATION(flag, min_value)
#endif

#ifndef DEFINE_MAX_VALUE_IMPLICATION
#define DEFINE_MAX_VALUE_IMPLICATION(flag, max_value)
#endif

#ifndef DEFINE_DISABLE_FLAG_IMPLICATION
#define DEFINE_DISABLE_FLAG_IMPLICATION(whenflag, thenflag)
#endif

#ifndef DEFINE_REQUIREMENT
#define DEFINE_REQUIREMENT(statement)
#endif

#ifndef DEFINE_NOT_EXPLICITLY_SET_IMPLICATION
#define DEFINE_NOT_EXPLICITLY_SET_IMPLICATION(whenflag, thenflag)
#endif

#ifndef DEBUG_BOOL
#error DEBUG_BOOL must be defined at this point.
#endif  // DEBUG_BOOL

#if V8_ENABLE_SPARKPLUG
#define ENABLE_SPARKPLUG_BY_DEFAULT true
#else
#define ENABLE_SPARKPLUG_BY_DEFAULT false
#endif

// Supported ARM configurations are:
//  "armv6":       ARMv6 + VFPv2
//  "armv7":       ARMv7 + VFPv3-D32 + NEON
//  "armv7+sudiv": ARMv7 + VFPv4-D32 + NEON + SUDIV
//  "armv8":       ARMv8 (including all of the above)
#if !defined(ARM_TEST_NO_FEATURE_PROBE) ||                            \
    (defined(CAN_USE_ARMV8_INSTRUCTIONS) &&                           \
     defined(CAN_USE_ARMV7_INSTRUCTIONS) && defined(CAN_USE_SUDIV) && \
     defined(CAN_USE_NEON) && defined(CAN_USE_VFP3_INSTRUCTIONS))
#define ARM_ARCH_DEFAULT "armv8"
#elif defined(CAN_USE_ARMV7_INSTRUCTIONS) && defined(CAN_USE_SUDIV) && \
    defined(CAN_USE_NEON) && defined(CAN_USE_VFP3_INSTRUCTIONS)
#define ARM_ARCH_DEFAULT "armv7+sudiv"
#elif defined(CAN_USE_ARMV7_INSTRUCTIONS) && defined(CAN_USE_NEON) && \
    defined(CAN_USE_VFP3_INSTRUCTIONS)
#define ARM_ARCH_DEFAULT "armv7"
#else
#define ARM_ARCH_DEFAULT "armv6"
#endif

#ifdef V8_OS_WIN
#define ENABLE_LOG_COLOUR false
#else
#define ENABLE_LOG_COLOUR true
#endif

#define DEFINE_BOOL(nam, def, cmt) FLAG(BOOL, bool, nam, def, cmt)
#define DEFINE_BOOL_READONLY(nam, def, cmt) \
  FLAG_READONLY(BOOL, bool, nam, def, cmt)
#define DEFINE_MAYBE_BOOL(nam, cmt) \
  FLAG(MAYBE_BOOL, std::optional<bool>, nam, std::nullopt, cmt)
#define DEFINE_INT(nam, def, cmt) FLAG(INT, int, nam, def, cmt)
#define DEFINE_UINT(nam, def, cmt) FLAG(UINT, unsigned int, nam, def, cmt)
#define DEFINE_UINT_READONLY(nam, def, cmt) \
  FLAG_READONLY(UINT, unsigned int, nam, def, cmt)
#define DEFINE_UINT64(nam, def, cmt) FLAG(UINT64, uint64_t, nam, def, cmt)
#define DEFINE_FLOAT(nam, def, cmt) FLAG(FLOAT, double, nam, def, cmt)
#define DEFINE_SIZE_T(nam, def, cmt) FLAG(SIZE_T, size_t, nam, def, cmt)
#define DEFINE_STRING(nam, def, cmt) FLAG(STRING, const char*, nam, def, cmt)
#define DEFINE_ALIAS_BOOL(alias, nam) FLAG_ALIAS(BOOL, bool, alias, nam)
#define DEFINE_ALIAS_BOOL_WITH_COMMENT(alias, nam, cmt) \
  FLAG_ALIAS_WITH_COMMENT(BOOL, bool, alias, nam, cmt)
#define DEFINE_ALIAS_INT(alias, nam) FLAG_ALIAS(INT, int, alias, nam)
#define DEFINE_ALIAS_FLOAT(alias, nam) FLAG_ALIAS(FLOAT, double, alias, nam)
#define DEFINE_ALIAS_SIZE_T(alias, nam) FLAG_ALIAS(SIZE_T, size_t, alias, nam)
#define DEFINE_ALIAS_STRING(alias, nam) \
  FLAG_ALIAS(STRING, const char*, alias, nam)

#define DEFINE_SMI(nam, def, cmt) \
  DEFINE_INT(nam, def, cmt)       \
  DEFINE_REQUIREMENT(Internals::IsValidSmi(v8_flags.nam.value()))
#define DEFINE_POSITIVE_SMI(nam, def, cmt) \
  DEFINE_UINT(nam, def, cmt)               \
  DEFINE_REQUIREMENT(Internals::IsValidSmi(v8_flags.nam.value()))

#ifdef DEBUG
#define DEFINE_DEBUG_BOOL DEFINE_BOOL
#else
#define DEFINE_DEBUG_BOOL DEFINE_BOOL_READONLY
#endif

#define TEMPORARY_WASM_ALIAS_COMMENT \
  "temporary alias, to be dropped in V8 v15.3"

//
// Flags in all modes.
//
#define FLAG FLAG_FULL

// Experimental features: Features that are still considered experimental and
// which are not ready for fuzz testing should be defined using this macro. The
// feature will then imply --experimental, which will indicate to the user that
// they are running an experimental configuration of V8. Experimental features
// are always disabled by default. When these features mature, the flag should
// first turn into a regular feature flag (still disabled by default) and then
// ideally be staged behind (for example) --future before being enabled by
// default.
DEFINE_BOOL(experimental, false,
            "Indicates that V8 is running with experimental features enabled. "
            "This flag is typically not set explicitly but instead enabled as "
            "an implication of other flags which enable experimental features.")
#define DEFINE_EXPERIMENTAL_FEATURE(nam, cmt)         \
  FLAG(BOOL, bool, nam, false, cmt " (experimental)") \
  DEFINE_IMPLICATION(nam, experimental)

DEFINE_EXPERIMENTAL_FEATURE(array_destructure_bytecode,
                            "enable experimental ArrayDestructure bytecode")

// Test-only flags that expose unsafe and/or unsupported configurations.
DEFINE_BOOL(test_only_unsafe, false,
            "Indicates that V8 is running in an unsupported and unsafe "
            "configuration, e.g. used for internal testing. This flag is "
            "typically not set explicitly but instead enabled as an "
            "implication of other flags")
#define DEFINE_TEST_ONLY_FLAG(nam, cmt)                     \
  FLAG(BOOL, bool, nam, false, cmt " (test-only / unsafe)") \
  DEFINE_IMPLICATION(nam, test_only_unsafe)

// Developer features: These flags expose features that are only meant to be
// used by developers for diagnosing purposes. These features should be robust
// but crashes will not be considered security problems as they do not affect
// users in production.
DEFINE_BOOL(
    developer_only_features, false,
    "Indicates that V8 is running with developer-only features enabled.")
DEFINE_BOOL(disallow_developer_only_features, false,
            "Disallow developer-only-features.")
#define DEFINE_DEVELOPER_FLAG(name, comment)            \
  DEFINE_BOOL(name, false, comment " (developer-only)") \
  DEFINE_IMPLICATION(name, developer_only_features)     \
  DEFINE_NEG_IMPLICATION(disallow_developer_only_features, name)
#define DEFINE_DEBUG_DEVELOPER_FLAG(name, comment)            \
  DEFINE_DEBUG_BOOL(name, false, comment " (developer-only)") \
  DEFINE_IMPLICATION(name, developer_only_features)           \
  DEFINE_NEG_IMPLICATION(disallow_developer_only_features, name)

DEFINE_STRING(flag_processing_mode, nullptr,
              "Control behavior for flag errors. Possible values: "
              "abort-on-error, exit-on-error, ignore-contradictions.")

// Flags for language modes and experimental language features.
DEFINE_BOOL(use_strict, false, "enforce strict mode")

DEFINE_DEVELOPER_FLAG(trace_temporal, "trace temporal code")

DEFINE_IMPLICATION(js_import_bytes, js_immutable_arraybuffer)

DEFINE_BOOL(js_postmessage_share_immutable_arraybuffer, true,
            "share immutable array buffers in postMessage instead of copying")

DEFINE_BOOL(builtin_subclassing, true,
            "subclassing support in built-in methods")

// If the following flag is set to `true`, the SharedArrayBuffer constructor is
// enabled per context depending on the callback set via
// `SetSharedArrayBufferConstructorEnabledCallback`. If no callback is set, the
// SharedArrayBuffer constructor is disabled.
DEFINE_BOOL(enable_sharedarraybuffer_per_context, false,
            "enable the SharedArrayBuffer constructor per context")

DEFINE_BOOL(js_nonextensible_applies_to_private, false,
            "non-extensibility includes private fields")

DEFINE_EXPERIMENTAL_FEATURE(
    for_of_optimization,
    "Experimental flag for improving ForOf loops on ArrayIterator")

DEFINE_EXPERIMENTAL_FEATURE(
    enable_queue_microtask,
    "ship a native queueMicrotask implementation on the global object")

#ifdef V8_INTL_SUPPORT
DEFINE_BOOL(icu_timezone_data, true, "get information about timezones from ICU")
DEFINE_STRING(icu_datetime_compat_lang, "*",
              "limits ICU date time compat changes to the given language")
DEFINE_BOOL(
    intl_date_time_pattern_generator_cache_eviction, false,
    "enable 9-entry cache eviction in DateTimePatternGeneratorCache")
#endif

#ifdef V8_ENABLE_DOUBLE_CONST_STORE_CHECK
#define V8_ENABLE_DOUBLE_CONST_STORE_CHECK_BOOL true
#else
#define V8_ENABLE_DOUBLE_CONST_STORE_CHECK_BOOL false
#endif

#ifdef V8_ENABLE_LAZY_SOURCE_POSITIONS
#define V8_LAZY_SOURCE_POSITIONS_BOOL true
#else
#define V8_LAZY_SOURCE_POSITIONS_BOOL false
#endif

DEFINE_BOOL(stress_snapshot, false,
            "disables sharing of the read-only heap for testing")
// Incremental marking is incompatible with the stress_snapshot mode;
// specifically, serialization may clear bytecode arrays from shared function
// infos which the MarkCompactCollector (running concurrently) may still need.
// See also https://crbug.com/v8/10882.
//
// Note: This is not an issue in production because we don't clear SFI's
// there (that only happens in mksnapshot and in --stress-snapshot mode).
DEFINE_NEG_IMPLICATION(stress_snapshot, incremental_marking)

#ifdef V8_LITE_MODE
#define V8_LITE_MODE_BOOL true
#else
#define V8_LITE_MODE_BOOL false
#endif

DEFINE_BOOL(lite_mode, V8_LITE_MODE_BOOL,
            "enables trade-off of performance for memory savings")

// Lite mode implies other flags to trade-off performance for memory.
DEFINE_IMPLICATION(lite_mode, jitless)
DEFINE_IMPLICATION(lite_mode, optimize_for_size)

#ifdef V8_ALLOCATION_FOLDING
#define V8_ALLOCATION_FOLDING_BOOL true
#else
#define V8_ALLOCATION_FOLDING_BOOL false
#endif

DEFINE_BOOL_READONLY(enable_allocation_folding, V8_ALLOCATION_FOLDING_BOOL,
                     "Use allocation folding globally")
DEFINE_NEG_NEG_IMPLICATION(enable_allocation_folding, turbo_allocation_folding)

#ifdef V8_DISABLE_WRITE_BARRIERS
#define V8_DISABLE_WRITE_BARRIERS_BOOL true
#else
#define V8_DISABLE_WRITE_BARRIERS_BOOL false
#endif

DEFINE_BOOL_READONLY(disable_write_barriers, V8_DISABLE_WRITE_BARRIERS_BOOL,
                     "disable write barriers when GC is non-incremental "
                     "and heap contains single generation.")

// Disable incremental marking barriers
DEFINE_NEG_IMPLICATION(disable_write_barriers, incremental_marking)
DEFINE_NEG_IMPLICATION(disable_write_barriers, concurrent_marking)
DEFINE_NEG_IMPLICATION(disable_write_barriers, cppheap_incremental_marking)
DEFINE_NEG_IMPLICATION(disable_write_barriers, cppheap_concurrent_marking)

#ifdef V8_ENABLE_UNCONDITIONAL_WRITE_BARRIERS
#define V8_ENABLE_UNCONDITIONAL_WRITE_BARRIERS_BOOL true
#else
#define V8_ENABLE_UNCONDITIONAL_WRITE_BARRIERS_BOOL false
#endif

DEFINE_BOOL_READONLY(enable_unconditional_write_barriers,
                     V8_ENABLE_UNCONDITIONAL_WRITE_BARRIERS_BOOL,
                     "always use full write barriers")

#ifdef V8_ENABLE_SINGLE_GENERATION
#define V8_SINGLE_GENERATION_BOOL true
#else
#define V8_SINGLE_GENERATION_BOOL false
#endif

DEFINE_BOOL_READONLY(
    single_generation, V8_SINGLE_GENERATION_BOOL,
    "allocate all objects from young generation to old generation")

#ifdef V8_ENABLE_DIRECT_HANDLE
// Direct handles require conservative stack scanning.
DEFINE_BOOL_READONLY(conservative_stack_scanning, true,
                     "use conservative stack scanning")
#else
DEFINE_EXPERIMENTAL_FEATURE(conservative_stack_scanning,
                            "use conservative stack scanning")
#endif  // V8_ENABLE_DIRECT_HANDLE
DEFINE_IMPLICATION(conservative_stack_scanning,
                   scavenger_conservative_object_pinning)

#ifdef V8_ENABLE_DIRECT_HANDLE
#define V8_ENABLE_DIRECT_HANDLE_BOOL true
#else
#define V8_ENABLE_DIRECT_HANDLE_BOOL false
#endif
DEFINE_BOOL_READONLY(direct_handle, V8_ENABLE_DIRECT_HANDLE_BOOL,
                     "use direct handles with conservative stack scanning")
// Do not use direct handles without conservative stack scanning, as this would
// break the correctness of the GC.
DEFINE_NEG_NEG_IMPLICATION(conservative_stack_scanning, direct_handle)

DEFINE_BOOL(scavenger_conservative_object_pinning, false,
            "Objects reachable from the native stack during "
            "scavenge will be pinned and "
            "won't move.")
DEFINE_BOOL(
    stress_scavenger_conservative_object_pinning, false,
    "Treat some precise references as conservative references to stress "
    "test object pinning in Scavenger")
DEFINE_IMPLICATION(stress_scavenger_conservative_object_pinning,
                   scavenger_conservative_object_pinning)
DEFINE_NEG_IMPLICATION(stress_scavenger_conservative_object_pinning,
                       minor_gc_task)
DEFINE_VALUE_IMPLICATION(stress_scavenger_conservative_object_pinning,
                         max_semi_space_size, size_t{1})
DEFINE_BOOL(stress_scavenger_conservative_object_pinning_random, false,
            "Enables random stressing of object pinning in Scavenger, such "
            "that each GC would randomly pick a subset of the precise "
            "references to treat conservatively")
DEFINE_IMPLICATION(stress_scavenger_conservative_object_pinning_random,
                   stress_scavenger_conservative_object_pinning)

DEFINE_BOOL(scavenger_precise_object_pinning, false,
            "Objects reachable from handles during scavenge "
            "will be pinned and won't move.")
DEFINE_BOOL(scavenger_updates_allocation_limit, true,
            "Scavenger updates allocation limits if allocation rate is low")

DEFINE_BOOL(
    precise_object_pinning, false,
    "Objects reachable from handles during GC will be pinned and won't move.")
DEFINE_IMPLICATION(precise_object_pinning, scavenger_precise_object_pinning)

DEFINE_BOOL(scavenger_promote_quarantined_pages, true,
            "Quarantined pages in the intermediate generation will be promoted "
            "to old space")

DEFINE_BOOL(scavenger_chaos_mode, false,
            "Scavenger will ignore age when making promotion decisions and "
            "instead choose objects to be promoted at random. This only "
            "applies to non-large objects.")
DEFINE_UINT(
    scavenger_chaos_mode_threshold, 50,
    "Percentage of non-large young objects that will be promoted during "
    "Scavenger in chaos mode")
DEFINE_REQUIREMENT(v8_flags.scavenger_chaos_mode_threshold <= 100)

#ifdef V8_ENABLE_LOCAL_OFF_STACK_CHECK
#define V8_ENABLE_LOCAL_OFF_STACK_CHECK_BOOL true
#else
#define V8_ENABLE_LOCAL_OFF_STACK_CHECK_BOOL false
#endif
DEFINE_BOOL_READONLY(local_off_stack_check,
                     V8_ENABLE_LOCAL_OFF_STACK_CHECK_BOOL,
                     "check for off-stack allocation of v8::Local")

DEFINE_BOOL(force_emit_interrupt_budget_checks, false,
            "force emit tier-up logic from all non-turbofan code, even if it "
            "is the top enabled tier")
#ifdef V8_ENABLE_MAGLEV
DEFINE_BOOL(maglev, true, "enable the maglev optimizing compiler")
#if !ENABLE_MAGLEV
// Enable Maglev on Future for platforms in which it's not enabled by default
// (eg, Android).
DEFINE_WEAK_IMPLICATION(future, maglev)
#endif
DEFINE_EXPERIMENTAL_FEATURE(
    maglev_future,
    "enable maglev features that we want to ship in the not-too-far future")
DEFINE_IMPLICATION(maglev_future, maglev)
DEFINE_BOOL(
    optimize_on_next_call_optimizes_to_maglev, false,
    "make OptimizeFunctionOnNextCall optimize to maglev instead of turbofan")

// We stress maglev by setting a very low interrupt budget for maglev. This
// way, we still gather *some* feedback before compiling optimized code.
DEFINE_BOOL(stress_maglev, false, "trigger maglev compilation earlier")
DEFINE_IMPLICATION(stress_maglev, maglev)
DEFINE_WEAK_VALUE_IMPLICATION(stress_maglev, invocation_count_for_maglev, 4)

#else
DEFINE_BOOL_READONLY(maglev, false, "enable the maglev optimizing compiler")
DEFINE_BOOL_READONLY(
    maglev_future, false,
    "enable maglev features that we want to ship in the not-too-far future")
DEFINE_BOOL_READONLY(stress_maglev, false, "trigger maglev compilation earlier")
DEFINE_BOOL_READONLY(
    optimize_on_next_call_optimizes_to_maglev, false,
    "make OptimizeFunctionOnNextCall optimize to maglev instead of turbofan")
#endif  //  V8_ENABLE_MAGLEV

DEFINE_INT(maglev_max_small_graph_size, 10,
           "max inlined maglev graph size that counts as a small function")

DEFINE_BOOL(maglev_as_top_tier, false,
            "disable Turbofan/Turbolev, make Maglev optimize more aggressively")
DEFINE_IMPLICATION(maglev_as_top_tier, maglev)
DEFINE_NEG_IMPLICATION(maglev_as_top_tier, turbofan)
DEFINE_NEG_IMPLICATION(maglev_as_top_tier, turbolev)

DEFINE_BOOL(maglev_inlining, true,
            "enable inlining in the maglev optimizing compiler")
DEFINE_BOOL(
    maglev_disable_builtin_reducers, false,
    "disable eager builtin reducers in the maglev graph builder (for testing)")
DEFINE_BOOL(maglev_loop_peeling, true,
            "enable loop peeling in the maglev optimizing compiler")
DEFINE_BOOL(maglev_optimistic_peeled_loops, true,
            "enable aggressive optimizations for loops (loop SPeeling) in the "
            "maglev optimizing compiler")
DEFINE_INT(maglev_loop_peeling_max_size, 400,
           "max loop size for loop peeling in the maglev optimizing compiler")
DEFINE_INT(
    maglev_loop_peeling_max_size_cumulative, 900,
    "max cumulative size for loop peeling in the maglev optimizing compiler")
DEFINE_BOOL(maglev_deopt_data_on_background, true,
            "Generate deopt data on background thread")
DEFINE_BOOL(maglev_build_code_on_background, true,
            "Generate code on background thread")
DEFINE_WEAK_IMPLICATION(maglev_build_code_on_background,
                        maglev_deopt_data_on_background)
DEFINE_BOOL(maglev_destroy_on_background, true,
            "Destroy compilation jobs on background thread")
DEFINE_BOOL(maglev_inline_api_calls, false,
            "Inline CallApiCallback builtin into generated code")
DEFINE_BOOL(maglev_cons_string_elision, true,
            "Native support for cons strings and their elision in maglev.")
DEFINE_BOOL(maglev_pretenure_store_values, true,
            "Recursively pretenure values which are stored into pretenured "
            "allocation sites.")
DEFINE_BOOL(maglev_poly_calls, true, "Support (inlining) polymorphic calls")
DEFINE_BOOL(maglev_truncation, true, "Enable Maglev truncation pass")
DEFINE_DEVELOPER_FLAG(trace_maglev_truncation, "trace maglev truncation pass")

DEFINE_EXPERIMENTAL_FEATURE(maglev_licm, "loop invariant code motion")
DEFINE_WEAK_IMPLICATION(maglev_future, maglev_speculative_hoist_phi_untagging)
DEFINE_WEAK_IMPLICATION(maglev_future, maglev_inline_api_calls)
DEFINE_WEAK_IMPLICATION(maglev_future, maglev_escape_analysis)
DEFINE_WEAK_IMPLICATION(maglev_future, maglev_licm)

DEFINE_BOOL(turbolev_truncated_int32_phis, true,
            "Enable truncated to int32 representation in the phi selector")

// TODO(victorgomes): Consider renaming this to turbolev range analysis, since
// it doesn't not enable this pass in the maglev pipeline?
DEFINE_BOOL(maglev_range_analysis, true,
            "Enable Maglev range value analysis pass")
DEFINE_DEVELOPER_FLAG(trace_maglev_range_analysis,
                      "Trace Maglev range value analysis pass")
DEFINE_DEVELOPER_FLAG(trace_maglev_kna, "Trace Maglev known node aspects")
DEFINE_BOOL(maglev_use_unreliable_maps, true,
            "Use unreliable unstable maps in Maglev")
DEFINE_BOOL(maglev_range_verification, false,
            "Run integer range verifiction pass in Turbolev frontend pipeline")
DEFINE_WEAK_IMPLICATION(maglev_assert, maglev_range_verification)
DEFINE_BOOL(maglev_verify_dominance, false,
            "verify dominance of eager deopt frame inputs")
DEFINE_WEAK_IMPLICATION(maglev_assert, maglev_verify_dominance)

DEFINE_UINT(
    concurrent_maglev_max_threads, 2,
    "max number of threads that concurrent Maglev can use (0 for unbounded)")
DEFINE_BOOL(concurrent_maglev_high_priority_threads, false,
            "use high priority compiler threads for concurrent Maglev")

DEFINE_INT(
    max_maglev_inline_depth, 1,
    "max depth of functions that Maglev will inline excl. small functions")
DEFINE_INT(
    max_maglev_hard_inline_depth, 10,
    "max depth of functions that Maglev will inline incl. small functions")
DEFINE_INT(max_maglev_inlined_bytecode_size, 100,
           "maximum size of bytecode for a single inlining")
DEFINE_INT(max_maglev_inlined_bytecode_size_cumulative, 920,
           "maximum cumulative size of bytecode considered for inlining excl. "
           "small functions")
DEFINE_INT(max_maglev_inlined_bytecode_size_small_total, 3000,
           "maximum size of small functions' bytecode that can be inlining")
DEFINE_INT(max_maglev_inlined_bytecode_size_small, 27,
           "maximum size of bytecode considered for small function inlining")
DEFINE_INT(max_maglev_inlined_bytecode_size_small_with_heapnum_in_out, 75,
           "maximum size of bytecode considered for small function inlining, "
           "when the function call has a HeapNumber as input or output")
DEFINE_FLOAT(min_maglev_inlining_frequency, 0.95,
             "minimum frequency for inlining")

// This is just to avoid some corner cases, especially since we allow
// recursive inlining.
DEFINE_INT(
    max_turbolev_inline_depth, 50,
    "max depth of functions that Maglev will inline excl. small functions")

DEFINE_WEAK_VALUE_IMPLICATION(maglev_as_top_tier,
                              max_maglev_inlined_bytecode_size, 460)
DEFINE_WEAK_VALUE_IMPLICATION(maglev_as_top_tier, min_maglev_inlining_frequency,
                              0.10)
DEFINE_WEAK_VALUE_IMPLICATION(maglev_as_top_tier,
                              max_maglev_inlined_bytecode_size_small_total,
                              30000)

DEFINE_BOOL(maglev_reuse_stack_slots, true,
            "reuse stack slots in the maglev optimizing compiler")
DEFINE_BOOL(maglev_untagged_phis, true,
            "enable phi untagging in the maglev optimizing compiler")
DEFINE_INT(maglev_untagged_phis_bisect_limit, -1,
           "limit the number of Phis we untag in Maglev phi untagging (-1 for "
           "unbounded)")
DEFINE_BOOL(turbolev_untagged_phis, true,
            "enable phi untagging in the Turbolev optimizing compiler")

DEFINE_BOOL(maglev_hoist_osr_value_phi_untagging, true,
            "enable phi untagging to hoist untagging of osr values")
DEFINE_EXPERIMENTAL_FEATURE(
    maglev_speculative_hoist_phi_untagging,
    "enable phi untagging to hoist untagging of loop phi inputs (could "
    "still cause deopt loops)")
DEFINE_BOOL(maglev_cse, true, "common subexpression elimination")

DEFINE_BOOL(maglev_non_eager_inlining, false,
            "enable Maglev non-eager inlining")
DEFINE_BOOL(turbolev_non_eager_inlining, true,
            "enable Turbolev non-eager inlining")
DEFINE_BOOL(turbolev_non_eager_loop_peeling, true,
            "enable Turbolev non-eager loop peeling")
DEFINE_BOOL(turbolev_eager_loop_peeling_osr, true,
            "use eager loop peeling in Turbolev OSR compiles")
DEFINE_DEVELOPER_FLAG(turbolev_trace_loop_peeling,
                      "trace turbolev non-eager loop peeling decisions")

DEFINE_STRING(maglev_filter, "*", "optimization filter for the maglev compiler")
DEFINE_STRING(maglev_print_filter, "*",
              "filter for maglev's tracing/printing options")
DEFINE_BOOL(maglev_assert, false, "insert extra assertion in maglev code")
DEFINE_DEBUG_BOOL(maglev_assert_stack_size, true,
                  "insert stack size checks before every IR node")
DEFINE_EXPERIMENTAL_FEATURE(
    maglev_assert_types, "Enable additional type assertions in generated code")

DEFINE_IMPLICATION(maglev_assert_types, turboshaft_enable_debug_features)
DEFINE_BOOL(maglev_break_on_entry, false, "insert an int3 on maglev entries")
DEFINE_BOOL(maglev_print_bytecode, false,
            "print bytecode for maglev compiled code")
DEFINE_BOOL(maglev_print_feedback, true,
            "print feedback vector for maglev compiled code")
DEFINE_BOOL(maglev_print_inlined, true,
            "print bytecode / feedback vectors also for inlined code")
DEFINE_BOOL(maglev_print_provenance, true,
            "print Maglev node provenance, ie, file name, bytecode and offset")

DEFINE_DEVELOPER_FLAG(print_maglev_code, "print maglev code")
DEFINE_WEAK_IMPLICATION(print_maglev_code, maglev_print_bytecode)

DEFINE_BOOL(trace_with_compilation_id, true,
            "prefix maglev/turbolev trace line with a compilation id")

DEFINE_DEVELOPER_FLAG(trace_maglev_graph_building,
                      "trace maglev graph building")
DEFINE_DEVELOPER_FLAG(trace_maglev_graph_optimizer,
                      "trace maglev graph optimizer")
DEFINE_DEVELOPER_FLAG(trace_maglev_loop_speeling, "trace maglev loop SPeeling")
DEFINE_WEAK_IMPLICATION(trace_maglev_graph_building, trace_maglev_loop_speeling)
DEFINE_DEVELOPER_FLAG(trace_maglev_inlining, "trace maglev inlining")
DEFINE_DEVELOPER_FLAG(trace_maglev_kna_processor,
                      "trace maglev known node aspects processor")
DEFINE_DEVELOPER_FLAG(trace_maglev_scope_info, "trace maglev scope info")
DEFINE_DEVELOPER_FLAG(trace_maglev, "trace Maglev IR to JSON")
DEFINE_STRING(trace_maglev_file_prefix, "maglev",
              "write maglev trace files with given prefix")

#ifdef V8_ENABLE_MAGLEV_GRAPH_PRINTER
DEFINE_DEVELOPER_FLAG(print_maglev_deopt_verbose, "print verbose deopt info")
DEFINE_WEAK_IMPLICATION(trace_deopt_verbose, print_maglev_deopt_verbose)
DEFINE_DEVELOPER_FLAG(print_maglev_graph, "print the final maglev graph")
DEFINE_DEVELOPER_FLAG(print_maglev_graphs,
                      "print maglev graph across all phases")
DEFINE_WEAK_IMPLICATION(print_maglev_graph, maglev_print_bytecode)
DEFINE_IMPLICATION(print_maglev_graphs, print_maglev_graph)
DEFINE_DEVELOPER_FLAG(trace_maglev_phi_untagging, "trace maglev phi untagging")
DEFINE_WEAK_IMPLICATION(trace_maglev_phi_untagging, maglev_print_bytecode)
DEFINE_DEVELOPER_FLAG(trace_maglev_regalloc, "trace maglev register allocation")
DEFINE_WEAK_IMPLICATION(trace_maglev_regalloc, maglev_print_bytecode)
#else
DEFINE_BOOL_READONLY(print_maglev_deopt_verbose, false,
                     "print verbose deopt info")
DEFINE_BOOL_READONLY(print_maglev_graph, false, "print the final maglev graph")
DEFINE_BOOL_READONLY(print_maglev_graphs, false,
                     "print maglev graph across all phases")
DEFINE_BOOL_READONLY(trace_maglev_phi_untagging, false,
                     "trace maglev phi untagging")
DEFINE_BOOL_READONLY(trace_maglev_regalloc, false,
                     "trace maglev register allocation")
#endif  // V8_ENABLE_MAGLEV_GRAPH_PRINTER

DEFINE_DEVELOPER_FLAG(maglev_stats, "print Maglev statistics")
DEFINE_DEVELOPER_FLAG(maglev_stats_nvp,
                      "print Maglev statistics in machine-readable format")

// TODO(v8:7700): Remove once stable.
DEFINE_BOOL(maglev_function_context_specialization, true,
            "enable function context specialization in maglev")

#ifdef V8_ENABLE_SPARKPLUG
DEFINE_WEAK_IMPLICATION(future, flush_baseline_code)
#endif


#ifdef V8_TARGET_ARCH_64_BIT
DEFINE_BOOL(additive_safe_int_feedback, true,
            "Record AdditiveSafeInteger feedback")
DEFINE_BOOL(turbolev_additive_safe_int_feedback, true,
            "Enable the use of AdditiveSafeInteger feedback for Turbolev")
DEFINE_BOOL_READONLY(
    turbofan_additive_safe_int_feedback, false,
    "Enable the use of AdditiveSafeInteger feedback for TurboFan")

// Additive safe ints are only used by TurboFan or Turbolev.
DEFINE_NEG_IMPLICATION(jitless, additive_safe_int_feedback)
DEFINE_NEG_IMPLICATION(disable_optimizing_compilers, additive_safe_int_feedback)
#else
DEFINE_BOOL_READONLY(additive_safe_int_feedback, false,
                     "Record AdditiveSafeInteger feedback")
DEFINE_BOOL_READONLY(
    turbolev_additive_safe_int_feedback, false,
    "Enable the use of AdditiveSafeInteger feedback for Turbolev")
DEFINE_BOOL_READONLY(
    turbofan_additive_safe_int_feedback, false,
    "Enable the use of AdditiveSafeInteger feedback for TurboFan")
#endif  // V8_TARGET_ARCH_64_BIT

DEFINE_BOOL(
    enable_enumerated_keyed_access_bytecode, true,
    "enable generating GetEnumeratedKeyedProperty bytecode for keyed access")

DEFINE_BOOL_READONLY(dict_property_const_tracking,
                     V8_DICT_PROPERTY_CONST_TRACKING_BOOL,
                     "Use const tracking on dictionary properties")

DEFINE_BOOL(script_context_cells, true,
            "Use context cells in script contexts, ie, const tracking let and "
            "mutable numbers")

DEFINE_BOOL(function_context_cells, true,
            "Use context cells in function contexts")
// JS3/UniPoker improves with size >= 2 and SP3/Charts-observable-plot
// regresses with size > 3. Be careful when changing this.
DEFINE_INT(function_context_cells_max_size, 2,
           "Max number of context slots allowed in a function context with "
           "context cells")

DEFINE_BOOL(empty_context_extension_dep, true,
            "Use compilation dependency to avoid dynamic checks for "
            "non-empty context extensions")

DEFINE_BOOL(json_stringify_fast_path, true, "Enable JSON.stringify fast-path")
DEFINE_UINT(json_parse_max_heuristically_internalized_strings, 100'000,
            "Maximum number of strings that are eagerly internalized during "
            "JSON.parse() based on heuristics. 0 means only strings that "
            "must be internalized e.g. property keys will be internalized.")
DEFINE_DEVELOPER_FLAG(
    trace_json_parse_internalization,
    "Print heuristic internalization stats after each JSON.parse()")

// TODO(jgruber): Remove this flag.
DEFINE_BOOL(cache_property_key_string_adds, true,
            "Enable caching property keys created by concatenating strings")

DEFINE_UINT(smi_string_cache_size, 8192, "Full size of SmiStringCache")
DEFINE_UINT(double_string_cache_size, 4096, "Full size of DoubleStringCache")
DEFINE_DEVELOPER_FLAG(trace_number_string_cache,
                      "Print NumberString caches stats on GC and at the end")
DEFINE_WEAK_IMPLICATION(trace_number_string_cache, native_code_counters)

DEFINE_BOOL(maglev_inline_date_accessors, false,
            "Inline Date accessors by Maglev")
DEFINE_BOOL(turbofan_inline_date_accessors, false,
            "Inline Date accessors by TurboFan")
DEFINE_BOOL(inline_date_accessors, true, "Inline Date accessors")
DEFINE_WEAK_IMPLICATION(inline_date_accessors, maglev_inline_date_accessors)
DEFINE_WEAK_IMPLICATION(inline_date_accessors, turbofan_inline_date_accessors)

#ifdef V8_ENABLE_EXTENSIBLE_RO_SNAPSHOT
DEFINE_BOOL(extensible_ro_snapshot, true,
            "Whether custom embedder snapshots may extend ReadOnlySpace")
#else
DEFINE_BOOL_READONLY(
    extensible_ro_snapshot, false,
    "Whether custom embedder snapshots may extend ReadOnlySpace")
#endif  // V8_ENABLE_EXTENSIBLE_RO_SNAPSHOT

DEFINE_UINT(max_opt, 999,
            "Set the maximal optimisation tier: "
            "> 3 == any, 0 == ignition/interpreter, 1 == sparkplug/baseline, "
            "2 == maglev, 3 == turbofan")

#ifdef V8_ENABLE_TURBOFAN
DEFINE_WEAK_VALUE_IMPLICATION(max_opt < 3, turbofan, false)
#endif  // V8_ENABLE_TURBOFAN
#ifdef V8_ENABLE_MAGLEV
DEFINE_WEAK_VALUE_IMPLICATION(max_opt < 2, maglev, false)
#endif  // V8_ENABLE_MAGLEV
#ifdef V8_ENABLE_SPARKPLUG
DEFINE_WEAK_VALUE_IMPLICATION(max_opt < 1, sparkplug, false)
#endif  // V8_ENABLE_SPARKPLUG

// Flags to override efficiency and battery saver mode settings for debugging
// and testing.
DEFINE_MAYBE_BOOL(efficiency_mode,
                  "Forces efficiency mode on or off, disregarding any dynamic "
                  "signals. Efficiency mode is optimized for situations with "
                  "no latency requirements and uses fewer threads.")
DEFINE_MAYBE_BOOL(
    battery_saver_mode,
    "Forces battery saver mode on or off, disregarding any dynamic signals. "
    "Battery saver tries to conserve overall cpu cycles spent.")

DEFINE_MAYBE_BOOL(
    memory_saver_mode,
    "Forces memory saver mode on or off, disregarding any dynamic signals. "
    "Memory saver tries to keep memory footprint low at the expense of extra "
    "cpu cycles.")

DEFINE_BOOL(efficiency_mode_disable_turbofan, false,
            "Defer tier-up to turbofan while in efficiency mode.")
DEFINE_INT(efficiency_mode_delay_turbofan_multiply, 3,
           "Delay tier-up to turbofan to a certain invocation count multipier "
           "while in efficiency mode.")

// Flag to select wasm trace mark type
DEFINE_STRING(
    wasm_trace_native, nullptr,
    "Select which native code sequence to use for wasm trace instruction: "
    "default or cpuid")

#ifdef V8_JITLESS
#define V8_JITLESS_BOOL true
DEFINE_BOOL_READONLY(jitless, true,
                     "Disable runtime allocation of executable memory.")
#else
#define V8_JITLESS_BOOL false
DEFINE_BOOL(jitless, V8_LITE_MODE_BOOL,
            "Disable runtime allocation of executable memory.")
#endif  // V8_JITLESS

// Jitless V8 has a few implications:
// Field type tracking is only used by TurboFan.
DEFINE_NEG_IMPLICATION(jitless, track_field_types)
DEFINE_NEG_IMPLICATION(jitless, script_context_cells)
DEFINE_NEG_IMPLICATION(jitless, function_context_cells)
// No code generation at runtime.
DEFINE_IMPLICATION(jitless, regexp_interpret_all)
DEFINE_NEG_IMPLICATION(jitless, turbofan)
DEFINE_NEG_IMPLICATION(jitless, turboshaft)
#ifdef V8_ENABLE_SPARKPLUG
DEFINE_NEG_IMPLICATION(jitless, sparkplug)
DEFINE_NEG_IMPLICATION(jitless, always_sparkplug)
#endif  // V8_ENABLE_SPARKPLUG
#ifdef V8_ENABLE_MAGLEV
DEFINE_NEG_IMPLICATION(jitless, maglev)
#endif  // V8_ENABLE_MAGLEV
DEFINE_NEG_IMPLICATION(jitless, turbolev)
DEFINE_NEG_IMPLICATION(jitless, turbolev_future)
DEFINE_NEG_IMPLICATION(jitless, wasm_in_js_inlining_body)
DEFINE_NEG_IMPLICATION(jitless, wasm_in_js_inlining_wrapper)
// Doesn't work without an executable code space.
DEFINE_NEG_IMPLICATION(jitless, interpreted_frames_native_stack)

DEFINE_BOOL(
    disable_optimizing_compilers, false,
    "Disable all optimizing compilers while leaving baseline compilers enabled")
// Disable all optimizing JavaScript compilers.
// JavaScript code can execute either in Ignition or Sparkplug.
DEFINE_NEG_IMPLICATION(disable_optimizing_compilers, turbofan)
DEFINE_NEG_IMPLICATION(disable_optimizing_compilers, turboshaft)
DEFINE_NEG_IMPLICATION(disable_optimizing_compilers, maglev)
DEFINE_NEG_IMPLICATION(disable_optimizing_compilers, turbolev)
DEFINE_NEG_IMPLICATION(disable_optimizing_compilers, turbolev_future)
DEFINE_NEG_IMPLICATION(disable_optimizing_compilers, wasm_in_js_inlining_body)
DEFINE_NEG_IMPLICATION(disable_optimizing_compilers,
                       wasm_in_js_inlining_wrapper)
#if V8_ENABLE_WEBASSEMBLY
// Disable optimizing Wasm compilers. Wasm code must execute with Liftoff.
DEFINE_IMPLICATION(disable_optimizing_compilers, liftoff)
DEFINE_NEG_IMPLICATION(disable_optimizing_compilers, wasm_tier_up)
DEFINE_NEG_IMPLICATION(disable_optimizing_compilers, wasm_dynamic_tiering)
#endif  // V8_ENABLE_WEBASSEMBLY
// Field type tracking is only used by TurboFan, so can be disabled.
DEFINE_NEG_IMPLICATION(disable_optimizing_compilers, track_field_types)
DEFINE_NEG_IMPLICATION(disable_optimizing_compilers, script_context_cells)
DEFINE_NEG_IMPLICATION(disable_optimizing_compilers, function_context_cells)

DEFINE_BOOL(memory_protection_keys, true,
            "protect code memory with PKU if available")
DEFINE_BOOL(force_memory_protection_keys, false,
            "fail if memory protection key support is not available")
DEFINE_IMPLICATION(force_memory_protection_keys, memory_protection_keys)

DEFINE_BOOL(assert_types, false,
            "generate runtime type assertions to test the typer")
// TODO(tebbi): Support allocating types from background thread.
DEFINE_NEG_IMPLICATION(assert_types, concurrent_recompilation)
DEFINE_NEG_IMPLICATION(assert_types, concurrent_builtin_generation)
DEFINE_EXPERIMENTAL_FEATURE(
    turboshaft_assert_types,
    "generate runtime type assertions to test the turboshaft type system")
DEFINE_NEG_IMPLICATION(turboshaft_assert_types, concurrent_recompilation)
DEFINE_NEG_IMPLICATION(turboshaft_assert_types, concurrent_builtin_generation)

// Enable verification of SimplifiedLowering in debug builds.
DEFINE_BOOL(verify_simplified_lowering, false,
            "verify graph generated by simplified lowering")

DEFINE_DEVELOPER_FLAG(trace_compilation_dependencies, "trace code dependencies")
// Depend on --trace-deopt-verbose for reporting dependency invalidations.
DEFINE_IMPLICATION(trace_compilation_dependencies, trace_deopt_verbose)

DEFINE_BOOL(unmap_holes, true, "unmap the page containing the holes.")

#ifdef V8_ALLOCATION_SITE_TRACKING
#define V8_ALLOCATION_SITE_TRACKING_BOOL true
#else
#define V8_ALLOCATION_SITE_TRACKING_BOOL false
#endif

DEFINE_BOOL_READONLY(allocation_site_tracking, V8_ALLOCATION_SITE_TRACKING_BOOL,
                     "Enable allocation site tracking")
DEFINE_NEG_NEG_IMPLICATION(allocation_site_tracking,
                           allocation_site_pretenuring)

// Flags for experimental implementation features.
DEFINE_BOOL(allocation_site_pretenuring, true,
            "pretenure with allocation sites")
DEFINE_BOOL(page_promotion, true, "promote pages based on utilization")
DEFINE_INT(page_promotion_threshold, 70,
           "min percentage of live bytes on a page to enable fast evacuation "
           "in full GCs")
DEFINE_INT(minor_ms_page_promotion_threshold, 50,
           "min percentage of live bytes on a page to enable fast evacuation "
           "in MinorMS")
DEFINE_INT(minor_ms_page_promotion_max_lab_threshold, 30,
           "max percentage of labs out of a page to still be considered for "
           "page promotion")
DEFINE_UINT(minor_ms_max_page_age, 4,
            "max age for a page after which it is force promoted to old space")

DEFINE_DEVELOPER_FLAG(trace_page_promotions, "trace page promotion decisions")
DEFINE_DEVELOPER_FLAG(trace_pretenuring,
                      "trace pretenuring decisions of HAllocate instructions")
DEFINE_DEVELOPER_FLAG(trace_pretenuring_statistics,
                      "trace allocation site pretenuring statistics")
DEFINE_DEVELOPER_FLAG(trace_resize_large_object,
                      "trace resizing of large objects")
DEFINE_BOOL(track_field_types, true, "track field types")
DEFINE_DEVELOPER_FLAG(trace_block_coverage,
                      "trace collected block coverage information")
DEFINE_DEVELOPER_FLAG(trace_protector_invalidation,
                      "trace protector cell invalidations")
DEFINE_BOOL(
    zero_unused_memory, true,
    "Zero unused memory (except for memory which was discarded) on memory "
    "reducing GCs.")
DEFINE_BOOL(high_end_android, false,
            "Enables high-end mode unconditionally for Android.")
DEFINE_UINT(high_end_android_physical_memory_threshold, 8,
            "Enables high-end mode for devices with more than X GB of physical "
            "memory (if X greater than 0).")

#ifdef V8_MINORMS_STRING_SHORTCUTTING
DEFINE_BOOL(minor_ms_shortcut_strings, false,
            "short cut strings during marking")
// String shortcutting currently doesn't work with concurrent marking.
DEFINE_NEG_IMPLICATION(minor_ms_shortcut_strings, concurrent_minor_ms_marking)
#else
DEFINE_BOOL_READONLY(minor_ms_shortcut_strings, false,
                     "short cut strings during marking")
#endif

DEFINE_EXPERIMENTAL_FEATURE(feedback_normalization,
                            "feed back normalization to constructors")
// TODO(jkummerow): This currently adds too much load on the stub cache.
DEFINE_BOOL_READONLY(internalize_on_the_fly, true,
                     "internalize string keys for generic keyed ICs on the fly")

// Flags for data representation optimizations
DEFINE_BOOL(unbox_double_arrays, true, "automatically unbox arrays of doubles")
DEFINE_BOOL_READONLY(string_slices, true, "use string slices")

// Tiering: Sparkplug / feedback vector allocation.
DEFINE_INT(invocation_count_for_feedback_allocation, 8,
           "invocation count required for allocating feedback vectors")

// Tiering: Maglev.
#if defined(ANDROID)
DEFINE_INT(invocation_count_for_maglev, 1000,
           "invocation count required for optimizing with Maglev")
#else
DEFINE_INT(invocation_count_for_maglev, 400,
           "invocation count required for optimizing with Maglev")
#endif  // ANDROID
DEFINE_INT(invocation_count_for_maglev_osr, 100,
           "invocation count required for maglev OSR")
DEFINE_INT(osr_from_maglev, 3,
           "bitset mode for OSR from Maglev to Turbofan (0=off, 1=on OSR "
           "compile, 2=if loop was OSR'd, 4=always)")
DEFINE_FLOAT(
    osr_from_maglev_interrupt_scale_factor, 0.8,
    "Scale interrupt budget reduction for OSR from Maglev vs. OSR to Maglev")
DEFINE_BOOL(always_osr_from_maglev, false,
            "whether we try to OSR to Turbofan from any Maglev (alias for "
            "--osr-from-maglev=4)")
DEFINE_VALUE_IMPLICATION(always_osr_from_maglev, osr_from_maglev, 4)

// Tiering: Turbofan.
DEFINE_INT(invocation_count_for_turbofan, 3000,
           "invocation count required for optimizing with TurboFan")
DEFINE_INT(invocation_count_for_osr, 500, "invocation count required for OSR")
DEFINE_FLOAT(invocation_count_for_osr_factor_while_tiering_in_progress, 3.0,
             "invocation count factor while waiting for code to compile")
DEFINE_UINT(osr_to_tierup, 1,
            "number to decrease the invocation budget by when we follow OSR")
DEFINE_INT(minimum_invocations_after_ic_update, 500,
           "How long to minimally wait after IC update before tier up")
DEFINE_INT(minimum_invocations_before_optimization, 2,
           "Minimum number of invocations we need before non-OSR optimization")

// Tiering: JIT fuzzing.
//
// When --jit-fuzzing is enabled, various tiering related thresholds are
// lowered so that the different JIT tiers are reached roughly within a few
// dozen executions of the code instead of a few hundred or thousand. As a rule
// of thumb, aiming for things to happen 5x to 10x sooner in this mode than
// they otherwise would is probably not unreasonable.
//
// WARNING: Avoid adding implications to this flag unless they always make
// sense. Unnecessary implications reduce default configuration coverage and
// limit fuzzer exploration. Prefer flag randomization in fuzzer configs
// instead.
DEFINE_BOOL(jit_fuzzing, false,
            "Set JIT tiering thresholds suitable for JIT fuzzing")
// Tier up to Maglev should happen soon afterwards.
DEFINE_VALUE_IMPLICATION(jit_fuzzing, invocation_count_for_maglev, 10)
// And tier up to Turbofan should happen after a couple dozen or so executions.
DEFINE_VALUE_IMPLICATION(jit_fuzzing, invocation_count_for_turbofan, 20)
// Additionally, some other JIT-related thresholds should also be lowered.
DEFINE_VALUE_IMPLICATION(jit_fuzzing, invocation_count_for_osr, 5)
DEFINE_VALUE_IMPLICATION(jit_fuzzing, invocation_count_for_maglev_osr, 1)
DEFINE_VALUE_IMPLICATION(jit_fuzzing, minimum_invocations_after_ic_update, 5)

#if V8_ENABLE_WEBASSEMBLY
// Wasm tiering thresholds.
DEFINE_VALUE_IMPLICATION(jit_fuzzing,
  wasm_wrapper_tiering_budget, 1)
DEFINE_VALUE_IMPLICATION(jit_fuzzing,
  wasm_tiering_budget, 1)
DEFINE_IMPLICATION(jit_fuzzing, wasm_inlining_ignore_call_counts)
#endif  // V8_ENABLE_WEBASSEMBLY

#if defined(V8_OS_AIX)
DEFINE_BOOL(use_std_math_pow, false,
            "use std::pow instead of our custom implementation")
#else
DEFINE_BOOL(use_std_math_pow, true,
            "use std::pow instead of our custom implementation")
#endif

// Flags for inline caching and feedback vectors.
DEFINE_BOOL(use_ic, true, "use inline caching")
// Note: when fuzzing, it's typically desired to disable it as that allows
// reaching higher JIT tiers faster (although a hard implication isn't used, to
// avoid having production path untested).
DEFINE_BOOL(lazy_feedback_allocation, true, "Allocate feedback vectors lazily")
DEFINE_BOOL(stress_ic, false, "exercise interesting paths in ICs more often")

// Flags for Ignition.
DEFINE_BOOL(ignition_elide_noneffectful_bytecodes, true,
            "elide bytecodes which won't have any external effect")
DEFINE_BOOL(ignition_reo, true, "use ignition register equivalence optimizer")
DEFINE_BOOL(ignition_filter_expression_positions, true,
            "filter expression positions before the bytecode pipeline")
DEFINE_BOOL(ignition_share_named_property_feedback, true,
            "share feedback slots when loading the same named property from "
            "the same object")
DEFINE_BOOL(ignition_elide_redundant_tdz_checks, true,
            "elide TDZ checks dominated by other TDZ checks")
DEFINE_DEVELOPER_FLAG(print_bytecode,
                      "print bytecode generated by ignition interpreter")
DEFINE_BOOL(enable_lazy_source_positions, V8_LAZY_SOURCE_POSITIONS_BOOL,
            "skip generating source positions during initial compile but "
            "regenerate when actually required")
// Note: when fuzzing, it's typically desired to enable it (except for sandbox
// fuzzers since it might trigger benign CHECKs that could mask actual sandbox
// violations).
DEFINE_BOOL(stress_lazy_source_positions, false,
            "collect lazy source positions immediately after lazy compile")
// Compile functions twice and ensure that the generated bytecode is the same.
// This can help find bugs such as crbug.com/1394403 as it avoids the need for
// bytecode aging to kick in to trigger the recomplication.
//
// Note: when fuzzing, it's typically desired to enable it (except for sandbox
// fuzzers since it might trigger benign CHECKs that could mask actual sandbox
// violations).
DEFINE_BOOL(stress_lazy, false, "stress lazy compilation")
DEFINE_STRING(print_bytecode_filter, "*",
              "filter for selecting which functions to print bytecode")
DEFINE_BOOL(omit_default_ctors, true, "omit calling default ctors in bytecode")
#ifdef V8_TRACE_UNOPTIMIZED
DEFINE_DEVELOPER_FLAG(
    trace_unoptimized,
    "trace the bytecodes executed by all unoptimized execution")
DEFINE_DEVELOPER_FLAG(
    trace_ignition, "trace the bytecodes executed by the ignition interpreter")
DEFINE_DEVELOPER_FLAG(trace_baseline_exec,
                      "trace the bytecodes executed by the baseline code")
DEFINE_WEAK_IMPLICATION(trace_unoptimized, trace_ignition)
DEFINE_WEAK_IMPLICATION(trace_unoptimized, trace_baseline_exec)
#endif
#ifdef V8_TRACE_FEEDBACK_UPDATES
DEFINE_BOOL(
    trace_feedback_updates, false,
    "trace updates to feedback vectors during ignition interpreter execution.")
#endif
DEFINE_DEVELOPER_FLAG(
    trace_ignition_codegen,
    "trace the codegen of ignition interpreter bytecode handlers")

DEFINE_DEVELOPER_FLAG(trace_track_allocation_sites,
                      "trace the tracking of allocation sites")
DEFINE_DEVELOPER_FLAG(trace_migration, "trace object migration")
DEFINE_DEVELOPER_FLAG(trace_generalization, "trace map generalization")


// Flags for Sparkplug
#undef FLAG
#if V8_ENABLE_SPARKPLUG
#define FLAG FLAG_FULL
#else
#define FLAG FLAG_READONLY
#endif
DEFINE_BOOL(sparkplug, ENABLE_SPARKPLUG_BY_DEFAULT,
            "enable Sparkplug baseline compiler")
DEFINE_BOOL(always_sparkplug, false, "directly tier up to Sparkplug code")
#if V8_ENABLE_SPARKPLUG
DEFINE_IMPLICATION(always_sparkplug, sparkplug)
// Note: when fuzzing, it's typically desired to disable it as that allows
// reaching higher JIT tiers faster (although a hard implication isn't used, to
// avoid having production path untested).
DEFINE_BOOL(baseline_batch_compilation, true, "batch compile Sparkplug code")
#if defined(V8_OS_DARWIN) && defined(V8_HOST_ARCH_ARM64) && \
    !V8_HEAP_USE_PTHREAD_JIT_WRITE_PROTECT &&               \
    !V8_HEAP_USE_BECORE_JIT_WRITE_PROTECT
// M1 requires W^X.
DEFINE_BOOL_READONLY(concurrent_sparkplug, false,
                     "compile Sparkplug code in a background thread")
#else
DEFINE_BOOL(concurrent_sparkplug, ENABLE_SPARKPLUG_BY_DEFAULT,
            "compile Sparkplug code in a background thread")
DEFINE_WEAK_IMPLICATION(future, concurrent_sparkplug)
DEFINE_NEG_IMPLICATION(predictable, concurrent_sparkplug)
DEFINE_NEG_IMPLICATION(single_threaded, concurrent_sparkplug)
DEFINE_NEG_IMPLICATION(jitless, concurrent_sparkplug)
#endif
DEFINE_UINT(
    concurrent_sparkplug_max_threads, 1,
    "max number of threads that concurrent Sparkplug can use (0 for unbounded)")
DEFINE_BOOL(concurrent_sparkplug_high_priority_threads, false,
            "use high priority compiler threads for concurrent Sparkplug")
#else
DEFINE_BOOL(baseline_batch_compilation, false, "batch compile Sparkplug code")
DEFINE_BOOL_READONLY(concurrent_sparkplug, false,
                     "compile Sparkplug code in a background thread")
#endif
DEFINE_STRING(sparkplug_filter, "*", "filter for Sparkplug baseline compiler")
DEFINE_BOOL(sparkplug_needs_short_builtins, false,
            "only enable Sparkplug baseline compiler when "
            "--short-builtin-calls are also enabled")
DEFINE_INT(baseline_batch_compilation_threshold, 4 * KB,
           "the estimated instruction size of a batch to trigger compilation")
DEFINE_DEVELOPER_FLAG(trace_baseline, "trace baseline compilation")
DEFINE_DEVELOPER_FLAG(trace_baseline_batch_compilation,
                      "trace baseline batch compilation")
DEFINE_WEAK_IMPLICATION(trace_baseline, trace_baseline_batch_compilation)
#undef FLAG
#define FLAG FLAG_FULL

// Internalize into a shared string table in the shared isolate
DEFINE_BOOL(shared_strings, false, "allow sharing of strings")
DEFINE_IMPLICATION(shared_strings, shared_heap)
DEFINE_EXPERIMENTAL_FEATURE(shared_string_table,
                            "internalize strings into shared table")
DEFINE_IMPLICATION(shared_string_table, shared_strings)
DEFINE_IMPLICATION(harmony_struct, shared_string_table)
DEFINE_BOOL_READONLY(always_use_string_forwarding_table, false,
                     "use string forwarding table instead of thin strings for "
                     "all strings (experimental)")
DEFINE_IMPLICATION(always_use_string_forwarding_table, experimental)
// With --always-use-string-forwarding-table, we can have young generation
// string entries in the forwarding table, requiring table updates when these
// strings get promoted to old space. Parallel GCs in client isolates
// (enabled by --shared-heap) are not supported using a single shared
// forwarding table.
DEFINE_NEG_IMPLICATION(shared_heap, always_use_string_forwarding_table)

DEFINE_BOOL(transition_strings_during_gc_with_stack, false,
            "Transition strings during a full GC with stack")
DEFINE_NEG_IMPLICATION(shared_string_table,
                       transition_strings_during_gc_with_stack)

DEFINE_SIZE_T(initial_shared_heap_size, 0,
              "initial size of the shared heap (in Mbytes); "
              "other heap size flags (e.g. initial_heap_size) take precedence")
DEFINE_SIZE_T(
    max_shared_heap_size, 0,
    "max size of the shared heap (in Mbytes); "
    "other heap size flags (e.g. max_shared_heap_size) take precedence")

DEFINE_BOOL(concurrent_builtin_generation, false,
            "generate builtins concurrently on separate threads in mksnapshot")

// Flags for concurrent recompilation.
DEFINE_BOOL(concurrent_recompilation, true,
            "optimizing hot functions asynchronously on a separate thread")
DEFINE_DEVELOPER_FLAG(trace_concurrent_recompilation,
                      "track concurrent recompilation")
DEFINE_INT(concurrent_recompilation_queue_length, 8,
           "the length of the concurrent compilation queue")
DEFINE_INT(concurrent_recompilation_delay, 0,
           "artificial compilation delay in ms")
DEFINE_BOOL(concurrent_recompilation_front_running, true,
            "move compile jobs to the front if recompilation is requested "
            "multiple times")
DEFINE_UINT(
    concurrent_turbofan_max_threads, 4,
    "max number of threads that concurrent Turbofan can use (0 for unbounded)")
DEFINE_BOOL(
    stress_concurrent_inlining, false,
    "create additional concurrent optimization jobs but throw away result")
DEFINE_IMPLICATION(stress_concurrent_inlining, concurrent_recompilation)
DEFINE_IMPLICATION(stress_concurrent_inlining, turbofan)
DEFINE_NEG_IMPLICATION(stress_concurrent_inlining, lazy_feedback_allocation)
DEFINE_WEAK_VALUE_IMPLICATION(stress_concurrent_inlining,
                              invocation_count_for_turbofan, 150)
DEFINE_BOOL(maglev_overwrite_budget, false,
            "whether maglev resets the interrupt budget")
DEFINE_WEAK_IMPLICATION(maglev, maglev_overwrite_budget)
DEFINE_NEG_IMPLICATION(stress_concurrent_inlining, maglev_overwrite_budget)
DEFINE_WEAK_VALUE_IMPLICATION(maglev_overwrite_budget,
                              invocation_count_for_turbofan, 16000)
DEFINE_BOOL(maglev_overwrite_osr_budget, false,
            "whether maglev resets the OSR interrupt budget")
DEFINE_WEAK_IMPLICATION(maglev_osr, maglev_overwrite_osr_budget)
DEFINE_NEG_IMPLICATION(stress_concurrent_inlining, maglev_overwrite_osr_budget)
DEFINE_WEAK_VALUE_IMPLICATION(maglev_overwrite_osr_budget,
                              invocation_count_for_osr, 800)
DEFINE_BOOL(stress_concurrent_inlining_attach_code, false,
            "create additional concurrent optimization jobs")
DEFINE_IMPLICATION(stress_concurrent_inlining_attach_code,
                   stress_concurrent_inlining)
DEFINE_INT(max_serializer_nesting, 25,
           "maximum levels for nesting child serializers")
DEFINE_DEVELOPER_FLAG(trace_heap_broker_verbose,
                      "trace the heap broker verbosely (all reports)")
DEFINE_DEVELOPER_FLAG(trace_heap_broker,
                      "trace the heap broker (reports on missing data only)")
DEFINE_IMPLICATION(trace_heap_broker_verbose, trace_heap_broker)
DEFINE_IMPLICATION(trace_heap_broker, trace_pending_allocations)

// Flags for stress-testing the compiler.
DEFINE_INT(stress_runs, 0, "number of stress runs")
DEFINE_INT(deopt_every_n_times, 0,
           "deoptimize every n times a deopt point is passed")
DEFINE_BOOL(print_deopt_stress, false, "print number of possible deopt points")
DEFINE_BOOL(disable_loop_stack_checks, false,
            "disable loop stack checks (for testing/fuzzing only)")

// Flags for TurboFan.
#ifdef V8_ENABLE_TURBOFAN
#define V8_ENABLE_TURBOFAN_BOOL true
DEFINE_BOOL(turbofan, true,
            "use the Turbofan optimizing compiler for JavaScript code "
            "(Wasm uses separate flags)")
// TODO(leszeks): Temporary alias until we make sure all our infra is passing
// --turbofan instead of --opt.
DEFINE_ALIAS_BOOL(opt, turbofan)
#else
#define V8_ENABLE_TURBOFAN_BOOL false
DEFINE_BOOL_READONLY(turbofan, false,
                     "use the Turbofan optimizing compiler for JavaScript code "
                     "(Wasm uses separate flags)")
DEFINE_BOOL_READONLY(opt, false,
                     "use the Turbofan optimizing compiler for JavaScript code "
                     "(Wasm uses separate flags)")
#endif  // V8_ENABLE_TURBOFAN

DEFINE_BOOL(
    turbo_always_optimize_spills, true,
    "optimize placement of all spill instructions, not just loop-top phis")

DEFINE_BOOL(turbo_wasm_address_reassociation, true,
            "refactor address components for immediate indexing")

DEFINE_BOOL(concurrent_turbo_tracing, false,
            "allow concurrent compilation to happen in combination with "
            "trace-turbo* flags")

DEFINE_BOOL(
    optimize_maglev_optimizes_to_turbofan, false,
    "make OptimizeMaglevOnNextCall optimize to turbofan instead of maglev")

DEFINE_STRING(turbo_filter, "*", "optimization filter for TurboFan compiler")
DEFINE_DEVELOPER_FLAG(trace_turbo, "trace generated TurboFan IR")
DEFINE_NEG_IMPLICATION(trace_turbo, concurrent_builtin_generation)
DEFINE_WEAK_IMPLICATION(trace_turbo, concurrent_turbo_tracing)
DEFINE_STRING(trace_turbo_path, nullptr,
              "directory to dump generated TurboFan IR to")
DEFINE_STRING(trace_turbo_filter, "*",
              "filter for tracing turbofan compilation")
DEFINE_DEVELOPER_FLAG(trace_turbo_graph, "trace generated TurboFan graphs")
DEFINE_NEG_IMPLICATION(trace_turbo_graph, concurrent_builtin_generation)
DEFINE_DEVELOPER_FLAG(trace_turbo_scheduled, "trace TurboFan IR with schedule")
DEFINE_IMPLICATION(trace_turbo_scheduled, trace_turbo_graph)
DEFINE_STRING(trace_turbo_file_prefix, "turbo",
              "trace turbo graph to a file with given prefix")
DEFINE_STRING(trace_turbo_cfg_file, nullptr,
              "trace turbo cfg graph (for C1 visualizer) to a given file name")
DEFINE_BOOL(trace_turbo_types, true, "trace TurboFan's types")
DEFINE_BOOL(trace_turbo_scheduler, false, "trace TurboFan's scheduler")
DEFINE_BOOL(trace_turbo_reduction, false, "trace TurboFan's various reducers")
DEFINE_BOOL(trace_turbo_bailouts, false, "trace TurboFan's various bailouts")
#ifdef V8_ENABLE_SLOW_TRACING
#define DEFINE_SLOW_TRACING_BOOL DEFINE_BOOL
#else
#define DEFINE_SLOW_TRACING_BOOL DEFINE_BOOL_READONLY
#endif  // V8_ENABLE_SLOW_TRACING
DEFINE_SLOW_TRACING_BOOL(trace_turbo_trimming, false,
                         "trace TurboFan's graph trimmer")
DEFINE_SLOW_TRACING_BOOL(trace_turbo_jt, false,
                         "trace TurboFan's jump threading")
DEFINE_SLOW_TRACING_BOOL(trace_turbo_ceq, false,
                         "trace TurboFan's control equivalence")
DEFINE_SLOW_TRACING_BOOL(trace_turbo_loop, false,
                         "trace TurboFan's loop optimizations")
DEFINE_SLOW_TRACING_BOOL(trace_turbo_alloc, false,
                         "trace TurboFan's register allocator")
DEFINE_SLOW_TRACING_BOOL(trace_all_uses, false, "trace all use positions")
DEFINE_SLOW_TRACING_BOOL(trace_representation, false,
                         "trace representation types")
DEFINE_BOOL(
    trace_turbo_stack_accesses, false,
    "trace stack load/store counters for optimized code in run-time (x64 only)")

// When fuzzing and concurrent compilation is enabled, disable Turbofan
// tracing flags since reading/printing heap state is not thread-safe and
// leads to false positives on TSAN bots.
// TODO(chromium:1205289): Teach relevant fuzzers to not pass TF tracing
// flags instead, and remove this section.
DEFINE_BOOL(fuzzing_and_concurrent_recompilation, true,
            "fuzzing && concurrent_recompilation")
DEFINE_NEG_NEG_IMPLICATION(fuzzing, fuzzing_and_concurrent_recompilation)
DEFINE_NEG_NEG_IMPLICATION(concurrent_recompilation,
                           fuzzing_and_concurrent_recompilation)
DEFINE_DISABLE_FLAG_IMPLICATION(fuzzing_and_concurrent_recompilation,
                                trace_turbo)
DEFINE_DISABLE_FLAG_IMPLICATION(fuzzing_and_concurrent_recompilation,
                                trace_turbo_graph)
DEFINE_DISABLE_FLAG_IMPLICATION(fuzzing_and_concurrent_recompilation,
                                trace_turbo_scheduled)
DEFINE_DISABLE_FLAG_IMPLICATION(fuzzing_and_concurrent_recompilation,
                                trace_turbo_reduction)
#ifdef V8_ENABLE_SLOW_TRACING
// If expensive tracing is disabled via a build flag, the following flags
// cannot be disabled (because they are already).
DEFINE_DISABLE_FLAG_IMPLICATION(fuzzing_and_concurrent_recompilation,
                                trace_turbo_trimming)
DEFINE_DISABLE_FLAG_IMPLICATION(fuzzing_and_concurrent_recompilation,
                                trace_turbo_jt)
DEFINE_DISABLE_FLAG_IMPLICATION(fuzzing_and_concurrent_recompilation,
                                trace_turbo_ceq)
DEFINE_DISABLE_FLAG_IMPLICATION(fuzzing_and_concurrent_recompilation,
                                trace_turbo_loop)
DEFINE_DISABLE_FLAG_IMPLICATION(fuzzing_and_concurrent_recompilation,
                                trace_turbo_alloc)
DEFINE_DISABLE_FLAG_IMPLICATION(fuzzing_and_concurrent_recompilation,
                                trace_all_uses)
DEFINE_DISABLE_FLAG_IMPLICATION(fuzzing_and_concurrent_recompilation,
                                trace_representation)
#endif
DEFINE_DISABLE_FLAG_IMPLICATION(fuzzing_and_concurrent_recompilation,
                                trace_turbo_stack_accesses)

DEFINE_BOOL(turbo_verify, DEBUG_BOOL, "verify TurboFan graphs at each phase")
DEFINE_STRING(turbo_verify_machine_graph, nullptr,
              "verify TurboFan machine graph before instruction selection")
#ifdef ENABLE_VERIFY_CSA
DEFINE_BOOL(verify_csa, DEBUG_BOOL,
            "verify TurboFan machine graph of code stubs")
#else
// Define the flag as read-only-false so that code still compiles even in the
// non-ENABLE_VERIFY_CSA configuration.
DEFINE_BOOL_READONLY(verify_csa, false,
                     "verify TurboFan machine graph of code stubs")
#endif  // ENABLE_VERIFY_CSA
DEFINE_DEVELOPER_FLAG(trace_verify_csa, "trace code stubs verification")
DEFINE_STRING(csa_trap_on_node, nullptr,
              "trigger break point when a node with given id is created in "
              "given stub. The format is: StubName,NodeId")
DEFINE_STRING(
    builtins_effects_src, nullptr,
    "path where to generate builtins-effects.h (used for mksnapshot only)")
DEFINE_BOOL_READONLY(fixed_array_bounds_checks, true,
                     "enable FixedArray bounds checks")
DEFINE_BOOL(turbo_stats, false, "print TurboFan statistics")
DEFINE_BOOL(turbo_stats_nvp, false,
            "print TurboFan statistics in machine-readable format")
DEFINE_BOOL(turbo_stats_wasm, false,
            "print TurboFan statistics of wasm compilations")
DEFINE_BOOL_READONLY(turbo_splitting, true,
                     "split nodes during scheduling in TurboFan")
DEFINE_BOOL(turbo_inlining, true, "enable inlining in TurboFan")
DEFINE_BOOL(turbo_elide_frames, true, "enable frame elision in TurboFan")
DEFINE_INT(max_inlined_bytecode_size, 460,
           "maximum size of bytecode for a single inlining")
// {max_inlined_bytecode_size_cumulative} and
// {max_inlined_bytecode_size_absolute} are the inlining limits for the regular
// case. By being not too high, we ensure that Turbofan compilation doesn't take
// too long.
// Still, inlining very small functions is usually very beneficial (removes call
// overhead, enable better load elimination and escape analysis, removes heap
// number allocations...), so small functions usually ignore the limits above
// and use {max_inlined_bytecode_size_small_total} instead.
DEFINE_INT(max_inlined_bytecode_size_cumulative, 920,
           "maximum cumulative size of bytecode considered for inlining")
DEFINE_INT(max_inlined_bytecode_size_absolute, 4600,
           "maximum absolute size of bytecode considered for inlining")
DEFINE_INT(max_inlined_bytecode_size_small_total, 30000,
           "maximum size of small functions' bytecode that can be inlining")
DEFINE_FLOAT(
    reserve_inline_budget_scale_factor, 1.2,
    "scale factor of bytecode size used to calculate the inlining budget")
DEFINE_INT(max_inlined_bytecode_size_small, 30,
           "maximum size of bytecode considered for small function inlining")
DEFINE_INT(max_inlined_bytecode_size_small_with_heapnum_in_out, 75,
           "maximum size of bytecode considered for small function inlining, "
           "when the function call has a HeapNumber as input or output")
DEFINE_INT(max_optimized_bytecode_size, 60 * KB,
           "maximum bytecode size to "
           "be considered for turbofan optimization; too high values may cause "
           "the compiler to hit (release) assertions")
DEFINE_INT(max_maglev_optimized_bytecode_size, 512 * KB,
           "maximum bytecode size to be considered for maglev optimization")
DEFINE_FLOAT(min_inlining_frequency, 0.15, "minimum frequency for inlining")
DEFINE_WEAK_VALUE_IMPLICATION(maglev, min_inlining_frequency, 0.05)
DEFINE_BOOL(stress_inline, false,
            "set high thresholds for inlining to inline as much as possible")
DEFINE_VALUE_IMPLICATION(stress_inline, max_inlined_bytecode_size, 999999)
DEFINE_VALUE_IMPLICATION(stress_inline, max_inlined_bytecode_size_cumulative,
                         999999)
DEFINE_VALUE_IMPLICATION(stress_inline, max_inlined_bytecode_size_absolute,
                         999999)
DEFINE_VALUE_IMPLICATION(stress_inline, min_inlining_frequency, 0.)
DEFINE_DEVELOPER_FLAG(trace_turbo_inlining, "trace TurboFan inlining")
DEFINE_BOOL(turbo_inline_array_builtins, true,
            "inline array builtins in TurboFan code")
DEFINE_BOOL(use_osr, true, "use on-stack replacement")
DEFINE_BOOL(maglev_osr, true, "use maglev as on-stack replacement target")

// Threshold to determine if a function is eager or non-eager inlined. Separate
// cumulative budgets (small vs. large) still apply regardless of the inlining
// type.
DEFINE_INT(max_maglev_eager_inlined_bytecode_size, 30,
           "maximum size of bytecode considered for eager inlining")
DEFINE_INT(max_turbolev_eager_inlined_bytecode_size, 30,
           "maximum size of bytecode considered for eager inlining")

// When using maglev as OSR target allow us to tier up further
DEFINE_WEAK_VALUE_IMPLICATION(maglev_osr, osr_from_maglev, 2)
DEFINE_VALUE_IMPLICATION(!use_osr, maglev_osr, false)
DEFINE_VALUE_IMPLICATION(!turbofan, osr_from_maglev, 0)
DEFINE_VALUE_IMPLICATION(!turbofan, always_osr_from_maglev, false)
DEFINE_BOOL(concurrent_osr, true, "enable concurrent OSR")

DEFINE_INT(maglev_allocation_folding, 2, "maglev allocation folding level")
DEFINE_BOOL(maglev_escape_analysis, true,
            "avoid inlined allocation of objects that cannot escape")
DEFINE_DEVELOPER_FLAG(trace_maglev_escape_analysis,
                      "trace maglev escape analysis")
DEFINE_EXPERIMENTAL_FEATURE(maglev_object_tracking,
                            "track object changes to avoid escaping them")
DEFINE_DEVELOPER_FLAG(trace_maglev_object_tracking,
                      "trace load/stores from maglev virtual objects")
DEFINE_WEAK_IMPLICATION(trace_maglev_graph_building,
                        trace_maglev_object_tracking)
DEFINE_WEAK_IMPLICATION(trace_maglev_graph_building, maglev_print_bytecode)

// TODO(dmercadier): fix and re-enable string builder.
DEFINE_BOOL_READONLY(turbo_string_builder, false,
                     "use TurboFan fast string builder")

DEFINE_DEVELOPER_FLAG(trace_osr, "trace on-stack replacement")
DEFINE_BOOL(log_or_trace_osr, false,
            "internal helper flag, please use --trace-osr instead.")
DEFINE_IMPLICATION(trace_osr, log_or_trace_osr)
DEFINE_IMPLICATION(log_function_events, log_or_trace_osr)

DEFINE_BOOL(analyze_environment_liveness, true,
            "analyze liveness of environment slots and zap dead values")
DEFINE_DEVELOPER_FLAG(trace_environment_liveness,
                      "trace liveness of local variable slots")
DEFINE_BOOL(turbo_load_elimination, true, "enable load elimination in TurboFan")
DEFINE_DEVELOPER_FLAG(trace_turbo_load_elimination,
                      "trace TurboFan load elimination")
DEFINE_BOOL(turbo_profiling, false, "enable basic block profiling in TurboFan")
DEFINE_NEG_IMPLICATION(turbo_profiling, concurrent_builtin_generation)
DEFINE_BOOL(turbo_profiling_verbose, false,
            "enable basic block profiling in TurboFan, and include each "
            "function's schedule and disassembly in the output")
DEFINE_IMPLICATION(turbo_profiling_verbose, turbo_profiling)
DEFINE_STRING(
    turbo_profiling_output, nullptr,
    "emit data about basic block usage in builtins to this file "
    "(requires that V8 was built with v8_enable_builtins_profiling=true)")
DEFINE_BOOL(reorder_builtins, false,
            "enable builtin reordering when run mksnapshot.")
DEFINE_NEG_IMPLICATION(reorder_builtins, concurrent_builtin_generation)

DEFINE_BOOL(abort_on_bad_builtin_profile_data, false,
            "flag for mksnapshot, abort if builtins profile can't be applied")
DEFINE_BOOL(
    warn_about_builtin_profile_data, false,
    "flag for mksnapshot, emit warnings when applying builtin profile data")
DEFINE_STRING(
    dump_builtins_hashes_to_file, nullptr,
    "flag for mksnapshot, dump CSA builtins graph hashes to this file")

DEFINE_BOOL(turbo_verify_allocation, DEBUG_BOOL,
            "verify register allocation in TurboFan")
DEFINE_BOOL(turbo_move_optimization, true, "optimize gap moves in TurboFan")
DEFINE_BOOL(turbo_jt, true, "enable jump threading in TurboFan")
DEFINE_BOOL(turbo_loop_peeling, true, "TurboFan loop peeling")
DEFINE_BOOL(turbo_loop_variable, true, "TurboFan loop variable optimization")
DEFINE_BOOL(turbo_loop_rotation, true, "TurboFan loop rotation")
DEFINE_BOOL(turbo_cf_optimization, true, "optimize control flow in TurboFan")
DEFINE_BOOL(turbo_escape, true, "enable escape analysis")
DEFINE_BOOL(turbo_allocation_folding, true, "TurboFan allocation folding")
DEFINE_BOOL(turbo_instruction_scheduling, false,
            "enable instruction scheduling in TurboFan")
DEFINE_BOOL(experimental_turbo_instruction_scheduling, false,
            "enable experimental instruction scheduling in TurboFan")
DEFINE_IMPLICATION(experimental_turbo_instruction_scheduling,
                   turbo_instruction_scheduling)
DEFINE_BOOL(turbo_stress_instruction_scheduling, false,
            "randomly schedule instructions to stress dependency tracking")
DEFINE_BOOL(trace_turbo_instruction_scheduling, false,
            "trace TurboShaft's instruction scheduler")
DEFINE_IMPLICATION(turbo_stress_instruction_scheduling,
                   experimental_turbo_instruction_scheduling)
DEFINE_BOOL(turbo_store_elimination, true,
            "enable store-store elimination in TurboFan")
DEFINE_DEVELOPER_FLAG(trace_store_elimination, "trace store elimination")
DEFINE_BOOL_READONLY(turbo_typer_hardening, true,
                     "extra bounds checks to protect against some known typer "
                     "mismatch exploit techniques (best effort)")

#if defined(V8_TARGET_ARCH_X64) || defined(V8_TARGET_ARCH_IA32)
DEFINE_BOOL(turbo_rewrite_far_jumps, true,
            "rewrite far to near jumps (ia32,x64)")
#else
DEFINE_BOOL_READONLY(turbo_rewrite_far_jumps, false,
                     "rewrite far to near jumps (ia32,x64)")
#endif

DEFINE_BOOL(
    stress_gc_during_compilation, false,
    "simulate GC/compiler thread race related to https://crbug.com/v8/8520")
DEFINE_BOOL(turbo_fast_api_calls, V8_ENABLE_TURBOFAN_BOOL,
            "enable fast API calls from TurboFan")

DEFINE_BOOL(fast_api_allow_float_in_sim, false,
            "allow float parameters to be passed in simulator mode")

// Float parameters in fast API calls don't work in the simulator in general,
// only for some specially prepared test functions. With this flag implication
// we want to make sure that the fuzzer does not enable float parameters also
// for other tests, which would just lead to errors or crashes.
DEFINE_NEG_IMPLICATION(fuzzing, fast_api_allow_float_in_sim)

DEFINE_BOOL(
    turbo_inline_js_wasm_calls, true,
    "inline JS->Wasm calls (specifically: inline JS-to-Wasm wrappers and then "
    "the body of the Wasm function, if applicable)")

DEFINE_BOOL(turbo_optimize_inlined_js_wasm_wrappers, false,
            "Run additional optimizations (especially load-elimination) on "
            "inlined JS-to-Wasm wrappers")
DEFINE_NEG_NEG_IMPLICATION(turbo_inline_js_wasm_calls,
                           turbo_optimize_inlined_js_wasm_wrappers)
DEFINE_WEAK_IMPLICATION(future, turbo_optimize_inlined_js_wasm_wrappers)

DEFINE_BOOL(turbo_optimize_apply, true, "optimize Function.prototype.apply")
DEFINE_BOOL(turbo_optimize_math_minmax, true,
            "optimize call math.min/max with double array")

DEFINE_BOOL(turboshaft, true, "enable TurboFan's Turboshaft phases for JS")

// Can't use Turbofan without Turboshaft.
DEFINE_NEG_NEG_IMPLICATION(turboshaft, turbofan)

#ifdef V8_ENABLE_EXPERIMENTAL_TSA_BUILTINS
DEFINE_BOOL(turboshaft_enable_debug_features, DEBUG_BOOL,
            "enables Turboshaft's DebugPrint, StaticAssert and "
            "CheckTurboshaftTypeOf operations")
#else
DEFINE_BOOL(turboshaft_enable_debug_features, false,
            "enables Turboshaft's DebugPrint, StaticAssert and "
            "CheckTurboshaftTypeOf operations")
#endif

DEFINE_BOOL(turboshaft_wasm_load_elimination, true,
            "enable Turboshaft's WasmLoadElimination")

DEFINE_BOOL(
    wasm_in_js_inlining_body, true,
    "inline Wasm code into JS functions via Turboshaft. This requires "
    "inlining the wrapper, see --wasm-in-js-inlining-wrapper. For controlling "
    "the inlining in the old Turbofan pipeline, see "
    "--turbo-inline-js-wasm-calls.")
// The Wasm-in-JS body inlining depends on the Turbolev-based JS-to-Wasm wrapper
// inlining. Thus both require Turbolev and don't do anything without that.
DEFINE_IMPLICATION(wasm_in_js_inlining_body, wasm_in_js_inlining_wrapper)
DEFINE_BOOL(wasm_in_js_inlining_wrapper, true,
            "inline JS-to-Wasm wrappers via Turboshaft/Turbolev.")

DEFINE_EXPERIMENTAL_FEATURE(
    wasm_in_js_inlining_opt,
    "enable optimizations for Wasm-in-JS inlining in Turboshaft")
DEFINE_IMPLICATION(turbolev_future, wasm_in_js_inlining_opt)

DEFINE_BOOL(turboshaft_load_elimination, true,
            "enable Turboshaft's low-level load elimination for JS")
DEFINE_BOOL(turboshaft_loop_unrolling, true,
            "enable Turboshaft's loop unrolling")
DEFINE_EXPERIMENTAL_FEATURE(turboshaft_loop_optimization,
                            "enable Turboshaft's loop optimization phase")
DEFINE_EXPERIMENTAL_FEATURE(turboshaft_random_rescheduling,
                            "enable Turboshaft's random rescheduling phase")
DEFINE_BOOL(turboshaft_string_concat_escape_analysis, true,
            "enable Turboshaft's escape analysis for string concatenation")

DEFINE_BOOL(turboshaft_trusted_load_elimination, true,
            "enable Turboshaft's low level load elimination for trusted loads "
            "(JS and Wasm)")
DEFINE_WEAK_IMPLICATION(turboshaft_trusted_load_elimination,
                        turboshaft_load_elimination)

DEFINE_EXPERIMENTAL_FEATURE(turboshaft_typed_optimizations,
                            "enable an additional Turboshaft phase that "
                            "performs optimizations based on type information")
#if V8_TARGET_ARCH_ARM64
DEFINE_BOOL(wasm_simd_opt, true, "enable optimizations for Webassembly SIMD")
DEFINE_EXPERIMENTAL_FEATURE(future_wasm_simd_opt,
                            "enable extra optimizations for Webassembly SIMD")
DEFINE_ALIAS_BOOL_WITH_COMMENT(experimental_wasm_simd_opt, future_wasm_simd_opt,
                               TEMPORARY_WASM_ALIAS_COMMENT)
DEFINE_EXPERIMENTAL_FEATURE(wasm_deinterleave_loads,
                            "enable deinterleaving loads for Webassembly SIMD")
DEFINE_ALIAS_BOOL_WITH_COMMENT(experimental_wasm_deinterleave_loads,
                               wasm_deinterleave_loads,
                               TEMPORARY_WASM_ALIAS_COMMENT)
DEFINE_IMPLICATION(future_wasm_simd_opt, wasm_simd_opt)
DEFINE_IMPLICATION(wasm_deinterleave_loads, wasm_simd_opt)
#endif  // V8_TARGET_ARCH_ARM64

DEFINE_BOOL(turbolev, false,
            "use Turbolev (≈ Maglev + Turboshaft combined) as the 4th tier "
            "compiler instead of Turbofan")

DEFINE_DEVELOPER_FLAG(print_turbolev_frontend,
                      "print Turbolev frontend (Maglev graphs)")
DEFINE_STRING(turbolev_phase_filter, "*",
              "filter for turbolev phases (comma-separated list of phase names)")

DEFINE_DEVELOPER_FLAG(print_turbolev_inline_functions,
                      "print Turbolev inline functions")

DEFINE_EXPERIMENTAL_FEATURE(
    turbolev_future,
    "enable Turbolev features that we want to ship in the not-too-far future")
DEFINE_IMPLICATION(turbolev_future, turbolev)

#if TAGGED_SIZE_8_BYTES
// The FixedArray length padding is not aligned with the other fields, which is
// a bit awkward to escape analysis to handle, so we just disable it for now.
// TODO(dmercadier): support this.
DEFINE_BOOL_READONLY(turbolev_escape_analysis, false,
                     "enable escape analysis for Turbolev")
#else
DEFINE_EXPERIMENTAL_FEATURE(turbolev_escape_analysis,
                            "enable escape analysis for Turbolev")
DEFINE_WEAK_IMPLICATION(turbolev_future, turbolev_escape_analysis)
#endif
DEFINE_DEVELOPER_FLAG(trace_turbolev_escape_analysis,
                      "enable tracing for Turbolev's escape analysis phase")

DEFINE_BOOL(
    typed_array_length_loading, true,
    "Enable specializing loading the TypedArray length in Maglev / Turbofan")
DEFINE_WEAK_IMPLICATION(future, typed_array_length_loading)

#if V8_ENABLE_WEBASSEMBLY
DEFINE_IMPLICATION(wasm_shared, shared_heap)
DEFINE_IMPLICATION(wasm_shared, shared_strings)
#endif

DEFINE_BOOL(
    deduplicate_heap_number_requests, false,
    "avoid duplicated HeapNumber materializations in HeapNumberRequests")

#ifdef DEBUG
DEFINE_BOOL(turboshaft_verify_load_elimination, false,
            "insert runtime checks to verify Late Load Elimination")
DEFINE_BOOL(turboshaft_verify_load_store_taggedness, false,
            "insert runtime checks to verify the representation of "
            "loaded/stored values")
DEFINE_IMPLICATION(turboshaft_verify_load_elimination,
                   deduplicate_heap_number_requests)
DEFINE_UINT64(turboshaft_opt_bisect_limit, std::numeric_limits<uint64_t>::max(),
              "stop applying optional optimizations after a specified number "
              "of steps, useful for bisecting optimization bugs")
DEFINE_UINT64(turboshaft_opt_bisect_break, std::numeric_limits<uint64_t>::max(),
              "abort after a specified number of steps, useful for bisecting "
              "optimization bugs")
DEFINE_BOOL(turboshaft_verify_reductions, false,
            "check that turboshaft reductions are correct with respect to "
            "inferred types")
DEFINE_DEVELOPER_FLAG(turboshaft_trace_typing,
                      "print typing steps of turboshaft type inference")
DEFINE_DEVELOPER_FLAG(turboshaft_trace_reduction,
                      "trace individual Turboshaft reduction steps")
DEFINE_DEVELOPER_FLAG(turboshaft_trace_intermediate_reductions,
                      "trace intermediate Turboshaft reduction steps")
DEFINE_DEVELOPER_FLAG(turboshaft_trace_emitted,
                      "trace emitted Turboshaft instructions")
DEFINE_WEAK_IMPLICATION(turboshaft_trace_intermediate_reductions,
                        turboshaft_trace_reduction)
DEFINE_DEVELOPER_FLAG(turboshaft_trace_unrolling,
                      "trace Turboshaft's loop unrolling reducer")
DEFINE_DEVELOPER_FLAG(turboshaft_trace_peeling,
                      "trace Turboshaft's loop peeling reducer")
DEFINE_DEVELOPER_FLAG(turboshaft_trace_load_elimination,
                      "trace Turboshaft's late load elimination")
DEFINE_DEVELOPER_FLAG(turboshaft_trace_store_store_elimination,
                      "trace Turboshaft's store store elimination")
DEFINE_DEVELOPER_FLAG(turboshaft_trace_if_else_to_switch,
                      "trace Turboshaft's if-else to switch reducer")
DEFINE_DEVELOPER_FLAG(turboshaft_trace_gvn, "trace Turboshaft's GVN reducer")

DEFINE_DEVELOPER_FLAG(
    trace_turbolev_graph_building,
    "trace the translation from Maglev to Turboshaft in Turbolev")
DEFINE_IMPLICATION(trace_turbolev_graph_building, turboshaft_trace_emitted)

DEFINE_BOOL(verify_turboshaft, false,
            "enable various verifications on Turboshaft")
DEFINE_IMPLICATION(verify_turboshaft, turboshaft_verify_load_elimination)
DEFINE_IMPLICATION(verify_turboshaft, turboshaft_verify_load_store_taggedness)
DEFINE_IMPLICATION(verify_turboshaft, turboshaft)
#else
DEFINE_BOOL_READONLY(turboshaft_trace_reduction, false,
                     "trace individual Turboshaft reduction steps")
DEFINE_BOOL_READONLY(turboshaft_trace_emitted, false,
                     "trace emitted Turboshaft instructions")
DEFINE_BOOL_READONLY(turboshaft_trace_intermediate_reductions, false,
                     "trace intermediate Turboshaft reduction steps")
DEFINE_BOOL_READONLY(turboshaft_trace_load_elimination, false,
                     "trace Turboshaft's late load elimination")
DEFINE_BOOL_READONLY(turboshaft_trace_store_store_elimination, false,
                     "trace Turboshaft's store store elimination")
DEFINE_BOOL_READONLY(turboshaft_trace_if_else_to_switch, false,
                     "trace Turboshaft's if-else to switch reducer")
DEFINE_BOOL_READONLY(verify_turboshaft, false,
                     "enable various verifications on Turboshaft")
#endif  // DEBUG

DEFINE_BOOL(profile_guided_optimization, true, "profile guided optimization")
DEFINE_BOOL(profile_guided_optimization_for_empty_feedback_vector, true,
            "profile guided optimization for empty feedback vector")
DEFINE_INT(invocation_count_for_early_optimization, 30,
           "invocation count threshold for early optimization")
DEFINE_MAX_VALUE_IMPLICATION(invocation_count_for_early_optimization, 254)
DEFINE_INT(invocation_count_for_maglev_with_delay, 600,
           "invocation count for maglev for functions which according to "
           "profile_guided_optimization are likely to deoptimize before "
           "reaching this invocation count")

// Favor memory over execution speed.
DEFINE_BOOL(optimize_for_size, false,
            "Enables optimizations which favor memory size over execution "
            "speed")
DEFINE_VALUE_IMPLICATION(optimize_for_size, max_semi_space_size, size_t{1})

DEFINE_BOOL(reopt_after_lazy_deopts, true,
            "Immediately re-optimize code after some lazy deopts")

// This verification doesn't work for debugger tests which set breakpoints
// into builtin functions and thus make certain core JS builtins look like
// they are not used.
DEFINE_BOOL(verify_get_js_builtin_state, false,
            "Enable verification of Builtins::GetJSBuiltinState().")
DEFINE_IMPLICATION(enable_slow_asserts, verify_get_js_builtin_state)

// Declare command-line flags for V8 features.
#include "src/flags/feature-flags.h"

// This flag implies experimental features for our fuzzers without needing to
// stage them yet. Once sufficiently stable, they should be moved to
// --future, --wasm-staging or a similar flag that indicates its readiness
// for staging.
DEFINE_EXPERIMENTAL_FEATURE(
    experimental_fuzzing,
    "Implies all experimental pre-staged features that can already be "
    "fuzzed but are not ready for staging yet.")

#ifdef V8_ENABLE_FUTURE
#define FUTURE_BOOL true
#else
#define FUTURE_BOOL false
#endif
DEFINE_BOOL(future, FUTURE_BOOL,
            "Implies all staged features that we want to ship in the "
            "not-too-far future")

DEFINE_BOOL(harmony, false, "enable all completed harmony features")
DEFINE_BOOL(js_staging, false, "enable all completed JavaScript features")
DEFINE_BOOL(wasm_staging, false, "enable staged wasm features")

DEFINE_BOOL(js_shipping, true, "enable all shipped JavaScript features")
DEFINE_BOOL(harmony_shipping, true, "enable all shipped harmony features")

#define DECL_EXPERIMENTAL_JS_FLAG(feature_name, description) \
  DEFINE_EXPERIMENTAL_FEATURE(feature_name, "enable " description " for JS")
#ifdef V8_ENABLE_WEBASSEMBLY
#define DECL_EXPERIMENTAL_WASM_FLAG(feature_name, description)     \
  DEFINE_EXPERIMENTAL_FEATURE(wasm_##feature_name,                 \
                              "enable " description " for Wasm")   \
  DEFINE_ALIAS_BOOL_WITH_COMMENT(experimental_wasm_##feature_name, \
                                 wasm_##feature_name,              \
                                 TEMPORARY_WASM_ALIAS_COMMENT)
#else
#define DECL_EXPERIMENTAL_WASM_FLAG(feature_name, description)
#endif  // V8_ENABLE_WEBASSEMBLY
#define DECL_EXPERIMENTAL_INTERNAL_FLAG(feature_name, description) \
  DEFINE_EXPERIMENTAL_FEATURE(feature_name, "enable " description)
FOREACH_EXPERIMENTAL_FEATURE_FLAG(DECL_EXPERIMENTAL_JS_FLAG,
                                  DECL_EXPERIMENTAL_WASM_FLAG,
                                  DECL_EXPERIMENTAL_INTERNAL_FLAG)
#undef DECL_EXPERIMENTAL_JS_FLAG
#undef DECL_EXPERIMENTAL_WASM_FLAG
#undef DECL_EXPERIMENTAL_INTERNAL_FLAG

#define DECL_PRE_STAGED_JS_FLAG(feature_name, description)                   \
  DEFINE_EXPERIMENTAL_FEATURE(feature_name, "enable " description " for JS") \
  DEFINE_IMPLICATION(experimental_fuzzing, feature_name)
#ifdef V8_ENABLE_WEBASSEMBLY
#define DECL_PRE_STAGED_WASM_FLAG(feature_name, description)       \
  DEFINE_EXPERIMENTAL_FEATURE(wasm_##feature_name,                 \
                              "enable " description " for Wasm")   \
  DEFINE_ALIAS_BOOL_WITH_COMMENT(experimental_wasm_##feature_name, \
                                 wasm_##feature_name,              \
                                 TEMPORARY_WASM_ALIAS_COMMENT)     \
  DEFINE_IMPLICATION(experimental_fuzzing, wasm_##feature_name)
#else
#define DECL_PRE_STAGED_WASM_FLAG(feature_name, description)
#endif  // V8_ENABLE_WEBASSEMBLY
#define DECL_PRE_STAGED_INTERNAL_FLAG(feature_name, description)   \
  DEFINE_EXPERIMENTAL_FEATURE(feature_name, "enable " description) \
  DEFINE_WEAK_IMPLICATION(experimental_fuzzing, feature_name)
FOREACH_PRE_STAGED_FEATURE_FLAG(DECL_PRE_STAGED_JS_FLAG,
                                DECL_PRE_STAGED_WASM_FLAG,
                                DECL_PRE_STAGED_INTERNAL_FLAG)
#undef DECL_PRE_STAGED_JS_FLAG
#undef DECL_PRE_STAGED_WASM_FLAG
#undef DECL_PRE_STAGED_INTERNAL_FLAG

#define DECL_STAGED_JS_FLAG(feature_name, description)              \
  DEFINE_BOOL(feature_name, false, "enable " description " for JS") \
  DEFINE_WEAK_IMPLICATION(js_staging, feature_name)                 \
  DEFINE_WEAK_IMPLICATION(harmony, feature_name)
#ifdef V8_ENABLE_WEBASSEMBLY
#define DECL_STAGED_WASM_FLAG(feature_name, description)                     \
  DEFINE_BOOL(wasm_##feature_name, false, "enable " description " for Wasm") \
  DEFINE_ALIAS_BOOL_WITH_COMMENT(experimental_wasm_##feature_name,           \
                                 wasm_##feature_name,                        \
                                 TEMPORARY_WASM_ALIAS_COMMENT)               \
  DEFINE_WEAK_IMPLICATION(wasm_staging, wasm_##feature_name)
#else
#define DECL_STAGED_WASM_FLAG(feature_name, description)
#endif  // V8_ENABLE_WEBASSEMBLY
#define DECL_STAGED_INTERNAL_FLAG(feature_name, description) \
  DEFINE_BOOL(feature_name, false, "enable " description)    \
  DEFINE_WEAK_IMPLICATION(future, feature_name)
FOREACH_STAGED_FEATURE_FLAG(DECL_STAGED_JS_FLAG, DECL_STAGED_WASM_FLAG,
                            DECL_STAGED_INTERNAL_FLAG)
DEFINE_IMPLICATION(harmony, js_staging)
#undef DECL_STAGED_JS_FLAG
#undef DECL_STAGED_WASM_FLAG
#undef DECL_STAGED_INTERNAL_FLAG

#define DECL_SHIPPED_JS_FLAG(feature_name, description)            \
  DEFINE_BOOL(feature_name, true, "enable " description " for JS") \
  DEFINE_NEG_NEG_IMPLICATION(js_shipping, feature_name)            \
  DEFINE_NEG_NEG_IMPLICATION(harmony_shipping, feature_name)
#ifdef V8_ENABLE_WEBASSEMBLY
#define DECL_SHIPPED_WASM_FLAG(feature_name, description)                   \
  DEFINE_BOOL(wasm_##feature_name, true, "enable " description " for Wasm") \
  DEFINE_ALIAS_BOOL_WITH_COMMENT(experimental_wasm_##feature_name,          \
                                 wasm_##feature_name,                       \
                                 TEMPORARY_WASM_ALIAS_COMMENT)
#else
#define DECL_SHIPPED_WASM_FLAG(feature_name, description)
#endif  // V8_ENABLE_WEBASSEMBLY
#define DECL_SHIPPED_INTERNAL_FLAG(feature_name, description) \
  DEFINE_BOOL(feature_name, true, "enable " description)
FOREACH_SHIPPED_FEATURE_FLAG(DECL_SHIPPED_JS_FLAG, DECL_SHIPPED_WASM_FLAG,
                             DECL_SHIPPED_INTERNAL_FLAG)
DEFINE_NEG_NEG_IMPLICATION(harmony_shipping, js_shipping)
#undef DECL_SHIPPED_JS_FLAG
#undef DECL_SHIPPED_WASM_FLAG
#undef DECL_SHIPPED_INTERNAL_FLAG

// Non-feature flags for WebAssembly.
#if V8_ENABLE_WEBASSEMBLY

DEFINE_BOOL(wasm_generic_wrapper, true,
            "allow use of the generic js-to-wasm wrapper instead of "
            "per-signature wrappers")
DEFINE_BOOL(wasm_unsafe_fast_api_wrapper, false, "allow use of the unsafe fast "
            "API wrapper")
DEFINE_INT(wasm_num_compilation_tasks, 128,
           "maximum number of parallel compilation tasks for wasm")
DEFINE_VALUE_IMPLICATION(single_threaded, wasm_num_compilation_tasks, 0)
DEFINE_DEBUG_BOOL(trace_wasm_native_heap, false,
                  "trace wasm native heap events")
DEFINE_DEVELOPER_FLAG(
    trace_wasm_offheap_memory,
    "print details of wasm off-heap memory when the memory measurement "
    "API is used")
DEFINE_BOOL(
    print_wasm_offheap_memory_size, false,
    "print off-heap memory consumption per module and engine when they die")
DEFINE_DEBUG_BOOL(trace_wasm_serialization, false,
                  "trace serialization/deserialization")
DEFINE_BOOL(wasm_test_streaming, false,
            "use streaming compilation instead of async compilation for tests")
DEFINE_BOOL(wasm_native_module_cache, true, "enable the native module cache")
// The actual value used at runtime is clamped to kV8MaxWasmMemory{32,64}Pages.
DEFINE_UINT(wasm_max_mem_pages, kMaxUInt32,
            "maximum number of 64KiB memory pages per wasm memory")
DEFINE_UINT(wasm_max_table_size, wasm::kV8MaxWasmTableSize,
            "maximum table size of a wasm instance")
DEFINE_UINT(wasm_max_committed_code_mb, kMaxCommittedWasmCodeMB,
            "maximum committed code space for wasm (in MB)")
DEFINE_UINT(wasm_max_code_space_size_mb, kDefaultMaxWasmCodeSpaceSizeMb,
            "maximum size of a single wasm code space")
DEFINE_BOOL(wasm_tier_up, V8_ENABLE_TURBOFAN_BOOL,
            "enable tier up to the optimizing compiler (requires --liftoff to "
            "have an effect)")
DEFINE_BOOL(wasm_dynamic_tiering, V8_ENABLE_TURBOFAN_BOOL,
            "enable dynamic tier up to the optimizing compiler")
DEFINE_NEG_NEG_IMPLICATION(liftoff, wasm_dynamic_tiering)
DEFINE_BOOL(wasm_sync_tier_up, false, "run Wasm tier up jobs synchronously")
DEFINE_INT(wasm_tiering_budget, 13'000'000,
           "budget for dynamic tiering (rough approximation of bytes executed")
DEFINE_SMI(wasm_wrapper_tiering_budget, wasm::kGenericWrapperBudget,
           "budget for wrapper tierup (number of calls until tier-up)")
DEFINE_INT(max_wasm_functions, wasm::kV8MaxWasmDefinedFunctions,
           "maximum number of wasm functions defined in a module")
DEFINE_INT(
    wasm_caching_threshold, 1'000,
    "the amount of wasm top tier code that triggers the next caching event")
// Note: wasm_caching_hard_threshold should always be larger than
// wasm_caching_threshold. If wasm_caching_timeout_ms is 0, the hard threshold
// will be ignored.
DEFINE_INT(wasm_caching_hard_threshold, 1'000'000,
           "the amount of wasm top tier code that triggers caching "
           "immediately, ignoring the --wasm-caching-timeout-ms")
DEFINE_INT(
    wasm_caching_timeout_ms, 2000,
    "only trigger caching if no new code was compiled within this timeout (0 "
    "to disable this logic and only use --wasm-caching-threshold)")
DEFINE_DEVELOPER_FLAG(trace_wasm_compilation_times,
                      "print how long it took to compile each wasm function")
DEFINE_INT(wasm_tier_up_filter, -1, "only tier-up function with this index")
DEFINE_INT(wasm_eager_tier_up_function, -1,
           "eagerly tier-up function with this index")
DEFINE_DEBUG_BOOL(trace_wasm_decoder, false, "trace decoding of wasm code")
DEFINE_DEBUG_BOOL(trace_wasm_compiler, false, "trace compiling of wasm code")
DEFINE_DEBUG_BOOL(trace_wasm_streaming, false,
                  "trace streaming compilation of wasm code")
DEFINE_DEBUG_BOOL(trace_wasm_stack_switching, false,
                  "trace wasm stack switching")
DEFINE_BOOL(stress_wasm_stack_switching, false,
            "Always run wasm on a secondary stack, even when it is called "
            "with a regular (non-JSPI) export")
DEFINE_INT(wasm_stack_switching_stack_size, V8_DEFAULT_STACK_SIZE_KB,
           "default size of stacks for wasm stack-switching (in kB)")
DEFINE_INT(wasm_stack_pool_capacity_mb, 500,
           "default capacity for the wasm stack pool in MB, -1 for unlimited")
// 1 will be rounded up to the smallest possible initial stack size, which
// depends on the stack limit margin and the platform's page size.
DEFINE_VALUE_IMPLICATION(wasm_growable_stacks,
  wasm_stack_switching_stack_size, 1)
DEFINE_BOOL(liftoff, true,
            "enable Liftoff, the baseline compiler for WebAssembly")
DEFINE_BOOL(liftoff_only, false,
            "disallow TurboFan compilation for WebAssembly (for testing)")
DEFINE_IMPLICATION(liftoff_only, liftoff)
DEFINE_NEG_IMPLICATION(liftoff_only, wasm_tier_up)
DEFINE_NEG_IMPLICATION(liftoff_only, wasm_dynamic_tiering)
DEFINE_DEBUG_BOOL(
    enable_testing_opcode_in_wasm, false,
    "enables a testing opcode in wasm that is only implemented in TurboFan")
DEFINE_NEG_IMPLICATION(liftoff_only, enable_testing_opcode_in_wasm)
// Do synchronous tier up (instead of in-background tierup) in single threaded
// and predictable mode.
DEFINE_IMPLICATION(single_threaded, wasm_sync_tier_up)
DEFINE_IMPLICATION(predictable, wasm_sync_tier_up)
DEFINE_DEBUG_BOOL(trace_liftoff, false,
                  "trace Liftoff, the baseline compiler for WebAssembly")
DEFINE_DEVELOPER_FLAG(trace_wasm_memory,
                      "print all memory updates performed in wasm code")
DEFINE_DEVELOPER_FLAG(
    trace_wasm_globals,
    "print all global variable updates performed in wasm code")
// Fuzzers use {wasm_tier_mask_for_testing} and {wasm_debug_mask_for_testing}
// together with {liftoff} and {no_wasm_tier_up} to force some functions to be
// compiled with TurboFan or for debug.
DEFINE_INT(wasm_tier_mask_for_testing, 0,
           "bitmask of declared(!) function indices to compile with TurboFan "
           "instead of Liftoff")
DEFINE_INT(wasm_debug_mask_for_testing, 0,
           "bitmask of declared(!) function indices to compile for debugging, "
           "only applies if the tier is Liftoff")
DEFINE_DEVELOPER_FLAG(
    wasm_pgo_to_file,
    "experimental: dump Wasm PGO information to a local file (for testing)")
DEFINE_ALIAS_BOOL_WITH_COMMENT(experimental_wasm_pgo_to_file, wasm_pgo_to_file,
                               TEMPORARY_WASM_ALIAS_COMMENT)
DEFINE_NEG_IMPLICATION(wasm_pgo_to_file, single_threaded)
DEFINE_DEVELOPER_FLAG(
    wasm_pgo_from_file,
    "experimental: read and use Wasm PGO data from a local file (for testing)")
DEFINE_ALIAS_BOOL_WITH_COMMENT(experimental_wasm_pgo_from_file,
                               wasm_pgo_from_file, TEMPORARY_WASM_ALIAS_COMMENT)

#if V8_ENABLE_DRUMBRAKE
// Wasm is put into interpreter-only mode. We repeat flag implications down
// here to ensure they're applied correctly by setting the --jitless flag.
DEFINE_NEG_IMPLICATION(jitless, wasm_lazy_compilation)
#endif  // V8_ENABLE_DRUMBRAKE

DEFINE_DEBUG_BOOL(dump_wasm_module, false, "dump wasm module bytes")
DEFINE_STRING(dump_wasm_module_path, nullptr,
              "directory to dump wasm modules to")
DEFINE_EXPERIMENTAL_FEATURE(
    wasm_fast_api,
    "Enable direct calls from wasm to fast API functions with bound "
    "call function to pass the receiver as first parameter")

DEFINE_EXPERIMENTAL_FEATURE(
    wasm_assert_types,
    "Enable additional type assertions in generated code (e.g. turbofan)")

#if V8_TARGET_ARCH_PPC64 || V8_TARGET_ARCH_S390X || \
    (V8_TARGET_ARCH_MIPS64 && V8_TARGET_BIG_ENDIAN)
DEFINE_EXPERIMENTAL_FEATURE(wasm_deopt,
                            "enable deopts in optimized wasm functions")
#else
DEFINE_BOOL(wasm_deopt, true, "enable deopts in optimized wasm functions")
#endif

// Deopt only works in combination with feedback.
DEFINE_NEG_NEG_IMPLICATION(liftoff, wasm_deopt)

// Note that this limit doesn't guarantee an upper bound, as e.g. with multiple
// frames of the same function on the stack, many more deopts can happen.
DEFINE_SIZE_T(wasm_deopts_per_function_limit, 10,
              "limit of wasm deopts for a single function after which no "
              "further deopt points are emitted in Turbofan")

// Unsafe additions to the GC proposal for performance experiments.
DEFINE_TEST_ONLY_FLAG(
    wasm_assume_ref_cast_succeeds,
    "assume ref.cast always succeeds and skip the related type check")
DEFINE_ALIAS_BOOL_WITH_COMMENT(experimental_wasm_assume_ref_cast_succeeds,
                               wasm_assume_ref_cast_succeeds,
                               TEMPORARY_WASM_ALIAS_COMMENT)
DEFINE_TEST_ONLY_FLAG(wasm_ref_cast_nop,
                      "enable unsafe ref.cast_nop instruction")
DEFINE_ALIAS_BOOL_WITH_COMMENT(experimental_wasm_ref_cast_nop,
                               wasm_ref_cast_nop, TEMPORARY_WASM_ALIAS_COMMENT)
DEFINE_TEST_ONLY_FLAG(
    wasm_skip_null_checks,
    "skip null checks for call.ref and array and struct operations")
DEFINE_ALIAS_BOOL_WITH_COMMENT(experimental_wasm_skip_null_checks,
                               wasm_skip_null_checks,
                               TEMPORARY_WASM_ALIAS_COMMENT)
DEFINE_TEST_ONLY_FLAG(wasm_skip_bounds_checks, "skip array bounds checks")
DEFINE_ALIAS_BOOL_WITH_COMMENT(experimental_wasm_skip_bounds_checks,
                               wasm_skip_bounds_checks,
                               TEMPORARY_WASM_ALIAS_COMMENT)

// Experimental variants of the Custom Descriptors prototype implementation.
DEFINE_EXPERIMENTAL_FEATURE(
    wasm_js_interop, "enable JS Interop part of Custom Descriptors proposal")
DEFINE_ALIAS_BOOL_WITH_COMMENT(experimental_wasm_js_interop, wasm_js_interop,
                               TEMPORARY_WASM_ALIAS_COMMENT)
DEFINE_IMPLICATION(wasm_js_interop, wasm_custom_descriptors)
DEFINE_BOOL(wasm_custom_descriptors_permitted, true,
            "Emergency off-switch for Custom Descriptors Origin Trial")
DEFINE_EXPERIMENTAL_FEATURE(wasm_merged_descriptors,
                            "merge Custom Descriptor into v8::internal::Map")
DEFINE_IMPLICATION(wasm_merged_descriptors, wasm_custom_descriptors)

DEFINE_DEBUG_BOOL(
    wasm_opt, true,
    "enable optimization when compiling Wasm functions with Turbofan")
DEFINE_BOOL(wasm_bounds_checks, true,
            "enable bounds checks (disable for performance testing only)")
DEFINE_NEG_VALUE_IMPLICATION(wasm_bounds_checks, test_only_unsafe, true)
DEFINE_BOOL(wasm_stack_checks, true,
            "enable stack checks (disable for performance testing only)")
DEFINE_NEG_VALUE_IMPLICATION(wasm_stack_checks, test_only_unsafe, true)
DEFINE_BOOL(
    wasm_enforce_bounds_checks, false,
    "enforce explicit bounds check even if the trap handler is available")
// "no bounds checks" implies "no enforced bounds checks".
DEFINE_NEG_NEG_IMPLICATION(wasm_bounds_checks, wasm_enforce_bounds_checks)

// The Arm architecture does not specify the results in memory of
// partially-in-bound writes, which does not align with the wasm spec. This
// affects when trap handlers can be used for OOB detection; however, Mac
// systems with Apple silicon currently do provide trapping behaviour for
// partially-out-of-bound writes, so we assume we can rely on that on MacOS,
// since doing so provides better performance for writes.
DEFINE_BOOL(
#if V8_TARGET_ARCH_RISCV64 || (V8_TARGET_ARCH_ARM64 && !V8_OS_MACOS)
    wasm_partial_oob_writes_are_noops, false,
#else
    wasm_partial_oob_writes_are_noops, true,
#endif
    "assume partially out-of-bounds writes are no-ops and can use the trap "
    "handler. Note that explicitly enabling this flag (if not enabled by "
    "default) can affect the spec-compliance of V8.")

DEFINE_BOOL(wasm_math_intrinsics, true,
            "intrinsify some Math imports into wasm")

DEFINE_BOOL(wasm_inlining, true,
            "enable inlining of Wasm functions into Wasm functions")
DEFINE_SIZE_T(wasm_inlining_budget, 5000,
              "maximum graph size (in TF nodes) that allows inlining more")
DEFINE_SIZE_T(wasm_inlining_max_size, 500,
              "maximum function size (in wire bytes) that may be inlined")
DEFINE_SIZE_T(
    wasm_inlining_factor, 3,
    "maximum multiple graph size (in TF nodes) in comparison to initial size")
DEFINE_SIZE_T(wasm_inlining_min_budget, 50,
              "minimum graph size budget (in TF nodes) for which the "
              "wasm_inlinining_factor does not apply")
DEFINE_BOOL(wasm_inlining_ignore_call_counts, false,
            "Ignore call counts when considering inlining candidates. The flag "
            "is supposed to be used for fuzzing")
DEFINE_DEVELOPER_FLAG(trace_wasm_inlining, "trace wasm inlining")
DEFINE_DEVELOPER_FLAG(trace_wasm_typer, "trace wasm typer")
DEFINE_DEVELOPER_FLAG(trace_wasm_simd_shuffle, "trace wasm simd shuffle")
DEFINE_BOOL(wasm_inlining_call_indirect, true,
            "enable speculative inlining of Wasm indirect calls")
// call_indirect inlining requires the basic inlining machinery, e.g., for
// allocating feedback vectors, so we should also disable it when inlining is
// disabled altogether.
DEFINE_NEG_NEG_IMPLICATION(wasm_inlining, wasm_inlining_call_indirect)

DEFINE_BOOL(wasm_bulkmem_inlining, true,
            "enable inline code generation for small bulk memory operations")
DEFINE_BOOL(wasm_loop_unrolling, true,
            "enable loop unrolling for wasm functions")
DEFINE_EXPERIMENTAL_FEATURE(
    wasm_random_rescheduling,
    "enable Turbofan's random rescheduling phase for wasm functions")
DEFINE_BOOL(wasm_loop_peeling, true, "enable loop peeling for wasm functions")
DEFINE_SIZE_T(wasm_loop_peeling_max_size, 1000, "maximum size for peeling")
DEFINE_DEVELOPER_FLAG(trace_wasm_loop_peeling, "trace wasm loop peeling")
DEFINE_BOOL(wasm_fuzzer_gen_test, false,
            "generate a test case when running a wasm fuzzer")
DEFINE_IMPLICATION(wasm_fuzzer_gen_test, single_threaded)
DEFINE_DEVELOPER_FLAG(print_wasm_code, "print WebAssembly code")
DEFINE_INT(print_wasm_code_function_index, -1,
           "print WebAssembly code for function at index")
DEFINE_DEVELOPER_FLAG(print_wasm_stub_code, "print WebAssembly stub code")
DEFINE_BOOL(wasm_lazy_compilation, true,
            "enable lazy compilation for all wasm modules")
DEFINE_DEBUG_BOOL(trace_wasm_lazy_compilation, false,
                  "trace lazy compilation of wasm functions")

DEFINE_BOOL(wasm_code_gc, true, "enable garbage collection of wasm code")
DEFINE_DEVELOPER_FLAG(trace_wasm_code_gc,
                      "trace garbage collection of wasm code")
DEFINE_BOOL(stress_wasm_code_gc, false,
            "stress test garbage collection of wasm code")
DEFINE_INT(wasm_max_initial_code_space_reservation, 0,
           "maximum size of the initial wasm code space reservation (in MB)")
DEFINE_BOOL(stress_wasm_memory_moving, false,
            "always move non-shared bounds-checked Wasm memory on grow")
DEFINE_BOOL(flush_liftoff_code, true,
            "enable flushing Liftoff code on memory pressure signal")
DEFINE_BOOL(stress_branch_hinting, false,
            "stress branch hinting by generating a random hint for each branch "
            "instruction")

DEFINE_SIZE_T(wasm_max_module_size, wasm::kV8MaxWasmModuleSize,
              "maximum allowed size of wasm modules")
DEFINE_SIZE_T(wasm_disassembly_max_mb, 1000,
              "maximum size of produced disassembly (in MB, approximate)")

DEFINE_INT(wasm_capi_thread_pool_size, 0,
           "size of the thread pool used by the wasm C API, with 0 meaning the "
           "maximum number of threads")

DEFINE_DEVELOPER_FLAG(trace_wasm, "trace wasm function calls")
// Inlining breaks --trace-wasm, hence disable that if --trace-wasm is enabled.
// TODO(40898108,mliedtke,manoskouk): We should fix this; now that inlining is
// enabled by default, one cannot trace the production configuration anymore.
DEFINE_NEG_IMPLICATION(trace_wasm, wasm_inlining)

// Flags for Wasm GDB remote debugging.
#ifdef V8_ENABLE_WASM_GDB_REMOTE_DEBUGGING
#define DEFAULT_WASM_GDB_REMOTE_PORT 8765
DEFINE_BOOL(wasm_gdb_remote, false,
            "enable GDB-remote for WebAssembly debugging")
DEFINE_NEG_IMPLICATION(wasm_gdb_remote, wasm_tier_up)
DEFINE_INT(wasm_gdb_remote_port, DEFAULT_WASM_GDB_REMOTE_PORT,
           "default port for WebAssembly debugging with LLDB.")
DEFINE_BOOL(wasm_pause_waiting_for_debugger, false,
            "pause at the first Webassembly instruction waiting for a debugger "
            "to attach")
DEFINE_DEVELOPER_FLAG(trace_wasm_gdb_remote,
                      "trace Webassembly GDB-remote server")
#endif  // V8_ENABLE_WASM_GDB_REMOTE_DEBUGGING

// wasm instance management
DEFINE_DEBUG_BOOL(trace_wasm_instances, false,
                  "trace creation and collection of wasm instances")

// Flags for WASM SIMD256 revectorize
#ifdef V8_ENABLE_WASM_SIMD256_REVEC
DEFINE_ALIAS_BOOL_WITH_COMMENT(experimental_wasm_revectorize, wasm_revectorize,
                               TEMPORARY_WASM_ALIAS_COMMENT)
DEFINE_DEVELOPER_FLAG(trace_wasm_revectorize, "trace wasm revectorize")
#endif  // V8_ENABLE_WASM_SIMD256_REVEC

#if V8_TARGET_ARCH_ARM64 || V8_TARGET_ARCH_X64 || V8_TARGET_ARCH_RISCV64 || \
    V8_TARGET_ARCH_LOONG64
DEFINE_BOOL(wasm_memory64_trap_handling, true,
            "Use trap handling for Wasm memory64 bounds checks")
#else
DEFINE_BOOL_READONLY(wasm_memory64_trap_handling, false,
                     "Use trap handling for Wasm memory64 bounds checks (not "
                     "supported for this architecture)")
#endif  // V8_TARGET_ARCH_ARM64 || V8_TARGET_ARCH_X64 || V8_TARGET_ARCH_RISCV64
        // || V8_TARGET_ARCH_LOONG64

#ifdef V8_ENABLE_DRUMBRAKE
// DrumBrake flags.
DEFINE_EXPERIMENTAL_FEATURE(wasm_jitless,
                            "Execute all wasm code in the Wasm interpreter")
#ifdef V8_OS_TVOS
// Enable wasm_jitless on tvOS where jit is not available.
DEFINE_IMPLICATION(jitless, wasm_jitless)
#endif
DEFINE_BOOL(wasm_jitless_if_available_for_testing, false,
            "Enables the Wasm interpreter, for testing, but only if "
            "the 'v8_enable_drumbrake' flag is set.")
DEFINE_IMPLICATION(wasm_jitless_if_available_for_testing, wasm_jitless)

DEFINE_BOOL(drumbrake_compact_bytecode, false,
            "Compress the Wasm interpreter bytecode")
DEFINE_DEVELOPER_FLAG(trace_drumbrake_compact_bytecode,
                      "Traces the Wasm interpreter compact bytecode")
DEFINE_BOOL(drumbrake_fuzzer_timeout, false,
            "enable timeout for wasm fuzzer (for testing)")
DEFINE_SIZE_T(drumbrake_fuzzer_timeout_limit_ms, 250,
              "timeout for wasm fuzzer (in ms)")
#ifdef V8_ENABLE_DRUMBRAKE_TRACING
DEFINE_DEVELOPER_FLAG(trace_drumbrake_bytecode_generator,
                      "trace drumbrake generation of interpreter bytecode")
DEFINE_DEVELOPER_FLAG(trace_drumbrake_execution,
                      "trace drumbrake execution of wasm code")
DEFINE_DEVELOPER_FLAG(
    trace_drumbrake_execution_verbose,
    "print more information for the drumbrake execution of wasm code")
DEFINE_IMPLICATION(trace_drumbrake_execution_verbose, trace_drumbrake_execution)
DEFINE_BOOL(redirect_drumbrake_traces, false,
            "write drumbrake traces into file <pid>-<isolate id>.dbt")
DEFINE_STRING(
    trace_drumbrake_filter, "*",
    "filter for selecting which wasm functions to trace in the interpreter")
#endif  // V8_ENABLE_DRUMBRAKE_TRACING
DEFINE_BOOL(drumbrake_super_instructions, true,
            "enable drumbrake merged wasm instructions optimization")
DEFINE_BOOL(drumbrake_register_optimization, true,
            "enable passing the top stack value in a register in drumbrake")
DEFINE_BOOL(drumbrake_fuzzing_mode, false,
            "enable drumbrake fuzzer mode (for testing)")

// --wasm-jitless resets --wasm-lazy-compilation and --wasm-tier-up.
DEFINE_NEG_IMPLICATION(wasm_jitless, wasm_lazy_compilation)
DEFINE_NEG_IMPLICATION(wasm_jitless, wasm_tier_up)

// --wasm-enable-exec-time-histograms works both in jitted and jitless mode
// and enables histogram V8.Jit[less]WasmExecutionPercentage, which measures
// the percentage of time spent running Wasm code. Note that generating samples
// for this metric causes a small performance degradation, and requires setting
// the additional flag --slow-histograms.
DEFINE_BOOL(wasm_enable_exec_time_histograms, false,
            "enables histograms that track the time spent executing Wasm code")
DEFINE_INT(wasm_exec_time_histogram_sample_duration, 1000,
           "sample duration for V8.Jit[less]WasmExecutionPercentage, in msec")
DEFINE_INT(wasm_exec_time_histogram_sample_period, 4000,
           "sample period for V8.Jit[less]WasmExecutionPercentage, in msec")
DEFINE_INT(wasm_exec_time_histogram_slow_threshold, 10000,
           "V8.Jit[less]WasmExecutionPercentage threshold used to detect "
           "Wasm-intensive workloads (0-100000)")
DEFINE_INT(wasm_exec_time_slow_threshold_samples_count, 1,
           "number of V8.Jit[less]WasmExecutionPercentage samples used to "
           "calculate the threshold for the V8.Jit[less]WasmExecutionTooSlow "
           "histogram")
DEFINE_IMPLICATION(wasm_enable_exec_time_histograms, slow_histograms)
DEFINE_NEG_IMPLICATION(wasm_enable_exec_time_histograms,
                       turbo_inline_js_wasm_calls)
DEFINE_NEG_IMPLICATION(wasm_enable_exec_time_histograms, wasm_generic_wrapper)
#else   // V8_ENABLE_DRUMBRAKE
DEFINE_BOOL_READONLY(wasm_jitless, false,
                     "execute all Wasm code in the Wasm interpreter")
DEFINE_BOOL(wasm_jitless_if_available_for_testing, false, "")
DEFINE_NEG_IMPLICATION(wasm_jitless_if_available_for_testing, turbolev)
#endif  // V8_ENABLE_DRUMBRAKE

DEFINE_BOOL(wasm_allow_mixed_eh_for_testing, false,
            "Allow mixed legacy and new exception handling instructions in the "
            "same wasm module")
// %WasmGenerateRandomModule() can generate modules with a mix of old and new EH
// instructions, and crashes if the module does not compile.
// So always allow mixing old and new EH for fuzzing.
DEFINE_IMPLICATION(fuzzing, wasm_allow_mixed_eh_for_testing)

#if V8_TARGET_ARCH_ARM || V8_TARGET_ARCH_ARM64 || V8_TARGET_ARCH_X64 ||   \
    defined(V8_TARGET_ARCH_IA32) || defined(V8_TARGET_ARCH_RISCV64) ||    \
    defined(V8_TARGET_ARCH_RISCV32) || defined(V8_TARGET_ARCH_LOONG64) || \
    defined(V8_TARGET_ARCH_MIPS64)
DEFINE_BOOL(wasm_code_coverage, false, "enable Wasm code coverage")
#else
DEFINE_BOOL_READONLY(wasm_code_coverage, false, "enable Wasm code coverage")
#endif  // V8_TARGET_ARCH_ARM || V8_TARGET_ARCH_ARM64 || V8_TARGET_ARCH_X64 ||
        // V8_TARGET_ARCH_IA32
DEFINE_NEG_IMPLICATION(wasm_code_coverage, wasm_loop_unrolling)
DEFINE_NEG_IMPLICATION(wasm_code_coverage, wasm_inlining)
// Wasm code coverage is not supported by the Wasm interpreter.
DEFINE_NEG_IMPLICATION(wasm_code_coverage, wasm_jitless)
// --wasm-code-coverage relies on the WasmOptimizePhase phase (which only runs
// when --wasm-opt is true) to lower the WasmIncCoverageCounter operations that
// it introduces.
DEFINE_IMPLICATION(wasm_code_coverage, wasm_opt)

DEFINE_DEVELOPER_FLAG(trace_wasm_compilation_hints,
                      "trace compilation hints parsing and usage")
DEFINE_TEST_ONLY_FLAG(
    wasm_generate_compilation_hints,
    "enable emitting compilation-hints sections for Wasm to a file")
DEFINE_TEST_ONLY_FLAG(trace_wasm_generate_compilation_hints,
                      "enable tracing wasm compilation hints generation")
// Feedback collection is guarded by the --wasm-inlining flag.
DEFINE_IMPLICATION(wasm_generate_compilation_hints, wasm_inlining)
DEFINE_IMPLICATION(trace_wasm_generate_compilation_hints, wasm_inlining)
// --wasm-code-coverage implies --no-wasm-inlining.
DEFINE_NEG_IMPLICATION(wasm_generate_compilation_hints, wasm_code_coverage)
DEFINE_NEG_IMPLICATION(trace_wasm_generate_compilation_hints,
                       wasm_code_coverage)
// We need liftoff to generate feedback when generating compilation hints.
DEFINE_IMPLICATION(wasm_generate_compilation_hints, liftoff)
DEFINE_IMPLICATION(trace_wasm_generate_compilation_hints, liftoff)
// Despite functions not being tiered up in this mode, we need this to track
// which functions were marked for tierup to generate the compilation-priority
// section.
DEFINE_IMPLICATION(wasm_generate_compilation_hints, wasm_tier_up)
DEFINE_IMPLICATION(trace_wasm_generate_compilation_hints, wasm_tier_up)
// Compilation hints generation is incompatible with eager tier-up.
DEFINE_NOT_EXPLICITLY_SET_IMPLICATION(wasm_generate_compilation_hints,
                                      wasm_eager_tier_up_function)
DEFINE_NOT_EXPLICITLY_SET_IMPLICATION(trace_wasm_generate_compilation_hints,
                                      wasm_eager_tier_up_function)
// Compilation hints generation is not compatible with
// --no-wasm-dynamic-tiering or --no-wasm-lazy-compilation.
DEFINE_IMPLICATION(wasm_generate_compilation_hints, wasm_dynamic_tiering)
DEFINE_IMPLICATION(trace_wasm_generate_compilation_hints, wasm_dynamic_tiering)
DEFINE_IMPLICATION(wasm_generate_compilation_hints, wasm_lazy_compilation)
DEFINE_IMPLICATION(trace_wasm_generate_compilation_hints, wasm_lazy_compilation)
// --single-threaded implies --no-wasm-tier-up.
DEFINE_NOT_EXPLICITLY_SET_IMPLICATION(wasm_generate_compilation_hints,
                                      single_threaded)
DEFINE_NOT_EXPLICITLY_SET_IMPLICATION(trace_wasm_generate_compilation_hints,
                                      single_threaded)
// Wasm compilation hints generation is incompatible with features that are not
// implemented in liftoff yet.
DEFINE_NEG_IMPLICATION(wasm_generate_compilation_hints, wasm_wasmfx)
DEFINE_NEG_IMPLICATION(trace_wasm_generate_compilation_hints, wasm_wasmfx)
// Wasm compilation hints generation is incompatible with the testing opcode
// that bails out liftoff.
DEFINE_NEG_IMPLICATION(wasm_generate_compilation_hints,
                       enable_testing_opcode_in_wasm)
DEFINE_NEG_IMPLICATION(trace_wasm_generate_compilation_hints,
                       enable_testing_opcode_in_wasm)

#endif  // V8_ENABLE_WEBASSEMBLY

DEFINE_INT(stress_sampling_allocation_profiler, 0,
           "Enables sampling allocation profiler with X as a sample interval")

// Garbage collections flags.
DEFINE_BOOL(lazy_new_space_shrinking, false,
            "Enables the lazy new space shrinking strategy")
DEFINE_SIZE_T(min_semi_space_size, 0,
              "min size of a semi-space (in MBytes), the new space consists of "
              "two semi-spaces")
DEFINE_SIZE_T(max_semi_space_size, 0,
              "max size of a semi-space (in MBytes), the new space consists of "
              "two semi-spaces")
DEFINE_INT(semi_space_growth_factor, 2, "factor by which to grow the new space")
// Set minimum semi space growth factor
DEFINE_MIN_VALUE_IMPLICATION(semi_space_growth_factor, 2)
DEFINE_SIZE_T(max_old_space_size, 0, "max size of the old space (in Mbytes)")
DEFINE_SIZE_T(
    max_heap_size, 0,
    "max size of the heap (in Mbytes) "
    "both max_semi_space_size and max_old_space_size take precedence. "
    "All three flags cannot be specified at the same time.")
DEFINE_SIZE_T(initial_heap_size, 0, "initial size of the heap (in Mbytes)")
DEFINE_SIZE_T(initial_old_space_size, 0, "initial old space size (in Mbytes)")
DEFINE_SIZE_T(preconfigured_old_space_size, 32,
              "preconfigured old space size (in Mbytes)")
DEFINE_WEAK_VALUE_IMPLICATION(future, preconfigured_old_space_size, size_t{32})
DEFINE_BOOL(gc_global, false, "always perform global GCs")

// TODO(12950): The next three flags only have an effect if
// V8_ENABLE_ALLOCATION_TIMEOUT is set, so we should only define them in that
// config. That currently breaks Node's parallel/test-domain-error-types test
// though.
DEFINE_INT(random_gc_interval, 0,
           "Collect garbage after random(0, X) V8 allocations. It overrides "
           "gc_interval.")
DEFINE_INT(gc_interval, -1, "garbage collect after <n> allocations")
DEFINE_INT(cppgc_random_gc_interval, 0,
            "Collect garbage after random(0, X) cppgc allocations.")
DEFINE_MIN_VALUE_IMPLICATION(cppgc_random_gc_interval, 0)

#ifdef V8_ENABLE_ALLOCATION_TIMEOUT
DEFINE_INT(dispatch_table_gc_interval, -1,
           "garbage collect after <n> dispatch table allocations")
#endif

DEFINE_SMI(retain_maps_for_n_gc, 2,
           "keeps maps alive for <n> old space garbage collections")
DEFINE_DEVELOPER_FLAG(trace_gc,
                      "print one trace line following each garbage collection")
DEFINE_DEVELOPER_FLAG(trace_gc_nvp,
                      "print one detailed trace line in name=value format "
                      "after each garbage collection")
DEFINE_DEVELOPER_FLAG(trace_gc_ignore_scavenger,
                      "do not print trace line after scavenger collection")
DEFINE_DEVELOPER_FLAG(trace_memory_reducer, "print memory reducer behavior")
DEFINE_DEVELOPER_FLAG(trace_gc_verbose,
                      "print more details following each garbage collection")
DEFINE_IMPLICATION(trace_gc_verbose, trace_gc)
DEFINE_DEVELOPER_FLAG(trace_gc_freelists,
                      "prints details of each freelist before and after "
                      "each major garbage collection")
DEFINE_DEVELOPER_FLAG(
    trace_gc_freelists_verbose,
    "prints details of freelists of each page before and after "
    "each major garbage collection")
DEFINE_IMPLICATION(trace_gc_freelists_verbose, trace_gc_freelists)
DEFINE_DEVELOPER_FLAG(trace_gc_heap_layout,
                      "print layout of pages in heap before and after gc")
DEFINE_BOOL(trace_gc_heap_layout_ignore_minor_gc, true,
            "do not print trace line before and after minor-gc")
DEFINE_DEVELOPER_FLAG(
    trace_evacuation_candidates,
    "Show statistics about the pages evacuation by the compaction")

DEFINE_DEVELOPER_FLAG(
    trace_pending_allocations,
    "trace calls to Heap::IsAllocationPending that return true")

DEFINE_INT(trace_allocation_stack_interval, -1,
           "print stack trace after <n> free-list allocations")
DEFINE_INT(trace_duplicate_threshold_kb, 0,
           "print duplicate objects in the heap if their size is more than "
           "given threshold")
DEFINE_DEVELOPER_FLAG(trace_fragmentation, "report fragmentation for old space")
DEFINE_DEVELOPER_FLAG(trace_fragmentation_verbose,
                      "report fragmentation for old space (detailed)")
DEFINE_DEVELOPER_FLAG(minor_ms_trace_fragmentation,
                      "trace fragmentation after marking")
DEFINE_DEVELOPER_FLAG(trace_evacuation, "report evacuation statistics")
DEFINE_DEVELOPER_FLAG(trace_mutator_utilization,
                      "print mutator utilization, allocation speed, gc speed")
DEFINE_BOOL(incremental_marking, true, "use incremental marking")
DEFINE_BOOL(incremental_marking_task, true, "use tasks for incremental marking")
DEFINE_INT(incremental_marking_soft_trigger, 0,
           "threshold for starting incremental marking via a task in percent "
           "of available space: limit - size")
DEFINE_INT(incremental_marking_hard_trigger, 0,
           "threshold for starting incremental marking immediately in percent "
           "of available space: limit - size")
DEFINE_BOOL(incremental_marking_unified_schedule, false,
            "Use a single schedule for determining a marking schedule between "
            "JS and C++ objects.")
DEFINE_DEVELOPER_FLAG(trace_unmapper, "Trace the unmapping")
DEFINE_BOOL(parallel_scavenge, true, "parallel scavenge")
DEFINE_BOOL(minor_gc_task, true, "schedule minor GC tasks")
DEFINE_UINT(minor_gc_task_trigger, 80,
            "minor GC task trigger in percent of the current heap limit")
DEFINE_BOOL(minor_gc_task_with_lower_priority, true,
            "schedules the minor GC task with kUserVisible priority.")
DEFINE_DEVELOPER_FLAG(trace_parallel_scavenge, "trace parallel scavenge")
DEFINE_EXPERIMENTAL_FEATURE(
    cppgc_young_generation,
    "run young generation garbage collections in Oilpan")
// CppGC young generation (enables unified young heap) is based on Minor MS.
DEFINE_IMPLICATION(cppgc_young_generation, minor_ms)
// Unified young generation disables the unmodified wrapper reclamation
// optimization.
DEFINE_NEG_IMPLICATION(cppgc_young_generation, reclaim_unmodified_wrappers)
DEFINE_BOOL(optimize_gc_for_battery, false, "optimize GC for battery")
#if defined(V8_ATOMIC_OBJECT_FIELD_WRITES)
DEFINE_BOOL(concurrent_marking, true, "use concurrent marking")
#else
// Concurrent marking cannot be used without atomic object field loads and
// stores.
DEFINE_BOOL(concurrent_marking, false, "use concurrent marking")
#endif
DEFINE_UINT(
    concurrent_marking_max_worker_num, 7,
    "max worker number of concurrent marking, 0 for NumberOfWorkerThreads")
DEFINE_BOOL(concurrent_array_buffer_sweeping, true,
            "concurrently sweep array buffers")
DEFINE_BOOL(stress_concurrent_allocation, false,
            "start background threads that allocate memory")
DEFINE_BOOL(parallel_marking, true, "use parallel marking in atomic pause")
DEFINE_INT(ephemeron_fixpoint_iterations, 10,
           "number of fixpoint iterations it takes to switch to linear "
           "ephemeron algorithm")
DEFINE_DEVELOPER_FLAG(trace_concurrent_marking, "trace concurrent marking")
DEFINE_BOOL(concurrent_sweeping, true, "use concurrent sweeping")
DEFINE_NEG_NEG_IMPLICATION(concurrent_sweeping,
                           concurrent_array_buffer_sweeping)
DEFINE_BOOL(parallel_compaction, true, "use parallel compaction")
DEFINE_BOOL(parallel_pointer_update, true,
            "use parallel pointer update during compaction")
DEFINE_BOOL(parallel_gc_clearing, true,
            "use parallel threads to clear weak refs in the atomic pause.")
DEFINE_BOOL(detect_ineffective_gcs_near_heap_limit, true,
            "trigger out-of-memory failure to avoid GC storm near heap limit")
DEFINE_BOOL(
    enforce_global_heap_limit, false,
    "Enforce global size by causing an out-of-memory failure above heap limit")
// Since the maximum v8_limit is 4Gb, this aligns with
// ArrayBuffer::kMaxByteLength.
DEFINE_INT(maximum_global_heap_limit_factor, 8,
           "Ratio from v8 to global maximum heap size")
DEFINE_FLOAT(
    ineffective_gc_size_threshold, 0.95,
    "Threshold on heap size to trigger out-of-memory failure near heap limit.")
DEFINE_FLOAT(ineffective_gc_mutator_utilization_threshold, 0.4,
             "Threshold on mutator utilization to trigger out-of-memory "
             "failure near heap limit.")
DEFINE_DEVELOPER_FLAG(trace_incremental_marking,
                      "trace progress of the incremental marking")
DEFINE_DEVELOPER_FLAG(print_gc_clearing_dependency_graph,
                      "print clearing dependency graph in dot format")
DEFINE_DEVELOPER_FLAG(trace_stress_marking, "trace stress marking progress")
DEFINE_DEVELOPER_FLAG(trace_stress_scavenge, "trace stress scavenge progress")
DEFINE_DEVELOPER_FLAG(track_gc_object_stats,
                      "track object counts and memory usage")
DEFINE_DEVELOPER_FLAG(trace_gc_object_stats,
                      "trace object counts and memory usage")
DEFINE_DEVELOPER_FLAG(trace_zone_stats, "trace zone memory usage")
DEFINE_GENERIC_IMPLICATION(
    trace_zone_stats,
    TracingFlags::zone_stats.store(
        v8::tracing::TracingCategoryObserver::ENABLED_BY_NATIVE))
DEFINE_SIZE_T(
    zone_stats_tolerance, 1 * MB,
    "report a tick only when allocated zone memory changes by this amount")
DEFINE_DEVELOPER_FLAG(trace_zone_type_stats, "trace per-type zone memory usage")
DEFINE_GENERIC_IMPLICATION(
    trace_zone_type_stats,
    TracingFlags::zone_stats.store(
        v8::tracing::TracingCategoryObserver::ENABLED_BY_NATIVE))
DEFINE_DEBUG_BOOL(trace_backing_store, false, "trace backing store events")
DEFINE_INT(gc_stats, 0, "Used by tracing internally to enable gc statistics")
DEFINE_IMPLICATION(trace_gc_object_stats, track_gc_object_stats)
DEFINE_GENERIC_IMPLICATION(
    track_gc_object_stats,
    TracingFlags::gc_stats.store(
        v8::tracing::TracingCategoryObserver::ENABLED_BY_NATIVE))
DEFINE_GENERIC_IMPLICATION(
    trace_gc_object_stats,
    TracingFlags::gc_stats.store(
        v8::tracing::TracingCategoryObserver::ENABLED_BY_NATIVE))

#ifdef V8_COMPRESS_POINTERS
DEFINE_DEVELOPER_FLAG(trace_gc_object_stats_all_objects,
                      "trace all objects on each gc (warning: large output)")
DEFINE_IMPLICATION(trace_gc_object_stats_all_objects, trace_gc_object_stats)
#endif  // V8_COMPRESS_POINTERS

DEFINE_NEG_IMPLICATION(trace_gc_object_stats, incremental_marking)
DEFINE_NEG_NEG_IMPLICATION(incremental_marking, concurrent_marking)
DEFINE_NEG_NEG_IMPLICATION(parallel_marking, concurrent_marking)
DEFINE_IMPLICATION(concurrent_marking, incremental_marking)
DEFINE_BOOL(track_detached_contexts, true,
            "track native contexts that are expected to be garbage collected")
DEFINE_DEVELOPER_FLAG(
    trace_detached_contexts,
    "trace native contexts that are expected to be garbage collected")
DEFINE_IMPLICATION(trace_detached_contexts, track_detached_contexts)
#ifdef VERIFY_HEAP
DEFINE_BOOL(verify_heap, false, "verify heap pointers before and after GC")
DEFINE_BOOL(verify_heap_skip_remembered_set, false,
            "disable remembered set verification")
#else
DEFINE_BOOL_READONLY(verify_heap, false,
                     "verify heap pointers before and after GC")
#endif
#if V8_VERIFY_WRITE_BARRIERS
#define V8_VERIFY_WRITE_BARRIERS_BOOL true
#else
#define V8_VERIFY_WRITE_BARRIERS_BOOL false
#endif  // // V8_VERIFY_WRITE_BARRIERS
DEFINE_BOOL_READONLY(verify_write_barriers, V8_VERIFY_WRITE_BARRIERS_BOOL,
                     "verify skipped write barriers")
#undef V8_VERIFY_WRITE_BARRIERS_BOOL
DEFINE_BOOL(safepoint_bump_qos_class, true,
            "Bump priority for running threads to reach safepoint")
DEFINE_BOOL(move_object_start, true, "enable moving of object starts")
DEFINE_BOOL(memory_reducer, true, "use memory reducer")
DEFINE_BOOL(memory_reducer_for_small_heaps, true,
            "use memory reducer for small heaps")
DEFINE_INT(memory_reducer_gc_count, 2,
           "Maximum number of memory reducer GCs scheduled")
DEFINE_REQUIREMENT(v8_flags.memory_reducer_gc_count > 0)
DEFINE_INT(memory_reducer_delay_ms, 8'000, "Delay before memory reducer start")
DEFINE_REQUIREMENT(v8_flags.memory_reducer_delay_ms > 0)
DEFINE_INT(gc_memory_reducer_start_delay_ms, 30'000,
           "Delay before memory reducer start")
DEFINE_REQUIREMENT(v8_flags.gc_memory_reducer_start_delay_ms > 0)
DEFINE_FLOAT(
    external_memory_max_growing_factor, 1.1,
    "This is the upper bound for growing factor imposed on external memory.")
DEFINE_INT(external_memory_max_reasonable_size, 32,
           "Max external memory value (in GB) checked for a reasonable size, 0 "
           "to disable the check.")
DEFINE_BOOL(
    sqrt_allocation_limits, false,
    "Old generation and global heap limit growth scale based on the sqrt of "
    "estimated GC cost.")
DEFINE_INT(
    sqrt_allocation_limits_factor, 80,
    "When the sqrt heap limit is enabled, multiplier on the heap growth.")
DEFINE_INT(
    sqrt_allocation_limits_slow_factor, 80,
    "When the sqrt heap limit is enabled, multiplier on the heap growth for "
    "HeapGrowingMode::kSlow.")
DEFINE_INT(
    sqrt_allocation_limits_minimal_factor, 20,
    "When the sqrt heap limit is enabled, multiplier on the heap growth for "
    "HeapGrowingMode::kMinimal.")
DEFINE_FLOAT(
    sqrt_allocation_limits_min_growing_factor, 1.1,
    "This is the lower bound for growing factor when using sqrt heap limit.")
DEFINE_FLOAT(
    sqrt_allocation_limits_max_growing_factor, 4.0,
    "This is the upper bound for growing factor when using sqrt heap limit.")
DEFINE_BOOL(gc_speed_uses_counters, false,
            "Old gen GC speed is computed directly from gc tracer counters.")
DEFINE_INT(heap_growing_percent, 0,
           "specifies heap growing factor as (1 + heap_growing_percent/100)")
DEFINE_INT(v8_os_page_size, 0, "override OS page size (in KBytes)")
DEFINE_BOOL(allocation_buffer_parking, true, "allocation buffer parking")
DEFINE_BOOL(compact, true,
            "Perform compaction on full GCs based on V8's default heuristics")
DEFINE_BOOL(compact_code_space, true,
            "Perform code space compaction on full collections.")
DEFINE_BOOL(compact_on_every_full_gc, false,
            "Perform compaction on every full GC")
DEFINE_BOOL(compaction_on_regular_gcs, true,
            "Perform compaction on regular GCs")
DEFINE_BOOL(compact_with_stack, true,
            "Perform compaction when finalizing a full GC with stack")
DEFINE_INT(compaction_max_evacuated_bytes_mb, 4,
           "Max evacuated bytes during compaction")
DEFINE_INT(compaction_max_evacuated_bytes_mb_for_reduce_memory, 12,
           "Max evacuated bytes during compaction for reduce memory GCs")
DEFINE_INT(compaction_max_evacuated_bytes_mb_for_optimize_memory, 6,
           "Max evacuated bytes during compaction for GCs when "
           "ShouldOptimizeForMemoryUsage() = true")
DEFINE_INT(compaction_target_fragmentation_percent_for_reduce_memory, 20,
           "Target fragmentation % during compaction for reduce memory GCs")
DEFINE_INT(compaction_target_fragmentation_percent_for_optimize_memory, 20,
           "Target fragmentation % during compaction for GCs when "
           "ShouldOptimizeForMemoryUsage() = true")
DEFINE_BOOL(shortcut_strings_with_stack, true,
            "Shortcut Strings during GC with stack")
DEFINE_BOOL(stress_compaction, false,
            "Stress GC compaction to flush out bugs with moving objects")
DEFINE_BOOL(resize_large_object, true, "Support resizing of large objects")
DEFINE_BOOL(stress_compaction_random, false,
            "Stress GC compaction by selecting random percent of pages as "
            "evacuation candidates. Overrides stress_compaction.")
DEFINE_IMPLICATION(stress_compaction, gc_global)
DEFINE_NEG_IMPLICATION(stress_compaction, resize_large_object)
DEFINE_VALUE_IMPLICATION(stress_compaction, max_semi_space_size, (size_t)1)
DEFINE_BOOL(stress_descriptor_array_trimming, false,
            "Stress descriptor array trimming on every stackless GC.")
DEFINE_BOOL(flush_baseline_code, false,
            "flush of baseline code when it has not been executed recently")
DEFINE_BOOL(flush_bytecode, true,
            "flush of bytecode when it has not been executed recently")
DEFINE_INT(bytecode_old_age, 6, "number of gcs before we flush code")
DEFINE_REQUIREMENT(v8_flags.bytecode_old_age >= 0)
DEFINE_BOOL(flush_code_based_on_time, true,
            "Use time-base code flushing instead of age.")
DEFINE_IMPLICATION(flush_code_based_on_time, late_heap_limit_check)
DEFINE_BOOL(flush_code_based_on_tab_visibility, false,
            "Flush code when tab goes into the background.")
DEFINE_IMPLICATION(flush_code_based_on_tab_visibility, late_heap_limit_check)
DEFINE_INT(bytecode_old_time, 180, "number of seconds before we flush code")
DEFINE_BOOL(stress_flush_code, false, "stress code flushing")
DEFINE_WEAK_IMPLICATION(stress_flush_code, flush_baseline_code)
DEFINE_DEVELOPER_FLAG(trace_flush_code, "trace bytecode flushing")
DEFINE_BOOL(use_marking_progress_bar, true,
            "Use a progress bar to scan large objects in increments when "
            "incremental marking is active.")
DEFINE_INT(fixed_margin_for_input_handling, 32,
           "how much we are allowed to overshoot the heap limit by during "
           "input mode, in MiB.")
DEFINE_BOOL(optimize_for_input_handling, true,
            "whether to use input hints to optimize for responsiveness.")
DEFINE_BOOL(stress_per_context_marking_worklist, false,
            "Use per-context worklist for marking")
DEFINE_BOOL(stress_incremental_marking, false,
            "force incremental marking for small heaps and run it more often")

DEFINE_BOOL(memory_pool, true,
            "Pool memory globally before returning it to the operating system")
DEFINE_BOOL(
    memory_pool_share_memory_on_teardown, true,
    "Share memory on Isolate teardown using other Isolate's task runners")
DEFINE_BOOL(memory_pool_release_on_malloc_failures, false,
            "discard the memory pool on malloc retries")
DEFINE_SIZE_T(memory_pool_timeout, 8, "Release pooled pages after X seconds.")
DEFINE_BOOL(large_page_pool, true, "Add large pages to the page pool")
DEFINE_SIZE_T(max_large_page_pool_size, 32,
              "Maximum size of pooled large pages in MB.")
DEFINE_BOOL(managed_zone_memory, false,
            "Manage zone memory in V8 instead of using malloc().")
DEFINE_BOOL(managed_zone_memory_for_isolate_independent_memory, false,
            "Pool zone memory for isolate independent memory (nullptr-isolate) "
            "(e.g. Wasm).")
DEFINE_WEAK_IMPLICATION(future, managed_zone_memory)
DEFINE_NEG_NEG_IMPLICATION(memory_pool, managed_zone_memory)

DEFINE_BOOL(fuzzer_gc_analysis, false,
            "prints number of allocations and enables analysis mode for gc "
            "fuzz testing, e.g. --stress-marking, --stress-scavenge")
DEFINE_INT(stress_marking, 0,
           "force marking at random points between 0 and X (inclusive) percent "
           "of the regular marking start limit")
DEFINE_REQUIREMENT(v8_flags.stress_marking >= 0)
DEFINE_REQUIREMENT(v8_flags.stress_marking <= 100)
DEFINE_INT(stress_scavenge, 0,
           "force scavenge at random points between 0 and X (inclusive) "
           "percent of the new space capacity")
DEFINE_REQUIREMENT(v8_flags.stress_scavenge >= 0)
DEFINE_REQUIREMENT(v8_flags.stress_scavenge <= 100)
DEFINE_VALUE_IMPLICATION(fuzzer_gc_analysis, stress_marking, 99)
DEFINE_VALUE_IMPLICATION(fuzzer_gc_analysis, stress_scavenge, 99)
DEFINE_BOOL(
    reclaim_unmodified_wrappers, true,
    "reclaim otherwise unreachable unmodified wrapper objects when possible")
DEFINE_BOOL(parallel_reclaim_unmodified_wrappers, true,
            "reclaim wrapper objects in parallel")

DEFINE_BOOL(concurrent_marking_high_priority_threads, false,
            "use high priority threads for concurrent Marking")

DEFINE_BOOL(disable_abortjs, false, "disables AbortJS runtime function")

DEFINE_BOOL(randomize_all_allocations, false,
            "randomize virtual memory reservations by ignoring any hints "
            "passed when allocating pages")

DEFINE_BOOL(manual_evacuation_candidates_selection, false,
            "Test mode only flag. It allows an unit test to select evacuation "
            "candidates pages (requires --stress_compaction).")

DEFINE_BOOL(clear_free_memory, false, "initialize free memory with 0")

DEFINE_BOOL(idle_gc_on_context_disposal, true, "idle gc on context disposal")

DEFINE_DEVELOPER_FLAG(trace_context_disposal, "trace context disposal")

// v8::CppHeap flags that allow fine-grained control of how C++ memory is
// reclaimed in the garbage collector.
DEFINE_BOOL(cppheap_incremental_marking, false,
            "use incremental marking for CppHeap")
DEFINE_NEG_NEG_IMPLICATION(incremental_marking, cppheap_incremental_marking)
DEFINE_NEG_NEG_IMPLICATION(incremental_marking, memory_reducer)
DEFINE_WEAK_IMPLICATION(incremental_marking, cppheap_incremental_marking)
DEFINE_BOOL(cppheap_concurrent_marking, false,
            "use concurrent marking for CppHeap")
DEFINE_NEG_NEG_IMPLICATION(cppheap_incremental_marking,
                           cppheap_concurrent_marking)
DEFINE_NEG_NEG_IMPLICATION(concurrent_marking, cppheap_concurrent_marking)
DEFINE_WEAK_IMPLICATION(concurrent_marking, cppheap_concurrent_marking)

DEFINE_BOOL(memory_balancer, false,
            "use membalancer, "
            "a new heap limit balancing algorithm")
DEFINE_FLOAT(memory_balancer_c_value, 3e-10,
             "c value for membalancer. "
             "A special constant to balance between memory and space tradeoff. "
             "The smaller the more memory it uses.")
DEFINE_NEG_IMPLICATION(memory_balancer, memory_reducer)
DEFINE_DEVELOPER_FLAG(trace_memory_balancer, "print memory balancer behavior.")
DEFINE_BOOL(late_heap_limit_check, true,
            "skips heap limit check for early GCs on allocation failure.")

// assembler-ia32.cc / assembler-arm.cc / assembler-arm64.cc / assembler-x64.cc
#ifdef V8_ENABLE_DEBUG_CODE
DEFINE_BOOL(debug_code, DEBUG_BOOL,
            "generate extra code (assertions) for debugging")
DEFINE_BOOL(trap_on_abort, false, "trap instead of calling abort for debugging")
#if defined(V8_ENABLE_SLOW_DEBUG_CODE_BY_DEFAULT) || \
    defined(ENABLE_SLOW_DCHECKS)
#define V8_ENABLE_SLOW_DEBUG_CODE_BY_DEFAULT_BOOL true
#else
#define V8_ENABLE_SLOW_DEBUG_CODE_BY_DEFAULT_BOOL false
#endif
// slow_debug_code is enabled by default for builds with is_debug or
// v8_enable_slow_dchecks.
DEFINE_BOOL(slow_debug_code, V8_ENABLE_SLOW_DEBUG_CODE_BY_DEFAULT_BOOL,
            "generate slow extra code (assertions) for debugging")
DEFINE_NEG_NEG_IMPLICATION(debug_code, slow_debug_code)
#else
DEFINE_BOOL_READONLY(debug_code, false, "")
DEFINE_BOOL_READONLY(trap_on_abort, true, "")
DEFINE_BOOL_READONLY(slow_debug_code, false, "")
#endif
#ifdef V8_CODE_COMMENTS
DEFINE_BOOL(code_comments, false,
            "emit comments in code disassembly; for more readable source "
            "positions you should add --no-concurrent_recompilation")
#else
DEFINE_BOOL_READONLY(code_comments, false, "")
#endif
DEFINE_BOOL(enable_sse3, true, "enable use of SSE3 instructions if available")
DEFINE_BOOL(enable_ssse3, true, "enable use of SSSE3 instructions if available")
DEFINE_BOOL(enable_sse4_1, true,
            "enable use of SSE4.1 instructions if available")
DEFINE_BOOL(enable_sse4_2, true,
            "enable use of SSE4.2 instructions if available")
DEFINE_BOOL(enable_sahf, true,
            "enable use of SAHF instruction if available (X64 only)")
DEFINE_BOOL(enable_avx, true, "enable use of AVX instructions if available")
DEFINE_BOOL(enable_avx2, true, "enable use of AVX2 instructions if available")
DEFINE_BOOL(enable_avx_vnni, true,
            "enable use of AVX-VNNI instructions if available")
DEFINE_BOOL(enable_avx_vnni_int8, true,
            "enable use of AVX-VNNI-INT8 instructions if available")
DEFINE_BOOL(enable_fma3, true, "enable use of FMA3 instructions if available")
DEFINE_BOOL(enable_f16c, true, "enable use of F16C instructions if available")
DEFINE_BOOL(enable_bmi1, true, "enable use of BMI1 instructions if available")
DEFINE_BOOL(enable_bmi2, true, "enable use of BMI2 instructions if available")
DEFINE_BOOL(enable_lzcnt, true, "enable use of LZCNT instruction if available")
DEFINE_BOOL(enable_popcnt, true,
            "enable use of POPCNT instruction if available")
#ifdef V8_ENABLE_APX_F
DEFINE_BOOL(enable_apx_f, false, "enable use of APX_F instruction if available")
DEFINE_BOOL(enable_apx_f_setzucc, false,
            "enable use of APX setzucc for x64 zero-extending setcc patterns")
DEFINE_BOOL(enable_apx_f_cmovcc, false,
            "enable use of APX cmovcc for x64 conditional move patterns")
DEFINE_BOOL(enable_apx_f_ccmp, false,
            "enable use of APX ccmp/ctest for x64 conditional compare patterns")
DEFINE_IMPLICATION(enable_apx_f_setzucc, enable_apx_f)
DEFINE_IMPLICATION(enable_apx_f_cmovcc, enable_apx_f)
DEFINE_IMPLICATION(enable_apx_f_ccmp, enable_apx_f)
#endif
#ifdef V8_ENABLE_AVX10_1
DEFINE_BOOL(enable_avx10_1, false,
            "enable use of AVX10.1 instructions if available")
#endif
DEFINE_STRING(arm_arch, ARM_ARCH_DEFAULT,
              "generate instructions for the selected ARM architecture if "
              "available: armv6, armv7, armv7+sudiv or armv8")
#if defined(V8_TARGET_ARCH_ARM)
DEFINE_STRING(mfloat_abi, "auto",
              "selects the ARM FP ABI to use: softfp, hardfp or auto."
              "available: softfp,hardfp or auto")
#endif
DEFINE_BOOL(force_long_branches, false,
            "force all emitted branches to be in long mode (MIPS/PPC only)")
DEFINE_STRING(mcpu, "auto", "enable optimization for specific cpu")
DEFINE_BOOL(partial_constant_pool, true,
            "enable use of partial constant pools (x64 only)")
DEFINE_STRING(sim_arm64_optional_features, "none",
              "enable optional features on the simulator for testing: none or "
              "all")
DEFINE_BOOL(sim_arm64_tbi, true,
            "simulate arm64 Top Byte Ignore (TBI) for data accesses")
DEFINE_BOOL(intel_jcc_erratum_mitigation, true,
            "enable mitigation for Intel JCC erratum on affected CPUs")

#if defined(V8_TARGET_ARCH_RISCV32) || defined(V8_TARGET_ARCH_RISCV64)
DEFINE_BOOL(riscv_trap_to_simulator_debugger, false,
            "enable simulator trap to debugger")
DEFINE_BOOL(riscv_debug, false, "enable debug prints")
DEFINE_STRING(riscv_debug_file_path, nullptr, "path to riscv_debug_file")

DEFINE_BOOL(riscv_constant_pool, true, "enable constant pool (RISCV only)")

DEFINE_BOOL(riscv_b_extension, false,
            "enable B extension isa variant (RISCV only)")
DEFINE_BOOL(
    use_aliases, true,
    "use aliases for instruction mnemonics when printing code (RISCV only)")

#ifdef USE_SIMULATOR
DEFINE_BOOL(sim_abort_on_shadowstack_mismatch, true,
            "Stop execution when shadowstack match fails in the "
            "riscv simulator.")
DEFINE_DEVELOPER_FLAG(trace_shadowstack,
                      "Trace shadowstack operations in the riscv simulator.")
#endif
#endif

// Controlling source positions for Torque/CSA code.
DEFINE_BOOL(enable_source_at_csa_bind, false,
            "Include source information in the binary at CSA bind locations.")

// Deprecated ARM flags (replaced by arm_arch).
DEFINE_MAYBE_BOOL(enable_armv7, "deprecated (use --arm_arch instead)")
DEFINE_MAYBE_BOOL(enable_vfp3, "deprecated (use --arm_arch instead)")
DEFINE_MAYBE_BOOL(enable_32dregs, "deprecated (use --arm_arch instead)")
DEFINE_MAYBE_BOOL(enable_neon, "deprecated (use --arm_arch instead)")
DEFINE_MAYBE_BOOL(enable_sudiv, "deprecated (use --arm_arch instead)")
DEFINE_MAYBE_BOOL(enable_armv8, "deprecated (use --arm_arch instead)")

// regexp-macro-assembler-*.cc
DEFINE_BOOL(enable_regexp_unaligned_accesses, true,
            "enable unaligned accesses for the regexp engine")

// api.cc
DEFINE_BOOL(script_streaming, true, "enable parsing on background")
DEFINE_BOOL(stress_background_compile, false,
            "stress test parsing on background")
DEFINE_BOOL(concurrent_cache_deserialization, true,
            "enable deserializing code caches on background")
DEFINE_BOOL(
    merge_background_deserialized_script_with_compilation_cache, true,
    "After deserializing code cache data on a background thread, merge it into "
    "an existing Script if one is found in the Isolate compilation cache")
DEFINE_BOOL(verify_code_merge, false, "Verify scope infos after merge")


// bootstrapper.cc
DEFINE_BOOL(expose_gc, false, "expose gc extension")
DEFINE_STRING(expose_gc_as, nullptr,
              "expose gc extension under the specified name")
DEFINE_IMPLICATION(expose_gc_as, expose_gc)
DEFINE_BOOL(expose_externalize_string, false,
            "expose externalize string extension")
DEFINE_BOOL(expose_statistics, false, "expose statistics extension")
DEFINE_BOOL(expose_trigger_failure, false, "expose trigger-failure extension")
DEFINE_SMI(stack_trace_limit, 10, "number of stack frames to capture")
DEFINE_BOOL(builtins_in_stack_traces, false,
            "show built-in functions in stack traces")
DEFINE_BOOL(experimental_stack_trace_frames, false,
            "enable experimental frames (API/Builtins) and stack trace layout")
DEFINE_BOOL(disallow_code_generation_from_strings, false,
            "disallow eval and friends")
DEFINE_BOOL(expose_async_hooks, false, "expose async_hooks object")
DEFINE_STRING(expose_cputracemark_as, nullptr,
              "expose cputracemark extension under the specified name")
#ifdef ENABLE_VTUNE_TRACEMARK
DEFINE_BOOL(enable_vtune_domain_support, true, "enable vtune domain support")
#endif  // ENABLE_VTUNE_TRACEMARK

#ifdef ENABLE_VTUNE_JIT_INTERFACE
DEFINE_BOOL(enable_vtunejit, true, "enable vtune jit interface")
DEFINE_NEG_IMPLICATION(enable_vtunejit, compact_code_space)
#endif  // ENABLE_VTUNE_JIT_INTERFACE

DEFINE_BOOL(experimental_report_exceptions_from_callbacks, true,
            "Notify Api callback about exceptions thrown in Api callbacks")

// builtins.cc
DEFINE_BOOL(allow_unsafe_function_constructor, false,
            "allow invoking the function constructor without security checks")
DEFINE_BOOL(force_slow_path, false, "always take the slow path for builtins")
DEFINE_BOOL(test_small_max_function_context_stub_size, false,
            "enable testing the function context size overflow path "
            "by making the maximum size smaller")
DEFINE_WEAK_IMPLICATION(future, fast_api_indexof)
DEFINE_BOOL(fast_api_indexof, false, "enable using indexOf Api callbacks")
DEFINE_WEAK_IMPLICATION(future, fast_api_iterable_to_list)
DEFINE_BOOL(fast_api_iterable_to_list, false,
            "enable fast path for IterableToList for indexed interceptors")

DEFINE_BOOL(inline_new, true, "use fast inline allocation")
DEFINE_NEG_NEG_IMPLICATION(inline_new, turbo_allocation_folding)

// bytecode-generator.cc
DEFINE_INT(switch_table_spread_threshold, 3,
           "allow the jump table used for switch statements to span a range "
           "of integers roughly equal to this number times the number of "
           "clauses in the switch")
DEFINE_INT(switch_table_min_cases, 6,
           "the number of Smi integer cases present in the switch statement "
           "before using the jump table optimization")
DEFINE_REQUIREMENT(v8_flags.switch_table_min_cases > 0)
// Note that enabling this stress mode might result in a failure to compile
// even a top-level code.
DEFINE_UINT(stress_lazy_compilation, 0,
            "stress lazy compilation by simulating stack overflow during "
            "unoptimized bytecode generation with 1/n-th probability, "
            "do nothing on 0")
// Correctness fuzzing treats stack overflows as crashes.
DEFINE_VALUE_IMPLICATION(correctness_fuzzer_suppressions,
                         stress_lazy_compilation, 0u)

// codegen-ia32.cc / codegen-arm.cc
DEFINE_BOOL(trace, false, "trace javascript function calls")

// codegen.cc
DEFINE_BOOL(lazy, true, "use lazy compilation")
DEFINE_BOOL(lazy_eval, true, "use lazy compilation during eval")
DEFINE_BOOL(lazy_streaming, true,
            "use lazy compilation during streaming compilation")
DEFINE_BOOL(max_lazy, false, "ignore eager compilation hints")
DEFINE_IMPLICATION(max_lazy, lazy)
DEFINE_BOOL(compile_hints_magic, false, "enable magic compile hints comments")
DEFINE_DEVELOPER_FLAG(trace_opt, "trace optimized compilation")
DEFINE_DEVELOPER_FLAG(
    trace_opt_status,
    "trace the optimization status of functions during tiering events")
DEFINE_DEVELOPER_FLAG(trace_opt_verbose,
                      "extra verbose optimized compilation tracing")
DEFINE_IMPLICATION(trace_opt_verbose, trace_opt)
DEFINE_DEVELOPER_FLAG(trace_opt_stats, "trace optimized compilation statistics")
DEFINE_DEVELOPER_FLAG(trace_deopt, "trace deoptimization")
DEFINE_DEVELOPER_FLAG(log_deopt, "log deoptimization")
DEFINE_DEVELOPER_FLAG(trace_deopt_verbose,
                      "extra verbose deoptimization tracing")
DEFINE_IMPLICATION(trace_deopt_verbose, trace_deopt)
DEFINE_DEVELOPER_FLAG(trace_file_names,
                      "include file names in trace-opt/trace-deopt output")
DEFINE_BOOL(always_osr, false, "always try to OSR functions")

DEFINE_DEVELOPER_FLAG(trace_serializer, "print code serializer trace")
#ifdef DEBUG
DEFINE_BOOL(external_reference_stats, false,
            "print statistics on external references used during serialization")
#endif  // DEBUG

#ifdef V8_DUMPLING
// Dumpling flags start.
DEFINE_BOOL(interpreter_dumping, false,
            "enable frame dumping in the interpreter")
DEFINE_BOOL(sparkplug_dumping, false,
            "enable frame dumping in baseline compiler")
DEFINE_BOOL(maglev_dumping, false, "enable frame dumping in maglev")
DEFINE_BOOL(turbofan_dumping, false, "enable frame dumping in turbofan")
// Needed for function id.
DEFINE_NEG_IMPLICATION(interpreter_dumping, enable_lazy_source_positions)
DEFINE_NEG_IMPLICATION(sparkplug_dumping, enable_lazy_source_positions)
DEFINE_NEG_IMPLICATION(maglev_dumping, enable_lazy_source_positions)
DEFINE_NEG_IMPLICATION(turbofan_dumping, enable_lazy_source_positions)
DEFINE_STRING(dump_out_filename, "/tmp/output_dump.txt",
              "File to save the frame dumps to")
DEFINE_INT(dumpling_depth, 3, "depth used in dumpling")
DEFINE_STRING(dump_positions_filename, "/tmp/dump_positions.txt",
              "File to save dump positions to")
DEFINE_BOOL(generate_dump_positions, false, "write dump positions to a file")
DEFINE_BOOL(load_dump_positions, false, "load dump positions from a file")
DEFINE_NEG_IMPLICATION(generate_dump_positions, load_dump_positions)
// Dumpling flags end.
#endif  // V8_DUMPLING

// compilation-cache.cc
DEFINE_BOOL(compilation_cache, true, "enable compilation cache")

DEFINE_BOOL(cache_prototype_transitions, true, "cache prototype transitions")

// lazy-compile-dispatcher.cc
DEFINE_EXPERIMENTAL_FEATURE(lazy_compile_dispatcher,
                            "enable compiler dispatcher")
DEFINE_UINT(lazy_compile_dispatcher_max_threads, 0,
            "max threads for compiler dispatcher (0 for unbounded)")
DEFINE_DEVELOPER_FLAG(trace_compiler_dispatcher,
                      "trace compiler dispatcher activity")
DEFINE_EXPERIMENTAL_FEATURE(
    parallel_compile_tasks_for_eager_toplevel,
    "spawn parallel compile tasks for eagerly compiled, top-level functions")
DEFINE_IMPLICATION(parallel_compile_tasks_for_eager_toplevel,
                   lazy_compile_dispatcher)
DEFINE_EXPERIMENTAL_FEATURE(
    parallel_compile_tasks_for_lazy,
    "spawn parallel compile tasks for all lazily compiled functions")
DEFINE_IMPLICATION(parallel_compile_tasks_for_lazy, lazy_compile_dispatcher)

// cpu-profiler.cc
DEFINE_UINT(cpu_profiler_sampling_interval, 1000,
            "CPU profiler sampling interval in microseconds")

// debugger
DEFINE_BOOL(simulator_debugger, false,
            "Start a debugger when a simulator hits a breakpoint")
DEFINE_NEG_IMPLICATION(fuzzing, simulator_debugger)
DEFINE_NEG_IMPLICATION(jit_fuzzing, simulator_debugger)
DEFINE_NEG_IMPLICATION(hole_fuzzing, simulator_debugger)
DEFINE_NEG_IMPLICATION(sandbox_fuzzing, simulator_debugger)

DEFINE_BOOL(
    trace_side_effect_free_debug_evaluate, false,
    "print debug messages for side-effect-free debug-evaluate for testing")
DEFINE_BOOL(hard_abort, true, "abort by crashing")
DEFINE_NEG_IMPLICATION(fuzzing, hard_abort)
DEFINE_NEG_IMPLICATION(hole_fuzzing, hard_abort)
DEFINE_NEG_IMPLICATION(sandbox_fuzzing, hard_abort)

// disassembler
DEFINE_BOOL(log_colour, ENABLE_LOG_COLOUR,
            "When logging, try to use coloured output.")

// inspector
DEFINE_BOOL(expose_inspector_scripts, false,
            "expose injected-script-source.js for debugging")

// execution.cc
//
// Note: the value of this flag may not match what is actually available. In
// particular, on MacOS, so-called "secondary threads" only get 512kB by
// default - and this is smaller than V8_DEFAULT_STACK_SIZE_KB. See e.g.
// Blink's V8Initializer::InitializeWorker function for a place where custom
// thread stack sizes are configured.
//
// In other words, be careful about using this process-wide flag.
DEFINE_INT(stack_size, V8_DEFAULT_STACK_SIZE_KB,
           "default size of stack region v8 is allowed to use (in kBytes)")

// frames.cc
DEFINE_INT(max_stack_trace_source_length, 300,
           "maximum length of function source code printed in a stack trace.")

// execution.cc, messages.cc
DEFINE_BOOL(clear_exceptions_on_js_entry, false,
            "clear exceptions when entering JavaScript")

DEFINE_BOOL(use_original_message_for_stack_trace, true,
            "use the message with which the Error constructor was called "
            "rather than the value of the \"message\" property for Error.stack")

// counters.cc
DEFINE_INT(histogram_interval, 600000,
           "time interval in ms for aggregating memory histograms")

// heap-snapshot-generator.cc
DEFINE_BOOL(heap_profiler_trace_objects, false,
            "Dump heap object allocations/movements/size_updates")
DEFINE_BOOL(heap_profiler_use_embedder_graph, true,
            "Use the new EmbedderGraph API to get embedder nodes")
DEFINE_BOOL(heap_snapshot_on_oom, false,
            "Write a heap snapshot to disk on last-resort GCs")
DEFINE_STRING(heap_snapshot_path, nullptr,
              "Directory to write heap snapshots to. (If not set, "
              "the snapshot is written to the current working directory.)")
// Fuzzing should not set a potentially invalid path.
DEFINE_VALUE_IMPLICATION(fuzzing, heap_snapshot_path,
                         static_cast<const char*>(nullptr))
DEFINE_INT(heap_snapshot_on_gc, -1,
           "Write a heap snapshot to disk on a certain GC invocation. 0 "
           "results in taking a snapshot on every invocation.")
DEFINE_UINT(heap_snapshot_string_limit, 1024,
            "truncate strings to this length in the heap snapshot")
DEFINE_BOOL(profile_heap_snapshot, false, "dump time spent on heap snapshot")
#ifdef V8_ENABLE_HEAP_SNAPSHOT_VERIFY
DEFINE_BOOL(heap_snapshot_verify, false,
            "verify that heap snapshot matches marking visitor behavior")
DEFINE_IMPLICATION(enable_slow_asserts, heap_snapshot_verify)
#endif

// sampling-heap-profiler.cc
DEFINE_BOOL(sampling_heap_profiler_suppress_randomness, false,
            "Use constant sample intervals to eliminate test flakiness")

// ic.cc
DEFINE_BOOL(log_ic, false,
            "Log inline cache state transitions for tools/ic-processor")
DEFINE_IMPLICATION(log_ic, log_code)
DEFINE_GENERIC_IMPLICATION(
    log_ic, TracingFlags::ic_stats.store(
                v8::tracing::TracingCategoryObserver::ENABLED_BY_NATIVE))
DEFINE_BOOL_READONLY(fast_map_update, false,
                     "enable fast map update by caching the migration target")
#define DEFAULT_MAX_POLYMORPHIC_MAP_COUNT 10
DEFINE_INT(max_valid_polymorphic_map_count, DEFAULT_MAX_POLYMORPHIC_MAP_COUNT,
           "maximum number of valid maps to track in POLYMORPHIC state")
DEFINE_BOOL(
    clone_object_sidestep_transitions, true,
    "support sidestep transitions for dependency tracking object clone maps")
DEFINE_WEAK_IMPLICATION(future, clone_object_sidestep_transitions)

// map-inl.h
DEFINE_INT(fast_properties_soft_limit, 12,
           "limits the number of properties that can be added to an object "
           "using keyed store before transitioning to dictionary mode")

DEFINE_BOOL(native_code_counters, DEBUG_BOOL,
            "generate extra code for manipulating stats counters")

#ifndef V8_ENABLE_SPARKPLUG_PLUS
// If the Sparkplug+ build flag is enabled, we define the flag in
// feature-flags.h instead of here to follow the regular launch process format.
DEFINE_BOOL_READONLY(sparkplug_plus, false,
                     "enable dynamic patching on JS baseline code")
DEFINE_BOOL_READONLY(sparkplug_inline_smi, false,
                     "inline the Smi fast path of embedded feedback "
                     "operations into baseline code")
#endif
DEFINE_IMPLICATION(sparkplug_plus, short_builtin_calls)

DEFINE_BOOL(super_ic, true, "use an IC for super property loads")

DEFINE_EXPERIMENTAL_FEATURE(mega_dom_ic, "use MegaDOM IC state for API objects")

DEFINE_UINT(homomorphic_ic_count, 8, "local cache size in homomorphic ICs")
DEFINE_REQUIREMENT(
    base::bits::IsPowerOfTwo(v8_flags.homomorphic_ic_count.value()))

// objects.cc
DEFINE_DEVELOPER_FLAG(trace_prototype_users,
                      "Trace updates to prototype user tracking")
DEFINE_DEVELOPER_FLAG(trace_for_in_enumerate,
                      "Trace for-in enumerate slow-paths")
DEFINE_BOOL(log_maps, false, "Log map creation")
DEFINE_BOOL(log_maps_details, true, "Also log map details")
DEFINE_IMPLICATION(log_maps, log_code)

// parser.cc
DEFINE_BOOL(allow_natives_syntax, false, "allow natives syntax")
DEFINE_BOOL(allow_natives_for_differential_fuzzing, false,
            "allow only natives explicitly allowlisted for differential "
            "fuzzers")
DEFINE_IMPLICATION(allow_natives_for_differential_fuzzing, allow_natives_syntax)
DEFINE_IMPLICATION(allow_natives_for_differential_fuzzing, fuzzing)
DEFINE_BOOL(parse_only, false, "only parse the sources")

// simulator-arm.cc and simulator-arm64.cc.
#ifdef USE_SIMULATOR
DEFINE_DEVELOPER_FLAG(trace_sim, "Trace simulator execution")
DEFINE_BOOL(debug_sim, false, "Enable debugging the simulator")
DEFINE_BOOL(check_icache, false,
            "Check icache flushes in ARM and MIPS simulator")
DEFINE_INT(stop_sim_at, 0, "Simulator stop after x number of instructions")
#if defined(V8_TARGET_ARCH_ARM64) || defined(V8_TARGET_ARCH_MIPS64) ||  \
    defined(V8_TARGET_ARCH_PPC64) || defined(V8_TARGET_ARCH_RISCV64) || \
    defined(V8_TARGET_ARCH_LOONG64)
DEFINE_INT(sim_stack_alignment, 16,
           "Stack alignment in bytes in simulator. This must be a power of two "
           "and it must be at least 16. 16 is default.")
DEFINE_REQUIREMENT(
    v8_flags.sim_stack_alignment >= 16 &&
    base::bits::IsPowerOfTwo(v8_flags.sim_stack_alignment.value()))
#else
DEFINE_INT(sim_stack_alignment, 8,
           "Stack alingment in bytes in simulator (4 or 8, 8 is default)")
DEFINE_REQUIREMENT(v8_flags.sim_stack_alignment == 4 ||
                   v8_flags.sim_stack_alignment == 8)
#endif
DEFINE_INT(sim_stack_size, 2 * MB / KB,
           "Stack size of the ARM64, MIPS64 and PPC64 simulator "
           "in kBytes (default is 2 MB)")
DEFINE_DEVELOPER_FLAG(trace_sim_messages,
                      "Trace simulator debug messages. Implied by --trace-sim.")
#endif  // USE_SIMULATOR

#if defined V8_TARGET_ARCH_ARM64
// pointer-auth-arm64.cc
DEFINE_BOOL(sim_abort_on_bad_auth, true,
            "Stop execution when a pointer authentication fails in the "
            "ARM64 simulator.")
#endif

// isolate.cc
DEFINE_BOOL(async_stack_traces, true,
            "include async stack traces in Error.stack")
DEFINE_BOOL(stack_trace_on_illegal, false,
            "print stack trace when an illegal exception is thrown")
DEFINE_BOOL(abort_on_uncaught_exception, false,
            "abort program (dump core) when an uncaught exception is thrown")
DEFINE_BOOL(correctness_fuzzer_suppressions, false,
            "Suppress certain unspecified behaviors to ease correctness "
            "fuzzing: Abort program when the stack overflows or a string "
            "exceeds maximum length (as opposed to throwing RangeError). "
            "Use a fixed suppression string for error messages.")
DEFINE_BOOL(rehash_snapshot, false,
            "rehash strings from the snapshot to override the baked-in seed")
DEFINE_UINT64(hash_seed, 0,
              "Fixed seed to use to hash property keys (0 means random)"
              "(with snapshots this option cannot override the baked-in seed)")
DEFINE_INT(random_seed, 0,
           "Default seed for initializing random generator "
           "(0, the default, means to use system random).")
DEFINE_INT(fuzzer_random_seed, 0,
           "Default seed for initializing fuzzer random generator "
           "(0, the default, means to use v8's random number generator seed).")
#if V8_HASHES_COLLIDE
DEFINE_BOOL(hashes_collide, false,
            "Create more hash collisions by making certain hash functions "
            "always return the same constant")
#endif  // V8_HASHES_COLLIDE
DEFINE_DEVELOPER_FLAG(trace_rail, "trace RAIL mode")
DEFINE_DEVELOPER_FLAG(
    print_all_exceptions,
    "print exception object and stack trace on each thrown exception")

DEFINE_BOOL(adjust_os_scheduling_parameters, true,
            "adjust OS specific scheduling params for the isolate")
DEFINE_BOOL(experimental_flush_embedded_blob_icache, true,
            "Used in an experiment to evaluate icache flushing on certain CPUs")

// Flags for short builtin calls feature
#if V8_SHORT_BUILTIN_CALLS
#define V8_SHORT_BUILTIN_CALLS_BOOL true
#else
#define V8_SHORT_BUILTIN_CALLS_BOOL false
#endif

DEFINE_BOOL(short_builtin_calls, V8_SHORT_BUILTIN_CALLS_BOOL,
            "Put embedded builtins code into the code range for shorter "
            "builtin calls/jumps if system has >=4GB memory")
DEFINE_DEVELOPER_FLAG(trace_code_range_allocation,
                      "Trace code range allocation process.")

DEFINE_BOOL(better_code_range_allocation,
            V8_EXTERNAL_CODE_SPACE_BOOL&& COMPRESS_POINTERS_IN_SHARED_CAGE_BOOL,
            "This mode tries harder to allocate code range near .text section. "
            "Works only for configurations with external code space and "
            "shared pointer compression cage.")
DEFINE_BOOL(abort_on_far_code_range, false,
            "Abort if code range is allocated further away than 4GB from the"
            ".text section")

// runtime.cc
DEFINE_BOOL(runtime_call_stats, false, "report runtime call counts and times")
DEFINE_GENERIC_IMPLICATION(
    runtime_call_stats,
    TracingFlags::runtime_stats.store(
        v8::tracing::TracingCategoryObserver::ENABLED_BY_NATIVE))
DEFINE_BOOL(rcs, false, "report runtime call counts and times")
DEFINE_IMPLICATION(rcs, runtime_call_stats)

DEFINE_BOOL(rcs_cpu_time, false,
            "report runtime times in cpu time (the default is wall time)")
DEFINE_IMPLICATION(rcs_cpu_time, rcs)

// snapshot-common.cc
DEFINE_BOOL(verify_snapshot_checksum, DEBUG_BOOL,
            "Verify snapshot checksums when deserializing snapshots. Enable "
            "checksum creation and verification for code caches. Enabled by "
            "default in debug builds and once per process for Android.")
DEFINE_DEVELOPER_FLAG(profile_deserialization,
                      "Print the time it takes to deserialize the snapshot.")
DEFINE_DEVELOPER_FLAG(trace_deserialization,
                      "Trace the snapshot deserialization.")
DEFINE_DEVELOPER_FLAG(serialization_statistics,
                      "Collect statistics on serialized objects.")
// Regexp
DEFINE_BOOL(regexp_optimization, true, "generate optimized regexp code")
DEFINE_BOOL(regexp_unroll, true, "unroll small {} repeats when optimizing")
DEFINE_BOOL(regexp_masked_dispatch, true,
            "dispatch disjoint regexp alternations on the masked quick-check "
            "value")
DEFINE_BOOL(regexp_quick_check, true,
            "generate quickcheck code when optimizing")
DEFINE_BOOL(regexp_interpret_all, false, "interpret all regexp code")
#ifdef V8_TARGET_BIG_ENDIAN
#define REGEXP_PEEPHOLE_OPTIMIZATION_BOOL false
#else
#define REGEXP_PEEPHOLE_OPTIMIZATION_BOOL true
#endif
// The regexp engine runs in one of three modes. The default is single-tier:
// compile directly to native code on first use, expressed as tier-up with a
// zero-tick threshold so that regexp_tier_up_ticks stays a usable knob. A
// nonzero tick count selects the two-tier pipeline (interpret, then compile);
// regexp_interpret_all never compiles to native code (and is implied by
// jitless).
//
// regexp_jit_all is an explicit alias for the single-tier default. Its
// implications are strong on purpose: layering a second, conflicting mode on
// top of it (e.g. --regexp-jit-all --regexp-interpret-all) is then a flag
// contradiction rather than silently resolving to one of them.
DEFINE_BOOL(regexp_tier_up, true,
            "enable regexp interpreter and tier up to the compiler after the "
            "number of executions set by the tier up ticks flag")
DEFINE_NEG_IMPLICATION(regexp_interpret_all, regexp_tier_up)
DEFINE_SMI(regexp_tier_up_ticks, 0,
           "set the number of executions for the regexp interpreter before "
           "tiering-up to the compiler")
DEFINE_REQUIREMENT(v8_flags.regexp_tier_up_ticks >= 0)
DEFINE_BOOL(
    regexp_jit_all, false,
    "compile all regexp patterns directly to native code, skipping the "
    "interpreter (equivalent to --regexp-tier-up --regexp-tier-up-ticks=0, "
    "which is also the default)")
DEFINE_NEG_IMPLICATION(jitless, regexp_jit_all)
DEFINE_IMPLICATION(regexp_jit_all, regexp_tier_up)
// clang-format off
DEFINE_VALUE_IMPLICATION(regexp_jit_all, regexp_tier_up_ticks, 0)
// clang-format on
DEFINE_BOOL(regexp_peephole_optimization, REGEXP_PEEPHOLE_OPTIMIZATION_BOOL,
            "enable peephole optimization for regexp bytecode")
DEFINE_BOOL(regexp_results_cache, true, "enable the regexp results cache")
DEFINE_BOOL(regexp_assemble_from_bytecode, false,
            "assemble regexp JIT-code from bytecode")
DEFINE_NEG_NEG_IMPLICATION(regexp_tier_up, regexp_assemble_from_bytecode)
DEFINE_BOOL(regexp_simd_in_rc, true,
            "emit the SIMD scans directly in the regexp compiler, instead of "
            "via the bytecode peephole pass")
#ifdef ENABLE_DISASSEMBLER
DEFINE_DEVELOPER_FLAG(trace_regexp_peephole_optimization,
                      "trace regexp bytecode peephole optimization")
DEFINE_DEVELOPER_FLAG(trace_regexp_bytecodes, "trace regexp bytecode execution")
#else
DEFINE_BOOL_READONLY(trace_regexp_peephole_optimization, false,
                     "trace regexp bytecode peephole optimization (requires "
                     "v8_enable_disassembler = true)")
DEFINE_BOOL_READONLY(
    trace_regexp_bytecodes, false,
    "trace regexp bytecode execution (requires v8_enable_disassembler = true)")
#endif
#ifdef V8_ENABLE_REGEXP_DIAGNOSTICS
DEFINE_DEVELOPER_FLAG(trace_regexp_exec, "trace regexp execution")
DEFINE_DEVELOPER_FLAG(trace_regexp_exec_ool_subjects,
                      "trace regexp execution out-of-line subject strings")
DEFINE_DEVELOPER_FLAG(trace_regexp_assembler,
                      "trace regexp macro assembler calls.")
DEFINE_DEVELOPER_FLAG(trace_regexp_compiler, "trace regexp compilation")
DEFINE_DEVELOPER_FLAG(trace_regexp_graph_building,
                      "trace regexp AST to graph conversion")
DEFINE_DEVELOPER_FLAG(trace_regexp_parser, "trace regexp parsing")
DEFINE_DEVELOPER_FLAG(trace_regexp_graph, "trace the regexp graph")
DEFINE_DEVELOPER_FLAG(print_regexp_graph, "print the regexp graph")
DEFINE_DEVELOPER_FLAG(trace_regexp_tier_up, "trace regexp tiering up execution")
#else
DEFINE_BOOL_READONLY(trace_regexp_exec, false,
                     "trace regexp execution (requires "
                     "v8_enable_regexp_diagnostics = true).")
DEFINE_BOOL_READONLY(trace_regexp_exec_ool_subjects, false,
                     "trace regexp execution out-of-line subject strings "
                     "(requires v8_enable_regexp_diagnostics = true).")
DEFINE_BOOL_READONLY(trace_regexp_assembler, false,
                     "trace regexp macro assembler calls (requires "
                     "v8_enable_regexp_diagnostics = true).")
DEFINE_BOOL_READONLY(
    trace_regexp_compiler, false,
    "trace regexp compilation (requires v8_enable_regexp_diagnostics = true)")
DEFINE_BOOL_READONLY(trace_regexp_graph_building, false,
                     "trace regexp AST to graph conversion (requires "
                     "v8_enable_regexp_diagnostics = true)")
DEFINE_BOOL_READONLY(
    trace_regexp_parser, false,
    "trace regexp parsing (requires v8_enable_regexp_diagnostics = true)")
DEFINE_BOOL_READONLY(
    trace_regexp_graph, false,
    "trace the regexp graph (requires v8_enable_regexp_diagnostics = true)")
DEFINE_BOOL_READONLY(
    print_regexp_graph, false,
    "print the regexp graph (requires v8_enable_regexp_diagnostics = true)")
DEFINE_BOOL_READONLY(trace_regexp_tier_up, false,
                     "trace regexp tiering up execution (requires "
                     "v8_enable_regexp_diagnostics = true)")
#endif

DEFINE_EXPERIMENTAL_FEATURE(
    enable_experimental_regexp_engine,
    "recognize regexps with 'l' flag, run them on experimental engine")
DEFINE_BOOL(default_to_experimental_regexp_engine, false,
            "run regexps with the experimental engine where possible")
DEFINE_IMPLICATION(default_to_experimental_regexp_engine,
                   enable_experimental_regexp_engine)
DEFINE_BOOL(experimental_regexp_engine_capture_group_opt, false,
            "enable time optimizations for the experimental regexp engine")
DEFINE_IMPLICATION(experimental_regexp_engine_capture_group_opt,
                   enable_experimental_regexp_engine)
DEFINE_UINT64(experimental_regexp_engine_capture_group_opt_max_memory_usage,
              1024,
              "maximum memory usage in MB allowed for experimental engine")
DEFINE_DEVELOPER_FLAG(trace_experimental_regexp_engine,
                      "trace execution of experimental regexp engine")

DEFINE_EXPERIMENTAL_FEATURE(
    enable_experimental_regexp_engine_on_excessive_backtracks,
    "fall back to a breadth-first regexp engine on excessive "
    "backtracking")
DEFINE_POSITIVE_SMI(
    regexp_backtracks_before_fallback, 50000,
    "number of backtracks during regexp execution before fall back "
    "to experimental engine if "
    "enable_experimental_regexp_engine_on_excessive_backtracks is set")

#if V8_TARGET_ARCH_X64 || V8_TARGET_ARCH_ARM64 || V8_TARGET_ARCH_RISCV32 || \
    V8_TARGET_ARCH_RISCV64
DEFINE_BOOL(regexp_simd, true, "enable SIMD for regexp jit code")
#else
DEFINE_BOOL_READONLY(
    regexp_simd, false,
    "enable SIMD for regexp jit code (not supported for this architecture)")
#endif  // V8_TARGET_ARCH_X64 || V8_TARGET_ARCH_ARM64 || V8_TARGET_ARCH_RISCV32
        // || V8_TARGET_ARCH_RISCV64

DEFINE_DEVELOPER_FLAG(trace_read_only_promotion,
                      "trace the read-only promotion pass")
DEFINE_DEVELOPER_FLAG(trace_read_only_promotion_verbose,
                      "trace the read-only promotion pass")
DEFINE_WEAK_IMPLICATION(trace_read_only_promotion_verbose,
                        trace_read_only_promotion)

// Testing flags for flag-definitions-unittest.cc
DEFINE_BOOL(testing_bool_flag, true, "testing_bool_flag")
DEFINE_MAYBE_BOOL(testing_maybe_bool_flag, "testing_maybe_bool_flag")
DEFINE_INT(testing_int_flag, 13, "testing_int_flag")
DEFINE_FLOAT(testing_float_flag, 2.5, "float-flag")
DEFINE_STRING(testing_string_flag, "Hello, world!", "string-flag")
DEFINE_INT(testing_prng_seed, 42, "Seed used for threading test randomness")
// Testing flags for testing implicaton order in flag-definitions-unittest.cc
DEFINE_BOOL(testing_bool_flag_A, false, "testing_bool_flag_A")
DEFINE_BOOL(testing_bool_flag_B, true, "testing_bool_flag_B")
DEFINE_IMPLICATION(testing_bool_flag_B, testing_bool_flag_A)
DEFINE_BOOL(testing_bool_flag_C, false, "testing_bool_flag_C")
DEFINE_NEG_IMPLICATION(testing_bool_flag_C, testing_bool_flag_B)

DEFINE_EXPERIMENTAL_FEATURE(
    strict_termination_checks,
    "Enable strict terminating DCHECKs to prevent accidentally "
    "keeping on executing JS after terminating V8.")

// WARNING: Avoid adding implications to this flag unless they always make
// sense. Unnecessary implications reduce default configuration coverage and
// limit fuzzer exploration. Prefer flag randomization in fuzzer configs
// instead.
DEFINE_BOOL(
    fuzzing, false,
    "Fuzzers use this flag to signal that they are ... fuzzing. This causes "
    "intrinsics to fail silently (e.g. return undefined) on invalid usage.")

DEFINE_BOOL(
    hole_fuzzing, false,
    "Fuzzers use this flag to turn DCHECKs into NOPs  and CHECK failures into "
    "silent exits. This is useful if we want to find memory corruption "
    "primitives with a leaked hole, where the engine is already in a weird "
    "state")

//
// Sandbox-related flags.
//
#ifdef V8_ENABLE_SANDBOX_HARDWARE_SUPPORT
DEFINE_BOOL(
    strict_pkey_sandbox, true,
    "Enable strict pkey-based hardware sandboxing for the V8 Sandbox. When "
    "this is enabled, sandboxed code does not have write access to any "
    "out-of-sandbox memory, except for \"sandbox extension\" memory "
    "specifically marked as such. Under the hood, this works by removing write "
    "access to the default pkey (key zero) in sandboxed execution mode. This "
    "currently only works on x64 Linux and might require additional "
    "workarounds: `LD_BIND_NOW=1` to avoid lazy resolving of imported "
    "functions which would cause a write to out-of-sandbox memory (the GOT), "
    "`GLIBC_TUNABLES=glibc.pthread.rseq=0` to disable rseq which is "
    "incompatible with code running without write access to the default pkey "
    "(otherwise, the kernel will attempt to write to thread-local storage "
    "during context switches, which would segfault due to missing pkey "
    "permissions). NOTE: this is an experimental proot-of-concept feature and "
    "not meant for production use.")
#endif

#ifdef V8_ENABLE_SANDBOX
DEFINE_BOOL(sandbox_testing, false,
            "Enable sandbox testing mode. This exposes the memory corruption "
            "API (if available) and enables the sandbox crash filter to "
            "terminate the process (with status zero) if a crash that does not "
            "represent a sandbox violation is detected.")
#else
DEFINE_BOOL_READONLY(
    sandbox_testing, false,
    "Enable sandbox testing mode. This exposes the memory corruption API (if "
    "available) and enables the sandbox crash filter to terminate the process "
    "(with status zero) if a crash that does not represent a sandbox violation "
    "is detected.")
#endif

#ifdef V8_ENABLE_GENERATED_CODE_VALIDATOR
DEFINE_EXPERIMENTAL_FEATURE(validate_generated_code,
                            "Enable generated code verifier")
#else
DEFINE_BOOL_READONLY(validate_generated_code, false,
                     "Enable generated code verifier")
#endif
DEFINE_DEVELOPER_FLAG(validate_generated_code_include_code,
                      "Print the disassembled code as part of the generated "
                      "code validator's output in case of violations.")
DEFINE_DEVELOPER_FLAG(
    validate_generated_code_non_fatal,
    "Treat generated code validator violations as non-fatal. Can be "
    "used to find all issues rather than exiting after the first one.")

#ifdef V8_ENABLE_MEMORY_CORRUPTION_API
// Sandbox fuzzing mode requires the memory corruption API.
//
// WARNING: Avoid adding implications to this flag unless they always make
// sense. Unnecessary implications reduce default configuration coverage and
// limit fuzzer exploration. Prefer flag randomization in fuzzer configs
// instead.
DEFINE_BOOL(sandbox_fuzzing, false,
            "Enable sandbox fuzzing mode. This exposes the memory corruption "
            "API and enables the sandbox crash filter to terminate the process "
            "(with non-zero status) if a crash that does not represent a "
            "sandbox violation is detected.")
#else
DEFINE_BOOL_READONLY(sandbox_fuzzing, false,
                     "Enable sandbox fuzzing mode. This exposes the memory "
                     "corruption API and enables the sandbox crash filter to "
                     "terminate the process (with non-zero status) if a crash "
                     "that does not represent a sandbox violation is detected.")
#endif

DEFINE_BOOL(sandbox_trap_fuzzing, false,
            "Enable the trap-based sandbox fuzzing mode.")
DEFINE_IMPLICATION(sandbox_trap_fuzzing, sandbox_fuzzing)

DEFINE_IMPLICATION(sandbox_fuzzing, fuzzing)

// Only one of these can be enabled.
DEFINE_NEG_IMPLICATION(sandbox_fuzzing, sandbox_testing)
DEFINE_NEG_IMPLICATION(sandbox_testing, sandbox_fuzzing)

DEFINE_BOOL(verify_bytecode_light, false,
            "Perform lightweight bytecode verification to ensure basic safety "
            "properties of generated bytecode, mostly around control-flow.")
DEFINE_BOOL(verify_bytecode_full, DEBUG_BOOL,
            "Perform full bytecode verification to ensure generated bytecode "
            "is safe to execute when the sandbox is enabled (i.e. does not "
            "lead to out-of-sandbox memory corruption). Full verification is a "
            "strict superset of the lightweight verification.")

// Only one of the two flags should be active (but full verification includes
// light verification).
DEFINE_NEG_IMPLICATION(verify_bytecode_full, verify_bytecode_light)
DEFINE_NEG_IMPLICATION(verify_bytecode_light, verify_bytecode_full)

#ifdef V8_ENABLE_MEMORY_CORRUPTION_API
DEFINE_BOOL(expose_memory_corruption_api, false,
            "Exposes the memory corruption API. Set automatically by "
            "--sandbox-testing and --sandbox-fuzzing.")
DEFINE_IMPLICATION(sandbox_fuzzing, expose_memory_corruption_api)
DEFINE_IMPLICATION(sandbox_testing, expose_memory_corruption_api)
#else
DEFINE_BOOL_READONLY(expose_memory_corruption_api, false,
                     "Exposes the memory corruption API. Set automatically by "
                     "--sandbox-testing and --sandbox-fuzzing.")
#endif

DEFINE_BOOL(sandbox_prohibit_insecure_mode, false,
            "Prohibits an insecure sandbox setup.")

#if defined(V8_OS_AIX) && defined(COMPONENT_BUILD)
// FreezeFlags relies on mprotect() method, which does not work by default on
// shared mem: https://www.ibm.com/docs/en/aix/7.2?topic=m-mprotect-subroutine
DEFINE_BOOL(freeze_flags_after_init, false,
            "Disallow changes to flag values after initializing V8")
#else
DEFINE_BOOL(freeze_flags_after_init, true,
            "Disallow changes to flag values after initializing V8")
#endif  // defined(V8_OS_AIX) && defined(COMPONENT_BUILD)

#if V8_ENABLE_CET_SHADOW_STACK
#define V8_CET_SHADOW_STACK_BOOL true
#else
#define V8_CET_SHADOW_STACK_BOOL false
#endif

#if V8_TARGET_ARCH_X64
DEFINE_BOOL(cet_compatible, V8_CET_SHADOW_STACK_BOOL,
            "Generate Intel CET compatible code")
#else
DEFINE_BOOL_READONLY(cet_compatible, false,
                     "Intel CET is only supported on x64.")
#endif  // V8_TARGET_ARCH_X64

// mksnapshot.cc
DEFINE_STRING(embedded_src, nullptr,
              "Path for the generated embedded data file. (mksnapshot only)")
DEFINE_STRING(
    embedded_variant, nullptr,
    "Label to disambiguate symbols in embedded data file. (mksnapshot only)")
#if V8_STATIC_ROOTS_GENERATION_BOOL
DEFINE_STRING(static_roots_src, nullptr,
              "Path for writing a fresh static-roots.h. (mksnapshot only, "
              "build without static roots only)")
#endif
DEFINE_STRING(startup_src, nullptr,
              "Write V8 startup as C++ src. (mksnapshot only)")
DEFINE_STRING(startup_blob, nullptr,
              "Write V8 startup blob file. (mksnapshot only)")
DEFINE_STRING(target_arch, nullptr,
              "The mksnapshot target arch. (mksnapshot only)")
DEFINE_STRING(target_os, nullptr, "The mksnapshot target os. (mksnapshot only)")
DEFINE_BOOL(target_is_simulator, false,
            "Instruct mksnapshot that the target is meant to run in the "
            "simulator and it can generate simulator-specific instructions. "
            "(mksnapshot only)")
DEFINE_STRING(turbo_profiling_input, nullptr,
              "Path of the input file containing basic information for "
              "builtins. (mksnapshot only)")
DEFINE_STRING(turbo_log_builtins_count_input, nullptr,
              "Path of the input file containing basic block counters for "
              "builtins for logging in turbolizer. (mksnapshot only)")

// On some platforms, the .text section only has execute permissions.
DEFINE_BOOL(text_is_readable, true,
            "Whether the .text section of binary can be read")
DEFINE_NEG_NEG_IMPLICATION(text_is_readable, partial_constant_pool)

//
// Minor mark sweep collector flags.
//
DEFINE_DEVELOPER_FLAG(trace_minor_ms_parallel_marking,
                      "trace parallel marking for the young generation")
DEFINE_EXPERIMENTAL_FEATURE(minor_ms, "perform young generation mark sweep GCs")
DEFINE_IMPLICATION(minor_ms, page_promotion)

DEFINE_BOOL(concurrent_minor_ms_marking, true,
            "perform young generation marking concurrently")
DEFINE_NEG_NEG_IMPLICATION(concurrent_marking, concurrent_minor_ms_marking)

#ifdef V8_ENABLE_BLACK_ALLOCATED_PAGES
#define V8_ENABLE_BLACK_ALLOCATED_PAGES_BOOL true
#else
#define V8_ENABLE_BLACK_ALLOCATED_PAGES_BOOL false
#endif
DEFINE_BOOL_READONLY(
    black_allocated_pages, V8_ENABLE_BLACK_ALLOCATED_PAGES_BOOL,
    "allocate non-young objects during incremental marking on separate pages")

#ifdef V8_ENABLE_STICKY_MARK_BITS
#define V8_ENABLE_STICKY_MARK_BITS_BOOL true
#if V8_ENABLE_BLACK_ALLOCATED_PAGES_BOOL
#error "Black allocated pages are not supported with sticky mark bits"
#endif  // V8_ENABLE_BLACK_ALLOCATED_PAGES_BOOL
#else
#define V8_ENABLE_STICKY_MARK_BITS_BOOL false
#endif
DEFINE_BOOL_READONLY(sticky_mark_bits, V8_ENABLE_STICKY_MARK_BITS_BOOL,
                     "use sticky mark bits for separation of generations")
DEFINE_IMPLICATION(sticky_mark_bits, minor_ms)
// TODO(333906585): Copy mark bits and live bytes on compaction.
DEFINE_NEG_IMPLICATION(sticky_mark_bits, compact)

#ifndef DEBUG
#define V8_MINOR_MS_CONCURRENT_MARKING_MIN_CAPACITY_DEFAULT 8
#else
#define V8_MINOR_MS_CONCURRENT_MARKING_MIN_CAPACITY_DEFAULT 0
#endif

DEFINE_UINT(minor_ms_min_new_space_capacity_for_concurrent_marking_mb,
            V8_MINOR_MS_CONCURRENT_MARKING_MIN_CAPACITY_DEFAULT,
            "min new space capacity in MBs for using young generation "
            "concurrent marking.")

DEFINE_UINT(minor_ms_concurrent_marking_trigger, 90,
            "minor ms concurrent marking trigger in percent of the current new "
            "space capacity")

DEFINE_SIZE_T(minor_ms_min_lab_size_kb, 0,
              "override for the minimum lab size in KB to be used for new "
              "space allocations with minor ms. ")

DEFINE_BOOL(
    handle_weak_ref_weakly_in_minor_gc, true,
    "Enables weak handling of WeakRef and FinalizationRegistry in minor GCs.")
DEFINE_NEG_IMPLICATION(minor_ms, handle_weak_ref_weakly_in_minor_gc)
DEFINE_NEG_IMPLICATION(scavenger_precise_object_pinning,
                       handle_weak_ref_weakly_in_minor_gc)
DEFINE_NEG_IMPLICATION(scavenger_conservative_object_pinning,
                       handle_weak_ref_weakly_in_minor_gc)

//
// Dev shell flags
//

DEFINE_BOOL(help, false, "Print usage message, including flags, on console")
DEFINE_BOOL(print_flag_values, false, "Print all flag values of V8")
DEFINE_BOOL(print_feature_flags_json, false,
            "Print JS and Wasm feature flags grouped by in-progress, staged, "
            "and shipped")

// Slow histograms are also enabled via --dump-counters in d8.
DEFINE_BOOL(slow_histograms, false,
            "Enable slow histograms with more overhead.")

DEFINE_BOOL(use_external_strings, false, "Use external strings for source code")
DEFINE_STRING(map_counters, "", "Map counters to a file")
DEFINE_TEST_ONLY_FLAG(mock_arraybuffer_allocator,
                      "Use a mock ArrayBuffer allocator for testing.")
DEFINE_SIZE_T(mock_arraybuffer_allocator_limit, 0,
              "Memory limit for mock ArrayBuffer allocator used to simulate "
              "OOM for testing.")
#ifdef V8_OS_LINUX
DEFINE_BOOL(multi_mapped_mock_allocator, false,
            "Use a multi-mapped mock ArrayBuffer allocator for testing.")
#endif

//
// GDB JIT integration flags.
//
#undef FLAG
#ifdef ENABLE_GDB_JIT_INTERFACE
#define FLAG FLAG_FULL
#else
#define FLAG FLAG_READONLY
#endif

DEFINE_BOOL(gdbjit, false, "enable GDBJIT interface")
DEFINE_BOOL(gdbjit_full, false, "enable GDBJIT interface for all code objects")
DEFINE_BOOL(gdbjit_dump, false, "dump elf objects with debug info to disk")
#ifdef ENABLE_GDB_JIT_INTERFACE
DEFINE_BOOL(maglev_gdbjit, false, "enable GDBJIT line info for Maglev graph")
#endif
DEFINE_BOOL(torque_dwarf, false, "enable DWARF line info for Torque files")
DEFINE_STRING(gdbjit_dump_filter, "",
              "dump only objects containing this substring")

#ifdef ENABLE_GDB_JIT_INTERFACE
DEFINE_IMPLICATION(gdbjit_full, gdbjit)
DEFINE_IMPLICATION(gdbjit_dump, gdbjit)
DEFINE_WEAK_IMPLICATION(gdbjit, gdbjit_full)
DEFINE_IMPLICATION(maglev_gdbjit, gdbjit)
DEFINE_WEAK_IMPLICATION(gdbjit, maglev_gdbjit)
#endif
DEFINE_NEG_IMPLICATION(gdbjit, compact_code_space)

//
// Debug only flags
//
#undef FLAG
#ifdef DEBUG
#define FLAG FLAG_FULL
#else
#define FLAG FLAG_READONLY
#endif

#ifdef ENABLE_SLOW_DCHECKS
DEFINE_BOOL(enable_slow_asserts, true,
            "enable asserts that are slow to execute")
#else
DEFINE_BOOL_READONLY(enable_slow_asserts, false,
                     "enable asserts that are slow to execute")
#endif

// codegen-ia32.cc / codegen-arm.cc / macro-assembler-*.cc
DEFINE_DEVELOPER_FLAG(print_ast, "print source AST")

// compiler.cc
DEFINE_DEVELOPER_FLAG(print_scopes, "print scopes")

// contexts.cc
DEFINE_DEVELOPER_FLAG(trace_contexts, "trace contexts operations")

// heap.cc
DEFINE_DEVELOPER_FLAG(code_stats, "report code statistics after GC")
DEFINE_DEVELOPER_FLAG(print_handles, "report handles after GC")
DEFINE_BOOL(check_handle_count, false,
            "Check that there are not too many handles at GC")
DEFINE_DEVELOPER_FLAG(print_global_handles, "report global handles after GC")

// TurboFan debug-only flags.
DEFINE_DEVELOPER_FLAG(trace_turbo_escape, "enable tracing in escape analysis")

// objects.cc
DEFINE_DEVELOPER_FLAG(trace_module_status,
                      "Trace status transitions of ECMAScript modules")
DEFINE_DEVELOPER_FLAG(trace_normalization,
                      "prints when objects are turned into dictionaries.")

// runtime.cc
DEFINE_DEVELOPER_FLAG(trace_lazy, "trace lazy compilation")

// spaces.cc
DEFINE_DEVELOPER_FLAG(trace_isolates, "trace isolate state changes")

// Regexp
DEFINE_BOOL(regexp_possessive_quantifier, false,
            "enable possessive quantifier syntax for testing")

// Debugger
DEFINE_DEVELOPER_FLAG(print_break_location,
                      "print source location on debug break")

//
// Logging and profiling flags
//
// Logging flag dependencies are also set separately in
// V8::InitializeOncePerProcessImpl. Please add your flag to the log_all_flags
// list in v8.cc to properly set v8_flags.log and automatically enable it with
// --log-all.
#undef FLAG
#define FLAG FLAG_FULL

// log.cc
DEFINE_STRING(logfile, "v8.log",
              "Specify the name of the log file, use '-' for console, '+' for "
              "a temporary file.")
DEFINE_BOOL(logfile_per_isolate, true, "Separate log files for each isolate.")

DEFINE_BOOL(log, false,
            "Minimal logging (no API, code, GC, suspect, or handles samples).")
DEFINE_BOOL(log_all, false, "Log all events to the log file.")

DEFINE_BOOL(log_internal_timer_events, false, "See --log-timer-events")
DEFINE_BOOL(log_timer_events, false,
            "Log timer events (incl. console.time* and Date.now).")

DEFINE_BOOL(log_source_code, false, "Log source code.")
DEFINE_BOOL(log_source_position, false, "Log detailed source information.")
DEFINE_BOOL(log_code, false,
            "Log code events to the log file without profiling.")
DEFINE_WEAK_IMPLICATION(log_code, log_source_code)
DEFINE_WEAK_IMPLICATION(log_code, log_source_position)
DEFINE_BOOL(log_feedback_vector, false, "Log FeedbackVectors on first creation")
DEFINE_BOOL(log_code_disassemble, false,
            "Log all disassembled code to the log file.")
DEFINE_IMPLICATION(log_code_disassemble, log_code)
DEFINE_BOOL(log_function_events, false,
            "Log function events "
            "(parse, compile, execute) separately.")

DEFINE_BOOL(detailed_line_info, false,
            "Always generate detailed line information for CPU profiling.")

DEFINE_BOOL(prof_include_idle, false, "Include idle samples in the profile")

#if defined(V8_USE_PERFETTO)
DEFINE_BOOL(perfetto_code_logger, false,
            "Enable the Perfetto code data source.")
#else
DEFINE_BOOL_READONLY(perfetto_code_logger, false,
                     "Enable the Perfetto code data source (requires the "
                     "v8_use_perfetto gn arg)")
#endif

#if defined(ANDROID)
// Phones and tablets have processors that are much slower than desktop
// and laptop computers for which current heuristics are tuned.
#define DEFAULT_PROF_SAMPLING_INTERVAL 5000
#else
#define DEFAULT_PROF_SAMPLING_INTERVAL 1000
#endif
DEFINE_INT(prof_sampling_interval, DEFAULT_PROF_SAMPLING_INTERVAL,
           "Interval for --prof samples (in microseconds).")
#undef DEFAULT_PROF_SAMPLING_INTERVAL

DEFINE_BOOL(prof_cpp, false, "Like --prof, but ignore generated code.")
DEFINE_BOOL(prof_browser_mode, true,
            "Used with --prof, turns on browser-compatible mode for profiling.")

DEFINE_BOOL(prof, false,
            "Log statistical profiling information (implies --log-code).")
DEFINE_IMPLICATION(prof, prof_cpp)
DEFINE_IMPLICATION(prof, log_code)

// Enable low-level linux profiler.
// When active, V8 will log code events (like code creation and code moving)
// to v8.log and will signal code-moving GC events to synchronize system-level
// profilers (like Linux perf) with V8's heap relocations via fake mmaps.
DEFINE_DEVELOPER_FLAG(ll_prof, "Enable low-level linux profiler.")

#if V8_OS_LINUX || V8_OS_DARWIN
#define DEFINE_PERF_PROF_BOOL(nam, cmt) DEFINE_DEVELOPER_FLAG(nam, cmt)
#define DEFINE_PERF_PROF_IMPLICATION DEFINE_IMPLICATION
#else
#define DEFINE_PERF_PROF_BOOL(nam, cmt) DEFINE_BOOL_READONLY(nam, false, cmt)
#define DEFINE_PERF_PROF_IMPLICATION(...)
#endif

#if defined(ANDROID)
#define DEFAULT_PERF_BASIC_PROF_PATH "/data/local/tmp"
#define DEFAULT_PERF_PROF_PATH DEFAULT_PERF_BASIC_PROF_PATH
#else
#define DEFAULT_PERF_BASIC_PROF_PATH "/tmp"
#define DEFAULT_PERF_PROF_PATH "."
#endif

DEFINE_PERF_PROF_BOOL(perf_basic_prof,
                      "Enable basic support for perf profiler.")
DEFINE_NEG_IMPLICATION(perf_basic_prof, compact_code_space)
DEFINE_STRING(perf_basic_prof_path, DEFAULT_PERF_BASIC_PROF_PATH,
              "directory to write perf-<pid>.map symbol file to")
DEFINE_PERF_PROF_BOOL(
    perf_basic_prof_only_functions,
    "Only report function code ranges to perf (i.e. no stubs).")
DEFINE_PERF_PROF_IMPLICATION(perf_basic_prof_only_functions, perf_basic_prof)

DEFINE_PERF_PROF_BOOL(perf_prof,
                      "Enable experimental annotate support for perf profiler.")
DEFINE_STRING(perf_prof_path, DEFAULT_PERF_PROF_PATH,
              "directory to write jit-<pid>.dump symbol file to")
DEFINE_PERF_PROF_BOOL(
    perf_prof_annotate_wasm,
    "Used with --perf-prof, load wasm source map and provide annotate "
    "support (experimental).")
DEFINE_PERF_PROF_BOOL(
    perf_prof_delete_file,
    "Remove the perf file right after creating it (for testing only).")
DEFINE_NEG_IMPLICATION(perf_prof, compact_code_space)

// --perf-prof-unwinding-info is available only on selected architectures.
#if V8_TARGET_ARCH_ARM || V8_TARGET_ARCH_ARM64 || V8_TARGET_ARCH_X64 || \
    V8_TARGET_ARCH_S390X || V8_TARGET_ARCH_PPC64
DEFINE_PERF_PROF_BOOL(
    perf_prof_unwinding_info,
    "Enable unwinding info for perf linux profiler (experimental).")
DEFINE_PERF_PROF_IMPLICATION(perf_prof, perf_prof_unwinding_info)
#else
DEFINE_BOOL_READONLY(
    perf_prof_unwinding_info, false,
    "Enable unwinding info for perf linux profiler (experimental).")
#endif

#undef DEFINE_PERF_PROF_BOOL
#undef DEFINE_PERF_PROF_IMPLICATION

// Specify the name of the file for fake gc mmap used in ll_prof.
// V8 will perform a temporary mmap/munmap on this file during a code-moving GC
// event, which injects a marker into the system-level profiler (e.g. perf)
// stream to align/synchronize V8 code log timestamps with the system trace.
DEFINE_STRING(gc_fake_mmap, "/tmp/__v8_gc__",
              "Specify the name of the file for fake gc mmap used in ll_prof")

DEFINE_BOOL(redirect_code_traces, false,
            "output deopt information and disassembly into file "
            "code-<pid>-<isolate id>.asm")
DEFINE_STRING(redirect_code_traces_to, nullptr,
              "output deopt information and disassembly into the given file")

DEFINE_DEVELOPER_FLAG(print_opt_source,
                      "print source code of optimized and inlined functions")

DEFINE_BOOL(vtune_prof_annotate_wasm, false,
            "Used when v8_enable_vtunejit is enabled, load wasm source map and "
            "provide annotate support (experimental).")

DEFINE_BOOL(win64_unwinding_info, true, "Enable unwinding info for Windows/x64")

DEFINE_BOOL(interpreted_frames_native_stack, false,
            "Show interpreted frames on the native stack (useful for external "
            "profilers).")

#if defined(V8_ENABLE_ETW_STACK_WALKING)
DEFINE_BOOL(enable_etw_stack_walking, false,
            "Enable etw stack walking for windows")
DEFINE_WEAK_IMPLICATION(future, enable_etw_stack_walking)
DEFINE_BOOL(etw_trace_debug, false,
            "Enable etw debug logging (only on debug builds)")
DEFINE_BOOL(enable_etw_by_custom_filter_only, true,
            "Enable etw stack walking for windows, but only if explicitly "
            "specified in a WPR profile")
#else   // V8_ENABLE_ETW_STACK_WALKING
DEFINE_BOOL_READONLY(enable_etw_stack_walking, false,
                     "Enable etw stack walking for windows")
DEFINE_BOOL_READONLY(etw_trace_debug, false,
                     "Enable etw debug logging (only on debug builds)")
DEFINE_BOOL_READONLY(
    enable_etw_by_custom_filter_only, false,
    "Enable etw stack walking for windows, but only if explicitly "
    "specified in a WPR profile")
#endif  // V8_ENABLE_ETW_STACK_WALKING

DEFINE_BOOL(print_builtin_size, false, "print code size for builtins")

//
// Disassembler only flags
//
#undef FLAG
#ifdef ENABLE_DISASSEMBLER
#define FLAG FLAG_FULL
#else
#define FLAG FLAG_READONLY
#endif

// elements.cc
DEFINE_DEVELOPER_FLAG(trace_elements_transitions, "trace elements transitions")

DEFINE_DEVELOPER_FLAG(trace_creation_allocation_sites,
                      "trace the creation of allocation sites")

DEFINE_DEVELOPER_FLAG(print_code, "print generated code")
DEFINE_DEVELOPER_FLAG(print_opt_code, "print optimized code")
DEFINE_STRING(print_opt_code_filter, "*", "filter for printing optimized code")
DEFINE_DEVELOPER_FLAG(print_code_verbose, "print more information for code")
DEFINE_DEVELOPER_FLAG(print_builtin_code, "print generated code for builtins")
DEFINE_STRING(print_builtin_code_filter, "*",
              "filter for printing builtin code")
DEFINE_DEVELOPER_FLAG(print_regexp_code, "print generated regexp code")
DEFINE_DEVELOPER_FLAG(print_regexp_bytecode, "print generated regexp bytecode")

#ifdef ENABLE_DISASSEMBLER
DEFINE_DEVELOPER_FLAG(print_all_code,
                      "enable all flags related to printing code")
DEFINE_IMPLICATION(print_all_code, print_code)
DEFINE_IMPLICATION(print_all_code, print_opt_code)
DEFINE_IMPLICATION(print_all_code, print_code_verbose)
DEFINE_IMPLICATION(print_all_code, print_builtin_code)
DEFINE_IMPLICATION(print_all_code, print_regexp_code)
#endif

#undef FLAG
#define FLAG FLAG_FULL

//
// Predictable mode related flags.
//

DEFINE_BOOL(predictable, false, "enable predictable mode")
DEFINE_NEG_IMPLICATION(predictable, memory_reducer)
// TODO(v8:11848): These flags were recursively implied via --single-threaded
// before. Audit them, and remove any unneeded implications.
DEFINE_IMPLICATION(predictable, single_threaded_gc)
DEFINE_NEG_IMPLICATION(predictable, concurrent_recompilation)
DEFINE_NEG_IMPLICATION(predictable, stress_concurrent_inlining)
DEFINE_NEG_IMPLICATION(predictable, lazy_compile_dispatcher)
DEFINE_NEG_IMPLICATION(predictable, parallel_compile_tasks_for_eager_toplevel)
DEFINE_NEG_IMPLICATION(predictable, parallel_compile_tasks_for_lazy)
#ifdef V8_ENABLE_MAGLEV
DEFINE_NEG_IMPLICATION(predictable, maglev_deopt_data_on_background)
DEFINE_NEG_IMPLICATION(predictable, maglev_build_code_on_background)
DEFINE_NEG_IMPLICATION(predictable, maglev_destroy_on_background)
#endif  // V8_ENABLE_MAGLEV
DEFINE_NEG_IMPLICATION(predictable, concurrent_cache_deserialization)
#if V8_ENABLE_WEBASSEMBLY
DEFINE_NEG_IMPLICATION(predictable, wasm_test_streaming)
#endif  // V8_ENABLE_WEBASSEMBLY
// Avoid random seeds in predictable mode.
DEFINE_VALUE_IMPLICATION(predictable && random_seed == 0, random_seed, 12347)

DEFINE_BOOL(predictable_gc_schedule, false,
            "Predictable garbage collection schedule. Fixes heap growing, "
            "idle, and memory reducing behavior.")
DEFINE_VALUE_IMPLICATION(predictable_gc_schedule, min_semi_space_size,
                         size_t{4})
DEFINE_VALUE_IMPLICATION(predictable_gc_schedule, max_semi_space_size,
                         size_t{4})
DEFINE_VALUE_IMPLICATION(predictable_gc_schedule, heap_growing_percent, 30)
DEFINE_NEG_IMPLICATION(predictable_gc_schedule, memory_reducer)

//
// Threading related flags.
//

DEFINE_BOOL(single_threaded, false, "disable the use of background tasks")
DEFINE_IMPLICATION(single_threaded, single_threaded_gc)
DEFINE_NEG_IMPLICATION(single_threaded, concurrent_recompilation)
DEFINE_NEG_IMPLICATION(single_threaded, concurrent_builtin_generation)
DEFINE_NEG_IMPLICATION(single_threaded, stress_concurrent_inlining)
DEFINE_NEG_IMPLICATION(single_threaded, lazy_compile_dispatcher)
DEFINE_NEG_IMPLICATION(single_threaded,
                       parallel_compile_tasks_for_eager_toplevel)
DEFINE_NEG_IMPLICATION(single_threaded, parallel_compile_tasks_for_lazy)
#ifdef V8_ENABLE_MAGLEV
DEFINE_NEG_IMPLICATION(single_threaded, maglev_deopt_data_on_background)
DEFINE_NEG_IMPLICATION(single_threaded, maglev_build_code_on_background)
#endif  // V8_ENABLE_MAGLEV

//
// Parallel and concurrent GC (Orinoco) related flags.
//
DEFINE_BOOL(single_threaded_gc, false, "disable the use of background gc tasks")
DEFINE_NEG_IMPLICATION(single_threaded_gc, concurrent_marking)
DEFINE_NEG_IMPLICATION(single_threaded_gc, concurrent_sweeping)
DEFINE_NEG_IMPLICATION(single_threaded_gc, parallel_compaction)
DEFINE_NEG_IMPLICATION(single_threaded_gc, parallel_marking)
DEFINE_NEG_IMPLICATION(single_threaded_gc, parallel_pointer_update)
DEFINE_NEG_IMPLICATION(single_threaded_gc, parallel_gc_clearing)
DEFINE_NEG_IMPLICATION(single_threaded_gc, parallel_scavenge)
DEFINE_NEG_IMPLICATION(single_threaded_gc, concurrent_array_buffer_sweeping)
DEFINE_NEG_IMPLICATION(single_threaded_gc, stress_concurrent_allocation)
DEFINE_NEG_IMPLICATION(single_threaded_gc, cppheap_concurrent_marking)

DEFINE_BOOL(single_threaded_gc_in_background, true,
            "disable the use of background gc tasks when in background")
DEFINE_BOOL(parallel_pause_for_gc_in_background, true,
            "Use parallel threads in the atomic pause for background GCs")
DEFINE_BOOL(incremental_marking_for_gc_in_background, true,
            "Use parallel threads in the atomic pause for background GCs")

#if V8_CAN_CREATE_SHARED_HEAP_BOOL
DEFINE_EXPERIMENTAL_FEATURE(shared_heap,
                            "Enables a shared heap between isolates.")
DEFINE_BOOL(empty_shared_heap, false,
            "Enables a shared heap, but not shared allocations")
DEFINE_IMPLICATION(empty_shared_heap, shared_heap)
DEFINE_NEG_IMPLICATION(empty_shared_heap, shared_string_table)
#else
DEFINE_BOOL_READONLY(shared_heap, false,
                     "Enables a shared heap between isolates.")
DEFINE_BOOL_READONLY(empty_shared_heap, false,
                     "Enables a shared heap, but not shared allocations")
#endif

DEFINE_BOOL(proto_assign_seq_opt, true,
            "Enable optimizing a sequence of `Class_X.prototype.[key] = ...`"
            "by replacing it by a runtime code somewhat equivalent to "
            "`Object.assign(Class_X.prototype, [boilerplate_obj])`")
DEFINE_WEAK_IMPLICATION(future, proto_assign_seq_opt)

DEFINE_UINT(proto_assign_seq_opt_count, 2,
            "The minimum number of consecutive property assignments on the "
            "prototype object for replacing it with a single byte code")
DEFINE_NEG_IMPLICATION(proto_assign_seq_opt_count == 0, proto_assign_seq_opt)

DEFINE_EXPERIMENTAL_FEATURE(
    proto_assign_seq_lazy_func_opt,
    "Functions bulk assigned to prototype via SetPrototypeProperties "
    "will remain in SharedFunctionInfo (Rather than JSFunction) State "
    "until first access")
DEFINE_WEAK_IMPLICATION(experimental_fuzzing, proto_assign_seq_lazy_func_opt)
DEFINE_IMPLICATION(proto_assign_seq_lazy_func_opt, proto_assign_seq_opt)

DEFINE_EXPERIMENTAL_FEATURE(
    private_field_bytecodes,
    "Use specialized bytecodes for Get/Set Private Fields")

DEFINE_BOOL(track_array_buffer_views, true,
            "Track TypedArrays and DataViews attached to array buffers and "
            "update them in-place when the buffer detaches")

DEFINE_EXPERIMENTAL_FEATURE(
    superspreading,
    "Allow arbitrary length spread arguments on supported builtins")

DEFINE_BOOL(fast_proxy_ic, false, "Support proxy traps in ICs")
DEFINE_WEAK_IMPLICATION(future, fast_proxy_ic)

DEFINE_BOOL(is_standalone_d8_shell, false,
            "Tells V8 it's running as part of the d8. This flag should not be "
            "set in other cases.")
DEFINE_WEAK_NEG_IMPLICATION(is_standalone_d8_shell, logfile_per_isolate)
DEFINE_WEAK_VALUE_IMPLICATION(is_standalone_d8_shell, trace_turbo_cfg_file,
                              "turbo.cfg")
DEFINE_WEAK_VALUE_IMPLICATION(is_standalone_d8_shell, redirect_code_traces_to,
                              "code.asm")

// The --disallow-unsafe-flags is meant to block known unsafe configurations and
// mitigate spurious reports due invalid flag combinations/values. To prevent AI
// agents and/or fuzzers from using a new unsafe flag, add an implication from
// --disallow-unsafe-flags below.
// TODO(crbug.com/452607988): Enable on fuzzers and merge the
// --disallow-unsafe-flags with
// --test-only-unsafe once the list of flags below is stable.
DEFINE_BOOL(disallow_unsafe_flags, false,
            "Prevents the use of flags that are considered unsafe. Setting "
            "this flag will make V8 treat the unsafe flags below as flag "
            "contradiction and either crash or exit gracefully with a message "
            "(depending on the curreny AbortMode)")
// --disallow-unsafe-flags is intended to only be used with --fuzzing.
DEFINE_IMPLICATION(disallow_unsafe_flags, fuzzing)
// Profiling flags.
DEFINE_NEG_IMPLICATION(disallow_unsafe_flags, turbo_profiling)
DEFINE_NEG_IMPLICATION(disallow_unsafe_flags, turbo_profiling_verbose)
DEFINE_NEG_IMPLICATION(disallow_unsafe_flags, perf_prof)
DEFINE_NEG_IMPLICATION(disallow_unsafe_flags, perf_prof_annotate_wasm)
DEFINE_NEG_IMPLICATION(disallow_unsafe_flags, perf_prof_delete_file)
DEFINE_NEG_IMPLICATION(disallow_unsafe_flags, perf_prof_unwinding_info)
// Experimental PGO/compilation-hints-generation flags.
#if V8_ENABLE_WEBASSEMBLY
DEFINE_NEG_IMPLICATION(disallow_unsafe_flags, wasm_pgo_to_file)
DEFINE_NEG_IMPLICATION(disallow_unsafe_flags, wasm_pgo_from_file)
DEFINE_NEG_IMPLICATION(disallow_unsafe_flags, wasm_generate_compilation_hints)
DEFINE_NEG_IMPLICATION(disallow_unsafe_flags,
                       trace_wasm_generate_compilation_hints)
#endif  // V8_ENABLE_WEBASSEMBLY
// Known-broken features/configuration.
DEFINE_NEG_IMPLICATION(disallow_unsafe_flags, feedback_normalization)
DEFINE_NEG_IMPLICATION(disallow_unsafe_flags, harmony_struct)
DEFINE_IMPLICATION(disallow_unsafe_flags, script_context_cells)
// Disabled-by-default misc. "unsafe" flags that should not be enabled.
DEFINE_NEG_IMPLICATION(disallow_unsafe_flags, mock_arraybuffer_allocator)
DEFINE_NEG_IMPLICATION(disallow_unsafe_flags, abort_on_bad_builtin_profile_data)
DEFINE_NEG_IMPLICATION(disallow_unsafe_flags, abort_on_uncaught_exception)
DEFINE_NEG_IMPLICATION(disallow_unsafe_flags, abort_on_far_code_range)
DEFINE_NEG_IMPLICATION(disallow_unsafe_flags, correctness_fuzzer_suppressions)
DEFINE_NEG_IMPLICATION(disallow_unsafe_flags, force_memory_protection_keys)
DEFINE_NEG_IMPLICATION(disallow_unsafe_flags, expose_trigger_failure)
DEFINE_NEG_IMPLICATION(disallow_unsafe_flags, redirect_code_traces)
#if V8_ENABLE_WEBASSEMBLY
#if V8_ENABLE_DRUMBRAKE_TRACING
DEFINE_NEG_IMPLICATION(disallow_unsafe_flags, redirect_drumbrake_traces)
#endif  // V8_ENABLE_DRUMBRAKE_TRACING
DEFINE_NEG_IMPLICATION(disallow_unsafe_flags, wasm_assume_ref_cast_succeeds)
DEFINE_NEG_IMPLICATION(disallow_unsafe_flags, wasm_skip_null_checks)
DEFINE_NEG_IMPLICATION(disallow_unsafe_flags, wasm_ref_cast_nop)
DEFINE_NEG_IMPLICATION(disallow_unsafe_flags, wasm_skip_bounds_checks)
DEFINE_NEG_IMPLICATION(disallow_unsafe_flags, wasm_unsafe_fast_api_wrapper)
// Enabled-by-default flags that should not be disabled.
DEFINE_IMPLICATION(disallow_unsafe_flags, wasm_bounds_checks)
DEFINE_IMPLICATION(disallow_unsafe_flags, wasm_stack_checks)
// Flags that are unsafe if given unexpected invalid values.
DEFINE_NOT_EXPLICITLY_SET_IMPLICATION(disallow_unsafe_flags, max_wasm_functions)
DEFINE_NOT_EXPLICITLY_SET_IMPLICATION(disallow_unsafe_flags,
                                      wasm_max_initial_code_space_reservation)
DEFINE_NOT_EXPLICITLY_SET_IMPLICATION(disallow_unsafe_flags,
                                      wasm_wrapper_tiering_budget)
DEFINE_NOT_EXPLICITLY_SET_IMPLICATION(disallow_unsafe_flags,
                                      wasm_eager_tier_up_function)
#endif  // V8_ENABLE_WEBASSEMBLY
// Disabling CPU features can lead to DCHECK failures.
DEFINE_IMPLICATION(disallow_unsafe_flags, enable_avx)
DEFINE_IMPLICATION(disallow_unsafe_flags, enable_sse3)
DEFINE_IMPLICATION(disallow_unsafe_flags, enable_sse4_1)
DEFINE_IMPLICATION(disallow_unsafe_flags, enable_sse4_2)
// Features we don't currently want to fuzz.
DEFINE_NEG_IMPLICATION(disallow_unsafe_flags, cppgc_young_generation)
DEFINE_NEG_IMPLICATION(disallow_unsafe_flags, test_only_unsafe)
// The memory corruption API is only allowed in sandbox testing/fuzzing mode.
DEFINE_NOT_EXPLICITLY_SET_IMPLICATION(disallow_unsafe_flags &&
                                          !sandbox_testing && !sandbox_fuzzing,
                                      expose_memory_corruption_api)

// Flags which trigger a breakpoint on purpose.
DEFINE_NEG_IMPLICATION(disallow_unsafe_flags, maglev_break_on_entry)
#ifdef USE_SIMULATOR
DEFINE_NOT_EXPLICITLY_SET_IMPLICATION(disallow_unsafe_flags, stop_sim_at)
#endif
DEFINE_NOT_EXPLICITLY_SET_IMPLICATION(disallow_unsafe_flags, gc_fake_mmap)
// Non-standard stack sizes can lead to stack overflows (signaled as segfaults)
// and produce spurious bug reports. V8 should handle stack overflows gracefully
// in default configurations.
DEFINE_NOT_EXPLICITLY_SET_IMPLICATION(disallow_unsafe_flags, stack_size)

// Runs a program as security POC. This mode is used to determine whether a bug
// in a program is a security problem. V8 supports many different configurations
// and modes that are sometimes incomplete or incompatible. The flag aims at
// providing guidance on what is actually considered a security issue. The flag
// must be passed as first argument.
//
// Note: The mode may be insufficient and/or incomplete. Passing this flag does
// not guarantee a bug will be classified as a valid vulnerability. The V8 team
// reserves the right to make the final determination on security impact during
// triage. See docs/security/triaging.md.
DEFINE_BOOL(run_as_security_poc, false,
            "Run programs as security proof of concept (POC).")
// Unsafe flags generally lead to unsupported configurations.
DEFINE_IMPLICATION(run_as_security_poc, disallow_unsafe_flags)
// Developer-only flags are not used in production. These flags should be robust
// but breakage is not generally a security issue.
DEFINE_IMPLICATION(run_as_security_poc, disallow_developer_only_features)
// TODO(495388612): Possibly split fuzzing flag to avoid auto-enabling some
// stress modes.
DEFINE_IMPLICATION(run_as_security_poc, fuzzing)
// Experimental features are not ready for broad usage yet. Bugs in these areas
// are not considered security issues.
DEFINE_NEG_IMPLICATION(run_as_security_poc, experimental)

// Runs a program as sandbox security POC. This mode is used to determine
// whether a bug in a program can lead to a sandbox violation. The mode enables
// the memory corruption APIs and as such allows to directly modify untrusted V8
// heap contents. V8 supports many different configurations and modes that are
// sometimes incomplete or incompatible. The flag aims at providing guidance on
// what is actually considered a security issue. The flag must be passed as
// first argument.
//
// Note: The mode may be insufficient and/or incomplete. Passing this flag does
// not guarantee a bug will be classified as a valid vulnerability. The V8 team
// reserves the right to make the final determination on security impact during
// triage. See docs/security/triaging.md.
DEFINE_BOOL(
    run_as_sandbox_security_poc, false,
    "Run programs as security proof of concept (POC) for the V8 sandbox")
// Use the same configuration as `--run-as-security-poc`.
DEFINE_IMPLICATION(run_as_sandbox_security_poc, run_as_security_poc)
// Enable sandbox test mode which allows for using memory corruption APIs and
// also installs the crash filter that determines whether issues are crashing
// inside or outside of the sandbox.
DEFINE_IMPLICATION(run_as_sandbox_security_poc, sandbox_testing)

#undef FLAG

#ifdef VERIFY_PREDICTABLE
#define FLAG FLAG_FULL
#else
#define FLAG FLAG_READONLY
#endif

DEFINE_BOOL(verify_predictable, false,
            "this mode is used for checking that V8 behaves predictably")
DEFINE_IMPLICATION(verify_predictable, predictable)
DEFINE_INT(dump_allocations_digest_at_alloc, -1,
           "dump allocations digest each n-th allocation")

#define LOG_FLAGS(V)      \
  V(log_code)             \
  V(log_code_disassemble) \
  V(log_deopt)            \
  V(log_feedback_vector)  \
  V(log_function_events)  \
  V(log_ic)               \
  V(log_maps)             \
  V(log_source_code)      \
  V(log_source_position)  \
  V(log_timer_events)     \
  V(prof)                 \
  V(prof_cpp)

#define SET_IMPLICATIONS(V)      \
  DEFINE_IMPLICATION(log_all, V) \
  DEFINE_IMPLICATION(V, log)

LOG_FLAGS(SET_IMPLICATIONS)

#undef SET_IMPLICATIONS
#undef LOG_FLAGS

DEFINE_IMPLICATION(log_all, log)
DEFINE_IMPLICATION(perf_prof, log)
DEFINE_IMPLICATION(perf_basic_prof, log)
DEFINE_IMPLICATION(ll_prof, log)
DEFINE_IMPLICATION(gdbjit, log)

// Cleanup...
#undef FLAG_FULL
#undef FLAG_READONLY
#undef FLAG
#undef FLAG_ALIAS
#undef FLAG_ALIAS_WITH_COMMENT

#undef DEFINE_BOOL
#undef DEFINE_MAYBE_BOOL
#undef DEFINE_DEBUG_BOOL
#undef DEFINE_INT
#undef DEFINE_STRING
#undef DEFINE_FLOAT
#undef DEFINE_IMPLICATION
#undef DEFINE_WEAK_IMPLICATION
#undef DEFINE_NEG_IMPLICATION
#undef DEFINE_NEG_IMPLICATION_WITH_WARNING
#undef DEFINE_WEAK_NEG_IMPLICATION
#undef DEFINE_NEG_NEG_IMPLICATION
#undef DEFINE_NEG_VALUE_IMPLICATION
#undef DEFINE_NEG_VALUE_VALUE_IMPLICATION
#undef DEFINE_VALUE_IMPLICATION
#undef DEFINE_MIN_VALUE_IMPLICATION
#undef DEFINE_MAX_VALUE_IMPLICATION
#undef DEFINE_DISABLE_FLAG_IMPLICATION
#undef DEFINE_WEAK_VALUE_IMPLICATION
#undef DEFINE_GENERIC_IMPLICATION
#undef DEFINE_REQUIREMENT
#undef DEFINE_NOT_EXPLICITLY_SET_IMPLICATION
#undef DEFINE_ALIAS_BOOL
#undef DEFINE_ALIAS_BOOL_WITH_COMMENT
#undef DEFINE_ALIAS_INT
#undef DEFINE_ALIAS_STRING
#undef DEFINE_ALIAS_FLOAT

#undef TEMPORARY_WASM_ALIAS_COMMENT

#undef FLAG_MODE_DECLARE
#undef FLAG_MODE_DEFINE_DEFAULTS
#undef FLAG_MODE_META
#undef FLAG_MODE_DEFINE_IMPLICATIONS
#undef FLAG_MODE_APPLY
