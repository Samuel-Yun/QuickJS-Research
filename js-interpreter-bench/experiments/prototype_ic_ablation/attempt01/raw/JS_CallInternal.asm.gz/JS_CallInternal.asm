
/home/mzyx/prototype_ic_ablation_attempt01/switch/qjs:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .plt.got:

Disassembly of section .plt.sec:

Disassembly of section .text:

0000000000022ba0 <JS_CallInternal>:
   22ba0:	55                   	push   rbp
   22ba1:	48 89 e5             	mov    rbp,rsp
   22ba4:	41 57                	push   r15
   22ba6:	41 56                	push   r14
   22ba8:	41 55                	push   r13
   22baa:	41 54                	push   r12
   22bac:	53                   	push   rbx
   22bad:	48 81 ec 48 02 00 00 	sub    rsp,0x248
   22bb4:	48 8b 45 10          	mov    rax,QWORD PTR [rbp+0x10]
   22bb8:	48 89 bd a0 fe ff ff 	mov    QWORD PTR [rbp-0x160],rdi
   22bbf:	48 89 b5 e0 fe ff ff 	mov    QWORD PTR [rbp-0x120],rsi
   22bc6:	48 89 85 70 fe ff ff 	mov    QWORD PTR [rbp-0x190],rax
   22bcd:	48 8b 45 18          	mov    rax,QWORD PTR [rbp+0x18]
   22bd1:	48 89 95 d0 fe ff ff 	mov    QWORD PTR [rbp-0x130],rdx
   22bd8:	48 89 85 80 fe ff ff 	mov    QWORD PTR [rbp-0x180],rax
   22bdf:	48 8b 45 20          	mov    rax,QWORD PTR [rbp+0x20]
   22be3:	48 89 8d 78 fe ff ff 	mov    QWORD PTR [rbp-0x188],rcx
   22bea:	4c 89 85 88 fe ff ff 	mov    QWORD PTR [rbp-0x178],r8
   22bf1:	44 89 8d bc fe ff ff 	mov    DWORD PTR [rbp-0x144],r9d
   22bf8:	48 89 85 a8 fe ff ff 	mov    QWORD PTR [rbp-0x158],rax
   22bff:	64 48 8b 04 25 28 00 	mov    rax,QWORD PTR fs:0x28
   22c06:	00 00 
   22c08:	48 89 45 c8          	mov    QWORD PTR [rbp-0x38],rax
   22c0c:	48 8b 47 10          	mov    rax,QWORD PTR [rdi+0x10]
   22c10:	48 89 85 c0 fe ff ff 	mov    QWORD PTR [rbp-0x140],rax
   22c17:	8b 87 a8 01 00 00    	mov    eax,DWORD PTR [rdi+0x1a8]
   22c1d:	89 85 e8 fe ff ff    	mov    DWORD PTR [rbp-0x118],eax
   22c23:	83 e8 01             	sub    eax,0x1
   22c26:	89 87 a8 01 00 00    	mov    DWORD PTR [rdi+0x1a8],eax
   22c2c:	85 c0                	test   eax,eax
   22c2e:	0f 8e 54 05 00 00    	jle    23188 <JS_CallInternal+0x5e8>
   22c34:	83 bd d0 fe ff ff ff 	cmp    DWORD PTR [rbp-0x130],0xffffffff
   22c3b:	0f 85 7f 05 00 00    	jne    231c0 <JS_CallInternal+0x620>
   22c41:	48 8b 85 e0 fe ff ff 	mov    rax,QWORD PTR [rbp-0x120]
   22c48:	0f b7 40 12          	movzx  eax,WORD PTR [rax+0x12]
   22c4c:	66 83 f8 0d          	cmp    ax,0xd
   22c50:	0f 85 99 07 00 00    	jne    233ef <JS_CallInternal+0x84f>
   22c56:	48 8b 85 e0 fe ff ff 	mov    rax,QWORD PTR [rbp-0x120]
   22c5d:	48 8b 40 28          	mov    rax,QWORD PTR [rax+0x28]
   22c61:	48 89 85 d8 fe ff ff 	mov    QWORD PTR [rbp-0x128],rax
   22c68:	0f b7 78 38          	movzx  edi,WORD PTR [rax+0x38]
   22c6c:	8b 85 bc fe ff ff    	mov    eax,DWORD PTR [rbp-0x144]
   22c72:	39 c7                	cmp    edi,eax
   22c74:	0f 8f fc 01 00 00    	jg     22e76 <JS_CallInternal+0x2d6>
   22c7a:	8b 45 28             	mov    eax,DWORD PTR [rbp+0x28]
   22c7d:	83 e0 02             	and    eax,0x2
   22c80:	0f 45 c7             	cmovne eax,edi
   22c83:	48 8b 95 d8 fe ff ff 	mov    rdx,QWORD PTR [rbp-0x128]
   22c8a:	4c 8b bd c0 fe ff ff 	mov    r15,QWORD PTR [rbp-0x140]
   22c91:	49 89 e8             	mov    r8,rbp
   22c94:	44 0f b7 52 3a       	movzx  r10d,WORD PTR [rdx+0x3a]
   22c99:	0f b7 72 3e          	movzx  esi,WORD PTR [rdx+0x3e]
   22c9d:	0f b7 52 40          	movzx  edx,WORD PTR [rdx+0x40]
   22ca1:	89 f1                	mov    ecx,esi
   22ca3:	44 01 d6             	add    esi,r10d
   22ca6:	4c 89 d3             	mov    rbx,r10
   22ca9:	01 c6                	add    esi,eax
   22cab:	49 89 d1             	mov    r9,rdx
   22cae:	48 63 f6             	movsxd rsi,esi
   22cb1:	48 8d 34 72          	lea    rsi,[rdx+rsi*2]
   22cb5:	48 c1 e6 03          	shl    rsi,0x3
   22cb9:	49 29 f0             	sub    r8,rsi
   22cbc:	4d 3b 87 d0 04 00 00 	cmp    r8,QWORD PTR [r15+0x4d0]
   22cc3:	0f 82 d0 07 00 00    	jb     23499 <JS_CallInternal+0x8f9>
   22cc9:	4c 8b bd d8 fe ff ff 	mov    r15,QWORD PTR [rbp-0x128]
   22cd0:	4c 8b 9d e0 fe ff ff 	mov    r11,QWORD PTR [rbp-0x120]
   22cd7:	48 83 c6 17          	add    rsi,0x17
   22cdb:	45 0f b6 47 10       	movzx  r8d,BYTE PTR [r15+0x10]
   22ce0:	44 8b bd bc fe ff ff 	mov    r15d,DWORD PTR [rbp-0x144]
   22ce7:	4c 89 9d 08 ff ff ff 	mov    QWORD PTR [rbp-0xf8],r11
   22cee:	4d 8b 5b 30          	mov    r11,QWORD PTR [r11+0x30]
   22cf2:	44 89 85 3c ff ff ff 	mov    DWORD PTR [rbp-0xc4],r8d
   22cf9:	49 89 f0             	mov    r8,rsi
   22cfc:	48 81 e6 00 f0 ff ff 	and    rsi,0xfffffffffffff000
   22d03:	44 89 bd 38 ff ff ff 	mov    DWORD PTR [rbp-0xc8],r15d
   22d0a:	4c 8b bd d0 fe ff ff 	mov    r15,QWORD PTR [rbp-0x130]
   22d11:	49 83 e0 f0          	and    r8,0xfffffffffffffff0
   22d15:	4c 89 9d 98 fe ff ff 	mov    QWORD PTR [rbp-0x168],r11
   22d1c:	49 89 e3             	mov    r11,rsp
   22d1f:	49 29 f3             	sub    r11,rsi
   22d22:	4c 89 bd 10 ff ff ff 	mov    QWORD PTR [rbp-0xf0],r15
   22d29:	4c 39 dc             	cmp    rsp,r11
   22d2c:	74 15                	je     22d43 <JS_CallInternal+0x1a3>
   22d2e:	48 81 ec 00 10 00 00 	sub    rsp,0x1000
   22d35:	48 83 8c 24 f8 0f 00 	or     QWORD PTR [rsp+0xff8],0x0
   22d3c:	00 00 
   22d3e:	4c 39 dc             	cmp    rsp,r11
   22d41:	75 eb                	jne    22d2e <JS_CallInternal+0x18e>
   22d43:	41 81 e0 ff 0f 00 00 	and    r8d,0xfff
   22d4a:	4c 29 c4             	sub    rsp,r8
   22d4d:	4d 85 c0             	test   r8,r8
   22d50:	74 06                	je     22d58 <JS_CallInternal+0x1b8>
   22d52:	4a 83 4c 04 f8 00    	or     QWORD PTR [rsp+r8*1-0x8],0x0
   22d58:	48 8b b5 a8 fe ff ff 	mov    rsi,QWORD PTR [rbp-0x158]
   22d5f:	4c 8d 5c 24 0f       	lea    r11,[rsp+0xf]
   22d64:	49 83 e3 f0          	and    r11,0xfffffffffffffff0
   22d68:	4c 89 9d 30 fe ff ff 	mov    QWORD PTR [rbp-0x1d0],r11
   22d6f:	48 89 b5 90 fe ff ff 	mov    QWORD PTR [rbp-0x170],rsi
   22d76:	85 c0                	test   eax,eax
   22d78:	0f 85 b4 61 00 00    	jne    28f32 <JS_CallInternal+0x6392>
   22d7e:	48 98                	cdqe
   22d80:	48 c1 e0 04          	shl    rax,0x4
   22d84:	4c 01 d8             	add    rax,r11
   22d87:	48 89 85 b0 fe ff ff 	mov    QWORD PTR [rbp-0x150],rax
   22d8e:	48 89 85 20 ff ff ff 	mov    QWORD PTR [rbp-0xe0],rax
   22d95:	48 8b 85 90 fe ff ff 	mov    rax,QWORD PTR [rbp-0x170]
   22d9c:	48 89 85 18 ff ff ff 	mov    QWORD PTR [rbp-0xe8],rax
   22da3:	45 85 d2             	test   r10d,r10d
   22da6:	74 30                	je     22dd8 <JS_CallInternal+0x238>
   22da8:	48 8b bd b0 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x150]
   22daf:	48 89 de             	mov    rsi,rbx
   22db2:	48 c1 e6 04          	shl    rsi,0x4
   22db6:	48 89 f8             	mov    rax,rdi
   22db9:	48 01 fe             	add    rsi,rdi
   22dbc:	0f 1f 40 00          	nop    DWORD PTR [rax+0x0]
   22dc0:	48 c7 00 00 00 00 00 	mov    QWORD PTR [rax],0x0
   22dc7:	48 83 c0 10          	add    rax,0x10
   22dcb:	48 c7 40 f8 03 00 00 	mov    QWORD PTR [rax-0x8],0x3
   22dd2:	00 
   22dd3:	48 39 f0             	cmp    rax,rsi
   22dd6:	75 e8                	jne    22dc0 <JS_CallInternal+0x220>
   22dd8:	0f b7 f9             	movzx  edi,cx
   22ddb:	48 8b 85 b0 fe ff ff 	mov    rax,QWORD PTR [rbp-0x150]
   22de2:	48 c1 e3 04          	shl    rbx,0x4
   22de6:	48 89 f9             	mov    rcx,rdi
   22de9:	48 01 c3             	add    rbx,rax
   22dec:	48 c1 e1 04          	shl    rcx,0x4
   22df0:	48 8d 3c 0b          	lea    rdi,[rbx+rcx*1]
   22df4:	48 89 bd 28 ff ff ff 	mov    QWORD PTR [rbp-0xd8],rdi
   22dfb:	66 45 85 c9          	test   r9w,r9w
   22dff:	74 0b                	je     22e0c <JS_CallInternal+0x26c>
   22e01:	48 c1 e2 03          	shl    rdx,0x3
   22e05:	31 f6                	xor    esi,esi
   22e07:	e8 a4 ec fe ff       	call   11ab0 <memset@plt>
   22e0c:	48 8b 8d d8 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x128]
   22e13:	48 8b bd c0 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x140]
   22e1a:	48 89 9d 68 fe ff ff 	mov    QWORD PTR [rbp-0x198],rbx
   22e21:	48 8b 41 18          	mov    rax,QWORD PTR [rcx+0x18]
   22e25:	48 8b 49 48          	mov    rcx,QWORD PTR [rcx+0x48]
   22e29:	48 8b 97 f0 04 00 00 	mov    rdx,QWORD PTR [rdi+0x4f0]
   22e30:	48 89 8d e8 fe ff ff 	mov    QWORD PTR [rbp-0x118],rcx
   22e37:	48 8b 8d e0 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x120]
   22e3e:	48 89 95 00 ff ff ff 	mov    QWORD PTR [rbp-0x100],rdx
   22e45:	48 8d 95 00 ff ff ff 	lea    rdx,[rbp-0x100]
   22e4c:	48 89 97 f0 04 00 00 	mov    QWORD PTR [rdi+0x4f0],rdx
   22e53:	48 89 8d 60 fe ff ff 	mov    QWORD PTR [rbp-0x1a0],rcx
   22e5a:	48 89 95 c8 fe ff ff 	mov    QWORD PTR [rbp-0x138],rdx
   22e61:	4c 8d 60 01          	lea    r12,[rax+0x1]
   22e65:	0f b6 00             	movzx  eax,BYTE PTR [rax]
   22e68:	4c 8d 3d 11 cf 0d 00 	lea    r15,[rip+0xdcf11]        # ffd80 <dispatch_table.85>
   22e6f:	49 89 c5             	mov    r13,rax
   22e72:	41 ff 24 c7          	jmp    QWORD PTR [r15+rax*8]
   22e76:	89 f8                	mov    eax,edi
   22e78:	e9 06 fe ff ff       	jmp    22c83 <JS_CallInternal+0xe3>
   22e7d:	f3 0f 1e fa          	endbr64
   22e81:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]
   22e88:	f3 0f 1e fa          	endbr64
   22e8c:	41 8d 85 4d ff ff ff 	lea    eax,[r13-0xb3]
   22e93:	48 c7 43 08 00 00 00 	mov    QWORD PTR [rbx+0x8],0x0
   22e9a:	00 
   22e9b:	49 83 c4 01          	add    r12,0x1
   22e9f:	48 83 c3 10          	add    rbx,0x10
   22ea3:	48 89 43 f0          	mov    QWORD PTR [rbx-0x10],rax
   22ea7:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   22ead:	49 89 c5             	mov    r13,rax
   22eb0:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   22eb4:	ff e0                	jmp    rax
   22eb6:	f3 0f 1e fa          	endbr64
   22eba:	66 0f 1f 44 00 00    	nop    WORD PTR [rax+rax*1+0x0]
   22ec0:	f3 0f 1e fa          	endbr64
   22ec4:	41 8b 44 24 04       	mov    eax,DWORD PTR [r12+0x4]
   22ec9:	f3 0f 6f 53 f0       	movdqu xmm2,XMMWORD PTR [rbx-0x10]
   22ece:	4d 8d 74 24 09       	lea    r14,[r12+0x9]
   22ed3:	41 8b 0c 24          	mov    ecx,DWORD PTR [r12]
   22ed7:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   22ede:	89 85 28 fe ff ff    	mov    DWORD PTR [rbp-0x1d8],eax
   22ee4:	41 0f b6 44 24 08    	movzx  eax,BYTE PTR [r12+0x8]
   22eea:	0f 29 95 50 fe ff ff 	movaps XMMWORD PTR [rbp-0x1b0],xmm2
   22ef1:	48 8b 95 58 fe ff ff 	mov    rdx,QWORD PTR [rbp-0x1a8]
   22ef8:	88 85 40 fe ff ff    	mov    BYTE PTR [rbp-0x1c0],al
   22efe:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   22f05:	89 8d 38 fe ff ff    	mov    DWORD PTR [rbp-0x1c8],ecx
   22f0b:	49 89 d4             	mov    r12,rdx
   22f0e:	4c 89 70 30          	mov    QWORD PTR [rax+0x30],r14
   22f12:	48 8b 85 50 fe ff ff 	mov    rax,QWORD PTR [rbp-0x1b0]
   22f19:	48 89 c6             	mov    rsi,rax
   22f1c:	48 89 85 10 fe ff ff 	mov    QWORD PTR [rbp-0x1f0],rax
   22f23:	e8 d8 b6 04 00       	call   6e600 <JS_HasProperty>
   22f28:	85 c0                	test   eax,eax
   22f2a:	0f 88 76 07 00 00    	js     236a6 <JS_CallInternal+0xb06>
   22f30:	0f 84 0d 61 00 00    	je     29043 <JS_CallInternal+0x64a3>
   22f36:	80 bd 40 fe ff ff 00 	cmp    BYTE PTR [rbp-0x1c0],0x0
   22f3d:	0f 85 d9 05 00 00    	jne    2351c <JS_CallInternal+0x97c>
   22f43:	41 83 ed 71          	sub    r13d,0x71
   22f47:	41 83 fd 04          	cmp    r13d,0x4
   22f4b:	0f 87 20 05 00 00    	ja     23471 <JS_CallInternal+0x8d1>
   22f51:	48 8d 15 b8 41 0b 00 	lea    rdx,[rip+0xb41b8]        # d7110 <qjsc_repl_size+0x444>
   22f58:	4a 63 04 aa          	movsxd rax,DWORD PTR [rdx+r13*4]
   22f5c:	48 01 d0             	add    rax,rdx
   22f5f:	3e ff e0             	notrack jmp rax
   22f62:	f3 0f 1e fa          	endbr64
   22f66:	f3 0f 1e fa          	endbr64
   22f6a:	4c 89 a5 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],r12
   22f71:	45 8d 95 14 ff ff ff 	lea    r10d,[r13-0xec]
   22f78:	4d 63 da             	movsxd r11,r10d
   22f7b:	49 89 de             	mov    r14,rbx
   22f7e:	48 8b 8d 50 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x1b0]
   22f85:	45 89 d1             	mov    r9d,r10d
   22f88:	49 c1 e3 04          	shl    r11,0x4
   22f8c:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   22f93:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   22f9a:	41 b8 03 00 00 00    	mov    r8d,0x3
   22fa0:	4d 29 de             	sub    r14,r11
   22fa3:	4c 89 9d 38 fe ff ff 	mov    QWORD PTR [rbp-0x1c8],r11
   22faa:	49 8b 76 f0          	mov    rsi,QWORD PTR [r14-0x10]
   22fae:	49 8b 56 f8          	mov    rdx,QWORD PTR [r14-0x8]
   22fb2:	48 89 48 30          	mov    QWORD PTR [rax+0x30],rcx
   22fb6:	31 c9                	xor    ecx,ecx
   22fb8:	6a 00                	push   0x0
   22fba:	4d 8d 66 f0          	lea    r12,[r14-0x10]
   22fbe:	41 56                	push   r14
   22fc0:	6a 03                	push   0x3
   22fc2:	6a 00                	push   0x0
   22fc4:	44 89 95 40 fe ff ff 	mov    DWORD PTR [rbp-0x1c0],r10d
   22fcb:	e8 d0 fb ff ff       	call   22ba0 <JS_CallInternal>
   22fd0:	48 83 c4 20          	add    rsp,0x20
   22fd4:	44 8b 95 40 fe ff ff 	mov    r10d,DWORD PTR [rbp-0x1c0]
   22fdb:	4c 8b 9d 38 fe ff ff 	mov    r11,QWORD PTR [rbp-0x1c8]
   22fe2:	83 fa 06             	cmp    edx,0x6
   22fe5:	49 89 c1             	mov    r9,rax
   22fe8:	49 89 d0             	mov    r8,rdx
   22feb:	48 89 d1             	mov    rcx,rdx
   22fee:	0f 84 4d 65 00 00    	je     29541 <JS_CallInternal+0x69a1>
   22ff4:	41 83 fd 23          	cmp    r13d,0x23
   22ff8:	0f 84 95 02 00 00    	je     23293 <JS_CallInternal+0x6f3>
   22ffe:	4d 01 de             	add    r14,r11
   23001:	45 85 d2             	test   r10d,r10d
   23004:	78 77                	js     2307d <JS_CallInternal+0x4dd>
   23006:	4d 89 e5             	mov    r13,r12
   23009:	4d 89 f0             	mov    r8,r14
   2300c:	48 89 95 38 fe ff ff 	mov    QWORD PTR [rbp-0x1c8],rdx
   23013:	45 89 d4             	mov    r12d,r10d
   23016:	49 89 c6             	mov    r14,rax
   23019:	eb 0e                	jmp    23029 <JS_CallInternal+0x489>
   2301b:	0f 1f 44 00 00       	nop    DWORD PTR [rax+rax*1+0x0]
   23020:	49 83 c5 10          	add    r13,0x10
   23024:	4d 39 c5             	cmp    r13,r8
   23027:	74 47                	je     23070 <JS_CallInternal+0x4d0>
   23029:	49 8b 4d 08          	mov    rcx,QWORD PTR [r13+0x8]
   2302d:	49 8b 75 00          	mov    rsi,QWORD PTR [r13+0x0]
   23031:	83 f9 f6             	cmp    ecx,0xfffffff6
   23034:	76 ea                	jbe    23020 <JS_CallInternal+0x480>
   23036:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   23039:	8d 50 ff             	lea    edx,[rax-0x1]
   2303c:	89 56 fc             	mov    DWORD PTR [rsi-0x4],edx
   2303f:	85 d2                	test   edx,edx
   23041:	7f dd                	jg     23020 <JS_CallInternal+0x480>
   23043:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2304a:	48 89 ca             	mov    rdx,rcx
   2304d:	4c 89 85 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],r8
   23054:	49 83 c5 10          	add    r13,0x10
   23058:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2305c:	e8 0f 99 ff ff       	call   1c970 <__JS_FreeValueRT>
   23061:	4c 8b 85 40 fe ff ff 	mov    r8,QWORD PTR [rbp-0x1c0]
   23068:	4d 39 c5             	cmp    r13,r8
   2306b:	75 bc                	jne    23029 <JS_CallInternal+0x489>
   2306d:	0f 1f 00             	nop    DWORD PTR [rax]
   23070:	4c 8b 85 38 fe ff ff 	mov    r8,QWORD PTR [rbp-0x1c8]
   23077:	45 89 e2             	mov    r10d,r12d
   2307a:	4d 89 f1             	mov    r9,r14
   2307d:	41 8d 42 01          	lea    eax,[r10+0x1]
   23081:	48 98                	cdqe
   23083:	48 c1 e0 04          	shl    rax,0x4
   23087:	48 89 c2             	mov    rdx,rax
   2308a:	48 89 d8             	mov    rax,rbx
   2308d:	48 29 d0             	sub    rax,rdx
   23090:	4c 89 08             	mov    QWORD PTR [rax],r9
   23093:	48 8d 58 10          	lea    rbx,[rax+0x10]
   23097:	4c 89 40 08          	mov    QWORD PTR [rax+0x8],r8
   2309b:	48 8b 85 50 fe ff ff 	mov    rax,QWORD PTR [rbp-0x1b0]
   230a2:	4c 8d 60 01          	lea    r12,[rax+0x1]
   230a6:	0f b6 00             	movzx  eax,BYTE PTR [rax]
   230a9:	49 89 c5             	mov    r13,rax
   230ac:	41 ff 24 c7          	jmp    QWORD PTR [r15+rax*8]
   230b0:	f3 0f 1e fa          	endbr64
   230b4:	f3 0f 1e fa          	endbr64
   230b8:	41 8b 04 24          	mov    eax,DWORD PTR [r12]
   230bc:	31 f6                	xor    esi,esi
   230be:	b9 01 00 00 00       	mov    ecx,0x1
   230c3:	ba 02 00 00 00       	mov    edx,0x2
   230c8:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   230cf:	45 0f b7 74 24 04    	movzx  r14d,WORD PTR [r12+0x4]
   230d5:	89 85 50 fe ff ff    	mov    DWORD PTR [rbp-0x1b0],eax
   230db:	49 8d 44 24 06       	lea    rax,[r12+0x6]
   230e0:	48 89 85 38 fe ff ff 	mov    QWORD PTR [rbp-0x1c8],rax
   230e7:	48 8d 43 10          	lea    rax,[rbx+0x10]
   230eb:	48 89 85 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],rax
   230f2:	e8 e9 3c 02 00       	call   46de0 <JS_NewObjectProtoClass>
   230f7:	48 89 53 08          	mov    QWORD PTR [rbx+0x8],rdx
   230fb:	83 7b 08 06          	cmp    DWORD PTR [rbx+0x8],0x6
   230ff:	48 89 03             	mov    QWORD PTR [rbx],rax
   23102:	0f 84 23 02 00 00    	je     2332b <JS_CallInternal+0x78b>
   23108:	41 83 fd 78          	cmp    r13d,0x78
   2310c:	0f 85 ed 01 00 00    	jne    232ff <JS_CallInternal+0x75f>
   23112:	48 8b 85 98 fe ff ff 	mov    rax,QWORD PTR [rbp-0x168]
   23119:	4e 8b 2c f0          	mov    r13,QWORD PTR [rax+r14*8]
   2311d:	41 83 45 fc 01       	add    DWORD PTR [r13-0x4],0x1
   23122:	48 8b 33             	mov    rsi,QWORD PTR [rbx]
   23125:	8b 95 50 fe ff ff    	mov    edx,DWORD PTR [rbp-0x1b0]
   2312b:	b9 22 00 00 00       	mov    ecx,0x22
   23130:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   23137:	e8 54 34 02 00       	call   46590 <add_property>
   2313c:	48 85 c0             	test   rax,rax
   2313f:	0f 84 f8 8e 00 00    	je     2c03d <JS_CallInternal+0x949d>
   23145:	4c 89 28             	mov    QWORD PTR [rax],r13
   23148:	8b b5 50 fe ff ff    	mov    esi,DWORD PTR [rbp-0x1b0]
   2314e:	31 d2                	xor    edx,edx
   23150:	48 83 c3 20          	add    rbx,0x20
   23154:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2315b:	49 83 c4 07          	add    r12,0x7
   2315f:	e8 ec 12 01 00       	call   34450 <__JS_AtomToValue>
   23164:	48 8b 8d 40 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x1c0]
   2316b:	48 89 01             	mov    QWORD PTR [rcx],rax
   2316e:	48 89 51 08          	mov    QWORD PTR [rcx+0x8],rdx
   23172:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   23178:	49 89 c5             	mov    r13,rax
   2317b:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   2317f:	ff e0                	jmp    rax
   23181:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]
   23188:	e8 53 04 01 00       	call   335e0 <__js_poll_interrupts>
   2318d:	85 c0                	test   eax,eax
   2318f:	0f 84 9f fa ff ff    	je     22c34 <JS_CallInternal+0x94>
   23195:	31 c0                	xor    eax,eax
   23197:	ba 06 00 00 00       	mov    edx,0x6
   2319c:	48 8b 4d c8          	mov    rcx,QWORD PTR [rbp-0x38]
   231a0:	64 48 2b 0c 25 28 00 	sub    rcx,QWORD PTR fs:0x28
   231a7:	00 00 
   231a9:	0f 85 f0 9e 00 00    	jne    2d09f <JS_CallInternal+0xa4ff>
   231af:	48 8d 65 d8          	lea    rsp,[rbp-0x28]
   231b3:	5b                   	pop    rbx
   231b4:	41 5c                	pop    r12
   231b6:	41 5d                	pop    r13
   231b8:	41 5e                	pop    r14
   231ba:	41 5f                	pop    r15
   231bc:	5d                   	pop    rbp
   231bd:	c3                   	ret
   231be:	66 90                	xchg   ax,ax
   231c0:	f6 45 28 04          	test   BYTE PTR [rbp+0x28],0x4
   231c4:	0f 84 d6 03 00 00    	je     235a0 <JS_CallInternal+0xa00>
   231ca:	48 8b 85 e0 fe ff ff 	mov    rax,QWORD PTR [rbp-0x120]
   231d1:	48 8b 48 58          	mov    rcx,QWORD PTR [rax+0x58]
   231d5:	48 8b 50 68          	mov    rdx,QWORD PTR [rax+0x68]
   231d9:	48 8d 78 50          	lea    rdi,[rax+0x50]
   231dd:	48 89 bd c8 fe ff ff 	mov    QWORD PTR [rbp-0x138],rdi
   231e4:	48 8b 59 28          	mov    rbx,QWORD PTR [rcx+0x28]
   231e8:	48 89 8d 60 fe ff ff 	mov    QWORD PTR [rbp-0x1a0],rcx
   231ef:	48 8b 49 30          	mov    rcx,QWORD PTR [rcx+0x30]
   231f3:	48 89 95 30 fe ff ff 	mov    QWORD PTR [rbp-0x1d0],rdx
   231fa:	48 8b 73 48          	mov    rsi,QWORD PTR [rbx+0x48]
   231fe:	48 89 9d d8 fe ff ff 	mov    QWORD PTR [rbp-0x128],rbx
   23205:	48 89 8d 98 fe ff ff 	mov    QWORD PTR [rbp-0x168],rcx
   2320c:	48 89 c1             	mov    rcx,rax
   2320f:	48 89 b5 e8 fe ff ff 	mov    QWORD PTR [rbp-0x118],rsi
   23216:	48 8b 70 70          	mov    rsi,QWORD PTR [rax+0x70]
   2321a:	0f b7 43 3a          	movzx  eax,WORD PTR [rbx+0x3a]
   2321e:	4c 8b a1 80 00 00 00 	mov    r12,QWORD PTR [rcx+0x80]
   23225:	48 89 b5 b0 fe ff ff 	mov    QWORD PTR [rbp-0x150],rsi
   2322c:	48 8b 99 90 00 00 00 	mov    rbx,QWORD PTR [rcx+0x90]
   23233:	48 c7 81 90 00 00 00 	mov    QWORD PTR [rcx+0x90],0x0
   2323a:	00 00 00 00 
   2323e:	48 c1 e0 04          	shl    rax,0x4
   23242:	48 01 f0             	add    rax,rsi
   23245:	48 8b b5 c0 fe ff ff 	mov    rsi,QWORD PTR [rbp-0x140]
   2324c:	48 89 85 68 fe ff ff 	mov    QWORD PTR [rbp-0x198],rax
   23253:	48 8b 86 f0 04 00 00 	mov    rax,QWORD PTR [rsi+0x4f0]
   2325a:	48 89 41 50          	mov    QWORD PTR [rcx+0x50],rax
   2325e:	48 89 be f0 04 00 00 	mov    QWORD PTR [rsi+0x4f0],rdi
   23265:	8b 79 24             	mov    edi,DWORD PTR [rcx+0x24]
   23268:	85 ff                	test   edi,edi
   2326a:	0f 84 9d 02 00 00    	je     2350d <JS_CallInternal+0x96d>
   23270:	48 8b 85 30 fe ff ff 	mov    rax,QWORD PTR [rbp-0x1d0]
   23277:	48 89 85 90 fe ff ff 	mov    QWORD PTR [rbp-0x170],rax
   2327e:	e9 bd 00 00 00       	jmp    23340 <JS_CallInternal+0x7a0>
   23283:	f3 0f 1e fa          	endbr64
   23287:	48 8b 43 f0          	mov    rax,QWORD PTR [rbx-0x10]
   2328b:	48 8b 4b f8          	mov    rcx,QWORD PTR [rbx-0x8]
   2328f:	48 83 eb 10          	sub    rbx,0x10
   23293:	48 8b bd d8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x128]
   2329a:	66 83 7f 40 00       	cmp    WORD PTR [rdi+0x40],0x0
   2329f:	0f 85 e5 6f 00 00    	jne    2a28a <JS_CallInternal+0x76ea>
   232a5:	4c 8b a5 30 fe ff ff 	mov    r12,QWORD PTR [rbp-0x1d0]
   232ac:	49 39 dc             	cmp    r12,rbx
   232af:	0f 83 1a 01 00 00    	jae    233cf <JS_CallInternal+0x82f>
   232b5:	4c 8b ad e8 fe ff ff 	mov    r13,QWORD PTR [rbp-0x118]
   232bc:	49 89 ce             	mov    r14,rcx
   232bf:	49 89 c7             	mov    r15,rax
   232c2:	eb 11                	jmp    232d5 <JS_CallInternal+0x735>
   232c4:	0f 1f 40 00          	nop    DWORD PTR [rax+0x0]
   232c8:	49 83 c4 10          	add    r12,0x10
   232cc:	49 39 dc             	cmp    r12,rbx
   232cf:	0f 83 b9 01 00 00    	jae    2348e <JS_CallInternal+0x8ee>
   232d5:	4d 8b 44 24 08       	mov    r8,QWORD PTR [r12+0x8]
   232da:	49 8b 34 24          	mov    rsi,QWORD PTR [r12]
   232de:	41 83 f8 f6          	cmp    r8d,0xfffffff6
   232e2:	76 e4                	jbe    232c8 <JS_CallInternal+0x728>
   232e4:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   232e7:	8d 50 ff             	lea    edx,[rax-0x1]
   232ea:	89 56 fc             	mov    DWORD PTR [rsi-0x4],edx
   232ed:	85 d2                	test   edx,edx
   232ef:	7f d7                	jg     232c8 <JS_CallInternal+0x728>
   232f1:	49 8b 7d 10          	mov    rdi,QWORD PTR [r13+0x10]
   232f5:	4c 89 c2             	mov    rdx,r8
   232f8:	e8 73 96 ff ff       	call   1c970 <__JS_FreeValueRT>
   232fd:	eb c9                	jmp    232c8 <JS_CallInternal+0x728>
   232ff:	31 c9                	xor    ecx,ecx
   23301:	48 8b b5 c8 fe ff ff 	mov    rsi,QWORD PTR [rbp-0x138]
   23308:	41 83 fd 77          	cmp    r13d,0x77
   2330c:	41 0f b7 d6          	movzx  edx,r14w
   23310:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   23317:	0f 94 c1             	sete   cl
   2331a:	e8 21 8b 02 00       	call   4be40 <get_var_ref>
   2331f:	49 89 c5             	mov    r13,rax
   23322:	48 85 c0             	test   rax,rax
   23325:	0f 85 f7 fd ff ff    	jne    23122 <JS_CallInternal+0x582>
   2332b:	48 8b 9d 40 fe ff ff 	mov    rbx,QWORD PTR [rbp-0x1c0]
   23332:	4c 8b a5 38 fe ff ff 	mov    r12,QWORD PTR [rbp-0x1c8]
   23339:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]
   23340:	48 8b 8d c0 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x140]
   23347:	83 b9 e0 04 00 00 ff 	cmp    DWORD PTR [rcx+0x4e0],0xffffffff
   2334e:	48 8b 81 d8 04 00 00 	mov    rax,QWORD PTR [rcx+0x4d8]
   23355:	75 39                	jne    23390 <JS_CallInternal+0x7f0>
   23357:	66 83 78 12 03       	cmp    WORD PTR [rax+0x12],0x3
   2335c:	75 32                	jne    23390 <JS_CallInternal+0x7f0>
   2335e:	48 8b 48 18          	mov    rcx,QWORD PTR [rax+0x18]
   23362:	8b 51 18             	mov    edx,DWORD PTR [rcx+0x18]
   23365:	89 d0                	mov    eax,edx
   23367:	83 e0 39             	and    eax,0x39
   2336a:	8b 44 81 38          	mov    eax,DWORD PTR [rcx+rax*4+0x38]
   2336e:	48 85 c0             	test   rax,rax
   23371:	0f 84 46 68 00 00    	je     29bbd <JS_CallInternal+0x701d>
   23377:	48 8d 14 95 34 00 00 	lea    rdx,[rdx*4+0x34]
   2337e:	00 
   2337f:	48 8d 04 c2          	lea    rax,[rdx+rax*8]
   23383:	48 01 c8             	add    rax,rcx
   23386:	83 78 04 39          	cmp    DWORD PTR [rax+0x4],0x39
   2338a:	0f 85 20 68 00 00    	jne    29bb0 <JS_CallInternal+0x7010>
   23390:	48 8b 85 c0 fe ff ff 	mov    rax,QWORD PTR [rbp-0x140]
   23397:	80 b8 e8 04 00 00 00 	cmp    BYTE PTR [rax+0x4e8],0x0
   2339e:	0f 84 39 01 00 00    	je     234dd <JS_CallInternal+0x93d>
   233a4:	48 8b 85 d8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x128]
   233ab:	b9 06 00 00 00       	mov    ecx,0x6
   233b0:	f6 40 11 30          	test   BYTE PTR [rax+0x11],0x30
   233b4:	b8 00 00 00 00       	mov    eax,0x0
   233b9:	0f 84 d4 fe ff ff    	je     23293 <JS_CallInternal+0x6f3>
   233bf:	90                   	nop
   233c0:	48 8b bd c8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x138]
   233c7:	4c 89 67 30          	mov    QWORD PTR [rdi+0x30],r12
   233cb:	48 89 5f 40          	mov    QWORD PTR [rdi+0x40],rbx
   233cf:	48 8b 9d c8 fe ff ff 	mov    rbx,QWORD PTR [rbp-0x138]
   233d6:	48 8b 13             	mov    rdx,QWORD PTR [rbx]
   233d9:	48 8b 9d c0 fe ff ff 	mov    rbx,QWORD PTR [rbp-0x140]
   233e0:	48 89 93 f0 04 00 00 	mov    QWORD PTR [rbx+0x4f0],rdx
   233e7:	48 89 ca             	mov    rdx,rcx
   233ea:	e9 ad fd ff ff       	jmp    2319c <JS_CallInternal+0x5fc>
   233ef:	48 8b 8d c0 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x140]
   233f6:	48 8d 04 80          	lea    rax,[rax+rax*4]
   233fa:	48 c1 e0 03          	shl    rax,0x3
   233fe:	48 03 81 58 04 00 00 	add    rax,QWORD PTR [rcx+0x458]
   23405:	48 8b 40 18          	mov    rax,QWORD PTR [rax+0x18]
   23409:	48 85 c0             	test   rax,rax
   2340c:	0f 84 8e 01 00 00    	je     235a0 <JS_CallInternal+0xa00>
   23412:	8b 4d 28             	mov    ecx,DWORD PTR [rbp+0x28]
   23415:	48 8b b5 e0 fe ff ff 	mov    rsi,QWORD PTR [rbp-0x120]
   2341c:	44 8b 8d bc fe ff ff 	mov    r9d,DWORD PTR [rbp-0x144]
   23423:	4c 8b 85 88 fe ff ff 	mov    r8,QWORD PTR [rbp-0x178]
   2342a:	48 8b 95 d0 fe ff ff 	mov    rdx,QWORD PTR [rbp-0x130]
   23431:	48 8b bd a0 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x160]
   23438:	51                   	push   rcx
   23439:	48 8b 8d 78 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x188]
   23440:	ff b5 a8 fe ff ff    	push   QWORD PTR [rbp-0x158]
   23446:	ff d0                	call   rax
   23448:	59                   	pop    rcx
   23449:	5e                   	pop    rsi
   2344a:	e9 4d fd ff ff       	jmp    2319c <JS_CallInternal+0x5fc>
   2344f:	8b b5 38 fe ff ff    	mov    esi,DWORD PTR [rbp-0x1c8]
   23455:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2345c:	31 d2                	xor    edx,edx
   2345e:	4c 8d 63 10          	lea    r12,[rbx+0x10]
   23462:	e8 e9 0f 01 00       	call   34450 <__JS_AtomToValue>
   23467:	48 89 03             	mov    QWORD PTR [rbx],rax
   2346a:	48 89 53 08          	mov    QWORD PTR [rbx+0x8],rdx
   2346e:	4c 89 e3             	mov    rbx,r12
   23471:	8b 85 28 fe ff ff    	mov    eax,DWORD PTR [rbp-0x1d8]
   23477:	83 e8 05             	sub    eax,0x5
   2347a:	48 98                	cdqe
   2347c:	49 01 c6             	add    r14,rax
   2347f:	41 0f b6 06          	movzx  eax,BYTE PTR [r14]
   23483:	4d 8d 66 01          	lea    r12,[r14+0x1]
   23487:	49 89 c5             	mov    r13,rax
   2348a:	41 ff 24 c7          	jmp    QWORD PTR [r15+rax*8]
   2348e:	4c 89 f1             	mov    rcx,r14
   23491:	4c 89 f8             	mov    rax,r15
   23494:	e9 36 ff ff ff       	jmp    233cf <JS_CallInternal+0x82f>
   23499:	48 8b bd a0 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x160]
   234a0:	48 8d 35 1c a0 0a 00 	lea    rsi,[rip+0xaa01c]        # cd4c3 <_IO_stdin_used+0x4c3>
   234a7:	31 c0                	xor    eax,eax
   234a9:	e8 b2 ff 00 00       	call   33460 <JS_ThrowInternalError>
   234ae:	e9 e9 fc ff ff       	jmp    2319c <JS_CallInternal+0x5fc>
   234b3:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   234ba:	4c 89 ee             	mov    rsi,r13
   234bd:	4c 89 f2             	mov    rdx,r14
   234c0:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   234c4:	e8 a7 94 ff ff       	call   1c970 <__JS_FreeValueRT>
   234c9:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]
   234d0:	41 83 fe 05          	cmp    r14d,0x5
   234d4:	0f 84 96 61 00 00    	je     29670 <JS_CallInternal+0x6ad0>
   234da:	4c 89 fb             	mov    rbx,r15
   234dd:	48 39 9d 68 fe ff ff 	cmp    QWORD PTR [rbp-0x198],rbx
   234e4:	0f 83 ba fe ff ff    	jae    233a4 <JS_CallInternal+0x804>
   234ea:	4c 8b 73 f8          	mov    r14,QWORD PTR [rbx-0x8]
   234ee:	4c 8d 7b f0          	lea    r15,[rbx-0x10]
   234f2:	4c 8b 6b f0          	mov    r13,QWORD PTR [rbx-0x10]
   234f6:	41 83 fe f6          	cmp    r14d,0xfffffff6
   234fa:	76 d4                	jbe    234d0 <JS_CallInternal+0x930>
   234fc:	41 8b 45 fc          	mov    eax,DWORD PTR [r13-0x4]
   23500:	83 e8 01             	sub    eax,0x1
   23503:	41 89 45 fc          	mov    DWORD PTR [r13-0x4],eax
   23507:	85 c0                	test   eax,eax
   23509:	7f c5                	jg     234d0 <JS_CallInternal+0x930>
   2350b:	eb a6                	jmp    234b3 <JS_CallInternal+0x913>
   2350d:	48 89 95 90 fe ff ff 	mov    QWORD PTR [rbp-0x170],rdx
   23514:	4c 89 e0             	mov    rax,r12
   23517:	e9 45 f9 ff ff       	jmp    22e61 <JS_CallInternal+0x2c1>
   2351c:	48 83 ec 08          	sub    rsp,0x8
   23520:	4c 8b 85 50 fe ff ff 	mov    r8,QWORD PTR [rbp-0x1b0]
   23527:	48 8b b5 10 fe ff ff 	mov    rsi,QWORD PTR [rbp-0x1f0]
   2352e:	b9 f1 00 00 00       	mov    ecx,0xf1
   23533:	6a 00                	push   0x0
   23535:	4c 8b 8d 58 fe ff ff 	mov    r9,QWORD PTR [rbp-0x1a8]
   2353c:	4c 89 e2             	mov    rdx,r12
   2353f:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   23546:	e8 c5 9c 00 00       	call   2d210 <JS_GetPropertyInternal>
   2354b:	59                   	pop    rcx
   2354c:	5e                   	pop    rsi
   2354d:	49 89 c0             	mov    r8,rax
   23550:	49 89 d4             	mov    r12,rdx
   23553:	83 fa 06             	cmp    edx,0x6
   23556:	0f 84 4a 01 00 00    	je     236a6 <JS_CallInternal+0xb06>
   2355c:	83 fa ff             	cmp    edx,0xffffffff
   2355f:	0f 84 7d 5a 00 00    	je     28fe2 <JS_CallInternal+0x6442>
   23565:	83 fa f6             	cmp    edx,0xfffffff6
   23568:	0f 86 d5 f9 ff ff    	jbe    22f43 <JS_CallInternal+0x3a3>
   2356e:	8b 40 fc             	mov    eax,DWORD PTR [rax-0x4]
   23571:	83 e8 01             	sub    eax,0x1
   23574:	41 89 40 fc          	mov    DWORD PTR [r8-0x4],eax
   23578:	85 c0                	test   eax,eax
   2357a:	0f 8f c3 f9 ff ff    	jg     22f43 <JS_CallInternal+0x3a3>
   23580:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   23587:	4c 89 c6             	mov    rsi,r8
   2358a:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2358e:	e8 dd 93 ff ff       	call   1c970 <__JS_FreeValueRT>
   23593:	e9 ab f9 ff ff       	jmp    22f43 <JS_CallInternal+0x3a3>
   23598:	0f 1f 84 00 00 00 00 	nop    DWORD PTR [rax+rax*1+0x0]
   2359f:	00 
   235a0:	48 8b bd a0 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x160]
   235a7:	48 8d 35 08 b6 0a 00 	lea    rsi,[rip+0xab608]        # cebb6 <_IO_stdin_used+0x1bb6>
   235ae:	31 c0                	xor    eax,eax
   235b0:	e8 cb da 00 00       	call   31080 <JS_ThrowTypeError>
   235b5:	e9 e2 fb ff ff       	jmp    2319c <JS_CallInternal+0x5fc>
   235ba:	48 8b 85 50 fe ff ff 	mov    rax,QWORD PTR [rbp-0x1b0]
   235c1:	48 8b 95 58 fe ff ff 	mov    rdx,QWORD PTR [rbp-0x1a8]
   235c8:	8b 8d 38 fe ff ff    	mov    ecx,DWORD PTR [rbp-0x1c8]
   235ce:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   235d5:	48 89 c6             	mov    rsi,rax
   235d8:	49 89 c5             	mov    r13,rax
   235db:	49 89 d4             	mov    r12,rdx
   235de:	e8 1d b0 04 00       	call   6e600 <JS_HasProperty>
   235e3:	85 c0                	test   eax,eax
   235e5:	0f 88 bb 00 00 00    	js     236a6 <JS_CallInternal+0xb06>
   235eb:	b8 03 00 00 00       	mov    eax,0x3
   235f0:	b9 00 00 00 00       	mov    ecx,0x0
   235f5:	0f 85 50 71 00 00    	jne    2a74b <JS_CallInternal+0x7bab>
   235fb:	48 89 0b             	mov    QWORD PTR [rbx],rcx
   235fe:	48 83 c3 10          	add    rbx,0x10
   23602:	48 89 43 f8          	mov    QWORD PTR [rbx-0x8],rax
   23606:	e9 66 fe ff ff       	jmp    23471 <JS_CallInternal+0x8d1>
   2360b:	48 8b 85 50 fe ff ff 	mov    rax,QWORD PTR [rbp-0x1b0]
   23612:	48 8b 95 58 fe ff ff 	mov    rdx,QWORD PTR [rbp-0x1a8]
   23619:	8b 8d 38 fe ff ff    	mov    ecx,DWORD PTR [rbp-0x1c8]
   2361f:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   23626:	48 89 c6             	mov    rsi,rax
   23629:	e8 d2 af 04 00       	call   6e600 <JS_HasProperty>
   2362e:	85 c0                	test   eax,eax
   23630:	0f 8e fa 88 00 00    	jle    2bf30 <JS_CallInternal+0x9390>
   23636:	48 83 ec 08          	sub    rsp,0x8
   2363a:	4c 8b 43 e0          	mov    r8,QWORD PTR [rbx-0x20]
   2363e:	4c 8b 4b e8          	mov    r9,QWORD PTR [rbx-0x18]
   23642:	4c 8d 63 e0          	lea    r12,[rbx-0x20]
   23646:	4c 8b 95 50 fe ff ff 	mov    r10,QWORD PTR [rbp-0x1b0]
   2364d:	4c 8b 9d 58 fe ff ff 	mov    r11,QWORD PTR [rbp-0x1a8]
   23654:	68 00 80 00 00       	push   0x8000
   23659:	8b 8d 38 fe ff ff    	mov    ecx,DWORD PTR [rbp-0x1c8]
   2365f:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   23666:	41 53                	push   r11
   23668:	4c 89 d6             	mov    rsi,r10
   2366b:	4c 89 da             	mov    rdx,r11
   2366e:	41 52                	push   r10
   23670:	e8 cb a8 00 00       	call   2df40 <JS_SetPropertyInternal>
   23675:	48 8b 53 f8          	mov    rdx,QWORD PTR [rbx-0x8]
   23679:	48 8b 73 f0          	mov    rsi,QWORD PTR [rbx-0x10]
   2367d:	48 83 c4 20          	add    rsp,0x20
   23681:	41 89 c5             	mov    r13d,eax
   23684:	83 fa f6             	cmp    edx,0xfffffff6
   23687:	76 11                	jbe    2369a <JS_CallInternal+0xafa>
   23689:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   2368c:	83 e8 01             	sub    eax,0x1
   2368f:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   23692:	85 c0                	test   eax,eax
   23694:	0f 8e d1 88 00 00    	jle    2bf6b <JS_CallInternal+0x93cb>
   2369a:	4c 89 e3             	mov    rbx,r12
   2369d:	45 85 ed             	test   r13d,r13d
   236a0:	0f 89 cb fd ff ff    	jns    23471 <JS_CallInternal+0x8d1>
   236a6:	4d 89 f4             	mov    r12,r14
   236a9:	e9 92 fc ff ff       	jmp    23340 <JS_CallInternal+0x7a0>
   236ae:	48 8b 85 50 fe ff ff 	mov    rax,QWORD PTR [rbp-0x1b0]
   236b5:	48 8b 95 58 fe ff ff 	mov    rdx,QWORD PTR [rbp-0x1a8]
   236bc:	8b 8d 38 fe ff ff    	mov    ecx,DWORD PTR [rbp-0x1c8]
   236c2:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   236c9:	48 89 c6             	mov    rsi,rax
   236cc:	49 89 c5             	mov    r13,rax
   236cf:	49 89 d4             	mov    r12,rdx
   236d2:	e8 29 af 04 00       	call   6e600 <JS_HasProperty>
   236d7:	85 c0                	test   eax,eax
   236d9:	0f 8e a1 88 00 00    	jle    2bf80 <JS_CallInternal+0x93e0>
   236df:	48 83 ec 08          	sub    rsp,0x8
   236e3:	8b 8d 38 fe ff ff    	mov    ecx,DWORD PTR [rbp-0x1c8]
   236e9:	4c 89 ee             	mov    rsi,r13
   236ec:	4c 89 e2             	mov    rdx,r12
   236ef:	4c 8b 8d 58 fe ff ff 	mov    r9,QWORD PTR [rbp-0x1a8]
   236f6:	4c 8b 85 50 fe ff ff 	mov    r8,QWORD PTR [rbp-0x1b0]
   236fd:	6a 00                	push   0x0
   236ff:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   23706:	e8 05 9b 00 00       	call   2d210 <JS_GetPropertyInternal>
   2370b:	41 59                	pop    r9
   2370d:	41 5a                	pop    r10
   2370f:	48 89 c1             	mov    rcx,rax
   23712:	48 89 d0             	mov    rax,rdx
   23715:	83 fa 06             	cmp    edx,0x6
   23718:	74 8c                	je     236a6 <JS_CallInternal+0xb06>
   2371a:	48 8b 53 f8          	mov    rdx,QWORD PTR [rbx-0x8]
   2371e:	48 8b 73 f0          	mov    rsi,QWORD PTR [rbx-0x10]
   23722:	48 89 43 f8          	mov    QWORD PTR [rbx-0x8],rax
   23726:	48 89 4b f0          	mov    QWORD PTR [rbx-0x10],rcx
   2372a:	83 fa f6             	cmp    edx,0xfffffff6
   2372d:	0f 86 3e fd ff ff    	jbe    23471 <JS_CallInternal+0x8d1>
   23733:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   23736:	83 e8 01             	sub    eax,0x1
   23739:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   2373c:	85 c0                	test   eax,eax
   2373e:	0f 8f 2d fd ff ff    	jg     23471 <JS_CallInternal+0x8d1>
   23744:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2374b:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2374f:	e8 1c 92 ff ff       	call   1c970 <__JS_FreeValueRT>
   23754:	e9 18 fd ff ff       	jmp    23471 <JS_CallInternal+0x8d1>
   23759:	48 8b 85 50 fe ff ff 	mov    rax,QWORD PTR [rbp-0x1b0]
   23760:	8b 8d 38 fe ff ff    	mov    ecx,DWORD PTR [rbp-0x1c8]
   23766:	45 31 c0             	xor    r8d,r8d
   23769:	48 8b 95 58 fe ff ff 	mov    rdx,QWORD PTR [rbp-0x1a8]
   23770:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   23777:	48 89 c6             	mov    rsi,rax
   2377a:	e8 e1 7d 02 00       	call   4b560 <JS_DeleteProperty>
   2377f:	41 89 c4             	mov    r12d,eax
   23782:	85 c0                	test   eax,eax
   23784:	0f 88 1c ff ff ff    	js     236a6 <JS_CallInternal+0xb06>
   2378a:	48 8b 53 f8          	mov    rdx,QWORD PTR [rbx-0x8]
   2378e:	48 8b 73 f0          	mov    rsi,QWORD PTR [rbx-0x10]
   23792:	83 fa f6             	cmp    edx,0xfffffff6
   23795:	76 11                	jbe    237a8 <JS_CallInternal+0xc08>
   23797:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   2379a:	83 e8 01             	sub    eax,0x1
   2379d:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   237a0:	85 c0                	test   eax,eax
   237a2:	0f 8e 51 87 00 00    	jle    2bef9 <JS_CallInternal+0x9359>
   237a8:	31 c0                	xor    eax,eax
   237aa:	45 85 e4             	test   r12d,r12d
   237ad:	48 c7 43 f8 01 00 00 	mov    QWORD PTR [rbx-0x8],0x1
   237b4:	00 
   237b5:	0f 95 c0             	setne  al
   237b8:	48 89 43 f0          	mov    QWORD PTR [rbx-0x10],rax
   237bc:	e9 b0 fc ff ff       	jmp    23471 <JS_CallInternal+0x8d1>
   237c1:	f3 0f 1e fa          	endbr64
   237c5:	f3 0f 1e fa          	endbr64
   237c9:	41 0f b7 04 24       	movzx  eax,WORD PTR [r12]
   237ce:	48 8b 8d 98 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x168]
   237d5:	4d 8d 74 24 02       	lea    r14,[r12+0x2]
   237da:	48 8b 14 c1          	mov    rdx,QWORD PTR [rcx+rax*8]
   237de:	48 8d 34 c5 00 00 00 	lea    rsi,[rax*8+0x0]
   237e5:	00 
   237e6:	48 8b 42 18          	mov    rax,QWORD PTR [rdx+0x18]
   237ea:	48 8b 48 08          	mov    rcx,QWORD PTR [rax+0x8]
   237ee:	83 f9 04             	cmp    ecx,0x4
   237f1:	0f 84 69 62 00 00    	je     29a60 <JS_CallInternal+0x6ec0>
   237f7:	80 7a 12 00          	cmp    BYTE PTR [rdx+0x12],0x0
   237fb:	0f 85 5f 62 00 00    	jne    29a60 <JS_CallInternal+0x6ec0>
   23801:	f3 0f 6f 63 f0       	movdqu xmm4,XMMWORD PTR [rbx-0x10]
   23806:	48 8b 30             	mov    rsi,QWORD PTR [rax]
   23809:	0f 11 20             	movups XMMWORD PTR [rax],xmm4
   2380c:	83 f9 f6             	cmp    ecx,0xfffffff6
   2380f:	76 11                	jbe    23822 <JS_CallInternal+0xc82>
   23811:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   23814:	83 e8 01             	sub    eax,0x1
   23817:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   2381a:	85 c0                	test   eax,eax
   2381c:	0f 8e 4f 6b 00 00    	jle    2a371 <JS_CallInternal+0x77d1>
   23822:	48 83 eb 10          	sub    rbx,0x10
   23826:	41 0f b6 44 24 02    	movzx  eax,BYTE PTR [r12+0x2]
   2382c:	49 83 c4 03          	add    r12,0x3
   23830:	49 89 c5             	mov    r13,rax
   23833:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   23837:	ff e0                	jmp    rax
   23839:	f3 0f 1e fa          	endbr64
   2383d:	f3 0f 1e fa          	endbr64
   23841:	48 83 ec 08          	sub    rsp,0x8
   23845:	31 c0                	xor    eax,eax
   23847:	41 83 fd 54          	cmp    r13d,0x54
   2384b:	41 0f b6 4c 24 04    	movzx  ecx,BYTE PTR [r12+0x4]
   23851:	0f 94 c0             	sete   al
   23854:	41 8b 14 24          	mov    edx,DWORD PTR [r12]
   23858:	48 89 de             	mov    rsi,rbx
   2385b:	4d 8d 74 24 05       	lea    r14,[r12+0x5]
   23860:	4c 8b 8d c8 fe ff ff 	mov    r9,QWORD PTR [rbp-0x138]
   23867:	4c 8b 85 98 fe ff ff 	mov    r8,QWORD PTR [rbp-0x168]
   2386e:	50                   	push   rax
   2386f:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   23876:	e8 15 5c 06 00       	call   89490 <js_op_define_class>
   2387b:	41 59                	pop    r9
   2387d:	41 5a                	pop    r10
   2387f:	85 c0                	test   eax,eax
   23881:	0f 88 e3 87 00 00    	js     2c06a <JS_CallInternal+0x94ca>
   23887:	41 0f b6 44 24 05    	movzx  eax,BYTE PTR [r12+0x5]
   2388d:	49 83 c4 06          	add    r12,0x6
   23891:	49 89 c5             	mov    r13,rax
   23894:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   23898:	ff e0                	jmp    rax
   2389a:	f3 0f 1e fa          	endbr64
   2389e:	f3 0f 1e fa          	endbr64
   238a2:	41 83 fd 52          	cmp    r13d,0x52
   238a6:	0f 94 c0             	sete   al
   238a9:	41 0f 94 c6          	sete   r14b
   238ad:	0f b6 c0             	movzx  eax,al
   238b0:	89 85 40 fe ff ff    	mov    DWORD PTR [rbp-0x1c0],eax
   238b6:	45 84 f6             	test   r14b,r14b
   238b9:	0f 85 89 60 00 00    	jne    29948 <JS_CallInternal+0x6da8>
   238bf:	41 8b 04 24          	mov    eax,DWORD PTR [r12]
   238c3:	4d 8d 6c 24 04       	lea    r13,[r12+0x4]
   238c8:	89 85 50 fe ff ff    	mov    DWORD PTR [rbp-0x1b0],eax
   238ce:	8b 8d 40 fe ff ff    	mov    ecx,DWORD PTR [rbp-0x1c0]
   238d4:	b8 fe ff ff ff       	mov    eax,0xfffffffe
   238d9:	41 0f b6 55 00       	movzx  edx,BYTE PTR [r13+0x0]
   238de:	bf 03 00 00 00       	mov    edi,0x3
   238e3:	48 c7 85 38 fe ff ff 	mov    QWORD PTR [rbp-0x1c8],0x0
   238ea:	00 00 00 00 
   238ee:	4c 8d 63 f0          	lea    r12,[rbx-0x10]
   238f2:	29 c8                	sub    eax,ecx
   238f4:	48 89 bd 18 fe ff ff 	mov    QWORD PTR [rbp-0x1e8],rdi
   238fb:	48 98                	cdqe
   238fd:	48 89 bd e8 fd ff ff 	mov    QWORD PTR [rbp-0x218],rdi
   23904:	48 c7 85 28 fe ff ff 	mov    QWORD PTR [rbp-0x1d8],0x3
   2390b:	03 00 00 00 
   2390f:	48 c1 e0 04          	shl    rax,0x4
   23913:	48 8b 0c 03          	mov    rcx,QWORD PTR [rbx+rax*1]
   23917:	48 8b 44 03 08       	mov    rax,QWORD PTR [rbx+rax*1+0x8]
   2391c:	48 89 85 c0 fd ff ff 	mov    QWORD PTR [rbp-0x240],rax
   23923:	89 d0                	mov    eax,edx
   23925:	83 e0 04             	and    eax,0x4
   23928:	48 89 8d c8 fd ff ff 	mov    QWORD PTR [rbp-0x238],rcx
   2392f:	3c 01                	cmp    al,0x1
   23931:	19 c0                	sbb    eax,eax
   23933:	31 f6                	xor    esi,esi
   23935:	83 e0 fc             	and    eax,0xfffffffc
   23938:	48 89 b5 10 fe ff ff 	mov    QWORD PTR [rbp-0x1f0],rsi
   2393f:	48 89 b5 e0 fd ff ff 	mov    QWORD PTR [rbp-0x220],rsi
   23946:	05 05 45 00 00       	add    eax,0x4505
   2394b:	83 e2 03             	and    edx,0x3
   2394e:	0f 85 6a 57 00 00    	jne    290be <JS_CallInternal+0x651e>
   23954:	48 8b 4b f0          	mov    rcx,QWORD PTR [rbx-0x10]
   23958:	0d 02 22 00 00       	or     eax,0x2202
   2395d:	8b b5 50 fe ff ff    	mov    esi,DWORD PTR [rbp-0x1b0]
   23963:	89 85 24 fe ff ff    	mov    DWORD PTR [rbp-0x1dc],eax
   23969:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   23970:	48 89 8d 38 fe ff ff 	mov    QWORD PTR [rbp-0x1c8],rcx
   23977:	48 8b 43 f0          	mov    rax,QWORD PTR [rbx-0x10]
   2397b:	48 8b 4b f8          	mov    rcx,QWORD PTR [rbx-0x8]
   2397f:	48 89 85 d8 fd ff ff 	mov    QWORD PTR [rbp-0x228],rax
   23986:	48 89 8d 28 fe ff ff 	mov    QWORD PTR [rbp-0x1d8],rcx
   2398d:	48 89 8d d0 fd ff ff 	mov    QWORD PTR [rbp-0x230],rcx
   23994:	e8 c7 d1 01 00       	call   40b60 <js_get_function_name>
   23999:	49 89 d1             	mov    r9,rdx
   2399c:	41 83 f9 06          	cmp    r9d,0x6
   239a0:	0f 84 76 6a 00 00    	je     2a41c <JS_CallInternal+0x787c>
   239a6:	48 83 ec 08          	sub    rsp,0x8
   239aa:	49 89 c0             	mov    r8,rax
   239ad:	b9 3a 00 00 00       	mov    ecx,0x3a
   239b2:	48 8b 95 d0 fd ff ff 	mov    rdx,QWORD PTR [rbp-0x230]
   239b9:	48 8b b5 d8 fd ff ff 	mov    rsi,QWORD PTR [rbp-0x228]
   239c0:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   239c7:	6a 01                	push   0x1
   239c9:	48 89 95 b8 fd ff ff 	mov    QWORD PTR [rbp-0x248],rdx
   239d0:	48 89 b5 b0 fd ff ff 	mov    QWORD PTR [rbp-0x250],rsi
   239d7:	e8 24 c8 00 00       	call   30200 <JS_DefinePropertyValue>
   239dc:	41 5b                	pop    r11
   239de:	5a                   	pop    rdx
   239df:	85 c0                	test   eax,eax
   239e1:	0f 88 35 6a 00 00    	js     2a41c <JS_CallInternal+0x787c>
   239e7:	4c 8b 95 c8 fd ff ff 	mov    r10,QWORD PTR [rbp-0x238]
   239ee:	48 8b 85 c0 fd ff ff 	mov    rax,QWORD PTR [rbp-0x240]
   239f5:	48 8b b5 b0 fd ff ff 	mov    rsi,QWORD PTR [rbp-0x250]
   239fc:	48 8b 95 b8 fd ff ff 	mov    rdx,QWORD PTR [rbp-0x248]
   23a03:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   23a0a:	4c 89 d1             	mov    rcx,r10
   23a0d:	49 89 c0             	mov    r8,rax
   23a10:	4c 89 95 d0 fd ff ff 	mov    QWORD PTR [rbp-0x230],r10
   23a17:	48 89 85 d8 fd ff ff 	mov    QWORD PTR [rbp-0x228],rax
   23a1e:	e8 cd a7 ff ff       	call   1e1f0 <js_method_set_home_object>
   23a23:	8b 85 24 fe ff ff    	mov    eax,DWORD PTR [rbp-0x1dc]
   23a29:	48 83 ec 08          	sub    rsp,0x8
   23a2d:	8b 8d 50 fe ff ff    	mov    ecx,DWORD PTR [rbp-0x1b0]
   23a33:	4c 8b 85 38 fe ff ff 	mov    r8,QWORD PTR [rbp-0x1c8]
   23a3a:	4c 8b 8d 28 fe ff ff 	mov    r9,QWORD PTR [rbp-0x1d8]
   23a41:	48 8b b5 d0 fd ff ff 	mov    rsi,QWORD PTR [rbp-0x230]
   23a48:	48 8b 95 d8 fd ff ff 	mov    rdx,QWORD PTR [rbp-0x228]
   23a4f:	50                   	push   rax
   23a50:	ff b5 e8 fd ff ff    	push   QWORD PTR [rbp-0x218]
   23a56:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   23a5d:	ff b5 e0 fd ff ff    	push   QWORD PTR [rbp-0x220]
   23a63:	ff b5 18 fe ff ff    	push   QWORD PTR [rbp-0x1e8]
   23a69:	ff b5 10 fe ff ff    	push   QWORD PTR [rbp-0x1f0]
   23a6f:	e8 fc b8 00 00       	call   2f370 <JS_DefineProperty>
   23a74:	48 83 c4 30          	add    rsp,0x30
   23a78:	89 c1                	mov    ecx,eax
   23a7a:	49 8b 54 24 08       	mov    rdx,QWORD PTR [r12+0x8]
   23a7f:	49 8b 34 24          	mov    rsi,QWORD PTR [r12]
   23a83:	83 fa f6             	cmp    edx,0xfffffff6
   23a86:	76 11                	jbe    23a99 <JS_CallInternal+0xef9>
   23a88:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   23a8b:	83 e8 01             	sub    eax,0x1
   23a8e:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   23a91:	85 c0                	test   eax,eax
   23a93:	0f 8e b7 68 00 00    	jle    2a350 <JS_CallInternal+0x77b0>
   23a99:	45 84 f6             	test   r14b,r14b
   23a9c:	0f 85 31 58 00 00    	jne    292d3 <JS_CallInternal+0x6733>
   23aa2:	8b 85 40 fe ff ff    	mov    eax,DWORD PTR [rbp-0x1c0]
   23aa8:	4d 8d 65 01          	lea    r12,[r13+0x1]
   23aac:	83 c0 01             	add    eax,0x1
   23aaf:	48 98                	cdqe
   23ab1:	48 c1 e0 04          	shl    rax,0x4
   23ab5:	48 29 c3             	sub    rbx,rax
   23ab8:	85 c9                	test   ecx,ecx
   23aba:	0f 88 80 f8 ff ff    	js     23340 <JS_CallInternal+0x7a0>
   23ac0:	41 0f b6 45 01       	movzx  eax,BYTE PTR [r13+0x1]
   23ac5:	4d 8d 65 02          	lea    r12,[r13+0x2]
   23ac9:	49 89 c5             	mov    r13,rax
   23acc:	41 ff 24 c7          	jmp    QWORD PTR [r15+rax*8]
   23ad0:	f3 0f 1e fa          	endbr64
   23ad4:	f3 0f 1e fa          	endbr64
   23ad8:	45 0f b7 0c 24       	movzx  r9d,WORD PTR [r12]
   23add:	49 89 db             	mov    r11,rbx
   23ae0:	49 8d 4c 24 02       	lea    rcx,[r12+0x2]
   23ae5:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   23aec:	48 89 8d 28 fe ff ff 	mov    QWORD PTR [rbp-0x1d8],rcx
   23af3:	4c 89 c8             	mov    rax,r9
   23af6:	44 89 8d 38 fe ff ff 	mov    DWORD PTR [rbp-0x1c8],r9d
   23afd:	48 c1 e0 04          	shl    rax,0x4
   23b01:	49 29 c3             	sub    r11,rax
   23b04:	48 89 85 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],rax
   23b0b:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   23b12:	49 8b 73 f0          	mov    rsi,QWORD PTR [r11-0x10]
   23b16:	49 8b 53 f8          	mov    rdx,QWORD PTR [r11-0x8]
   23b1a:	4d 8d 73 e0          	lea    r14,[r11-0x20]
   23b1e:	48 89 48 30          	mov    QWORD PTR [rax+0x30],rcx
   23b22:	4d 8b 46 08          	mov    r8,QWORD PTR [r14+0x8]
   23b26:	49 8b 4b e0          	mov    rcx,QWORD PTR [r11-0x20]
   23b2a:	6a 00                	push   0x0
   23b2c:	41 53                	push   r11
   23b2e:	4c 89 9d 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],r11
   23b35:	6a 03                	push   0x3
   23b37:	6a 00                	push   0x0
   23b39:	e8 62 f0 ff ff       	call   22ba0 <JS_CallInternal>
   23b3e:	48 83 c4 20          	add    rsp,0x20
   23b42:	4c 8b 9d 50 fe ff ff 	mov    r11,QWORD PTR [rbp-0x1b0]
   23b49:	4c 8b 95 40 fe ff ff 	mov    r10,QWORD PTR [rbp-0x1c0]
   23b50:	83 fa 06             	cmp    edx,0x6
   23b53:	48 89 d1             	mov    rcx,rdx
   23b56:	0f 84 3b 69 00 00    	je     2a497 <JS_CallInternal+0x78f7>
   23b5c:	41 83 fd 25          	cmp    r13d,0x25
   23b60:	0f 84 2d f7 ff ff    	je     23293 <JS_CallInternal+0x6f3>
   23b66:	4f 8d 2c 13          	lea    r13,[r11+r10*1]
   23b6a:	48 89 9d 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],rbx
   23b71:	4c 89 f3             	mov    rbx,r14
   23b74:	49 89 d6             	mov    r14,rdx
   23b77:	4c 89 a5 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],r12
   23b7e:	4d 89 ec             	mov    r12,r13
   23b81:	49 89 c5             	mov    r13,rax
   23b84:	eb 17                	jmp    23b9d <JS_CallInternal+0xffd>
   23b86:	66 2e 0f 1f 84 00 00 	cs nop WORD PTR [rax+rax*1+0x0]
   23b8d:	00 00 00 
   23b90:	48 83 c3 10          	add    rbx,0x10
   23b94:	4c 39 e3             	cmp    rbx,r12
   23b97:	0f 84 e0 54 00 00    	je     2907d <JS_CallInternal+0x64dd>
   23b9d:	48 8b 4b 08          	mov    rcx,QWORD PTR [rbx+0x8]
   23ba1:	48 8b 33             	mov    rsi,QWORD PTR [rbx]
   23ba4:	83 f9 f6             	cmp    ecx,0xfffffff6
   23ba7:	76 e7                	jbe    23b90 <JS_CallInternal+0xff0>
   23ba9:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   23bac:	8d 50 ff             	lea    edx,[rax-0x1]
   23baf:	89 56 fc             	mov    DWORD PTR [rsi-0x4],edx
   23bb2:	85 d2                	test   edx,edx
   23bb4:	7f da                	jg     23b90 <JS_CallInternal+0xff0>
   23bb6:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   23bbd:	48 89 ca             	mov    rdx,rcx
   23bc0:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   23bc4:	e8 a7 8d ff ff       	call   1c970 <__JS_FreeValueRT>
   23bc9:	eb c5                	jmp    23b90 <JS_CallInternal+0xff0>
   23bcb:	f3 0f 1e fa          	endbr64
   23bcf:	f3 0f 1e fa          	endbr64
   23bd3:	31 c9                	xor    ecx,ecx
   23bd5:	b8 02 00 00 00       	mov    eax,0x2
   23bda:	e9 e1 f7 ff ff       	jmp    233c0 <JS_CallInternal+0x820>
   23bdf:	f3 0f 1e fa          	endbr64
   23be3:	f3 0f 1e fa          	endbr64
   23be7:	48 8b 85 d8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x128]
   23bee:	4c 89 e2             	mov    rdx,r12
   23bf1:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   23bf8:	44 89 e9             	mov    ecx,r13d
   23bfb:	48 8d 35 66 d2 0a 00 	lea    rsi,[rip+0xad266]        # d0e68 <_IO_stdin_used+0x3e68>
   23c02:	48 2b 50 18          	sub    rdx,QWORD PTR [rax+0x18]
   23c06:	31 c0                	xor    eax,eax
   23c08:	83 ea 01             	sub    edx,0x1
   23c0b:	e8 50 f8 00 00       	call   33460 <JS_ThrowInternalError>
   23c10:	e9 2b f7 ff ff       	jmp    23340 <JS_CallInternal+0x7a0>
   23c15:	f3 0f 1e fa          	endbr64
   23c19:	f3 0f 1e fa          	endbr64
   23c1d:	41 0f b7 04 24       	movzx  eax,WORD PTR [r12]
   23c22:	48 8b bd 98 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x168]
   23c29:	4d 8d 74 24 02       	lea    r14,[r12+0x2]
   23c2e:	48 8d 0c c5 00 00 00 	lea    rcx,[rax*8+0x0]
   23c35:	00 
   23c36:	48 8b 04 c7          	mov    rax,QWORD PTR [rdi+rax*8]
   23c3a:	48 8b 40 18          	mov    rax,QWORD PTR [rax+0x18]
   23c3e:	48 8b 10             	mov    rdx,QWORD PTR [rax]
   23c41:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
   23c45:	83 f8 04             	cmp    eax,0x4
   23c48:	0f 84 9a 68 00 00    	je     2a4e8 <JS_CallInternal+0x7948>
   23c4e:	83 f8 f6             	cmp    eax,0xfffffff6
   23c51:	76 04                	jbe    23c57 <JS_CallInternal+0x10b7>
   23c53:	83 42 fc 01          	add    DWORD PTR [rdx-0x4],0x1
   23c57:	48 89 13             	mov    QWORD PTR [rbx],rdx
   23c5a:	48 89 43 08          	mov    QWORD PTR [rbx+0x8],rax
   23c5e:	41 0f b6 44 24 02    	movzx  eax,BYTE PTR [r12+0x2]
   23c64:	48 83 c3 10          	add    rbx,0x10
   23c68:	49 83 c4 03          	add    r12,0x3
   23c6c:	49 89 c5             	mov    r13,rax
   23c6f:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   23c73:	ff e0                	jmp    rax
   23c75:	f3 0f 1e fa          	endbr64
   23c79:	f3 0f 1e fa          	endbr64
   23c7d:	49 8d 44 24 02       	lea    rax,[r12+0x2]
   23c82:	45 0f b7 14 24       	movzx  r10d,WORD PTR [r12]
   23c87:	48 89 85 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],rax
   23c8e:	e9 e5 f2 ff ff       	jmp    22f78 <JS_CallInternal+0x3d8>
   23c93:	f3 0f 1e fa          	endbr64
   23c97:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   23c9e:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   23ca5:	44 89 ea             	mov    edx,r13d
   23ca8:	48 89 de             	mov    rsi,rbx
   23cab:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   23caf:	e8 5c 0d 03 00       	call   54a10 <js_binary_arith_slow>
   23cb4:	85 c0                	test   eax,eax
   23cb6:	0f 85 84 f6 ff ff    	jne    23340 <JS_CallInternal+0x7a0>
   23cbc:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   23cc1:	48 83 eb 10          	sub    rbx,0x10
   23cc5:	49 83 c4 01          	add    r12,0x1
   23cc9:	49 89 c5             	mov    r13,rax
   23ccc:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   23cd0:	ff e0                	jmp    rax
   23cd2:	f3 0f 1e fa          	endbr64
   23cd6:	45 0f b7 0c 24       	movzx  r9d,WORD PTR [r12]
   23cdb:	49 89 de             	mov    r14,rbx
   23cde:	4d 8d 54 24 02       	lea    r10,[r12+0x2]
   23ce3:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   23cea:	4c 89 95 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],r10
   23cf1:	4c 89 c8             	mov    rax,r9
   23cf4:	44 89 8d 40 fe ff ff 	mov    DWORD PTR [rbp-0x1c0],r9d
   23cfb:	48 c1 e0 04          	shl    rax,0x4
   23cff:	49 29 c6             	sub    r14,rax
   23d02:	48 89 85 38 fe ff ff 	mov    QWORD PTR [rbp-0x1c8],rax
   23d09:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   23d10:	4d 8b 46 f8          	mov    r8,QWORD PTR [r14-0x8]
   23d14:	49 8b 4e f0          	mov    rcx,QWORD PTR [r14-0x10]
   23d18:	4d 8d 6e e0          	lea    r13,[r14-0x20]
   23d1c:	49 8b 76 e0          	mov    rsi,QWORD PTR [r14-0x20]
   23d20:	49 8b 55 08          	mov    rdx,QWORD PTR [r13+0x8]
   23d24:	4c 89 50 30          	mov    QWORD PTR [rax+0x30],r10
   23d28:	6a 00                	push   0x0
   23d2a:	41 56                	push   r14
   23d2c:	e8 1f d6 06 00       	call   91350 <JS_CallConstructorInternal>
   23d31:	41 5b                	pop    r11
   23d33:	4c 8b 95 50 fe ff ff 	mov    r10,QWORD PTR [rbp-0x1b0]
   23d3a:	83 fa 06             	cmp    edx,0x6
   23d3d:	49 89 c1             	mov    r9,rax
   23d40:	49 89 d0             	mov    r8,rdx
   23d43:	58                   	pop    rax
   23d44:	0f 84 d8 7d 00 00    	je     2bb22 <JS_CallInternal+0x8f82>
   23d4a:	4c 8b 9d 38 fe ff ff 	mov    r11,QWORD PTR [rbp-0x1c8]
   23d51:	4d 01 de             	add    r14,r11
   23d54:	eb 17                	jmp    23d6d <JS_CallInternal+0x11cd>
   23d56:	66 2e 0f 1f 84 00 00 	cs nop WORD PTR [rax+rax*1+0x0]
   23d5d:	00 00 00 
   23d60:	49 83 c5 10          	add    r13,0x10
   23d64:	4d 39 f5             	cmp    r13,r14
   23d67:	0f 84 31 54 00 00    	je     2919e <JS_CallInternal+0x65fe>
   23d6d:	49 8b 55 08          	mov    rdx,QWORD PTR [r13+0x8]
   23d71:	49 8b 75 00          	mov    rsi,QWORD PTR [r13+0x0]
   23d75:	83 fa f6             	cmp    edx,0xfffffff6
   23d78:	76 e6                	jbe    23d60 <JS_CallInternal+0x11c0>
   23d7a:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   23d7d:	83 e8 01             	sub    eax,0x1
   23d80:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   23d83:	85 c0                	test   eax,eax
   23d85:	7f d9                	jg     23d60 <JS_CallInternal+0x11c0>
   23d87:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   23d8e:	4c 89 85 38 fe ff ff 	mov    QWORD PTR [rbp-0x1c8],r8
   23d95:	4c 89 8d 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],r9
   23d9c:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   23da0:	e8 cb 8b ff ff       	call   1c970 <__JS_FreeValueRT>
   23da5:	4c 8b 85 38 fe ff ff 	mov    r8,QWORD PTR [rbp-0x1c8]
   23dac:	4c 8b 8d 50 fe ff ff 	mov    r9,QWORD PTR [rbp-0x1b0]
   23db3:	eb ab                	jmp    23d60 <JS_CallInternal+0x11c0>
   23db5:	f3 0f 1e fa          	endbr64
   23db9:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   23dc0:	4c 8b 43 f8          	mov    r8,QWORD PTR [rbx-0x8]
   23dc4:	4c 8d 73 f0          	lea    r14,[rbx-0x10]
   23dc8:	48 8b 4b f0          	mov    rcx,QWORD PTR [rbx-0x10]
   23dcc:	48 8b 73 e0          	mov    rsi,QWORD PTR [rbx-0x20]
   23dd0:	48 8b 53 e8          	mov    rdx,QWORD PTR [rbx-0x18]
   23dd4:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   23ddb:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   23ddf:	e8 8c 54 08 00       	call   a9270 <js_dynamic_import>
   23de4:	49 89 d0             	mov    r8,rdx
   23de7:	83 fa 06             	cmp    edx,0x6
   23dea:	0f 84 50 f5 ff ff    	je     23340 <JS_CallInternal+0x7a0>
   23df0:	48 8b 53 e8          	mov    rdx,QWORD PTR [rbx-0x18]
   23df4:	48 8b 73 e0          	mov    rsi,QWORD PTR [rbx-0x20]
   23df8:	83 fa f6             	cmp    edx,0xfffffff6
   23dfb:	76 11                	jbe    23e0e <JS_CallInternal+0x126e>
   23dfd:	8b 5e fc             	mov    ebx,DWORD PTR [rsi-0x4]
   23e00:	8d 4b ff             	lea    ecx,[rbx-0x1]
   23e03:	89 4e fc             	mov    DWORD PTR [rsi-0x4],ecx
   23e06:	85 c9                	test   ecx,ecx
   23e08:	0f 8e cc 6b 00 00    	jle    2a9da <JS_CallInternal+0x7e3a>
   23e0e:	49 8b 56 08          	mov    rdx,QWORD PTR [r14+0x8]
   23e12:	49 8b 36             	mov    rsi,QWORD PTR [r14]
   23e15:	83 fa f6             	cmp    edx,0xfffffff6
   23e18:	76 11                	jbe    23e2b <JS_CallInternal+0x128b>
   23e1a:	8b 5e fc             	mov    ebx,DWORD PTR [rsi-0x4]
   23e1d:	8d 4b ff             	lea    ecx,[rbx-0x1]
   23e20:	89 4e fc             	mov    DWORD PTR [rsi-0x4],ecx
   23e23:	85 c9                	test   ecx,ecx
   23e25:	0f 8e e0 6b 00 00    	jle    2aa0b <JS_CallInternal+0x7e6b>
   23e2b:	49 89 46 f0          	mov    QWORD PTR [r14-0x10],rax
   23e2f:	4c 89 f3             	mov    rbx,r14
   23e32:	49 83 c4 01          	add    r12,0x1
   23e36:	4d 89 46 f8          	mov    QWORD PTR [r14-0x8],r8
   23e3a:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   23e40:	49 89 c5             	mov    r13,rax
   23e43:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   23e47:	ff e0                	jmp    rax
   23e49:	f3 0f 1e fa          	endbr64
   23e4d:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   23e54:	48 8b 73 f0          	mov    rsi,QWORD PTR [rbx-0x10]
   23e58:	48 8b 53 f8          	mov    rdx,QWORD PTR [rbx-0x8]
   23e5c:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   23e63:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   23e67:	e8 34 e6 ff ff       	call   224a0 <JS_GetPrototype>
   23e6c:	49 89 c6             	mov    r14,rax
   23e6f:	48 89 d1             	mov    rcx,rdx
   23e72:	83 fa 06             	cmp    edx,0x6
   23e75:	0f 84 c5 f4 ff ff    	je     23340 <JS_CallInternal+0x7a0>
   23e7b:	48 8b 53 f8          	mov    rdx,QWORD PTR [rbx-0x8]
   23e7f:	48 8b 73 f0          	mov    rsi,QWORD PTR [rbx-0x10]
   23e83:	83 fa f6             	cmp    edx,0xfffffff6
   23e86:	76 11                	jbe    23e99 <JS_CallInternal+0x12f9>
   23e88:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   23e8b:	83 e8 01             	sub    eax,0x1
   23e8e:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   23e91:	85 c0                	test   eax,eax
   23e93:	0f 8e f6 6a 00 00    	jle    2a98f <JS_CallInternal+0x7def>
   23e99:	4c 89 73 f0          	mov    QWORD PTR [rbx-0x10],r14
   23e9d:	49 83 c4 01          	add    r12,0x1
   23ea1:	48 89 4b f8          	mov    QWORD PTR [rbx-0x8],rcx
   23ea5:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   23eab:	49 89 c5             	mov    r13,rax
   23eae:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   23eb2:	ff e0                	jmp    rax
   23eb4:	f3 0f 1e fa          	endbr64
   23eb8:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   23ebf:	4d 8d 54 24 02       	lea    r10,[r12+0x2]
   23ec4:	48 8b 73 d0          	mov    rsi,QWORD PTR [rbx-0x30]
   23ec8:	4c 8d 73 e0          	lea    r14,[rbx-0x20]
   23ecc:	45 0f b7 0c 24       	movzx  r9d,WORD PTR [r12]
   23ed1:	48 8b 53 d8          	mov    rdx,QWORD PTR [rbx-0x28]
   23ed5:	4d 89 f0             	mov    r8,r14
   23ed8:	b9 02 00 00 00       	mov    ecx,0x2
   23edd:	4c 89 50 30          	mov    QWORD PTR [rax+0x30],r10
   23ee1:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   23ee8:	4c 89 95 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],r10
   23eef:	e8 7c da 07 00       	call   a1970 <js_function_apply>
   23ef4:	4c 8b 95 50 fe ff ff 	mov    r10,QWORD PTR [rbp-0x1b0]
   23efb:	83 fa 06             	cmp    edx,0x6
   23efe:	49 89 c1             	mov    r9,rax
   23f01:	49 89 d0             	mov    r8,rdx
   23f04:	0f 84 4a 7a 00 00    	je     2b954 <JS_CallInternal+0x8db4>
   23f0a:	48 8b 53 d8          	mov    rdx,QWORD PTR [rbx-0x28]
   23f0e:	48 8b 73 d0          	mov    rsi,QWORD PTR [rbx-0x30]
   23f12:	83 fa f6             	cmp    edx,0xfffffff6
   23f15:	76 11                	jbe    23f28 <JS_CallInternal+0x1388>
   23f17:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   23f1a:	83 e8 01             	sub    eax,0x1
   23f1d:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   23f20:	85 c0                	test   eax,eax
   23f22:	0f 8e ac 68 00 00    	jle    2a7d4 <JS_CallInternal+0x7c34>
   23f28:	49 8b 56 08          	mov    rdx,QWORD PTR [r14+0x8]
   23f2c:	49 8b 36             	mov    rsi,QWORD PTR [r14]
   23f2f:	83 fa f6             	cmp    edx,0xfffffff6
   23f32:	76 11                	jbe    23f45 <JS_CallInternal+0x13a5>
   23f34:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   23f37:	83 e8 01             	sub    eax,0x1
   23f3a:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   23f3d:	85 c0                	test   eax,eax
   23f3f:	0f 8e c0 68 00 00    	jle    2a805 <JS_CallInternal+0x7c65>
   23f45:	48 8b 53 f8          	mov    rdx,QWORD PTR [rbx-0x8]
   23f49:	48 8b 73 f0          	mov    rsi,QWORD PTR [rbx-0x10]
   23f4d:	83 fa f6             	cmp    edx,0xfffffff6
   23f50:	76 11                	jbe    23f63 <JS_CallInternal+0x13c3>
   23f52:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   23f55:	83 e8 01             	sub    eax,0x1
   23f58:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   23f5b:	85 c0                	test   eax,eax
   23f5d:	0f 8e 40 68 00 00    	jle    2a7a3 <JS_CallInternal+0x7c03>
   23f63:	4c 89 4b d0          	mov    QWORD PTR [rbx-0x30],r9
   23f67:	49 83 c4 03          	add    r12,0x3
   23f6b:	4c 89 43 d8          	mov    QWORD PTR [rbx-0x28],r8
   23f6f:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   23f75:	4c 89 f3             	mov    rbx,r14
   23f78:	49 89 c5             	mov    r13,rax
   23f7b:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   23f7f:	ff e0                	jmp    rax
   23f81:	f3 0f 1e fa          	endbr64
   23f85:	41 0f b7 14 24       	movzx  edx,WORD PTR [r12]
   23f8a:	49 8d 4c 24 02       	lea    rcx,[r12+0x2]
   23f8f:	48 89 8d 38 fe ff ff 	mov    QWORD PTR [rbp-0x1c8],rcx
   23f96:	31 c9                	xor    ecx,ecx
   23f98:	49 89 d6             	mov    r14,rdx
   23f9b:	89 95 50 fe ff ff    	mov    DWORD PTR [rbp-0x1b0],edx
   23fa1:	49 c1 e6 04          	shl    r14,0x4
   23fa5:	48 89 95 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],rdx
   23fac:	ba 02 00 00 00       	mov    edx,0x2
   23fb1:	4c 29 f3             	sub    rbx,r14
   23fb4:	49 89 dd             	mov    r13,rbx
   23fb7:	48 8b 9d e8 fe ff ff 	mov    rbx,QWORD PTR [rbp-0x118]
   23fbe:	48 8b 73 30          	mov    rsi,QWORD PTR [rbx+0x30]
   23fc2:	48 89 df             	mov    rdi,rbx
   23fc5:	83 46 fc 01          	add    DWORD PTR [rsi-0x4],0x1
   23fc9:	e8 92 28 02 00       	call   46860 <JS_NewObjectFromShape>
   23fce:	49 89 c0             	mov    r8,rax
   23fd1:	48 89 d1             	mov    rcx,rdx
   23fd4:	83 fa 06             	cmp    edx,0x6
   23fd7:	0f 84 c5 7b 00 00    	je     2bba2 <JS_CallInternal+0x9002>
   23fdd:	8b 95 50 fe ff ff    	mov    edx,DWORD PTR [rbp-0x1b0]
   23fe3:	85 d2                	test   edx,edx
   23fe5:	0f 85 b5 59 00 00    	jne    299a0 <JS_CallInternal+0x6e00>
   23feb:	4d 89 45 00          	mov    QWORD PTR [r13+0x0],r8
   23fef:	49 8d 5d 10          	lea    rbx,[r13+0x10]
   23ff3:	49 83 c4 03          	add    r12,0x3
   23ff7:	49 89 4d 08          	mov    QWORD PTR [r13+0x8],rcx
   23ffb:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   24001:	49 89 c5             	mov    r13,rax
   24004:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   24008:	ff e0                	jmp    rax
   2400a:	f3 0f 1e fa          	endbr64
   2400e:	41 8b 04 24          	mov    eax,DWORD PTR [r12]
   24012:	4c 8b 5b f8          	mov    r11,QWORD PTR [rbx-0x8]
   24016:	4c 8b 53 f0          	mov    r10,QWORD PTR [rbx-0x10]
   2401a:	48 8d 14 40          	lea    rdx,[rax+rax*2]
   2401e:	48 8b 85 d8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x128]
   24025:	48 8b 40 60          	mov    rax,QWORD PTR [rax+0x60]
   24029:	4c 8d 34 d0          	lea    r14,[rax+rdx*8]
   2402d:	49 8d 44 24 04       	lea    rax,[r12+0x4]
   24032:	48 89 85 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],rax
   24039:	41 83 fb ff          	cmp    r11d,0xffffffff
   2403d:	0f 85 e1 72 00 00    	jne    2b324 <JS_CallInternal+0x8784>
   24043:	45 8b 42 10          	mov    r8d,DWORD PTR [r10+0x10]
   24047:	4d 8b 4a 18          	mov    r9,QWORD PTR [r10+0x18]
   2404b:	41 81 e0 08 00 ff ff 	and    r8d,0xffff0008
   24052:	41 81 f8 00 00 01 00 	cmp    r8d,0x10000
   24059:	0f 84 5a 60 00 00    	je     2a0b9 <JS_CallInternal+0x7519>
   2405f:	41 8b 4e 14          	mov    ecx,DWORD PTR [r14+0x14]
   24063:	4d 89 cd             	mov    r13,r9
   24066:	4c 89 d2             	mov    rdx,r10
   24069:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]
   24070:	41 8b 45 18          	mov    eax,DWORD PTR [r13+0x18]
   24074:	89 ce                	mov    esi,ecx
   24076:	21 c6                	and    esi,eax
   24078:	41 8b 74 b5 38       	mov    esi,DWORD PTR [r13+rsi*4+0x38]
   2407d:	48 85 f6             	test   rsi,rsi
   24080:	0f 84 5e 4e 00 00    	je     28ee4 <JS_CallInternal+0x6344>
   24086:	48 8d 3c 85 34 00 00 	lea    rdi,[rax*4+0x34]
   2408d:	00 
   2408e:	48 8d 04 f7          	lea    rax,[rdi+rsi*8]
   24092:	4c 01 e8             	add    rax,r13
   24095:	3b 48 04             	cmp    ecx,DWORD PTR [rax+0x4]
   24098:	0f 85 38 4e 00 00    	jne    28ed6 <JS_CallInternal+0x6336>
   2409e:	80 78 03 3f          	cmp    BYTE PTR [rax+0x3],0x3f
   240a2:	0f 87 88 52 00 00    	ja     29330 <JS_CallInternal+0x6790>
   240a8:	48 8b 42 20          	mov    rax,QWORD PTR [rdx+0x20]
   240ac:	48 c1 e6 04          	shl    rsi,0x4
   240b0:	48 83 ee 10          	sub    rsi,0x10
   240b4:	48 01 f0             	add    rax,rsi
   240b7:	48 8b 38             	mov    rdi,QWORD PTR [rax]
   240ba:	48 8b 48 08          	mov    rcx,QWORD PTR [rax+0x8]
   240be:	48 89 bd 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],rdi
   240c5:	83 f9 f6             	cmp    ecx,0xfffffff6
   240c8:	76 04                	jbe    240ce <JS_CallInternal+0x152e>
   240ca:	83 47 fc 01          	add    DWORD PTR [rdi-0x4],0x1
   240ce:	49 39 d2             	cmp    r10,rdx
   240d1:	0f 84 9d 83 00 00    	je     2c474 <JS_CallInternal+0x98d4>
   240d7:	41 81 f8 00 00 01 00 	cmp    r8d,0x10000
   240de:	0f 84 d0 82 00 00    	je     2c3b4 <JS_CallInternal+0x9814>
   240e4:	48 8b 85 40 fe ff ff 	mov    rax,QWORD PTR [rbp-0x1c0]
   240eb:	48 89 03             	mov    QWORD PTR [rbx],rax
   240ee:	49 83 c4 05          	add    r12,0x5
   240f2:	48 83 c3 10          	add    rbx,0x10
   240f6:	48 89 4b f8          	mov    QWORD PTR [rbx-0x8],rcx
   240fa:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   24100:	49 89 c5             	mov    r13,rax
   24103:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   24107:	ff e0                	jmp    rax
   24109:	f3 0f 1e fa          	endbr64
   2410d:	41 8b 04 24          	mov    eax,DWORD PTR [r12]
   24111:	4c 8b 5b f8          	mov    r11,QWORD PTR [rbx-0x8]
   24115:	4c 8b 53 f0          	mov    r10,QWORD PTR [rbx-0x10]
   24119:	48 8d 14 40          	lea    rdx,[rax+rax*2]
   2411d:	48 8b 85 d8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x128]
   24124:	48 8b 40 60          	mov    rax,QWORD PTR [rax+0x60]
   24128:	4c 8d 34 d0          	lea    r14,[rax+rdx*8]
   2412c:	49 8d 44 24 04       	lea    rax,[r12+0x4]
   24131:	48 89 85 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],rax
   24138:	41 83 fb ff          	cmp    r11d,0xffffffff
   2413c:	0f 85 44 77 00 00    	jne    2b886 <JS_CallInternal+0x8ce6>
   24142:	45 8b 42 10          	mov    r8d,DWORD PTR [r10+0x10]
   24146:	4d 8b 4a 18          	mov    r9,QWORD PTR [r10+0x18]
   2414a:	41 81 e0 08 00 ff ff 	and    r8d,0xffff0008
   24151:	41 81 f8 00 00 01 00 	cmp    r8d,0x10000
   24158:	0f 84 ba 5c 00 00    	je     29e18 <JS_CallInternal+0x7278>
   2415e:	41 8b 4e 14          	mov    ecx,DWORD PTR [r14+0x14]
   24162:	4d 89 cd             	mov    r13,r9
   24165:	4c 89 d2             	mov    rdx,r10
   24168:	0f 1f 84 00 00 00 00 	nop    DWORD PTR [rax+rax*1+0x0]
   2416f:	00 
   24170:	41 8b 45 18          	mov    eax,DWORD PTR [r13+0x18]
   24174:	89 ce                	mov    esi,ecx
   24176:	21 c6                	and    esi,eax
   24178:	41 8b 74 b5 38       	mov    esi,DWORD PTR [r13+rsi*4+0x38]
   2417d:	48 85 f6             	test   rsi,rsi
   24180:	0f 84 8c 4d 00 00    	je     28f12 <JS_CallInternal+0x6372>
   24186:	48 8d 3c 85 34 00 00 	lea    rdi,[rax*4+0x34]
   2418d:	00 
   2418e:	48 8d 04 f7          	lea    rax,[rdi+rsi*8]
   24192:	4c 01 e8             	add    rax,r13
   24195:	3b 48 04             	cmp    ecx,DWORD PTR [rax+0x4]
   24198:	0f 85 66 4d 00 00    	jne    28f04 <JS_CallInternal+0x6364>
   2419e:	80 78 03 3f          	cmp    BYTE PTR [rax+0x3],0x3f
   241a2:	0f 87 7c 52 00 00    	ja     29424 <JS_CallInternal+0x6884>
   241a8:	48 8b 42 20          	mov    rax,QWORD PTR [rdx+0x20]
   241ac:	48 c1 e6 04          	shl    rsi,0x4
   241b0:	48 8d 4e f0          	lea    rcx,[rsi-0x10]
   241b4:	48 01 c8             	add    rax,rcx
   241b7:	48 8b 38             	mov    rdi,QWORD PTR [rax]
   241ba:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
   241be:	48 89 bd 38 fe ff ff 	mov    QWORD PTR [rbp-0x1c8],rdi
   241c5:	83 f8 f6             	cmp    eax,0xfffffff6
   241c8:	76 04                	jbe    241ce <JS_CallInternal+0x162e>
   241ca:	83 47 fc 01          	add    DWORD PTR [rdi-0x4],0x1
   241ce:	48 8d 7b f0          	lea    rdi,[rbx-0x10]
   241d2:	48 89 bd 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],rdi
   241d9:	4c 39 d2             	cmp    rdx,r10
   241dc:	0f 84 57 81 00 00    	je     2c339 <JS_CallInternal+0x9799>
   241e2:	41 81 f8 00 00 01 00 	cmp    r8d,0x10000
   241e9:	0f 84 88 80 00 00    	je     2c277 <JS_CallInternal+0x96d7>
   241ef:	4c 8b ad 38 fe ff ff 	mov    r13,QWORD PTR [rbp-0x1c8]
   241f6:	48 8b 8d 50 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x1b0]
   241fd:	48 8b 51 08          	mov    rdx,QWORD PTR [rcx+0x8]
   24201:	48 8b 31             	mov    rsi,QWORD PTR [rcx]
   24204:	83 fa f6             	cmp    edx,0xfffffff6
   24207:	76 11                	jbe    2421a <JS_CallInternal+0x167a>
   24209:	8b 4e fc             	mov    ecx,DWORD PTR [rsi-0x4]
   2420c:	83 e9 01             	sub    ecx,0x1
   2420f:	89 4e fc             	mov    DWORD PTR [rsi-0x4],ecx
   24212:	85 c9                	test   ecx,ecx
   24214:	0f 8e 52 67 00 00    	jle    2a96c <JS_CallInternal+0x7dcc>
   2421a:	4c 89 6b f0          	mov    QWORD PTR [rbx-0x10],r13
   2421e:	49 83 c4 05          	add    r12,0x5
   24222:	48 89 43 f8          	mov    QWORD PTR [rbx-0x8],rax
   24226:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   2422c:	49 89 c5             	mov    r13,rax
   2422f:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   24233:	ff e0                	jmp    rax
   24235:	f3 0f 1e fa          	endbr64
   24239:	48 8b 43 e0          	mov    rax,QWORD PTR [rbx-0x20]
   2423d:	4c 8d 6b e0          	lea    r13,[rbx-0x20]
   24241:	4c 8d 73 f0          	lea    r14,[rbx-0x10]
   24245:	48 8b 4b f0          	mov    rcx,QWORD PTR [rbx-0x10]
   24249:	49 8b 5e 08          	mov    rbx,QWORD PTR [r14+0x8]
   2424d:	48 89 85 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],rax
   24254:	49 8b 45 08          	mov    rax,QWORD PTR [r13+0x8]
   24258:	48 89 8d 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],rcx
   2425f:	48 89 85 38 fe ff ff 	mov    QWORD PTR [rbp-0x1c8],rax
   24266:	83 fb f9             	cmp    ebx,0xfffffff9
   24269:	0f 85 63 5f 00 00    	jne    2a1d2 <JS_CallInternal+0x7632>
   2426f:	83 f8 f9             	cmp    eax,0xfffffff9
   24272:	0f 85 5a 5f 00 00    	jne    2a1d2 <JS_CallInternal+0x7632>
   24278:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2427f:	ba 12 00 00 00       	mov    edx,0x12
   24284:	48 8d 8d 50 ff ff ff 	lea    rcx,[rbp-0xb0]
   2428b:	48 c7 85 50 ff ff ff 	mov    QWORD PTR [rbp-0xb0],0x0
   24292:	00 00 00 00 
   24296:	48 c7 85 58 ff ff ff 	mov    QWORD PTR [rbp-0xa8],0x0
   2429d:	00 00 00 00 
   242a1:	48 8b 77 48          	mov    rsi,QWORD PTR [rdi+0x48]
   242a5:	83 46 fc 01          	add    DWORD PTR [rsi-0x4],0x1
   242a9:	e8 b2 25 02 00       	call   46860 <JS_NewObjectFromShape>
   242ae:	83 fa 06             	cmp    edx,0x6
   242b1:	0f 84 30 5f 00 00    	je     2a1e7 <JS_CallInternal+0x7647>
   242b7:	f3 0f 7e 85 40 fe ff 	movq   xmm0,QWORD PTR [rbp-0x1c0]
   242be:	ff 
   242bf:	0f 16 85 50 fe ff ff 	movhps xmm0,QWORD PTR [rbp-0x1b0]
   242c6:	0f 11 40 28          	movups XMMWORD PTR [rax+0x28],xmm0
   242ca:	49 89 45 00          	mov    QWORD PTR [r13+0x0],rax
   242ce:	49 89 55 08          	mov    QWORD PTR [r13+0x8],rdx
   242d2:	41 83 7e f8 06       	cmp    DWORD PTR [r14-0x8],0x6
   242d7:	0f 84 a1 75 00 00    	je     2b87e <JS_CallInternal+0x8cde>
   242dd:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   242e2:	4c 89 f3             	mov    rbx,r14
   242e5:	49 83 c4 01          	add    r12,0x1
   242e9:	49 89 c5             	mov    r13,rax
   242ec:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   242f0:	ff e0                	jmp    rax
   242f2:	f3 0f 1e fa          	endbr64
   242f6:	41 0f b7 04 24       	movzx  eax,WORD PTR [r12]
   242fb:	48 8b 53 f0          	mov    rdx,QWORD PTR [rbx-0x10]
   242ff:	48 8d b5 f0 fe ff ff 	lea    rsi,[rbp-0x110]
   24306:	48 8b 8d c8 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x138]
   2430d:	4c 8b ad e8 fe ff ff 	mov    r13,QWORD PTR [rbp-0x118]
   24314:	66 89 85 38 fe ff ff 	mov    WORD PTR [rbp-0x1c8],ax
   2431b:	49 8d 44 24 02       	lea    rax,[r12+0x2]
   24320:	48 89 41 30          	mov    QWORD PTR [rcx+0x30],rax
   24324:	48 8b 4b f8          	mov    rcx,QWORD PTR [rbx-0x8]
   24328:	4c 89 ef             	mov    rdi,r13
   2432b:	48 89 85 10 fe ff ff 	mov    QWORD PTR [rbp-0x1f0],rax
   24332:	48 8d 43 f0          	lea    rax,[rbx-0x10]
   24336:	48 89 85 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],rax
   2433d:	e8 6e 0a 06 00       	call   84db0 <build_arg_list>
   24342:	49 89 c6             	mov    r14,rax
   24345:	48 85 c0             	test   rax,rax
   24348:	0f 84 e8 65 00 00    	je     2a936 <JS_CallInternal+0x7d96>
   2434e:	f3 41 0f 6f 9d 70 01 	movdqu xmm3,XMMWORD PTR [r13+0x170]
   24355:	00 00 
   24357:	48 8b 43 e0          	mov    rax,QWORD PTR [rbx-0x20]
   2435b:	41 b8 01 00 00 00    	mov    r8d,0x1
   24361:	4c 8b 6b e8          	mov    r13,QWORD PTR [rbx-0x18]
   24365:	0f 29 9d 40 fe ff ff 	movaps XMMWORD PTR [rbp-0x1c0],xmm3
   2436c:	48 8b 95 40 fe ff ff 	mov    rdx,QWORD PTR [rbp-0x1c0]
   24373:	48 89 c7             	mov    rdi,rax
   24376:	48 8b 8d 48 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x1b8]
   2437d:	4c 89 ee             	mov    rsi,r13
   24380:	48 89 85 28 fe ff ff 	mov    QWORD PTR [rbp-0x1d8],rax
   24387:	e8 a4 61 ff ff       	call   1a530 <js_strict_eq2.isra.0>
   2438c:	44 8b 95 f0 fe ff ff 	mov    r10d,DWORD PTR [rbp-0x110]
   24393:	85 c0                	test   eax,eax
   24395:	0f 84 ea 59 00 00    	je     29d85 <JS_CallInternal+0x71e5>
   2439b:	45 85 d2             	test   r10d,r10d
   2439e:	0f 84 d4 59 00 00    	je     29d78 <JS_CallInternal+0x71d8>
   243a4:	49 8b 0e             	mov    rcx,QWORD PTR [r14]
   243a7:	4d 8b 46 08          	mov    r8,QWORD PTR [r14+0x8]
   243ab:	0f b7 85 38 fe ff ff 	movzx  eax,WORD PTR [rbp-0x1c8]
   243b2:	48 83 ec 08          	sub    rsp,0x8
   243b6:	31 f6                	xor    esi,esi
   243b8:	44 89 95 28 fe ff ff 	mov    DWORD PTR [rbp-0x1d8],r10d
   243bf:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   243c6:	41 b9 02 00 00 00    	mov    r9d,0x2
   243cc:	ba 03 00 00 00       	mov    edx,0x3
   243d1:	83 e8 02             	sub    eax,0x2
   243d4:	50                   	push   rax
   243d5:	e8 e6 e9 01 00       	call   42dc0 <JS_EvalObject>
   243da:	44 8b 95 28 fe ff ff 	mov    r10d,DWORD PTR [rbp-0x1d8]
   243e1:	48 89 85 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],rax
   243e8:	49 89 d5             	mov    r13,rdx
   243eb:	58                   	pop    rax
   243ec:	5a                   	pop    rdx
   243ed:	45 85 d2             	test   r10d,r10d
   243f0:	0f 84 29 6d 00 00    	je     2b11f <JS_CallInternal+0x857f>
   243f6:	45 89 d0             	mov    r8d,r10d
   243f9:	48 8b 8d e8 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x118]
   24400:	48 89 9d 38 fe ff ff 	mov    QWORD PTR [rbp-0x1c8],rbx
   24407:	4c 89 f3             	mov    rbx,r14
   2440a:	49 c1 e0 04          	shl    r8,0x4
   2440e:	4c 89 a5 28 fe ff ff 	mov    QWORD PTR [rbp-0x1d8],r12
   24415:	4d 01 f0             	add    r8,r14
   24418:	48 8b 79 10          	mov    rdi,QWORD PTR [rcx+0x10]
   2441c:	4d 89 c4             	mov    r12,r8
   2441f:	eb 14                	jmp    24435 <JS_CallInternal+0x1895>
   24421:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]
   24428:	48 83 c3 10          	add    rbx,0x10
   2442c:	4c 39 e3             	cmp    rbx,r12
   2442f:	0f 84 9c 4d 00 00    	je     291d1 <JS_CallInternal+0x6631>
   24435:	48 8b 4b 08          	mov    rcx,QWORD PTR [rbx+0x8]
   24439:	48 8b 33             	mov    rsi,QWORD PTR [rbx]
   2443c:	83 f9 f6             	cmp    ecx,0xfffffff6
   2443f:	76 e7                	jbe    24428 <JS_CallInternal+0x1888>
   24441:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   24444:	8d 50 ff             	lea    edx,[rax-0x1]
   24447:	89 56 fc             	mov    DWORD PTR [rsi-0x4],edx
   2444a:	85 d2                	test   edx,edx
   2444c:	7f da                	jg     24428 <JS_CallInternal+0x1888>
   2444e:	48 89 ca             	mov    rdx,rcx
   24451:	e8 1a 85 ff ff       	call   1c970 <__JS_FreeValueRT>
   24456:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2445d:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   24461:	eb c5                	jmp    24428 <JS_CallInternal+0x1888>
   24463:	f3 0f 1e fa          	endbr64
   24467:	41 0f b7 0c 24       	movzx  ecx,WORD PTR [r12]
   2446c:	49 89 dd             	mov    r13,rbx
   2446f:	41 0f b7 7c 24 02    	movzx  edi,WORD PTR [r12+0x2]
   24475:	41 b8 01 00 00 00    	mov    r8d,0x1
   2447b:	48 89 c8             	mov    rax,rcx
   2447e:	89 8d 50 fe ff ff    	mov    DWORD PTR [rbp-0x1b0],ecx
   24484:	49 8d 4c 24 04       	lea    rcx,[r12+0x4]
   24489:	48 c1 e0 04          	shl    rax,0x4
   2448d:	66 89 bd 38 fe ff ff 	mov    WORD PTR [rbp-0x1c8],di
   24494:	49 29 c5             	sub    r13,rax
   24497:	49 89 c6             	mov    r14,rax
   2449a:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   244a1:	48 89 8d 28 fe ff ff 	mov    QWORD PTR [rbp-0x1d8],rcx
   244a8:	49 8b 7d f0          	mov    rdi,QWORD PTR [r13-0x10]
   244ac:	49 8b 75 f8          	mov    rsi,QWORD PTR [r13-0x8]
   244b0:	48 89 48 30          	mov    QWORD PTR [rax+0x30],rcx
   244b4:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   244bb:	f3 0f 6f b8 70 01 00 	movdqu xmm7,XMMWORD PTR [rax+0x170]
   244c2:	00 
   244c3:	0f 29 bd 40 fe ff ff 	movaps XMMWORD PTR [rbp-0x1c0],xmm7
   244ca:	48 8b 95 40 fe ff ff 	mov    rdx,QWORD PTR [rbp-0x1c0]
   244d1:	48 8b 8d 48 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x1b8]
   244d8:	e8 53 60 ff ff       	call   1a530 <js_strict_eq2.isra.0>
   244dd:	85 c0                	test   eax,eax
   244df:	0f 84 d4 57 00 00    	je     29cb9 <JS_CallInternal+0x7119>
   244e5:	8b bd 50 fe ff ff    	mov    edi,DWORD PTR [rbp-0x1b0]
   244eb:	85 ff                	test   edi,edi
   244ed:	0f 84 33 56 00 00    	je     29b26 <JS_CallInternal+0x6f86>
   244f3:	49 8b 4d 00          	mov    rcx,QWORD PTR [r13+0x0]
   244f7:	4d 8b 45 08          	mov    r8,QWORD PTR [r13+0x8]
   244fb:	0f b7 85 38 fe ff ff 	movzx  eax,WORD PTR [rbp-0x1c8]
   24502:	48 83 ec 08          	sub    rsp,0x8
   24506:	41 b9 02 00 00 00    	mov    r9d,0x2
   2450c:	31 f6                	xor    esi,esi
   2450e:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   24515:	ba 03 00 00 00       	mov    edx,0x3
   2451a:	83 e8 02             	sub    eax,0x2
   2451d:	50                   	push   rax
   2451e:	e8 9d e8 01 00       	call   42dc0 <JS_EvalObject>
   24523:	59                   	pop    rcx
   24524:	5e                   	pop    rsi
   24525:	49 89 c1             	mov    r9,rax
   24528:	49 89 d0             	mov    r8,rdx
   2452b:	49 8d 45 f0          	lea    rax,[r13-0x10]
   2452f:	4d 01 f5             	add    r13,r14
   24532:	49 89 c6             	mov    r14,rax
   24535:	41 83 f8 06          	cmp    r8d,0x6
   24539:	75 12                	jne    2454d <JS_CallInternal+0x19ad>
   2453b:	e9 d6 75 00 00       	jmp    2bb16 <JS_CallInternal+0x8f76>
   24540:	49 83 c6 10          	add    r14,0x10
   24544:	4d 39 ee             	cmp    r14,r13
   24547:	0f 84 1e 4c 00 00    	je     2916b <JS_CallInternal+0x65cb>
   2454d:	49 8b 56 08          	mov    rdx,QWORD PTR [r14+0x8]
   24551:	49 8b 36             	mov    rsi,QWORD PTR [r14]
   24554:	83 fa f6             	cmp    edx,0xfffffff6
   24557:	76 e7                	jbe    24540 <JS_CallInternal+0x19a0>
   24559:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   2455c:	83 e8 01             	sub    eax,0x1
   2455f:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   24562:	85 c0                	test   eax,eax
   24564:	7f da                	jg     24540 <JS_CallInternal+0x19a0>
   24566:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2456d:	4c 89 85 38 fe ff ff 	mov    QWORD PTR [rbp-0x1c8],r8
   24574:	4c 89 8d 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],r9
   2457b:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2457f:	e8 ec 83 ff ff       	call   1c970 <__JS_FreeValueRT>
   24584:	4c 8b 85 38 fe ff ff 	mov    r8,QWORD PTR [rbp-0x1c8]
   2458b:	4c 8b 8d 40 fe ff ff 	mov    r9,QWORD PTR [rbp-0x1c0]
   24592:	eb ac                	jmp    24540 <JS_CallInternal+0x19a0>
   24594:	f3 0f 1e fa          	endbr64
   24598:	41 0f b6 44 24 04    	movzx  eax,BYTE PTR [r12+0x4]
   2459e:	41 8b 34 24          	mov    esi,DWORD PTR [r12]
   245a2:	49 83 c4 05          	add    r12,0x5
   245a6:	3c 04                	cmp    al,0x4
   245a8:	0f 87 fb 5f 00 00    	ja     2a5a9 <JS_CallInternal+0x7a09>
   245ae:	48 8d 15 6f 2b 0b 00 	lea    rdx,[rip+0xb2b6f]        # d7124 <qjsc_repl_size+0x458>
   245b5:	48 63 04 82          	movsxd rax,DWORD PTR [rdx+rax*4]
   245b9:	48 01 d0             	add    rax,rdx
   245bc:	3e ff e0             	notrack jmp rax
   245bf:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   245c6:	48 8d 35 db c7 0a 00 	lea    rsi,[rip+0xac7db]        # d0da8 <_IO_stdin_used+0x3da8>
   245cd:	31 c0                	xor    eax,eax
   245cf:	e8 9c eb 00 00       	call   33170 <JS_ThrowReferenceError>
   245d4:	e9 67 ed ff ff       	jmp    23340 <JS_CallInternal+0x7a0>
   245d9:	48 8d 15 d2 8e 0a 00 	lea    rdx,[rip+0xa8ed2]        # cd4b2 <_IO_stdin_used+0x4b2>
   245e0:	85 f6                	test   esi,esi
   245e2:	0f 85 6e 7c 00 00    	jne    2c256 <JS_CallInternal+0x96b6>
   245e8:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   245ef:	48 8d 35 18 8f 0a 00 	lea    rsi,[rip+0xa8f18]        # cd50e <_IO_stdin_used+0x50e>
   245f6:	31 c0                	xor    eax,eax
   245f8:	e8 73 eb 00 00       	call   33170 <JS_ThrowReferenceError>
   245fd:	e9 3e ed ff ff       	jmp    23340 <JS_CallInternal+0x7a0>
   24602:	4c 8b bd e8 fe ff ff 	mov    r15,QWORD PTR [rbp-0x118]
   24609:	48 8d 45 80          	lea    rax,[rbp-0x80]
   2460d:	89 f2                	mov    edx,esi
   2460f:	48 89 c6             	mov    rsi,rax
   24612:	49 8b 7f 10          	mov    rdi,QWORD PTR [r15+0x10]
   24616:	e8 55 2d ff ff       	call   17370 <JS_AtomGetStrRT.constprop.0>
   2461b:	48 8d 35 d6 8e 0a 00 	lea    rsi,[rip+0xa8ed6]        # cd4f8 <_IO_stdin_used+0x4f8>
   24622:	4c 89 ff             	mov    rdi,r15
   24625:	48 89 c2             	mov    rdx,rax
   24628:	31 c0                	xor    eax,eax
   2462a:	e8 31 c6 00 00       	call   30c60 <JS_ThrowSyntaxError>
   2462f:	e9 0c ed ff ff       	jmp    23340 <JS_CallInternal+0x7a0>
   24634:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2463b:	e8 00 df 00 00       	call   32540 <JS_ThrowTypeErrorReadOnly.part.0>
   24640:	e9 fb ec ff ff       	jmp    23340 <JS_CallInternal+0x7a0>
   24645:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2464c:	48 8d 35 7d c7 0a 00 	lea    rsi,[rip+0xac77d]        # d0dd0 <_IO_stdin_used+0x3dd0>
   24653:	31 c0                	xor    eax,eax
   24655:	e8 26 ca 00 00       	call   31080 <JS_ThrowTypeError>
   2465a:	e9 e1 ec ff ff       	jmp    23340 <JS_CallInternal+0x7a0>
   2465f:	f3 0f 1e fa          	endbr64
   24663:	48 8b 53 f8          	mov    rdx,QWORD PTR [rbx-0x8]
   24667:	41 0f b7 04 24       	movzx  eax,WORD PTR [r12]
   2466c:	48 8b 4b f0          	mov    rcx,QWORD PTR [rbx-0x10]
   24670:	83 fa f6             	cmp    edx,0xfffffff6
   24673:	76 04                	jbe    24679 <JS_CallInternal+0x1ad9>
   24675:	83 41 fc 01          	add    DWORD PTR [rcx-0x4],0x1
   24679:	48 8b bd 90 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x170]
   24680:	48 c1 e0 04          	shl    rax,0x4
   24684:	48 01 f8             	add    rax,rdi
   24687:	4c 8b 40 08          	mov    r8,QWORD PTR [rax+0x8]
   2468b:	48 8b 30             	mov    rsi,QWORD PTR [rax]
   2468e:	48 89 50 08          	mov    QWORD PTR [rax+0x8],rdx
   24692:	48 89 08             	mov    QWORD PTR [rax],rcx
   24695:	41 83 f8 f6          	cmp    r8d,0xfffffff6
   24699:	76 11                	jbe    246ac <JS_CallInternal+0x1b0c>
   2469b:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   2469e:	83 e8 01             	sub    eax,0x1
   246a1:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   246a4:	85 c0                	test   eax,eax
   246a6:	0f 8e 9e 65 00 00    	jle    2ac4a <JS_CallInternal+0x80aa>
   246ac:	41 0f b6 44 24 02    	movzx  eax,BYTE PTR [r12+0x2]
   246b2:	49 83 c4 03          	add    r12,0x3
   246b6:	49 89 c5             	mov    r13,rax
   246b9:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   246bd:	ff e0                	jmp    rax
   246bf:	f3 0f 1e fa          	endbr64
   246c3:	41 0f b7 04 24       	movzx  eax,WORD PTR [r12]
   246c8:	48 8b 8d 90 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x170]
   246cf:	48 c1 e0 04          	shl    rax,0x4
   246d3:	48 01 c8             	add    rax,rcx
   246d6:	48 8b 10             	mov    rdx,QWORD PTR [rax]
   246d9:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
   246dd:	83 f8 f6             	cmp    eax,0xfffffff6
   246e0:	76 04                	jbe    246e6 <JS_CallInternal+0x1b46>
   246e2:	83 42 fc 01          	add    DWORD PTR [rdx-0x4],0x1
   246e6:	48 89 13             	mov    QWORD PTR [rbx],rdx
   246e9:	49 83 c4 03          	add    r12,0x3
   246ed:	48 83 c3 10          	add    rbx,0x10
   246f1:	48 89 43 f8          	mov    QWORD PTR [rbx-0x8],rax
   246f5:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   246fb:	49 89 c5             	mov    r13,rax
   246fe:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   24702:	ff e0                	jmp    rax
   24704:	f3 0f 1e fa          	endbr64
   24708:	48 8b 53 f8          	mov    rdx,QWORD PTR [rbx-0x8]
   2470c:	41 0f b7 04 24       	movzx  eax,WORD PTR [r12]
   24711:	48 8b 4b f0          	mov    rcx,QWORD PTR [rbx-0x10]
   24715:	83 fa f6             	cmp    edx,0xfffffff6
   24718:	76 04                	jbe    2471e <JS_CallInternal+0x1b7e>
   2471a:	83 41 fc 01          	add    DWORD PTR [rcx-0x4],0x1
   2471e:	48 8b bd b0 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x150]
   24725:	48 c1 e0 04          	shl    rax,0x4
   24729:	48 01 f8             	add    rax,rdi
   2472c:	4c 8b 40 08          	mov    r8,QWORD PTR [rax+0x8]
   24730:	48 8b 30             	mov    rsi,QWORD PTR [rax]
   24733:	48 89 50 08          	mov    QWORD PTR [rax+0x8],rdx
   24737:	48 89 08             	mov    QWORD PTR [rax],rcx
   2473a:	41 83 f8 f6          	cmp    r8d,0xfffffff6
   2473e:	76 11                	jbe    24751 <JS_CallInternal+0x1bb1>
   24740:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   24743:	83 e8 01             	sub    eax,0x1
   24746:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   24749:	85 c0                	test   eax,eax
   2474b:	0f 8e e1 64 00 00    	jle    2ac32 <JS_CallInternal+0x8092>
   24751:	41 0f b6 44 24 02    	movzx  eax,BYTE PTR [r12+0x2]
   24757:	49 83 c4 03          	add    r12,0x3
   2475b:	49 89 c5             	mov    r13,rax
   2475e:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   24762:	ff e0                	jmp    rax
   24764:	f3 0f 1e fa          	endbr64
   24768:	41 0f b7 04 24       	movzx  eax,WORD PTR [r12]
   2476d:	48 8b 8d 90 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x170]
   24774:	f3 0f 6f 63 f0       	movdqu xmm4,XMMWORD PTR [rbx-0x10]
   24779:	48 c1 e0 04          	shl    rax,0x4
   2477d:	48 01 c8             	add    rax,rcx
   24780:	48 8b 50 08          	mov    rdx,QWORD PTR [rax+0x8]
   24784:	48 8b 30             	mov    rsi,QWORD PTR [rax]
   24787:	0f 11 20             	movups XMMWORD PTR [rax],xmm4
   2478a:	83 fa f6             	cmp    edx,0xfffffff6
   2478d:	76 11                	jbe    247a0 <JS_CallInternal+0x1c00>
   2478f:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   24792:	83 e8 01             	sub    eax,0x1
   24795:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   24798:	85 c0                	test   eax,eax
   2479a:	0f 8e d7 64 00 00    	jle    2ac77 <JS_CallInternal+0x80d7>
   247a0:	41 0f b6 44 24 02    	movzx  eax,BYTE PTR [r12+0x2]
   247a6:	48 83 eb 10          	sub    rbx,0x10
   247aa:	49 83 c4 03          	add    r12,0x3
   247ae:	49 89 c5             	mov    r13,rax
   247b1:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   247b5:	ff e0                	jmp    rax
   247b7:	f3 0f 1e fa          	endbr64
   247bb:	41 0f b7 04 24       	movzx  eax,WORD PTR [r12]
   247c0:	48 8b 8d b0 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x150]
   247c7:	f3 0f 6f 4b f0       	movdqu xmm1,XMMWORD PTR [rbx-0x10]
   247cc:	48 c1 e0 04          	shl    rax,0x4
   247d0:	48 01 c8             	add    rax,rcx
   247d3:	48 8b 50 08          	mov    rdx,QWORD PTR [rax+0x8]
   247d7:	48 8b 30             	mov    rsi,QWORD PTR [rax]
   247da:	0f 11 08             	movups XMMWORD PTR [rax],xmm1
   247dd:	83 fa f6             	cmp    edx,0xfffffff6
   247e0:	76 11                	jbe    247f3 <JS_CallInternal+0x1c53>
   247e2:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   247e5:	83 e8 01             	sub    eax,0x1
   247e8:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   247eb:	85 c0                	test   eax,eax
   247ed:	0f 8e 6f 64 00 00    	jle    2ac62 <JS_CallInternal+0x80c2>
   247f3:	41 0f b6 44 24 02    	movzx  eax,BYTE PTR [r12+0x2]
   247f9:	48 83 eb 10          	sub    rbx,0x10
   247fd:	49 83 c4 03          	add    r12,0x3
   24801:	49 89 c5             	mov    r13,rax
   24804:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   24808:	ff e0                	jmp    rax
   2480a:	f3 0f 1e fa          	endbr64
   2480e:	41 0f b7 04 24       	movzx  eax,WORD PTR [r12]
   24813:	48 8b 8d b0 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x150]
   2481a:	48 c1 e0 04          	shl    rax,0x4
   2481e:	48 01 c8             	add    rax,rcx
   24821:	48 8b 10             	mov    rdx,QWORD PTR [rax]
   24824:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
   24828:	83 f8 f6             	cmp    eax,0xfffffff6
   2482b:	76 04                	jbe    24831 <JS_CallInternal+0x1c91>
   2482d:	83 42 fc 01          	add    DWORD PTR [rdx-0x4],0x1
   24831:	48 89 13             	mov    QWORD PTR [rbx],rdx
   24834:	49 83 c4 03          	add    r12,0x3
   24838:	48 83 c3 10          	add    rbx,0x10
   2483c:	48 89 43 f8          	mov    QWORD PTR [rbx-0x8],rax
   24840:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   24846:	49 89 c5             	mov    r13,rax
   24849:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   2484d:	ff e0                	jmp    rax
   2484f:	f3 0f 1e fa          	endbr64
   24853:	48 8b 85 90 fe ff ff 	mov    rax,QWORD PTR [rbp-0x170]
   2485a:	48 8d 4b 10          	lea    rcx,[rbx+0x10]
   2485e:	48 8b 10             	mov    rdx,QWORD PTR [rax]
   24861:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
   24865:	83 f8 f6             	cmp    eax,0xfffffff6
   24868:	76 04                	jbe    2486e <JS_CallInternal+0x1cce>
   2486a:	83 42 fc 01          	add    DWORD PTR [rdx-0x4],0x1
   2486e:	48 89 13             	mov    QWORD PTR [rbx],rdx
   24871:	49 83 c4 01          	add    r12,0x1
   24875:	48 89 43 08          	mov    QWORD PTR [rbx+0x8],rax
   24879:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   2487f:	48 89 cb             	mov    rbx,rcx
   24882:	49 89 c5             	mov    r13,rax
   24885:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   24889:	ff e0                	jmp    rax
   2488b:	f3 0f 1e fa          	endbr64
   2488f:	48 8b 43 f8          	mov    rax,QWORD PTR [rbx-0x8]
   24893:	48 8b 53 f0          	mov    rdx,QWORD PTR [rbx-0x10]
   24897:	83 f8 f6             	cmp    eax,0xfffffff6
   2489a:	76 04                	jbe    248a0 <JS_CallInternal+0x1d00>
   2489c:	83 42 fc 01          	add    DWORD PTR [rdx-0x4],0x1
   248a0:	48 8b bd b0 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x150]
   248a7:	48 8b 4f 38          	mov    rcx,QWORD PTR [rdi+0x38]
   248ab:	48 8b 77 30          	mov    rsi,QWORD PTR [rdi+0x30]
   248af:	48 89 47 38          	mov    QWORD PTR [rdi+0x38],rax
   248b3:	48 89 57 30          	mov    QWORD PTR [rdi+0x30],rdx
   248b7:	83 f9 f6             	cmp    ecx,0xfffffff6
   248ba:	76 11                	jbe    248cd <JS_CallInternal+0x1d2d>
   248bc:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   248bf:	83 e8 01             	sub    eax,0x1
   248c2:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   248c5:	85 c0                	test   eax,eax
   248c7:	0f 8e 5d 62 00 00    	jle    2ab2a <JS_CallInternal+0x7f8a>
   248cd:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   248d2:	49 83 c4 01          	add    r12,0x1
   248d6:	49 89 c5             	mov    r13,rax
   248d9:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   248dd:	ff e0                	jmp    rax
   248df:	f3 0f 1e fa          	endbr64
   248e3:	48 8b 43 f8          	mov    rax,QWORD PTR [rbx-0x8]
   248e7:	48 8b 53 f0          	mov    rdx,QWORD PTR [rbx-0x10]
   248eb:	83 f8 f6             	cmp    eax,0xfffffff6
   248ee:	76 04                	jbe    248f4 <JS_CallInternal+0x1d54>
   248f0:	83 42 fc 01          	add    DWORD PTR [rdx-0x4],0x1
   248f4:	48 8b bd b0 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x150]
   248fb:	48 8b 4f 08          	mov    rcx,QWORD PTR [rdi+0x8]
   248ff:	48 8b 37             	mov    rsi,QWORD PTR [rdi]
   24902:	48 89 47 08          	mov    QWORD PTR [rdi+0x8],rax
   24906:	48 89 17             	mov    QWORD PTR [rdi],rdx
   24909:	83 f9 f6             	cmp    ecx,0xfffffff6
   2490c:	76 11                	jbe    2491f <JS_CallInternal+0x1d7f>
   2490e:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   24911:	83 e8 01             	sub    eax,0x1
   24914:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   24917:	85 c0                	test   eax,eax
   24919:	0f 8e bc 62 00 00    	jle    2abdb <JS_CallInternal+0x803b>
   2491f:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   24924:	49 83 c4 01          	add    r12,0x1
   24928:	49 89 c5             	mov    r13,rax
   2492b:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   2492f:	ff e0                	jmp    rax
   24931:	f3 0f 1e fa          	endbr64
   24935:	48 8b 43 f8          	mov    rax,QWORD PTR [rbx-0x8]
   24939:	48 8b 53 f0          	mov    rdx,QWORD PTR [rbx-0x10]
   2493d:	83 f8 f6             	cmp    eax,0xfffffff6
   24940:	76 04                	jbe    24946 <JS_CallInternal+0x1da6>
   24942:	83 42 fc 01          	add    DWORD PTR [rdx-0x4],0x1
   24946:	48 8b bd b0 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x150]
   2494d:	48 8b 4f 28          	mov    rcx,QWORD PTR [rdi+0x28]
   24951:	48 8b 77 20          	mov    rsi,QWORD PTR [rdi+0x20]
   24955:	48 89 47 28          	mov    QWORD PTR [rdi+0x28],rax
   24959:	48 89 57 20          	mov    QWORD PTR [rdi+0x20],rdx
   2495d:	83 f9 f6             	cmp    ecx,0xfffffff6
   24960:	76 11                	jbe    24973 <JS_CallInternal+0x1dd3>
   24962:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   24965:	83 e8 01             	sub    eax,0x1
   24968:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   2496b:	85 c0                	test   eax,eax
   2496d:	0f 8e 93 5f 00 00    	jle    2a906 <JS_CallInternal+0x7d66>
   24973:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   24978:	49 83 c4 01          	add    r12,0x1
   2497c:	49 89 c5             	mov    r13,rax
   2497f:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   24983:	ff e0                	jmp    rax
   24985:	f3 0f 1e fa          	endbr64
   24989:	48 8b 85 b0 fe ff ff 	mov    rax,QWORD PTR [rbp-0x150]
   24990:	f3 0f 6f 7b f0       	movdqu xmm7,XMMWORD PTR [rbx-0x10]
   24995:	48 83 eb 10          	sub    rbx,0x10
   24999:	48 8b 50 28          	mov    rdx,QWORD PTR [rax+0x28]
   2499d:	48 8b 70 20          	mov    rsi,QWORD PTR [rax+0x20]
   249a1:	0f 11 78 20          	movups XMMWORD PTR [rax+0x20],xmm7
   249a5:	83 fa f6             	cmp    edx,0xfffffff6
   249a8:	76 11                	jbe    249bb <JS_CallInternal+0x1e1b>
   249aa:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   249ad:	83 e8 01             	sub    eax,0x1
   249b0:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   249b3:	85 c0                	test   eax,eax
   249b5:	0f 8e 4d 62 00 00    	jle    2ac08 <JS_CallInternal+0x8068>
   249bb:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   249c0:	49 83 c4 01          	add    r12,0x1
   249c4:	49 89 c5             	mov    r13,rax
   249c7:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   249cb:	ff e0                	jmp    rax
   249cd:	f3 0f 1e fa          	endbr64
   249d1:	48 8b 43 f8          	mov    rax,QWORD PTR [rbx-0x8]
   249d5:	48 8b 53 f0          	mov    rdx,QWORD PTR [rbx-0x10]
   249d9:	83 f8 f6             	cmp    eax,0xfffffff6
   249dc:	76 04                	jbe    249e2 <JS_CallInternal+0x1e42>
   249de:	83 42 fc 01          	add    DWORD PTR [rdx-0x4],0x1
   249e2:	48 8b bd b0 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x150]
   249e9:	48 8b 4f 18          	mov    rcx,QWORD PTR [rdi+0x18]
   249ed:	48 8b 77 10          	mov    rsi,QWORD PTR [rdi+0x10]
   249f1:	48 89 47 18          	mov    QWORD PTR [rdi+0x18],rax
   249f5:	48 89 57 10          	mov    QWORD PTR [rdi+0x10],rdx
   249f9:	83 f9 f6             	cmp    ecx,0xfffffff6
   249fc:	76 11                	jbe    24a0f <JS_CallInternal+0x1e6f>
   249fe:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   24a01:	83 e8 01             	sub    eax,0x1
   24a04:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   24a07:	85 c0                	test   eax,eax
   24a09:	0f 8e 0f 5f 00 00    	jle    2a91e <JS_CallInternal+0x7d7e>
   24a0f:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   24a14:	49 83 c4 01          	add    r12,0x1
   24a18:	49 89 c5             	mov    r13,rax
   24a1b:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   24a1f:	ff e0                	jmp    rax
   24a21:	f3 0f 1e fa          	endbr64
   24a25:	48 8b 85 b0 fe ff ff 	mov    rax,QWORD PTR [rbp-0x150]
   24a2c:	f3 0f 6f 5b f0       	movdqu xmm3,XMMWORD PTR [rbx-0x10]
   24a31:	48 83 eb 10          	sub    rbx,0x10
   24a35:	48 8b 50 38          	mov    rdx,QWORD PTR [rax+0x38]
   24a39:	48 8b 70 30          	mov    rsi,QWORD PTR [rax+0x30]
   24a3d:	0f 11 58 30          	movups XMMWORD PTR [rax+0x30],xmm3
   24a41:	83 fa f6             	cmp    edx,0xfffffff6
   24a44:	76 11                	jbe    24a57 <JS_CallInternal+0x1eb7>
   24a46:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   24a49:	83 e8 01             	sub    eax,0x1
   24a4c:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   24a4f:	85 c0                	test   eax,eax
   24a51:	0f 8e 9c 61 00 00    	jle    2abf3 <JS_CallInternal+0x8053>
   24a57:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   24a5c:	49 83 c4 01          	add    r12,0x1
   24a60:	49 89 c5             	mov    r13,rax
   24a63:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   24a67:	ff e0                	jmp    rax
   24a69:	f3 0f 1e fa          	endbr64
   24a6d:	48 8b 85 b0 fe ff ff 	mov    rax,QWORD PTR [rbp-0x150]
   24a74:	f3 0f 6f 73 f0       	movdqu xmm6,XMMWORD PTR [rbx-0x10]
   24a79:	48 83 eb 10          	sub    rbx,0x10
   24a7d:	48 8b 50 18          	mov    rdx,QWORD PTR [rax+0x18]
   24a81:	48 8b 70 10          	mov    rsi,QWORD PTR [rax+0x10]
   24a85:	0f 11 70 10          	movups XMMWORD PTR [rax+0x10],xmm6
   24a89:	83 fa f6             	cmp    edx,0xfffffff6
   24a8c:	76 11                	jbe    24a9f <JS_CallInternal+0x1eff>
   24a8e:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   24a91:	83 e8 01             	sub    eax,0x1
   24a94:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   24a97:	85 c0                	test   eax,eax
   24a99:	0f 8e 7e 61 00 00    	jle    2ac1d <JS_CallInternal+0x807d>
   24a9f:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   24aa4:	49 83 c4 01          	add    r12,0x1
   24aa8:	49 89 c5             	mov    r13,rax
   24aab:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   24aaf:	ff e0                	jmp    rax
   24ab1:	f3 0f 1e fa          	endbr64
   24ab5:	48 8b 85 b0 fe ff ff 	mov    rax,QWORD PTR [rbp-0x150]
   24abc:	f3 0f 6f 6b f0       	movdqu xmm5,XMMWORD PTR [rbx-0x10]
   24ac1:	48 83 eb 10          	sub    rbx,0x10
   24ac5:	48 8b 50 08          	mov    rdx,QWORD PTR [rax+0x8]
   24ac9:	48 8b 30             	mov    rsi,QWORD PTR [rax]
   24acc:	0f 11 28             	movups XMMWORD PTR [rax],xmm5
   24acf:	83 fa f6             	cmp    edx,0xfffffff6
   24ad2:	76 11                	jbe    24ae5 <JS_CallInternal+0x1f45>
   24ad4:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   24ad7:	83 e8 01             	sub    eax,0x1
   24ada:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   24add:	85 c0                	test   eax,eax
   24adf:	0f 8e 13 62 00 00    	jle    2acf8 <JS_CallInternal+0x8158>
   24ae5:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   24aea:	49 83 c4 01          	add    r12,0x1
   24aee:	49 89 c5             	mov    r13,rax
   24af1:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   24af5:	ff e0                	jmp    rax
   24af7:	f3 0f 1e fa          	endbr64
   24afb:	48 8b 85 b0 fe ff ff 	mov    rax,QWORD PTR [rbp-0x150]
   24b02:	48 8d 4b 10          	lea    rcx,[rbx+0x10]
   24b06:	48 8b 10             	mov    rdx,QWORD PTR [rax]
   24b09:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
   24b0d:	83 f8 f6             	cmp    eax,0xfffffff6
   24b10:	76 04                	jbe    24b16 <JS_CallInternal+0x1f76>
   24b12:	83 42 fc 01          	add    DWORD PTR [rdx-0x4],0x1
   24b16:	48 89 13             	mov    QWORD PTR [rbx],rdx
   24b19:	49 83 c4 01          	add    r12,0x1
   24b1d:	48 89 43 08          	mov    QWORD PTR [rbx+0x8],rax
   24b21:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   24b27:	48 89 cb             	mov    rbx,rcx
   24b2a:	49 89 c5             	mov    r13,rax
   24b2d:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   24b31:	ff e0                	jmp    rax
   24b33:	f3 0f 1e fa          	endbr64
   24b37:	48 8b 53 f8          	mov    rdx,QWORD PTR [rbx-0x8]
   24b3b:	48 8b 4b f0          	mov    rcx,QWORD PTR [rbx-0x10]
   24b3f:	83 fa f6             	cmp    edx,0xfffffff6
   24b42:	76 04                	jbe    24b48 <JS_CallInternal+0x1fa8>
   24b44:	83 41 fc 01          	add    DWORD PTR [rcx-0x4],0x1
   24b48:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   24b4d:	48 8b bd b0 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x150]
   24b54:	48 c1 e0 04          	shl    rax,0x4
   24b58:	48 01 f8             	add    rax,rdi
   24b5b:	4c 8b 40 08          	mov    r8,QWORD PTR [rax+0x8]
   24b5f:	48 8b 30             	mov    rsi,QWORD PTR [rax]
   24b62:	48 89 50 08          	mov    QWORD PTR [rax+0x8],rdx
   24b66:	48 89 08             	mov    QWORD PTR [rax],rcx
   24b69:	41 83 f8 f6          	cmp    r8d,0xfffffff6
   24b6d:	76 11                	jbe    24b80 <JS_CallInternal+0x1fe0>
   24b6f:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   24b72:	83 e8 01             	sub    eax,0x1
   24b75:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   24b78:	85 c0                	test   eax,eax
   24b7a:	0f 8e b3 5b 00 00    	jle    2a733 <JS_CallInternal+0x7b93>
   24b80:	41 0f b6 44 24 01    	movzx  eax,BYTE PTR [r12+0x1]
   24b86:	49 83 c4 02          	add    r12,0x2
   24b8a:	49 89 c5             	mov    r13,rax
   24b8d:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   24b91:	ff e0                	jmp    rax
   24b93:	f3 0f 1e fa          	endbr64
   24b97:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   24b9c:	48 8b 8d b0 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x150]
   24ba3:	48 83 eb 10          	sub    rbx,0x10
   24ba7:	f3 0f 6f 13          	movdqu xmm2,XMMWORD PTR [rbx]
   24bab:	48 c1 e0 04          	shl    rax,0x4
   24baf:	48 01 c8             	add    rax,rcx
   24bb2:	48 8b 50 08          	mov    rdx,QWORD PTR [rax+0x8]
   24bb6:	48 8b 30             	mov    rsi,QWORD PTR [rax]
   24bb9:	0f 11 10             	movups XMMWORD PTR [rax],xmm2
   24bbc:	83 fa f6             	cmp    edx,0xfffffff6
   24bbf:	76 11                	jbe    24bd2 <JS_CallInternal+0x2032>
   24bc1:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   24bc4:	83 e8 01             	sub    eax,0x1
   24bc7:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   24bca:	85 c0                	test   eax,eax
   24bcc:	0f 8e 4c 5b 00 00    	jle    2a71e <JS_CallInternal+0x7b7e>
   24bd2:	41 0f b6 44 24 01    	movzx  eax,BYTE PTR [r12+0x1]
   24bd8:	49 83 c4 02          	add    r12,0x2
   24bdc:	49 89 c5             	mov    r13,rax
   24bdf:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   24be3:	ff e0                	jmp    rax
   24be5:	f3 0f 1e fa          	endbr64
   24be9:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   24bee:	48 8b 8d b0 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x150]
   24bf5:	48 c1 e0 04          	shl    rax,0x4
   24bf9:	48 01 c8             	add    rax,rcx
   24bfc:	48 8d 4b 10          	lea    rcx,[rbx+0x10]
   24c00:	48 8b 10             	mov    rdx,QWORD PTR [rax]
   24c03:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
   24c07:	83 f8 f6             	cmp    eax,0xfffffff6
   24c0a:	76 04                	jbe    24c10 <JS_CallInternal+0x2070>
   24c0c:	83 42 fc 01          	add    DWORD PTR [rdx-0x4],0x1
   24c10:	48 89 13             	mov    QWORD PTR [rbx],rdx
   24c13:	49 83 c4 02          	add    r12,0x2
   24c17:	48 89 43 08          	mov    QWORD PTR [rbx+0x8],rax
   24c1b:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   24c21:	48 89 cb             	mov    rbx,rcx
   24c24:	49 89 c5             	mov    r13,rax
   24c27:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   24c2b:	ff e0                	jmp    rax
   24c2d:	f3 0f 1e fa          	endbr64
   24c31:	48 8b 85 b0 fe ff ff 	mov    rax,QWORD PTR [rbp-0x150]
   24c38:	48 8d 4b 10          	lea    rcx,[rbx+0x10]
   24c3c:	48 8b 50 20          	mov    rdx,QWORD PTR [rax+0x20]
   24c40:	48 8b 40 28          	mov    rax,QWORD PTR [rax+0x28]
   24c44:	83 f8 f6             	cmp    eax,0xfffffff6
   24c47:	76 04                	jbe    24c4d <JS_CallInternal+0x20ad>
   24c49:	83 42 fc 01          	add    DWORD PTR [rdx-0x4],0x1
   24c4d:	48 89 13             	mov    QWORD PTR [rbx],rdx
   24c50:	49 83 c4 01          	add    r12,0x1
   24c54:	48 89 43 08          	mov    QWORD PTR [rbx+0x8],rax
   24c58:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   24c5e:	48 89 cb             	mov    rbx,rcx
   24c61:	49 89 c5             	mov    r13,rax
   24c64:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   24c68:	ff e0                	jmp    rax
   24c6a:	f3 0f 1e fa          	endbr64
   24c6e:	48 8b 85 b0 fe ff ff 	mov    rax,QWORD PTR [rbp-0x150]
   24c75:	48 8d 4b 10          	lea    rcx,[rbx+0x10]
   24c79:	48 8b 50 10          	mov    rdx,QWORD PTR [rax+0x10]
   24c7d:	48 8b 40 18          	mov    rax,QWORD PTR [rax+0x18]
   24c81:	83 f8 f6             	cmp    eax,0xfffffff6
   24c84:	76 04                	jbe    24c8a <JS_CallInternal+0x20ea>
   24c86:	83 42 fc 01          	add    DWORD PTR [rdx-0x4],0x1
   24c8a:	48 89 13             	mov    QWORD PTR [rbx],rdx
   24c8d:	49 83 c4 01          	add    r12,0x1
   24c91:	48 89 43 08          	mov    QWORD PTR [rbx+0x8],rax
   24c95:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   24c9b:	48 89 cb             	mov    rbx,rcx
   24c9e:	49 89 c5             	mov    r13,rax
   24ca1:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   24ca5:	ff e0                	jmp    rax
   24ca7:	f3 0f 1e fa          	endbr64
   24cab:	48 8b 85 b0 fe ff ff 	mov    rax,QWORD PTR [rbp-0x150]
   24cb2:	48 8d 4b 10          	lea    rcx,[rbx+0x10]
   24cb6:	48 8b 50 30          	mov    rdx,QWORD PTR [rax+0x30]
   24cba:	48 8b 40 38          	mov    rax,QWORD PTR [rax+0x38]
   24cbe:	83 f8 f6             	cmp    eax,0xfffffff6
   24cc1:	76 04                	jbe    24cc7 <JS_CallInternal+0x2127>
   24cc3:	83 42 fc 01          	add    DWORD PTR [rdx-0x4],0x1
   24cc7:	48 89 13             	mov    QWORD PTR [rbx],rdx
   24cca:	49 83 c4 01          	add    r12,0x1
   24cce:	48 89 43 08          	mov    QWORD PTR [rbx+0x8],rax
   24cd2:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   24cd8:	48 89 cb             	mov    rbx,rcx
   24cdb:	49 89 c5             	mov    r13,rax
   24cde:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   24ce2:	ff e0                	jmp    rax
   24ce4:	f3 0f 1e fa          	endbr64
   24ce8:	41 0f b7 04 24       	movzx  eax,WORD PTR [r12]
   24ced:	48 8b bd b0 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x150]
   24cf4:	4d 8d 6c 24 02       	lea    r13,[r12+0x2]
   24cf9:	48 89 c1             	mov    rcx,rax
   24cfc:	48 c1 e0 04          	shl    rax,0x4
   24d00:	48 01 f8             	add    rax,rdi
   24d03:	48 8b 50 08          	mov    rdx,QWORD PTR [rax+0x8]
   24d07:	83 fa 04             	cmp    edx,0x4
   24d0a:	0f 84 78 61 00 00    	je     2ae88 <JS_CallInternal+0x82e8>
   24d10:	48 8b 00             	mov    rax,QWORD PTR [rax]
   24d13:	83 fa f6             	cmp    edx,0xfffffff6
   24d16:	76 04                	jbe    24d1c <JS_CallInternal+0x217c>
   24d18:	83 40 fc 01          	add    DWORD PTR [rax-0x4],0x1
   24d1c:	48 89 03             	mov    QWORD PTR [rbx],rax
   24d1f:	49 83 c4 03          	add    r12,0x3
   24d23:	48 83 c3 10          	add    rbx,0x10
   24d27:	48 89 53 f8          	mov    QWORD PTR [rbx-0x8],rdx
   24d2b:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   24d31:	49 89 c5             	mov    r13,rax
   24d34:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   24d38:	ff e0                	jmp    rax
   24d3a:	f3 0f 1e fa          	endbr64
   24d3e:	41 0f b7 04 24       	movzx  eax,WORD PTR [r12]
   24d43:	48 8b bd b0 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x150]
   24d4a:	4d 8d 6c 24 02       	lea    r13,[r12+0x2]
   24d4f:	48 89 c1             	mov    rcx,rax
   24d52:	48 c1 e0 04          	shl    rax,0x4
   24d56:	48 01 f8             	add    rax,rdi
   24d59:	48 8b 50 08          	mov    rdx,QWORD PTR [rax+0x8]
   24d5d:	83 fa 04             	cmp    edx,0x4
   24d60:	0f 84 02 61 00 00    	je     2ae68 <JS_CallInternal+0x82c8>
   24d66:	48 8b 00             	mov    rax,QWORD PTR [rax]
   24d69:	83 fa f6             	cmp    edx,0xfffffff6
   24d6c:	76 04                	jbe    24d72 <JS_CallInternal+0x21d2>
   24d6e:	83 40 fc 01          	add    DWORD PTR [rax-0x4],0x1
   24d72:	48 89 03             	mov    QWORD PTR [rbx],rax
   24d75:	49 83 c4 03          	add    r12,0x3
   24d79:	48 83 c3 10          	add    rbx,0x10
   24d7d:	48 89 53 f8          	mov    QWORD PTR [rbx-0x8],rdx
   24d81:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   24d87:	49 89 c5             	mov    r13,rax
   24d8a:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   24d8e:	ff e0                	jmp    rax
   24d90:	f3 0f 1e fa          	endbr64
   24d94:	41 0f b7 04 24       	movzx  eax,WORD PTR [r12]
   24d99:	48 8b 8d b0 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x150]
   24da0:	48 c1 e0 04          	shl    rax,0x4
   24da4:	48 01 c8             	add    rax,rcx
   24da7:	48 8b 50 08          	mov    rdx,QWORD PTR [rax+0x8]
   24dab:	48 8b 30             	mov    rsi,QWORD PTR [rax]
   24dae:	48 c7 40 08 04 00 00 	mov    QWORD PTR [rax+0x8],0x4
   24db5:	00 
   24db6:	48 c7 00 00 00 00 00 	mov    QWORD PTR [rax],0x0
   24dbd:	83 fa f6             	cmp    edx,0xfffffff6
   24dc0:	76 11                	jbe    24dd3 <JS_CallInternal+0x2233>
   24dc2:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   24dc5:	83 e8 01             	sub    eax,0x1
   24dc8:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   24dcb:	85 c0                	test   eax,eax
   24dcd:	0f 8e 10 5f 00 00    	jle    2ace3 <JS_CallInternal+0x8143>
   24dd3:	41 0f b6 44 24 02    	movzx  eax,BYTE PTR [r12+0x2]
   24dd9:	49 83 c4 03          	add    r12,0x3
   24ddd:	49 89 c5             	mov    r13,rax
   24de0:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   24de4:	ff e0                	jmp    rax
   24de6:	f3 0f 1e fa          	endbr64
   24dea:	41 0f b7 04 24       	movzx  eax,WORD PTR [r12]
   24def:	48 8b 8d 98 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x168]
   24df6:	4d 8d 6c 24 02       	lea    r13,[r12+0x2]
   24dfb:	48 8d 14 c5 00 00 00 	lea    rdx,[rax*8+0x0]
   24e02:	00 
   24e03:	48 8b 04 c1          	mov    rax,QWORD PTR [rcx+rax*8]
   24e07:	48 8b 40 18          	mov    rax,QWORD PTR [rax+0x18]
   24e0b:	83 78 08 04          	cmp    DWORD PTR [rax+0x8],0x4
   24e0f:	0f 85 ce 60 00 00    	jne    2aee3 <JS_CallInternal+0x8343>
   24e15:	f3 0f 6f 7b f0       	movdqu xmm7,XMMWORD PTR [rbx-0x10]
   24e1a:	49 83 c4 03          	add    r12,0x3
   24e1e:	48 83 eb 10          	sub    rbx,0x10
   24e22:	0f 11 38             	movups XMMWORD PTR [rax],xmm7
   24e25:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   24e2b:	49 89 c5             	mov    r13,rax
   24e2e:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   24e32:	ff e0                	jmp    rax
   24e34:	f3 0f 1e fa          	endbr64
   24e38:	41 0f b7 04 24       	movzx  eax,WORD PTR [r12]
   24e3d:	48 8b bd 98 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x168]
   24e44:	4d 8d 6c 24 02       	lea    r13,[r12+0x2]
   24e49:	48 8d 0c c5 00 00 00 	lea    rcx,[rax*8+0x0]
   24e50:	00 
   24e51:	48 8b 04 c7          	mov    rax,QWORD PTR [rdi+rax*8]
   24e55:	48 8b 40 18          	mov    rax,QWORD PTR [rax+0x18]
   24e59:	48 8b 50 08          	mov    rdx,QWORD PTR [rax+0x8]
   24e5d:	83 fa 04             	cmp    edx,0x4
   24e60:	0f 84 84 66 00 00    	je     2b4ea <JS_CallInternal+0x894a>
   24e66:	f3 0f 6f 73 f0       	movdqu xmm6,XMMWORD PTR [rbx-0x10]
   24e6b:	48 8b 30             	mov    rsi,QWORD PTR [rax]
   24e6e:	0f 11 30             	movups XMMWORD PTR [rax],xmm6
   24e71:	83 fa f6             	cmp    edx,0xfffffff6
   24e74:	76 11                	jbe    24e87 <JS_CallInternal+0x22e7>
   24e76:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   24e79:	83 e8 01             	sub    eax,0x1
   24e7c:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   24e7f:	85 c0                	test   eax,eax
   24e81:	0f 8e 82 58 00 00    	jle    2a709 <JS_CallInternal+0x7b69>
   24e87:	41 0f b6 44 24 02    	movzx  eax,BYTE PTR [r12+0x2]
   24e8d:	48 83 eb 10          	sub    rbx,0x10
   24e91:	49 83 c4 03          	add    r12,0x3
   24e95:	49 89 c5             	mov    r13,rax
   24e98:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   24e9c:	ff e0                	jmp    rax
   24e9e:	f3 0f 1e fa          	endbr64
   24ea2:	48 8b 73 f0          	mov    rsi,QWORD PTR [rbx-0x10]
   24ea6:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   24ead:	4c 8d 43 f0          	lea    r8,[rbx-0x10]
   24eb1:	49 8b 50 08          	mov    rdx,QWORD PTR [r8+0x8]
   24eb5:	e8 66 6b ff ff       	call   1ba20 <js_operator_typeof>
   24eba:	83 f8 1b             	cmp    eax,0x1b
   24ebd:	74 61                	je     24f20 <JS_CallInternal+0x2380>
   24ebf:	49 8b 50 08          	mov    rdx,QWORD PTR [r8+0x8]
   24ec3:	49 8b 30             	mov    rsi,QWORD PTR [r8]
   24ec6:	83 fa f6             	cmp    edx,0xfffffff6
   24ec9:	76 11                	jbe    24edc <JS_CallInternal+0x233c>
   24ecb:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   24ece:	83 e8 01             	sub    eax,0x1
   24ed1:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   24ed4:	85 c0                	test   eax,eax
   24ed6:	0f 8e 56 49 00 00    	jle    29832 <JS_CallInternal+0x6c92>
   24edc:	48 c7 43 f0 00 00 00 	mov    QWORD PTR [rbx-0x10],0x0
   24ee3:	00 
   24ee4:	49 83 c4 01          	add    r12,0x1
   24ee8:	48 c7 43 f8 01 00 00 	mov    QWORD PTR [rbx-0x8],0x1
   24eef:	00 
   24ef0:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   24ef6:	49 89 c5             	mov    r13,rax
   24ef9:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   24efd:	ff e0                	jmp    rax
   24eff:	f3 0f 1e fa          	endbr64
   24f03:	48 8b 73 f0          	mov    rsi,QWORD PTR [rbx-0x10]
   24f07:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   24f0e:	4c 8d 43 f0          	lea    r8,[rbx-0x10]
   24f12:	49 8b 50 08          	mov    rdx,QWORD PTR [r8+0x8]
   24f16:	e8 05 6b ff ff       	call   1ba20 <js_operator_typeof>
   24f1b:	83 f8 49             	cmp    eax,0x49
   24f1e:	75 9f                	jne    24ebf <JS_CallInternal+0x231f>
   24f20:	49 8b 50 08          	mov    rdx,QWORD PTR [r8+0x8]
   24f24:	49 8b 30             	mov    rsi,QWORD PTR [r8]
   24f27:	83 fa f6             	cmp    edx,0xfffffff6
   24f2a:	76 11                	jbe    24f3d <JS_CallInternal+0x239d>
   24f2c:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   24f2f:	83 e8 01             	sub    eax,0x1
   24f32:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   24f35:	85 c0                	test   eax,eax
   24f37:	0f 8e 2d 6d 00 00    	jle    2bc6a <JS_CallInternal+0x90ca>
   24f3d:	48 c7 43 f0 01 00 00 	mov    QWORD PTR [rbx-0x10],0x1
   24f44:	00 
   24f45:	49 83 c4 01          	add    r12,0x1
   24f49:	48 c7 43 f8 01 00 00 	mov    QWORD PTR [rbx-0x8],0x1
   24f50:	00 
   24f51:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   24f57:	49 89 c5             	mov    r13,rax
   24f5a:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   24f5e:	ff e0                	jmp    rax
   24f60:	f3 0f 1e fa          	endbr64
   24f64:	31 c9                	xor    ecx,ecx
   24f66:	b8 03 00 00 00       	mov    eax,0x3
   24f6b:	e9 50 e4 ff ff       	jmp    233c0 <JS_CallInternal+0x820>
   24f70:	f3 0f 1e fa          	endbr64
   24f74:	b9 03 00 00 00       	mov    ecx,0x3
   24f79:	31 c0                	xor    eax,eax
   24f7b:	e9 40 e4 ff ff       	jmp    233c0 <JS_CallInternal+0x820>
   24f80:	f3 0f 1e fa          	endbr64
   24f84:	83 7b f8 02          	cmp    DWORD PTR [rbx-0x8],0x2
   24f88:	74 b3                	je     24f3d <JS_CallInternal+0x239d>
   24f8a:	4c 8d 43 f0          	lea    r8,[rbx-0x10]
   24f8e:	e9 2c ff ff ff       	jmp    24ebf <JS_CallInternal+0x231f>
   24f93:	f3 0f 1e fa          	endbr64
   24f97:	83 7b f8 03          	cmp    DWORD PTR [rbx-0x8],0x3
   24f9b:	75 ed                	jne    24f8a <JS_CallInternal+0x23ea>
   24f9d:	eb 9e                	jmp    24f3d <JS_CallInternal+0x239d>
   24f9f:	f3 0f 1e fa          	endbr64
   24fa3:	8b 43 f8             	mov    eax,DWORD PTR [rbx-0x8]
   24fa6:	83 e8 02             	sub    eax,0x2
   24fa9:	83 f8 01             	cmp    eax,0x1
   24fac:	77 dc                	ja     24f8a <JS_CallInternal+0x23ea>
   24fae:	eb 8d                	jmp    24f3d <JS_CallInternal+0x239d>
   24fb0:	f3 0f 1e fa          	endbr64
   24fb4:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   24fb9:	49 83 c4 01          	add    r12,0x1
   24fbd:	49 89 c5             	mov    r13,rax
   24fc0:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   24fc4:	ff e0                	jmp    rax
   24fc6:	f3 0f 1e fa          	endbr64
   24fca:	31 c9                	xor    ecx,ecx
   24fcc:	b8 01 00 00 00       	mov    eax,0x1
   24fd1:	e9 ea e3 ff ff       	jmp    233c0 <JS_CallInternal+0x820>
   24fd6:	f3 0f 1e fa          	endbr64
   24fda:	31 c9                	xor    ecx,ecx
   24fdc:	31 c0                	xor    eax,eax
   24fde:	e9 dd e3 ff ff       	jmp    233c0 <JS_CallInternal+0x820>
   24fe3:	f3 0f 1e fa          	endbr64
   24fe7:	e9 d4 de ff ff       	jmp    22ec0 <JS_CallInternal+0x320>
   24fec:	f3 0f 1e fa          	endbr64
   24ff0:	e9 cb de ff ff       	jmp    22ec0 <JS_CallInternal+0x320>
   24ff5:	f3 0f 1e fa          	endbr64
   24ff9:	e9 c2 de ff ff       	jmp    22ec0 <JS_CallInternal+0x320>
   24ffe:	f3 0f 1e fa          	endbr64
   25002:	48 8b 43 f8          	mov    rax,QWORD PTR [rbx-0x8]
   25006:	83 f8 fa             	cmp    eax,0xfffffffa
   25009:	0f 8d d5 46 00 00    	jge    296e4 <JS_CallInternal+0x6b44>
   2500f:	83 f8 f8             	cmp    eax,0xfffffff8
   25012:	0f 8c d4 46 00 00    	jl     296ec <JS_CallInternal+0x6b4c>
   25018:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   2501d:	49 83 c4 01          	add    r12,0x1
   25021:	49 89 c5             	mov    r13,rax
   25024:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   25028:	ff e0                	jmp    rax
   2502a:	f3 0f 1e fa          	endbr64
   2502e:	83 7b f8 ff          	cmp    DWORD PTR [rbx-0x8],0xffffffff
   25032:	74 54                	je     25088 <JS_CallInternal+0x24e8>
   25034:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   2503b:	48 8b 73 f0          	mov    rsi,QWORD PTR [rbx-0x10]
   2503f:	48 8b 53 f8          	mov    rdx,QWORD PTR [rbx-0x8]
   25043:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2504a:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   2504e:	e8 ed 38 02 00       	call   48940 <JS_ToObject>
   25053:	49 89 c1             	mov    r9,rax
   25056:	49 89 d0             	mov    r8,rdx
   25059:	83 fa 06             	cmp    edx,0x6
   2505c:	0f 84 de e2 ff ff    	je     23340 <JS_CallInternal+0x7a0>
   25062:	48 8b 53 f8          	mov    rdx,QWORD PTR [rbx-0x8]
   25066:	48 8b 73 f0          	mov    rsi,QWORD PTR [rbx-0x10]
   2506a:	83 fa f6             	cmp    edx,0xfffffff6
   2506d:	76 11                	jbe    25080 <JS_CallInternal+0x24e0>
   2506f:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   25072:	83 e8 01             	sub    eax,0x1
   25075:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   25078:	85 c0                	test   eax,eax
   2507a:	0f 8e 8c 6f 00 00    	jle    2c00c <JS_CallInternal+0x946c>
   25080:	4c 89 4b f0          	mov    QWORD PTR [rbx-0x10],r9
   25084:	4c 89 43 f8          	mov    QWORD PTR [rbx-0x8],r8
   25088:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   2508d:	49 83 c4 01          	add    r12,0x1
   25091:	49 89 c5             	mov    r13,rax
   25094:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   25098:	ff e0                	jmp    rax
   2509a:	f3 0f 1e fa          	endbr64
   2509e:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   250a5:	4d 8d 6c 24 04       	lea    r13,[r12+0x4]
   250aa:	45 8b 34 24          	mov    r14d,DWORD PTR [r12]
   250ae:	4c 89 68 30          	mov    QWORD PTR [rax+0x30],r13
   250b2:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   250b9:	44 89 f1             	mov    ecx,r14d
   250bc:	48 8b 80 90 01 00 00 	mov    rax,QWORD PTR [rax+0x190]
   250c3:	48 8b 50 18          	mov    rdx,QWORD PTR [rax+0x18]
   250c7:	8b 42 18             	mov    eax,DWORD PTR [rdx+0x18]
   250ca:	21 c1                	and    ecx,eax
   250cc:	8b 4c 8a 38          	mov    ecx,DWORD PTR [rdx+rcx*4+0x38]
   250d0:	48 85 c9             	test   rcx,rcx
   250d3:	0f 84 65 50 00 00    	je     2a13e <JS_CallInternal+0x759e>
   250d9:	48 8d 34 85 34 00 00 	lea    rsi,[rax*4+0x34]
   250e0:	00 
   250e1:	48 8d 04 ce          	lea    rax,[rsi+rcx*8]
   250e5:	48 01 d0             	add    rax,rdx
   250e8:	44 3b 70 04          	cmp    r14d,DWORD PTR [rax+0x4]
   250ec:	0f 85 3e 50 00 00    	jne    2a130 <JS_CallInternal+0x7590>
   250f2:	31 c0                	xor    eax,eax
   250f4:	48 89 03             	mov    QWORD PTR [rbx],rax
   250f7:	49 83 c4 05          	add    r12,0x5
   250fb:	48 83 c3 10          	add    rbx,0x10
   250ff:	48 c7 43 f8 01 00 00 	mov    QWORD PTR [rbx-0x8],0x1
   25106:	00 
   25107:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   2510d:	49 89 c5             	mov    r13,rax
   25110:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   25114:	ff e0                	jmp    rax
   25116:	f3 0f 1e fa          	endbr64
   2511a:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   25121:	4c 8b 6b f0          	mov    r13,QWORD PTR [rbx-0x10]
   25125:	4c 8b 73 f8          	mov    r14,QWORD PTR [rbx-0x8]
   25129:	48 8b 4b e8          	mov    rcx,QWORD PTR [rbx-0x18]
   2512d:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   25131:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   25138:	4c 89 ee             	mov    rsi,r13
   2513b:	48 8b 43 e0          	mov    rax,QWORD PTR [rbx-0x20]
   2513f:	4c 89 f2             	mov    rdx,r14
   25142:	48 89 8d 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],rcx
   25149:	48 89 85 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],rax
   25150:	e8 7b ed 01 00       	call   43ed0 <JS_ValueToAtom>
   25155:	89 c1                	mov    ecx,eax
   25157:	85 c0                	test   eax,eax
   25159:	0f 84 e1 e1 ff ff    	je     23340 <JS_CallInternal+0x7a0>
   2515f:	48 8b b5 40 fe ff ff 	mov    rsi,QWORD PTR [rbp-0x1c0]
   25166:	48 8b 95 50 fe ff ff 	mov    rdx,QWORD PTR [rbp-0x1b0]
   2516d:	41 b8 00 80 00 00    	mov    r8d,0x8000
   25173:	89 85 38 fe ff ff    	mov    DWORD PTR [rbp-0x1c8],eax
   25179:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   25180:	e8 db 63 02 00       	call   4b560 <JS_DeleteProperty>
   25185:	8b 8d 38 fe ff ff    	mov    ecx,DWORD PTR [rbp-0x1c8]
   2518b:	41 89 c0             	mov    r8d,eax
   2518e:	81 f9 f2 00 00 00    	cmp    ecx,0xf2
   25194:	0f 8f fe 4c 00 00    	jg     29e98 <JS_CallInternal+0x72f8>
   2519a:	45 85 c0             	test   r8d,r8d
   2519d:	0f 88 9d e1 ff ff    	js     23340 <JS_CallInternal+0x7a0>
   251a3:	83 bd 50 fe ff ff f6 	cmp    DWORD PTR [rbp-0x1b0],0xfffffff6
   251aa:	76 1e                	jbe    251ca <JS_CallInternal+0x262a>
   251ac:	48 8b 8d 40 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x1c0]
   251b3:	8b 41 fc             	mov    eax,DWORD PTR [rcx-0x4]
   251b6:	89 85 38 fe ff ff    	mov    DWORD PTR [rbp-0x1c8],eax
   251bc:	83 e8 01             	sub    eax,0x1
   251bf:	89 41 fc             	mov    DWORD PTR [rcx-0x4],eax
   251c2:	85 c0                	test   eax,eax
   251c4:	0f 8e 73 6a 00 00    	jle    2bc3d <JS_CallInternal+0x909d>
   251ca:	41 83 fe f6          	cmp    r14d,0xfffffff6
   251ce:	76 13                	jbe    251e3 <JS_CallInternal+0x2643>
   251d0:	41 8b 45 fc          	mov    eax,DWORD PTR [r13-0x4]
   251d4:	83 e8 01             	sub    eax,0x1
   251d7:	41 89 45 fc          	mov    DWORD PTR [r13-0x4],eax
   251db:	85 c0                	test   eax,eax
   251dd:	0f 8e 9e 5f 00 00    	jle    2b181 <JS_CallInternal+0x85e1>
   251e3:	31 c0                	xor    eax,eax
   251e5:	45 85 c0             	test   r8d,r8d
   251e8:	48 c7 43 e8 01 00 00 	mov    QWORD PTR [rbx-0x18],0x1
   251ef:	00 
   251f0:	0f 95 c0             	setne  al
   251f3:	48 83 eb 10          	sub    rbx,0x10
   251f7:	49 83 c4 01          	add    r12,0x1
   251fb:	48 89 43 f0          	mov    QWORD PTR [rbx-0x10],rax
   251ff:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   25205:	49 89 c5             	mov    r13,rax
   25208:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   2520c:	ff e0                	jmp    rax
   2520e:	f3 0f 1e fa          	endbr64
   25212:	48 8b 43 d8          	mov    rax,QWORD PTR [rbx-0x28]
   25216:	48 8b 53 d0          	mov    rdx,QWORD PTR [rbx-0x30]
   2521a:	83 f8 f6             	cmp    eax,0xfffffff6
   2521d:	76 04                	jbe    25223 <JS_CallInternal+0x2683>
   2521f:	83 42 fc 01          	add    DWORD PTR [rdx-0x4],0x1
   25223:	48 89 43 08          	mov    QWORD PTR [rbx+0x8],rax
   25227:	48 8b 43 e8          	mov    rax,QWORD PTR [rbx-0x18]
   2522b:	48 89 13             	mov    QWORD PTR [rbx],rdx
   2522e:	48 8b 53 e0          	mov    rdx,QWORD PTR [rbx-0x20]
   25232:	83 f8 f6             	cmp    eax,0xfffffff6
   25235:	76 04                	jbe    2523b <JS_CallInternal+0x269b>
   25237:	83 42 fc 01          	add    DWORD PTR [rdx-0x4],0x1
   2523b:	48 89 43 18          	mov    QWORD PTR [rbx+0x18],rax
   2523f:	48 8b 43 f8          	mov    rax,QWORD PTR [rbx-0x8]
   25243:	48 89 53 10          	mov    QWORD PTR [rbx+0x10],rdx
   25247:	48 8b 53 f0          	mov    rdx,QWORD PTR [rbx-0x10]
   2524b:	83 f8 f6             	cmp    eax,0xfffffff6
   2524e:	76 04                	jbe    25254 <JS_CallInternal+0x26b4>
   25250:	83 42 fc 01          	add    DWORD PTR [rdx-0x4],0x1
   25254:	48 89 53 20          	mov    QWORD PTR [rbx+0x20],rdx
   25258:	49 83 c4 01          	add    r12,0x1
   2525c:	48 83 c3 30          	add    rbx,0x30
   25260:	48 89 43 f8          	mov    QWORD PTR [rbx-0x8],rax
   25264:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   2526a:	49 89 c5             	mov    r13,rax
   2526d:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   25271:	ff e0                	jmp    rax
   25273:	f3 0f 1e fa          	endbr64
   25277:	48 8b 43 e8          	mov    rax,QWORD PTR [rbx-0x18]
   2527b:	48 8b 53 e0          	mov    rdx,QWORD PTR [rbx-0x20]
   2527f:	83 f8 f6             	cmp    eax,0xfffffff6
   25282:	76 04                	jbe    25288 <JS_CallInternal+0x26e8>
   25284:	83 42 fc 01          	add    DWORD PTR [rdx-0x4],0x1
   25288:	48 89 43 08          	mov    QWORD PTR [rbx+0x8],rax
   2528c:	48 8b 43 f8          	mov    rax,QWORD PTR [rbx-0x8]
   25290:	48 89 13             	mov    QWORD PTR [rbx],rdx
   25293:	48 8b 53 f0          	mov    rdx,QWORD PTR [rbx-0x10]
   25297:	83 f8 f6             	cmp    eax,0xfffffff6
   2529a:	76 04                	jbe    252a0 <JS_CallInternal+0x2700>
   2529c:	83 42 fc 01          	add    DWORD PTR [rdx-0x4],0x1
   252a0:	48 89 53 10          	mov    QWORD PTR [rbx+0x10],rdx
   252a4:	49 83 c4 01          	add    r12,0x1
   252a8:	48 83 c3 20          	add    rbx,0x20
   252ac:	48 89 43 f8          	mov    QWORD PTR [rbx-0x8],rax
   252b0:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   252b6:	49 89 c5             	mov    r13,rax
   252b9:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   252bd:	ff e0                	jmp    rax
   252bf:	f3 0f 1e fa          	endbr64
   252c3:	48 8b 43 f8          	mov    rax,QWORD PTR [rbx-0x8]
   252c7:	48 8b 53 f0          	mov    rdx,QWORD PTR [rbx-0x10]
   252cb:	83 f8 f6             	cmp    eax,0xfffffff6
   252ce:	76 04                	jbe    252d4 <JS_CallInternal+0x2734>
   252d0:	83 42 fc 01          	add    DWORD PTR [rdx-0x4],0x1
   252d4:	48 89 13             	mov    QWORD PTR [rbx],rdx
   252d7:	49 83 c4 01          	add    r12,0x1
   252db:	48 83 c3 10          	add    rbx,0x10
   252df:	48 89 43 f8          	mov    QWORD PTR [rbx-0x8],rax
   252e3:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   252e9:	49 89 c5             	mov    r13,rax
   252ec:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   252f0:	ff e0                	jmp    rax
   252f2:	f3 0f 1e fa          	endbr64
   252f6:	48 8b 53 d8          	mov    rdx,QWORD PTR [rbx-0x28]
   252fa:	48 8b 73 d0          	mov    rsi,QWORD PTR [rbx-0x30]
   252fe:	83 fa f6             	cmp    edx,0xfffffff6
   25301:	76 11                	jbe    25314 <JS_CallInternal+0x2774>
   25303:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   25306:	83 e8 01             	sub    eax,0x1
   25309:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   2530c:	85 c0                	test   eax,eax
   2530e:	0f 8e 17 5b 00 00    	jle    2ae2b <JS_CallInternal+0x828b>
   25314:	f3 0f 6f 73 e0       	movdqu xmm6,XMMWORD PTR [rbx-0x20]
   25319:	f3 0f 6f 7b f0       	movdqu xmm7,XMMWORD PTR [rbx-0x10]
   2531e:	49 83 c4 01          	add    r12,0x1
   25322:	48 83 eb 10          	sub    rbx,0x10
   25326:	0f 11 73 e0          	movups XMMWORD PTR [rbx-0x20],xmm6
   2532a:	0f 11 7b f0          	movups XMMWORD PTR [rbx-0x10],xmm7
   2532e:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   25334:	49 89 c5             	mov    r13,rax
   25337:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   2533b:	ff e0                	jmp    rax
   2533d:	f3 0f 1e fa          	endbr64
   25341:	48 8b 53 e8          	mov    rdx,QWORD PTR [rbx-0x18]
   25345:	48 8b 73 e0          	mov    rsi,QWORD PTR [rbx-0x20]
   25349:	83 fa f6             	cmp    edx,0xfffffff6
   2534c:	76 11                	jbe    2535f <JS_CallInternal+0x27bf>
   2534e:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   25351:	83 e8 01             	sub    eax,0x1
   25354:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   25357:	85 c0                	test   eax,eax
   25359:	0f 8e b7 5a 00 00    	jle    2ae16 <JS_CallInternal+0x8276>
   2535f:	f3 0f 6f 6b f0       	movdqu xmm5,XMMWORD PTR [rbx-0x10]
   25364:	49 83 c4 01          	add    r12,0x1
   25368:	48 83 eb 10          	sub    rbx,0x10
   2536c:	0f 11 6b f0          	movups XMMWORD PTR [rbx-0x10],xmm5
   25370:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   25376:	49 89 c5             	mov    r13,rax
   25379:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   2537d:	ff e0                	jmp    rax
   2537f:	f3 0f 1e fa          	endbr64
   25383:	48 8b 53 f8          	mov    rdx,QWORD PTR [rbx-0x8]
   25387:	48 83 eb 10          	sub    rbx,0x10
   2538b:	48 8b 33             	mov    rsi,QWORD PTR [rbx]
   2538e:	83 fa f6             	cmp    edx,0xfffffff6
   25391:	76 11                	jbe    253a4 <JS_CallInternal+0x2804>
   25393:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   25396:	83 e8 01             	sub    eax,0x1
   25399:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   2539c:	85 c0                	test   eax,eax
   2539e:	0f 8e 9c 5a 00 00    	jle    2ae40 <JS_CallInternal+0x82a0>
   253a4:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   253a9:	49 83 c4 01          	add    r12,0x1
   253ad:	49 89 c5             	mov    r13,rax
   253b0:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   253b4:	ff e0                	jmp    rax
   253b6:	f3 0f 1e fa          	endbr64
   253ba:	8b 8d bc fe ff ff    	mov    ecx,DWORD PTR [rbp-0x144]
   253c0:	41 0f b7 04 24       	movzx  eax,WORD PTR [r12]
   253c5:	4d 8d 6c 24 02       	lea    r13,[r12+0x2]
   253ca:	4c 8d 73 10          	lea    r14,[rbx+0x10]
   253ce:	48 8b bd a8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x158]
   253d5:	39 c8                	cmp    eax,ecx
   253d7:	0f 4f c1             	cmovg  eax,ecx
   253da:	48 63 d0             	movsxd rdx,eax
   253dd:	29 c1                	sub    ecx,eax
   253df:	48 c1 e2 04          	shl    rdx,0x4
   253e3:	89 ce                	mov    esi,ecx
   253e5:	48 01 fa             	add    rdx,rdi
   253e8:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   253ef:	e8 4c 4d 02 00       	call   4a140 <js_create_array>
   253f4:	48 89 53 08          	mov    QWORD PTR [rbx+0x8],rdx
   253f8:	83 7b 08 06          	cmp    DWORD PTR [rbx+0x8],0x6
   253fc:	48 89 03             	mov    QWORD PTR [rbx],rax
   253ff:	0f 84 50 5a 00 00    	je     2ae55 <JS_CallInternal+0x82b5>
   25405:	41 0f b6 44 24 02    	movzx  eax,BYTE PTR [r12+0x2]
   2540b:	4c 89 f3             	mov    rbx,r14
   2540e:	49 83 c4 03          	add    r12,0x3
   25412:	49 89 c5             	mov    r13,rax
   25415:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   25419:	ff e0                	jmp    rax
   2541b:	f3 0f 1e fa          	endbr64
   2541f:	41 80 3c 24 06       	cmp    BYTE PTR [r12],0x6
   25424:	4d 8d 74 24 01       	lea    r14,[r12+0x1]
   25429:	0f 87 95 cb fe ff    	ja     11fc4 <JS_CallInternal.cold>
   2542f:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   25434:	48 8d 15 fd 1c 0b 00 	lea    rdx,[rip+0xb1cfd]        # d7138 <qjsc_repl_size+0x46c>
   2543b:	48 63 04 82          	movsxd rax,DWORD PTR [rdx+rax*4]
   2543f:	48 01 d0             	add    rax,rdx
   25442:	3e ff e0             	notrack jmp rax
   25445:	31 f6                	xor    esi,esi
   25447:	b9 01 00 00 00       	mov    ecx,0x1
   2544c:	4c 8d 6b 10          	lea    r13,[rbx+0x10]
   25450:	ba 02 00 00 00       	mov    edx,0x2
   25455:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2545c:	e8 7f 19 02 00       	call   46de0 <JS_NewObjectProtoClass>
   25461:	48 89 53 08          	mov    QWORD PTR [rbx+0x8],rdx
   25465:	83 7b 08 06          	cmp    DWORD PTR [rbx+0x8],0x6
   25469:	48 89 03             	mov    QWORD PTR [rbx],rax
   2546c:	0f 84 be 00 00 00    	je     25530 <JS_CallInternal+0x2990>
   25472:	4c 89 eb             	mov    rbx,r13
   25475:	41 0f b6 44 24 01    	movzx  eax,BYTE PTR [r12+0x1]
   2547b:	49 83 c4 02          	add    r12,0x2
   2547f:	49 89 c5             	mov    r13,rax
   25482:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   25486:	ff e0                	jmp    rax
   25488:	48 8b 85 60 fe ff ff 	mov    rax,QWORD PTR [rbp-0x1a0]
   2548f:	48 8d 53 10          	lea    rdx,[rbx+0x10]
   25493:	48 8b 40 38          	mov    rax,QWORD PTR [rax+0x38]
   25497:	48 85 c0             	test   rax,rax
   2549a:	0f 84 0d 73 00 00    	je     2c7ad <JS_CallInternal+0x9c0d>
   254a0:	83 40 fc 01          	add    DWORD PTR [rax-0x4],0x1
   254a4:	48 89 03             	mov    QWORD PTR [rbx],rax
   254a7:	48 c7 43 08 ff ff ff 	mov    QWORD PTR [rbx+0x8],0xffffffffffffffff
   254ae:	ff 
   254af:	48 89 d3             	mov    rbx,rdx
   254b2:	eb c1                	jmp    25475 <JS_CallInternal+0x28d5>
   254b4:	83 bd 80 fe ff ff f6 	cmp    DWORD PTR [rbp-0x180],0xfffffff6
   254bb:	48 8d 43 10          	lea    rax,[rbx+0x10]
   254bf:	76 0b                	jbe    254cc <JS_CallInternal+0x292c>
   254c1:	48 8b 8d 70 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x190]
   254c8:	83 41 fc 01          	add    DWORD PTR [rcx-0x4],0x1
   254cc:	48 8b 8d 70 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x190]
   254d3:	48 89 0b             	mov    QWORD PTR [rbx],rcx
   254d6:	48 8b 8d 80 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x180]
   254dd:	48 89 4b 08          	mov    QWORD PTR [rbx+0x8],rcx
   254e1:	48 89 c3             	mov    rbx,rax
   254e4:	eb 8f                	jmp    25475 <JS_CallInternal+0x28d5>
   254e6:	48 8b 85 d8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x128]
   254ed:	48 8b 8d c8 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x138]
   254f4:	4c 8d 6b 10          	lea    r13,[rbx+0x10]
   254f8:	48 8b 95 a8 fe ff ff 	mov    rdx,QWORD PTR [rbp-0x158]
   254ff:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   25506:	44 0f b7 40 38       	movzx  r8d,WORD PTR [rax+0x38]
   2550b:	8b 85 bc fe ff ff    	mov    eax,DWORD PTR [rbp-0x144]
   25511:	41 39 c0             	cmp    r8d,eax
   25514:	89 c6                	mov    esi,eax
   25516:	44 0f 4f c0          	cmovg  r8d,eax
   2551a:	e8 f1 6a 02 00       	call   4c010 <js_build_mapped_arguments>
   2551f:	48 89 53 08          	mov    QWORD PTR [rbx+0x8],rdx
   25523:	83 7b 08 06          	cmp    DWORD PTR [rbx+0x8],0x6
   25527:	48 89 03             	mov    QWORD PTR [rbx],rax
   2552a:	0f 85 42 ff ff ff    	jne    25472 <JS_CallInternal+0x28d2>
   25530:	4c 89 eb             	mov    rbx,r13
   25533:	4d 89 f4             	mov    r12,r14
   25536:	e9 05 de ff ff       	jmp    23340 <JS_CallInternal+0x7a0>
   2553b:	48 8b 8d e8 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x118]
   25542:	8b 85 bc fe ff ff    	mov    eax,DWORD PTR [rbp-0x144]
   25548:	4c 8d 6b 10          	lea    r13,[rbx+0x10]
   2554c:	48 c7 85 58 ff ff ff 	mov    QWORD PTR [rbp-0xa8],0x0
   25553:	00 00 00 00 
   25557:	48 8b 91 58 01 00 00 	mov    rdx,QWORD PTR [rcx+0x158]
   2555e:	48 89 85 50 ff ff ff 	mov    QWORD PTR [rbp-0xb0],rax
   25565:	48 8b 81 50 01 00 00 	mov    rax,QWORD PTR [rcx+0x150]
   2556c:	83 fa f6             	cmp    edx,0xfffffff6
   2556f:	76 04                	jbe    25575 <JS_CallInternal+0x29d5>
   25571:	83 40 fc 01          	add    DWORD PTR [rax-0x4],0x1
   25575:	48 8b 8d e8 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x118]
   2557c:	48 89 85 60 ff ff ff 	mov    QWORD PTR [rbp-0xa0],rax
   25583:	48 89 95 68 ff ff ff 	mov    QWORD PTR [rbp-0x98],rdx
   2558a:	48 8b 81 60 01 00 00 	mov    rax,QWORD PTR [rcx+0x160]
   25591:	83 b9 68 01 00 00 f6 	cmp    DWORD PTR [rcx+0x168],0xfffffff6
   25598:	48 89 85 70 ff ff ff 	mov    QWORD PTR [rbp-0x90],rax
   2559f:	76 04                	jbe    255a5 <JS_CallInternal+0x2a05>
   255a1:	83 40 fc 02          	add    DWORD PTR [rax-0x4],0x2
   255a5:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   255ac:	48 8d 8d 50 ff ff ff 	lea    rcx,[rbp-0xb0]
   255b3:	ba 08 00 00 00       	mov    edx,0x8
   255b8:	48 89 85 78 ff ff ff 	mov    QWORD PTR [rbp-0x88],rax
   255bf:	48 8b 77 38          	mov    rsi,QWORD PTR [rdi+0x38]
   255c3:	83 46 fc 01          	add    DWORD PTR [rsi-0x4],0x1
   255c7:	e8 94 12 02 00       	call   46860 <JS_NewObjectFromShape>
   255cc:	49 89 c1             	mov    r9,rax
   255cf:	48 89 d1             	mov    rcx,rdx
   255d2:	83 fa 06             	cmp    edx,0x6
   255d5:	0f 84 e4 71 00 00    	je     2c7bf <JS_CallInternal+0x9c1f>
   255db:	8b bd bc fe ff ff    	mov    edi,DWORD PTR [rbp-0x144]
   255e1:	31 c0                	xor    eax,eax
   255e3:	85 ff                	test   edi,edi
   255e5:	0f 8f 90 6b 00 00    	jg     2c17b <JS_CallInternal+0x95db>
   255eb:	49 89 41 30          	mov    QWORD PTR [r9+0x30],rax
   255ef:	8b 85 bc fe ff ff    	mov    eax,DWORD PTR [rbp-0x144]
   255f5:	41 89 41 38          	mov    DWORD PTR [r9+0x38],eax
   255f9:	4c 89 0b             	mov    QWORD PTR [rbx],r9
   255fc:	48 89 4b 08          	mov    QWORD PTR [rbx+0x8],rcx
   25600:	4c 89 eb             	mov    rbx,r13
   25603:	e9 6d fe ff ff       	jmp    25475 <JS_CallInternal+0x28d5>
   25608:	48 8b bd c8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x138]
   2560f:	48 8d 4b 10          	lea    rcx,[rbx+0x10]
   25613:	48 8b 57 10          	mov    rdx,QWORD PTR [rdi+0x10]
   25617:	48 8b 47 08          	mov    rax,QWORD PTR [rdi+0x8]
   2561b:	83 fa f6             	cmp    edx,0xfffffff6
   2561e:	76 04                	jbe    25624 <JS_CallInternal+0x2a84>
   25620:	83 40 fc 01          	add    DWORD PTR [rax-0x4],0x1
   25624:	48 89 03             	mov    QWORD PTR [rbx],rax
   25627:	48 89 53 08          	mov    QWORD PTR [rbx+0x8],rdx
   2562b:	48 89 cb             	mov    rbx,rcx
   2562e:	e9 42 fe ff ff       	jmp    25475 <JS_CallInternal+0x28d5>
   25633:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2563a:	31 f6                	xor    esi,esi
   2563c:	4c 8d 6b 10          	lea    r13,[rbx+0x10]
   25640:	e8 0b d4 ff ff       	call   22a50 <JS_GetScriptOrModuleName>
   25645:	85 c0                	test   eax,eax
   25647:	0f 84 37 67 00 00    	je     2bd84 <JS_CallInternal+0x91e4>
   2564d:	48 8b 8d e8 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x118]
   25654:	48 8b 91 b8 01 00 00 	mov    rdx,QWORD PTR [rcx+0x1b8]
   2565b:	48 81 c1 b0 01 00 00 	add    rcx,0x1b0
   25662:	48 39 d1             	cmp    rcx,rdx
   25665:	75 16                	jne    2567d <JS_CallInternal+0x2add>
   25667:	e9 fc 78 00 00       	jmp    2cf68 <JS_CallInternal+0xa3c8>
   2566c:	0f 1f 40 00          	nop    DWORD PTR [rax+0x0]
   25670:	48 8b 52 08          	mov    rdx,QWORD PTR [rdx+0x8]
   25674:	48 39 d1             	cmp    rcx,rdx
   25677:	0f 84 bd 66 00 00    	je     2bd3a <JS_CallInternal+0x919a>
   2567d:	3b 42 f8             	cmp    eax,DWORD PTR [rdx-0x8]
   25680:	75 ee                	jne    25670 <JS_CallInternal+0x2ad0>
   25682:	48 83 ea 18          	sub    rdx,0x18
   25686:	3d f2 00 00 00       	cmp    eax,0xf2
   2568b:	0f 8f b2 66 00 00    	jg     2bd43 <JS_CallInternal+0x91a3>
   25691:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   25698:	48 89 d6             	mov    rsi,rdx
   2569b:	e8 80 d4 ff ff       	call   22b20 <JS_GetImportMeta>
   256a0:	48 89 03             	mov    QWORD PTR [rbx],rax
   256a3:	48 89 53 08          	mov    QWORD PTR [rbx+0x8],rdx
   256a7:	83 fa 06             	cmp    edx,0x6
   256aa:	0f 85 c2 fd ff ff    	jne    25472 <JS_CallInternal+0x28d2>
   256b0:	e9 7b fe ff ff       	jmp    25530 <JS_CallInternal+0x2990>
   256b5:	0f 1f 00             	nop    DWORD PTR [rax]
   256b8:	f3 0f 1e fa          	endbr64
   256bc:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   256c3:	b9 01 00 00 00       	mov    ecx,0x1
   256c8:	4c 8d 73 10          	lea    r14,[rbx+0x10]
   256cc:	48 8b 47 58          	mov    rax,QWORD PTR [rdi+0x58]
   256d0:	48 8b 70 10          	mov    rsi,QWORD PTR [rax+0x10]
   256d4:	48 8b 50 18          	mov    rdx,QWORD PTR [rax+0x18]
   256d8:	e8 03 17 02 00       	call   46de0 <JS_NewObjectProtoClass>
   256dd:	48 89 53 08          	mov    QWORD PTR [rbx+0x8],rdx
   256e1:	83 7b 08 06          	cmp    DWORD PTR [rbx+0x8],0x6
   256e5:	48 89 03             	mov    QWORD PTR [rbx],rax
   256e8:	0f 84 72 57 00 00    	je     2ae60 <JS_CallInternal+0x82c0>
   256ee:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   256f3:	4c 89 f3             	mov    rbx,r14
   256f6:	49 83 c4 01          	add    r12,0x1
   256fa:	49 89 c5             	mov    r13,rax
   256fd:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   25701:	ff e0                	jmp    rax
   25703:	f3 0f 1e fa          	endbr64
   25707:	48 c7 03 01 00 00 00 	mov    QWORD PTR [rbx],0x1
   2570e:	49 83 c4 01          	add    r12,0x1
   25712:	48 83 c3 10          	add    rbx,0x10
   25716:	48 c7 43 f8 01 00 00 	mov    QWORD PTR [rbx-0x8],0x1
   2571d:	00 
   2571e:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   25724:	49 89 c5             	mov    r13,rax
   25727:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   2572b:	ff e0                	jmp    rax
   2572d:	f3 0f 1e fa          	endbr64
   25731:	48 c7 03 00 00 00 00 	mov    QWORD PTR [rbx],0x0
   25738:	49 83 c4 01          	add    r12,0x1
   2573c:	48 83 c3 10          	add    rbx,0x10
   25740:	48 c7 43 f8 01 00 00 	mov    QWORD PTR [rbx-0x8],0x1
   25747:	00 
   25748:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   2574e:	49 89 c5             	mov    r13,rax
   25751:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   25755:	ff e0                	jmp    rax
   25757:	f3 0f 1e fa          	endbr64
   2575b:	48 8b 85 d8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x128]
   25762:	f6 40 10 01          	test   BYTE PTR [rax+0x10],0x1
   25766:	0f 85 ed 3e 00 00    	jne    29659 <JS_CallInternal+0x6ab9>
   2576c:	83 bd 88 fe ff ff ff 	cmp    DWORD PTR [rbp-0x178],0xffffffff
   25773:	0f 85 47 67 00 00    	jne    2bec0 <JS_CallInternal+0x9320>
   25779:	48 8b 85 78 fe ff ff 	mov    rax,QWORD PTR [rbp-0x188]
   25780:	83 40 fc 01          	add    DWORD PTR [rax-0x4],0x1
   25784:	48 8b 85 88 fe ff ff 	mov    rax,QWORD PTR [rbp-0x178]
   2578b:	48 8b 8d 78 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x188]
   25792:	48 89 0b             	mov    QWORD PTR [rbx],rcx
   25795:	49 83 c4 01          	add    r12,0x1
   25799:	48 83 c3 10          	add    rbx,0x10
   2579d:	48 89 43 f8          	mov    QWORD PTR [rbx-0x8],rax
   257a1:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   257a7:	49 89 c5             	mov    r13,rax
   257aa:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   257ae:	ff e0                	jmp    rax
   257b0:	f3 0f 1e fa          	endbr64
   257b4:	48 8b 73 e0          	mov    rsi,QWORD PTR [rbx-0x20]
   257b8:	48 8b 7b e8          	mov    rdi,QWORD PTR [rbx-0x18]
   257bc:	48 8b 4b f0          	mov    rcx,QWORD PTR [rbx-0x10]
   257c0:	4c 8b 43 f8          	mov    r8,QWORD PTR [rbx-0x8]
   257c4:	49 89 f5             	mov    r13,rsi
   257c7:	49 89 fe             	mov    r14,rdi
   257ca:	83 ff ff             	cmp    edi,0xffffffff
   257cd:	0f 85 1a 43 00 00    	jne    29aed <JS_CallInternal+0x6f4d>
   257d3:	45 85 c0             	test   r8d,r8d
   257d6:	0f 85 11 43 00 00    	jne    29aed <JS_CallInternal+0x6f4d>
   257dc:	66 83 7e 12 02       	cmp    WORD PTR [rsi+0x12],0x2
   257e1:	0f 85 06 43 00 00    	jne    29aed <JS_CallInternal+0x6f4d>
   257e7:	3b 4e 38             	cmp    ecx,DWORD PTR [rsi+0x38]
   257ea:	0f 83 fd 42 00 00    	jae    29aed <JS_CallInternal+0x6f4d>
   257f0:	89 c8                	mov    eax,ecx
   257f2:	48 c1 e0 04          	shl    rax,0x4
   257f6:	48 03 46 30          	add    rax,QWORD PTR [rsi+0x30]
   257fa:	48 8b 08             	mov    rcx,QWORD PTR [rax]
   257fd:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
   25801:	83 f8 f6             	cmp    eax,0xfffffff6
   25804:	76 04                	jbe    2580a <JS_CallInternal+0x2c6a>
   25806:	83 41 fc 01          	add    DWORD PTR [rcx-0x4],0x1
   2580a:	41 83 fe f6          	cmp    r14d,0xfffffff6
   2580e:	76 13                	jbe    25823 <JS_CallInternal+0x2c83>
   25810:	41 8b 7d fc          	mov    edi,DWORD PTR [r13-0x4]
   25814:	8d 57 ff             	lea    edx,[rdi-0x1]
   25817:	41 89 55 fc          	mov    DWORD PTR [r13-0x4],edx
   2581b:	85 d2                	test   edx,edx
   2581d:	0f 8e 6c 53 00 00    	jle    2ab8f <JS_CallInternal+0x7fef>
   25823:	48 89 4b e0          	mov    QWORD PTR [rbx-0x20],rcx
   25827:	49 83 c4 01          	add    r12,0x1
   2582b:	48 83 eb 10          	sub    rbx,0x10
   2582f:	48 89 43 f8          	mov    QWORD PTR [rbx-0x8],rax
   25833:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   25839:	49 89 c5             	mov    r13,rax
   2583c:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   25840:	ff e0                	jmp    rax
   25842:	f3 0f 1e fa          	endbr64
   25846:	48 8b 85 98 fe ff ff 	mov    rax,QWORD PTR [rbp-0x168]
   2584d:	f3 0f 6f 73 f0       	movdqu xmm6,XMMWORD PTR [rbx-0x10]
   25852:	48 83 eb 10          	sub    rbx,0x10
   25856:	48 8b 00             	mov    rax,QWORD PTR [rax]
   25859:	48 8b 40 18          	mov    rax,QWORD PTR [rax+0x18]
   2585d:	48 8b 50 08          	mov    rdx,QWORD PTR [rax+0x8]
   25861:	48 8b 30             	mov    rsi,QWORD PTR [rax]
   25864:	0f 11 30             	movups XMMWORD PTR [rax],xmm6
   25867:	83 fa f6             	cmp    edx,0xfffffff6
   2586a:	76 11                	jbe    2587d <JS_CallInternal+0x2cdd>
   2586c:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   2586f:	83 e8 01             	sub    eax,0x1
   25872:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   25875:	85 c0                	test   eax,eax
   25877:	0f 8e 6c 55 00 00    	jle    2ade9 <JS_CallInternal+0x8249>
   2587d:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   25882:	49 83 c4 01          	add    r12,0x1
   25886:	49 89 c5             	mov    r13,rax
   25889:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   2588d:	ff e0                	jmp    rax
   2588f:	f3 0f 1e fa          	endbr64
   25893:	48 8b 85 98 fe ff ff 	mov    rax,QWORD PTR [rbp-0x168]
   2589a:	48 8d 4b 10          	lea    rcx,[rbx+0x10]
   2589e:	48 8b 40 18          	mov    rax,QWORD PTR [rax+0x18]
   258a2:	48 8b 40 18          	mov    rax,QWORD PTR [rax+0x18]
   258a6:	48 8b 10             	mov    rdx,QWORD PTR [rax]
   258a9:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
   258ad:	83 f8 f6             	cmp    eax,0xfffffff6
   258b0:	76 04                	jbe    258b6 <JS_CallInternal+0x2d16>
   258b2:	83 42 fc 01          	add    DWORD PTR [rdx-0x4],0x1
   258b6:	48 89 13             	mov    QWORD PTR [rbx],rdx
   258b9:	49 83 c4 01          	add    r12,0x1
   258bd:	48 89 43 08          	mov    QWORD PTR [rbx+0x8],rax
   258c1:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   258c7:	48 89 cb             	mov    rbx,rcx
   258ca:	49 89 c5             	mov    r13,rax
   258cd:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   258d1:	ff e0                	jmp    rax
   258d3:	f3 0f 1e fa          	endbr64
   258d7:	48 8b 85 98 fe ff ff 	mov    rax,QWORD PTR [rbp-0x168]
   258de:	48 8d 4b 10          	lea    rcx,[rbx+0x10]
   258e2:	48 8b 40 10          	mov    rax,QWORD PTR [rax+0x10]
   258e6:	48 8b 40 18          	mov    rax,QWORD PTR [rax+0x18]
   258ea:	48 8b 10             	mov    rdx,QWORD PTR [rax]
   258ed:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
   258f1:	83 f8 f6             	cmp    eax,0xfffffff6
   258f4:	76 04                	jbe    258fa <JS_CallInternal+0x2d5a>
   258f6:	83 42 fc 01          	add    DWORD PTR [rdx-0x4],0x1
   258fa:	48 89 13             	mov    QWORD PTR [rbx],rdx
   258fd:	49 83 c4 01          	add    r12,0x1
   25901:	48 89 43 08          	mov    QWORD PTR [rbx+0x8],rax
   25905:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   2590b:	48 89 cb             	mov    rbx,rcx
   2590e:	49 89 c5             	mov    r13,rax
   25911:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   25915:	ff e0                	jmp    rax
   25917:	f3 0f 1e fa          	endbr64
   2591b:	48 8b 85 98 fe ff ff 	mov    rax,QWORD PTR [rbp-0x168]
   25922:	48 8d 4b 10          	lea    rcx,[rbx+0x10]
   25926:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
   2592a:	48 8b 40 18          	mov    rax,QWORD PTR [rax+0x18]
   2592e:	48 8b 10             	mov    rdx,QWORD PTR [rax]
   25931:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
   25935:	83 f8 f6             	cmp    eax,0xfffffff6
   25938:	76 04                	jbe    2593e <JS_CallInternal+0x2d9e>
   2593a:	83 42 fc 01          	add    DWORD PTR [rdx-0x4],0x1
   2593e:	48 89 13             	mov    QWORD PTR [rbx],rdx
   25941:	49 83 c4 01          	add    r12,0x1
   25945:	48 89 43 08          	mov    QWORD PTR [rbx+0x8],rax
   25949:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   2594f:	48 89 cb             	mov    rbx,rcx
   25952:	49 89 c5             	mov    r13,rax
   25955:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   25959:	ff e0                	jmp    rax
   2595b:	f3 0f 1e fa          	endbr64
   2595f:	48 8b 85 98 fe ff ff 	mov    rax,QWORD PTR [rbp-0x168]
   25966:	48 8d 4b 10          	lea    rcx,[rbx+0x10]
   2596a:	48 8b 00             	mov    rax,QWORD PTR [rax]
   2596d:	48 8b 40 18          	mov    rax,QWORD PTR [rax+0x18]
   25971:	48 8b 10             	mov    rdx,QWORD PTR [rax]
   25974:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
   25978:	83 f8 f6             	cmp    eax,0xfffffff6
   2597b:	76 04                	jbe    25981 <JS_CallInternal+0x2de1>
   2597d:	83 42 fc 01          	add    DWORD PTR [rdx-0x4],0x1
   25981:	48 89 13             	mov    QWORD PTR [rbx],rdx
   25984:	49 83 c4 01          	add    r12,0x1
   25988:	48 89 43 08          	mov    QWORD PTR [rbx+0x8],rax
   2598c:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   25992:	48 89 cb             	mov    rbx,rcx
   25995:	49 89 c5             	mov    r13,rax
   25998:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   2599c:	ff e0                	jmp    rax
   2599e:	f3 0f 1e fa          	endbr64
   259a2:	48 8b 43 f8          	mov    rax,QWORD PTR [rbx-0x8]
   259a6:	48 8b 53 f0          	mov    rdx,QWORD PTR [rbx-0x10]
   259aa:	83 f8 f6             	cmp    eax,0xfffffff6
   259ad:	76 04                	jbe    259b3 <JS_CallInternal+0x2e13>
   259af:	83 42 fc 01          	add    DWORD PTR [rdx-0x4],0x1
   259b3:	48 8b bd 90 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x170]
   259ba:	48 8b 4f 38          	mov    rcx,QWORD PTR [rdi+0x38]
   259be:	48 8b 77 30          	mov    rsi,QWORD PTR [rdi+0x30]
   259c2:	48 89 47 38          	mov    QWORD PTR [rdi+0x38],rax
   259c6:	48 89 57 30          	mov    QWORD PTR [rdi+0x30],rdx
   259ca:	83 f9 f6             	cmp    ecx,0xfffffff6
   259cd:	76 11                	jbe    259e0 <JS_CallInternal+0x2e40>
   259cf:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   259d2:	83 e8 01             	sub    eax,0x1
   259d5:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   259d8:	85 c0                	test   eax,eax
   259da:	0f 8e 1e 54 00 00    	jle    2adfe <JS_CallInternal+0x825e>
   259e0:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   259e5:	49 83 c4 01          	add    r12,0x1
   259e9:	49 89 c5             	mov    r13,rax
   259ec:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   259f0:	ff e0                	jmp    rax
   259f2:	f3 0f 1e fa          	endbr64
   259f6:	48 8b 43 f8          	mov    rax,QWORD PTR [rbx-0x8]
   259fa:	48 8b 53 f0          	mov    rdx,QWORD PTR [rbx-0x10]
   259fe:	83 f8 f6             	cmp    eax,0xfffffff6
   25a01:	76 04                	jbe    25a07 <JS_CallInternal+0x2e67>
   25a03:	83 42 fc 01          	add    DWORD PTR [rdx-0x4],0x1
   25a07:	48 8b bd 90 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x170]
   25a0e:	48 8b 4f 28          	mov    rcx,QWORD PTR [rdi+0x28]
   25a12:	48 8b 77 20          	mov    rsi,QWORD PTR [rdi+0x20]
   25a16:	48 89 47 28          	mov    QWORD PTR [rdi+0x28],rax
   25a1a:	48 89 57 20          	mov    QWORD PTR [rdi+0x20],rdx
   25a1e:	83 f9 f6             	cmp    ecx,0xfffffff6
   25a21:	76 11                	jbe    25a34 <JS_CallInternal+0x2e94>
   25a23:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   25a26:	83 e8 01             	sub    eax,0x1
   25a29:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   25a2c:	85 c0                	test   eax,eax
   25a2e:	0f 8e 81 50 00 00    	jle    2aab5 <JS_CallInternal+0x7f15>
   25a34:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   25a39:	49 83 c4 01          	add    r12,0x1
   25a3d:	49 89 c5             	mov    r13,rax
   25a40:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   25a44:	ff e0                	jmp    rax
   25a46:	f3 0f 1e fa          	endbr64
   25a4a:	48 8b 43 f8          	mov    rax,QWORD PTR [rbx-0x8]
   25a4e:	48 8b 53 f0          	mov    rdx,QWORD PTR [rbx-0x10]
   25a52:	83 f8 f6             	cmp    eax,0xfffffff6
   25a55:	76 04                	jbe    25a5b <JS_CallInternal+0x2ebb>
   25a57:	83 42 fc 01          	add    DWORD PTR [rdx-0x4],0x1
   25a5b:	48 8b bd 90 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x170]
   25a62:	48 8b 4f 18          	mov    rcx,QWORD PTR [rdi+0x18]
   25a66:	48 8b 77 10          	mov    rsi,QWORD PTR [rdi+0x10]
   25a6a:	48 89 47 18          	mov    QWORD PTR [rdi+0x18],rax
   25a6e:	48 89 57 10          	mov    QWORD PTR [rdi+0x10],rdx
   25a72:	83 f9 f6             	cmp    ecx,0xfffffff6
   25a75:	76 11                	jbe    25a88 <JS_CallInternal+0x2ee8>
   25a77:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   25a7a:	83 e8 01             	sub    eax,0x1
   25a7d:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   25a80:	85 c0                	test   eax,eax
   25a82:	0f 8e 45 50 00 00    	jle    2aacd <JS_CallInternal+0x7f2d>
   25a88:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   25a8d:	49 83 c4 01          	add    r12,0x1
   25a91:	49 89 c5             	mov    r13,rax
   25a94:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   25a98:	ff e0                	jmp    rax
   25a9a:	f3 0f 1e fa          	endbr64
   25a9e:	48 8b 43 f8          	mov    rax,QWORD PTR [rbx-0x8]
   25aa2:	48 8b 53 f0          	mov    rdx,QWORD PTR [rbx-0x10]
   25aa6:	83 f8 f6             	cmp    eax,0xfffffff6
   25aa9:	76 04                	jbe    25aaf <JS_CallInternal+0x2f0f>
   25aab:	83 42 fc 01          	add    DWORD PTR [rdx-0x4],0x1
   25aaf:	48 8b bd 90 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x170]
   25ab6:	48 8b 4f 08          	mov    rcx,QWORD PTR [rdi+0x8]
   25aba:	48 8b 37             	mov    rsi,QWORD PTR [rdi]
   25abd:	48 89 47 08          	mov    QWORD PTR [rdi+0x8],rax
   25ac1:	48 89 17             	mov    QWORD PTR [rdi],rdx
   25ac4:	83 f9 f6             	cmp    ecx,0xfffffff6
   25ac7:	76 11                	jbe    25ada <JS_CallInternal+0x2f3a>
   25ac9:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   25acc:	83 e8 01             	sub    eax,0x1
   25acf:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   25ad2:	85 c0                	test   eax,eax
   25ad4:	0f 8e ae 4f 00 00    	jle    2aa88 <JS_CallInternal+0x7ee8>
   25ada:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   25adf:	49 83 c4 01          	add    r12,0x1
   25ae3:	49 89 c5             	mov    r13,rax
   25ae6:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   25aea:	ff e0                	jmp    rax
   25aec:	f3 0f 1e fa          	endbr64
   25af0:	48 8b 85 90 fe ff ff 	mov    rax,QWORD PTR [rbp-0x170]
   25af7:	f3 0f 6f 6b f0       	movdqu xmm5,XMMWORD PTR [rbx-0x10]
   25afc:	48 83 eb 10          	sub    rbx,0x10
   25b00:	48 8b 50 38          	mov    rdx,QWORD PTR [rax+0x38]
   25b04:	48 8b 70 30          	mov    rsi,QWORD PTR [rax+0x30]
   25b08:	0f 11 68 30          	movups XMMWORD PTR [rax+0x30],xmm5
   25b0c:	83 fa f6             	cmp    edx,0xfffffff6
   25b0f:	76 11                	jbe    25b22 <JS_CallInternal+0x2f82>
   25b11:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   25b14:	83 e8 01             	sub    eax,0x1
   25b17:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   25b1a:	85 c0                	test   eax,eax
   25b1c:	0f 8e 7e 4f 00 00    	jle    2aaa0 <JS_CallInternal+0x7f00>
   25b22:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   25b27:	49 83 c4 01          	add    r12,0x1
   25b2b:	49 89 c5             	mov    r13,rax
   25b2e:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   25b32:	ff e0                	jmp    rax
   25b34:	f3 0f 1e fa          	endbr64
   25b38:	48 8b 85 90 fe ff ff 	mov    rax,QWORD PTR [rbp-0x170]
   25b3f:	f3 0f 6f 53 f0       	movdqu xmm2,XMMWORD PTR [rbx-0x10]
   25b44:	48 83 eb 10          	sub    rbx,0x10
   25b48:	48 8b 50 28          	mov    rdx,QWORD PTR [rax+0x28]
   25b4c:	48 8b 70 20          	mov    rsi,QWORD PTR [rax+0x20]
   25b50:	0f 11 50 20          	movups XMMWORD PTR [rax+0x20],xmm2
   25b54:	83 fa f6             	cmp    edx,0xfffffff6
   25b57:	76 11                	jbe    25b6a <JS_CallInternal+0x2fca>
   25b59:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   25b5c:	83 e8 01             	sub    eax,0x1
   25b5f:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   25b62:	85 c0                	test   eax,eax
   25b64:	0f 8e 2d 52 00 00    	jle    2ad97 <JS_CallInternal+0x81f7>
   25b6a:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   25b6f:	49 83 c4 01          	add    r12,0x1
   25b73:	49 89 c5             	mov    r13,rax
   25b76:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   25b7a:	ff e0                	jmp    rax
   25b7c:	f3 0f 1e fa          	endbr64
   25b80:	48 8b 85 90 fe ff ff 	mov    rax,QWORD PTR [rbp-0x170]
   25b87:	f3 0f 6f 63 f0       	movdqu xmm4,XMMWORD PTR [rbx-0x10]
   25b8c:	48 83 eb 10          	sub    rbx,0x10
   25b90:	48 8b 50 18          	mov    rdx,QWORD PTR [rax+0x18]
   25b94:	48 8b 70 10          	mov    rsi,QWORD PTR [rax+0x10]
   25b98:	0f 11 60 10          	movups XMMWORD PTR [rax+0x10],xmm4
   25b9c:	83 fa f6             	cmp    edx,0xfffffff6
   25b9f:	76 11                	jbe    25bb2 <JS_CallInternal+0x3012>
   25ba1:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   25ba4:	83 e8 01             	sub    eax,0x1
   25ba7:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   25baa:	85 c0                	test   eax,eax
   25bac:	0f 8e fa 51 00 00    	jle    2adac <JS_CallInternal+0x820c>
   25bb2:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   25bb7:	49 83 c4 01          	add    r12,0x1
   25bbb:	49 89 c5             	mov    r13,rax
   25bbe:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   25bc2:	ff e0                	jmp    rax
   25bc4:	f3 0f 1e fa          	endbr64
   25bc8:	48 8b 85 90 fe ff ff 	mov    rax,QWORD PTR [rbp-0x170]
   25bcf:	f3 0f 6f 4b f0       	movdqu xmm1,XMMWORD PTR [rbx-0x10]
   25bd4:	48 83 eb 10          	sub    rbx,0x10
   25bd8:	48 8b 50 08          	mov    rdx,QWORD PTR [rax+0x8]
   25bdc:	48 8b 30             	mov    rsi,QWORD PTR [rax]
   25bdf:	0f 11 08             	movups XMMWORD PTR [rax],xmm1
   25be2:	83 fa f6             	cmp    edx,0xfffffff6
   25be5:	76 11                	jbe    25bf8 <JS_CallInternal+0x3058>
   25be7:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   25bea:	83 e8 01             	sub    eax,0x1
   25bed:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   25bf0:	85 c0                	test   eax,eax
   25bf2:	0f 8e 72 51 00 00    	jle    2ad6a <JS_CallInternal+0x81ca>
   25bf8:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   25bfd:	49 83 c4 01          	add    r12,0x1
   25c01:	49 89 c5             	mov    r13,rax
   25c04:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   25c08:	ff e0                	jmp    rax
   25c0a:	f3 0f 1e fa          	endbr64
   25c0e:	48 8b 85 90 fe ff ff 	mov    rax,QWORD PTR [rbp-0x170]
   25c15:	48 8d 4b 10          	lea    rcx,[rbx+0x10]
   25c19:	48 8b 50 30          	mov    rdx,QWORD PTR [rax+0x30]
   25c1d:	48 8b 40 38          	mov    rax,QWORD PTR [rax+0x38]
   25c21:	83 f8 f6             	cmp    eax,0xfffffff6
   25c24:	76 04                	jbe    25c2a <JS_CallInternal+0x308a>
   25c26:	83 42 fc 01          	add    DWORD PTR [rdx-0x4],0x1
   25c2a:	48 89 13             	mov    QWORD PTR [rbx],rdx
   25c2d:	49 83 c4 01          	add    r12,0x1
   25c31:	48 89 43 08          	mov    QWORD PTR [rbx+0x8],rax
   25c35:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   25c3b:	48 89 cb             	mov    rbx,rcx
   25c3e:	49 89 c5             	mov    r13,rax
   25c41:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   25c45:	ff e0                	jmp    rax
   25c47:	f3 0f 1e fa          	endbr64
   25c4b:	48 8b 85 90 fe ff ff 	mov    rax,QWORD PTR [rbp-0x170]
   25c52:	48 8d 4b 10          	lea    rcx,[rbx+0x10]
   25c56:	48 8b 50 20          	mov    rdx,QWORD PTR [rax+0x20]
   25c5a:	48 8b 40 28          	mov    rax,QWORD PTR [rax+0x28]
   25c5e:	83 f8 f6             	cmp    eax,0xfffffff6
   25c61:	76 04                	jbe    25c67 <JS_CallInternal+0x30c7>
   25c63:	83 42 fc 01          	add    DWORD PTR [rdx-0x4],0x1
   25c67:	48 89 13             	mov    QWORD PTR [rbx],rdx
   25c6a:	49 83 c4 01          	add    r12,0x1
   25c6e:	48 89 43 08          	mov    QWORD PTR [rbx+0x8],rax
   25c72:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   25c78:	48 89 cb             	mov    rbx,rcx
   25c7b:	49 89 c5             	mov    r13,rax
   25c7e:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   25c82:	ff e0                	jmp    rax
   25c84:	f3 0f 1e fa          	endbr64
   25c88:	48 8b 85 90 fe ff ff 	mov    rax,QWORD PTR [rbp-0x170]
   25c8f:	48 8d 4b 10          	lea    rcx,[rbx+0x10]
   25c93:	48 8b 50 10          	mov    rdx,QWORD PTR [rax+0x10]
   25c97:	48 8b 40 18          	mov    rax,QWORD PTR [rax+0x18]
   25c9b:	83 f8 f6             	cmp    eax,0xfffffff6
   25c9e:	76 04                	jbe    25ca4 <JS_CallInternal+0x3104>
   25ca0:	83 42 fc 01          	add    DWORD PTR [rdx-0x4],0x1
   25ca4:	48 89 13             	mov    QWORD PTR [rbx],rdx
   25ca7:	49 83 c4 01          	add    r12,0x1
   25cab:	48 89 43 08          	mov    QWORD PTR [rbx+0x8],rax
   25caf:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   25cb5:	48 89 cb             	mov    rbx,rcx
   25cb8:	49 89 c5             	mov    r13,rax
   25cbb:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   25cbf:	ff e0                	jmp    rax
   25cc1:	f3 0f 1e fa          	endbr64
   25cc5:	41 0f b7 04 24       	movzx  eax,WORD PTR [r12]
   25cca:	48 8b 8d 98 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x168]
   25cd1:	48 8b 04 c1          	mov    rax,QWORD PTR [rcx+rax*8]
   25cd5:	48 8b 40 18          	mov    rax,QWORD PTR [rax+0x18]
   25cd9:	48 8b 10             	mov    rdx,QWORD PTR [rax]
   25cdc:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
   25ce0:	83 f8 f6             	cmp    eax,0xfffffff6
   25ce3:	76 04                	jbe    25ce9 <JS_CallInternal+0x3149>
   25ce5:	83 42 fc 01          	add    DWORD PTR [rdx-0x4],0x1
   25ce9:	48 89 13             	mov    QWORD PTR [rbx],rdx
   25cec:	49 83 c4 03          	add    r12,0x3
   25cf0:	48 83 c3 10          	add    rbx,0x10
   25cf4:	48 89 43 f8          	mov    QWORD PTR [rbx-0x8],rax
   25cf8:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   25cfe:	49 89 c5             	mov    r13,rax
   25d01:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   25d05:	ff e0                	jmp    rax
   25d07:	f3 0f 1e fa          	endbr64
   25d0b:	48 8b 53 f8          	mov    rdx,QWORD PTR [rbx-0x8]
   25d0f:	48 8b 4b f0          	mov    rcx,QWORD PTR [rbx-0x10]
   25d13:	83 fa f6             	cmp    edx,0xfffffff6
   25d16:	76 04                	jbe    25d1c <JS_CallInternal+0x317c>
   25d18:	83 41 fc 01          	add    DWORD PTR [rcx-0x4],0x1
   25d1c:	48 8b 85 98 fe ff ff 	mov    rax,QWORD PTR [rbp-0x168]
   25d23:	48 8b 40 18          	mov    rax,QWORD PTR [rax+0x18]
   25d27:	48 8b 40 18          	mov    rax,QWORD PTR [rax+0x18]
   25d2b:	4c 8b 40 08          	mov    r8,QWORD PTR [rax+0x8]
   25d2f:	48 8b 30             	mov    rsi,QWORD PTR [rax]
   25d32:	48 89 50 08          	mov    QWORD PTR [rax+0x8],rdx
   25d36:	48 89 08             	mov    QWORD PTR [rax],rcx
   25d39:	41 83 f8 f6          	cmp    r8d,0xfffffff6
   25d3d:	76 11                	jbe    25d50 <JS_CallInternal+0x31b0>
   25d3f:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   25d42:	83 e8 01             	sub    eax,0x1
   25d45:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   25d48:	85 c0                	test   eax,eax
   25d4a:	0f 8e 2f 50 00 00    	jle    2ad7f <JS_CallInternal+0x81df>
   25d50:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   25d55:	49 83 c4 01          	add    r12,0x1
   25d59:	49 89 c5             	mov    r13,rax
   25d5c:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   25d60:	ff e0                	jmp    rax
   25d62:	f3 0f 1e fa          	endbr64
   25d66:	48 8b 53 f8          	mov    rdx,QWORD PTR [rbx-0x8]
   25d6a:	48 8b 4b f0          	mov    rcx,QWORD PTR [rbx-0x10]
   25d6e:	83 fa f6             	cmp    edx,0xfffffff6
   25d71:	76 04                	jbe    25d77 <JS_CallInternal+0x31d7>
   25d73:	83 41 fc 01          	add    DWORD PTR [rcx-0x4],0x1
   25d77:	48 8b 85 98 fe ff ff 	mov    rax,QWORD PTR [rbp-0x168]
   25d7e:	48 8b 40 10          	mov    rax,QWORD PTR [rax+0x10]
   25d82:	48 8b 40 18          	mov    rax,QWORD PTR [rax+0x18]
   25d86:	4c 8b 40 08          	mov    r8,QWORD PTR [rax+0x8]
   25d8a:	48 8b 30             	mov    rsi,QWORD PTR [rax]
   25d8d:	48 89 50 08          	mov    QWORD PTR [rax+0x8],rdx
   25d91:	48 89 08             	mov    QWORD PTR [rax],rcx
   25d94:	41 83 f8 f6          	cmp    r8d,0xfffffff6
   25d98:	76 11                	jbe    25dab <JS_CallInternal+0x320b>
   25d9a:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   25d9d:	83 e8 01             	sub    eax,0x1
   25da0:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   25da3:	85 c0                	test   eax,eax
   25da5:	0f 8e 8f 4f 00 00    	jle    2ad3a <JS_CallInternal+0x819a>
   25dab:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   25db0:	49 83 c4 01          	add    r12,0x1
   25db4:	49 89 c5             	mov    r13,rax
   25db7:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   25dbb:	ff e0                	jmp    rax
   25dbd:	f3 0f 1e fa          	endbr64
   25dc1:	48 8b 53 f8          	mov    rdx,QWORD PTR [rbx-0x8]
   25dc5:	48 8b 4b f0          	mov    rcx,QWORD PTR [rbx-0x10]
   25dc9:	83 fa f6             	cmp    edx,0xfffffff6
   25dcc:	76 04                	jbe    25dd2 <JS_CallInternal+0x3232>
   25dce:	83 41 fc 01          	add    DWORD PTR [rcx-0x4],0x1
   25dd2:	48 8b 85 98 fe ff ff 	mov    rax,QWORD PTR [rbp-0x168]
   25dd9:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
   25ddd:	48 8b 40 18          	mov    rax,QWORD PTR [rax+0x18]
   25de1:	4c 8b 40 08          	mov    r8,QWORD PTR [rax+0x8]
   25de5:	48 8b 30             	mov    rsi,QWORD PTR [rax]
   25de8:	48 89 50 08          	mov    QWORD PTR [rax+0x8],rdx
   25dec:	48 89 08             	mov    QWORD PTR [rax],rcx
   25def:	41 83 f8 f6          	cmp    r8d,0xfffffff6
   25df3:	76 11                	jbe    25e06 <JS_CallInternal+0x3266>
   25df5:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   25df8:	83 e8 01             	sub    eax,0x1
   25dfb:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   25dfe:	85 c0                	test   eax,eax
   25e00:	0f 8e 4c 4f 00 00    	jle    2ad52 <JS_CallInternal+0x81b2>
   25e06:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   25e0b:	49 83 c4 01          	add    r12,0x1
   25e0f:	49 89 c5             	mov    r13,rax
   25e12:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   25e16:	ff e0                	jmp    rax
   25e18:	f3 0f 1e fa          	endbr64
   25e1c:	48 8b 53 f8          	mov    rdx,QWORD PTR [rbx-0x8]
   25e20:	48 8b 4b f0          	mov    rcx,QWORD PTR [rbx-0x10]
   25e24:	83 fa f6             	cmp    edx,0xfffffff6
   25e27:	76 04                	jbe    25e2d <JS_CallInternal+0x328d>
   25e29:	83 41 fc 01          	add    DWORD PTR [rcx-0x4],0x1
   25e2d:	48 8b 85 98 fe ff ff 	mov    rax,QWORD PTR [rbp-0x168]
   25e34:	48 8b 00             	mov    rax,QWORD PTR [rax]
   25e37:	48 8b 40 18          	mov    rax,QWORD PTR [rax+0x18]
   25e3b:	4c 8b 40 08          	mov    r8,QWORD PTR [rax+0x8]
   25e3f:	48 8b 30             	mov    rsi,QWORD PTR [rax]
   25e42:	48 89 50 08          	mov    QWORD PTR [rax+0x8],rdx
   25e46:	48 89 08             	mov    QWORD PTR [rax],rcx
   25e49:	41 83 f8 f6          	cmp    r8d,0xfffffff6
   25e4d:	76 11                	jbe    25e60 <JS_CallInternal+0x32c0>
   25e4f:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   25e52:	83 e8 01             	sub    eax,0x1
   25e55:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   25e58:	85 c0                	test   eax,eax
   25e5a:	0f 8e ad 4e 00 00    	jle    2ad0d <JS_CallInternal+0x816d>
   25e60:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   25e65:	49 83 c4 01          	add    r12,0x1
   25e69:	49 89 c5             	mov    r13,rax
   25e6c:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   25e70:	ff e0                	jmp    rax
   25e72:	f3 0f 1e fa          	endbr64
   25e76:	48 8b 85 98 fe ff ff 	mov    rax,QWORD PTR [rbp-0x168]
   25e7d:	f3 0f 6f 4b f0       	movdqu xmm1,XMMWORD PTR [rbx-0x10]
   25e82:	48 83 eb 10          	sub    rbx,0x10
   25e86:	48 8b 40 18          	mov    rax,QWORD PTR [rax+0x18]
   25e8a:	48 8b 40 18          	mov    rax,QWORD PTR [rax+0x18]
   25e8e:	48 8b 50 08          	mov    rdx,QWORD PTR [rax+0x8]
   25e92:	48 8b 30             	mov    rsi,QWORD PTR [rax]
   25e95:	0f 11 08             	movups XMMWORD PTR [rax],xmm1
   25e98:	83 fa f6             	cmp    edx,0xfffffff6
   25e9b:	76 11                	jbe    25eae <JS_CallInternal+0x330e>
   25e9d:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   25ea0:	83 e8 01             	sub    eax,0x1
   25ea3:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   25ea6:	85 c0                	test   eax,eax
   25ea8:	0f 8e 77 4e 00 00    	jle    2ad25 <JS_CallInternal+0x8185>
   25eae:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   25eb3:	49 83 c4 01          	add    r12,0x1
   25eb7:	49 89 c5             	mov    r13,rax
   25eba:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   25ebe:	ff e0                	jmp    rax
   25ec0:	f3 0f 1e fa          	endbr64
   25ec4:	48 8b 85 98 fe ff ff 	mov    rax,QWORD PTR [rbp-0x168]
   25ecb:	f3 0f 6f 5b f0       	movdqu xmm3,XMMWORD PTR [rbx-0x10]
   25ed0:	48 83 eb 10          	sub    rbx,0x10
   25ed4:	48 8b 40 10          	mov    rax,QWORD PTR [rax+0x10]
   25ed8:	48 8b 40 18          	mov    rax,QWORD PTR [rax+0x18]
   25edc:	48 8b 50 08          	mov    rdx,QWORD PTR [rax+0x8]
   25ee0:	48 8b 30             	mov    rsi,QWORD PTR [rax]
   25ee3:	0f 11 18             	movups XMMWORD PTR [rax],xmm3
   25ee6:	83 fa f6             	cmp    edx,0xfffffff6
   25ee9:	76 11                	jbe    25efc <JS_CallInternal+0x335c>
   25eeb:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   25eee:	83 e8 01             	sub    eax,0x1
   25ef1:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   25ef4:	85 c0                	test   eax,eax
   25ef6:	0f 8e bd 4d 00 00    	jle    2acb9 <JS_CallInternal+0x8119>
   25efc:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   25f01:	49 83 c4 01          	add    r12,0x1
   25f05:	49 89 c5             	mov    r13,rax
   25f08:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   25f0c:	ff e0                	jmp    rax
   25f0e:	f3 0f 1e fa          	endbr64
   25f12:	48 8b 85 98 fe ff ff 	mov    rax,QWORD PTR [rbp-0x168]
   25f19:	f3 0f 6f 7b f0       	movdqu xmm7,XMMWORD PTR [rbx-0x10]
   25f1e:	48 83 eb 10          	sub    rbx,0x10
   25f22:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
   25f26:	48 8b 40 18          	mov    rax,QWORD PTR [rax+0x18]
   25f2a:	48 8b 50 08          	mov    rdx,QWORD PTR [rax+0x8]
   25f2e:	48 8b 30             	mov    rsi,QWORD PTR [rax]
   25f31:	0f 11 38             	movups XMMWORD PTR [rax],xmm7
   25f34:	83 fa f6             	cmp    edx,0xfffffff6
   25f37:	76 11                	jbe    25f4a <JS_CallInternal+0x33aa>
   25f39:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   25f3c:	83 e8 01             	sub    eax,0x1
   25f3f:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   25f42:	85 c0                	test   eax,eax
   25f44:	0f 8e 84 4d 00 00    	jle    2acce <JS_CallInternal+0x812e>
   25f4a:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   25f4f:	49 83 c4 01          	add    r12,0x1
   25f53:	49 89 c5             	mov    r13,rax
   25f56:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   25f5a:	ff e0                	jmp    rax
   25f5c:	f3 0f 1e fa          	endbr64
   25f60:	48 8b 53 f8          	mov    rdx,QWORD PTR [rbx-0x8]
   25f64:	41 0f b7 04 24       	movzx  eax,WORD PTR [r12]
   25f69:	48 8b 7b f0          	mov    rdi,QWORD PTR [rbx-0x10]
   25f6d:	83 fa f6             	cmp    edx,0xfffffff6
   25f70:	76 04                	jbe    25f76 <JS_CallInternal+0x33d6>
   25f72:	83 47 fc 01          	add    DWORD PTR [rdi-0x4],0x1
   25f76:	48 8b 8d 98 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x168]
   25f7d:	48 8b 04 c1          	mov    rax,QWORD PTR [rcx+rax*8]
   25f81:	48 8b 40 18          	mov    rax,QWORD PTR [rax+0x18]
   25f85:	48 8b 48 08          	mov    rcx,QWORD PTR [rax+0x8]
   25f89:	48 8b 30             	mov    rsi,QWORD PTR [rax]
   25f8c:	48 89 50 08          	mov    QWORD PTR [rax+0x8],rdx
   25f90:	48 89 38             	mov    QWORD PTR [rax],rdi
   25f93:	83 f9 f6             	cmp    ecx,0xfffffff6
   25f96:	76 11                	jbe    25fa9 <JS_CallInternal+0x3409>
   25f98:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   25f9b:	83 e8 01             	sub    eax,0x1
   25f9e:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   25fa1:	85 c0                	test   eax,eax
   25fa3:	0f 8e e3 4c 00 00    	jle    2ac8c <JS_CallInternal+0x80ec>
   25fa9:	41 0f b6 44 24 02    	movzx  eax,BYTE PTR [r12+0x2]
   25faf:	49 83 c4 03          	add    r12,0x3
   25fb3:	49 89 c5             	mov    r13,rax
   25fb6:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   25fba:	ff e0                	jmp    rax
   25fbc:	f3 0f 1e fa          	endbr64
   25fc0:	41 0f b7 04 24       	movzx  eax,WORD PTR [r12]
   25fc5:	48 8b 8d 98 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x168]
   25fcc:	f3 0f 6f 63 f0       	movdqu xmm4,XMMWORD PTR [rbx-0x10]
   25fd1:	48 8b 04 c1          	mov    rax,QWORD PTR [rcx+rax*8]
   25fd5:	48 8b 40 18          	mov    rax,QWORD PTR [rax+0x18]
   25fd9:	48 8b 50 08          	mov    rdx,QWORD PTR [rax+0x8]
   25fdd:	48 8b 30             	mov    rsi,QWORD PTR [rax]
   25fe0:	0f 11 20             	movups XMMWORD PTR [rax],xmm4
   25fe3:	83 fa f6             	cmp    edx,0xfffffff6
   25fe6:	76 11                	jbe    25ff9 <JS_CallInternal+0x3459>
   25fe8:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   25feb:	83 e8 01             	sub    eax,0x1
   25fee:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   25ff1:	85 c0                	test   eax,eax
   25ff3:	0f 8e ab 4c 00 00    	jle    2aca4 <JS_CallInternal+0x8104>
   25ff9:	41 0f b6 44 24 02    	movzx  eax,BYTE PTR [r12+0x2]
   25fff:	48 83 eb 10          	sub    rbx,0x10
   26003:	49 83 c4 03          	add    r12,0x3
   26007:	49 89 c5             	mov    r13,rax
   2600a:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   2600e:	ff e0                	jmp    rax
   26010:	f3 0f 1e fa          	endbr64
   26014:	41 0f b7 04 24       	movzx  eax,WORD PTR [r12]
   26019:	48 8b bd 98 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x168]
   26020:	4d 8d 6c 24 02       	lea    r13,[r12+0x2]
   26025:	48 8d 0c c5 00 00 00 	lea    rcx,[rax*8+0x0]
   2602c:	00 
   2602d:	48 8b 04 c7          	mov    rax,QWORD PTR [rdi+rax*8]
   26031:	48 8b 40 18          	mov    rax,QWORD PTR [rax+0x18]
   26035:	48 8b 10             	mov    rdx,QWORD PTR [rax]
   26038:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
   2603c:	83 f8 04             	cmp    eax,0x4
   2603f:	0f 84 63 4e 00 00    	je     2aea8 <JS_CallInternal+0x8308>
   26045:	83 f8 f6             	cmp    eax,0xfffffff6
   26048:	76 04                	jbe    2604e <JS_CallInternal+0x34ae>
   2604a:	83 42 fc 01          	add    DWORD PTR [rdx-0x4],0x1
   2604e:	48 89 13             	mov    QWORD PTR [rbx],rdx
   26051:	49 83 c4 03          	add    r12,0x3
   26055:	48 83 c3 10          	add    rbx,0x10
   26059:	48 89 43 f8          	mov    QWORD PTR [rbx-0x8],rax
   2605d:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   26063:	49 89 c5             	mov    r13,rax
   26066:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   2606a:	ff e0                	jmp    rax
   2606c:	f3 0f 1e fa          	endbr64
   26070:	e9 f1 ce ff ff       	jmp    22f66 <JS_CallInternal+0x3c6>
   26075:	f3 0f 1e fa          	endbr64
   26079:	e9 e8 ce ff ff       	jmp    22f66 <JS_CallInternal+0x3c6>
   2607e:	f3 0f 1e fa          	endbr64
   26082:	41 8b 04 24          	mov    eax,DWORD PTR [r12]
   26086:	48 8b 8d d8 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x128]
   2608d:	48 c1 e0 04          	shl    rax,0x4
   26091:	48 03 41 50          	add    rax,QWORD PTR [rcx+0x50]
   26095:	48 8b 50 08          	mov    rdx,QWORD PTR [rax+0x8]
   26099:	48 8b 30             	mov    rsi,QWORD PTR [rax]
   2609c:	83 fa f6             	cmp    edx,0xfffffff6
   2609f:	76 04                	jbe    260a5 <JS_CallInternal+0x3505>
   260a1:	83 46 fc 01          	add    DWORD PTR [rsi-0x4],0x1
   260a5:	4c 8b 85 c8 fe ff ff 	mov    r8,QWORD PTR [rbp-0x138]
   260ac:	45 31 c9             	xor    r9d,r9d
   260af:	4d 8d 6c 24 04       	lea    r13,[r12+0x4]
   260b4:	4c 8d 73 10          	lea    r14,[rbx+0x10]
   260b8:	48 8b 8d 98 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x168]
   260bf:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   260c6:	e8 b5 6b 02 00       	call   4cc80 <js_closure>
   260cb:	48 89 53 08          	mov    QWORD PTR [rbx+0x8],rdx
   260cf:	83 7b 08 06          	cmp    DWORD PTR [rbx+0x8],0x6
   260d3:	48 89 03             	mov    QWORD PTR [rbx],rax
   260d6:	0f 84 1e 5b 00 00    	je     2bbfa <JS_CallInternal+0x905a>
   260dc:	41 0f b6 44 24 04    	movzx  eax,BYTE PTR [r12+0x4]
   260e2:	4c 89 f3             	mov    rbx,r14
   260e5:	49 83 c4 05          	add    r12,0x5
   260e9:	49 89 c5             	mov    r13,rax
   260ec:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   260f0:	ff e0                	jmp    rax
   260f2:	f3 0f 1e fa          	endbr64
   260f6:	f3 0f 6f 4b c0       	movdqu xmm1,XMMWORD PTR [rbx-0x40]
   260fb:	f3 0f 6f 43 d0       	movdqu xmm0,XMMWORD PTR [rbx-0x30]
   26100:	49 83 c4 01          	add    r12,0x1
   26104:	f3 0f 6f 6b e0       	movdqu xmm5,XMMWORD PTR [rbx-0x20]
   26109:	f3 0f 6f 73 f0       	movdqu xmm6,XMMWORD PTR [rbx-0x10]
   2610e:	0f 11 4b e0          	movups XMMWORD PTR [rbx-0x20],xmm1
   26112:	0f 11 6b c0          	movups XMMWORD PTR [rbx-0x40],xmm5
   26116:	0f 11 73 d0          	movups XMMWORD PTR [rbx-0x30],xmm6
   2611a:	0f 11 43 f0          	movups XMMWORD PTR [rbx-0x10],xmm0
   2611e:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   26124:	49 89 c5             	mov    r13,rax
   26127:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   2612b:	ff e0                	jmp    rax
   2612d:	f3 0f 1e fa          	endbr64
   26131:	f3 0f 6f 43 e0       	movdqu xmm0,XMMWORD PTR [rbx-0x20]
   26136:	f3 0f 6f 53 f0       	movdqu xmm2,XMMWORD PTR [rbx-0x10]
   2613b:	49 83 c4 01          	add    r12,0x1
   2613f:	0f 11 53 e0          	movups XMMWORD PTR [rbx-0x20],xmm2
   26143:	0f 11 43 f0          	movups XMMWORD PTR [rbx-0x10],xmm0
   26147:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   2614d:	49 89 c5             	mov    r13,rax
   26150:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   26154:	ff e0                	jmp    rax
   26156:	f3 0f 1e fa          	endbr64
   2615a:	f3 0f 6f 43 e0       	movdqu xmm0,XMMWORD PTR [rbx-0x20]
   2615f:	f3 0f 6f 5b d0       	movdqu xmm3,XMMWORD PTR [rbx-0x30]
   26164:	49 83 c4 01          	add    r12,0x1
   26168:	f3 0f 6f 4b c0       	movdqu xmm1,XMMWORD PTR [rbx-0x40]
   2616d:	f3 0f 6f 63 b0       	movdqu xmm4,XMMWORD PTR [rbx-0x50]
   26172:	0f 11 5b e0          	movups XMMWORD PTR [rbx-0x20],xmm3
   26176:	0f 11 4b d0          	movups XMMWORD PTR [rbx-0x30],xmm1
   2617a:	0f 11 63 c0          	movups XMMWORD PTR [rbx-0x40],xmm4
   2617e:	0f 11 43 b0          	movups XMMWORD PTR [rbx-0x50],xmm0
   26182:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   26188:	49 89 c5             	mov    r13,rax
   2618b:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   2618f:	ff e0                	jmp    rax
   26191:	f3 0f 1e fa          	endbr64
   26195:	f3 0f 6f 43 e0       	movdqu xmm0,XMMWORD PTR [rbx-0x20]
   2619a:	f3 0f 6f 73 d0       	movdqu xmm6,XMMWORD PTR [rbx-0x30]
   2619f:	49 83 c4 01          	add    r12,0x1
   261a3:	f3 0f 6f 7b c0       	movdqu xmm7,XMMWORD PTR [rbx-0x40]
   261a8:	0f 11 73 e0          	movups XMMWORD PTR [rbx-0x20],xmm6
   261ac:	0f 11 7b d0          	movups XMMWORD PTR [rbx-0x30],xmm7
   261b0:	0f 11 43 c0          	movups XMMWORD PTR [rbx-0x40],xmm0
   261b4:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   261ba:	49 89 c5             	mov    r13,rax
   261bd:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   261c1:	ff e0                	jmp    rax
   261c3:	f3 0f 1e fa          	endbr64
   261c7:	f3 0f 6f 43 f0       	movdqu xmm0,XMMWORD PTR [rbx-0x10]
   261cc:	f3 0f 6f 53 e0       	movdqu xmm2,XMMWORD PTR [rbx-0x20]
   261d1:	49 83 c4 01          	add    r12,0x1
   261d5:	f3 0f 6f 6b d0       	movdqu xmm5,XMMWORD PTR [rbx-0x30]
   261da:	0f 11 53 f0          	movups XMMWORD PTR [rbx-0x10],xmm2
   261de:	0f 11 6b e0          	movups XMMWORD PTR [rbx-0x20],xmm5
   261e2:	0f 11 43 d0          	movups XMMWORD PTR [rbx-0x30],xmm0
   261e6:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   261ec:	49 89 c5             	mov    r13,rax
   261ef:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   261f3:	ff e0                	jmp    rax
   261f5:	f3 0f 1e fa          	endbr64
   261f9:	f3 0f 6f 43 b0       	movdqu xmm0,XMMWORD PTR [rbx-0x50]
   261fe:	f3 0f 6f 7b c0       	movdqu xmm7,XMMWORD PTR [rbx-0x40]
   26203:	49 83 c4 01          	add    r12,0x1
   26207:	f3 0f 6f 5b d0       	movdqu xmm3,XMMWORD PTR [rbx-0x30]
   2620c:	f3 0f 6f 4b e0       	movdqu xmm1,XMMWORD PTR [rbx-0x20]
   26211:	f3 0f 6f 63 f0       	movdqu xmm4,XMMWORD PTR [rbx-0x10]
   26216:	0f 11 7b b0          	movups XMMWORD PTR [rbx-0x50],xmm7
   2621a:	0f 11 5b c0          	movups XMMWORD PTR [rbx-0x40],xmm3
   2621e:	0f 11 4b d0          	movups XMMWORD PTR [rbx-0x30],xmm1
   26222:	0f 11 63 e0          	movups XMMWORD PTR [rbx-0x20],xmm4
   26226:	0f 11 43 f0          	movups XMMWORD PTR [rbx-0x10],xmm0
   2622a:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   26230:	49 89 c5             	mov    r13,rax
   26233:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   26237:	ff e0                	jmp    rax
   26239:	f3 0f 1e fa          	endbr64
   2623d:	f3 0f 6f 43 c0       	movdqu xmm0,XMMWORD PTR [rbx-0x40]
   26242:	f3 0f 6f 63 d0       	movdqu xmm4,XMMWORD PTR [rbx-0x30]
   26247:	49 83 c4 01          	add    r12,0x1
   2624b:	f3 0f 6f 6b e0       	movdqu xmm5,XMMWORD PTR [rbx-0x20]
   26250:	f3 0f 6f 73 f0       	movdqu xmm6,XMMWORD PTR [rbx-0x10]
   26255:	0f 11 63 c0          	movups XMMWORD PTR [rbx-0x40],xmm4
   26259:	0f 11 6b d0          	movups XMMWORD PTR [rbx-0x30],xmm5
   2625d:	0f 11 73 e0          	movups XMMWORD PTR [rbx-0x20],xmm6
   26261:	0f 11 43 f0          	movups XMMWORD PTR [rbx-0x10],xmm0
   26265:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   2626b:	49 89 c5             	mov    r13,rax
   2626e:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   26272:	ff e0                	jmp    rax
   26274:	f3 0f 1e fa          	endbr64
   26278:	f3 0f 6f 43 d0       	movdqu xmm0,XMMWORD PTR [rbx-0x30]
   2627d:	f3 0f 6f 7b e0       	movdqu xmm7,XMMWORD PTR [rbx-0x20]
   26282:	49 83 c4 01          	add    r12,0x1
   26286:	f3 0f 6f 5b f0       	movdqu xmm3,XMMWORD PTR [rbx-0x10]
   2628b:	0f 11 7b d0          	movups XMMWORD PTR [rbx-0x30],xmm7
   2628f:	0f 11 5b e0          	movups XMMWORD PTR [rbx-0x20],xmm3
   26293:	0f 11 43 f0          	movups XMMWORD PTR [rbx-0x10],xmm0
   26297:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   2629d:	49 89 c5             	mov    r13,rax
   262a0:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   262a4:	ff e0                	jmp    rax
   262a6:	f3 0f 1e fa          	endbr64
   262aa:	f3 0f 6f 43 e0       	movdqu xmm0,XMMWORD PTR [rbx-0x20]
   262af:	f3 0f 6f 73 d0       	movdqu xmm6,XMMWORD PTR [rbx-0x30]
   262b4:	49 83 c4 01          	add    r12,0x1
   262b8:	0f 11 73 e0          	movups XMMWORD PTR [rbx-0x20],xmm6
   262bc:	0f 11 43 d0          	movups XMMWORD PTR [rbx-0x30],xmm0
   262c0:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   262c6:	49 89 c5             	mov    r13,rax
   262c9:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   262cd:	ff e0                	jmp    rax
   262cf:	f3 0f 1e fa          	endbr64
   262d3:	f3 0f 6f 7b f0       	movdqu xmm7,XMMWORD PTR [rbx-0x10]
   262d8:	f3 0f 6f 5b e0       	movdqu xmm3,XMMWORD PTR [rbx-0x20]
   262dd:	f3 0f 6f 63 d0       	movdqu xmm4,XMMWORD PTR [rbx-0x30]
   262e2:	f3 0f 6f 6b c0       	movdqu xmm5,XMMWORD PTR [rbx-0x40]
   262e7:	0f 11 3b             	movups XMMWORD PTR [rbx],xmm7
   262ea:	48 8b 43 08          	mov    rax,QWORD PTR [rbx+0x8]
   262ee:	48 8b 53 f0          	mov    rdx,QWORD PTR [rbx-0x10]
   262f2:	0f 11 63 e0          	movups XMMWORD PTR [rbx-0x20],xmm4
   262f6:	0f 11 5b f0          	movups XMMWORD PTR [rbx-0x10],xmm3
   262fa:	0f 11 6b d0          	movups XMMWORD PTR [rbx-0x30],xmm5
   262fe:	83 f8 f6             	cmp    eax,0xfffffff6
   26301:	76 04                	jbe    26307 <JS_CallInternal+0x3767>
   26303:	83 42 fc 01          	add    DWORD PTR [rdx-0x4],0x1
   26307:	48 89 53 c0          	mov    QWORD PTR [rbx-0x40],rdx
   2630b:	49 83 c4 01          	add    r12,0x1
   2630f:	48 83 c3 10          	add    rbx,0x10
   26313:	48 89 43 b8          	mov    QWORD PTR [rbx-0x48],rax
   26317:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   2631d:	49 89 c5             	mov    r13,rax
   26320:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   26324:	ff e0                	jmp    rax
   26326:	f3 0f 1e fa          	endbr64
   2632a:	f3 0f 6f 63 f0       	movdqu xmm4,XMMWORD PTR [rbx-0x10]
   2632f:	f3 0f 6f 6b e0       	movdqu xmm5,XMMWORD PTR [rbx-0x20]
   26334:	f3 0f 6f 73 d0       	movdqu xmm6,XMMWORD PTR [rbx-0x30]
   26339:	48 8b 53 f0          	mov    rdx,QWORD PTR [rbx-0x10]
   2633d:	0f 11 23             	movups XMMWORD PTR [rbx],xmm4
   26340:	48 8b 43 08          	mov    rax,QWORD PTR [rbx+0x8]
   26344:	0f 11 6b f0          	movups XMMWORD PTR [rbx-0x10],xmm5
   26348:	0f 11 73 e0          	movups XMMWORD PTR [rbx-0x20],xmm6
   2634c:	83 f8 f6             	cmp    eax,0xfffffff6
   2634f:	76 04                	jbe    26355 <JS_CallInternal+0x37b5>
   26351:	83 42 fc 01          	add    DWORD PTR [rdx-0x4],0x1
   26355:	48 89 53 d0          	mov    QWORD PTR [rbx-0x30],rdx
   26359:	49 83 c4 01          	add    r12,0x1
   2635d:	48 83 c3 10          	add    rbx,0x10
   26361:	48 89 43 c8          	mov    QWORD PTR [rbx-0x38],rax
   26365:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   2636b:	49 89 c5             	mov    r13,rax
   2636e:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   26372:	ff e0                	jmp    rax
   26374:	f3 0f 1e fa          	endbr64
   26378:	f3 0f 6f 73 f0       	movdqu xmm6,XMMWORD PTR [rbx-0x10]
   2637d:	f3 0f 6f 7b e0       	movdqu xmm7,XMMWORD PTR [rbx-0x20]
   26382:	48 8b 53 f0          	mov    rdx,QWORD PTR [rbx-0x10]
   26386:	0f 11 33             	movups XMMWORD PTR [rbx],xmm6
   26389:	48 8b 43 08          	mov    rax,QWORD PTR [rbx+0x8]
   2638d:	0f 11 7b f0          	movups XMMWORD PTR [rbx-0x10],xmm7
   26391:	83 f8 f6             	cmp    eax,0xfffffff6
   26394:	76 04                	jbe    2639a <JS_CallInternal+0x37fa>
   26396:	83 42 fc 01          	add    DWORD PTR [rdx-0x4],0x1
   2639a:	48 89 53 e0          	mov    QWORD PTR [rbx-0x20],rdx
   2639e:	49 83 c4 01          	add    r12,0x1
   263a2:	48 83 c3 10          	add    rbx,0x10
   263a6:	48 89 43 d8          	mov    QWORD PTR [rbx-0x28],rax
   263aa:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   263b0:	49 89 c5             	mov    r13,rax
   263b3:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   263b7:	ff e0                	jmp    rax
   263b9:	f3 0f 1e fa          	endbr64
   263bd:	f3 0f 6f 6b f0       	movdqu xmm5,XMMWORD PTR [rbx-0x10]
   263c2:	48 8b 43 e8          	mov    rax,QWORD PTR [rbx-0x18]
   263c6:	48 8b 53 e0          	mov    rdx,QWORD PTR [rbx-0x20]
   263ca:	0f 11 2b             	movups XMMWORD PTR [rbx],xmm5
   263cd:	83 f8 f6             	cmp    eax,0xfffffff6
   263d0:	76 04                	jbe    263d6 <JS_CallInternal+0x3836>
   263d2:	83 42 fc 01          	add    DWORD PTR [rdx-0x4],0x1
   263d6:	48 89 53 f0          	mov    QWORD PTR [rbx-0x10],rdx
   263da:	49 83 c4 01          	add    r12,0x1
   263de:	48 83 c3 10          	add    rbx,0x10
   263e2:	48 89 43 e8          	mov    QWORD PTR [rbx-0x18],rax
   263e6:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   263ec:	49 89 c5             	mov    r13,rax
   263ef:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   263f3:	ff e0                	jmp    rax
   263f5:	f3 0f 1e fa          	endbr64
   263f9:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   26400:	48 8b 73 f0          	mov    rsi,QWORD PTR [rbx-0x10]
   26404:	48 83 eb 10          	sub    rbx,0x10
   26408:	48 8b 53 08          	mov    rdx,QWORD PTR [rbx+0x8]
   2640c:	e8 bf bf ff ff       	call   223d0 <JS_Throw>
   26411:	e9 2a cf ff ff       	jmp    23340 <JS_CallInternal+0x7a0>
   26416:	f3 0f 1e fa          	endbr64
   2641a:	48 8b 4b f0          	mov    rcx,QWORD PTR [rbx-0x10]
   2641e:	48 8b 73 e0          	mov    rsi,QWORD PTR [rbx-0x20]
   26422:	4c 8d 6b f0          	lea    r13,[rbx-0x10]
   26426:	4c 8d 73 e0          	lea    r14,[rbx-0x20]
   2642a:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   26431:	49 8b 56 08          	mov    rdx,QWORD PTR [r14+0x8]
   26435:	4d 8b 45 08          	mov    r8,QWORD PTR [r13+0x8]
   26439:	e8 a2 41 02 00       	call   4a5e0 <JS_AddBrand>
   2643e:	85 c0                	test   eax,eax
   26440:	0f 88 fa ce ff ff    	js     23340 <JS_CallInternal+0x7a0>
   26446:	49 8b 56 08          	mov    rdx,QWORD PTR [r14+0x8]
   2644a:	48 8b 73 e0          	mov    rsi,QWORD PTR [rbx-0x20]
   2644e:	83 fa f6             	cmp    edx,0xfffffff6
   26451:	76 11                	jbe    26464 <JS_CallInternal+0x38c4>
   26453:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   26456:	83 e8 01             	sub    eax,0x1
   26459:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   2645c:	85 c0                	test   eax,eax
   2645e:	0f 8e 0f 46 00 00    	jle    2aa73 <JS_CallInternal+0x7ed3>
   26464:	49 8b 55 08          	mov    rdx,QWORD PTR [r13+0x8]
   26468:	49 8b 75 00          	mov    rsi,QWORD PTR [r13+0x0]
   2646c:	83 fa f6             	cmp    edx,0xfffffff6
   2646f:	76 11                	jbe    26482 <JS_CallInternal+0x38e2>
   26471:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   26474:	83 e8 01             	sub    eax,0x1
   26477:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   2647a:	85 c0                	test   eax,eax
   2647c:	0f 8e 44 47 00 00    	jle    2abc6 <JS_CallInternal+0x8026>
   26482:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   26487:	4c 89 f3             	mov    rbx,r14
   2648a:	49 83 c4 01          	add    r12,0x1
   2648e:	49 89 c5             	mov    r13,rax
   26491:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   26495:	ff e0                	jmp    rax
   26497:	f3 0f 1e fa          	endbr64
   2649b:	48 8b 4b f0          	mov    rcx,QWORD PTR [rbx-0x10]
   2649f:	48 8b 73 e0          	mov    rsi,QWORD PTR [rbx-0x20]
   264a3:	48 8b 53 e8          	mov    rdx,QWORD PTR [rbx-0x18]
   264a7:	4c 8b 43 f8          	mov    r8,QWORD PTR [rbx-0x8]
   264ab:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   264b2:	e8 49 b2 00 00       	call   31700 <JS_CheckBrand>
   264b7:	85 c0                	test   eax,eax
   264b9:	0f 88 81 ce ff ff    	js     23340 <JS_CallInternal+0x7a0>
   264bf:	0f 84 65 65 00 00    	je     2ca2a <JS_CallInternal+0x9e8a>
   264c5:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   264ca:	49 83 c4 01          	add    r12,0x1
   264ce:	49 89 c5             	mov    r13,rax
   264d1:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   264d5:	ff e0                	jmp    rax
   264d7:	f3 0f 1e fa          	endbr64
   264db:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   264e2:	83 bd 80 fe ff ff 03 	cmp    DWORD PTR [rbp-0x180],0x3
   264e9:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   264ed:	0f 84 e5 5b 00 00    	je     2c0d8 <JS_CallInternal+0x9538>
   264f3:	48 8b b5 e0 fe ff ff 	mov    rsi,QWORD PTR [rbp-0x120]
   264fa:	48 8b 95 d0 fe ff ff 	mov    rdx,QWORD PTR [rbp-0x130]
   26501:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   26508:	e8 93 bf ff ff       	call   224a0 <JS_GetPrototype>
   2650d:	49 89 c6             	mov    r14,rax
   26510:	49 89 d5             	mov    r13,rdx
   26513:	83 fa 06             	cmp    edx,0x6
   26516:	0f 84 24 ce ff ff    	je     23340 <JS_CallInternal+0x7a0>
   2651c:	6a 02                	push   0x2
   2651e:	44 8b 8d bc fe ff ff 	mov    r9d,DWORD PTR [rbp-0x144]
   26525:	48 89 c6             	mov    rsi,rax
   26528:	ff b5 a8 fe ff ff    	push   QWORD PTR [rbp-0x158]
   2652e:	48 8b 8d 70 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x190]
   26535:	4c 8b 85 80 fe ff ff 	mov    r8,QWORD PTR [rbp-0x180]
   2653c:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   26543:	e8 08 ae 06 00       	call   91350 <JS_CallConstructorInternal>
   26548:	41 58                	pop    r8
   2654a:	41 59                	pop    r9
   2654c:	48 89 d1             	mov    rcx,rdx
   2654f:	41 83 fd f6          	cmp    r13d,0xfffffff6
   26553:	76 13                	jbe    26568 <JS_CallInternal+0x39c8>
   26555:	41 8b 7e fc          	mov    edi,DWORD PTR [r14-0x4]
   26559:	8d 57 ff             	lea    edx,[rdi-0x1]
   2655c:	41 89 56 fc          	mov    DWORD PTR [r14-0x4],edx
   26560:	85 d2                	test   edx,edx
   26562:	0f 8e d4 44 00 00    	jle    2aa3c <JS_CallInternal+0x7e9c>
   26568:	83 f9 06             	cmp    ecx,0x6
   2656b:	0f 84 cf cd ff ff    	je     23340 <JS_CallInternal+0x7a0>
   26571:	48 89 03             	mov    QWORD PTR [rbx],rax
   26574:	49 83 c4 01          	add    r12,0x1
   26578:	48 83 c3 10          	add    rbx,0x10
   2657c:	48 89 4b f8          	mov    QWORD PTR [rbx-0x8],rcx
   26580:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   26586:	49 89 c5             	mov    r13,rax
   26589:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   2658d:	ff e0                	jmp    rax
   2658f:	f3 0f 1e fa          	endbr64
   26593:	83 bd 80 fe ff ff 03 	cmp    DWORD PTR [rbp-0x180],0x3
   2659a:	0f 84 38 5b 00 00    	je     2c0d8 <JS_CallInternal+0x9538>
   265a0:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   265a5:	49 83 c4 01          	add    r12,0x1
   265a9:	49 89 c5             	mov    r13,rax
   265ac:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   265b0:	ff e0                	jmp    rax
   265b2:	f3 0f 1e fa          	endbr64
   265b6:	48 8b 43 f8          	mov    rax,QWORD PTR [rbx-0x8]
   265ba:	83 f8 ff             	cmp    eax,0xffffffff
   265bd:	0f 84 5c 35 00 00    	je     29b1f <JS_CallInternal+0x6f7f>
   265c3:	83 f8 03             	cmp    eax,0x3
   265c6:	0f 85 44 64 00 00    	jne    2ca10 <JS_CallInternal+0x9e70>
   265cc:	b8 01 00 00 00       	mov    eax,0x1
   265d1:	48 89 03             	mov    QWORD PTR [rbx],rax
   265d4:	49 83 c4 01          	add    r12,0x1
   265d8:	48 83 c3 10          	add    rbx,0x10
   265dc:	48 c7 43 f8 01 00 00 	mov    QWORD PTR [rbx-0x8],0x1
   265e3:	00 
   265e4:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   265ea:	49 89 c5             	mov    r13,rax
   265ed:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   265f1:	ff e0                	jmp    rax
   265f3:	f3 0f 1e fa          	endbr64
   265f7:	b9 03 00 00 00       	mov    ecx,0x3
   265fc:	31 c0                	xor    eax,eax
   265fe:	e9 90 cc ff ff       	jmp    23293 <JS_CallInternal+0x6f3>
   26603:	f3 0f 1e fa          	endbr64
   26607:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   2660c:	48 8b 8d d8 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x128]
   26613:	4d 8d 6c 24 01       	lea    r13,[r12+0x1]
   26618:	48 c1 e0 04          	shl    rax,0x4
   2661c:	48 03 41 50          	add    rax,QWORD PTR [rcx+0x50]
   26620:	48 8b 50 08          	mov    rdx,QWORD PTR [rax+0x8]
   26624:	48 8b 30             	mov    rsi,QWORD PTR [rax]
   26627:	83 fa f6             	cmp    edx,0xfffffff6
   2662a:	76 04                	jbe    26630 <JS_CallInternal+0x3a90>
   2662c:	83 46 fc 01          	add    DWORD PTR [rsi-0x4],0x1
   26630:	4c 8b 85 c8 fe ff ff 	mov    r8,QWORD PTR [rbp-0x138]
   26637:	48 8b 8d 98 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x168]
   2663e:	45 31 c9             	xor    r9d,r9d
   26641:	4c 8d 73 10          	lea    r14,[rbx+0x10]
   26645:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2664c:	e8 2f 66 02 00       	call   4cc80 <js_closure>
   26651:	48 89 53 08          	mov    QWORD PTR [rbx+0x8],rdx
   26655:	83 7b 08 06          	cmp    DWORD PTR [rbx+0x8],0x6
   26659:	48 89 03             	mov    QWORD PTR [rbx],rax
   2665c:	0f 84 72 4c 00 00    	je     2b2d4 <JS_CallInternal+0x8734>
   26662:	41 0f b6 44 24 01    	movzx  eax,BYTE PTR [r12+0x1]
   26668:	4c 89 f3             	mov    rbx,r14
   2666b:	49 83 c4 02          	add    r12,0x2
   2666f:	49 89 c5             	mov    r13,rax
   26672:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   26676:	ff e0                	jmp    rax
   26678:	f3 0f 1e fa          	endbr64
   2667c:	48 8b 8d d8 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x128]
   26683:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   26688:	48 c1 e0 04          	shl    rax,0x4
   2668c:	48 03 41 50          	add    rax,QWORD PTR [rcx+0x50]
   26690:	48 8d 4b 10          	lea    rcx,[rbx+0x10]
   26694:	48 8b 10             	mov    rdx,QWORD PTR [rax]
   26697:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
   2669b:	83 f8 f6             	cmp    eax,0xfffffff6
   2669e:	76 04                	jbe    266a4 <JS_CallInternal+0x3b04>
   266a0:	83 42 fc 01          	add    DWORD PTR [rdx-0x4],0x1
   266a4:	48 89 13             	mov    QWORD PTR [rbx],rdx
   266a7:	49 83 c4 02          	add    r12,0x2
   266ab:	48 89 43 08          	mov    QWORD PTR [rbx+0x8],rax
   266af:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   266b5:	48 89 cb             	mov    rbx,rcx
   266b8:	49 89 c5             	mov    r13,rax
   266bb:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   266bf:	ff e0                	jmp    rax
   266c1:	f3 0f 1e fa          	endbr64
   266c5:	41 0f bf 04 24       	movsx  eax,WORD PTR [r12]
   266ca:	48 83 c3 10          	add    rbx,0x10
   266ce:	49 83 c4 03          	add    r12,0x3
   266d2:	48 c7 43 f8 00 00 00 	mov    QWORD PTR [rbx-0x8],0x0
   266d9:	00 
   266da:	48 89 43 f0          	mov    QWORD PTR [rbx-0x10],rax
   266de:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   266e4:	49 89 c5             	mov    r13,rax
   266e7:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   266eb:	ff e0                	jmp    rax
   266ed:	f3 0f 1e fa          	endbr64
   266f1:	41 0f be 04 24       	movsx  eax,BYTE PTR [r12]
   266f6:	48 83 c3 10          	add    rbx,0x10
   266fa:	49 83 c4 02          	add    r12,0x2
   266fe:	48 c7 43 f8 00 00 00 	mov    QWORD PTR [rbx-0x8],0x0
   26705:	00 
   26706:	48 89 43 f0          	mov    QWORD PTR [rbx-0x10],rax
   2670a:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   26710:	49 89 c5             	mov    r13,rax
   26713:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   26717:	ff e0                	jmp    rax
   26719:	f3 0f 1e fa          	endbr64
   2671d:	e9 66 c7 ff ff       	jmp    22e88 <JS_CallInternal+0x2e8>
   26722:	f3 0f 1e fa          	endbr64
   26726:	e9 5d c7 ff ff       	jmp    22e88 <JS_CallInternal+0x2e8>
   2672b:	f3 0f 1e fa          	endbr64
   2672f:	e9 54 c7 ff ff       	jmp    22e88 <JS_CallInternal+0x2e8>
   26734:	f3 0f 1e fa          	endbr64
   26738:	e9 4b c7 ff ff       	jmp    22e88 <JS_CallInternal+0x2e8>
   2673d:	f3 0f 1e fa          	endbr64
   26741:	e9 42 c7 ff ff       	jmp    22e88 <JS_CallInternal+0x2e8>
   26746:	f3 0f 1e fa          	endbr64
   2674a:	e9 39 c7 ff ff       	jmp    22e88 <JS_CallInternal+0x2e8>
   2674f:	f3 0f 1e fa          	endbr64
   26753:	e9 30 c7 ff ff       	jmp    22e88 <JS_CallInternal+0x2e8>
   26758:	f3 0f 1e fa          	endbr64
   2675c:	48 8b 8d d8 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x128]
   26763:	41 8b 04 24          	mov    eax,DWORD PTR [r12]
   26767:	48 c1 e0 04          	shl    rax,0x4
   2676b:	48 03 41 50          	add    rax,QWORD PTR [rcx+0x50]
   2676f:	48 8d 4b 10          	lea    rcx,[rbx+0x10]
   26773:	48 8b 10             	mov    rdx,QWORD PTR [rax]
   26776:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
   2677a:	83 f8 f6             	cmp    eax,0xfffffff6
   2677d:	76 04                	jbe    26783 <JS_CallInternal+0x3be3>
   2677f:	83 42 fc 01          	add    DWORD PTR [rdx-0x4],0x1
   26783:	48 89 13             	mov    QWORD PTR [rbx],rdx
   26786:	49 83 c4 05          	add    r12,0x5
   2678a:	48 89 43 08          	mov    QWORD PTR [rbx+0x8],rax
   2678e:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   26794:	48 89 cb             	mov    rbx,rcx
   26797:	49 89 c5             	mov    r13,rax
   2679a:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   2679e:	ff e0                	jmp    rax
   267a0:	f3 0f 1e fa          	endbr64
   267a4:	49 63 04 24          	movsxd rax,DWORD PTR [r12]
   267a8:	48 c7 43 08 07 00 00 	mov    QWORD PTR [rbx+0x8],0x7
   267af:	00 
   267b0:	49 83 c4 05          	add    r12,0x5
   267b4:	48 83 c3 10          	add    rbx,0x10
   267b8:	48 89 43 f0          	mov    QWORD PTR [rbx-0x10],rax
   267bc:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   267c2:	49 89 c5             	mov    r13,rax
   267c5:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   267c9:	ff e0                	jmp    rax
   267cb:	f3 0f 1e fa          	endbr64
   267cf:	41 8b 04 24          	mov    eax,DWORD PTR [r12]
   267d3:	48 c7 43 08 00 00 00 	mov    QWORD PTR [rbx+0x8],0x0
   267da:	00 
   267db:	49 83 c4 05          	add    r12,0x5
   267df:	48 83 c3 10          	add    rbx,0x10
   267e3:	48 89 43 f0          	mov    QWORD PTR [rbx-0x10],rax
   267e7:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   267ed:	49 89 c5             	mov    r13,rax
   267f0:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   267f4:	ff e0                	jmp    rax
   267f6:	f3 0f 1e fa          	endbr64
   267fa:	48 c7 03 00 00 00 00 	mov    QWORD PTR [rbx],0x0
   26801:	49 83 c4 01          	add    r12,0x1
   26805:	48 83 c3 10          	add    rbx,0x10
   26809:	48 c7 43 f8 02 00 00 	mov    QWORD PTR [rbx-0x8],0x2
   26810:	00 
   26811:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   26817:	49 89 c5             	mov    r13,rax
   2681a:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   2681e:	ff e0                	jmp    rax
   26820:	f3 0f 1e fa          	endbr64
   26824:	48 c7 03 00 00 00 00 	mov    QWORD PTR [rbx],0x0
   2682b:	49 83 c4 01          	add    r12,0x1
   2682f:	48 83 c3 10          	add    rbx,0x10
   26833:	48 c7 43 f8 03 00 00 	mov    QWORD PTR [rbx-0x8],0x3
   2683a:	00 
   2683b:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   26841:	49 89 c5             	mov    r13,rax
   26844:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   26848:	ff e0                	jmp    rax
   2684a:	f3 0f 1e fa          	endbr64
   2684e:	41 8b 34 24          	mov    esi,DWORD PTR [r12]
   26852:	31 d2                	xor    edx,edx
   26854:	4c 8d 73 10          	lea    r14,[rbx+0x10]
   26858:	49 83 c4 05          	add    r12,0x5
   2685c:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   26863:	e8 e8 db 00 00       	call   34450 <__JS_AtomToValue>
   26868:	48 89 03             	mov    QWORD PTR [rbx],rax
   2686b:	48 89 53 08          	mov    QWORD PTR [rbx+0x8],rdx
   2686f:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   26875:	4c 89 f3             	mov    rbx,r14
   26878:	49 89 c5             	mov    r13,rax
   2687b:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   2687f:	ff e0                	jmp    rax
   26881:	f3 0f 1e fa          	endbr64
   26885:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2688c:	ba 01 00 00 00       	mov    edx,0x1
   26891:	4c 8d 73 10          	lea    r14,[rbx+0x10]
   26895:	49 83 c4 01          	add    r12,0x1
   26899:	be 2f 00 00 00       	mov    esi,0x2f
   2689e:	e8 ad db 00 00       	call   34450 <__JS_AtomToValue>
   268a3:	48 89 03             	mov    QWORD PTR [rbx],rax
   268a6:	48 89 53 08          	mov    QWORD PTR [rbx+0x8],rdx
   268aa:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   268b0:	4c 89 f3             	mov    rbx,r14
   268b3:	49 89 c5             	mov    r13,rax
   268b6:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   268ba:	ff e0                	jmp    rax
   268bc:	f3 0f 1e fa          	endbr64
   268c0:	48 8b 53 f8          	mov    rdx,QWORD PTR [rbx-0x8]
   268c4:	0b 53 e8             	or     edx,DWORD PTR [rbx-0x18]
   268c7:	48 8b 43 e0          	mov    rax,QWORD PTR [rbx-0x20]
   268cb:	48 8b 4b f0          	mov    rcx,QWORD PTR [rbx-0x10]
   268cf:	0f 85 1a 51 00 00    	jne    2b9ef <JS_CallInternal+0x8e4f>
   268d5:	21 c8                	and    eax,ecx
   268d7:	48 c7 43 e8 00 00 00 	mov    QWORD PTR [rbx-0x18],0x0
   268de:	00 
   268df:	48 83 eb 10          	sub    rbx,0x10
   268e3:	48 89 43 f0          	mov    QWORD PTR [rbx-0x10],rax
   268e7:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   268ec:	49 83 c4 01          	add    r12,0x1
   268f0:	49 89 c5             	mov    r13,rax
   268f3:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   268f7:	ff e0                	jmp    rax
   268f9:	f3 0f 1e fa          	endbr64
   268fd:	48 8b 53 f8          	mov    rdx,QWORD PTR [rbx-0x8]
   26901:	0b 53 e8             	or     edx,DWORD PTR [rbx-0x18]
   26904:	48 8b 43 e0          	mov    rax,QWORD PTR [rbx-0x20]
   26908:	48 8b 4b f0          	mov    rcx,QWORD PTR [rbx-0x10]
   2690c:	0f 85 0b 51 00 00    	jne    2ba1d <JS_CallInternal+0x8e7d>
   26912:	d3 f8                	sar    eax,cl
   26914:	48 c7 43 e8 00 00 00 	mov    QWORD PTR [rbx-0x18],0x0
   2691b:	00 
   2691c:	48 83 eb 10          	sub    rbx,0x10
   26920:	48 89 43 f0          	mov    QWORD PTR [rbx-0x10],rax
   26924:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   26929:	49 83 c4 01          	add    r12,0x1
   2692d:	49 89 c5             	mov    r13,rax
   26930:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   26934:	ff e0                	jmp    rax
   26936:	f3 0f 1e fa          	endbr64
   2693a:	48 8b 53 f8          	mov    rdx,QWORD PTR [rbx-0x8]
   2693e:	0b 53 e8             	or     edx,DWORD PTR [rbx-0x18]
   26941:	48 8b 43 e0          	mov    rax,QWORD PTR [rbx-0x20]
   26945:	48 8b 4b f0          	mov    rcx,QWORD PTR [rbx-0x10]
   26949:	0f 85 89 47 00 00    	jne    2b0d8 <JS_CallInternal+0x8538>
   2694f:	d3 e8                	shr    eax,cl
   26951:	85 c0                	test   eax,eax
   26953:	0f 88 47 31 00 00    	js     29aa0 <JS_CallInternal+0x6f00>
   26959:	66 0f 6e c0          	movd   xmm0,eax
   2695d:	31 c0                	xor    eax,eax
   2695f:	48 89 43 e8          	mov    QWORD PTR [rbx-0x18],rax
   26963:	48 83 eb 10          	sub    rbx,0x10
   26967:	66 0f d6 43 f0       	movq   QWORD PTR [rbx-0x10],xmm0
   2696c:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   26971:	49 83 c4 01          	add    r12,0x1
   26975:	49 89 c5             	mov    r13,rax
   26978:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   2697c:	ff e0                	jmp    rax
   2697e:	f3 0f 1e fa          	endbr64
   26982:	48 8b 53 f8          	mov    rdx,QWORD PTR [rbx-0x8]
   26986:	0b 53 e8             	or     edx,DWORD PTR [rbx-0x18]
   26989:	48 8b 43 e0          	mov    rax,QWORD PTR [rbx-0x20]
   2698d:	48 8b 4b f0          	mov    rcx,QWORD PTR [rbx-0x10]
   26991:	0f 85 2f 4d 00 00    	jne    2b6c6 <JS_CallInternal+0x8b26>
   26997:	d3 e0                	shl    eax,cl
   26999:	48 c7 43 e8 00 00 00 	mov    QWORD PTR [rbx-0x18],0x0
   269a0:	00 
   269a1:	48 83 eb 10          	sub    rbx,0x10
   269a5:	48 89 43 f0          	mov    QWORD PTR [rbx-0x10],rax
   269a9:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   269ae:	49 83 c4 01          	add    r12,0x1
   269b2:	49 89 c5             	mov    r13,rax
   269b5:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   269b9:	ff e0                	jmp    rax
   269bb:	f3 0f 1e fa          	endbr64
   269bf:	8b 7b f8             	mov    edi,DWORD PTR [rbx-0x8]
   269c2:	48 8b 43 f0          	mov    rax,QWORD PTR [rbx-0x10]
   269c6:	85 ff                	test   edi,edi
   269c8:	0f 85 1f 34 00 00    	jne    29ded <JS_CallInternal+0x724d>
   269ce:	f7 d0                	not    eax
   269d0:	48 c7 43 f8 00 00 00 	mov    QWORD PTR [rbx-0x8],0x0
   269d7:	00 
   269d8:	48 89 43 f0          	mov    QWORD PTR [rbx-0x10],rax
   269dc:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   269e1:	49 83 c4 01          	add    r12,0x1
   269e5:	49 89 c5             	mov    r13,rax
   269e8:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   269ec:	ff e0                	jmp    rax
   269ee:	f3 0f 1e fa          	endbr64
   269f2:	49 63 04 24          	movsxd rax,DWORD PTR [r12]
   269f6:	48 8b 8d d8 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x128]
   269fd:	49 8d 54 24 04       	lea    rdx,[r12+0x4]
   26a02:	48 83 c3 10          	add    rbx,0x10
   26a06:	2b 51 18             	sub    edx,DWORD PTR [rcx+0x18]
   26a09:	4c 01 e0             	add    rax,r12
   26a0c:	48 c7 43 f8 00 00 00 	mov    QWORD PTR [rbx-0x8],0x0
   26a13:	00 
   26a14:	48 89 53 f0          	mov    QWORD PTR [rbx-0x10],rdx
   26a18:	4c 8d 60 01          	lea    r12,[rax+0x1]
   26a1c:	0f b6 00             	movzx  eax,BYTE PTR [rax]
   26a1f:	49 89 c5             	mov    r13,rax
   26a22:	41 ff 24 c7          	jmp    QWORD PTR [r15+rax*8]
   26a26:	f3 0f 1e fa          	endbr64
   26a2a:	4c 8b 73 e0          	mov    r14,QWORD PTR [rbx-0x20]
   26a2e:	4c 8b 4b f0          	mov    r9,QWORD PTR [rbx-0x10]
   26a32:	4c 8b 43 f8          	mov    r8,QWORD PTR [rbx-0x8]
   26a36:	4c 8b 6b e8          	mov    r13,QWORD PTR [rbx-0x18]
   26a3a:	4c 89 f7             	mov    rdi,r14
   26a3d:	4c 89 ce             	mov    rsi,r9
   26a40:	4c 89 c0             	mov    rax,r8
   26a43:	45 85 ed             	test   r13d,r13d
   26a46:	0f 85 da 4b 00 00    	jne    2b626 <JS_CallInternal+0x8a86>
   26a4c:	45 85 c0             	test   r8d,r8d
   26a4f:	0f 85 59 2d 00 00    	jne    297ae <JS_CallInternal+0x6c0e>
   26a55:	31 c0                	xor    eax,eax
   26a57:	45 39 ce             	cmp    r14d,r9d
   26a5a:	0f 94 c0             	sete   al
   26a5d:	83 f8 01             	cmp    eax,0x1
   26a60:	48 c7 43 e8 01 00 00 	mov    QWORD PTR [rbx-0x18],0x1
   26a67:	00 
   26a68:	0f 95 c0             	setne  al
   26a6b:	0f b6 c0             	movzx  eax,al
   26a6e:	48 89 43 e0          	mov    QWORD PTR [rbx-0x20],rax
   26a72:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   26a77:	48 83 eb 10          	sub    rbx,0x10
   26a7b:	49 83 c4 01          	add    r12,0x1
   26a7f:	49 89 c5             	mov    r13,rax
   26a82:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   26a86:	ff e0                	jmp    rax
   26a88:	f3 0f 1e fa          	endbr64
   26a8c:	4c 8b 73 e0          	mov    r14,QWORD PTR [rbx-0x20]
   26a90:	4c 8b 4b f0          	mov    r9,QWORD PTR [rbx-0x10]
   26a94:	4c 8b 43 f8          	mov    r8,QWORD PTR [rbx-0x8]
   26a98:	4c 8b 6b e8          	mov    r13,QWORD PTR [rbx-0x18]
   26a9c:	4c 89 f7             	mov    rdi,r14
   26a9f:	4c 89 ce             	mov    rsi,r9
   26aa2:	4c 89 c0             	mov    rax,r8
   26aa5:	45 85 ed             	test   r13d,r13d
   26aa8:	0f 85 bb 4a 00 00    	jne    2b569 <JS_CallInternal+0x89c9>
   26aae:	45 85 c0             	test   r8d,r8d
   26ab1:	0f 85 4f 2d 00 00    	jne    29806 <JS_CallInternal+0x6c66>
   26ab7:	45 39 ce             	cmp    r14d,r9d
   26aba:	0f 94 c0             	sete   al
   26abd:	0f b6 c0             	movzx  eax,al
   26ac0:	48 c7 43 e8 01 00 00 	mov    QWORD PTR [rbx-0x18],0x1
   26ac7:	00 
   26ac8:	48 89 43 e0          	mov    QWORD PTR [rbx-0x20],rax
   26acc:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   26ad1:	48 83 eb 10          	sub    rbx,0x10
   26ad5:	49 83 c4 01          	add    r12,0x1
   26ad9:	49 89 c5             	mov    r13,rax
   26adc:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   26ae0:	ff e0                	jmp    rax
   26ae2:	f3 0f 1e fa          	endbr64
   26ae6:	48 8b 4b f8          	mov    rcx,QWORD PTR [rbx-0x8]
   26aea:	48 8b 73 e8          	mov    rsi,QWORD PTR [rbx-0x18]
   26aee:	48 8b 53 e0          	mov    rdx,QWORD PTR [rbx-0x20]
   26af2:	48 8b 43 f0          	mov    rax,QWORD PTR [rbx-0x10]
   26af6:	89 cf                	mov    edi,ecx
   26af8:	09 f7                	or     edi,esi
   26afa:	0f 85 5e 50 00 00    	jne    2bb5e <JS_CallInternal+0x8fbe>
   26b00:	39 c2                	cmp    edx,eax
   26b02:	48 c7 43 e8 01 00 00 	mov    QWORD PTR [rbx-0x18],0x1
   26b09:	00 
   26b0a:	0f 9d c0             	setge  al
   26b0d:	48 83 eb 10          	sub    rbx,0x10
   26b11:	0f b6 c0             	movzx  eax,al
   26b14:	48 89 43 f0          	mov    QWORD PTR [rbx-0x10],rax
   26b18:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   26b1d:	49 83 c4 01          	add    r12,0x1
   26b21:	49 89 c5             	mov    r13,rax
   26b24:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   26b28:	ff e0                	jmp    rax
   26b2a:	f3 0f 1e fa          	endbr64
   26b2e:	48 8b 4b f8          	mov    rcx,QWORD PTR [rbx-0x8]
   26b32:	48 8b 73 e8          	mov    rsi,QWORD PTR [rbx-0x18]
   26b36:	48 8b 53 e0          	mov    rdx,QWORD PTR [rbx-0x20]
   26b3a:	48 8b 43 f0          	mov    rax,QWORD PTR [rbx-0x10]
   26b3e:	89 cf                	mov    edi,ecx
   26b40:	09 f7                	or     edi,esi
   26b42:	0f 85 4d 44 00 00    	jne    2af95 <JS_CallInternal+0x83f5>
   26b48:	39 c2                	cmp    edx,eax
   26b4a:	48 c7 43 e8 01 00 00 	mov    QWORD PTR [rbx-0x18],0x1
   26b51:	00 
   26b52:	0f 9f c0             	setg   al
   26b55:	48 83 eb 10          	sub    rbx,0x10
   26b59:	0f b6 c0             	movzx  eax,al
   26b5c:	48 89 43 f0          	mov    QWORD PTR [rbx-0x10],rax
   26b60:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   26b65:	49 83 c4 01          	add    r12,0x1
   26b69:	49 89 c5             	mov    r13,rax
   26b6c:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   26b70:	ff e0                	jmp    rax
   26b72:	f3 0f 1e fa          	endbr64
   26b76:	48 8b 4b f8          	mov    rcx,QWORD PTR [rbx-0x8]
   26b7a:	48 8b 73 e8          	mov    rsi,QWORD PTR [rbx-0x18]
   26b7e:	48 8b 43 e0          	mov    rax,QWORD PTR [rbx-0x20]
   26b82:	48 8b 53 f0          	mov    rdx,QWORD PTR [rbx-0x10]
   26b86:	89 cf                	mov    edi,ecx
   26b88:	09 f7                	or     edi,esi
   26b8a:	0f 85 ce 46 00 00    	jne    2b25e <JS_CallInternal+0x86be>
   26b90:	39 d0                	cmp    eax,edx
   26b92:	48 c7 43 e8 01 00 00 	mov    QWORD PTR [rbx-0x18],0x1
   26b99:	00 
   26b9a:	0f 9e c0             	setle  al
   26b9d:	48 83 eb 10          	sub    rbx,0x10
   26ba1:	0f b6 c0             	movzx  eax,al
   26ba4:	48 89 43 f0          	mov    QWORD PTR [rbx-0x10],rax
   26ba8:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   26bad:	49 83 c4 01          	add    r12,0x1
   26bb1:	49 89 c5             	mov    r13,rax
   26bb4:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   26bb8:	ff e0                	jmp    rax
   26bba:	f3 0f 1e fa          	endbr64
   26bbe:	48 8b 4b f8          	mov    rcx,QWORD PTR [rbx-0x8]
   26bc2:	83 7b d8 ff          	cmp    DWORD PTR [rbx-0x28],0xffffffff
   26bc6:	4c 8d 73 e0          	lea    r14,[rbx-0x20]
   26bca:	4c 8b 43 d0          	mov    r8,QWORD PTR [rbx-0x30]
   26bce:	48 8b 73 e0          	mov    rsi,QWORD PTR [rbx-0x20]
   26bd2:	4c 8b 6b f0          	mov    r13,QWORD PTR [rbx-0x10]
   26bd6:	49 8b 46 08          	mov    rax,QWORD PTR [r14+0x8]
   26bda:	48 89 8d 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],rcx
   26be1:	0f 85 5d 4f 00 00    	jne    2bb44 <JS_CallInternal+0x8fa4>
   26be7:	83 f8 f8             	cmp    eax,0xfffffff8
   26bea:	0f 85 3a 4f 00 00    	jne    2bb2a <JS_CallInternal+0x8f8a>
   26bf0:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   26bf7:	4c 89 85 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],r8
   26bfe:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   26c02:	e8 a9 ff fe ff       	call   16bb0 <js_get_atom_index>
   26c07:	4c 8b 85 40 fe ff ff 	mov    r8,QWORD PTR [rbp-0x1c0]
   26c0e:	89 c6                	mov    esi,eax
   26c10:	49 8b 48 18          	mov    rcx,QWORD PTR [r8+0x18]
   26c14:	89 f2                	mov    edx,esi
   26c16:	8b 41 18             	mov    eax,DWORD PTR [rcx+0x18]
   26c19:	21 c2                	and    edx,eax
   26c1b:	8b 54 91 38          	mov    edx,DWORD PTR [rcx+rdx*4+0x38]
   26c1f:	48 85 d2             	test   rdx,rdx
   26c22:	0f 84 42 26 00 00    	je     2926a <JS_CallInternal+0x66ca>
   26c28:	48 8d 3c 85 34 00 00 	lea    rdi,[rax*4+0x34]
   26c2f:	00 
   26c30:	48 8d 04 d7          	lea    rax,[rdi+rdx*8]
   26c34:	48 01 c8             	add    rax,rcx
   26c37:	3b 70 04             	cmp    esi,DWORD PTR [rax+0x4]
   26c3a:	0f 85 1c 26 00 00    	jne    2925c <JS_CallInternal+0x66bc>
   26c40:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   26c47:	48 8d 0d f6 64 0a 00 	lea    rcx,[rip+0xa64f6]        # cd144 <_IO_stdin_used+0x144>
   26c4e:	48 8d 15 3b a2 0a 00 	lea    rdx,[rip+0xaa23b]        # d0e90 <_IO_stdin_used+0x3e90>
   26c55:	31 c0                	xor    eax,eax
   26c57:	e8 34 a6 00 00       	call   31290 <__JS_ThrowTypeErrorAtom>
   26c5c:	83 bd 50 fe ff ff f6 	cmp    DWORD PTR [rbp-0x1b0],0xfffffff6
   26c63:	76 13                	jbe    26c78 <JS_CallInternal+0x40d8>
   26c65:	41 8b 45 fc          	mov    eax,DWORD PTR [r13-0x4]
   26c69:	83 e8 01             	sub    eax,0x1
   26c6c:	41 89 45 fc          	mov    DWORD PTR [r13-0x4],eax
   26c70:	85 c0                	test   eax,eax
   26c72:	0f 8e f5 5b 00 00    	jle    2c86d <JS_CallInternal+0x9ccd>
   26c78:	49 8b 56 08          	mov    rdx,QWORD PTR [r14+0x8]
   26c7c:	49 8b 36             	mov    rsi,QWORD PTR [r14]
   26c7f:	4c 89 f3             	mov    rbx,r14
   26c82:	83 fa f6             	cmp    edx,0xfffffff6
   26c85:	0f 86 b5 c6 ff ff    	jbe    23340 <JS_CallInternal+0x7a0>
   26c8b:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   26c8e:	83 e8 01             	sub    eax,0x1
   26c91:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   26c94:	85 c0                	test   eax,eax
   26c96:	0f 8f a4 c6 ff ff    	jg     23340 <JS_CallInternal+0x7a0>
   26c9c:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   26ca3:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   26ca7:	e8 c4 5c ff ff       	call   1c970 <__JS_FreeValueRT>
   26cac:	e9 8f c6 ff ff       	jmp    23340 <JS_CallInternal+0x7a0>
   26cb1:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]
   26cb8:	f3 0f 1e fa          	endbr64
   26cbc:	44 8b 4b f8          	mov    r9d,DWORD PTR [rbx-0x8]
   26cc0:	48 8b 43 f0          	mov    rax,QWORD PTR [rbx-0x10]
   26cc4:	45 85 c9             	test   r9d,r9d
   26cc7:	0f 85 a5 2c 00 00    	jne    29972 <JS_CallInternal+0x6dd2>
   26ccd:	3d ff ff ff 7f       	cmp    eax,0x7fffffff
   26cd2:	0f 84 9a 2c 00 00    	je     29972 <JS_CallInternal+0x6dd2>
   26cd8:	83 c0 01             	add    eax,0x1
   26cdb:	48 c7 43 08 00 00 00 	mov    QWORD PTR [rbx+0x8],0x0
   26ce2:	00 
   26ce3:	48 89 03             	mov    QWORD PTR [rbx],rax
   26ce6:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   26ceb:	48 83 c3 10          	add    rbx,0x10
   26cef:	49 83 c4 01          	add    r12,0x1
   26cf3:	49 89 c5             	mov    r13,rax
   26cf6:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   26cfa:	ff e0                	jmp    rax
   26cfc:	f3 0f 1e fa          	endbr64
   26d00:	44 8b 53 f8          	mov    r10d,DWORD PTR [rbx-0x8]
   26d04:	48 8b 43 f0          	mov    rax,QWORD PTR [rbx-0x10]
   26d08:	45 85 d2             	test   r10d,r10d
   26d0b:	0f 85 97 2b 00 00    	jne    298a8 <JS_CallInternal+0x6d08>
   26d11:	3d 00 00 00 80       	cmp    eax,0x80000000
   26d16:	0f 84 8c 2b 00 00    	je     298a8 <JS_CallInternal+0x6d08>
   26d1c:	83 e8 01             	sub    eax,0x1
   26d1f:	48 c7 43 f8 00 00 00 	mov    QWORD PTR [rbx-0x8],0x0
   26d26:	00 
   26d27:	48 89 43 f0          	mov    QWORD PTR [rbx-0x10],rax
   26d2b:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   26d30:	49 83 c4 01          	add    r12,0x1
   26d34:	49 89 c5             	mov    r13,rax
   26d37:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   26d3b:	ff e0                	jmp    rax
   26d3d:	f3 0f 1e fa          	endbr64
   26d41:	44 8b 5b f8          	mov    r11d,DWORD PTR [rbx-0x8]
   26d45:	48 8b 43 f0          	mov    rax,QWORD PTR [rbx-0x10]
   26d49:	45 85 db             	test   r11d,r11d
   26d4c:	0f 85 26 2b 00 00    	jne    29878 <JS_CallInternal+0x6cd8>
   26d52:	3d ff ff ff 7f       	cmp    eax,0x7fffffff
   26d57:	0f 84 1b 2b 00 00    	je     29878 <JS_CallInternal+0x6cd8>
   26d5d:	83 c0 01             	add    eax,0x1
   26d60:	48 c7 43 f8 00 00 00 	mov    QWORD PTR [rbx-0x8],0x0
   26d67:	00 
   26d68:	48 89 43 f0          	mov    QWORD PTR [rbx-0x10],rax
   26d6c:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   26d71:	49 83 c4 01          	add    r12,0x1
   26d75:	49 89 c5             	mov    r13,rax
   26d78:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   26d7c:	ff e0                	jmp    rax
   26d7e:	f3 0f 1e fa          	endbr64
   26d82:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   26d89:	4c 8b 73 f8          	mov    r14,QWORD PTR [rbx-0x8]
   26d8d:	48 8b 73 f0          	mov    rsi,QWORD PTR [rbx-0x10]
   26d91:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   26d95:	41 83 fe ff          	cmp    r14d,0xffffffff
   26d99:	0f 85 ed 5a 00 00    	jne    2c88c <JS_CallInternal+0x9cec>
   26d9f:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   26da6:	48 8d 8d f0 fe ff ff 	lea    rcx,[rbp-0x110]
   26dad:	4c 89 f2             	mov    rdx,r14
   26db0:	48 89 b5 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],rsi
   26db7:	e8 c4 69 00 00       	call   2d780 <JS_IteratorGetCompleteValue>
   26dbc:	48 89 c1             	mov    rcx,rax
   26dbf:	49 89 d5             	mov    r13,rdx
   26dc2:	83 fa 06             	cmp    edx,0x6
   26dc5:	0f 84 75 c5 ff ff    	je     23340 <JS_CallInternal+0x7a0>
   26dcb:	48 8b b5 50 fe ff ff 	mov    rsi,QWORD PTR [rbp-0x1b0]
   26dd2:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   26dd5:	83 e8 01             	sub    eax,0x1
   26dd8:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   26ddb:	85 c0                	test   eax,eax
   26ddd:	0f 8e 87 38 00 00    	jle    2a66a <JS_CallInternal+0x7aca>
   26de3:	8b bd f0 fe ff ff    	mov    edi,DWORD PTR [rbp-0x110]
   26de9:	31 c0                	xor    eax,eax
   26deb:	4c 89 6b f8          	mov    QWORD PTR [rbx-0x8],r13
   26def:	48 c7 43 e0 00 00 00 	mov    QWORD PTR [rbx-0x20],0x0
   26df6:	00 
   26df7:	85 ff                	test   edi,edi
   26df9:	48 c7 43 e8 05 00 00 	mov    QWORD PTR [rbx-0x18],0x5
   26e00:	00 
   26e01:	0f 95 c0             	setne  al
   26e04:	48 89 4b f0          	mov    QWORD PTR [rbx-0x10],rcx
   26e08:	49 83 c4 01          	add    r12,0x1
   26e0c:	48 83 c3 10          	add    rbx,0x10
   26e10:	48 89 43 f0          	mov    QWORD PTR [rbx-0x10],rax
   26e14:	48 c7 43 f8 01 00 00 	mov    QWORD PTR [rbx-0x8],0x1
   26e1b:	00 
   26e1c:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   26e22:	49 89 c5             	mov    r13,rax
   26e25:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   26e29:	ff e0                	jmp    rax
   26e2b:	f3 0f 1e fa          	endbr64
   26e2f:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   26e36:	4c 8b 6b e8          	mov    r13,QWORD PTR [rbx-0x18]
   26e3a:	4c 8b 4b e0          	mov    r9,QWORD PTR [rbx-0x20]
   26e3e:	4c 8b 73 f8          	mov    r14,QWORD PTR [rbx-0x8]
   26e42:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   26e46:	48 8b 43 f0          	mov    rax,QWORD PTR [rbx-0x10]
   26e4a:	48 89 85 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],rax
   26e51:	41 83 fd ff          	cmp    r13d,0xffffffff
   26e55:	0f 85 cf 62 00 00    	jne    2d12a <JS_CallInternal+0xa58a>
   26e5b:	41 83 fe ff          	cmp    r14d,0xffffffff
   26e5f:	0f 84 4e 2c 00 00    	je     29ab3 <JS_CallInternal+0x6f13>
   26e65:	48 8b b5 50 fe ff ff 	mov    rsi,QWORD PTR [rbp-0x1b0]
   26e6c:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   26e73:	4c 89 f2             	mov    rdx,r14
   26e76:	4c 89 8d 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],r9
   26e7d:	e8 4e d0 01 00       	call   43ed0 <JS_ValueToAtom>
   26e82:	85 c0                	test   eax,eax
   26e84:	0f 84 b6 c4 ff ff    	je     23340 <JS_CallInternal+0x7a0>
   26e8a:	4c 8b 8d 40 fe ff ff 	mov    r9,QWORD PTR [rbp-0x1c0]
   26e91:	89 c2                	mov    edx,eax
   26e93:	49 8b 49 18          	mov    rcx,QWORD PTR [r9+0x18]
   26e97:	8b 71 18             	mov    esi,DWORD PTR [rcx+0x18]
   26e9a:	21 f2                	and    edx,esi
   26e9c:	8b 54 91 38          	mov    edx,DWORD PTR [rcx+rdx*4+0x38]
   26ea0:	48 85 d2             	test   rdx,rdx
   26ea3:	0f 84 d7 51 00 00    	je     2c080 <JS_CallInternal+0x94e0>
   26ea9:	48 8d 34 b5 34 00 00 	lea    rsi,[rsi*4+0x34]
   26eb0:	00 
   26eb1:	48 8d 14 d6          	lea    rdx,[rsi+rdx*8]
   26eb5:	48 01 ca             	add    rdx,rcx
   26eb8:	3b 42 04             	cmp    eax,DWORD PTR [rdx+0x4]
   26ebb:	0f 85 b1 51 00 00    	jne    2c072 <JS_CallInternal+0x94d2>
   26ec1:	3d f2 00 00 00       	cmp    eax,0xf2
   26ec6:	0f 8f 7c 35 00 00    	jg     2a448 <JS_CallInternal+0x78a8>
   26ecc:	48 85 d2             	test   rdx,rdx
   26ecf:	0f 95 c0             	setne  al
   26ed2:	41 83 fd f6          	cmp    r13d,0xfffffff6
   26ed6:	76 13                	jbe    26eeb <JS_CallInternal+0x434b>
   26ed8:	41 8b 49 fc          	mov    ecx,DWORD PTR [r9-0x4]
   26edc:	8d 51 ff             	lea    edx,[rcx-0x1]
   26edf:	41 89 51 fc          	mov    DWORD PTR [r9-0x4],edx
   26ee3:	85 d2                	test   edx,edx
   26ee5:	0f 8e d6 3e 00 00    	jle    2adc1 <JS_CallInternal+0x8221>
   26eeb:	41 83 fe f6          	cmp    r14d,0xfffffff6
   26eef:	76 1e                	jbe    26f0f <JS_CallInternal+0x436f>
   26ef1:	48 8b 8d 50 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x1b0]
   26ef8:	8b 79 fc             	mov    edi,DWORD PTR [rcx-0x4]
   26efb:	8d 57 ff             	lea    edx,[rdi-0x1]
   26efe:	89 bd 40 fe ff ff    	mov    DWORD PTR [rbp-0x1c0],edi
   26f04:	89 51 fc             	mov    DWORD PTR [rcx-0x4],edx
   26f07:	85 d2                	test   edx,edx
   26f09:	0f 8e a3 3a 00 00    	jle    2a9b2 <JS_CallInternal+0x7e12>
   26f0f:	0f b6 c0             	movzx  eax,al
   26f12:	48 c7 43 e8 01 00 00 	mov    QWORD PTR [rbx-0x18],0x1
   26f19:	00 
   26f1a:	49 83 c4 01          	add    r12,0x1
   26f1e:	48 83 eb 10          	sub    rbx,0x10
   26f22:	48 89 43 f0          	mov    QWORD PTR [rbx-0x10],rax
   26f26:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   26f2c:	49 89 c5             	mov    r13,rax
   26f2f:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   26f33:	ff e0                	jmp    rax
   26f35:	f3 0f 1e fa          	endbr64
   26f39:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   26f40:	4c 8b 6b f8          	mov    r13,QWORD PTR [rbx-0x8]
   26f44:	4c 8b 73 e0          	mov    r14,QWORD PTR [rbx-0x20]
   26f48:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   26f4c:	48 8b 43 e8          	mov    rax,QWORD PTR [rbx-0x18]
   26f50:	48 89 85 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],rax
   26f57:	48 8b 43 f0          	mov    rax,QWORD PTR [rbx-0x10]
   26f5b:	48 89 85 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],rax
   26f62:	41 83 fd ff          	cmp    r13d,0xffffffff
   26f66:	0f 85 5f 58 00 00    	jne    2c7cb <JS_CallInternal+0x9c2b>
   26f6c:	48 8b 95 50 fe ff ff 	mov    rdx,QWORD PTR [rbp-0x1b0]
   26f73:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   26f7a:	4c 89 f6             	mov    rsi,r14
   26f7d:	e8 4e cf 01 00       	call   43ed0 <JS_ValueToAtom>
   26f82:	89 c1                	mov    ecx,eax
   26f84:	85 c0                	test   eax,eax
   26f86:	0f 84 b4 c3 ff ff    	je     23340 <JS_CallInternal+0x7a0>
   26f8c:	48 8b b5 40 fe ff ff 	mov    rsi,QWORD PTR [rbp-0x1c0]
   26f93:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   26f9a:	4c 89 ea             	mov    rdx,r13
   26f9d:	89 85 38 fe ff ff    	mov    DWORD PTR [rbp-0x1c8],eax
   26fa3:	e8 58 76 04 00       	call   6e600 <JS_HasProperty>
   26fa8:	8b 8d 38 fe ff ff    	mov    ecx,DWORD PTR [rbp-0x1c8]
   26fae:	41 89 c0             	mov    r8d,eax
   26fb1:	81 f9 f2 00 00 00    	cmp    ecx,0xf2
   26fb7:	0f 8f bb 30 00 00    	jg     2a078 <JS_CallInternal+0x74d8>
   26fbd:	45 85 c0             	test   r8d,r8d
   26fc0:	0f 88 7a c3 ff ff    	js     23340 <JS_CallInternal+0x7a0>
   26fc6:	83 bd 50 fe ff ff f6 	cmp    DWORD PTR [rbp-0x1b0],0xfffffff6
   26fcd:	76 13                	jbe    26fe2 <JS_CallInternal+0x4442>
   26fcf:	41 8b 46 fc          	mov    eax,DWORD PTR [r14-0x4]
   26fd3:	83 e8 01             	sub    eax,0x1
   26fd6:	41 89 46 fc          	mov    DWORD PTR [r14-0x4],eax
   26fda:	85 c0                	test   eax,eax
   26fdc:	0f 8e db 48 00 00    	jle    2b8bd <JS_CallInternal+0x8d1d>
   26fe2:	41 83 fd f6          	cmp    r13d,0xfffffff6
   26fe6:	76 1e                	jbe    27006 <JS_CallInternal+0x4466>
   26fe8:	48 8b 8d 40 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x1c0]
   26fef:	8b 41 fc             	mov    eax,DWORD PTR [rcx-0x4]
   26ff2:	89 85 50 fe ff ff    	mov    DWORD PTR [rbp-0x1b0],eax
   26ff8:	83 e8 01             	sub    eax,0x1
   26ffb:	89 41 fc             	mov    DWORD PTR [rcx-0x4],eax
   26ffe:	85 c0                	test   eax,eax
   27000:	0f 8e f5 42 00 00    	jle    2b2fb <JS_CallInternal+0x875b>
   27006:	31 c0                	xor    eax,eax
   27008:	45 85 c0             	test   r8d,r8d
   2700b:	48 c7 43 e8 01 00 00 	mov    QWORD PTR [rbx-0x18],0x1
   27012:	00 
   27013:	0f 95 c0             	setne  al
   27016:	48 83 eb 10          	sub    rbx,0x10
   2701a:	49 83 c4 01          	add    r12,0x1
   2701e:	48 89 43 f0          	mov    QWORD PTR [rbx-0x10],rax
   27022:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   27028:	49 89 c5             	mov    r13,rax
   2702b:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   2702f:	ff e0                	jmp    rax
   27031:	f3 0f 1e fa          	endbr64
   27035:	48 8b 43 f8          	mov    rax,QWORD PTR [rbx-0x8]
   27039:	48 8b 73 e8          	mov    rsi,QWORD PTR [rbx-0x18]
   2703d:	48 8b 4b e0          	mov    rcx,QWORD PTR [rbx-0x20]
   27041:	48 8b 53 f0          	mov    rdx,QWORD PTR [rbx-0x10]
   27045:	89 c7                	mov    edi,eax
   27047:	09 f7                	or     edi,esi
   27049:	0f 85 2b 43 00 00    	jne    2b37a <JS_CallInternal+0x87da>
   2704f:	48 63 f2             	movsxd rsi,edx
   27052:	48 63 c1             	movsxd rax,ecx
   27055:	48 0f af c6          	imul   rax,rsi
   27059:	48 63 f0             	movsxd rsi,eax
   2705c:	48 39 c6             	cmp    rsi,rax
   2705f:	0f 85 f9 42 00 00    	jne    2b35e <JS_CallInternal+0x87be>
   27065:	48 85 f6             	test   rsi,rsi
   27068:	0f 84 b7 4c 00 00    	je     2bd25 <JS_CallInternal+0x9185>
   2706e:	83 e0 ff             	and    eax,0xffffffff
   27071:	48 8d 53 f0          	lea    rdx,[rbx-0x10]
   27075:	48 89 43 e0          	mov    QWORD PTR [rbx-0x20],rax
   27079:	31 c0                	xor    eax,eax
   2707b:	48 89 43 e8          	mov    QWORD PTR [rbx-0x18],rax
   2707f:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   27084:	48 89 d3             	mov    rbx,rdx
   27087:	49 83 c4 01          	add    r12,0x1
   2708b:	49 89 c5             	mov    r13,rax
   2708e:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   27092:	ff e0                	jmp    rax
   27094:	f3 0f 1e fa          	endbr64
   27098:	48 8b 43 f8          	mov    rax,QWORD PTR [rbx-0x8]
   2709c:	48 8b 53 e8          	mov    rdx,QWORD PTR [rbx-0x18]
   270a0:	48 8b 7b e0          	mov    rdi,QWORD PTR [rbx-0x20]
   270a4:	48 8b 4b f0          	mov    rcx,QWORD PTR [rbx-0x10]
   270a8:	89 c6                	mov    esi,eax
   270aa:	09 d6                	or     esi,edx
   270ac:	0f 85 0d 43 00 00    	jne    2b3bf <JS_CallInternal+0x881f>
   270b2:	89 fa                	mov    edx,edi
   270b4:	48 63 f1             	movsxd rsi,ecx
   270b7:	48 63 c7             	movsxd rax,edi
   270ba:	29 ca                	sub    edx,ecx
   270bc:	48 29 f0             	sub    rax,rsi
   270bf:	48 63 ca             	movsxd rcx,edx
   270c2:	48 39 c1             	cmp    rcx,rax
   270c5:	0f 85 dc 42 00 00    	jne    2b3a7 <JS_CallInternal+0x8807>
   270cb:	89 d0                	mov    eax,edx
   270cd:	48 89 43 e0          	mov    QWORD PTR [rbx-0x20],rax
   270d1:	31 c0                	xor    eax,eax
   270d3:	48 8d 53 f0          	lea    rdx,[rbx-0x10]
   270d7:	48 89 43 e8          	mov    QWORD PTR [rbx-0x18],rax
   270db:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   270e0:	48 89 d3             	mov    rbx,rdx
   270e3:	49 83 c4 01          	add    r12,0x1
   270e7:	49 89 c5             	mov    r13,rax
   270ea:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   270ee:	ff e0                	jmp    rax
   270f0:	f3 0f 1e fa          	endbr64
   270f4:	45 0f b6 2c 24       	movzx  r13d,BYTE PTR [r12]
   270f9:	48 8b 85 b0 fe ff ff 	mov    rax,QWORD PTR [rbp-0x150]
   27100:	4d 8d 4c 24 01       	lea    r9,[r12+0x1]
   27105:	4c 8b 73 f8          	mov    r14,QWORD PTR [rbx-0x8]
   27109:	4c 8b 43 f0          	mov    r8,QWORD PTR [rbx-0x10]
   2710d:	49 c1 e5 04          	shl    r13,0x4
   27111:	49 01 c5             	add    r13,rax
   27114:	44 89 f1             	mov    ecx,r14d
   27117:	49 8b 55 08          	mov    rdx,QWORD PTR [r13+0x8]
   2711b:	09 d1                	or     ecx,edx
   2711d:	0f 85 f3 42 00 00    	jne    2b416 <JS_CallInternal+0x8876>
   27123:	49 8b 45 00          	mov    rax,QWORD PTR [r13+0x0]
   27127:	49 63 c8             	movsxd rcx,r8d
   2712a:	48 63 d0             	movsxd rdx,eax
   2712d:	44 01 c0             	add    eax,r8d
   27130:	48 01 ca             	add    rdx,rcx
   27133:	48 63 c8             	movsxd rcx,eax
   27136:	48 39 d1             	cmp    rcx,rdx
   27139:	0f 85 be 42 00 00    	jne    2b3fd <JS_CallInternal+0x885d>
   2713f:	89 c0                	mov    eax,eax
   27141:	49 89 45 00          	mov    QWORD PTR [r13+0x0],rax
   27145:	31 c0                	xor    eax,eax
   27147:	49 89 45 08          	mov    QWORD PTR [r13+0x8],rax
   2714b:	48 83 eb 10          	sub    rbx,0x10
   2714f:	41 0f b6 44 24 01    	movzx  eax,BYTE PTR [r12+0x1]
   27155:	49 83 c4 02          	add    r12,0x2
   27159:	49 89 c5             	mov    r13,rax
   2715c:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   27160:	ff e0                	jmp    rax
   27162:	f3 0f 1e fa          	endbr64
   27166:	48 8b 7b f8          	mov    rdi,QWORD PTR [rbx-0x8]
   2716a:	4c 8b 5b e8          	mov    r11,QWORD PTR [rbx-0x18]
   2716e:	4c 8b 43 f0          	mov    r8,QWORD PTR [rbx-0x10]
   27172:	4c 8b 53 e0          	mov    r10,QWORD PTR [rbx-0x20]
   27176:	41 89 fe             	mov    r14d,edi
   27179:	4c 89 de             	mov    rsi,r11
   2717c:	48 89 f9             	mov    rcx,rdi
   2717f:	45 09 de             	or     r14d,r11d
   27182:	4c 89 c0             	mov    rax,r8
   27185:	0f 85 77 47 00 00    	jne    2b902 <JS_CallInternal+0x8d62>
   2718b:	49 63 ca             	movsxd rcx,r10d
   2718e:	49 63 f0             	movsxd rsi,r8d
   27191:	44 01 d0             	add    eax,r10d
   27194:	48 01 f1             	add    rcx,rsi
   27197:	48 63 d0             	movsxd rdx,eax
   2719a:	48 39 ca             	cmp    rdx,rcx
   2719d:	0f 85 47 47 00 00    	jne    2b8ea <JS_CallInternal+0x8d4a>
   271a3:	89 c0                	mov    eax,eax
   271a5:	48 89 43 e0          	mov    QWORD PTR [rbx-0x20],rax
   271a9:	31 c0                	xor    eax,eax
   271ab:	48 89 43 e8          	mov    QWORD PTR [rbx-0x18],rax
   271af:	48 83 eb 10          	sub    rbx,0x10
   271b3:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   271b8:	49 83 c4 01          	add    r12,0x1
   271bc:	49 89 c5             	mov    r13,rax
   271bf:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   271c3:	ff e0                	jmp    rax
   271c5:	f3 0f 1e fa          	endbr64
   271c9:	41 0f b6 3c 24       	movzx  edi,BYTE PTR [r12]
   271ce:	48 8b 8d c8 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x138]
   271d5:	4d 8d 6c 24 01       	lea    r13,[r12+0x1]
   271da:	45 31 c9             	xor    r9d,r9d
   271dd:	89 fa                	mov    edx,edi
   271df:	89 f8                	mov    eax,edi
   271e1:	4c 89 69 30          	mov    QWORD PTR [rcx+0x30],r13
   271e5:	c1 fa 02             	sar    edx,0x2
   271e8:	83 e0 03             	and    eax,0x3
   271eb:	83 e2 07             	and    edx,0x7
   271ee:	f7 d0                	not    eax
   271f0:	f7 d2                	not    edx
   271f2:	48 98                	cdqe
   271f4:	48 63 d2             	movsxd rdx,edx
   271f7:	48 c1 e0 04          	shl    rax,0x4
   271fb:	48 c1 e2 04          	shl    rdx,0x4
   271ff:	48 01 d8             	add    rax,rbx
   27202:	48 01 da             	add    rdx,rbx
   27205:	48 8b 30             	mov    rsi,QWORD PTR [rax]
   27208:	48 8b 0a             	mov    rcx,QWORD PTR [rdx]
   2720b:	4c 8b 42 08          	mov    r8,QWORD PTR [rdx+0x8]
   2720f:	48 8b 50 08          	mov    rdx,QWORD PTR [rax+0x8]
   27213:	89 f8                	mov    eax,edi
   27215:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2721c:	c1 f8 05             	sar    eax,0x5
   2721f:	f7 d0                	not    eax
   27221:	48 98                	cdqe
   27223:	48 c1 e0 04          	shl    rax,0x4
   27227:	ff 74 03 08          	push   QWORD PTR [rbx+rax*1+0x8]
   2722b:	ff 34 03             	push   QWORD PTR [rbx+rax*1]
   2722e:	e8 1d 47 06 00       	call   8b950 <JS_CopyDataProperties>
   27233:	41 5e                	pop    r14
   27235:	5a                   	pop    rdx
   27236:	85 c0                	test   eax,eax
   27238:	0f 85 fd 54 00 00    	jne    2c73b <JS_CallInternal+0x9b9b>
   2723e:	41 0f b6 44 24 01    	movzx  eax,BYTE PTR [r12+0x1]
   27244:	49 83 c4 02          	add    r12,0x2
   27248:	49 89 c5             	mov    r13,rax
   2724b:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   2724f:	ff e0                	jmp    rax
   27251:	f3 0f 1e fa          	endbr64
   27255:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   2725c:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   27263:	48 89 de             	mov    rsi,rbx
   27266:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   2726a:	e8 91 3d 07 00       	call   9b000 <js_append_enumerate>
   2726f:	85 c0                	test   eax,eax
   27271:	0f 85 c9 c0 ff ff    	jne    23340 <JS_CallInternal+0x7a0>
   27277:	48 8b 53 f8          	mov    rdx,QWORD PTR [rbx-0x8]
   2727b:	48 83 eb 10          	sub    rbx,0x10
   2727f:	48 8b 33             	mov    rsi,QWORD PTR [rbx]
   27282:	83 fa f6             	cmp    edx,0xfffffff6
   27285:	76 11                	jbe    27298 <JS_CallInternal+0x46f8>
   27287:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   2728a:	83 e8 01             	sub    eax,0x1
   2728d:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   27290:	85 c0                	test   eax,eax
   27292:	0f 8e bf 36 00 00    	jle    2a957 <JS_CallInternal+0x7db7>
   27298:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   2729d:	49 83 c4 01          	add    r12,0x1
   272a1:	49 89 c5             	mov    r13,rax
   272a4:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   272a8:	ff e0                	jmp    rax
   272aa:	f3 0f 1e fa          	endbr64
   272ae:	45 0f b6 2c 24       	movzx  r13d,BYTE PTR [r12]
   272b3:	48 8b 85 b0 fe ff ff 	mov    rax,QWORD PTR [rbp-0x150]
   272ba:	4d 8d 74 24 01       	lea    r14,[r12+0x1]
   272bf:	49 c1 e5 04          	shl    r13,0x4
   272c3:	49 01 c5             	add    r13,rax
   272c6:	f3 41 0f 6f 55 00    	movdqu xmm2,XMMWORD PTR [r13+0x0]
   272cc:	0f 29 95 f0 fe ff ff 	movaps XMMWORD PTR [rbp-0x110],xmm2
   272d3:	48 8b 95 f8 fe ff ff 	mov    rdx,QWORD PTR [rbp-0x108]
   272da:	48 8b 85 f0 fe ff ff 	mov    rax,QWORD PTR [rbp-0x110]
   272e1:	85 d2                	test   edx,edx
   272e3:	0f 85 64 22 00 00    	jne    2954d <JS_CallInternal+0x69ad>
   272e9:	3d ff ff ff 7f       	cmp    eax,0x7fffffff
   272ee:	0f 84 59 22 00 00    	je     2954d <JS_CallInternal+0x69ad>
   272f4:	83 c0 01             	add    eax,0x1
   272f7:	49 c7 45 08 00 00 00 	mov    QWORD PTR [r13+0x8],0x0
   272fe:	00 
   272ff:	49 89 45 00          	mov    QWORD PTR [r13+0x0],rax
   27303:	41 0f b6 44 24 01    	movzx  eax,BYTE PTR [r12+0x1]
   27309:	49 83 c4 02          	add    r12,0x2
   2730d:	49 89 c5             	mov    r13,rax
   27310:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   27314:	ff e0                	jmp    rax
   27316:	f3 0f 1e fa          	endbr64
   2731a:	44 8b 43 f8          	mov    r8d,DWORD PTR [rbx-0x8]
   2731e:	48 8b 43 f0          	mov    rax,QWORD PTR [rbx-0x10]
   27322:	45 85 c0             	test   r8d,r8d
   27325:	0f 85 1c 25 00 00    	jne    29847 <JS_CallInternal+0x6ca7>
   2732b:	3d 00 00 00 80       	cmp    eax,0x80000000
   27330:	0f 84 11 25 00 00    	je     29847 <JS_CallInternal+0x6ca7>
   27336:	83 e8 01             	sub    eax,0x1
   27339:	48 c7 43 08 00 00 00 	mov    QWORD PTR [rbx+0x8],0x0
   27340:	00 
   27341:	48 89 03             	mov    QWORD PTR [rbx],rax
   27344:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   27349:	48 83 c3 10          	add    rbx,0x10
   2734d:	49 83 c4 01          	add    r12,0x1
   27351:	49 89 c5             	mov    r13,rax
   27354:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   27358:	ff e0                	jmp    rax
   2735a:	f3 0f 1e fa          	endbr64
   2735e:	48 8b 8d e8 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x118]
   27365:	4d 63 2c 24          	movsxd r13,DWORD PTR [r12]
   27369:	8b 81 a8 01 00 00    	mov    eax,DWORD PTR [rcx+0x1a8]
   2736f:	4d 01 e5             	add    r13,r12
   27372:	89 85 50 fe ff ff    	mov    DWORD PTR [rbp-0x1b0],eax
   27378:	83 e8 01             	sub    eax,0x1
   2737b:	89 81 a8 01 00 00    	mov    DWORD PTR [rcx+0x1a8],eax
   27381:	85 c0                	test   eax,eax
   27383:	0f 8e 98 48 00 00    	jle    2bc21 <JS_CallInternal+0x9081>
   27389:	41 0f b6 45 00       	movzx  eax,BYTE PTR [r13+0x0]
   2738e:	4d 8d 65 01          	lea    r12,[r13+0x1]
   27392:	49 89 c5             	mov    r13,rax
   27395:	41 ff 24 c7          	jmp    QWORD PTR [r15+rax*8]
   27399:	f3 0f 1e fa          	endbr64
   2739d:	48 8b 53 f8          	mov    rdx,QWORD PTR [rbx-0x8]
   273a1:	0b 53 e8             	or     edx,DWORD PTR [rbx-0x18]
   273a4:	48 8b 43 e0          	mov    rax,QWORD PTR [rbx-0x20]
   273a8:	48 8b 4b f0          	mov    rcx,QWORD PTR [rbx-0x10]
   273ac:	0f 85 11 3e 00 00    	jne    2b1c3 <JS_CallInternal+0x8623>
   273b2:	31 c8                	xor    eax,ecx
   273b4:	48 c7 43 e8 00 00 00 	mov    QWORD PTR [rbx-0x18],0x0
   273bb:	00 
   273bc:	48 83 eb 10          	sub    rbx,0x10
   273c0:	48 89 43 f0          	mov    QWORD PTR [rbx-0x10],rax
   273c4:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   273c9:	49 83 c4 01          	add    r12,0x1
   273cd:	49 89 c5             	mov    r13,rax
   273d0:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   273d4:	ff e0                	jmp    rax
   273d6:	f3 0f 1e fa          	endbr64
   273da:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   273e1:	4c 8b 73 f8          	mov    r14,QWORD PTR [rbx-0x8]
   273e5:	4c 8b 6b f0          	mov    r13,QWORD PTR [rbx-0x10]
   273e9:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   273ed:	41 83 fe ff          	cmp    r14d,0xffffffff
   273f1:	0f 84 53 23 00 00    	je     2974a <JS_CallInternal+0x6baa>
   273f7:	41 83 fe 02          	cmp    r14d,0x2
   273fb:	0f 84 49 23 00 00    	je     2974a <JS_CallInternal+0x6baa>
   27401:	41 83 fe f6          	cmp    r14d,0xfffffff6
   27405:	76 13                	jbe    2741a <JS_CallInternal+0x487a>
   27407:	41 8b 45 fc          	mov    eax,DWORD PTR [r13-0x4]
   2740b:	83 e8 01             	sub    eax,0x1
   2740e:	41 89 45 fc          	mov    DWORD PTR [r13-0x4],eax
   27412:	85 c0                	test   eax,eax
   27414:	0f 8e cb 36 00 00    	jle    2aae5 <JS_CallInternal+0x7f45>
   2741a:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   2741f:	48 83 eb 10          	sub    rbx,0x10
   27423:	49 83 c4 01          	add    r12,0x1
   27427:	49 89 c5             	mov    r13,rax
   2742a:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   2742e:	ff e0                	jmp    rax
   27430:	f3 0f 1e fa          	endbr64
   27434:	48 8b 43 f8          	mov    rax,QWORD PTR [rbx-0x8]
   27438:	0b 43 e8             	or     eax,DWORD PTR [rbx-0x18]
   2743b:	48 8b 4b e0          	mov    rcx,QWORD PTR [rbx-0x20]
   2743f:	48 8b 53 f0          	mov    rdx,QWORD PTR [rbx-0x10]
   27443:	0f 85 4e c8 ff ff    	jne    23c97 <JS_CallInternal+0x10f7>
   27449:	89 c8                	mov    eax,ecx
   2744b:	89 d6                	mov    esi,edx
   2744d:	85 c9                	test   ecx,ecx
   2744f:	0f 88 42 c8 ff ff    	js     23c97 <JS_CallInternal+0x10f7>
   27455:	85 d2                	test   edx,edx
   27457:	0f 8e 3a c8 ff ff    	jle    23c97 <JS_CallInternal+0x10f7>
   2745d:	99                   	cdq
   2745e:	48 c7 43 e8 00 00 00 	mov    QWORD PTR [rbx-0x18],0x0
   27465:	00 
   27466:	49 83 c4 01          	add    r12,0x1
   2746a:	48 83 eb 10          	sub    rbx,0x10
   2746e:	f7 fe                	idiv   esi
   27470:	48 63 d2             	movsxd rdx,edx
   27473:	48 89 53 f0          	mov    QWORD PTR [rbx-0x10],rdx
   27477:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   2747d:	49 89 c5             	mov    r13,rax
   27480:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   27484:	ff e0                	jmp    rax
   27486:	f3 0f 1e fa          	endbr64
   2748a:	48 8b 43 f8          	mov    rax,QWORD PTR [rbx-0x8]
   2748e:	48 8b 53 f0          	mov    rdx,QWORD PTR [rbx-0x10]
   27492:	a9 f7 ff ff ff       	test   eax,0xfffffff7
   27497:	74 1b                	je     274b4 <JS_CallInternal+0x4914>
   27499:	83 e8 01             	sub    eax,0x1
   2749c:	83 f8 01             	cmp    eax,0x1
   2749f:	0f 87 12 30 00 00    	ja     2a4b7 <JS_CallInternal+0x7917>
   274a5:	83 e2 ff             	and    edx,0xffffffff
   274a8:	48 c7 43 f8 00 00 00 	mov    QWORD PTR [rbx-0x8],0x0
   274af:	00 
   274b0:	48 89 53 f0          	mov    QWORD PTR [rbx-0x10],rdx
   274b4:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   274b9:	49 83 c4 01          	add    r12,0x1
   274bd:	49 89 c5             	mov    r13,rax
   274c0:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   274c4:	ff e0                	jmp    rax
   274c6:	f3 0f 1e fa          	endbr64
   274ca:	48 8b 53 f8          	mov    rdx,QWORD PTR [rbx-0x8]
   274ce:	48 8b 43 f0          	mov    rax,QWORD PTR [rbx-0x10]
   274d2:	83 fa 02             	cmp    edx,0x2
   274d5:	0f 87 e1 21 00 00    	ja     296bc <JS_CallInternal+0x6b1c>
   274db:	85 c0                	test   eax,eax
   274dd:	0f 84 32 4c 00 00    	je     2c115 <JS_CallInternal+0x9575>
   274e3:	3d 00 00 00 80       	cmp    eax,0x80000000
   274e8:	0f 84 49 4c 00 00    	je     2c137 <JS_CallInternal+0x9597>
   274ee:	f7 d8                	neg    eax
   274f0:	48 c7 43 f8 00 00 00 	mov    QWORD PTR [rbx-0x8],0x0
   274f7:	00 
   274f8:	48 89 43 f0          	mov    QWORD PTR [rbx-0x10],rax
   274fc:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   27501:	49 83 c4 01          	add    r12,0x1
   27505:	49 89 c5             	mov    r13,rax
   27508:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   2750c:	ff e0                	jmp    rax
   2750e:	f3 0f 1e fa          	endbr64
   27512:	48 8b 43 f8          	mov    rax,QWORD PTR [rbx-0x8]
   27516:	0b 43 e8             	or     eax,DWORD PTR [rbx-0x18]
   27519:	48 8b 4b e0          	mov    rcx,QWORD PTR [rbx-0x20]
   2751d:	48 8b 53 f0          	mov    rdx,QWORD PTR [rbx-0x10]
   27521:	0f 85 70 c7 ff ff    	jne    23c97 <JS_CallInternal+0x10f7>
   27527:	66 0f ef c0          	pxor   xmm0,xmm0
   2752b:	66 0f ef c9          	pxor   xmm1,xmm1
   2752f:	f2 0f 2a c1          	cvtsi2sd xmm0,ecx
   27533:	f2 0f 2a ca          	cvtsi2sd xmm1,edx
   27537:	f2 0f 5e c1          	divsd  xmm0,xmm1
   2753b:	66 0f 2f 05 d5 be 0a 	comisd xmm0,QWORD PTR [rip+0xabed5]        # d3418 <__PRETTY_FUNCTION__.0+0xc8>
   27542:	00 
   27543:	66 48 0f 7e c0       	movq   rax,xmm0
   27548:	0f 82 7b 1d 00 00    	jb     292c9 <JS_CallInternal+0x6729>
   2754e:	f2 0f 10 0d ca be 0a 	movsd  xmm1,QWORD PTR [rip+0xabeca]        # d3420 <__PRETTY_FUNCTION__.0+0xd0>
   27555:	00 
   27556:	66 0f 2f c8          	comisd xmm1,xmm0
   2755a:	0f 82 69 1d 00 00    	jb     292c9 <JS_CallInternal+0x6729>
   27560:	f2 0f 2c c8          	cvttsd2si ecx,xmm0
   27564:	66 0f ef ed          	pxor   xmm5,xmm5
   27568:	ba 08 00 00 00       	mov    edx,0x8
   2756d:	f2 0f 2a e9          	cvtsi2sd xmm5,ecx
   27571:	66 48 0f 7e ee       	movq   rsi,xmm5
   27576:	48 39 f0             	cmp    rax,rsi
   27579:	0f 84 84 4a 00 00    	je     2c003 <JS_CallInternal+0x9463>
   2757f:	48 89 43 e0          	mov    QWORD PTR [rbx-0x20],rax
   27583:	49 83 c4 01          	add    r12,0x1
   27587:	48 83 eb 10          	sub    rbx,0x10
   2758b:	48 89 53 f8          	mov    QWORD PTR [rbx-0x8],rdx
   2758f:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   27595:	49 89 c5             	mov    r13,rax
   27598:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   2759c:	ff e0                	jmp    rax
   2759e:	f3 0f 1e fa          	endbr64
   275a2:	45 0f b6 2c 24       	movzx  r13d,BYTE PTR [r12]
   275a7:	48 8b 85 b0 fe ff ff 	mov    rax,QWORD PTR [rbp-0x150]
   275ae:	4d 8d 74 24 01       	lea    r14,[r12+0x1]
   275b3:	49 c1 e5 04          	shl    r13,0x4
   275b7:	49 01 c5             	add    r13,rax
   275ba:	f3 41 0f 6f 6d 00    	movdqu xmm5,XMMWORD PTR [r13+0x0]
   275c0:	0f 29 ad f0 fe ff ff 	movaps XMMWORD PTR [rbp-0x110],xmm5
   275c7:	48 8b 95 f8 fe ff ff 	mov    rdx,QWORD PTR [rbp-0x108]
   275ce:	48 8b 85 f0 fe ff ff 	mov    rax,QWORD PTR [rbp-0x110]
   275d5:	85 d2                	test   edx,edx
   275d7:	0f 85 f6 1f 00 00    	jne    295d3 <JS_CallInternal+0x6a33>
   275dd:	3d 00 00 00 80       	cmp    eax,0x80000000
   275e2:	0f 84 eb 1f 00 00    	je     295d3 <JS_CallInternal+0x6a33>
   275e8:	83 e8 01             	sub    eax,0x1
   275eb:	49 c7 45 08 00 00 00 	mov    QWORD PTR [r13+0x8],0x0
   275f2:	00 
   275f3:	49 89 45 00          	mov    QWORD PTR [r13+0x0],rax
   275f7:	41 0f b6 44 24 01    	movzx  eax,BYTE PTR [r12+0x1]
   275fd:	49 83 c4 02          	add    r12,0x2
   27601:	49 89 c5             	mov    r13,rax
   27604:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   27608:	ff e0                	jmp    rax
   2760a:	f3 0f 1e fa          	endbr64
   2760e:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   27615:	4c 8d 6b f0          	lea    r13,[rbx-0x10]
   27619:	48 8b 4b c0          	mov    rcx,QWORD PTR [rbx-0x40]
   2761d:	48 c7 85 00 fe ff ff 	mov    QWORD PTR [rbp-0x200],0x0
   27624:	00 00 00 00 
   27628:	4c 8b 43 c8          	mov    r8,QWORD PTR [rbx-0x38]
   2762c:	48 8b 73 d0          	mov    rsi,QWORD PTR [rbx-0x30]
   27630:	41 b9 01 00 00 00    	mov    r9d,0x1
   27636:	48 c7 85 08 fe ff ff 	mov    QWORD PTR [rbp-0x1f8],0x3
   2763d:	03 00 00 00 
   27641:	48 8b 53 d8          	mov    rdx,QWORD PTR [rbx-0x28]
   27645:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2764c:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   27650:	6a 02                	push   0x2
   27652:	41 55                	push   r13
   27654:	ff b5 08 fe ff ff    	push   QWORD PTR [rbp-0x1f8]
   2765a:	ff b5 00 fe ff ff    	push   QWORD PTR [rbp-0x200]
   27660:	e8 3b b5 ff ff       	call   22ba0 <JS_CallInternal>
   27665:	48 83 c4 20          	add    rsp,0x20
   27669:	48 89 c1             	mov    rcx,rax
   2766c:	49 89 d6             	mov    r14,rdx
   2766f:	83 fa 06             	cmp    edx,0x6
   27672:	0f 84 c8 bc ff ff    	je     23340 <JS_CallInternal+0x7a0>
   27678:	48 8b 53 f8          	mov    rdx,QWORD PTR [rbx-0x8]
   2767c:	48 8b 73 f0          	mov    rsi,QWORD PTR [rbx-0x10]
   27680:	83 fa f6             	cmp    edx,0xfffffff6
   27683:	76 11                	jbe    27696 <JS_CallInternal+0x4af6>
   27685:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   27688:	83 e8 01             	sub    eax,0x1
   2768b:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   2768e:	85 c0                	test   eax,eax
   27690:	0f 8e 4d 32 00 00    	jle    2a8e3 <JS_CallInternal+0x7d43>
   27696:	48 89 4b f0          	mov    QWORD PTR [rbx-0x10],rcx
   2769a:	49 83 c4 01          	add    r12,0x1
   2769e:	4c 89 73 f8          	mov    QWORD PTR [rbx-0x8],r14
   276a2:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   276a8:	49 89 c5             	mov    r13,rax
   276ab:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   276af:	ff e0                	jmp    rax
   276b1:	f3 0f 1e fa          	endbr64
   276b5:	4c 8b 43 f8          	mov    r8,QWORD PTR [rbx-0x8]
   276b9:	48 8b 73 f0          	mov    rsi,QWORD PTR [rbx-0x10]
   276bd:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   276c4:	4c 89 c2             	mov    rdx,r8
   276c7:	e8 54 43 ff ff       	call   1ba20 <js_operator_typeof>
   276cc:	41 89 c5             	mov    r13d,eax
   276cf:	41 83 f8 f6          	cmp    r8d,0xfffffff6
   276d3:	76 11                	jbe    276e6 <JS_CallInternal+0x4b46>
   276d5:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   276d8:	83 e8 01             	sub    eax,0x1
   276db:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   276de:	85 c0                	test   eax,eax
   276e0:	0f 8e ec 31 00 00    	jle    2a8d2 <JS_CallInternal+0x7d32>
   276e6:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   276ed:	44 89 ee             	mov    esi,r13d
   276f0:	ba 01 00 00 00       	mov    edx,0x1
   276f5:	49 83 c4 01          	add    r12,0x1
   276f9:	e8 52 cd 00 00       	call   34450 <__JS_AtomToValue>
   276fe:	48 89 43 f0          	mov    QWORD PTR [rbx-0x10],rax
   27702:	48 89 53 f8          	mov    QWORD PTR [rbx-0x8],rdx
   27706:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   2770c:	49 89 c5             	mov    r13,rax
   2770f:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   27713:	ff e0                	jmp    rax
   27715:	f3 0f 1e fa          	endbr64
   27719:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   27720:	4c 8b 73 f0          	mov    r14,QWORD PTR [rbx-0x10]
   27724:	4c 8b 6b f8          	mov    r13,QWORD PTR [rbx-0x8]
   27728:	48 8b 73 e0          	mov    rsi,QWORD PTR [rbx-0x20]
   2772c:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   27730:	48 8b 53 e8          	mov    rdx,QWORD PTR [rbx-0x18]
   27734:	4c 89 f1             	mov    rcx,r14
   27737:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2773e:	4d 89 e8             	mov    r8,r13
   27741:	48 89 b5 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],rsi
   27748:	48 89 95 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],rdx
   2774f:	e8 1c c1 00 00       	call   33870 <JS_IsInstanceOf>
   27754:	89 c1                	mov    ecx,eax
   27756:	85 c0                	test   eax,eax
   27758:	0f 88 e2 bb ff ff    	js     23340 <JS_CallInternal+0x7a0>
   2775e:	48 8b 95 50 fe ff ff 	mov    rdx,QWORD PTR [rbp-0x1b0]
   27765:	83 fa f6             	cmp    edx,0xfffffff6
   27768:	76 18                	jbe    27782 <JS_CallInternal+0x4be2>
   2776a:	48 8b b5 40 fe ff ff 	mov    rsi,QWORD PTR [rbp-0x1c0]
   27771:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   27774:	83 e8 01             	sub    eax,0x1
   27777:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   2777a:	85 c0                	test   eax,eax
   2777c:	0f 8e 46 46 00 00    	jle    2bdc8 <JS_CallInternal+0x9228>
   27782:	41 83 fd f6          	cmp    r13d,0xfffffff6
   27786:	76 13                	jbe    2779b <JS_CallInternal+0x4bfb>
   27788:	41 8b 46 fc          	mov    eax,DWORD PTR [r14-0x4]
   2778c:	83 e8 01             	sub    eax,0x1
   2778f:	41 89 46 fc          	mov    DWORD PTR [r14-0x4],eax
   27793:	85 c0                	test   eax,eax
   27795:	0f 8e 4e 46 00 00    	jle    2bde9 <JS_CallInternal+0x9249>
   2779b:	31 c0                	xor    eax,eax
   2779d:	85 c9                	test   ecx,ecx
   2779f:	48 c7 43 e8 01 00 00 	mov    QWORD PTR [rbx-0x18],0x1
   277a6:	00 
   277a7:	0f 95 c0             	setne  al
   277aa:	48 83 eb 10          	sub    rbx,0x10
   277ae:	49 83 c4 01          	add    r12,0x1
   277b2:	48 89 43 f0          	mov    QWORD PTR [rbx-0x10],rax
   277b6:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   277bc:	49 89 c5             	mov    r13,rax
   277bf:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   277c3:	ff e0                	jmp    rax
   277c5:	f3 0f 1e fa          	endbr64
   277c9:	48 8b 53 e0          	mov    rdx,QWORD PTR [rbx-0x20]
   277cd:	4c 8b 4b e8          	mov    r9,QWORD PTR [rbx-0x18]
   277d1:	4c 8b 6b f0          	mov    r13,QWORD PTR [rbx-0x10]
   277d5:	4c 8b 73 f8          	mov    r14,QWORD PTR [rbx-0x8]
   277d9:	48 89 d7             	mov    rdi,rdx
   277dc:	45 85 c9             	test   r9d,r9d
   277df:	0f 85 62 38 00 00    	jne    2b047 <JS_CallInternal+0x84a7>
   277e5:	45 85 f6             	test   r14d,r14d
   277e8:	0f 85 92 1f 00 00    	jne    29780 <JS_CallInternal+0x6be0>
   277ee:	31 c0                	xor    eax,eax
   277f0:	44 39 ea             	cmp    edx,r13d
   277f3:	0f 95 c0             	setne  al
   277f6:	48 89 43 e0          	mov    QWORD PTR [rbx-0x20],rax
   277fa:	49 83 c4 01          	add    r12,0x1
   277fe:	48 83 eb 10          	sub    rbx,0x10
   27802:	48 c7 43 f8 01 00 00 	mov    QWORD PTR [rbx-0x8],0x1
   27809:	00 
   2780a:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   27810:	49 89 c5             	mov    r13,rax
   27813:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   27817:	ff e0                	jmp    rax
   27819:	f3 0f 1e fa          	endbr64
   2781d:	48 8b 53 e0          	mov    rdx,QWORD PTR [rbx-0x20]
   27821:	4c 8b 43 e8          	mov    r8,QWORD PTR [rbx-0x18]
   27825:	4c 8b 6b f0          	mov    r13,QWORD PTR [rbx-0x10]
   27829:	4c 8b 73 f8          	mov    r14,QWORD PTR [rbx-0x8]
   2782d:	48 89 d7             	mov    rdi,rdx
   27830:	45 85 c0             	test   r8d,r8d
   27833:	0f 85 b5 3f 00 00    	jne    2b7ee <JS_CallInternal+0x8c4e>
   27839:	45 85 f6             	test   r14d,r14d
   2783c:	0f 85 96 1f 00 00    	jne    297d8 <JS_CallInternal+0x6c38>
   27842:	31 c0                	xor    eax,eax
   27844:	44 39 ea             	cmp    edx,r13d
   27847:	0f 94 c0             	sete   al
   2784a:	48 89 43 e0          	mov    QWORD PTR [rbx-0x20],rax
   2784e:	49 83 c4 01          	add    r12,0x1
   27852:	48 83 eb 10          	sub    rbx,0x10
   27856:	48 c7 43 f8 01 00 00 	mov    QWORD PTR [rbx-0x8],0x1
   2785d:	00 
   2785e:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   27864:	49 89 c5             	mov    r13,rax
   27867:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   2786b:	ff e0                	jmp    rax
   2786d:	f3 0f 1e fa          	endbr64
   27871:	48 8b 4b f8          	mov    rcx,QWORD PTR [rbx-0x8]
   27875:	48 8b 73 e8          	mov    rsi,QWORD PTR [rbx-0x18]
   27879:	48 8b 43 e0          	mov    rax,QWORD PTR [rbx-0x20]
   2787d:	48 8b 53 f0          	mov    rdx,QWORD PTR [rbx-0x10]
   27881:	89 cf                	mov    edi,ecx
   27883:	09 f7                	or     edi,esi
   27885:	0f 85 9a 3c 00 00    	jne    2b525 <JS_CallInternal+0x8985>
   2788b:	39 d0                	cmp    eax,edx
   2788d:	48 c7 43 e8 01 00 00 	mov    QWORD PTR [rbx-0x18],0x1
   27894:	00 
   27895:	0f 9c c0             	setl   al
   27898:	48 83 eb 10          	sub    rbx,0x10
   2789c:	0f b6 c0             	movzx  eax,al
   2789f:	48 89 43 f0          	mov    QWORD PTR [rbx-0x10],rax
   278a3:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   278a8:	49 83 c4 01          	add    r12,0x1
   278ac:	49 89 c5             	mov    r13,rax
   278af:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   278b3:	ff e0                	jmp    rax
   278b5:	f3 0f 1e fa          	endbr64
   278b9:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   278c0:	48 8b 73 e0          	mov    rsi,QWORD PTR [rbx-0x20]
   278c4:	48 8b 53 e8          	mov    rdx,QWORD PTR [rbx-0x18]
   278c8:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   278cf:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   278d3:	48 8d 43 e0          	lea    rax,[rbx-0x20]
   278d7:	48 89 85 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],rax
   278de:	e8 ed c5 01 00       	call   43ed0 <JS_ValueToAtom>
   278e3:	41 89 c5             	mov    r13d,eax
   278e6:	45 85 ed             	test   r13d,r13d
   278e9:	0f 84 51 ba ff ff    	je     23340 <JS_CallInternal+0x7a0>
   278ef:	83 7b d8 03          	cmp    DWORD PTR [rbx-0x28],0x3
   278f3:	0f 84 f5 36 00 00    	je     2afee <JS_CallInternal+0x844e>
   278f9:	48 8b 73 d0          	mov    rsi,QWORD PTR [rbx-0x30]
   278fd:	48 8b 53 d8          	mov    rdx,QWORD PTR [rbx-0x28]
   27901:	44 89 e9             	mov    ecx,r13d
   27904:	4c 8d 73 d0          	lea    r14,[rbx-0x30]
   27908:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2790f:	e8 ec 6c 04 00       	call   6e600 <JS_HasProperty>
   27914:	85 c0                	test   eax,eax
   27916:	0f 8e 02 36 00 00    	jle    2af1e <JS_CallInternal+0x837e>
   2791c:	48 83 ec 08          	sub    rsp,0x8
   27920:	4c 8b 43 f0          	mov    r8,QWORD PTR [rbx-0x10]
   27924:	4c 8b 4b f8          	mov    r9,QWORD PTR [rbx-0x8]
   27928:	44 89 e9             	mov    ecx,r13d
   2792b:	49 8b 36             	mov    rsi,QWORD PTR [r14]
   2792e:	49 8b 56 08          	mov    rdx,QWORD PTR [r14+0x8]
   27932:	68 00 80 00 00       	push   0x8000
   27937:	41 ff 76 08          	push   QWORD PTR [r14+0x8]
   2793b:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   27942:	41 ff 36             	push   QWORD PTR [r14]
   27945:	e8 f6 65 00 00       	call   2df40 <JS_SetPropertyInternal>
   2794a:	48 83 c4 20          	add    rsp,0x20
   2794e:	89 c3                	mov    ebx,eax
   27950:	41 81 fd f2 00 00 00 	cmp    r13d,0xf2
   27957:	0f 8f 44 28 00 00    	jg     2a1a1 <JS_CallInternal+0x7601>
   2795d:	48 8b 85 50 fe ff ff 	mov    rax,QWORD PTR [rbp-0x1b0]
   27964:	48 8b 50 08          	mov    rdx,QWORD PTR [rax+0x8]
   27968:	48 8b 30             	mov    rsi,QWORD PTR [rax]
   2796b:	83 fa f6             	cmp    edx,0xfffffff6
   2796e:	76 11                	jbe    27981 <JS_CallInternal+0x4de1>
   27970:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   27973:	83 e8 01             	sub    eax,0x1
   27976:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   27979:	85 c0                	test   eax,eax
   2797b:	0f 8e 58 36 00 00    	jle    2afd9 <JS_CallInternal+0x8439>
   27981:	49 8b 56 08          	mov    rdx,QWORD PTR [r14+0x8]
   27985:	49 8b 36             	mov    rsi,QWORD PTR [r14]
   27988:	83 fa f6             	cmp    edx,0xfffffff6
   2798b:	76 11                	jbe    2799e <JS_CallInternal+0x4dfe>
   2798d:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   27990:	83 e8 01             	sub    eax,0x1
   27993:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   27996:	85 c0                	test   eax,eax
   27998:	0f 8e e2 35 00 00    	jle    2af80 <JS_CallInternal+0x83e0>
   2799e:	85 db                	test   ebx,ebx
   279a0:	0f 88 62 43 00 00    	js     2bd08 <JS_CallInternal+0x9168>
   279a6:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   279ab:	4c 89 f3             	mov    rbx,r14
   279ae:	49 83 c4 01          	add    r12,0x1
   279b2:	49 89 c5             	mov    r13,rax
   279b5:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   279b9:	ff e0                	jmp    rax
   279bb:	f3 0f 1e fa          	endbr64
   279bf:	48 8b 53 f8          	mov    rdx,QWORD PTR [rbx-0x8]
   279c3:	0b 53 e8             	or     edx,DWORD PTR [rbx-0x18]
   279c6:	48 8b 43 e0          	mov    rax,QWORD PTR [rbx-0x20]
   279ca:	48 8b 4b f0          	mov    rcx,QWORD PTR [rbx-0x10]
   279ce:	0f 85 bb 3e 00 00    	jne    2b88f <JS_CallInternal+0x8cef>
   279d4:	09 c8                	or     eax,ecx
   279d6:	48 c7 43 e8 00 00 00 	mov    QWORD PTR [rbx-0x18],0x0
   279dd:	00 
   279de:	48 83 eb 10          	sub    rbx,0x10
   279e2:	48 89 43 f0          	mov    QWORD PTR [rbx-0x10],rax
   279e6:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   279eb:	49 83 c4 01          	add    r12,0x1
   279ef:	49 89 c5             	mov    r13,rax
   279f2:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   279f6:	ff e0                	jmp    rax
   279f8:	f3 0f 1e fa          	endbr64
   279fc:	48 8b 4b f0          	mov    rcx,QWORD PTR [rbx-0x10]
   27a00:	83 7b f8 03          	cmp    DWORD PTR [rbx-0x8],0x3
   27a04:	4d 8d 6c 24 04       	lea    r13,[r12+0x4]
   27a09:	48 8b 53 f8          	mov    rdx,QWORD PTR [rbx-0x8]
   27a0d:	48 89 c8             	mov    rax,rcx
   27a10:	0f 87 0f 23 00 00    	ja     29d25 <JS_CallInternal+0x7185>
   27a16:	48 83 eb 10          	sub    rbx,0x10
   27a1a:	85 c0                	test   eax,eax
   27a1c:	75 0c                	jne    27a2a <JS_CallInternal+0x4e8a>
   27a1e:	41 8b 04 24          	mov    eax,DWORD PTR [r12]
   27a22:	83 e8 04             	sub    eax,0x4
   27a25:	48 98                	cdqe
   27a27:	49 01 c5             	add    r13,rax
   27a2a:	48 8b 8d e8 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x118]
   27a31:	8b 81 a8 01 00 00    	mov    eax,DWORD PTR [rcx+0x1a8]
   27a37:	89 85 50 fe ff ff    	mov    DWORD PTR [rbp-0x1b0],eax
   27a3d:	83 e8 01             	sub    eax,0x1
   27a40:	89 81 a8 01 00 00    	mov    DWORD PTR [rcx+0x1a8],eax
   27a46:	85 c0                	test   eax,eax
   27a48:	0f 8e b7 41 00 00    	jle    2bc05 <JS_CallInternal+0x9065>
   27a4e:	41 0f b6 45 00       	movzx  eax,BYTE PTR [r13+0x0]
   27a53:	4d 8d 65 01          	lea    r12,[r13+0x1]
   27a57:	49 89 c5             	mov    r13,rax
   27a5a:	41 ff 24 c7          	jmp    QWORD PTR [r15+rax*8]
   27a5e:	f3 0f 1e fa          	endbr64
   27a62:	4c 8b 73 e8          	mov    r14,QWORD PTR [rbx-0x18]
   27a66:	41 8b 0c 24          	mov    ecx,DWORD PTR [r12]
   27a6a:	4d 8d 54 24 04       	lea    r10,[r12+0x4]
   27a6f:	48 8b 43 e0          	mov    rax,QWORD PTR [rbx-0x20]
   27a73:	48 8b 53 e8          	mov    rdx,QWORD PTR [rbx-0x18]
   27a77:	4c 8b 6b e0          	mov    r13,QWORD PTR [rbx-0x20]
   27a7b:	41 83 fe ff          	cmp    r14d,0xffffffff
   27a7f:	0f 85 bd 20 00 00    	jne    29b42 <JS_CallInternal+0x6fa2>
   27a85:	4d 8b 4d 18          	mov    r9,QWORD PTR [r13+0x18]
   27a89:	41 8b 79 18          	mov    edi,DWORD PTR [r9+0x18]
   27a8d:	89 fe                	mov    esi,edi
   27a8f:	21 ce                	and    esi,ecx
   27a91:	41 8b 74 b1 38       	mov    esi,DWORD PTR [r9+rsi*4+0x38]
   27a96:	48 85 f6             	test   rsi,rsi
   27a99:	0f 84 a3 20 00 00    	je     29b42 <JS_CallInternal+0x6fa2>
   27a9f:	48 8d 3c bd 34 00 00 	lea    rdi,[rdi*4+0x34]
   27aa6:	00 
   27aa7:	4c 8d 04 f7          	lea    r8,[rdi+rsi*8]
   27aab:	4d 01 c8             	add    r8,r9
   27aae:	41 39 48 04          	cmp    DWORD PTR [r8+0x4],ecx
   27ab2:	0f 85 7b 20 00 00    	jne    29b33 <JS_CallInternal+0x6f93>
   27ab8:	49 8b 7d 20          	mov    rdi,QWORD PTR [r13+0x20]
   27abc:	48 c1 e6 04          	shl    rsi,0x4
   27ac0:	48 8d 7c 37 f0       	lea    rdi,[rdi+rsi*1-0x10]
   27ac5:	41 0f b6 70 03       	movzx  esi,BYTE PTR [r8+0x3]
   27aca:	40 c0 ee 02          	shr    sil,0x2
   27ace:	83 e6 3a             	and    esi,0x3a
   27ad1:	40 80 fe 02          	cmp    sil,0x2
   27ad5:	0f 85 67 20 00 00    	jne    29b42 <JS_CallInternal+0x6fa2>
   27adb:	48 8b 57 08          	mov    rdx,QWORD PTR [rdi+0x8]
   27adf:	f3 0f 6f 73 f0       	movdqu xmm6,XMMWORD PTR [rbx-0x10]
   27ae4:	48 8b 37             	mov    rsi,QWORD PTR [rdi]
   27ae7:	0f 11 37             	movups XMMWORD PTR [rdi],xmm6
   27aea:	83 fa f6             	cmp    edx,0xfffffff6
   27aed:	76 11                	jbe    27b00 <JS_CallInternal+0x4f60>
   27aef:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   27af2:	83 e8 01             	sub    eax,0x1
   27af5:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   27af8:	85 c0                	test   eax,eax
   27afa:	0f 8e 73 43 00 00    	jle    2be73 <JS_CallInternal+0x92d3>
   27b00:	41 83 fe f6          	cmp    r14d,0xfffffff6
   27b04:	76 13                	jbe    27b19 <JS_CallInternal+0x4f79>
   27b06:	41 8b 45 fc          	mov    eax,DWORD PTR [r13-0x4]
   27b0a:	83 e8 01             	sub    eax,0x1
   27b0d:	41 89 45 fc          	mov    DWORD PTR [r13-0x4],eax
   27b11:	85 c0                	test   eax,eax
   27b13:	0f 8e 94 42 00 00    	jle    2bdad <JS_CallInternal+0x920d>
   27b19:	48 83 eb 20          	sub    rbx,0x20
   27b1d:	41 0f b6 44 24 04    	movzx  eax,BYTE PTR [r12+0x4]
   27b23:	49 83 c4 05          	add    r12,0x5
   27b27:	49 89 c5             	mov    r13,rax
   27b2a:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   27b2e:	ff e0                	jmp    rax
   27b30:	f3 0f 1e fa          	endbr64
   27b34:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   27b3b:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   27b42:	31 d2                	xor    edx,edx
   27b44:	48 89 de             	mov    rsi,rbx
   27b47:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   27b4b:	e8 70 e3 06 00       	call   95ec0 <js_for_of_start>
   27b50:	85 c0                	test   eax,eax
   27b52:	0f 85 e8 b7 ff ff    	jne    23340 <JS_CallInternal+0x7a0>
   27b58:	48 c7 43 10 00 00 00 	mov    QWORD PTR [rbx+0x10],0x0
   27b5f:	00 
   27b60:	49 83 c4 01          	add    r12,0x1
   27b64:	48 83 c3 20          	add    rbx,0x20
   27b68:	48 c7 43 f8 05 00 00 	mov    QWORD PTR [rbx-0x8],0x5
   27b6f:	00 
   27b70:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   27b76:	49 89 c5             	mov    r13,rax
   27b79:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   27b7d:	ff e0                	jmp    rax
   27b7f:	f3 0f 1e fa          	endbr64
   27b83:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   27b8a:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   27b91:	48 89 de             	mov    rsi,rbx
   27b94:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   27b98:	e8 43 62 04 00       	call   6dde0 <js_for_in_next>
   27b9d:	85 c0                	test   eax,eax
   27b9f:	0f 85 9b b7 ff ff    	jne    23340 <JS_CallInternal+0x7a0>
   27ba5:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   27baa:	48 83 c3 20          	add    rbx,0x20
   27bae:	49 83 c4 01          	add    r12,0x1
   27bb2:	49 89 c5             	mov    r13,rax
   27bb5:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   27bb9:	ff e0                	jmp    rax
   27bbb:	f3 0f 1e fa          	endbr64
   27bbf:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   27bc6:	48 8b 73 f0          	mov    rsi,QWORD PTR [rbx-0x10]
   27bca:	48 8b 53 f8          	mov    rdx,QWORD PTR [rbx-0x8]
   27bce:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   27bd5:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   27bd9:	e8 62 5f 04 00       	call   6db40 <build_for_in_iterator>
   27bde:	48 89 53 f8          	mov    QWORD PTR [rbx-0x8],rdx
   27be2:	83 7b f8 06          	cmp    DWORD PTR [rbx-0x8],0x6
   27be6:	48 89 43 f0          	mov    QWORD PTR [rbx-0x10],rax
   27bea:	0f 84 50 b7 ff ff    	je     23340 <JS_CallInternal+0x7a0>
   27bf0:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   27bf5:	49 83 c4 01          	add    r12,0x1
   27bf9:	49 89 c5             	mov    r13,rax
   27bfc:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   27c00:	ff e0                	jmp    rax
   27c02:	f3 0f 1e fa          	endbr64
   27c06:	44 8b 4b f8          	mov    r9d,DWORD PTR [rbx-0x8]
   27c0a:	48 8b 43 f0          	mov    rax,QWORD PTR [rbx-0x10]
   27c0e:	45 85 c9             	test   r9d,r9d
   27c11:	0f 85 17 28 00 00    	jne    2a42e <JS_CallInternal+0x788e>
   27c17:	48 8b 8d d8 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x128]
   27c1e:	3b 41 20             	cmp    eax,DWORD PTR [rcx+0x20]
   27c21:	0f 83 07 28 00 00    	jae    2a42e <JS_CallInternal+0x788e>
   27c27:	48 8b 8d d8 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x128]
   27c2e:	89 c0                	mov    eax,eax
   27c30:	48 83 eb 10          	sub    rbx,0x10
   27c34:	48 03 41 18          	add    rax,QWORD PTR [rcx+0x18]
   27c38:	4c 8d 60 01          	lea    r12,[rax+0x1]
   27c3c:	0f b6 00             	movzx  eax,BYTE PTR [rax]
   27c3f:	49 89 c5             	mov    r13,rax
   27c42:	41 ff 24 c7          	jmp    QWORD PTR [r15+rax*8]
   27c46:	f3 0f 1e fa          	endbr64
   27c4a:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   27c51:	48 8b 4b d0          	mov    rcx,QWORD PTR [rbx-0x30]
   27c55:	45 31 c9             	xor    r9d,r9d
   27c58:	48 c7 85 f0 fd ff ff 	mov    QWORD PTR [rbp-0x210],0x0
   27c5f:	00 00 00 00 
   27c63:	48 c7 85 f8 fd ff ff 	mov    QWORD PTR [rbp-0x208],0x3
   27c6a:	03 00 00 00 
   27c6e:	4c 8b 43 d8          	mov    r8,QWORD PTR [rbx-0x28]
   27c72:	48 8b 73 e0          	mov    rsi,QWORD PTR [rbx-0x20]
   27c76:	48 8b 53 e8          	mov    rdx,QWORD PTR [rbx-0x18]
   27c7a:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   27c7e:	48 c7 43 f0 00 00 00 	mov    QWORD PTR [rbx-0x10],0x0
   27c85:	00 
   27c86:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   27c8d:	48 c7 43 f8 03 00 00 	mov    QWORD PTR [rbx-0x8],0x3
   27c94:	00 
   27c95:	6a 02                	push   0x2
   27c97:	6a 00                	push   0x0
   27c99:	ff b5 f8 fd ff ff    	push   QWORD PTR [rbp-0x208]
   27c9f:	ff b5 f0 fd ff ff    	push   QWORD PTR [rbp-0x210]
   27ca5:	e8 f6 ae ff ff       	call   22ba0 <JS_CallInternal>
   27caa:	48 83 c4 20          	add    rsp,0x20
   27cae:	83 fa 06             	cmp    edx,0x6
   27cb1:	0f 84 89 b6 ff ff    	je     23340 <JS_CallInternal+0x7a0>
   27cb7:	48 89 03             	mov    QWORD PTR [rbx],rax
   27cba:	49 83 c4 01          	add    r12,0x1
   27cbe:	48 83 c3 10          	add    rbx,0x10
   27cc2:	48 89 53 f8          	mov    QWORD PTR [rbx-0x8],rdx
   27cc6:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   27ccc:	49 89 c5             	mov    r13,rax
   27ccf:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   27cd3:	ff e0                	jmp    rax
   27cd5:	f3 0f 1e fa          	endbr64
   27cd9:	4c 8b 43 e8          	mov    r8,QWORD PTR [rbx-0x18]
   27cdd:	48 8b 4b e0          	mov    rcx,QWORD PTR [rbx-0x20]
   27ce1:	4c 8d 73 f0          	lea    r14,[rbx-0x10]
   27ce5:	41 83 f8 f6          	cmp    r8d,0xfffffff6
   27ce9:	76 04                	jbe    27cef <JS_CallInternal+0x514f>
   27ceb:	83 41 fc 01          	add    DWORD PTR [rcx-0x4],0x1
   27cef:	48 8b 73 d0          	mov    rsi,QWORD PTR [rbx-0x30]
   27cf3:	48 8b 53 d8          	mov    rdx,QWORD PTR [rbx-0x28]
   27cf7:	41 ff 76 08          	push   QWORD PTR [r14+0x8]
   27cfb:	41 b9 07 40 00 00    	mov    r9d,0x4007
   27d01:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   27d08:	41 ff 36             	push   QWORD PTR [r14]
   27d0b:	e8 50 c3 01 00       	call   44060 <JS_DefinePropertyValueValue>
   27d10:	59                   	pop    rcx
   27d11:	5e                   	pop    rsi
   27d12:	85 c0                	test   eax,eax
   27d14:	0f 88 32 3c 00 00    	js     2b94c <JS_CallInternal+0x8dac>
   27d1a:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   27d1f:	4c 89 f3             	mov    rbx,r14
   27d22:	49 83 c4 01          	add    r12,0x1
   27d26:	49 89 c5             	mov    r13,rax
   27d29:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   27d2d:	ff e0                	jmp    rax
   27d2f:	f3 0f 1e fa          	endbr64
   27d33:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   27d3a:	83 7b d8 ff          	cmp    DWORD PTR [rbx-0x28],0xffffffff
   27d3e:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   27d42:	0f 85 05 4e 00 00    	jne    2cb4d <JS_CallInternal+0x9fad>
   27d48:	48 8b 73 e0          	mov    rsi,QWORD PTR [rbx-0x20]
   27d4c:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   27d53:	4c 8d 73 e0          	lea    r14,[rbx-0x20]
   27d57:	49 8b 56 08          	mov    rdx,QWORD PTR [r14+0x8]
   27d5b:	e8 70 c1 01 00       	call   43ed0 <JS_ValueToAtom>
   27d60:	41 89 c5             	mov    r13d,eax
   27d63:	45 85 ed             	test   r13d,r13d
   27d66:	0f 84 d4 b5 ff ff    	je     23340 <JS_CallInternal+0x7a0>
   27d6c:	48 83 ec 08          	sub    rsp,0x8
   27d70:	4c 8d 53 d0          	lea    r10,[rbx-0x30]
   27d74:	48 8d 43 c0          	lea    rax,[rbx-0x40]
   27d78:	4c 8b 43 f0          	mov    r8,QWORD PTR [rbx-0x10]
   27d7c:	4c 89 95 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],r10
   27d83:	4c 8b 4b f8          	mov    r9,QWORD PTR [rbx-0x8]
   27d87:	44 89 e9             	mov    ecx,r13d
   27d8a:	48 8b 73 d0          	mov    rsi,QWORD PTR [rbx-0x30]
   27d8e:	48 8b 53 d8          	mov    rdx,QWORD PTR [rbx-0x28]
   27d92:	48 89 85 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],rax
   27d99:	68 00 80 00 00       	push   0x8000
   27d9e:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   27da5:	ff 73 c8             	push   QWORD PTR [rbx-0x38]
   27da8:	ff 73 c0             	push   QWORD PTR [rbx-0x40]
   27dab:	e8 90 61 00 00       	call   2df40 <JS_SetPropertyInternal>
   27db0:	48 83 c4 20          	add    rsp,0x20
   27db4:	41 81 fd f2 00 00 00 	cmp    r13d,0xf2
   27dbb:	4c 8b 95 40 fe ff ff 	mov    r10,QWORD PTR [rbp-0x1c0]
   27dc2:	89 c3                	mov    ebx,eax
   27dc4:	0f 8f 87 21 00 00    	jg     29f51 <JS_CallInternal+0x73b1>
   27dca:	48 8b 85 50 fe ff ff 	mov    rax,QWORD PTR [rbp-0x1b0]
   27dd1:	48 8b 50 08          	mov    rdx,QWORD PTR [rax+0x8]
   27dd5:	48 8b 30             	mov    rsi,QWORD PTR [rax]
   27dd8:	83 fa f6             	cmp    edx,0xfffffff6
   27ddb:	76 11                	jbe    27dee <JS_CallInternal+0x524e>
   27ddd:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   27de0:	83 e8 01             	sub    eax,0x1
   27de3:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   27de6:	85 c0                	test   eax,eax
   27de8:	0f 8e 54 2d 00 00    	jle    2ab42 <JS_CallInternal+0x7fa2>
   27dee:	49 8b 52 08          	mov    rdx,QWORD PTR [r10+0x8]
   27df2:	49 8b 32             	mov    rsi,QWORD PTR [r10]
   27df5:	83 fa f6             	cmp    edx,0xfffffff6
   27df8:	76 11                	jbe    27e0b <JS_CallInternal+0x526b>
   27dfa:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   27dfd:	83 e8 01             	sub    eax,0x1
   27e00:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   27e03:	85 c0                	test   eax,eax
   27e05:	0f 8e 5a 2d 00 00    	jle    2ab65 <JS_CallInternal+0x7fc5>
   27e0b:	49 8b 56 08          	mov    rdx,QWORD PTR [r14+0x8]
   27e0f:	49 8b 36             	mov    rsi,QWORD PTR [r14]
   27e12:	83 fa f6             	cmp    edx,0xfffffff6
   27e15:	76 11                	jbe    27e28 <JS_CallInternal+0x5288>
   27e17:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   27e1a:	83 e8 01             	sub    eax,0x1
   27e1d:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   27e20:	85 c0                	test   eax,eax
   27e22:	0f 8e 52 2d 00 00    	jle    2ab7a <JS_CallInternal+0x7fda>
   27e28:	85 db                	test   ebx,ebx
   27e2a:	0f 88 ae 4b 00 00    	js     2c9de <JS_CallInternal+0x9e3e>
   27e30:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   27e35:	48 8b 9d 50 fe ff ff 	mov    rbx,QWORD PTR [rbp-0x1b0]
   27e3c:	49 83 c4 01          	add    r12,0x1
   27e40:	49 89 c5             	mov    r13,rax
   27e43:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   27e47:	ff e0                	jmp    rax
   27e49:	f3 0f 1e fa          	endbr64
   27e4d:	48 8b 8d d8 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x128]
   27e54:	41 0f b7 04 24       	movzx  eax,WORD PTR [r12]
   27e59:	0f b7 51 38          	movzx  edx,WORD PTR [rcx+0x38]
   27e5d:	4c 8b 51 28          	mov    r10,QWORD PTR [rcx+0x28]
   27e61:	01 d0                	add    eax,edx
   27e63:	48 98                	cdqe
   27e65:	48 8d 04 40          	lea    rax,[rax+rax*2]
   27e69:	49 8d 04 82          	lea    rax,[r10+rax*4]
   27e6d:	44 0f b7 68 0a       	movzx  r13d,WORD PTR [rax+0xa]
   27e72:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   27e79:	48 8b 48 28          	mov    rcx,QWORD PTR [rax+0x28]
   27e7d:	49 c1 e5 03          	shl    r13,0x3
   27e81:	4c 01 e9             	add    rcx,r13
   27e84:	4c 8b 31             	mov    r14,QWORD PTR [rcx]
   27e87:	4d 85 f6             	test   r14,r14
   27e8a:	74 50                	je     27edc <JS_CallInternal+0x533c>
   27e8c:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   27e93:	48 8b 7f 10          	mov    rdi,QWORD PTR [rdi+0x10]
   27e97:	f6 40 3c 04          	test   BYTE PTR [rax+0x3c],0x4
   27e9b:	0f 85 c7 26 00 00    	jne    2a568 <JS_CallInternal+0x79c8>
   27ea1:	49 8b 56 18          	mov    rdx,QWORD PTR [r14+0x18]
   27ea5:	48 8b 02             	mov    rax,QWORD PTR [rdx]
   27ea8:	48 8b 52 08          	mov    rdx,QWORD PTR [rdx+0x8]
   27eac:	83 fa f6             	cmp    edx,0xfffffff6
   27eaf:	76 04                	jbe    27eb5 <JS_CallInternal+0x5315>
   27eb1:	83 40 fc 01          	add    DWORD PTR [rax-0x4],0x1
   27eb5:	49 8d 7e 20          	lea    rdi,[r14+0x20]
   27eb9:	66 48 0f 6e e0       	movq   xmm4,rax
   27ebe:	49 89 56 28          	mov    QWORD PTR [r14+0x28],rdx
   27ec2:	66 48 0f 6e c7       	movq   xmm0,rdi
   27ec7:	41 c6 46 10 01       	mov    BYTE PTR [r14+0x10],0x1
   27ecc:	66 0f 6c c4          	punpcklqdq xmm0,xmm4
   27ed0:	41 0f 11 46 18       	movups XMMWORD PTR [r14+0x18],xmm0
   27ed5:	48 c7 01 00 00 00 00 	mov    QWORD PTR [rcx],0x0
   27edc:	41 0f b6 44 24 02    	movzx  eax,BYTE PTR [r12+0x2]
   27ee2:	49 83 c4 03          	add    r12,0x3
   27ee6:	49 89 c5             	mov    r13,rax
   27ee9:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   27eed:	ff e0                	jmp    rax
   27eef:	f3 0f 1e fa          	endbr64
   27ef3:	48 8b 4b e0          	mov    rcx,QWORD PTR [rbx-0x20]
   27ef7:	48 8b 73 f0          	mov    rsi,QWORD PTR [rbx-0x10]
   27efb:	49 83 c4 01          	add    r12,0x1
   27eff:	48 8b 53 f8          	mov    rdx,QWORD PTR [rbx-0x8]
   27f03:	4c 8b 43 e8          	mov    r8,QWORD PTR [rbx-0x18]
   27f07:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   27f0e:	e8 dd 62 ff ff       	call   1e1f0 <js_method_set_home_object>
   27f13:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   27f19:	49 89 c5             	mov    r13,rax
   27f1c:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   27f20:	ff e0                	jmp    rax
   27f22:	f3 0f 1e fa          	endbr64
   27f26:	41 8b 0c 24          	mov    ecx,DWORD PTR [r12]
   27f2a:	48 8b 73 f0          	mov    rsi,QWORD PTR [rbx-0x10]
   27f2e:	4d 8d 6c 24 04       	lea    r13,[r12+0x4]
   27f33:	48 8b 53 f8          	mov    rdx,QWORD PTR [rbx-0x8]
   27f37:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   27f3e:	e8 4d ca 00 00       	call   34990 <JS_DefineObjectName.constprop.0>
   27f43:	85 c0                	test   eax,eax
   27f45:	0f 88 70 32 00 00    	js     2b1bb <JS_CallInternal+0x861b>
   27f4b:	41 0f b6 44 24 04    	movzx  eax,BYTE PTR [r12+0x4]
   27f51:	49 83 c4 05          	add    r12,0x5
   27f55:	49 89 c5             	mov    r13,rax
   27f58:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   27f5c:	ff e0                	jmp    rax
   27f5e:	f3 0f 1e fa          	endbr64
   27f62:	48 83 ec 08          	sub    rsp,0x8
   27f66:	41 8b 0c 24          	mov    ecx,DWORD PTR [r12]
   27f6a:	48 8b 73 e0          	mov    rsi,QWORD PTR [rbx-0x20]
   27f6e:	4c 8d 73 f0          	lea    r14,[rbx-0x10]
   27f72:	4c 8b 43 f0          	mov    r8,QWORD PTR [rbx-0x10]
   27f76:	4c 8b 4b f8          	mov    r9,QWORD PTR [rbx-0x8]
   27f7a:	4d 8d 6c 24 04       	lea    r13,[r12+0x4]
   27f7f:	48 8b 53 e8          	mov    rdx,QWORD PTR [rbx-0x18]
   27f83:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   27f8a:	68 07 40 00 00       	push   0x4007
   27f8f:	e8 6c 82 00 00       	call   30200 <JS_DefinePropertyValue>
   27f94:	59                   	pop    rcx
   27f95:	5e                   	pop    rsi
   27f96:	85 c0                	test   eax,eax
   27f98:	0f 88 53 32 00 00    	js     2b1f1 <JS_CallInternal+0x8651>
   27f9e:	41 0f b6 44 24 04    	movzx  eax,BYTE PTR [r12+0x4]
   27fa4:	4c 89 f3             	mov    rbx,r14
   27fa7:	49 83 c4 05          	add    r12,0x5
   27fab:	49 89 c5             	mov    r13,rax
   27fae:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   27fb2:	ff e0                	jmp    rax
   27fb4:	f3 0f 1e fa          	endbr64
   27fb8:	48 8b 4b e0          	mov    rcx,QWORD PTR [rbx-0x20]
   27fbc:	48 8b 73 f0          	mov    rsi,QWORD PTR [rbx-0x10]
   27fc0:	48 8b 53 f8          	mov    rdx,QWORD PTR [rbx-0x8]
   27fc4:	4c 8b 43 e8          	mov    r8,QWORD PTR [rbx-0x18]
   27fc8:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   27fcf:	e8 7c c2 01 00       	call   44250 <JS_DefineObjectNameComputed.constprop.0>
   27fd4:	85 c0                	test   eax,eax
   27fd6:	0f 88 64 b3 ff ff    	js     23340 <JS_CallInternal+0x7a0>
   27fdc:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   27fe1:	49 83 c4 01          	add    r12,0x1
   27fe5:	49 89 c5             	mov    r13,rax
   27fe8:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   27fec:	ff e0                	jmp    rax
   27fee:	f3 0f 1e fa          	endbr64
   27ff2:	48 8d 43 e0          	lea    rax,[rbx-0x20]
   27ff6:	83 7b e8 ff          	cmp    DWORD PTR [rbx-0x18],0xffffffff
   27ffa:	4c 8d 73 f0          	lea    r14,[rbx-0x10]
   27ffe:	4c 8b 43 e0          	mov    r8,QWORD PTR [rbx-0x20]
   28002:	4c 8b 6b f0          	mov    r13,QWORD PTR [rbx-0x10]
   28006:	4d 8b 4e 08          	mov    r9,QWORD PTR [r14+0x8]
   2800a:	48 89 85 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],rax
   28011:	0f 85 1c 32 00 00    	jne    2b233 <JS_CallInternal+0x8693>
   28017:	41 83 f9 f8          	cmp    r9d,0xfffffff8
   2801b:	0f 85 89 32 00 00    	jne    2b2aa <JS_CallInternal+0x870a>
   28021:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   28028:	4c 89 ee             	mov    rsi,r13
   2802b:	4c 89 85 38 fe ff ff 	mov    QWORD PTR [rbp-0x1c8],r8
   28032:	4c 89 8d 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],r9
   28039:	48 8b 40 10          	mov    rax,QWORD PTR [rax+0x10]
   2803d:	48 89 c7             	mov    rdi,rax
   28040:	48 89 85 28 fe ff ff 	mov    QWORD PTR [rbp-0x1d8],rax
   28047:	e8 64 eb fe ff       	call   16bb0 <js_get_atom_index>
   2804c:	4c 8b 85 38 fe ff ff 	mov    r8,QWORD PTR [rbp-0x1c8]
   28053:	89 c2                	mov    edx,eax
   28055:	49 8b 70 18          	mov    rsi,QWORD PTR [r8+0x18]
   28059:	8b 4e 18             	mov    ecx,DWORD PTR [rsi+0x18]
   2805c:	21 c8                	and    eax,ecx
   2805e:	8b 44 86 38          	mov    eax,DWORD PTR [rsi+rax*4+0x38]
   28062:	48 85 c0             	test   rax,rax
   28065:	0f 84 c7 3d 00 00    	je     2be32 <JS_CallInternal+0x9292>
   2806b:	4c 8b 8d 40 fe ff ff 	mov    r9,QWORD PTR [rbp-0x1c0]
   28072:	48 8d 3c 8d 34 00 00 	lea    rdi,[rcx*4+0x34]
   28079:	00 
   2807a:	48 8d 0c c7          	lea    rcx,[rdi+rax*8]
   2807e:	48 01 f1             	add    rcx,rsi
   28081:	3b 51 04             	cmp    edx,DWORD PTR [rcx+0x4]
   28084:	0f 85 9b 3d 00 00    	jne    2be25 <JS_CallInternal+0x9285>
   2808a:	49 8b 50 20          	mov    rdx,QWORD PTR [r8+0x20]
   2808e:	48 c1 e0 04          	shl    rax,0x4
   28092:	48 8d 44 02 f0       	lea    rax,[rdx+rax*1-0x10]
   28097:	48 8b 10             	mov    rdx,QWORD PTR [rax]
   2809a:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
   2809e:	83 f8 f6             	cmp    eax,0xfffffff6
   280a1:	76 04                	jbe    280a7 <JS_CallInternal+0x5507>
   280a3:	83 42 fc 01          	add    DWORD PTR [rdx-0x4],0x1
   280a7:	48 89 d1             	mov    rcx,rdx
   280aa:	41 89 c0             	mov    r8d,eax
   280ad:	41 83 f9 f6          	cmp    r9d,0xfffffff6
   280b1:	76 13                	jbe    280c6 <JS_CallInternal+0x5526>
   280b3:	41 8b 7d fc          	mov    edi,DWORD PTR [r13-0x4]
   280b7:	8d 57 ff             	lea    edx,[rdi-0x1]
   280ba:	41 89 55 fc          	mov    DWORD PTR [r13-0x4],edx
   280be:	85 d2                	test   edx,edx
   280c0:	0f 8e 20 25 00 00    	jle    2a5e6 <JS_CallInternal+0x7a46>
   280c6:	48 8b bd 50 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x1b0]
   280cd:	48 8b 57 08          	mov    rdx,QWORD PTR [rdi+0x8]
   280d1:	48 8b 37             	mov    rsi,QWORD PTR [rdi]
   280d4:	83 fa f6             	cmp    edx,0xfffffff6
   280d7:	76 11                	jbe    280ea <JS_CallInternal+0x554a>
   280d9:	8b 7e fc             	mov    edi,DWORD PTR [rsi-0x4]
   280dc:	83 ef 01             	sub    edi,0x1
   280df:	89 7e fc             	mov    DWORD PTR [rsi-0x4],edi
   280e2:	85 ff                	test   edi,edi
   280e4:	0f 8e 41 25 00 00    	jle    2a62b <JS_CallInternal+0x7a8b>
   280ea:	48 89 4b e0          	mov    QWORD PTR [rbx-0x20],rcx
   280ee:	48 89 43 e8          	mov    QWORD PTR [rbx-0x18],rax
   280f2:	4c 89 f3             	mov    rbx,r14
   280f5:	41 83 f8 06          	cmp    r8d,0x6
   280f9:	0f 84 41 b2 ff ff    	je     23340 <JS_CallInternal+0x7a0>
   280ff:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   28104:	49 83 c4 01          	add    r12,0x1
   28108:	49 89 c5             	mov    r13,rax
   2810b:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   2810f:	ff e0                	jmp    rax
   28111:	f3 0f 1e fa          	endbr64
   28115:	41 8b 34 24          	mov    esi,DWORD PTR [r12]
   28119:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   28120:	4d 8d 6c 24 04       	lea    r13,[r12+0x4]
   28125:	e8 46 be 00 00       	call   33f70 <JS_NewSymbolFromAtom.constprop.0>
   2812a:	83 fa 06             	cmp    edx,0x6
   2812d:	0f 84 6f 31 00 00    	je     2b2a2 <JS_CallInternal+0x8702>
   28133:	48 89 03             	mov    QWORD PTR [rbx],rax
   28136:	49 83 c4 05          	add    r12,0x5
   2813a:	48 83 c3 10          	add    rbx,0x10
   2813e:	48 89 53 f8          	mov    QWORD PTR [rbx-0x8],rdx
   28142:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   28148:	49 89 c5             	mov    r13,rax
   2814b:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   2814f:	ff e0                	jmp    rax
   28151:	f3 0f 1e fa          	endbr64
   28155:	48 8d 43 e0          	lea    rax,[rbx-0x20]
   28159:	4c 8d 73 f0          	lea    r14,[rbx-0x10]
   2815d:	4c 8b 28             	mov    r13,QWORD PTR [rax]
   28160:	48 83 eb 30          	sub    rbx,0x30
   28164:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
   28168:	83 7b 08 ff          	cmp    DWORD PTR [rbx+0x8],0xffffffff
   2816c:	48 8b 13             	mov    rdx,QWORD PTR [rbx]
   2816f:	49 8b 36             	mov    rsi,QWORD PTR [r14]
   28172:	48 89 85 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],rax
   28179:	49 8b 4e 08          	mov    rcx,QWORD PTR [r14+0x8]
   2817d:	0f 85 09 36 00 00    	jne    2b78c <JS_CallInternal+0x8bec>
   28183:	83 f9 f8             	cmp    ecx,0xfffffff8
   28186:	0f 85 c4 35 00 00    	jne    2b750 <JS_CallInternal+0x8bb0>
   2818c:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   28193:	48 89 95 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],rdx
   2819a:	48 8b 40 10          	mov    rax,QWORD PTR [rax+0x10]
   2819e:	48 89 c7             	mov    rdi,rax
   281a1:	48 89 85 38 fe ff ff 	mov    QWORD PTR [rbp-0x1c8],rax
   281a8:	e8 03 ea fe ff       	call   16bb0 <js_get_atom_index>
   281ad:	48 8b 95 40 fe ff ff 	mov    rdx,QWORD PTR [rbp-0x1c0]
   281b4:	89 c6                	mov    esi,eax
   281b6:	48 8b 7a 18          	mov    rdi,QWORD PTR [rdx+0x18]
   281ba:	8b 4f 18             	mov    ecx,DWORD PTR [rdi+0x18]
   281bd:	21 c8                	and    eax,ecx
   281bf:	8b 44 87 38          	mov    eax,DWORD PTR [rdi+rax*4+0x38]
   281c3:	48 85 c0             	test   rax,rax
   281c6:	0f 84 c9 3c 00 00    	je     2be95 <JS_CallInternal+0x92f5>
   281cc:	4c 8d 04 8d 34 00 00 	lea    r8,[rcx*4+0x34]
   281d3:	00 
   281d4:	49 8d 0c c0          	lea    rcx,[r8+rax*8]
   281d8:	48 01 f9             	add    rcx,rdi
   281db:	3b 71 04             	cmp    esi,DWORD PTR [rcx+0x4]
   281de:	0f 85 a4 3c 00 00    	jne    2be88 <JS_CallInternal+0x92e8>
   281e4:	48 8b 52 20          	mov    rdx,QWORD PTR [rdx+0x20]
   281e8:	48 c1 e0 04          	shl    rax,0x4
   281ec:	48 8b 8d 50 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x1b0]
   281f3:	48 8d 44 02 f0       	lea    rax,[rdx+rax*1-0x10]
   281f8:	48 8b 50 08          	mov    rdx,QWORD PTR [rax+0x8]
   281fc:	48 8b 30             	mov    rsi,QWORD PTR [rax]
   281ff:	48 89 48 08          	mov    QWORD PTR [rax+0x8],rcx
   28203:	4c 89 28             	mov    QWORD PTR [rax],r13
   28206:	83 fa f6             	cmp    edx,0xfffffff6
   28209:	76 11                	jbe    2821c <JS_CallInternal+0x567c>
   2820b:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   2820e:	83 e8 01             	sub    eax,0x1
   28211:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   28214:	85 c0                	test   eax,eax
   28216:	0f 8e 87 35 00 00    	jle    2b7a3 <JS_CallInternal+0x8c03>
   2821c:	45 31 ed             	xor    r13d,r13d
   2821f:	48 8b 53 08          	mov    rdx,QWORD PTR [rbx+0x8]
   28223:	48 8b 33             	mov    rsi,QWORD PTR [rbx]
   28226:	83 fa f6             	cmp    edx,0xfffffff6
   28229:	76 11                	jbe    2823c <JS_CallInternal+0x569c>
   2822b:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   2822e:	83 e8 01             	sub    eax,0x1
   28231:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   28234:	85 c0                	test   eax,eax
   28236:	0f 8e 85 24 00 00    	jle    2a6c1 <JS_CallInternal+0x7b21>
   2823c:	49 8b 56 08          	mov    rdx,QWORD PTR [r14+0x8]
   28240:	49 8b 36             	mov    rsi,QWORD PTR [r14]
   28243:	83 fa f6             	cmp    edx,0xfffffff6
   28246:	76 11                	jbe    28259 <JS_CallInternal+0x56b9>
   28248:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   2824b:	83 e8 01             	sub    eax,0x1
   2824e:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   28251:	85 c0                	test   eax,eax
   28253:	0f 8e 35 25 00 00    	jle    2a78e <JS_CallInternal+0x7bee>
   28259:	41 83 fd ff          	cmp    r13d,0xffffffff
   2825d:	0f 84 dd b0 ff ff    	je     23340 <JS_CallInternal+0x7a0>
   28263:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   28268:	49 83 c4 01          	add    r12,0x1
   2826c:	49 89 c5             	mov    r13,rax
   2826f:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   28273:	ff e0                	jmp    rax
   28275:	f3 0f 1e fa          	endbr64
   28279:	48 8b 7b f8          	mov    rdi,QWORD PTR [rbx-0x8]
   2827d:	41 8b 34 24          	mov    esi,DWORD PTR [r12]
   28281:	4d 8d 6c 24 04       	lea    r13,[r12+0x4]
   28286:	4c 8b 53 f0          	mov    r10,QWORD PTR [rbx-0x10]
   2828a:	83 ff ff             	cmp    edi,0xffffffff
   2828d:	0f 85 45 11 00 00    	jne    293d8 <JS_CallInternal+0x6838>
   28293:	4c 89 d1             	mov    rcx,r10
   28296:	66 2e 0f 1f 84 00 00 	cs nop WORD PTR [rax+rax*1+0x0]
   2829d:	00 00 00 
   282a0:	48 8b 51 18          	mov    rdx,QWORD PTR [rcx+0x18]
   282a4:	8b 42 18             	mov    eax,DWORD PTR [rdx+0x18]
   282a7:	41 89 c0             	mov    r8d,eax
   282aa:	41 21 f0             	and    r8d,esi
   282ad:	46 8b 44 82 38       	mov    r8d,DWORD PTR [rdx+r8*4+0x38]
   282b2:	4d 85 c0             	test   r8,r8
   282b5:	0f 84 c0 0b 00 00    	je     28e7b <JS_CallInternal+0x62db>
   282bb:	4c 8d 0c 85 34 00 00 	lea    r9,[rax*4+0x34]
   282c2:	00 
   282c3:	4b 8d 04 c1          	lea    rax,[r9+r8*8]
   282c7:	48 01 d0             	add    rax,rdx
   282ca:	39 70 04             	cmp    DWORD PTR [rax+0x4],esi
   282cd:	0f 85 98 0b 00 00    	jne    28e6b <JS_CallInternal+0x62cb>
   282d3:	80 78 03 3f          	cmp    BYTE PTR [rax+0x3],0x3f
   282d7:	0f 87 fb 10 00 00    	ja     293d8 <JS_CallInternal+0x6838>
   282dd:	48 8b 41 20          	mov    rax,QWORD PTR [rcx+0x20]
   282e1:	49 c1 e0 04          	shl    r8,0x4
   282e5:	4a 8d 54 00 f0       	lea    rdx,[rax+r8*1-0x10]
   282ea:	48 8b 02             	mov    rax,QWORD PTR [rdx]
   282ed:	48 8b 52 08          	mov    rdx,QWORD PTR [rdx+0x8]
   282f1:	83 fa f6             	cmp    edx,0xfffffff6
   282f4:	76 04                	jbe    282fa <JS_CallInternal+0x575a>
   282f6:	83 40 fc 01          	add    DWORD PTR [rax-0x4],0x1
   282fa:	48 89 03             	mov    QWORD PTR [rbx],rax
   282fd:	49 83 c4 05          	add    r12,0x5
   28301:	48 83 c3 10          	add    rbx,0x10
   28305:	48 89 53 f8          	mov    QWORD PTR [rbx-0x8],rdx
   28309:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   2830f:	49 89 c5             	mov    r13,rax
   28312:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   28316:	ff e0                	jmp    rax
   28318:	f3 0f 1e fa          	endbr64
   2831c:	48 8b 7b f8          	mov    rdi,QWORD PTR [rbx-0x8]
   28320:	41 8b 34 24          	mov    esi,DWORD PTR [r12]
   28324:	4d 8d 74 24 04       	lea    r14,[r12+0x4]
   28329:	4c 8b 53 f0          	mov    r10,QWORD PTR [rbx-0x10]
   2832d:	83 ff ff             	cmp    edi,0xffffffff
   28330:	0f 85 54 11 00 00    	jne    2948a <JS_CallInternal+0x68ea>
   28336:	4c 89 d1             	mov    rcx,r10
   28339:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]
   28340:	48 8b 51 18          	mov    rdx,QWORD PTR [rcx+0x18]
   28344:	8b 42 18             	mov    eax,DWORD PTR [rdx+0x18]
   28347:	41 89 c0             	mov    r8d,eax
   2834a:	41 21 f0             	and    r8d,esi
   2834d:	46 8b 44 82 38       	mov    r8d,DWORD PTR [rdx+r8*4+0x38]
   28352:	4d 85 c0             	test   r8,r8
   28355:	0f 84 53 0b 00 00    	je     28eae <JS_CallInternal+0x630e>
   2835b:	4c 8d 0c 85 34 00 00 	lea    r9,[rax*4+0x34]
   28362:	00 
   28363:	4b 8d 04 c1          	lea    rax,[r9+r8*8]
   28367:	48 01 d0             	add    rax,rdx
   2836a:	39 70 04             	cmp    DWORD PTR [rax+0x4],esi
   2836d:	0f 85 2b 0b 00 00    	jne    28e9e <JS_CallInternal+0x62fe>
   28373:	80 78 03 3f          	cmp    BYTE PTR [rax+0x3],0x3f
   28377:	0f 87 0d 11 00 00    	ja     2948a <JS_CallInternal+0x68ea>
   2837d:	48 8b 41 20          	mov    rax,QWORD PTR [rcx+0x20]
   28381:	49 c1 e0 04          	shl    r8,0x4
   28385:	4a 8d 54 00 f0       	lea    rdx,[rax+r8*1-0x10]
   2838a:	4c 8b 42 08          	mov    r8,QWORD PTR [rdx+0x8]
   2838e:	48 8b 02             	mov    rax,QWORD PTR [rdx]
   28391:	41 83 f8 f6          	cmp    r8d,0xfffffff6
   28395:	76 04                	jbe    2839b <JS_CallInternal+0x57fb>
   28397:	83 40 fc 01          	add    DWORD PTR [rax-0x4],0x1
   2839b:	4c 8d 6b f0          	lea    r13,[rbx-0x10]
   2839f:	49 8b 55 08          	mov    rdx,QWORD PTR [r13+0x8]
   283a3:	49 8b 75 00          	mov    rsi,QWORD PTR [r13+0x0]
   283a7:	83 fa f6             	cmp    edx,0xfffffff6
   283aa:	76 11                	jbe    283bd <JS_CallInternal+0x581d>
   283ac:	8b 4e fc             	mov    ecx,DWORD PTR [rsi-0x4]
   283af:	83 e9 01             	sub    ecx,0x1
   283b2:	89 4e fc             	mov    DWORD PTR [rsi-0x4],ecx
   283b5:	85 c9                	test   ecx,ecx
   283b7:	0f 8e d3 22 00 00    	jle    2a690 <JS_CallInternal+0x7af0>
   283bd:	48 89 43 f0          	mov    QWORD PTR [rbx-0x10],rax
   283c1:	49 83 c4 05          	add    r12,0x5
   283c5:	4c 89 43 f8          	mov    QWORD PTR [rbx-0x8],r8
   283c9:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   283cf:	49 89 c5             	mov    r13,rax
   283d2:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   283d6:	ff e0                	jmp    rax
   283d8:	f3 0f 1e fa          	endbr64
   283dc:	48 8b 7b f8          	mov    rdi,QWORD PTR [rbx-0x8]
   283e0:	48 8b 73 f0          	mov    rsi,QWORD PTR [rbx-0x10]
   283e4:	83 ff ff             	cmp    edi,0xffffffff
   283e7:	0f 85 99 0f 00 00    	jne    29386 <JS_CallInternal+0x67e6>
   283ed:	48 89 f1             	mov    rcx,rsi
   283f0:	48 8b 51 18          	mov    rdx,QWORD PTR [rcx+0x18]
   283f4:	8b 42 18             	mov    eax,DWORD PTR [rdx+0x18]
   283f7:	41 89 c0             	mov    r8d,eax
   283fa:	41 83 e0 32          	and    r8d,0x32
   283fe:	46 8b 44 82 38       	mov    r8d,DWORD PTR [rdx+r8*4+0x38]
   28403:	4d 85 c0             	test   r8,r8
   28406:	0f 84 37 0a 00 00    	je     28e43 <JS_CallInternal+0x62a3>
   2840c:	4c 8d 0c 85 34 00 00 	lea    r9,[rax*4+0x34]
   28413:	00 
   28414:	4b 8d 04 c1          	lea    rax,[r9+r8*8]
   28418:	48 01 d0             	add    rax,rdx
   2841b:	83 78 04 32          	cmp    DWORD PTR [rax+0x4],0x32
   2841f:	0f 85 0e 0a 00 00    	jne    28e33 <JS_CallInternal+0x6293>
   28425:	80 78 03 3f          	cmp    BYTE PTR [rax+0x3],0x3f
   28429:	0f 87 57 0f 00 00    	ja     29386 <JS_CallInternal+0x67e6>
   2842f:	48 8b 41 20          	mov    rax,QWORD PTR [rcx+0x20]
   28433:	49 c1 e0 04          	shl    r8,0x4
   28437:	4a 8d 44 00 f0       	lea    rax,[rax+r8*1-0x10]
   2843c:	48 8b 48 08          	mov    rcx,QWORD PTR [rax+0x8]
   28440:	4c 8b 30             	mov    r14,QWORD PTR [rax]
   28443:	83 f9 f6             	cmp    ecx,0xfffffff6
   28446:	76 05                	jbe    2844d <JS_CallInternal+0x58ad>
   28448:	41 83 46 fc 01       	add    DWORD PTR [r14-0x4],0x1
   2844d:	4c 8d 6b f0          	lea    r13,[rbx-0x10]
   28451:	49 8b 55 08          	mov    rdx,QWORD PTR [r13+0x8]
   28455:	49 8b 75 00          	mov    rsi,QWORD PTR [r13+0x0]
   28459:	83 fa f6             	cmp    edx,0xfffffff6
   2845c:	76 11                	jbe    2846f <JS_CallInternal+0x58cf>
   2845e:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   28461:	83 e8 01             	sub    eax,0x1
   28464:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   28467:	85 c0                	test   eax,eax
   28469:	0f 8e c7 23 00 00    	jle    2a836 <JS_CallInternal+0x7c96>
   2846f:	4c 89 73 f0          	mov    QWORD PTR [rbx-0x10],r14
   28473:	49 83 c4 01          	add    r12,0x1
   28477:	48 89 4b f8          	mov    QWORD PTR [rbx-0x8],rcx
   2847b:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   28481:	49 89 c5             	mov    r13,rax
   28484:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   28488:	ff e0                	jmp    rax
   2848a:	f3 0f 1e fa          	endbr64
   2848e:	48 8b 43 e8          	mov    rax,QWORD PTR [rbx-0x18]
   28492:	4c 8b 6b f8          	mov    r13,QWORD PTR [rbx-0x8]
   28496:	83 f8 ff             	cmp    eax,0xffffffff
   28499:	0f 85 15 33 00 00    	jne    2b7b4 <JS_CallInternal+0x8c14>
   2849f:	45 85 ed             	test   r13d,r13d
   284a2:	0f 85 e1 1a 00 00    	jne    29f89 <JS_CallInternal+0x73e9>
   284a8:	48 8b 53 e0          	mov    rdx,QWORD PTR [rbx-0x20]
   284ac:	48 8b 43 f0          	mov    rax,QWORD PTR [rbx-0x10]
   284b0:	66 83 7a 12 02       	cmp    WORD PTR [rdx+0x12],0x2
   284b5:	0f 85 33 1b 00 00    	jne    29fee <JS_CallInternal+0x744e>
   284bb:	3b 42 38             	cmp    eax,DWORD PTR [rdx+0x38]
   284be:	0f 83 2a 1b 00 00    	jae    29fee <JS_CallInternal+0x744e>
   284c4:	89 c0                	mov    eax,eax
   284c6:	48 c1 e0 04          	shl    rax,0x4
   284ca:	48 03 42 30          	add    rax,QWORD PTR [rdx+0x30]
   284ce:	48 8b 08             	mov    rcx,QWORD PTR [rax]
   284d1:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
   284d5:	83 f8 f6             	cmp    eax,0xfffffff6
   284d8:	76 04                	jbe    284de <JS_CallInternal+0x593e>
   284da:	83 41 fc 01          	add    DWORD PTR [rcx-0x4],0x1
   284de:	48 89 0b             	mov    QWORD PTR [rbx],rcx
   284e1:	49 83 c4 01          	add    r12,0x1
   284e5:	48 83 c3 10          	add    rbx,0x10
   284e9:	48 89 43 f8          	mov    QWORD PTR [rbx-0x8],rax
   284ed:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   284f3:	49 89 c5             	mov    r13,rax
   284f6:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   284fa:	ff e0                	jmp    rax
   284fc:	f3 0f 1e fa          	endbr64
   28500:	83 7b e8 ff          	cmp    DWORD PTR [rbx-0x18],0xffffffff
   28504:	48 8b 73 e0          	mov    rsi,QWORD PTR [rbx-0x20]
   28508:	48 8b 4b e8          	mov    rcx,QWORD PTR [rbx-0x18]
   2850c:	4c 8b 43 f0          	mov    r8,QWORD PTR [rbx-0x10]
   28510:	48 8b 7b f8          	mov    rdi,QWORD PTR [rbx-0x8]
   28514:	0f 85 56 17 00 00    	jne    29c70 <JS_CallInternal+0x70d0>
   2851a:	85 ff                	test   edi,edi
   2851c:	0f 85 4e 17 00 00    	jne    29c70 <JS_CallInternal+0x70d0>
   28522:	66 83 7e 12 02       	cmp    WORD PTR [rsi+0x12],0x2
   28527:	0f 85 43 17 00 00    	jne    29c70 <JS_CallInternal+0x70d0>
   2852d:	44 3b 46 38          	cmp    r8d,DWORD PTR [rsi+0x38]
   28531:	0f 83 39 17 00 00    	jae    29c70 <JS_CallInternal+0x70d0>
   28537:	44 89 c0             	mov    eax,r8d
   2853a:	48 c1 e0 04          	shl    rax,0x4
   2853e:	48 03 46 30          	add    rax,QWORD PTR [rsi+0x30]
   28542:	48 8b 10             	mov    rdx,QWORD PTR [rax]
   28545:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
   28549:	83 f8 f6             	cmp    eax,0xfffffff6
   2854c:	76 04                	jbe    28552 <JS_CallInternal+0x59b2>
   2854e:	83 42 fc 01          	add    DWORD PTR [rdx-0x4],0x1
   28552:	48 89 53 f0          	mov    QWORD PTR [rbx-0x10],rdx
   28556:	49 83 c4 01          	add    r12,0x1
   2855a:	48 89 43 f8          	mov    QWORD PTR [rbx-0x8],rax
   2855e:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   28564:	49 89 c5             	mov    r13,rax
   28567:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   2856b:	ff e0                	jmp    rax
   2856d:	f3 0f 1e fa          	endbr64
   28571:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   28578:	48 8b 73 f0          	mov    rsi,QWORD PTR [rbx-0x10]
   2857c:	4c 8d 73 f0          	lea    r14,[rbx-0x10]
   28580:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   28587:	49 8b 56 08          	mov    rdx,QWORD PTR [r14+0x8]
   2858b:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   2858f:	e8 3c b9 01 00       	call   43ed0 <JS_ValueToAtom>
   28594:	41 89 c5             	mov    r13d,eax
   28597:	45 85 ed             	test   r13d,r13d
   2859a:	0f 84 a0 ad ff ff    	je     23340 <JS_CallInternal+0x7a0>
   285a0:	48 83 ec 08          	sub    rsp,0x8
   285a4:	4c 8d 53 e0          	lea    r10,[rbx-0x20]
   285a8:	48 8d 43 d0          	lea    rax,[rbx-0x30]
   285ac:	4c 8b 43 d0          	mov    r8,QWORD PTR [rbx-0x30]
   285b0:	4c 89 95 38 fe ff ff 	mov    QWORD PTR [rbp-0x1c8],r10
   285b7:	4c 8b 4b d8          	mov    r9,QWORD PTR [rbx-0x28]
   285bb:	44 89 e9             	mov    ecx,r13d
   285be:	48 8b 73 e0          	mov    rsi,QWORD PTR [rbx-0x20]
   285c2:	48 89 85 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],rax
   285c9:	48 8b 53 e8          	mov    rdx,QWORD PTR [rbx-0x18]
   285cd:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   285d4:	6a 00                	push   0x0
   285d6:	e8 35 4c 00 00       	call   2d210 <JS_GetPropertyInternal>
   285db:	41 81 fd f2 00 00 00 	cmp    r13d,0xf2
   285e2:	4c 8b 95 38 fe ff ff 	mov    r10,QWORD PTR [rbp-0x1c8]
   285e9:	48 89 85 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],rax
   285f0:	48 89 d0             	mov    rax,rdx
   285f3:	5a                   	pop    rdx
   285f4:	59                   	pop    rcx
   285f5:	0f 8f 37 1a 00 00    	jg     2a032 <JS_CallInternal+0x7492>
   285fb:	83 f8 06             	cmp    eax,0x6
   285fe:	0f 84 3c ad ff ff    	je     23340 <JS_CallInternal+0x7a0>
   28604:	49 8b 56 08          	mov    rdx,QWORD PTR [r14+0x8]
   28608:	49 8b 36             	mov    rsi,QWORD PTR [r14]
   2860b:	83 fa f6             	cmp    edx,0xfffffff6
   2860e:	76 11                	jbe    28621 <JS_CallInternal+0x5a81>
   28610:	8b 4e fc             	mov    ecx,DWORD PTR [rsi-0x4]
   28613:	83 e9 01             	sub    ecx,0x1
   28616:	89 4e fc             	mov    DWORD PTR [rsi-0x4],ecx
   28619:	85 c9                	test   ecx,ecx
   2861b:	0f 8e 3b 33 00 00    	jle    2b95c <JS_CallInternal+0x8dbc>
   28621:	49 8b 52 08          	mov    rdx,QWORD PTR [r10+0x8]
   28625:	49 8b 32             	mov    rsi,QWORD PTR [r10]
   28628:	83 fa f6             	cmp    edx,0xfffffff6
   2862b:	76 11                	jbe    2863e <JS_CallInternal+0x5a9e>
   2862d:	8b 4e fc             	mov    ecx,DWORD PTR [rsi-0x4]
   28630:	83 e9 01             	sub    ecx,0x1
   28633:	89 4e fc             	mov    DWORD PTR [rsi-0x4],ecx
   28636:	85 c9                	test   ecx,ecx
   28638:	0f 8e 4f 33 00 00    	jle    2b98d <JS_CallInternal+0x8ded>
   2863e:	48 8b 8d 50 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x1b0]
   28645:	48 8b 51 08          	mov    rdx,QWORD PTR [rcx+0x8]
   28649:	48 8b 31             	mov    rsi,QWORD PTR [rcx]
   2864c:	83 fa f6             	cmp    edx,0xfffffff6
   2864f:	76 11                	jbe    28662 <JS_CallInternal+0x5ac2>
   28651:	8b 4e fc             	mov    ecx,DWORD PTR [rsi-0x4]
   28654:	83 e9 01             	sub    ecx,0x1
   28657:	89 4e fc             	mov    DWORD PTR [rsi-0x4],ecx
   2865a:	85 c9                	test   ecx,ecx
   2865c:	0f 8e 5c 33 00 00    	jle    2b9be <JS_CallInternal+0x8e1e>
   28662:	48 8b 8d 40 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x1c0]
   28669:	48 89 43 d8          	mov    QWORD PTR [rbx-0x28],rax
   2866d:	49 83 c4 01          	add    r12,0x1
   28671:	48 89 4b d0          	mov    QWORD PTR [rbx-0x30],rcx
   28675:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   2867b:	4c 89 d3             	mov    rbx,r10
   2867e:	49 89 c5             	mov    r13,rax
   28681:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   28685:	ff e0                	jmp    rax
   28687:	f3 0f 1e fa          	endbr64
   2868b:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   28692:	48 8b 73 f0          	mov    rsi,QWORD PTR [rbx-0x10]
   28696:	48 8b 53 f8          	mov    rdx,QWORD PTR [rbx-0x8]
   2869a:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   286a1:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   286a5:	e8 26 b8 01 00       	call   43ed0 <JS_ValueToAtom>
   286aa:	41 89 c5             	mov    r13d,eax
   286ad:	45 85 ed             	test   r13d,r13d
   286b0:	0f 84 8a ac ff ff    	je     23340 <JS_CallInternal+0x7a0>
   286b6:	48 8b 53 e8          	mov    rdx,QWORD PTR [rbx-0x18]
   286ba:	83 fa 03             	cmp    edx,0x3
   286bd:	0f 84 e7 33 00 00    	je     2baaa <JS_CallInternal+0x8f0a>
   286c3:	48 8b 73 e0          	mov    rsi,QWORD PTR [rbx-0x20]
   286c7:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   286ce:	44 89 e9             	mov    ecx,r13d
   286d1:	e8 2a 5f 04 00       	call   6e600 <JS_HasProperty>
   286d6:	85 c0                	test   eax,eax
   286d8:	0f 8e 6d 33 00 00    	jle    2ba4b <JS_CallInternal+0x8eab>
   286de:	48 83 ec 08          	sub    rsp,0x8
   286e2:	4c 8b 43 e0          	mov    r8,QWORD PTR [rbx-0x20]
   286e6:	4c 8b 4b e8          	mov    r9,QWORD PTR [rbx-0x18]
   286ea:	44 89 e9             	mov    ecx,r13d
   286ed:	6a 00                	push   0x0
   286ef:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   286f6:	4c 89 c6             	mov    rsi,r8
   286f9:	4c 89 ca             	mov    rdx,r9
   286fc:	e8 0f 4b 00 00       	call   2d210 <JS_GetPropertyInternal>
   28701:	5e                   	pop    rsi
   28702:	5f                   	pop    rdi
   28703:	48 89 c1             	mov    rcx,rax
   28706:	49 89 d6             	mov    r14,rdx
   28709:	48 89 d0             	mov    rax,rdx
   2870c:	41 81 fd f2 00 00 00 	cmp    r13d,0xf2
   28713:	0f 8f 24 1b 00 00    	jg     2a23d <JS_CallInternal+0x769d>
   28719:	41 83 fe 06          	cmp    r14d,0x6
   2871d:	0f 84 1d ac ff ff    	je     23340 <JS_CallInternal+0x7a0>
   28723:	48 89 0b             	mov    QWORD PTR [rbx],rcx
   28726:	49 83 c4 01          	add    r12,0x1
   2872a:	48 83 c3 10          	add    rbx,0x10
   2872e:	48 89 43 f8          	mov    QWORD PTR [rbx-0x8],rax
   28732:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   28738:	49 89 c5             	mov    r13,rax
   2873b:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   2873f:	ff e0                	jmp    rax
   28741:	f3 0f 1e fa          	endbr64
   28745:	83 7b d8 ff          	cmp    DWORD PTR [rbx-0x28],0xffffffff
   28749:	0f 85 af 14 00 00    	jne    29bfe <JS_CallInternal+0x705e>
   2874f:	44 8b 5b e8          	mov    r11d,DWORD PTR [rbx-0x18]
   28753:	45 85 db             	test   r11d,r11d
   28756:	0f 85 a2 14 00 00    	jne    29bfe <JS_CallInternal+0x705e>
   2875c:	48 8b 4b d0          	mov    rcx,QWORD PTR [rbx-0x30]
   28760:	48 8b 43 e0          	mov    rax,QWORD PTR [rbx-0x20]
   28764:	66 83 79 12 02       	cmp    WORD PTR [rcx+0x12],0x2
   28769:	0f 85 8f 14 00 00    	jne    29bfe <JS_CallInternal+0x705e>
   2876f:	8b 51 38             	mov    edx,DWORD PTR [rcx+0x38]
   28772:	39 d0                	cmp    eax,edx
   28774:	0f 83 05 35 00 00    	jae    2bc7f <JS_CallInternal+0x90df>
   2877a:	89 c0                	mov    eax,eax
   2877c:	f3 0f 6f 6b f0       	movdqu xmm5,XMMWORD PTR [rbx-0x10]
   28781:	48 c1 e0 04          	shl    rax,0x4
   28785:	48 03 41 30          	add    rax,QWORD PTR [rcx+0x30]
   28789:	48 8b 50 08          	mov    rdx,QWORD PTR [rax+0x8]
   2878d:	48 8b 30             	mov    rsi,QWORD PTR [rax]
   28790:	0f 11 28             	movups XMMWORD PTR [rax],xmm5
   28793:	83 fa f6             	cmp    edx,0xfffffff6
   28796:	76 11                	jbe    287a9 <JS_CallInternal+0x5c09>
   28798:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   2879b:	83 e8 01             	sub    eax,0x1
   2879e:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   287a1:	85 c0                	test   eax,eax
   287a3:	0f 8e 67 35 00 00    	jle    2bd10 <JS_CallInternal+0x9170>
   287a9:	48 8b 53 d8          	mov    rdx,QWORD PTR [rbx-0x28]
   287ad:	48 83 eb 30          	sub    rbx,0x30
   287b1:	48 8b 33             	mov    rsi,QWORD PTR [rbx]
   287b4:	83 fa f6             	cmp    edx,0xfffffff6
   287b7:	76 11                	jbe    287ca <JS_CallInternal+0x5c2a>
   287b9:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   287bc:	83 e8 01             	sub    eax,0x1
   287bf:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   287c2:	85 c0                	test   eax,eax
   287c4:	0f 8e 46 36 00 00    	jle    2be10 <JS_CallInternal+0x9270>
   287ca:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   287cf:	49 83 c4 01          	add    r12,0x1
   287d3:	49 89 c5             	mov    r13,rax
   287d6:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   287da:	ff e0                	jmp    rax
   287dc:	f3 0f 1e fa          	endbr64
   287e0:	83 7b f8 03          	cmp    DWORD PTR [rbx-0x8],0x3
   287e4:	48 8b 53 f0          	mov    rdx,QWORD PTR [rbx-0x10]
   287e8:	48 8b 43 f8          	mov    rax,QWORD PTR [rbx-0x8]
   287ec:	0f 87 47 15 00 00    	ja     29d39 <JS_CallInternal+0x7199>
   287f2:	31 c0                	xor    eax,eax
   287f4:	85 d2                	test   edx,edx
   287f6:	0f 95 c0             	setne  al
   287f9:	85 c0                	test   eax,eax
   287fb:	48 c7 43 f8 01 00 00 	mov    QWORD PTR [rbx-0x8],0x1
   28802:	00 
   28803:	0f 94 c0             	sete   al
   28806:	49 83 c4 01          	add    r12,0x1
   2880a:	0f b6 c0             	movzx  eax,al
   2880d:	48 89 43 f0          	mov    QWORD PTR [rbx-0x10],rax
   28811:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   28817:	49 89 c5             	mov    r13,rax
   2881a:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   2881e:	ff e0                	jmp    rax
   28820:	f3 0f 1e fa          	endbr64
   28824:	45 0f b6 34 24       	movzx  r14d,BYTE PTR [r12]
   28829:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   28830:	4d 8d 6c 24 01       	lea    r13,[r12+0x1]
   28835:	4c 8b 43 c0          	mov    r8,QWORD PTR [rbx-0x40]
   28839:	4c 8b 4b c8          	mov    r9,QWORD PTR [rbx-0x38]
   2883d:	4c 89 68 30          	mov    QWORD PTR [rax+0x30],r13
   28841:	44 89 f0             	mov    eax,r14d
   28844:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2884b:	83 e0 01             	and    eax,0x1
   2884e:	4c 89 c6             	mov    rsi,r8
   28851:	4c 89 ca             	mov    rdx,r9
   28854:	3c 01                	cmp    al,0x1
   28856:	19 c9                	sbb    ecx,ecx
   28858:	48 83 ec 08          	sub    rsp,0x8
   2885c:	6a 00                	push   0x0
   2885e:	83 e1 ef             	and    ecx,0xffffffef
   28861:	83 c1 17             	add    ecx,0x17
   28864:	e8 a7 49 00 00       	call   2d210 <JS_GetPropertyInternal>
   28869:	59                   	pop    rcx
   2886a:	5e                   	pop    rsi
   2886b:	83 fa 06             	cmp    edx,0x6
   2886e:	0f 84 6a 1d 00 00    	je     2a5de <JS_CallInternal+0x7a3e>
   28874:	8d 72 fe             	lea    esi,[rdx-0x2]
   28877:	b9 01 00 00 00       	mov    ecx,0x1
   2887c:	83 fe 01             	cmp    esi,0x1
   2887f:	0f 87 53 10 00 00    	ja     298d8 <JS_CallInternal+0x6d38>
   28885:	48 89 0b             	mov    QWORD PTR [rbx],rcx
   28888:	49 83 c4 02          	add    r12,0x2
   2888c:	48 83 c3 10          	add    rbx,0x10
   28890:	48 c7 43 f8 01 00 00 	mov    QWORD PTR [rbx-0x8],0x1
   28897:	00 
   28898:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   2889e:	49 89 c5             	mov    r13,rax
   288a1:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   288a5:	ff e0                	jmp    rax
   288a7:	f3 0f 1e fa          	endbr64
   288ab:	48 8b 4b f0          	mov    rcx,QWORD PTR [rbx-0x10]
   288af:	83 7b f8 03          	cmp    DWORD PTR [rbx-0x8],0x3
   288b3:	4d 8d 6c 24 01       	lea    r13,[r12+0x1]
   288b8:	48 8b 53 f8          	mov    rdx,QWORD PTR [rbx-0x8]
   288bc:	48 89 c8             	mov    rax,rcx
   288bf:	0f 87 9f 14 00 00    	ja     29d64 <JS_CallInternal+0x71c4>
   288c5:	48 83 eb 10          	sub    rbx,0x10
   288c9:	85 c0                	test   eax,eax
   288cb:	75 0d                	jne    288da <JS_CallInternal+0x5d3a>
   288cd:	41 0f be 04 24       	movsx  eax,BYTE PTR [r12]
   288d2:	83 e8 01             	sub    eax,0x1
   288d5:	48 98                	cdqe
   288d7:	49 01 c5             	add    r13,rax
   288da:	48 8b 8d e8 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x118]
   288e1:	8b 81 a8 01 00 00    	mov    eax,DWORD PTR [rcx+0x1a8]
   288e7:	89 85 50 fe ff ff    	mov    DWORD PTR [rbp-0x1b0],eax
   288ed:	83 e8 01             	sub    eax,0x1
   288f0:	89 81 a8 01 00 00    	mov    DWORD PTR [rcx+0x1a8],eax
   288f6:	85 c0                	test   eax,eax
   288f8:	0f 8e 05 28 00 00    	jle    2b103 <JS_CallInternal+0x8563>
   288fe:	41 0f b6 45 00       	movzx  eax,BYTE PTR [r13+0x0]
   28903:	4d 8d 65 01          	lea    r12,[r13+0x1]
   28907:	49 89 c5             	mov    r13,rax
   2890a:	41 ff 24 c7          	jmp    QWORD PTR [r15+rax*8]
   2890e:	f3 0f 1e fa          	endbr64
   28912:	48 8b 4b f0          	mov    rcx,QWORD PTR [rbx-0x10]
   28916:	83 7b f8 03          	cmp    DWORD PTR [rbx-0x8],0x3
   2891a:	4d 8d 6c 24 01       	lea    r13,[r12+0x1]
   2891f:	48 8b 53 f8          	mov    rdx,QWORD PTR [rbx-0x8]
   28923:	48 89 c8             	mov    rax,rcx
   28926:	0f 87 24 14 00 00    	ja     29d50 <JS_CallInternal+0x71b0>
   2892c:	48 83 eb 10          	sub    rbx,0x10
   28930:	85 c0                	test   eax,eax
   28932:	74 0d                	je     28941 <JS_CallInternal+0x5da1>
   28934:	41 0f be 04 24       	movsx  eax,BYTE PTR [r12]
   28939:	83 e8 01             	sub    eax,0x1
   2893c:	48 98                	cdqe
   2893e:	49 01 c5             	add    r13,rax
   28941:	48 8b 8d e8 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x118]
   28948:	8b 81 a8 01 00 00    	mov    eax,DWORD PTR [rcx+0x1a8]
   2894e:	89 85 50 fe ff ff    	mov    DWORD PTR [rbp-0x1b0],eax
   28954:	83 e8 01             	sub    eax,0x1
   28957:	89 81 a8 01 00 00    	mov    DWORD PTR [rcx+0x1a8],eax
   2895d:	85 c0                	test   eax,eax
   2895f:	0f 8e 45 2d 00 00    	jle    2b6aa <JS_CallInternal+0x8b0a>
   28965:	41 0f b6 45 00       	movzx  eax,BYTE PTR [r13+0x0]
   2896a:	4d 8d 65 01          	lea    r12,[r13+0x1]
   2896e:	49 89 c5             	mov    r13,rax
   28971:	41 ff 24 c7          	jmp    QWORD PTR [r15+rax*8]
   28975:	f3 0f 1e fa          	endbr64
   28979:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   28980:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   28987:	ba 01 00 00 00       	mov    edx,0x1
   2898c:	48 89 de             	mov    rsi,rbx
   2898f:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   28993:	e8 28 d5 06 00       	call   95ec0 <js_for_of_start>
   28998:	85 c0                	test   eax,eax
   2899a:	0f 85 a0 a9 ff ff    	jne    23340 <JS_CallInternal+0x7a0>
   289a0:	48 c7 43 10 00 00 00 	mov    QWORD PTR [rbx+0x10],0x0
   289a7:	00 
   289a8:	49 83 c4 01          	add    r12,0x1
   289ac:	48 83 c3 20          	add    rbx,0x20
   289b0:	48 c7 43 f8 05 00 00 	mov    QWORD PTR [rbx-0x8],0x5
   289b7:	00 
   289b8:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   289be:	49 89 c5             	mov    r13,rax
   289c1:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   289c5:	ff e0                	jmp    rax
   289c7:	f3 0f 1e fa          	endbr64
   289cb:	e9 e4 a6 ff ff       	jmp    230b4 <JS_CallInternal+0x514>
   289d0:	f3 0f 1e fa          	endbr64
   289d4:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   289db:	4d 8d 6c 24 04       	lea    r13,[r12+0x4]
   289e0:	41 8b 34 24          	mov    esi,DWORD PTR [r12]
   289e4:	48 89 da             	mov    rdx,rbx
   289e7:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   289ee:	4c 89 68 30          	mov    QWORD PTR [rax+0x30],r13
   289f2:	e8 79 5d 04 00       	call   6e770 <JS_GetGlobalVarRef>
   289f7:	85 c0                	test   eax,eax
   289f9:	0f 85 d7 3f 00 00    	jne    2c9d6 <JS_CallInternal+0x9e36>
   289ff:	41 0f b6 44 24 04    	movzx  eax,BYTE PTR [r12+0x4]
   28a05:	48 83 c3 20          	add    rbx,0x20
   28a09:	49 83 c4 05          	add    r12,0x5
   28a0d:	49 89 c5             	mov    r13,rax
   28a10:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   28a14:	ff e0                	jmp    rax
   28a16:	f3 0f 1e fa          	endbr64
   28a1a:	41 0f b7 04 24       	movzx  eax,WORD PTR [r12]
   28a1f:	48 8b 8d b0 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x150]
   28a26:	4d 8d 6c 24 02       	lea    r13,[r12+0x2]
   28a2b:	48 89 c2             	mov    rdx,rax
   28a2e:	48 c1 e0 04          	shl    rax,0x4
   28a32:	48 01 c8             	add    rax,rcx
   28a35:	48 8b 48 08          	mov    rcx,QWORD PTR [rax+0x8]
   28a39:	83 f9 04             	cmp    ecx,0x4
   28a3c:	0f 84 ba 27 00 00    	je     2b1fc <JS_CallInternal+0x865c>
   28a42:	48 8b 53 f8          	mov    rdx,QWORD PTR [rbx-0x8]
   28a46:	48 8b 73 f0          	mov    rsi,QWORD PTR [rbx-0x10]
   28a4a:	83 fa f6             	cmp    edx,0xfffffff6
   28a4d:	76 04                	jbe    28a53 <JS_CallInternal+0x5eb3>
   28a4f:	83 46 fc 01          	add    DWORD PTR [rsi-0x4],0x1
   28a53:	4c 8b 00             	mov    r8,QWORD PTR [rax]
   28a56:	48 89 50 08          	mov    QWORD PTR [rax+0x8],rdx
   28a5a:	48 89 30             	mov    QWORD PTR [rax],rsi
   28a5d:	83 f9 f6             	cmp    ecx,0xfffffff6
   28a60:	76 13                	jbe    28a75 <JS_CallInternal+0x5ed5>
   28a62:	41 8b 40 fc          	mov    eax,DWORD PTR [r8-0x4]
   28a66:	83 e8 01             	sub    eax,0x1
   28a69:	41 89 40 fc          	mov    DWORD PTR [r8-0x4],eax
   28a6d:	85 c0                	test   eax,eax
   28a6f:	0f 8e 61 1c 00 00    	jle    2a6d6 <JS_CallInternal+0x7b36>
   28a75:	41 0f b6 44 24 02    	movzx  eax,BYTE PTR [r12+0x2]
   28a7b:	49 83 c4 03          	add    r12,0x3
   28a7f:	49 89 c5             	mov    r13,rax
   28a82:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   28a86:	ff e0                	jmp    rax
   28a88:	f3 0f 1e fa          	endbr64
   28a8c:	48 8b 53 e8          	mov    rdx,QWORD PTR [rbx-0x18]
   28a90:	4c 8d 6b e0          	lea    r13,[rbx-0x20]
   28a94:	48 8b 73 e0          	mov    rsi,QWORD PTR [rbx-0x20]
   28a98:	83 fa f6             	cmp    edx,0xfffffff6
   28a9b:	76 11                	jbe    28aae <JS_CallInternal+0x5f0e>
   28a9d:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   28aa0:	83 e8 01             	sub    eax,0x1
   28aa3:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   28aa6:	85 c0                	test   eax,eax
   28aa8:	0f 8e 94 1e 00 00    	jle    2a942 <JS_CallInternal+0x7da2>
   28aae:	48 8b 43 d8          	mov    rax,QWORD PTR [rbx-0x28]
   28ab2:	48 83 eb 30          	sub    rbx,0x30
   28ab6:	83 f8 03             	cmp    eax,0x3
   28ab9:	74 45                	je     28b00 <JS_CallInternal+0x5f60>
   28abb:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   28ac2:	48 8b 33             	mov    rsi,QWORD PTR [rbx]
   28ac5:	31 c9                	xor    ecx,ecx
   28ac7:	48 8b 53 08          	mov    rdx,QWORD PTR [rbx+0x8]
   28acb:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   28ad2:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   28ad6:	e8 f5 88 00 00       	call   313d0 <JS_IteratorClose>
   28adb:	85 c0                	test   eax,eax
   28add:	0f 85 d5 44 00 00    	jne    2cfb8 <JS_CallInternal+0xa418>
   28ae3:	48 8b 53 08          	mov    rdx,QWORD PTR [rbx+0x8]
   28ae7:	48 8b 33             	mov    rsi,QWORD PTR [rbx]
   28aea:	83 fa f6             	cmp    edx,0xfffffff6
   28aed:	76 11                	jbe    28b00 <JS_CallInternal+0x5f60>
   28aef:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   28af2:	83 e8 01             	sub    eax,0x1
   28af5:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   28af8:	85 c0                	test   eax,eax
   28afa:	0f 8e 19 3a 00 00    	jle    2c519 <JS_CallInternal+0x9979>
   28b00:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   28b05:	49 83 c4 01          	add    r12,0x1
   28b09:	49 89 c5             	mov    r13,rax
   28b0c:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   28b10:	ff e0                	jmp    rax
   28b12:	f3 0f 1e fa          	endbr64
   28b16:	83 7b f8 ff          	cmp    DWORD PTR [rbx-0x8],0xffffffff
   28b1a:	0f 85 f9 26 00 00    	jne    2b219 <JS_CallInternal+0x8679>
   28b20:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   28b25:	49 83 c4 01          	add    r12,0x1
   28b29:	49 89 c5             	mov    r13,rax
   28b2c:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   28b30:	ff e0                	jmp    rax
   28b32:	f3 0f 1e fa          	endbr64
   28b36:	4c 8b 6b f0          	mov    r13,QWORD PTR [rbx-0x10]
   28b3a:	4c 8d 73 f0          	lea    r14,[rbx-0x10]
   28b3e:	48 8b 5b f8          	mov    rbx,QWORD PTR [rbx-0x8]
   28b42:	4c 39 b5 68 fe ff ff 	cmp    QWORD PTR [rbp-0x198],r14
   28b49:	0f 83 ee 05 00 00    	jae    2913d <JS_CallInternal+0x659d>
   28b4f:	4c 89 a5 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],r12
   28b56:	4d 89 f4             	mov    r12,r14
   28b59:	49 89 de             	mov    r14,rbx
   28b5c:	48 8b 9d 68 fe ff ff 	mov    rbx,QWORD PTR [rbp-0x198]
   28b63:	eb 0c                	jmp    28b71 <JS_CallInternal+0x5fd1>
   28b65:	0f 1f 00             	nop    DWORD PTR [rax]
   28b68:	4c 39 e3             	cmp    rbx,r12
   28b6b:	0f 83 bf 05 00 00    	jae    29130 <JS_CallInternal+0x6590>
   28b71:	41 83 7c 24 f8 05    	cmp    DWORD PTR [r12-0x8],0x5
   28b77:	0f 84 b3 05 00 00    	je     29130 <JS_CallInternal+0x6590>
   28b7d:	49 8b 4c 24 f8       	mov    rcx,QWORD PTR [r12-0x8]
   28b82:	49 83 ec 10          	sub    r12,0x10
   28b86:	49 8b 34 24          	mov    rsi,QWORD PTR [r12]
   28b8a:	83 f9 f6             	cmp    ecx,0xfffffff6
   28b8d:	76 d9                	jbe    28b68 <JS_CallInternal+0x5fc8>
   28b8f:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   28b92:	8d 50 ff             	lea    edx,[rax-0x1]
   28b95:	89 56 fc             	mov    DWORD PTR [rsi-0x4],edx
   28b98:	85 d2                	test   edx,edx
   28b9a:	7f cc                	jg     28b68 <JS_CallInternal+0x5fc8>
   28b9c:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   28ba3:	48 89 ca             	mov    rdx,rcx
   28ba6:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   28baa:	e8 c1 3d ff ff       	call   1c970 <__JS_FreeValueRT>
   28baf:	eb b7                	jmp    28b68 <JS_CallInternal+0x5fc8>
   28bb1:	f3 0f 1e fa          	endbr64
   28bb5:	48 8b 8d e8 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x118]
   28bbc:	4d 0f be 2c 24       	movsx  r13,BYTE PTR [r12]
   28bc1:	8b 81 a8 01 00 00    	mov    eax,DWORD PTR [rcx+0x1a8]
   28bc7:	4d 01 e5             	add    r13,r12
   28bca:	89 85 50 fe ff ff    	mov    DWORD PTR [rbp-0x1b0],eax
   28bd0:	83 e8 01             	sub    eax,0x1
   28bd3:	89 81 a8 01 00 00    	mov    DWORD PTR [rcx+0x1a8],eax
   28bd9:	85 c0                	test   eax,eax
   28bdb:	0f 8e 19 2f 00 00    	jle    2bafa <JS_CallInternal+0x8f5a>
   28be1:	41 0f b6 45 00       	movzx  eax,BYTE PTR [r13+0x0]
   28be6:	4d 8d 65 01          	lea    r12,[r13+0x1]
   28bea:	49 89 c5             	mov    r13,rax
   28bed:	41 ff 24 c7          	jmp    QWORD PTR [r15+rax*8]
   28bf1:	f3 0f 1e fa          	endbr64
   28bf5:	48 8b 8d e8 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x118]
   28bfc:	4d 0f bf 2c 24       	movsx  r13,WORD PTR [r12]
   28c01:	8b 81 a8 01 00 00    	mov    eax,DWORD PTR [rcx+0x1a8]
   28c07:	4d 01 e5             	add    r13,r12
   28c0a:	89 85 50 fe ff ff    	mov    DWORD PTR [rbp-0x1b0],eax
   28c10:	83 e8 01             	sub    eax,0x1
   28c13:	89 81 a8 01 00 00    	mov    DWORD PTR [rcx+0x1a8],eax
   28c19:	85 c0                	test   eax,eax
   28c1b:	0f 8e be 26 00 00    	jle    2b2df <JS_CallInternal+0x873f>
   28c21:	41 0f b6 45 00       	movzx  eax,BYTE PTR [r13+0x0]
   28c26:	4d 8d 65 01          	lea    r12,[r13+0x1]
   28c2a:	49 89 c5             	mov    r13,rax
   28c2d:	41 ff 24 c7          	jmp    QWORD PTR [r15+rax*8]
   28c31:	f3 0f 1e fa          	endbr64
   28c35:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   28c3c:	41 0f b6 0c 24       	movzx  ecx,BYTE PTR [r12]
   28c41:	4d 8d 74 24 01       	lea    r14,[r12+0x1]
   28c46:	c7 85 f0 fe ff ff 01 	mov    DWORD PTR [rbp-0x110],0x1
   28c4d:	00 00 00 
   28c50:	4c 89 70 30          	mov    QWORD PTR [rax+0x30],r14
   28c54:	b8 fd ff ff ff       	mov    eax,0xfffffffd
   28c59:	29 c8                	sub    eax,ecx
   28c5b:	48 98                	cdqe
   28c5d:	48 c1 e0 04          	shl    rax,0x4
   28c61:	4c 8d 2c 03          	lea    r13,[rbx+rax*1]
   28c65:	49 8b 55 08          	mov    rdx,QWORD PTR [r13+0x8]
   28c69:	83 fa 03             	cmp    edx,0x3
   28c6c:	0f 84 38 25 00 00    	je     2b1aa <JS_CallInternal+0x860a>
   28c72:	b8 fe ff ff ff       	mov    eax,0xfffffffe
   28c77:	49 8b 75 00          	mov    rsi,QWORD PTR [r13+0x0]
   28c7b:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   28c82:	4c 8d 8d f0 fe ff ff 	lea    r9,[rbp-0x110]
   28c89:	29 c8                	sub    eax,ecx
   28c8b:	48 98                	cdqe
   28c8d:	48 c1 e0 04          	shl    rax,0x4
   28c91:	48 01 d8             	add    rax,rbx
   28c94:	48 8b 08             	mov    rcx,QWORD PTR [rax]
   28c97:	4c 8b 40 08          	mov    r8,QWORD PTR [rax+0x8]
   28c9b:	e8 10 e9 06 00       	call   975b0 <JS_IteratorNext.constprop.0>
   28ca0:	49 89 d1             	mov    r9,rdx
   28ca3:	48 89 c7             	mov    rdi,rax
   28ca6:	48 89 d6             	mov    rsi,rdx
   28ca9:	83 fa 06             	cmp    edx,0x6
   28cac:	0f 84 27 12 00 00    	je     29ed9 <JS_CallInternal+0x7339>
   28cb2:	8b 8d f0 fe ff ff    	mov    ecx,DWORD PTR [rbp-0x110]
   28cb8:	31 d2                	xor    edx,edx
   28cba:	85 c9                	test   ecx,ecx
   28cbc:	0f 85 26 12 00 00    	jne    29ee8 <JS_CallInternal+0x7348>
   28cc2:	48 89 3b             	mov    QWORD PTR [rbx],rdi
   28cc5:	49 83 c4 02          	add    r12,0x2
   28cc9:	48 83 c3 20          	add    rbx,0x20
   28ccd:	48 89 73 e8          	mov    QWORD PTR [rbx-0x18],rsi
   28cd1:	48 89 53 f0          	mov    QWORD PTR [rbx-0x10],rdx
   28cd5:	48 c7 43 f8 01 00 00 	mov    QWORD PTR [rbx-0x8],0x1
   28cdc:	00 
   28cdd:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   28ce3:	49 89 c5             	mov    r13,rax
   28ce6:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   28cea:	ff e0                	jmp    rax
   28cec:	f3 0f 1e fa          	endbr64
   28cf0:	41 0f b7 04 24       	movzx  eax,WORD PTR [r12]
   28cf5:	48 8b 8d b0 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x150]
   28cfc:	4d 8d 6c 24 02       	lea    r13,[r12+0x2]
   28d01:	48 c1 e0 04          	shl    rax,0x4
   28d05:	48 01 c8             	add    rax,rcx
   28d08:	83 78 08 04          	cmp    DWORD PTR [rax+0x8],0x4
   28d0c:	0f 85 1d 24 00 00    	jne    2b12f <JS_CallInternal+0x858f>
   28d12:	f3 0f 6f 4b f0       	movdqu xmm1,XMMWORD PTR [rbx-0x10]
   28d17:	49 83 c4 03          	add    r12,0x3
   28d1b:	48 83 eb 10          	sub    rbx,0x10
   28d1f:	0f 11 08             	movups XMMWORD PTR [rax],xmm1
   28d22:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   28d28:	49 89 c5             	mov    r13,rax
   28d2b:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   28d2f:	ff e0                	jmp    rax
   28d31:	f3 0f 1e fa          	endbr64
   28d35:	41 0f b7 04 24       	movzx  eax,WORD PTR [r12]
   28d3a:	48 8b 8d b0 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x150]
   28d41:	4d 8d 6c 24 02       	lea    r13,[r12+0x2]
   28d46:	48 89 c2             	mov    rdx,rax
   28d49:	48 c1 e0 04          	shl    rax,0x4
   28d4d:	48 01 c8             	add    rax,rcx
   28d50:	48 8b 48 08          	mov    rcx,QWORD PTR [rax+0x8]
   28d54:	83 f9 04             	cmp    ecx,0x4
   28d57:	0f 84 70 27 00 00    	je     2b4cd <JS_CallInternal+0x892d>
   28d5d:	f3 0f 6f 5b f0       	movdqu xmm3,XMMWORD PTR [rbx-0x10]
   28d62:	48 8b 30             	mov    rsi,QWORD PTR [rax]
   28d65:	0f 11 18             	movups XMMWORD PTR [rax],xmm3
   28d68:	83 f9 f6             	cmp    ecx,0xfffffff6
   28d6b:	76 11                	jbe    28d7e <JS_CallInternal+0x61de>
   28d6d:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   28d70:	83 e8 01             	sub    eax,0x1
   28d73:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   28d76:	85 c0                	test   eax,eax
   28d78:	0f 8e 73 19 00 00    	jle    2a6f1 <JS_CallInternal+0x7b51>
   28d7e:	41 0f b6 44 24 02    	movzx  eax,BYTE PTR [r12+0x2]
   28d84:	48 83 eb 10          	sub    rbx,0x10
   28d88:	49 83 c4 03          	add    r12,0x3
   28d8c:	49 89 c5             	mov    r13,rax
   28d8f:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   28d93:	ff e0                	jmp    rax
   28d95:	f3 0f 1e fa          	endbr64
   28d99:	49 63 04 24          	movsxd rax,DWORD PTR [r12]
   28d9d:	48 8b 8d d8 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x128]
   28da4:	48 83 c3 10          	add    rbx,0x10
   28da8:	4c 01 e0             	add    rax,r12
   28dab:	2b 41 18             	sub    eax,DWORD PTR [rcx+0x18]
   28dae:	48 c7 43 f8 05 00 00 	mov    QWORD PTR [rbx-0x8],0x5
   28db5:	00 
   28db6:	49 83 c4 05          	add    r12,0x5
   28dba:	48 89 43 f0          	mov    QWORD PTR [rbx-0x10],rax
   28dbe:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   28dc4:	49 89 c5             	mov    r13,rax
   28dc7:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   28dcb:	ff e0                	jmp    rax
   28dcd:	f3 0f 1e fa          	endbr64
   28dd1:	48 8b 4b f0          	mov    rcx,QWORD PTR [rbx-0x10]
   28dd5:	83 7b f8 03          	cmp    DWORD PTR [rbx-0x8],0x3
   28dd9:	4d 8d 6c 24 04       	lea    r13,[r12+0x4]
   28dde:	48 8b 53 f8          	mov    rdx,QWORD PTR [rbx-0x8]
   28de2:	48 89 c8             	mov    rax,rcx
   28de5:	0f 87 26 0f 00 00    	ja     29d11 <JS_CallInternal+0x7171>
   28deb:	48 83 eb 10          	sub    rbx,0x10
   28def:	85 c0                	test   eax,eax
   28df1:	74 0c                	je     28dff <JS_CallInternal+0x625f>
   28df3:	41 8b 04 24          	mov    eax,DWORD PTR [r12]
   28df7:	83 e8 04             	sub    eax,0x4
   28dfa:	48 98                	cdqe
   28dfc:	49 01 c5             	add    r13,rax
   28dff:	48 8b 8d e8 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x118]
   28e06:	8b 81 a8 01 00 00    	mov    eax,DWORD PTR [rcx+0x1a8]
   28e0c:	89 85 50 fe ff ff    	mov    DWORD PTR [rbp-0x1b0],eax
   28e12:	83 e8 01             	sub    eax,0x1
   28e15:	89 81 a8 01 00 00    	mov    DWORD PTR [rcx+0x1a8],eax
   28e1b:	85 c0                	test   eax,eax
   28e1d:	0f 8e 1f 25 00 00    	jle    2b342 <JS_CallInternal+0x87a2>
   28e23:	41 0f b6 45 00       	movzx  eax,BYTE PTR [r13+0x0]
   28e28:	4d 8d 65 01          	lea    r12,[r13+0x1]
   28e2c:	49 89 c5             	mov    r13,rax
   28e2f:	41 ff 24 c7          	jmp    QWORD PTR [r15+rax*8]
   28e33:	44 8b 00             	mov    r8d,DWORD PTR [rax]
   28e36:	41 81 e0 ff ff ff 03 	and    r8d,0x3ffffff
   28e3d:	0f 85 d1 f5 ff ff    	jne    28414 <JS_CallInternal+0x5874>
   28e43:	f6 41 10 08          	test   BYTE PTR [rcx+0x10],0x8
   28e47:	0f 85 2f 05 00 00    	jne    2937c <JS_CallInternal+0x67dc>
   28e4d:	48 8b 4a 30          	mov    rcx,QWORD PTR [rdx+0x30]
   28e51:	48 85 c9             	test   rcx,rcx
   28e54:	0f 85 96 f5 ff ff    	jne    283f0 <JS_CallInternal+0x5850>
   28e5a:	4c 8d 6b f0          	lea    r13,[rbx-0x10]
   28e5e:	b9 03 00 00 00       	mov    ecx,0x3
   28e63:	45 31 f6             	xor    r14d,r14d
   28e66:	e9 e6 f5 ff ff       	jmp    28451 <JS_CallInternal+0x58b1>
   28e6b:	44 8b 00             	mov    r8d,DWORD PTR [rax]
   28e6e:	41 81 e0 ff ff ff 03 	and    r8d,0x3ffffff
   28e75:	0f 85 48 f4 ff ff    	jne    282c3 <JS_CallInternal+0x5723>
   28e7b:	f6 41 10 08          	test   BYTE PTR [rcx+0x10],0x8
   28e7f:	0f 85 49 05 00 00    	jne    293ce <JS_CallInternal+0x682e>
   28e85:	48 8b 4a 30          	mov    rcx,QWORD PTR [rdx+0x30]
   28e89:	48 85 c9             	test   rcx,rcx
   28e8c:	0f 85 0e f4 ff ff    	jne    282a0 <JS_CallInternal+0x5700>
   28e92:	ba 03 00 00 00       	mov    edx,0x3
   28e97:	31 c0                	xor    eax,eax
   28e99:	e9 5c f4 ff ff       	jmp    282fa <JS_CallInternal+0x575a>
   28e9e:	44 8b 00             	mov    r8d,DWORD PTR [rax]
   28ea1:	41 81 e0 ff ff ff 03 	and    r8d,0x3ffffff
   28ea8:	0f 85 b5 f4 ff ff    	jne    28363 <JS_CallInternal+0x57c3>
   28eae:	f6 41 10 08          	test   BYTE PTR [rcx+0x10],0x8
   28eb2:	0f 85 c8 05 00 00    	jne    29480 <JS_CallInternal+0x68e0>
   28eb8:	48 8b 4a 30          	mov    rcx,QWORD PTR [rdx+0x30]
   28ebc:	48 85 c9             	test   rcx,rcx
   28ebf:	0f 85 7b f4 ff ff    	jne    28340 <JS_CallInternal+0x57a0>
   28ec5:	4c 8d 6b f0          	lea    r13,[rbx-0x10]
   28ec9:	41 b8 03 00 00 00    	mov    r8d,0x3
   28ecf:	31 c0                	xor    eax,eax
   28ed1:	e9 c9 f4 ff ff       	jmp    2839f <JS_CallInternal+0x57ff>
   28ed6:	8b 30                	mov    esi,DWORD PTR [rax]
   28ed8:	81 e6 ff ff ff 03    	and    esi,0x3ffffff
   28ede:	0f 85 aa b1 ff ff    	jne    2408e <JS_CallInternal+0x14ee>
   28ee4:	f6 42 10 08          	test   BYTE PTR [rdx+0x10],0x8
   28ee8:	0f 85 38 04 00 00    	jne    29326 <JS_CallInternal+0x6786>
   28eee:	49 8b 55 30          	mov    rdx,QWORD PTR [r13+0x30]
   28ef2:	48 85 d2             	test   rdx,rdx
   28ef5:	0f 84 61 16 00 00    	je     2a55c <JS_CallInternal+0x79bc>
   28efb:	4c 8b 6a 18          	mov    r13,QWORD PTR [rdx+0x18]
   28eff:	e9 6c b1 ff ff       	jmp    24070 <JS_CallInternal+0x14d0>
   28f04:	8b 30                	mov    esi,DWORD PTR [rax]
   28f06:	81 e6 ff ff ff 03    	and    esi,0x3ffffff
   28f0c:	0f 85 7c b2 ff ff    	jne    2418e <JS_CallInternal+0x15ee>
   28f12:	f6 42 10 08          	test   BYTE PTR [rdx+0x10],0x8
   28f16:	0f 85 fe 04 00 00    	jne    2941a <JS_CallInternal+0x687a>
   28f1c:	49 8b 55 30          	mov    rdx,QWORD PTR [r13+0x30]
   28f20:	48 85 d2             	test   rdx,rdx
   28f23:	0f 84 9d 16 00 00    	je     2a5c6 <JS_CallInternal+0x7a26>
   28f29:	4c 8b 6a 18          	mov    r13,QWORD PTR [rdx+0x18]
   28f2d:	e9 3e b2 ff ff       	jmp    24170 <JS_CallInternal+0x15d0>
   28f32:	8b b5 bc fe ff ff    	mov    esi,DWORD PTR [rbp-0x144]
   28f38:	39 f7                	cmp    edi,esi
   28f3a:	41 89 f5             	mov    r13d,esi
   28f3d:	44 0f 4e ef          	cmovle r13d,edi
   28f41:	45 85 ed             	test   r13d,r13d
   28f44:	0f 8e dc 14 00 00    	jle    2a426 <JS_CallInternal+0x7886>
   28f4a:	4c 8b bd a8 fe ff ff 	mov    r15,QWORD PTR [rbp-0x158]
   28f51:	4d 63 f5             	movsxd r14,r13d
   28f54:	4d 8d 43 08          	lea    r8,[r11+0x8]
   28f58:	49 c1 e6 04          	shl    r14,0x4
   28f5c:	4c 89 fe             	mov    rsi,r15
   28f5f:	4d 01 fe             	add    r14,r15
   28f62:	66 0f 1f 44 00 00    	nop    WORD PTR [rax+rax*1+0x0]
   28f68:	4c 8b 66 08          	mov    r12,QWORD PTR [rsi+0x8]
   28f6c:	4c 8b 3e             	mov    r15,QWORD PTR [rsi]
   28f6f:	41 83 fc f6          	cmp    r12d,0xfffffff6
   28f73:	76 05                	jbe    28f7a <JS_CallInternal+0x63da>
   28f75:	41 83 47 fc 01       	add    DWORD PTR [r15-0x4],0x1
   28f7a:	48 83 c6 10          	add    rsi,0x10
   28f7e:	4d 89 78 f8          	mov    QWORD PTR [r8-0x8],r15
   28f82:	49 83 c0 10          	add    r8,0x10
   28f86:	4d 89 60 f0          	mov    QWORD PTR [r8-0x10],r12
   28f8a:	4c 39 f6             	cmp    rsi,r14
   28f8d:	75 d9                	jne    28f68 <JS_CallInternal+0x63c8>
   28f8f:	44 39 ef             	cmp    edi,r13d
   28f92:	7e 3c                	jle    28fd0 <JS_CallInternal+0x6430>
   28f94:	44 8d 47 ff          	lea    r8d,[rdi-0x1]
   28f98:	4d 63 e5             	movsxd r12,r13d
   28f9b:	45 29 e8             	sub    r8d,r13d
   28f9e:	4c 89 e6             	mov    rsi,r12
   28fa1:	4d 01 e0             	add    r8,r12
   28fa4:	48 c1 e6 04          	shl    rsi,0x4
   28fa8:	49 c1 e0 04          	shl    r8,0x4
   28fac:	4c 01 de             	add    rsi,r11
   28faf:	4f 8d 44 03 10       	lea    r8,[r11+r8*1+0x10]
   28fb4:	0f 1f 40 00          	nop    DWORD PTR [rax+0x0]
   28fb8:	48 c7 06 00 00 00 00 	mov    QWORD PTR [rsi],0x0
   28fbf:	48 83 c6 10          	add    rsi,0x10
   28fc3:	48 c7 46 f8 03 00 00 	mov    QWORD PTR [rsi-0x8],0x3
   28fca:	00 
   28fcb:	4c 39 c6             	cmp    rsi,r8
   28fce:	75 e8                	jne    28fb8 <JS_CallInternal+0x6418>
   28fd0:	89 bd 38 ff ff ff    	mov    DWORD PTR [rbp-0xc8],edi
   28fd6:	4c 89 9d 90 fe ff ff 	mov    QWORD PTR [rbp-0x170],r11
   28fdd:	e9 9c 9d ff ff       	jmp    22d7e <JS_CallInternal+0x1de>
   28fe2:	48 83 ec 08          	sub    rsp,0x8
   28fe6:	8b 8d 38 fe ff ff    	mov    ecx,DWORD PTR [rbp-0x1c8]
   28fec:	49 89 d1             	mov    r9,rdx
   28fef:	48 89 c6             	mov    rsi,rax
   28ff2:	6a 00                	push   0x0
   28ff4:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   28ffb:	48 89 85 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],rax
   29002:	e8 09 42 00 00       	call   2d210 <JS_GetPropertyInternal>
   29007:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2900e:	48 89 c6             	mov    rsi,rax
   29011:	e8 8a 5b ff ff       	call   1eba0 <JS_ToBoolFree>
   29016:	4c 8b 85 40 fe ff ff 	mov    r8,QWORD PTR [rbp-0x1c0]
   2901d:	89 c1                	mov    ecx,eax
   2901f:	41 8b 40 fc          	mov    eax,DWORD PTR [r8-0x4]
   29023:	83 e8 01             	sub    eax,0x1
   29026:	41 89 40 fc          	mov    DWORD PTR [r8-0x4],eax
   2902a:	41 5b                	pop    r11
   2902c:	5a                   	pop    rdx
   2902d:	85 c0                	test   eax,eax
   2902f:	0f 8e 0b 39 00 00    	jle    2c940 <JS_CallInternal+0x9da0>
   29035:	85 c9                	test   ecx,ecx
   29037:	0f 88 69 a6 ff ff    	js     236a6 <JS_CallInternal+0xb06>
   2903d:	0f 84 00 9f ff ff    	je     22f43 <JS_CallInternal+0x3a3>
   29043:	48 8b 53 f8          	mov    rdx,QWORD PTR [rbx-0x8]
   29047:	48 83 eb 10          	sub    rbx,0x10
   2904b:	48 8b 33             	mov    rsi,QWORD PTR [rbx]
   2904e:	83 fa f6             	cmp    edx,0xfffffff6
   29051:	0f 86 28 a4 ff ff    	jbe    2347f <JS_CallInternal+0x8df>
   29057:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   2905a:	83 e8 01             	sub    eax,0x1
   2905d:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   29060:	85 c0                	test   eax,eax
   29062:	0f 8f 17 a4 ff ff    	jg     2347f <JS_CallInternal+0x8df>
   29068:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2906f:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   29073:	e8 f8 38 ff ff       	call   1c970 <__JS_FreeValueRT>
   29078:	e9 02 a4 ff ff       	jmp    2347f <JS_CallInternal+0x8df>
   2907d:	8b 85 38 fe ff ff    	mov    eax,DWORD PTR [rbp-0x1c8]
   29083:	48 8b 9d 50 fe ff ff 	mov    rbx,QWORD PTR [rbp-0x1b0]
   2908a:	4c 8b a5 40 fe ff ff 	mov    r12,QWORD PTR [rbp-0x1c0]
   29091:	83 c0 02             	add    eax,0x2
   29094:	48 98                	cdqe
   29096:	49 83 c4 03          	add    r12,0x3
   2909a:	48 c1 e0 04          	shl    rax,0x4
   2909e:	48 29 c3             	sub    rbx,rax
   290a1:	48 89 da             	mov    rdx,rbx
   290a4:	48 8d 5b 10          	lea    rbx,[rbx+0x10]
   290a8:	4c 89 2a             	mov    QWORD PTR [rdx],r13
   290ab:	4c 89 72 08          	mov    QWORD PTR [rdx+0x8],r14
   290af:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   290b5:	49 89 c5             	mov    r13,rax
   290b8:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   290bc:	ff e0                	jmp    rax
   290be:	80 fa 01             	cmp    dl,0x1
   290c1:	0f 84 11 04 00 00    	je     294d8 <JS_CallInternal+0x6938>
   290c7:	80 cc 10             	or     ah,0x10
   290ca:	f3 0f 6f 53 f0       	movdqu xmm2,XMMWORD PTR [rbx-0x10]
   290cf:	8b b5 50 fe ff ff    	mov    esi,DWORD PTR [rbp-0x1b0]
   290d5:	89 85 24 fe ff ff    	mov    DWORD PTR [rbp-0x1dc],eax
   290db:	49 8b 04 24          	mov    rax,QWORD PTR [r12]
   290df:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   290e6:	0f 29 95 e0 fd ff ff 	movaps XMMWORD PTR [rbp-0x220],xmm2
   290ed:	48 89 85 d8 fd ff ff 	mov    QWORD PTR [rbp-0x228],rax
   290f4:	49 8b 44 24 08       	mov    rax,QWORD PTR [r12+0x8]
   290f9:	48 89 85 d0 fd ff ff 	mov    QWORD PTR [rbp-0x230],rax
   29100:	e8 5b 7a 01 00       	call   40b60 <js_get_function_name>
   29105:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2910c:	4c 8d 05 31 40 0a 00 	lea    r8,[rip+0xa4031]        # cd144 <_IO_stdin_used+0x144>
   29113:	48 8d 35 70 44 0a 00 	lea    rsi,[rip+0xa4470]        # cd58a <_IO_stdin_used+0x58a>
   2911a:	49 89 d1             	mov    r9,rdx
   2911d:	48 89 c2             	mov    rdx,rax
   29120:	4c 89 c9             	mov    rcx,r9
   29123:	e8 c8 78 01 00       	call   409f0 <JS_ConcatString3>
   29128:	49 89 d1             	mov    r9,rdx
   2912b:	e9 6c a8 ff ff       	jmp    2399c <JS_CallInternal+0xdfc>
   29130:	4c 89 f3             	mov    rbx,r14
   29133:	4d 89 e6             	mov    r14,r12
   29136:	4c 8b a5 50 fe ff ff 	mov    r12,QWORD PTR [rbp-0x1b0]
   2913d:	48 8b 85 68 fe ff ff 	mov    rax,QWORD PTR [rbp-0x198]
   29144:	49 39 c6             	cmp    r14,rax
   29147:	0f 84 ff 1f 00 00    	je     2b14c <JS_CallInternal+0x85ac>
   2914d:	4d 89 6e f0          	mov    QWORD PTR [r14-0x10],r13
   29151:	49 83 c4 01          	add    r12,0x1
   29155:	49 89 5e f8          	mov    QWORD PTR [r14-0x8],rbx
   29159:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   2915f:	4c 89 f3             	mov    rbx,r14
   29162:	49 89 c5             	mov    r13,rax
   29165:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   29169:	ff e0                	jmp    rax
   2916b:	8b 85 50 fe ff ff    	mov    eax,DWORD PTR [rbp-0x1b0]
   29171:	49 83 c4 05          	add    r12,0x5
   29175:	83 c0 01             	add    eax,0x1
   29178:	48 98                	cdqe
   2917a:	48 c1 e0 04          	shl    rax,0x4
   2917e:	48 29 c3             	sub    rbx,rax
   29181:	48 89 da             	mov    rdx,rbx
   29184:	48 8d 5b 10          	lea    rbx,[rbx+0x10]
   29188:	4c 89 0a             	mov    QWORD PTR [rdx],r9
   2918b:	4c 89 42 08          	mov    QWORD PTR [rdx+0x8],r8
   2918f:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   29195:	49 89 c5             	mov    r13,rax
   29198:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   2919c:	ff e0                	jmp    rax
   2919e:	8b 85 40 fe ff ff    	mov    eax,DWORD PTR [rbp-0x1c0]
   291a4:	49 83 c4 03          	add    r12,0x3
   291a8:	83 c0 02             	add    eax,0x2
   291ab:	48 98                	cdqe
   291ad:	48 c1 e0 04          	shl    rax,0x4
   291b1:	48 29 c3             	sub    rbx,rax
   291b4:	48 89 da             	mov    rdx,rbx
   291b7:	48 8d 5b 10          	lea    rbx,[rbx+0x10]
   291bb:	4c 89 0a             	mov    QWORD PTR [rdx],r9
   291be:	4c 89 42 08          	mov    QWORD PTR [rdx+0x8],r8
   291c2:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   291c8:	49 89 c5             	mov    r13,rax
   291cb:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   291cf:	ff e0                	jmp    rax
   291d1:	48 8b 9d 38 fe ff ff 	mov    rbx,QWORD PTR [rbp-0x1c8]
   291d8:	4c 8b a5 28 fe ff ff 	mov    r12,QWORD PTR [rbp-0x1d8]
   291df:	4c 89 f6             	mov    rsi,r14
   291e2:	e8 f9 b8 fe ff       	call   14ae0 <__js_free>
   291e7:	41 83 fd 06          	cmp    r13d,0x6
   291eb:	0f 84 45 17 00 00    	je     2a936 <JS_CallInternal+0x7d96>
   291f1:	48 8b 53 e8          	mov    rdx,QWORD PTR [rbx-0x18]
   291f5:	48 8b 73 e0          	mov    rsi,QWORD PTR [rbx-0x20]
   291f9:	83 fa f6             	cmp    edx,0xfffffff6
   291fc:	76 11                	jbe    2920f <JS_CallInternal+0x666f>
   291fe:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   29201:	83 e8 01             	sub    eax,0x1
   29204:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   29207:	85 c0                	test   eax,eax
   29209:	0f 8e 06 19 00 00    	jle    2ab15 <JS_CallInternal+0x7f75>
   2920f:	48 8b 85 50 fe ff ff 	mov    rax,QWORD PTR [rbp-0x1b0]
   29216:	48 8b 50 08          	mov    rdx,QWORD PTR [rax+0x8]
   2921a:	48 8b 30             	mov    rsi,QWORD PTR [rax]
   2921d:	83 fa f6             	cmp    edx,0xfffffff6
   29220:	76 11                	jbe    29233 <JS_CallInternal+0x6693>
   29222:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   29225:	83 e8 01             	sub    eax,0x1
   29228:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   2922b:	85 c0                	test   eax,eax
   2922d:	0f 8e cd 18 00 00    	jle    2ab00 <JS_CallInternal+0x7f60>
   29233:	48 8b 85 40 fe ff ff 	mov    rax,QWORD PTR [rbp-0x1c0]
   2923a:	4c 89 6b e8          	mov    QWORD PTR [rbx-0x18],r13
   2923e:	49 83 c4 03          	add    r12,0x3
   29242:	48 89 43 e0          	mov    QWORD PTR [rbx-0x20],rax
   29246:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   2924c:	48 8b 9d 50 fe ff ff 	mov    rbx,QWORD PTR [rbp-0x1b0]
   29253:	49 89 c5             	mov    r13,rax
   29256:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   2925a:	ff e0                	jmp    rax
   2925c:	8b 10                	mov    edx,DWORD PTR [rax]
   2925e:	81 e2 ff ff ff 03    	and    edx,0x3ffffff
   29264:	0f 85 c6 d9 ff ff    	jne    26c30 <JS_CallInternal+0x4090>
   2926a:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   29271:	89 f2                	mov    edx,esi
   29273:	b9 07 00 00 00       	mov    ecx,0x7
   29278:	4c 89 c6             	mov    rsi,r8
   2927b:	e8 10 d3 01 00       	call   46590 <add_property>
   29280:	48 85 c0             	test   rax,rax
   29283:	0f 84 d3 d9 ff ff    	je     26c5c <JS_CallInternal+0x40bc>
   29289:	48 8b 9d 50 fe ff ff 	mov    rbx,QWORD PTR [rbp-0x1b0]
   29290:	4c 89 28             	mov    QWORD PTR [rax],r13
   29293:	48 89 58 08          	mov    QWORD PTR [rax+0x8],rbx
   29297:	49 8b 56 08          	mov    rdx,QWORD PTR [r14+0x8]
   2929b:	49 8b 36             	mov    rsi,QWORD PTR [r14]
   2929e:	83 fa f6             	cmp    edx,0xfffffff6
   292a1:	76 11                	jbe    292b4 <JS_CallInternal+0x6714>
   292a3:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   292a6:	83 e8 01             	sub    eax,0x1
   292a9:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   292ac:	85 c0                	test   eax,eax
   292ae:	0f 8e 79 20 00 00    	jle    2b32d <JS_CallInternal+0x878d>
   292b4:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   292b9:	4c 89 f3             	mov    rbx,r14
   292bc:	49 83 c4 01          	add    r12,0x1
   292c0:	49 89 c5             	mov    r13,rax
   292c3:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   292c7:	ff e0                	jmp    rax
   292c9:	ba 08 00 00 00       	mov    edx,0x8
   292ce:	e9 ac e2 ff ff       	jmp    2757f <JS_CallInternal+0x49df>
   292d3:	81 bd 50 fe ff ff f2 	cmp    DWORD PTR [rbp-0x1b0],0xf2
   292da:	00 00 00 
   292dd:	0f 8f f6 10 00 00    	jg     2a3d9 <JS_CallInternal+0x7839>
   292e3:	48 8b 53 e8          	mov    rdx,QWORD PTR [rbx-0x18]
   292e7:	48 8b 73 e0          	mov    rsi,QWORD PTR [rbx-0x20]
   292eb:	83 fa f6             	cmp    edx,0xfffffff6
   292ee:	0f 86 ae a7 ff ff    	jbe    23aa2 <JS_CallInternal+0xf02>
   292f4:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   292f7:	83 e8 01             	sub    eax,0x1
   292fa:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   292fd:	85 c0                	test   eax,eax
   292ff:	0f 8f 9d a7 ff ff    	jg     23aa2 <JS_CallInternal+0xf02>
   29305:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2930c:	89 8d 50 fe ff ff    	mov    DWORD PTR [rbp-0x1b0],ecx
   29312:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   29316:	e8 55 36 ff ff       	call   1c970 <__JS_FreeValueRT>
   2931b:	8b 8d 50 fe ff ff    	mov    ecx,DWORD PTR [rbp-0x1b0]
   29321:	e9 7c a7 ff ff       	jmp    23aa2 <JS_CallInternal+0xf02>
   29326:	49 89 d2             	mov    r10,rdx
   29329:	49 c7 c3 ff ff ff ff 	mov    r11,0xffffffffffffffff
   29330:	48 83 ec 08          	sub    rsp,0x8
   29334:	4c 8b 43 f0          	mov    r8,QWORD PTR [rbx-0x10]
   29338:	4c 8b 4b f8          	mov    r9,QWORD PTR [rbx-0x8]
   2933c:	4c 89 d6             	mov    rsi,r10
   2933f:	48 8b bd 50 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x1b0]
   29346:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   2934d:	4c 89 da             	mov    rdx,r11
   29350:	48 89 78 30          	mov    QWORD PTR [rax+0x30],rdi
   29354:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2935b:	6a 00                	push   0x0
   2935d:	e8 ae 3e 00 00       	call   2d210 <JS_GetPropertyInternal>
   29362:	5e                   	pop    rsi
   29363:	5f                   	pop    rdi
   29364:	48 89 d1             	mov    rcx,rdx
   29367:	83 fa 06             	cmp    edx,0x6
   2936a:	0f 85 7b ad ff ff    	jne    240eb <JS_CallInternal+0x154b>
   29370:	4c 8b a5 50 fe ff ff 	mov    r12,QWORD PTR [rbp-0x1b0]
   29377:	e9 c4 9f ff ff       	jmp    23340 <JS_CallInternal+0x7a0>
   2937c:	48 89 ce             	mov    rsi,rcx
   2937f:	48 c7 c7 ff ff ff ff 	mov    rdi,0xffffffffffffffff
   29386:	48 83 ec 08          	sub    rsp,0x8
   2938a:	4c 8b 43 f0          	mov    r8,QWORD PTR [rbx-0x10]
   2938e:	4c 8b 4b f8          	mov    r9,QWORD PTR [rbx-0x8]
   29392:	48 89 fa             	mov    rdx,rdi
   29395:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   2939c:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   293a3:	b9 32 00 00 00       	mov    ecx,0x32
   293a8:	4c 8d 6b f0          	lea    r13,[rbx-0x10]
   293ac:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   293b0:	6a 00                	push   0x0
   293b2:	e8 59 3e 00 00       	call   2d210 <JS_GetPropertyInternal>
   293b7:	5f                   	pop    rdi
   293b8:	41 58                	pop    r8
   293ba:	49 89 c6             	mov    r14,rax
   293bd:	48 89 d1             	mov    rcx,rdx
   293c0:	83 fa 06             	cmp    edx,0x6
   293c3:	0f 85 88 f0 ff ff    	jne    28451 <JS_CallInternal+0x58b1>
   293c9:	e9 72 9f ff ff       	jmp    23340 <JS_CallInternal+0x7a0>
   293ce:	49 89 ca             	mov    r10,rcx
   293d1:	48 c7 c7 ff ff ff ff 	mov    rdi,0xffffffffffffffff
   293d8:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   293df:	48 83 ec 08          	sub    rsp,0x8
   293e3:	48 89 fa             	mov    rdx,rdi
   293e6:	89 f1                	mov    ecx,esi
   293e8:	4c 8b 4b f8          	mov    r9,QWORD PTR [rbx-0x8]
   293ec:	4c 8b 43 f0          	mov    r8,QWORD PTR [rbx-0x10]
   293f0:	4c 89 d6             	mov    rsi,r10
   293f3:	4c 89 68 30          	mov    QWORD PTR [rax+0x30],r13
   293f7:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   293fe:	6a 00                	push   0x0
   29400:	e8 0b 3e 00 00       	call   2d210 <JS_GetPropertyInternal>
   29405:	41 59                	pop    r9
   29407:	41 5a                	pop    r10
   29409:	83 fa 06             	cmp    edx,0x6
   2940c:	0f 85 e8 ee ff ff    	jne    282fa <JS_CallInternal+0x575a>
   29412:	4d 89 ec             	mov    r12,r13
   29415:	e9 26 9f ff ff       	jmp    23340 <JS_CallInternal+0x7a0>
   2941a:	49 89 d2             	mov    r10,rdx
   2941d:	49 c7 c3 ff ff ff ff 	mov    r11,0xffffffffffffffff
   29424:	48 83 ec 08          	sub    rsp,0x8
   29428:	4c 8b 4b f8          	mov    r9,QWORD PTR [rbx-0x8]
   2942c:	4c 8b 43 f0          	mov    r8,QWORD PTR [rbx-0x10]
   29430:	4c 89 d6             	mov    rsi,r10
   29433:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   2943a:	48 8b bd 40 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x1c0]
   29441:	4c 89 da             	mov    rdx,r11
   29444:	48 89 78 30          	mov    QWORD PTR [rax+0x30],rdi
   29448:	48 8d 43 f0          	lea    rax,[rbx-0x10]
   2944c:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   29453:	48 89 85 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],rax
   2945a:	6a 00                	push   0x0
   2945c:	e8 af 3d 00 00       	call   2d210 <JS_GetPropertyInternal>
   29461:	41 59                	pop    r9
   29463:	41 5a                	pop    r10
   29465:	49 89 c5             	mov    r13,rax
   29468:	48 89 d0             	mov    rax,rdx
   2946b:	83 fa 06             	cmp    edx,0x6
   2946e:	0f 85 82 ad ff ff    	jne    241f6 <JS_CallInternal+0x1656>
   29474:	4c 8b a5 40 fe ff ff 	mov    r12,QWORD PTR [rbp-0x1c0]
   2947b:	e9 c0 9e ff ff       	jmp    23340 <JS_CallInternal+0x7a0>
   29480:	49 89 ca             	mov    r10,rcx
   29483:	48 c7 c7 ff ff ff ff 	mov    rdi,0xffffffffffffffff
   2948a:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   29491:	48 83 ec 08          	sub    rsp,0x8
   29495:	48 89 fa             	mov    rdx,rdi
   29498:	89 f1                	mov    ecx,esi
   2949a:	4c 8b 43 f0          	mov    r8,QWORD PTR [rbx-0x10]
   2949e:	4c 8b 4b f8          	mov    r9,QWORD PTR [rbx-0x8]
   294a2:	4c 89 d6             	mov    rsi,r10
   294a5:	4c 8d 6b f0          	lea    r13,[rbx-0x10]
   294a9:	4c 89 70 30          	mov    QWORD PTR [rax+0x30],r14
   294ad:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   294b4:	6a 00                	push   0x0
   294b6:	e8 55 3d 00 00       	call   2d210 <JS_GetPropertyInternal>
   294bb:	41 5b                	pop    r11
   294bd:	49 89 d0             	mov    r8,rdx
   294c0:	5a                   	pop    rdx
   294c1:	41 83 f8 06          	cmp    r8d,0x6
   294c5:	0f 85 d4 ee ff ff    	jne    2839f <JS_CallInternal+0x57ff>
   294cb:	4d 89 f4             	mov    r12,r14
   294ce:	e9 6d 9e ff ff       	jmp    23340 <JS_CallInternal+0x7a0>
   294d3:	0f 1f 44 00 00       	nop    DWORD PTR [rax+rax*1+0x0]
   294d8:	80 cc 08             	or     ah,0x8
   294db:	f3 0f 6f 7b f0       	movdqu xmm7,XMMWORD PTR [rbx-0x10]
   294e0:	8b b5 50 fe ff ff    	mov    esi,DWORD PTR [rbp-0x1b0]
   294e6:	89 85 24 fe ff ff    	mov    DWORD PTR [rbp-0x1dc],eax
   294ec:	49 8b 04 24          	mov    rax,QWORD PTR [r12]
   294f0:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   294f7:	0f 29 bd 10 fe ff ff 	movaps XMMWORD PTR [rbp-0x1f0],xmm7
   294fe:	48 89 85 d8 fd ff ff 	mov    QWORD PTR [rbp-0x228],rax
   29505:	49 8b 44 24 08       	mov    rax,QWORD PTR [r12+0x8]
   2950a:	48 89 85 d0 fd ff ff 	mov    QWORD PTR [rbp-0x230],rax
   29511:	e8 4a 76 01 00       	call   40b60 <js_get_function_name>
   29516:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2951d:	4c 8d 05 20 3c 0a 00 	lea    r8,[rip+0xa3c20]        # cd144 <_IO_stdin_used+0x144>
   29524:	48 8d 35 5a 40 0a 00 	lea    rsi,[rip+0xa405a]        # cd585 <_IO_stdin_used+0x585>
   2952b:	49 89 d1             	mov    r9,rdx
   2952e:	48 89 c2             	mov    rdx,rax
   29531:	4c 89 c9             	mov    rcx,r9
   29534:	e8 b7 74 01 00       	call   409f0 <JS_ConcatString3>
   29539:	49 89 d1             	mov    r9,rdx
   2953c:	e9 5b a4 ff ff       	jmp    2399c <JS_CallInternal+0xdfc>
   29541:	4c 8b a5 50 fe ff ff 	mov    r12,QWORD PTR [rbp-0x1b0]
   29548:	e9 f3 9d ff ff       	jmp    23340 <JS_CallInternal+0x7a0>
   2954d:	48 8b 8d c8 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x138]
   29554:	4c 89 71 30          	mov    QWORD PTR [rcx+0x30],r14
   29558:	83 fa f6             	cmp    edx,0xfffffff6
   2955b:	76 04                	jbe    29561 <JS_CallInternal+0x69c1>
   2955d:	83 40 fc 01          	add    DWORD PTR [rax-0x4],0x1
   29561:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   29568:	48 89 95 f8 fe ff ff 	mov    QWORD PTR [rbp-0x108],rdx
   2956f:	48 8d b5 00 ff ff ff 	lea    rsi,[rbp-0x100]
   29576:	ba 8d 00 00 00       	mov    edx,0x8d
   2957b:	48 89 85 f0 fe ff ff 	mov    QWORD PTR [rbp-0x110],rax
   29582:	e8 09 c1 02 00       	call   55690 <js_unary_arith_slow>
   29587:	85 c0                	test   eax,eax
   29589:	0f 85 51 39 00 00    	jne    2cee0 <JS_CallInternal+0xa340>
   2958f:	49 8b 55 08          	mov    rdx,QWORD PTR [r13+0x8]
   29593:	66 0f 6f 9d f0 fe ff 	movdqa xmm3,XMMWORD PTR [rbp-0x110]
   2959a:	ff 
   2959b:	49 8b 75 00          	mov    rsi,QWORD PTR [r13+0x0]
   2959f:	41 0f 11 5d 00       	movups XMMWORD PTR [r13+0x0],xmm3
   295a4:	83 fa f6             	cmp    edx,0xfffffff6
   295a7:	0f 86 56 dd ff ff    	jbe    27303 <JS_CallInternal+0x4763>
   295ad:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   295b0:	83 e8 01             	sub    eax,0x1
   295b3:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   295b6:	85 c0                	test   eax,eax
   295b8:	0f 8f 45 dd ff ff    	jg     27303 <JS_CallInternal+0x4763>
   295be:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   295c5:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   295c9:	e8 a2 33 ff ff       	call   1c970 <__JS_FreeValueRT>
   295ce:	e9 30 dd ff ff       	jmp    27303 <JS_CallInternal+0x4763>
   295d3:	48 8b 8d c8 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x138]
   295da:	4c 89 71 30          	mov    QWORD PTR [rcx+0x30],r14
   295de:	83 fa f6             	cmp    edx,0xfffffff6
   295e1:	76 04                	jbe    295e7 <JS_CallInternal+0x6a47>
   295e3:	83 40 fc 01          	add    DWORD PTR [rax-0x4],0x1
   295e7:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   295ee:	48 89 95 f8 fe ff ff 	mov    QWORD PTR [rbp-0x108],rdx
   295f5:	48 8d b5 00 ff ff ff 	lea    rsi,[rbp-0x100]
   295fc:	ba 8c 00 00 00       	mov    edx,0x8c
   29601:	48 89 85 f0 fe ff ff 	mov    QWORD PTR [rbp-0x110],rax
   29608:	e8 83 c0 02 00       	call   55690 <js_unary_arith_slow>
   2960d:	85 c0                	test   eax,eax
   2960f:	0f 85 be 39 00 00    	jne    2cfd3 <JS_CallInternal+0xa433>
   29615:	49 8b 55 08          	mov    rdx,QWORD PTR [r13+0x8]
   29619:	66 0f 6f a5 f0 fe ff 	movdqa xmm4,XMMWORD PTR [rbp-0x110]
   29620:	ff 
   29621:	49 8b 75 00          	mov    rsi,QWORD PTR [r13+0x0]
   29625:	41 0f 11 65 00       	movups XMMWORD PTR [r13+0x0],xmm4
   2962a:	83 fa f6             	cmp    edx,0xfffffff6
   2962d:	0f 86 c4 df ff ff    	jbe    275f7 <JS_CallInternal+0x4a57>
   29633:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   29636:	83 e8 01             	sub    eax,0x1
   29639:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   2963c:	85 c0                	test   eax,eax
   2963e:	0f 8f b3 df ff ff    	jg     275f7 <JS_CallInternal+0x4a57>
   29644:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2964b:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2964f:	e8 1c 33 ff ff       	call   1c970 <__JS_FreeValueRT>
   29654:	e9 9e df ff ff       	jmp    275f7 <JS_CallInternal+0x4a57>
   29659:	83 bd 88 fe ff ff f6 	cmp    DWORD PTR [rbp-0x178],0xfffffff6
   29660:	0f 86 1e c1 ff ff    	jbe    25784 <JS_CallInternal+0x2be4>
   29666:	e9 0e c1 ff ff       	jmp    25779 <JS_CallInternal+0x2bd9>
   2966b:	0f 1f 44 00 00       	nop    DWORD PTR [rax+rax*1+0x0]
   29670:	45 85 ed             	test   r13d,r13d
   29673:	0f 85 a4 31 00 00    	jne    2c81d <JS_CallInternal+0x9c7d>
   29679:	48 8b 53 e8          	mov    rdx,QWORD PTR [rbx-0x18]
   2967d:	48 8b 73 e0          	mov    rsi,QWORD PTR [rbx-0x20]
   29681:	4c 8d 6b e0          	lea    r13,[rbx-0x20]
   29685:	83 fa f6             	cmp    edx,0xfffffff6
   29688:	76 11                	jbe    2969b <JS_CallInternal+0x6afb>
   2968a:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   2968d:	83 e8 01             	sub    eax,0x1
   29690:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   29693:	85 c0                	test   eax,eax
   29695:	0f 8e 87 2a 00 00    	jle    2c122 <JS_CallInternal+0x9582>
   2969b:	48 8b 73 d0          	mov    rsi,QWORD PTR [rbx-0x30]
   2969f:	48 8b 53 d8          	mov    rdx,QWORD PTR [rbx-0x28]
   296a3:	b9 01 00 00 00       	mov    ecx,0x1
   296a8:	4c 89 eb             	mov    rbx,r13
   296ab:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   296b2:	e8 19 7d 00 00       	call   313d0 <JS_IteratorClose>
   296b7:	e9 21 9e ff ff       	jmp    234dd <JS_CallInternal+0x93d>
   296bc:	83 fa 08             	cmp    edx,0x8
   296bf:	0f 85 5b 0c 00 00    	jne    2a320 <JS_CallInternal+0x7780>
   296c5:	66 48 0f 6e c0       	movq   xmm0,rax
   296ca:	66 0f 57 05 ce 13 0b 	xorpd  xmm0,XMMWORD PTR [rip+0xb13ce]        # daaa0 <typed_array_size_log2+0x28>
   296d1:	00 
   296d2:	48 c7 43 f8 08 00 00 	mov    QWORD PTR [rbx-0x8],0x8
   296d9:	00 
   296da:	f2 0f 11 43 f0       	movsd  QWORD PTR [rbx-0x10],xmm0
   296df:	e9 18 de ff ff       	jmp    274fc <JS_CallInternal+0x495c>
   296e4:	85 c0                	test   eax,eax
   296e6:	0f 84 2c b9 ff ff    	je     25018 <JS_CallInternal+0x2478>
   296ec:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   296f3:	48 8b 73 f0          	mov    rsi,QWORD PTR [rbx-0x10]
   296f7:	b9 01 00 00 00       	mov    ecx,0x1
   296fc:	48 8b 53 f8          	mov    rdx,QWORD PTR [rbx-0x8]
   29700:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   29707:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   2970b:	e8 e0 6b 01 00       	call   402f0 <JS_ToStringInternal>
   29710:	48 89 c1             	mov    rcx,rax
   29713:	49 89 d5             	mov    r13,rdx
   29716:	83 fa 06             	cmp    edx,0x6
   29719:	0f 84 21 9c ff ff    	je     23340 <JS_CallInternal+0x7a0>
   2971f:	48 8b 53 f8          	mov    rdx,QWORD PTR [rbx-0x8]
   29723:	48 8b 73 f0          	mov    rsi,QWORD PTR [rbx-0x10]
   29727:	83 fa f6             	cmp    edx,0xfffffff6
   2972a:	76 11                	jbe    2973d <JS_CallInternal+0x6b9d>
   2972c:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   2972f:	83 e8 01             	sub    eax,0x1
   29732:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   29735:	85 c0                	test   eax,eax
   29737:	0f 8e b5 29 00 00    	jle    2c0f2 <JS_CallInternal+0x9552>
   2973d:	48 89 4b f0          	mov    QWORD PTR [rbx-0x10],rcx
   29741:	4c 89 6b f8          	mov    QWORD PTR [rbx-0x8],r13
   29745:	e9 ce b8 ff ff       	jmp    25018 <JS_CallInternal+0x2478>
   2974a:	48 8b 73 e0          	mov    rsi,QWORD PTR [rbx-0x20]
   2974e:	48 8b 53 e8          	mov    rdx,QWORD PTR [rbx-0x18]
   29752:	4c 89 e9             	mov    rcx,r13
   29755:	4d 89 f0             	mov    r8,r14
   29758:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2975f:	41 b9 01 00 00 00    	mov    r9d,0x1
   29765:	e8 06 31 01 00       	call   3c870 <JS_SetPrototypeInternal>
   2976a:	85 c0                	test   eax,eax
   2976c:	0f 89 8f dc ff ff    	jns    27401 <JS_CallInternal+0x4861>
   29772:	e9 c9 9b ff ff       	jmp    23340 <JS_CallInternal+0x7a0>
   29777:	66 0f 1f 84 00 00 00 	nop    WORD PTR [rax+rax*1+0x0]
   2977e:	00 00 
   29780:	41 83 fe 08          	cmp    r14d,0x8
   29784:	0f 85 ff 0b 00 00    	jne    2a389 <JS_CallInternal+0x77e9>
   2978a:	66 0f ef c0          	pxor   xmm0,xmm0
   2978e:	66 49 0f 6e cd       	movq   xmm1,r13
   29793:	31 c0                	xor    eax,eax
   29795:	f2 0f 2a c2          	cvtsi2sd xmm0,edx
   29799:	ba 01 00 00 00       	mov    edx,0x1
   2979e:	66 0f 2e c1          	ucomisd xmm0,xmm1
   297a2:	0f 9a c0             	setp   al
   297a5:	48 0f 45 c2          	cmovne rax,rdx
   297a9:	e9 48 e0 ff ff       	jmp    277f6 <JS_CallInternal+0x4c56>
   297ae:	41 83 f8 08          	cmp    r8d,0x8
   297b2:	0f 85 09 0b 00 00    	jne    2a2c1 <JS_CallInternal+0x7721>
   297b8:	66 0f ef c0          	pxor   xmm0,xmm0
   297bc:	66 49 0f 6e d1       	movq   xmm2,r9
   297c1:	31 c0                	xor    eax,eax
   297c3:	f2 41 0f 2a c6       	cvtsi2sd xmm0,r14d
   297c8:	66 0f 2e c2          	ucomisd xmm0,xmm2
   297cc:	0f 9b c0             	setnp  al
   297cf:	41 0f 45 c5          	cmovne eax,r13d
   297d3:	e9 85 d2 ff ff       	jmp    26a5d <JS_CallInternal+0x3ebd>
   297d8:	41 83 fe 08          	cmp    r14d,0x8
   297dc:	0f 85 be 0b 00 00    	jne    2a3a0 <JS_CallInternal+0x7800>
   297e2:	66 0f ef c0          	pxor   xmm0,xmm0
   297e6:	66 49 0f 6e ed       	movq   xmm5,r13
   297eb:	31 c0                	xor    eax,eax
   297ed:	f2 0f 2a c2          	cvtsi2sd xmm0,edx
   297f1:	ba 00 00 00 00       	mov    edx,0x0
   297f6:	66 0f 2e c5          	ucomisd xmm0,xmm5
   297fa:	0f 9b c0             	setnp  al
   297fd:	48 0f 45 c2          	cmovne rax,rdx
   29801:	e9 44 e0 ff ff       	jmp    2784a <JS_CallInternal+0x4caa>
   29806:	41 83 f8 08          	cmp    r8d,0x8
   2980a:	0f 85 e0 0a 00 00    	jne    2a2f0 <JS_CallInternal+0x7750>
   29810:	66 0f ef c0          	pxor   xmm0,xmm0
   29814:	66 49 0f 6e f1       	movq   xmm6,r9
   29819:	ba 00 00 00 00       	mov    edx,0x0
   2981e:	f2 41 0f 2a c6       	cvtsi2sd xmm0,r14d
   29823:	66 0f 2e c6          	ucomisd xmm0,xmm6
   29827:	0f 9b c0             	setnp  al
   2982a:	0f 45 c2             	cmovne eax,edx
   2982d:	e9 8b d2 ff ff       	jmp    26abd <JS_CallInternal+0x3f1d>
   29832:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   29839:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2983d:	e8 2e 31 ff ff       	call   1c970 <__JS_FreeValueRT>
   29842:	e9 95 b6 ff ff       	jmp    24edc <JS_CallInternal+0x233c>
   29847:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   2984e:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   29855:	44 89 ea             	mov    edx,r13d
   29858:	48 89 de             	mov    rsi,rbx
   2985b:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   2985f:	e8 cc c2 02 00       	call   55b30 <js_post_inc_slow>
   29864:	85 c0                	test   eax,eax
   29866:	0f 84 d8 da ff ff    	je     27344 <JS_CallInternal+0x47a4>
   2986c:	e9 cf 9a ff ff       	jmp    23340 <JS_CallInternal+0x7a0>
   29871:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]
   29878:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   2987f:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   29886:	44 89 ea             	mov    edx,r13d
   29889:	48 89 de             	mov    rsi,rbx
   2988c:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   29890:	e8 fb bd 02 00       	call   55690 <js_unary_arith_slow>
   29895:	85 c0                	test   eax,eax
   29897:	0f 84 cf d4 ff ff    	je     26d6c <JS_CallInternal+0x41cc>
   2989d:	e9 9e 9a ff ff       	jmp    23340 <JS_CallInternal+0x7a0>
   298a2:	66 0f 1f 44 00 00    	nop    WORD PTR [rax+rax*1+0x0]
   298a8:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   298af:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   298b6:	44 89 ea             	mov    edx,r13d
   298b9:	48 89 de             	mov    rsi,rbx
   298bc:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   298c0:	e8 cb bd 02 00       	call   55690 <js_unary_arith_slow>
   298c5:	85 c0                	test   eax,eax
   298c7:	0f 84 5e d4 ff ff    	je     26d2b <JS_CallInternal+0x418b>
   298cd:	e9 6e 9a ff ff       	jmp    23340 <JS_CallInternal+0x7a0>
   298d2:	66 0f 1f 44 00 00    	nop    WORD PTR [rax+rax*1+0x0]
   298d8:	41 83 e6 02          	and    r14d,0x2
   298dc:	48 8d 4b c0          	lea    rcx,[rbx-0x40]
   298e0:	48 8b 73 c0          	mov    rsi,QWORD PTR [rbx-0x40]
   298e4:	4c 8b 41 08          	mov    r8,QWORD PTR [rcx+0x8]
   298e8:	0f 84 b5 0b 00 00    	je     2a4a3 <JS_CallInternal+0x7903>
   298ee:	48 83 ec 08          	sub    rsp,0x8
   298f2:	45 31 c9             	xor    r9d,r9d
   298f5:	6a 00                	push   0x0
   298f7:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   298fe:	48 89 f1             	mov    rcx,rsi
   29901:	48 89 c6             	mov    rsi,rax
   29904:	e8 97 38 00 00       	call   2d1a0 <JS_CallFree>
   29909:	49 89 d6             	mov    r14,rdx
   2990c:	48 89 c1             	mov    rcx,rax
   2990f:	58                   	pop    rax
   29910:	5a                   	pop    rdx
   29911:	41 83 fe 06          	cmp    r14d,0x6
   29915:	0f 84 c3 0c 00 00    	je     2a5de <JS_CallInternal+0x7a3e>
   2991b:	48 8b 53 f8          	mov    rdx,QWORD PTR [rbx-0x8]
   2991f:	48 8b 73 f0          	mov    rsi,QWORD PTR [rbx-0x10]
   29923:	83 fa f6             	cmp    edx,0xfffffff6
   29926:	76 11                	jbe    29939 <JS_CallInternal+0x6d99>
   29928:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   2992b:	83 e8 01             	sub    eax,0x1
   2992e:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   29931:	85 c0                	test   eax,eax
   29933:	0f 8e a7 26 00 00    	jle    2bfe0 <JS_CallInternal+0x9440>
   29939:	48 89 4b f0          	mov    QWORD PTR [rbx-0x10],rcx
   2993d:	31 c9                	xor    ecx,ecx
   2993f:	4c 89 73 f8          	mov    QWORD PTR [rbx-0x8],r14
   29943:	e9 3d ef ff ff       	jmp    28885 <JS_CallInternal+0x5ce5>
   29948:	48 8b 73 e0          	mov    rsi,QWORD PTR [rbx-0x20]
   2994c:	48 8b 53 e8          	mov    rdx,QWORD PTR [rbx-0x18]
   29950:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   29957:	e8 74 a5 01 00       	call   43ed0 <JS_ValueToAtom>
   2995c:	89 85 50 fe ff ff    	mov    DWORD PTR [rbp-0x1b0],eax
   29962:	85 c0                	test   eax,eax
   29964:	0f 84 d6 99 ff ff    	je     23340 <JS_CallInternal+0x7a0>
   2996a:	4d 89 e5             	mov    r13,r12
   2996d:	e9 5c 9f ff ff       	jmp    238ce <JS_CallInternal+0xd2e>
   29972:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   29979:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   29980:	44 89 ea             	mov    edx,r13d
   29983:	48 89 de             	mov    rsi,rbx
   29986:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   2998a:	e8 a1 c1 02 00       	call   55b30 <js_post_inc_slow>
   2998f:	85 c0                	test   eax,eax
   29991:	0f 84 4f d3 ff ff    	je     26ce6 <JS_CallInternal+0x4146>
   29997:	e9 a4 99 ff ff       	jmp    23340 <JS_CallInternal+0x7a0>
   2999c:	0f 1f 40 00          	nop    DWORD PTR [rax+0x0]
   299a0:	4c 89 c6             	mov    rsi,r8
   299a3:	48 89 df             	mov    rdi,rbx
   299a6:	48 89 8d 10 fe ff ff 	mov    QWORD PTR [rbp-0x1f0],rcx
   299ad:	4c 89 85 28 fe ff ff 	mov    QWORD PTR [rbp-0x1d8],r8
   299b4:	e8 d7 27 01 00       	call   3c190 <expand_fast_array>
   299b9:	4c 8b 85 28 fe ff ff 	mov    r8,QWORD PTR [rbp-0x1d8]
   299c0:	48 8b 8d 10 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x1f0]
   299c7:	85 c0                	test   eax,eax
   299c9:	0f 88 75 27 00 00    	js     2c144 <JS_CallInternal+0x95a4>
   299cf:	8b 85 50 fe ff ff    	mov    eax,DWORD PTR [rbp-0x1b0]
   299d5:	41 89 40 38          	mov    DWORD PTR [r8+0x38],eax
   299d9:	31 c0                	xor    eax,eax
   299db:	0f 1f 44 00 00       	nop    DWORD PTR [rax+rax*1+0x0]
   299e0:	f3 41 0f 6f 5c 05 00 	movdqu xmm3,XMMWORD PTR [r13+rax*1+0x0]
   299e7:	49 8b 50 30          	mov    rdx,QWORD PTR [r8+0x30]
   299eb:	0f 11 1c 02          	movups XMMWORD PTR [rdx+rax*1],xmm3
   299ef:	48 83 c0 10          	add    rax,0x10
   299f3:	4c 39 f0             	cmp    rax,r14
   299f6:	75 e8                	jne    299e0 <JS_CallInternal+0x6e40>
   299f8:	49 8b 40 20          	mov    rax,QWORD PTR [r8+0x20]
   299fc:	48 8b 9d 40 fe ff ff 	mov    rbx,QWORD PTR [rbp-0x1c0]
   29a03:	48 8b 50 08          	mov    rdx,QWORD PTR [rax+0x8]
   29a07:	48 8b 30             	mov    rsi,QWORD PTR [rax]
   29a0a:	48 c7 40 08 00 00 00 	mov    QWORD PTR [rax+0x8],0x0
   29a11:	00 
   29a12:	48 89 18             	mov    QWORD PTR [rax],rbx
   29a15:	83 fa f6             	cmp    edx,0xfffffff6
   29a18:	0f 86 cd a5 ff ff    	jbe    23feb <JS_CallInternal+0x144b>
   29a1e:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   29a21:	83 e8 01             	sub    eax,0x1
   29a24:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   29a27:	85 c0                	test   eax,eax
   29a29:	0f 8f bc a5 ff ff    	jg     23feb <JS_CallInternal+0x144b>
   29a2f:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   29a36:	48 89 8d 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],rcx
   29a3d:	4c 89 85 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],r8
   29a44:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   29a48:	e8 23 2f ff ff       	call   1c970 <__JS_FreeValueRT>
   29a4d:	48 8b 8d 40 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x1c0]
   29a54:	4c 8b 85 50 fe ff ff 	mov    r8,QWORD PTR [rbp-0x1b0]
   29a5b:	e9 8b a5 ff ff       	jmp    23feb <JS_CallInternal+0x144b>
   29a60:	48 8b bd d8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x128]
   29a67:	48 03 77 30          	add    rsi,QWORD PTR [rdi+0x30]
   29a6b:	80 7a 11 00          	cmp    BYTE PTR [rdx+0x11],0x0
   29a6f:	0f 84 e4 0d 00 00    	je     2a859 <JS_CallInternal+0x7cb9>
   29a75:	41 83 fd 3a          	cmp    r13d,0x3a
   29a79:	0f 84 82 9d ff ff    	je     23801 <JS_CallInternal+0xc61>
   29a7f:	8b 76 04             	mov    esi,DWORD PTR [rsi+0x4]
   29a82:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   29a89:	83 f9 04             	cmp    ecx,0x4
   29a8c:	0f 84 ba 36 00 00    	je     2d14c <JS_CallInternal+0xa5ac>
   29a92:	e8 a9 8a 00 00       	call   32540 <JS_ThrowTypeErrorReadOnly.part.0>
   29a97:	4d 89 f4             	mov    r12,r14
   29a9a:	e9 a1 98 ff ff       	jmp    23340 <JS_CallInternal+0x7a0>
   29a9f:	90                   	nop
   29aa0:	66 0f ef c0          	pxor   xmm0,xmm0
   29aa4:	f2 48 0f 2a c0       	cvtsi2sd xmm0,rax
   29aa9:	b8 08 00 00 00       	mov    eax,0x8
   29aae:	e9 ac ce ff ff       	jmp    2695f <JS_CallInternal+0x3dbf>
   29ab3:	48 8b 8d 50 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x1b0]
   29aba:	4d 89 f0             	mov    r8,r14
   29abd:	4c 89 ce             	mov    rsi,r9
   29ac0:	4c 89 ea             	mov    rdx,r13
   29ac3:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   29aca:	4c 89 8d 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],r9
   29ad1:	e8 2a 7c 00 00       	call   31700 <JS_CheckBrand>
   29ad6:	85 c0                	test   eax,eax
   29ad8:	0f 88 62 98 ff ff    	js     23340 <JS_CallInternal+0x7a0>
   29ade:	4c 8b 8d 40 fe ff ff 	mov    r9,QWORD PTR [rbp-0x1c0]
   29ae5:	0f 95 c0             	setne  al
   29ae8:	e9 e5 d3 ff ff       	jmp    26ed2 <JS_CallInternal+0x4332>
   29aed:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   29af4:	48 89 fa             	mov    rdx,rdi
   29af7:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   29afe:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   29b02:	e8 79 3d 00 00       	call   2d880 <JS_GetPropertyValue>
   29b07:	48 89 c1             	mov    rcx,rax
   29b0a:	48 89 d0             	mov    rax,rdx
   29b0d:	83 fa 06             	cmp    edx,0x6
   29b10:	0f 85 f4 bc ff ff    	jne    2580a <JS_CallInternal+0x2c6a>
   29b16:	48 83 eb 10          	sub    rbx,0x10
   29b1a:	e9 21 98 ff ff       	jmp    23340 <JS_CallInternal+0x7a0>
   29b1f:	31 c0                	xor    eax,eax
   29b21:	e9 ab ca ff ff       	jmp    265d1 <JS_CallInternal+0x3a31>
   29b26:	31 c9                	xor    ecx,ecx
   29b28:	41 b8 03 00 00 00    	mov    r8d,0x3
   29b2e:	e9 c8 a9 ff ff       	jmp    244fb <JS_CallInternal+0x195b>
   29b33:	41 8b 30             	mov    esi,DWORD PTR [r8]
   29b36:	81 e6 ff ff ff 03    	and    esi,0x3ffffff
   29b3c:	0f 85 65 df ff ff    	jne    27aa7 <JS_CallInternal+0x4f07>
   29b42:	48 83 ec 08          	sub    rsp,0x8
   29b46:	4c 8b 43 f0          	mov    r8,QWORD PTR [rbx-0x10]
   29b4a:	4c 8b 4b f8          	mov    r9,QWORD PTR [rbx-0x8]
   29b4e:	48 89 c6             	mov    rsi,rax
   29b51:	48 8b bd c8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x138]
   29b58:	4c 89 95 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],r10
   29b5f:	4c 89 57 30          	mov    QWORD PTR [rdi+0x30],r10
   29b63:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   29b6a:	68 00 80 00 00       	push   0x8000
   29b6f:	52                   	push   rdx
   29b70:	50                   	push   rax
   29b71:	e8 ca 43 00 00       	call   2df40 <JS_SetPropertyInternal>
   29b76:	48 83 c4 20          	add    rsp,0x20
   29b7a:	41 83 fe f6          	cmp    r14d,0xfffffff6
   29b7e:	4c 8b 95 50 fe ff ff 	mov    r10,QWORD PTR [rbp-0x1b0]
   29b85:	89 c1                	mov    ecx,eax
   29b87:	76 13                	jbe    29b9c <JS_CallInternal+0x6ffc>
   29b89:	41 8b 45 fc          	mov    eax,DWORD PTR [r13-0x4]
   29b8d:	83 e8 01             	sub    eax,0x1
   29b90:	41 89 45 fc          	mov    DWORD PTR [r13-0x4],eax
   29b94:	85 c0                	test   eax,eax
   29b96:	0f 8e eb 24 00 00    	jle    2c087 <JS_CallInternal+0x94e7>
   29b9c:	48 83 eb 20          	sub    rbx,0x20
   29ba0:	85 c9                	test   ecx,ecx
   29ba2:	0f 89 75 df ff ff    	jns    27b1d <JS_CallInternal+0x4f7d>
   29ba8:	4d 89 d4             	mov    r12,r10
   29bab:	e9 90 97 ff ff       	jmp    23340 <JS_CallInternal+0x7a0>
   29bb0:	8b 00                	mov    eax,DWORD PTR [rax]
   29bb2:	25 ff ff ff 03       	and    eax,0x3ffffff
   29bb7:	0f 85 c2 97 ff ff    	jne    2337f <JS_CallInternal+0x7df>
   29bbd:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   29bc4:	48 83 ec 08          	sub    rsp,0x8
   29bc8:	31 c9                	xor    ecx,ecx
   29bca:	45 31 c9             	xor    r9d,r9d
   29bcd:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   29bd4:	45 31 c0             	xor    r8d,r8d
   29bd7:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   29bdb:	48 8b 85 c0 fe ff ff 	mov    rax,QWORD PTR [rbp-0x140]
   29be2:	48 8b b0 d8 04 00 00 	mov    rsi,QWORD PTR [rax+0x4d8]
   29be9:	48 8b 90 e0 04 00 00 	mov    rdx,QWORD PTR [rax+0x4e0]
   29bf0:	6a 00                	push   0x0
   29bf2:	e8 c9 67 00 00       	call   303c0 <build_backtrace>
   29bf7:	59                   	pop    rcx
   29bf8:	5e                   	pop    rsi
   29bf9:	e9 92 97 ff ff       	jmp    23390 <JS_CallInternal+0x7f0>
   29bfe:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   29c05:	48 8d 7b f0          	lea    rdi,[rbx-0x10]
   29c09:	41 b9 00 80 00 00    	mov    r9d,0x8000
   29c0f:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   29c13:	48 8d 43 e0          	lea    rax,[rbx-0x20]
   29c17:	4c 8b 40 08          	mov    r8,QWORD PTR [rax+0x8]
   29c1b:	48 83 eb 30          	sub    rbx,0x30
   29c1f:	48 8b 33             	mov    rsi,QWORD PTR [rbx]
   29c22:	48 8b 53 08          	mov    rdx,QWORD PTR [rbx+0x8]
   29c26:	48 8b 08             	mov    rcx,QWORD PTR [rax]
   29c29:	ff 77 08             	push   QWORD PTR [rdi+0x8]
   29c2c:	ff 37                	push   QWORD PTR [rdi]
   29c2e:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   29c35:	e8 16 50 00 00       	call   2ec50 <JS_SetPropertyValue>
   29c3a:	48 8b 53 08          	mov    rdx,QWORD PTR [rbx+0x8]
   29c3e:	5f                   	pop    rdi
   29c3f:	48 8b 33             	mov    rsi,QWORD PTR [rbx]
   29c42:	41 89 c5             	mov    r13d,eax
   29c45:	41 58                	pop    r8
   29c47:	83 fa f6             	cmp    edx,0xfffffff6
   29c4a:	76 11                	jbe    29c5d <JS_CallInternal+0x70bd>
   29c4c:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   29c4f:	83 e8 01             	sub    eax,0x1
   29c52:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   29c55:	85 c0                	test   eax,eax
   29c57:	0f 8e 66 24 00 00    	jle    2c0c3 <JS_CallInternal+0x9523>
   29c5d:	45 85 ed             	test   r13d,r13d
   29c60:	0f 89 64 eb ff ff    	jns    287ca <JS_CallInternal+0x5c2a>
   29c66:	e9 d5 96 ff ff       	jmp    23340 <JS_CallInternal+0x7a0>
   29c6b:	0f 1f 44 00 00       	nop    DWORD PTR [rax+rax*1+0x0]
   29c70:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   29c77:	48 89 ca             	mov    rdx,rcx
   29c7a:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   29c7e:	4c 89 c0             	mov    rax,r8
   29c81:	49 89 f8             	mov    r8,rdi
   29c84:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   29c8b:	48 89 c1             	mov    rcx,rax
   29c8e:	e8 ed 3b 00 00       	call   2d880 <JS_GetPropertyValue>
   29c93:	48 89 c1             	mov    rcx,rax
   29c96:	48 89 d0             	mov    rax,rdx
   29c99:	48 89 ca             	mov    rdx,rcx
   29c9c:	83 f8 06             	cmp    eax,0x6
   29c9f:	0f 85 ad e8 ff ff    	jne    28552 <JS_CallInternal+0x59b2>
   29ca5:	45 31 c0             	xor    r8d,r8d
   29ca8:	48 c7 43 f8 03 00 00 	mov    QWORD PTR [rbx-0x8],0x3
   29caf:	00 
   29cb0:	4c 89 43 f0          	mov    QWORD PTR [rbx-0x10],r8
   29cb4:	e9 87 96 ff ff       	jmp    23340 <JS_CallInternal+0x7a0>
   29cb9:	49 8b 75 f0          	mov    rsi,QWORD PTR [r13-0x10]
   29cbd:	49 8b 55 f8          	mov    rdx,QWORD PTR [r13-0x8]
   29cc1:	41 b8 03 00 00 00    	mov    r8d,0x3
   29cc7:	31 c9                	xor    ecx,ecx
   29cc9:	44 8b 8d 50 fe ff ff 	mov    r9d,DWORD PTR [rbp-0x1b0]
   29cd0:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   29cd7:	48 c7 85 90 fd ff ff 	mov    QWORD PTR [rbp-0x270],0x0
   29cde:	00 00 00 00 
   29ce2:	48 c7 85 98 fd ff ff 	mov    QWORD PTR [rbp-0x268],0x3
   29ce9:	03 00 00 00 
   29ced:	6a 00                	push   0x0
   29cef:	41 55                	push   r13
   29cf1:	ff b5 98 fd ff ff    	push   QWORD PTR [rbp-0x268]
   29cf7:	ff b5 90 fd ff ff    	push   QWORD PTR [rbp-0x270]
   29cfd:	e8 9e 8e ff ff       	call   22ba0 <JS_CallInternal>
   29d02:	48 83 c4 20          	add    rsp,0x20
   29d06:	49 89 c1             	mov    r9,rax
   29d09:	49 89 d0             	mov    r8,rdx
   29d0c:	e9 1a a8 ff ff       	jmp    2452b <JS_CallInternal+0x198b>
   29d11:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   29d18:	48 89 ce             	mov    rsi,rcx
   29d1b:	e8 80 4e ff ff       	call   1eba0 <JS_ToBoolFree>
   29d20:	e9 c6 f0 ff ff       	jmp    28deb <JS_CallInternal+0x624b>
   29d25:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   29d2c:	48 89 ce             	mov    rsi,rcx
   29d2f:	e8 6c 4e ff ff       	call   1eba0 <JS_ToBoolFree>
   29d34:	e9 dd dc ff ff       	jmp    27a16 <JS_CallInternal+0x4e76>
   29d39:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   29d40:	48 89 d6             	mov    rsi,rdx
   29d43:	48 89 c2             	mov    rdx,rax
   29d46:	e8 55 4e ff ff       	call   1eba0 <JS_ToBoolFree>
   29d4b:	e9 a9 ea ff ff       	jmp    287f9 <JS_CallInternal+0x5c59>
   29d50:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   29d57:	48 89 ce             	mov    rsi,rcx
   29d5a:	e8 41 4e ff ff       	call   1eba0 <JS_ToBoolFree>
   29d5f:	e9 c8 eb ff ff       	jmp    2892c <JS_CallInternal+0x5d8c>
   29d64:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   29d6b:	48 89 ce             	mov    rsi,rcx
   29d6e:	e8 2d 4e ff ff       	call   1eba0 <JS_ToBoolFree>
   29d73:	e9 4d eb ff ff       	jmp    288c5 <JS_CallInternal+0x5d25>
   29d78:	31 c9                	xor    ecx,ecx
   29d7a:	41 b8 03 00 00 00    	mov    r8d,0x3
   29d80:	e9 26 a6 ff ff       	jmp    243ab <JS_CallInternal+0x180b>
   29d85:	48 8b b5 28 fe ff ff 	mov    rsi,QWORD PTR [rbp-0x1d8]
   29d8c:	45 89 d1             	mov    r9d,r10d
   29d8f:	4c 89 ea             	mov    rdx,r13
   29d92:	31 c9                	xor    ecx,ecx
   29d94:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   29d9b:	41 b8 03 00 00 00    	mov    r8d,0x3
   29da1:	48 c7 85 a0 fd ff ff 	mov    QWORD PTR [rbp-0x260],0x0
   29da8:	00 00 00 00 
   29dac:	48 c7 85 a8 fd ff ff 	mov    QWORD PTR [rbp-0x258],0x3
   29db3:	03 00 00 00 
   29db7:	6a 02                	push   0x2
   29db9:	41 56                	push   r14
   29dbb:	ff b5 a8 fd ff ff    	push   QWORD PTR [rbp-0x258]
   29dc1:	ff b5 a0 fd ff ff    	push   QWORD PTR [rbp-0x260]
   29dc7:	44 89 95 38 fe ff ff 	mov    DWORD PTR [rbp-0x1c8],r10d
   29dce:	e8 cd 8d ff ff       	call   22ba0 <JS_CallInternal>
   29dd3:	44 8b 95 38 fe ff ff 	mov    r10d,DWORD PTR [rbp-0x1c8]
   29dda:	48 83 c4 20          	add    rsp,0x20
   29dde:	48 89 85 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],rax
   29de5:	49 89 d5             	mov    r13,rdx
   29de8:	e9 00 a6 ff ff       	jmp    243ed <JS_CallInternal+0x184d>
   29ded:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   29df4:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   29dfb:	48 89 de             	mov    rsi,rbx
   29dfe:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   29e02:	e8 99 bd 02 00       	call   55ba0 <js_not_slow>
   29e07:	85 c0                	test   eax,eax
   29e09:	0f 84 cd cb ff ff    	je     269dc <JS_CallInternal+0x3e3c>
   29e0f:	e9 2c 95 ff ff       	jmp    23340 <JS_CallInternal+0x7a0>
   29e14:	0f 1f 40 00          	nop    DWORD PTR [rax+0x0]
   29e18:	4d 39 0e             	cmp    QWORD PTR [r14],r9
   29e1b:	0f 85 3d a3 ff ff    	jne    2415e <JS_CallInternal+0x15be>
   29e21:	41 8b 76 10          	mov    esi,DWORD PTR [r14+0x10]
   29e25:	83 fe ff             	cmp    esi,0xffffffff
   29e28:	0f 84 30 a3 ff ff    	je     2415e <JS_CallInternal+0x15be>
   29e2e:	49 8b 4e 08          	mov    rcx,QWORD PTR [r14+0x8]
   29e32:	48 85 c9             	test   rcx,rcx
   29e35:	0f 84 09 33 00 00    	je     2d144 <JS_CallInternal+0xa5a4>
   29e3b:	49 8b 41 30          	mov    rax,QWORD PTR [r9+0x30]
   29e3f:	48 85 c0             	test   rax,rax
   29e42:	0f 84 16 a3 ff ff    	je     2415e <JS_CallInternal+0x15be>
   29e48:	8b 50 10             	mov    edx,DWORD PTR [rax+0x10]
   29e4b:	81 e2 08 00 ff ff    	and    edx,0xffff0008
   29e51:	81 fa 00 00 01 00    	cmp    edx,0x10000
   29e57:	0f 85 01 a3 ff ff    	jne    2415e <JS_CallInternal+0x15be>
   29e5d:	48 3b 48 18          	cmp    rcx,QWORD PTR [rax+0x18]
   29e61:	0f 85 f7 a2 ff ff    	jne    2415e <JS_CallInternal+0x15be>
   29e67:	89 f2                	mov    edx,esi
   29e69:	48 c1 e2 04          	shl    rdx,0x4
   29e6d:	48 03 50 20          	add    rdx,QWORD PTR [rax+0x20]
   29e71:	48 8b 42 08          	mov    rax,QWORD PTR [rdx+0x8]
   29e75:	4c 8b 2a             	mov    r13,QWORD PTR [rdx]
   29e78:	83 f8 f6             	cmp    eax,0xfffffff6
   29e7b:	76 05                	jbe    29e82 <JS_CallInternal+0x72e2>
   29e7d:	41 83 45 fc 01       	add    DWORD PTR [r13-0x4],0x1
   29e82:	48 8d 4b f0          	lea    rcx,[rbx-0x10]
   29e86:	48 89 8d 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],rcx
   29e8d:	e9 64 a3 ff ff       	jmp    241f6 <JS_CallInternal+0x1656>
   29e92:	66 0f 1f 44 00 00    	nop    WORD PTR [rax+rax*1+0x0]
   29e98:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   29e9f:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   29ea3:	89 c8                	mov    eax,ecx
   29ea5:	48 8b 97 48 04 00 00 	mov    rdx,QWORD PTR [rdi+0x448]
   29eac:	48 8b 34 c2          	mov    rsi,QWORD PTR [rdx+rax*8]
   29eb0:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   29eb3:	83 e8 01             	sub    eax,0x1
   29eb6:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   29eb9:	85 c0                	test   eax,eax
   29ebb:	0f 8f d9 b2 ff ff    	jg     2519a <JS_CallInternal+0x25fa>
   29ec1:	44 89 85 38 fe ff ff 	mov    DWORD PTR [rbp-0x1c8],r8d
   29ec8:	e8 73 b5 fe ff       	call   15440 <JS_FreeAtomStruct>
   29ecd:	44 8b 85 38 fe ff ff 	mov    r8d,DWORD PTR [rbp-0x1c8]
   29ed4:	e9 c1 b2 ff ff       	jmp    2519a <JS_CallInternal+0x25fa>
   29ed9:	c7 85 f0 fe ff ff ff 	mov    DWORD PTR [rbp-0x110],0xffffffff
   29ee0:	ff ff ff 
   29ee3:	b9 ff ff ff ff       	mov    ecx,0xffffffff
   29ee8:	4d 8b 45 08          	mov    r8,QWORD PTR [r13+0x8]
   29eec:	49 8b 75 00          	mov    rsi,QWORD PTR [r13+0x0]
   29ef0:	41 83 f8 f6          	cmp    r8d,0xfffffff6
   29ef4:	76 11                	jbe    29f07 <JS_CallInternal+0x7367>
   29ef6:	8b 7e fc             	mov    edi,DWORD PTR [rsi-0x4]
   29ef9:	8d 57 ff             	lea    edx,[rdi-0x1]
   29efc:	89 56 fc             	mov    DWORD PTR [rsi-0x4],edx
   29eff:	85 d2                	test   edx,edx
   29f01:	0f 8e f4 22 00 00    	jle    2c1fb <JS_CallInternal+0x965b>
   29f07:	49 c7 45 00 00 00 00 	mov    QWORD PTR [r13+0x0],0x0
   29f0e:	00 
   29f0f:	49 c7 45 08 03 00 00 	mov    QWORD PTR [r13+0x8],0x3
   29f16:	00 
   29f17:	85 c9                	test   ecx,ecx
   29f19:	0f 88 b1 31 00 00    	js     2d0d0 <JS_CallInternal+0xa530>
   29f1f:	41 83 f9 f6          	cmp    r9d,0xfffffff6
   29f23:	76 11                	jbe    29f36 <JS_CallInternal+0x7396>
   29f25:	8b 48 fc             	mov    ecx,DWORD PTR [rax-0x4]
   29f28:	8d 51 ff             	lea    edx,[rcx-0x1]
   29f2b:	89 50 fc             	mov    DWORD PTR [rax-0x4],edx
   29f2e:	85 d2                	test   edx,edx
   29f30:	0f 8e 05 23 00 00    	jle    2c23b <JS_CallInternal+0x969b>
   29f36:	44 8b 85 f0 fe ff ff 	mov    r8d,DWORD PTR [rbp-0x110]
   29f3d:	31 d2                	xor    edx,edx
   29f3f:	be 03 00 00 00       	mov    esi,0x3
   29f44:	45 85 c0             	test   r8d,r8d
   29f47:	0f 95 c2             	setne  dl
   29f4a:	31 ff                	xor    edi,edi
   29f4c:	e9 71 ed ff ff       	jmp    28cc2 <JS_CallInternal+0x6122>
   29f51:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   29f58:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   29f5c:	48 8b 87 48 04 00 00 	mov    rax,QWORD PTR [rdi+0x448]
   29f63:	4a 8b 34 e8          	mov    rsi,QWORD PTR [rax+r13*8]
   29f67:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   29f6a:	83 e8 01             	sub    eax,0x1
   29f6d:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   29f70:	85 c0                	test   eax,eax
   29f72:	0f 8f 52 de ff ff    	jg     27dca <JS_CallInternal+0x522a>
   29f78:	e8 c3 b4 fe ff       	call   15440 <JS_FreeAtomStruct>
   29f7d:	4c 8b 95 40 fe ff ff 	mov    r10,QWORD PTR [rbp-0x1c0]
   29f84:	e9 41 de ff ff       	jmp    27dca <JS_CallInternal+0x522a>
   29f89:	41 83 fd fa          	cmp    r13d,0xfffffffa
   29f8d:	7d 06                	jge    29f95 <JS_CallInternal+0x73f5>
   29f8f:	41 83 fd f8          	cmp    r13d,0xfffffff8
   29f93:	7d 59                	jge    29fee <JS_CallInternal+0x744e>
   29f95:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   29f9c:	48 8b 73 f0          	mov    rsi,QWORD PTR [rbx-0x10]
   29fa0:	b9 01 00 00 00       	mov    ecx,0x1
   29fa5:	48 8b 53 f8          	mov    rdx,QWORD PTR [rbx-0x8]
   29fa9:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   29fb0:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   29fb4:	e8 37 63 01 00       	call   402f0 <JS_ToStringInternal>
   29fb9:	49 89 d0             	mov    r8,rdx
   29fbc:	49 89 d5             	mov    r13,rdx
   29fbf:	83 fa 06             	cmp    edx,0x6
   29fc2:	0f 84 78 93 ff ff    	je     23340 <JS_CallInternal+0x7a0>
   29fc8:	48 8b 53 f8          	mov    rdx,QWORD PTR [rbx-0x8]
   29fcc:	48 8b 73 f0          	mov    rsi,QWORD PTR [rbx-0x10]
   29fd0:	83 fa f6             	cmp    edx,0xfffffff6
   29fd3:	76 11                	jbe    29fe6 <JS_CallInternal+0x7446>
   29fd5:	8b 4e fc             	mov    ecx,DWORD PTR [rsi-0x4]
   29fd8:	83 e9 01             	sub    ecx,0x1
   29fdb:	89 4e fc             	mov    DWORD PTR [rsi-0x4],ecx
   29fde:	85 c9                	test   ecx,ecx
   29fe0:	0f 8e 0c 2d 00 00    	jle    2ccf2 <JS_CallInternal+0xa152>
   29fe6:	48 89 43 f0          	mov    QWORD PTR [rbx-0x10],rax
   29fea:	4c 89 43 f8          	mov    QWORD PTR [rbx-0x8],r8
   29fee:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   29ff5:	48 8b 4b f0          	mov    rcx,QWORD PTR [rbx-0x10]
   29ff9:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   29ffd:	41 83 fd f6          	cmp    r13d,0xfffffff6
   2a001:	76 04                	jbe    2a007 <JS_CallInternal+0x7467>
   2a003:	83 41 fc 01          	add    DWORD PTR [rcx-0x4],0x1
   2a007:	48 8b 73 e0          	mov    rsi,QWORD PTR [rbx-0x20]
   2a00b:	48 8b 53 e8          	mov    rdx,QWORD PTR [rbx-0x18]
   2a00f:	4d 89 e8             	mov    r8,r13
   2a012:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2a019:	e8 62 38 00 00       	call   2d880 <JS_GetPropertyValue>
   2a01e:	48 89 c1             	mov    rcx,rax
   2a021:	48 89 d0             	mov    rax,rdx
   2a024:	83 fa 06             	cmp    edx,0x6
   2a027:	0f 85 b1 e4 ff ff    	jne    284de <JS_CallInternal+0x593e>
   2a02d:	e9 0e 93 ff ff       	jmp    23340 <JS_CallInternal+0x7a0>
   2a032:	48 8b 8d e8 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x118]
   2a039:	48 8b 79 10          	mov    rdi,QWORD PTR [rcx+0x10]
   2a03d:	48 8b 97 48 04 00 00 	mov    rdx,QWORD PTR [rdi+0x448]
   2a044:	4a 8b 34 ea          	mov    rsi,QWORD PTR [rdx+r13*8]
   2a048:	8b 4e fc             	mov    ecx,DWORD PTR [rsi-0x4]
   2a04b:	8d 51 ff             	lea    edx,[rcx-0x1]
   2a04e:	89 56 fc             	mov    DWORD PTR [rsi-0x4],edx
   2a051:	85 d2                	test   edx,edx
   2a053:	0f 8f a2 e5 ff ff    	jg     285fb <JS_CallInternal+0x5a5b>
   2a059:	48 89 85 28 fe ff ff 	mov    QWORD PTR [rbp-0x1d8],rax
   2a060:	e8 db b3 fe ff       	call   15440 <JS_FreeAtomStruct>
   2a065:	48 8b 85 28 fe ff ff 	mov    rax,QWORD PTR [rbp-0x1d8]
   2a06c:	4c 8b 95 38 fe ff ff 	mov    r10,QWORD PTR [rbp-0x1c8]
   2a073:	e9 83 e5 ff ff       	jmp    285fb <JS_CallInternal+0x5a5b>
   2a078:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a07f:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a083:	89 c8                	mov    eax,ecx
   2a085:	48 8b 97 48 04 00 00 	mov    rdx,QWORD PTR [rdi+0x448]
   2a08c:	48 8b 34 c2          	mov    rsi,QWORD PTR [rdx+rax*8]
   2a090:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   2a093:	83 e8 01             	sub    eax,0x1
   2a096:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   2a099:	85 c0                	test   eax,eax
   2a09b:	0f 8f 1c cf ff ff    	jg     26fbd <JS_CallInternal+0x441d>
   2a0a1:	44 89 85 38 fe ff ff 	mov    DWORD PTR [rbp-0x1c8],r8d
   2a0a8:	e8 93 b3 fe ff       	call   15440 <JS_FreeAtomStruct>
   2a0ad:	44 8b 85 38 fe ff ff 	mov    r8d,DWORD PTR [rbp-0x1c8]
   2a0b4:	e9 04 cf ff ff       	jmp    26fbd <JS_CallInternal+0x441d>
   2a0b9:	4d 39 0e             	cmp    QWORD PTR [r14],r9
   2a0bc:	0f 85 9d 9f ff ff    	jne    2405f <JS_CallInternal+0x14bf>
   2a0c2:	41 8b 76 10          	mov    esi,DWORD PTR [r14+0x10]
   2a0c6:	83 fe ff             	cmp    esi,0xffffffff
   2a0c9:	0f 84 90 9f ff ff    	je     2405f <JS_CallInternal+0x14bf>
   2a0cf:	49 8b 4e 08          	mov    rcx,QWORD PTR [r14+0x8]
   2a0d3:	48 85 c9             	test   rcx,rcx
   2a0d6:	0f 84 10 2d 00 00    	je     2cdec <JS_CallInternal+0xa24c>
   2a0dc:	49 8b 41 30          	mov    rax,QWORD PTR [r9+0x30]
   2a0e0:	48 85 c0             	test   rax,rax
   2a0e3:	0f 84 76 9f ff ff    	je     2405f <JS_CallInternal+0x14bf>
   2a0e9:	8b 50 10             	mov    edx,DWORD PTR [rax+0x10]
   2a0ec:	81 e2 08 00 ff ff    	and    edx,0xffff0008
   2a0f2:	81 fa 00 00 01 00    	cmp    edx,0x10000
   2a0f8:	0f 85 61 9f ff ff    	jne    2405f <JS_CallInternal+0x14bf>
   2a0fe:	48 3b 48 18          	cmp    rcx,QWORD PTR [rax+0x18]
   2a102:	0f 85 57 9f ff ff    	jne    2405f <JS_CallInternal+0x14bf>
   2a108:	89 f2                	mov    edx,esi
   2a10a:	48 c1 e2 04          	shl    rdx,0x4
   2a10e:	48 03 50 20          	add    rdx,QWORD PTR [rax+0x20]
   2a112:	48 8b 4a 08          	mov    rcx,QWORD PTR [rdx+0x8]
   2a116:	48 8b 02             	mov    rax,QWORD PTR [rdx]
   2a119:	83 f9 f6             	cmp    ecx,0xfffffff6
   2a11c:	0f 86 c9 9f ff ff    	jbe    240eb <JS_CallInternal+0x154b>
   2a122:	83 40 fc 01          	add    DWORD PTR [rax-0x4],0x1
   2a126:	e9 c0 9f ff ff       	jmp    240eb <JS_CallInternal+0x154b>
   2a12b:	0f 1f 44 00 00       	nop    DWORD PTR [rax+rax*1+0x0]
   2a130:	8b 08                	mov    ecx,DWORD PTR [rax]
   2a132:	81 e1 ff ff ff 03    	and    ecx,0x3ffffff
   2a138:	0f 85 a3 af ff ff    	jne    250e1 <JS_CallInternal+0x2541>
   2a13e:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2a145:	44 89 f1             	mov    ecx,r14d
   2a148:	48 8b b7 80 01 00 00 	mov    rsi,QWORD PTR [rdi+0x180]
   2a14f:	48 8b 97 88 01 00 00 	mov    rdx,QWORD PTR [rdi+0x188]
   2a156:	e8 a5 44 04 00       	call   6e600 <JS_HasProperty>
   2a15b:	85 c0                	test   eax,eax
   2a15d:	0f 88 85 2f 00 00    	js     2d0e8 <JS_CallInternal+0xa548>
   2a163:	b8 01 00 00 00       	mov    eax,0x1
   2a168:	0f 84 86 af ff ff    	je     250f4 <JS_CallInternal+0x2554>
   2a16e:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2a175:	45 31 c0             	xor    r8d,r8d
   2a178:	44 89 f1             	mov    ecx,r14d
   2a17b:	48 8b b7 80 01 00 00 	mov    rsi,QWORD PTR [rdi+0x180]
   2a182:	48 8b 97 88 01 00 00 	mov    rdx,QWORD PTR [rdi+0x188]
   2a189:	e8 d2 13 02 00       	call   4b560 <JS_DeleteProperty>
   2a18e:	85 c0                	test   eax,eax
   2a190:	0f 88 10 27 00 00    	js     2c8a6 <JS_CallInternal+0x9d06>
   2a196:	0f 95 c0             	setne  al
   2a199:	0f b6 c0             	movzx  eax,al
   2a19c:	e9 53 af ff ff       	jmp    250f4 <JS_CallInternal+0x2554>
   2a1a1:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a1a8:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a1ac:	48 8b 87 48 04 00 00 	mov    rax,QWORD PTR [rdi+0x448]
   2a1b3:	4a 8b 34 e8          	mov    rsi,QWORD PTR [rax+r13*8]
   2a1b7:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   2a1ba:	83 e8 01             	sub    eax,0x1
   2a1bd:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   2a1c0:	85 c0                	test   eax,eax
   2a1c2:	0f 8f 95 d7 ff ff    	jg     2795d <JS_CallInternal+0x4dbd>
   2a1c8:	e8 73 b2 fe ff       	call   15440 <JS_FreeAtomStruct>
   2a1cd:	e9 8b d7 ff ff       	jmp    2795d <JS_CallInternal+0x4dbd>
   2a1d2:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2a1d9:	48 8d 35 5e 33 0a 00 	lea    rsi,[rip+0xa335e]        # cd53e <_IO_stdin_used+0x53e>
   2a1e0:	31 c0                	xor    eax,eax
   2a1e2:	e8 99 6e 00 00       	call   31080 <JS_ThrowTypeError>
   2a1e7:	83 fb f6             	cmp    ebx,0xfffffff6
   2a1ea:	76 1e                	jbe    2a20a <JS_CallInternal+0x766a>
   2a1ec:	48 8b 8d 50 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x1b0]
   2a1f3:	8b 41 fc             	mov    eax,DWORD PTR [rcx-0x4]
   2a1f6:	89 85 28 fe ff ff    	mov    DWORD PTR [rbp-0x1d8],eax
   2a1fc:	83 e8 01             	sub    eax,0x1
   2a1ff:	89 41 fc             	mov    DWORD PTR [rcx-0x4],eax
   2a202:	85 c0                	test   eax,eax
   2a204:	0f 8e f7 24 00 00    	jle    2c701 <JS_CallInternal+0x9b61>
   2a20a:	83 bd 38 fe ff ff f6 	cmp    DWORD PTR [rbp-0x1c8],0xfffffff6
   2a211:	76 1e                	jbe    2a231 <JS_CallInternal+0x7691>
   2a213:	48 8b 9d 40 fe ff ff 	mov    rbx,QWORD PTR [rbp-0x1c0]
   2a21a:	8b 43 fc             	mov    eax,DWORD PTR [rbx-0x4]
   2a21d:	89 85 50 fe ff ff    	mov    DWORD PTR [rbp-0x1b0],eax
   2a223:	83 e8 01             	sub    eax,0x1
   2a226:	89 43 fc             	mov    DWORD PTR [rbx-0x4],eax
   2a229:	85 c0                	test   eax,eax
   2a22b:	0f 8e eb 24 00 00    	jle    2c71c <JS_CallInternal+0x9b7c>
   2a231:	ba 06 00 00 00       	mov    edx,0x6
   2a236:	31 c0                	xor    eax,eax
   2a238:	e9 8d a0 ff ff       	jmp    242ca <JS_CallInternal+0x172a>
   2a23d:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2a244:	48 8b 7f 10          	mov    rdi,QWORD PTR [rdi+0x10]
   2a248:	48 8b 97 48 04 00 00 	mov    rdx,QWORD PTR [rdi+0x448]
   2a24f:	4a 8b 34 ea          	mov    rsi,QWORD PTR [rdx+r13*8]
   2a253:	8b 56 fc             	mov    edx,DWORD PTR [rsi-0x4]
   2a256:	83 ea 01             	sub    edx,0x1
   2a259:	89 56 fc             	mov    DWORD PTR [rsi-0x4],edx
   2a25c:	85 d2                	test   edx,edx
   2a25e:	0f 8f b5 e4 ff ff    	jg     28719 <JS_CallInternal+0x5b79>
   2a264:	48 89 8d 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],rcx
   2a26b:	4c 89 b5 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],r14
   2a272:	e8 c9 b1 fe ff       	call   15440 <JS_FreeAtomStruct>
   2a277:	48 8b 8d 40 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x1c0]
   2a27e:	48 8b 85 50 fe ff ff 	mov    rax,QWORD PTR [rbp-0x1b0]
   2a285:	e9 8f e4 ff ff       	jmp    28719 <JS_CallInternal+0x5b79>
   2a28a:	48 89 fe             	mov    rsi,rdi
   2a28d:	48 8b 95 c8 fe ff ff 	mov    rdx,QWORD PTR [rbp-0x138]
   2a294:	48 8b bd c0 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x140]
   2a29b:	48 89 85 d0 fe ff ff 	mov    QWORD PTR [rbp-0x130],rax
   2a2a2:	48 89 8d e0 fe ff ff 	mov    QWORD PTR [rbp-0x120],rcx
   2a2a9:	e8 02 62 ff ff       	call   204b0 <close_var_refs>
   2a2ae:	48 8b 85 d0 fe ff ff 	mov    rax,QWORD PTR [rbp-0x130]
   2a2b5:	48 8b 8d e0 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x120]
   2a2bc:	e9 e4 8f ff ff       	jmp    232a5 <JS_CallInternal+0x705>
   2a2c1:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   2a2c8:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2a2cf:	ba 01 00 00 00       	mov    edx,0x1
   2a2d4:	48 89 de             	mov    rsi,rbx
   2a2d7:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   2a2db:	e8 80 10 03 00       	call   5b360 <js_eq_slow>
   2a2e0:	85 c0                	test   eax,eax
   2a2e2:	0f 84 8a c7 ff ff    	je     26a72 <JS_CallInternal+0x3ed2>
   2a2e8:	e9 53 90 ff ff       	jmp    23340 <JS_CallInternal+0x7a0>
   2a2ed:	0f 1f 00             	nop    DWORD PTR [rax]
   2a2f0:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   2a2f7:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2a2fe:	31 d2                	xor    edx,edx
   2a300:	48 89 de             	mov    rsi,rbx
   2a303:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   2a307:	e8 54 10 03 00       	call   5b360 <js_eq_slow>
   2a30c:	85 c0                	test   eax,eax
   2a30e:	0f 84 b8 c7 ff ff    	je     26acc <JS_CallInternal+0x3f2c>
   2a314:	e9 27 90 ff ff       	jmp    23340 <JS_CallInternal+0x7a0>
   2a319:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]
   2a320:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   2a327:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2a32e:	44 89 ea             	mov    edx,r13d
   2a331:	48 89 de             	mov    rsi,rbx
   2a334:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   2a338:	e8 53 b3 02 00       	call   55690 <js_unary_arith_slow>
   2a33d:	85 c0                	test   eax,eax
   2a33f:	0f 84 b7 d1 ff ff    	je     274fc <JS_CallInternal+0x495c>
   2a345:	e9 f6 8f ff ff       	jmp    23340 <JS_CallInternal+0x7a0>
   2a34a:	66 0f 1f 44 00 00    	nop    WORD PTR [rax+rax*1+0x0]
   2a350:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a357:	89 8d 38 fe ff ff    	mov    DWORD PTR [rbp-0x1c8],ecx
   2a35d:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a361:	e8 0a 26 ff ff       	call   1c970 <__JS_FreeValueRT>
   2a366:	8b 8d 38 fe ff ff    	mov    ecx,DWORD PTR [rbp-0x1c8]
   2a36c:	e9 28 97 ff ff       	jmp    23a99 <JS_CallInternal+0xef9>
   2a371:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a378:	48 89 ca             	mov    rdx,rcx
   2a37b:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a37f:	e8 ec 25 ff ff       	call   1c970 <__JS_FreeValueRT>
   2a384:	e9 99 94 ff ff       	jmp    23822 <JS_CallInternal+0xc82>
   2a389:	41 83 fe f6          	cmp    r14d,0xfffffff6
   2a38d:	0f 87 65 12 00 00    	ja     2b5f8 <JS_CallInternal+0x8a58>
   2a393:	b8 01 00 00 00       	mov    eax,0x1
   2a398:	e9 59 d4 ff ff       	jmp    277f6 <JS_CallInternal+0x4c56>
   2a39d:	0f 1f 00             	nop    DWORD PTR [rax]
   2a3a0:	41 83 fe f6          	cmp    r14d,0xfffffff6
   2a3a4:	76 0f                	jbe    2a3b5 <JS_CallInternal+0x7815>
   2a3a6:	41 8b 45 fc          	mov    eax,DWORD PTR [r13-0x4]
   2a3aa:	83 e8 01             	sub    eax,0x1
   2a3ad:	41 89 45 fc          	mov    DWORD PTR [r13-0x4],eax
   2a3b1:	85 c0                	test   eax,eax
   2a3b3:	7e 07                	jle    2a3bc <JS_CallInternal+0x781c>
   2a3b5:	31 c0                	xor    eax,eax
   2a3b7:	e9 8e d4 ff ff       	jmp    2784a <JS_CallInternal+0x4caa>
   2a3bc:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a3c3:	4c 89 ee             	mov    rsi,r13
   2a3c6:	4c 89 f2             	mov    rdx,r14
   2a3c9:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a3cd:	e8 9e 25 ff ff       	call   1c970 <__JS_FreeValueRT>
   2a3d2:	31 c0                	xor    eax,eax
   2a3d4:	e9 71 d4 ff ff       	jmp    2784a <JS_CallInternal+0x4caa>
   2a3d9:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a3e0:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a3e4:	8b 85 50 fe ff ff    	mov    eax,DWORD PTR [rbp-0x1b0]
   2a3ea:	48 8b 97 48 04 00 00 	mov    rdx,QWORD PTR [rdi+0x448]
   2a3f1:	48 8b 34 c2          	mov    rsi,QWORD PTR [rdx+rax*8]
   2a3f5:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   2a3f8:	83 e8 01             	sub    eax,0x1
   2a3fb:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   2a3fe:	85 c0                	test   eax,eax
   2a400:	0f 8f dd ee ff ff    	jg     292e3 <JS_CallInternal+0x6743>
   2a406:	89 8d 50 fe ff ff    	mov    DWORD PTR [rbp-0x1b0],ecx
   2a40c:	e8 2f b0 fe ff       	call   15440 <JS_FreeAtomStruct>
   2a411:	8b 8d 50 fe ff ff    	mov    ecx,DWORD PTR [rbp-0x1b0]
   2a417:	e9 c7 ee ff ff       	jmp    292e3 <JS_CallInternal+0x6743>
   2a41c:	b9 ff ff ff ff       	mov    ecx,0xffffffff
   2a421:	e9 54 96 ff ff       	jmp    23a7a <JS_CallInternal+0xeda>
   2a426:	45 31 ed             	xor    r13d,r13d
   2a429:	e9 61 eb ff ff       	jmp    28f8f <JS_CallInternal+0x63ef>
   2a42e:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2a435:	48 8d 35 12 31 0a 00 	lea    rsi,[rip+0xa3112]        # cd54e <_IO_stdin_used+0x54e>
   2a43c:	31 c0                	xor    eax,eax
   2a43e:	e8 1d 90 00 00       	call   33460 <JS_ThrowInternalError>
   2a443:	e9 f8 8e ff ff       	jmp    23340 <JS_CallInternal+0x7a0>
   2a448:	48 8b 8d e8 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x118]
   2a44f:	89 c0                	mov    eax,eax
   2a451:	48 8b 79 10          	mov    rdi,QWORD PTR [rcx+0x10]
   2a455:	48 8b 8f 48 04 00 00 	mov    rcx,QWORD PTR [rdi+0x448]
   2a45c:	48 8b 34 c1          	mov    rsi,QWORD PTR [rcx+rax*8]
   2a460:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   2a463:	83 e8 01             	sub    eax,0x1
   2a466:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   2a469:	85 c0                	test   eax,eax
   2a46b:	0f 8f 5b ca ff ff    	jg     26ecc <JS_CallInternal+0x432c>
   2a471:	48 89 95 38 fe ff ff 	mov    QWORD PTR [rbp-0x1c8],rdx
   2a478:	4c 89 8d 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],r9
   2a47f:	e8 bc af fe ff       	call   15440 <JS_FreeAtomStruct>
   2a484:	48 8b 95 38 fe ff ff 	mov    rdx,QWORD PTR [rbp-0x1c8]
   2a48b:	4c 8b 8d 40 fe ff ff 	mov    r9,QWORD PTR [rbp-0x1c0]
   2a492:	e9 35 ca ff ff       	jmp    26ecc <JS_CallInternal+0x432c>
   2a497:	4c 8b a5 28 fe ff ff 	mov    r12,QWORD PTR [rbp-0x1d8]
   2a49e:	e9 9d 8e ff ff       	jmp    23340 <JS_CallInternal+0x7a0>
   2a4a3:	48 83 ec 08          	sub    rsp,0x8
   2a4a7:	48 8d 4b f0          	lea    rcx,[rbx-0x10]
   2a4ab:	41 b9 01 00 00 00    	mov    r9d,0x1
   2a4b1:	51                   	push   rcx
   2a4b2:	e9 40 f4 ff ff       	jmp    298f7 <JS_CallInternal+0x6d57>
   2a4b7:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   2a4be:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2a4c5:	44 89 ea             	mov    edx,r13d
   2a4c8:	48 89 de             	mov    rsi,rbx
   2a4cb:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   2a4cf:	e8 bc b1 02 00       	call   55690 <js_unary_arith_slow>
   2a4d4:	85 c0                	test   eax,eax
   2a4d6:	0f 84 d8 cf ff ff    	je     274b4 <JS_CallInternal+0x4914>
   2a4dc:	e9 5f 8e ff ff       	jmp    23340 <JS_CallInternal+0x7a0>
   2a4e1:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]
   2a4e8:	48 8b bd d8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x128]
   2a4ef:	48 8b 47 30          	mov    rax,QWORD PTR [rdi+0x30]
   2a4f3:	48 01 c8             	add    rax,rcx
   2a4f6:	8b 48 04             	mov    ecx,DWORD PTR [rax+0x4]
   2a4f9:	f6 00 08             	test   BYTE PTR [rax],0x8
   2a4fc:	0f 85 be 2a 00 00    	jne    2cfc0 <JS_CallInternal+0xa420>
   2a502:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2a509:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   2a510:	48 83 ec 08          	sub    rsp,0x8
   2a514:	41 83 ed 37          	sub    r13d,0x37
   2a518:	4c 89 70 30          	mov    QWORD PTR [rax+0x30],r14
   2a51c:	4c 8b 87 80 01 00 00 	mov    r8,QWORD PTR [rdi+0x180]
   2a523:	4c 8b 8f 88 01 00 00 	mov    r9,QWORD PTR [rdi+0x188]
   2a52a:	48 8b b7 80 01 00 00 	mov    rsi,QWORD PTR [rdi+0x180]
   2a531:	48 8b 97 88 01 00 00 	mov    rdx,QWORD PTR [rdi+0x188]
   2a538:	41 55                	push   r13
   2a53a:	e8 d1 2c 00 00       	call   2d210 <JS_GetPropertyInternal>
   2a53f:	48 89 53 08          	mov    QWORD PTR [rbx+0x8],rdx
   2a543:	83 7b 08 06          	cmp    DWORD PTR [rbx+0x8],0x6
   2a547:	48 89 03             	mov    QWORD PTR [rbx],rax
   2a54a:	41 5b                	pop    r11
   2a54c:	41 5d                	pop    r13
   2a54e:	0f 85 0a 97 ff ff    	jne    23c5e <JS_CallInternal+0x10be>
   2a554:	4d 89 f4             	mov    r12,r14
   2a557:	e9 e4 8d ff ff       	jmp    23340 <JS_CallInternal+0x7a0>
   2a55c:	b9 03 00 00 00       	mov    ecx,0x3
   2a561:	31 c0                	xor    eax,eax
   2a563:	e9 83 9b ff ff       	jmp    240eb <JS_CallInternal+0x154b>
   2a568:	48 89 c6             	mov    rsi,rax
   2a56b:	8b 40 ac             	mov    eax,DWORD PTR [rax-0x54]
   2a56e:	89 85 50 fe ff ff    	mov    DWORD PTR [rbp-0x1b0],eax
   2a574:	83 e8 01             	sub    eax,0x1
   2a577:	89 46 ac             	mov    DWORD PTR [rsi-0x54],eax
   2a57a:	0f 85 21 d9 ff ff    	jne    27ea1 <JS_CallInternal+0x5301>
   2a580:	80 bf a0 04 00 00 02 	cmp    BYTE PTR [rdi+0x4a0],0x2
   2a587:	0f 84 14 d9 ff ff    	je     27ea1 <JS_CallInternal+0x5301>
   2a58d:	48 83 ee 50          	sub    rsi,0x50
   2a591:	e8 5a 5e ff ff       	call   203f0 <async_func_free.part.0>
   2a596:	48 8b b5 c8 fe ff ff 	mov    rsi,QWORD PTR [rbp-0x138]
   2a59d:	48 8b 4e 28          	mov    rcx,QWORD PTR [rsi+0x28]
   2a5a1:	4c 01 e9             	add    rcx,r13
   2a5a4:	e9 f8 d8 ff ff       	jmp    27ea1 <JS_CallInternal+0x5301>
   2a5a9:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2a5b0:	0f b6 d0             	movzx  edx,al
   2a5b3:	31 c0                	xor    eax,eax
   2a5b5:	48 8d 35 68 2f 0a 00 	lea    rsi,[rip+0xa2f68]        # cd524 <_IO_stdin_used+0x524>
   2a5bc:	e8 9f 8e 00 00       	call   33460 <JS_ThrowInternalError>
   2a5c1:	e9 7a 8d ff ff       	jmp    23340 <JS_CallInternal+0x7a0>
   2a5c6:	48 8d 43 f0          	lea    rax,[rbx-0x10]
   2a5ca:	45 31 ed             	xor    r13d,r13d
   2a5cd:	48 89 85 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],rax
   2a5d4:	b8 03 00 00 00       	mov    eax,0x3
   2a5d9:	e9 18 9c ff ff       	jmp    241f6 <JS_CallInternal+0x1656>
   2a5de:	4d 89 ec             	mov    r12,r13
   2a5e1:	e9 5a 8d ff ff       	jmp    23340 <JS_CallInternal+0x7a0>
   2a5e6:	48 89 85 38 fe ff ff 	mov    QWORD PTR [rbp-0x1c8],rax
   2a5ed:	4c 89 ee             	mov    rsi,r13
   2a5f0:	4c 89 ca             	mov    rdx,r9
   2a5f3:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a5fa:	44 89 85 28 fe ff ff 	mov    DWORD PTR [rbp-0x1d8],r8d
   2a601:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a605:	48 89 8d 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],rcx
   2a60c:	e8 5f 23 ff ff       	call   1c970 <__JS_FreeValueRT>
   2a611:	44 8b 85 28 fe ff ff 	mov    r8d,DWORD PTR [rbp-0x1d8]
   2a618:	48 8b 85 38 fe ff ff 	mov    rax,QWORD PTR [rbp-0x1c8]
   2a61f:	48 8b 8d 40 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x1c0]
   2a626:	e9 9b da ff ff       	jmp    280c6 <JS_CallInternal+0x5526>
   2a62b:	48 89 85 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],rax
   2a632:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a639:	44 89 85 38 fe ff ff 	mov    DWORD PTR [rbp-0x1c8],r8d
   2a640:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a644:	48 89 8d 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],rcx
   2a64b:	e8 20 23 ff ff       	call   1c970 <__JS_FreeValueRT>
   2a650:	44 8b 85 38 fe ff ff 	mov    r8d,DWORD PTR [rbp-0x1c8]
   2a657:	48 8b 85 40 fe ff ff 	mov    rax,QWORD PTR [rbp-0x1c0]
   2a65e:	48 8b 8d 50 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x1b0]
   2a665:	e9 80 da ff ff       	jmp    280ea <JS_CallInternal+0x554a>
   2a66a:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a671:	4c 89 f2             	mov    rdx,r14
   2a674:	48 89 8d 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],rcx
   2a67b:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a67f:	e8 ec 22 ff ff       	call   1c970 <__JS_FreeValueRT>
   2a684:	48 8b 8d 50 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x1b0]
   2a68b:	e9 53 c7 ff ff       	jmp    26de3 <JS_CallInternal+0x4243>
   2a690:	48 89 85 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],rax
   2a697:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a69e:	4c 89 85 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],r8
   2a6a5:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a6a9:	e8 c2 22 ff ff       	call   1c970 <__JS_FreeValueRT>
   2a6ae:	4c 8b 85 40 fe ff ff 	mov    r8,QWORD PTR [rbp-0x1c0]
   2a6b5:	48 8b 85 50 fe ff ff 	mov    rax,QWORD PTR [rbp-0x1b0]
   2a6bc:	e9 fc dc ff ff       	jmp    283bd <JS_CallInternal+0x581d>
   2a6c1:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a6c8:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a6cc:	e8 9f 22 ff ff       	call   1c970 <__JS_FreeValueRT>
   2a6d1:	e9 66 db ff ff       	jmp    2823c <JS_CallInternal+0x569c>
   2a6d6:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a6dd:	4c 89 c6             	mov    rsi,r8
   2a6e0:	48 89 ca             	mov    rdx,rcx
   2a6e3:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a6e7:	e8 84 22 ff ff       	call   1c970 <__JS_FreeValueRT>
   2a6ec:	e9 84 e3 ff ff       	jmp    28a75 <JS_CallInternal+0x5ed5>
   2a6f1:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a6f8:	48 89 ca             	mov    rdx,rcx
   2a6fb:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a6ff:	e8 6c 22 ff ff       	call   1c970 <__JS_FreeValueRT>
   2a704:	e9 75 e6 ff ff       	jmp    28d7e <JS_CallInternal+0x61de>
   2a709:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a710:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a714:	e8 57 22 ff ff       	call   1c970 <__JS_FreeValueRT>
   2a719:	e9 69 a7 ff ff       	jmp    24e87 <JS_CallInternal+0x22e7>
   2a71e:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a725:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a729:	e8 42 22 ff ff       	call   1c970 <__JS_FreeValueRT>
   2a72e:	e9 9f a4 ff ff       	jmp    24bd2 <JS_CallInternal+0x2032>
   2a733:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a73a:	4c 89 c2             	mov    rdx,r8
   2a73d:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a741:	e8 2a 22 ff ff       	call   1c970 <__JS_FreeValueRT>
   2a746:	e9 35 a4 ff ff       	jmp    24b80 <JS_CallInternal+0x1fe0>
   2a74b:	48 83 ec 08          	sub    rsp,0x8
   2a74f:	8b 8d 38 fe ff ff    	mov    ecx,DWORD PTR [rbp-0x1c8]
   2a755:	4c 89 ee             	mov    rsi,r13
   2a758:	4c 89 e2             	mov    rdx,r12
   2a75b:	4c 8b 85 50 fe ff ff 	mov    r8,QWORD PTR [rbp-0x1b0]
   2a762:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2a769:	6a 00                	push   0x0
   2a76b:	4c 8b 8d 58 fe ff ff 	mov    r9,QWORD PTR [rbp-0x1a8]
   2a772:	e8 99 2a 00 00       	call   2d210 <JS_GetPropertyInternal>
   2a777:	5f                   	pop    rdi
   2a778:	41 58                	pop    r8
   2a77a:	48 89 c1             	mov    rcx,rax
   2a77d:	48 89 d0             	mov    rax,rdx
   2a780:	83 fa 06             	cmp    edx,0x6
   2a783:	0f 85 72 8e ff ff    	jne    235fb <JS_CallInternal+0xa5b>
   2a789:	e9 18 8f ff ff       	jmp    236a6 <JS_CallInternal+0xb06>
   2a78e:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a795:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a799:	e8 d2 21 ff ff       	call   1c970 <__JS_FreeValueRT>
   2a79e:	e9 b6 da ff ff       	jmp    28259 <JS_CallInternal+0x56b9>
   2a7a3:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a7aa:	4c 89 85 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],r8
   2a7b1:	4c 89 8d 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],r9
   2a7b8:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a7bc:	e8 af 21 ff ff       	call   1c970 <__JS_FreeValueRT>
   2a7c1:	4c 8b 85 40 fe ff ff 	mov    r8,QWORD PTR [rbp-0x1c0]
   2a7c8:	4c 8b 8d 50 fe ff ff 	mov    r9,QWORD PTR [rbp-0x1b0]
   2a7cf:	e9 8f 97 ff ff       	jmp    23f63 <JS_CallInternal+0x13c3>
   2a7d4:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a7db:	4c 89 85 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],r8
   2a7e2:	4c 89 8d 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],r9
   2a7e9:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a7ed:	e8 7e 21 ff ff       	call   1c970 <__JS_FreeValueRT>
   2a7f2:	4c 8b 85 40 fe ff ff 	mov    r8,QWORD PTR [rbp-0x1c0]
   2a7f9:	4c 8b 8d 50 fe ff ff 	mov    r9,QWORD PTR [rbp-0x1b0]
   2a800:	e9 23 97 ff ff       	jmp    23f28 <JS_CallInternal+0x1388>
   2a805:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a80c:	4c 89 85 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],r8
   2a813:	4c 89 8d 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],r9
   2a81a:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a81e:	e8 4d 21 ff ff       	call   1c970 <__JS_FreeValueRT>
   2a823:	4c 8b 85 40 fe ff ff 	mov    r8,QWORD PTR [rbp-0x1c0]
   2a82a:	4c 8b 8d 50 fe ff ff 	mov    r9,QWORD PTR [rbp-0x1b0]
   2a831:	e9 0f 97 ff ff       	jmp    23f45 <JS_CallInternal+0x13a5>
   2a836:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a83d:	48 89 8d 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],rcx
   2a844:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a848:	e8 23 21 ff ff       	call   1c970 <__JS_FreeValueRT>
   2a84d:	48 8b 8d 50 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x1b0]
   2a854:	e9 16 dc ff ff       	jmp    2846f <JS_CallInternal+0x58cf>
   2a859:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   2a860:	8b 4e 04             	mov    ecx,DWORD PTR [rsi+0x4]
   2a863:	48 89 b5 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],rsi
   2a86a:	4c 8b ad e8 fe ff ff 	mov    r13,QWORD PTR [rbp-0x118]
   2a871:	4c 89 70 30          	mov    QWORD PTR [rax+0x30],r14
   2a875:	49 8b b5 80 01 00 00 	mov    rsi,QWORD PTR [r13+0x180]
   2a87c:	49 8b 95 88 01 00 00 	mov    rdx,QWORD PTR [r13+0x188]
   2a883:	4c 89 ef             	mov    rdi,r13
   2a886:	e8 75 3d 04 00       	call   6e600 <JS_HasProperty>
   2a88b:	85 c0                	test   eax,eax
   2a88d:	0f 88 61 25 00 00    	js     2cdf4 <JS_CallInternal+0xa254>
   2a893:	4c 8b 95 50 fe ff ff 	mov    r10,QWORD PTR [rbp-0x1b0]
   2a89a:	0f 85 54 0e 00 00    	jne    2b6f4 <JS_CallInternal+0x8b54>
   2a8a0:	49 8b 45 10          	mov    rax,QWORD PTR [r13+0x10]
   2a8a4:	4c 89 ef             	mov    rdi,r13
   2a8a7:	48 8b 80 f0 04 00 00 	mov    rax,QWORD PTR [rax+0x4f0]
   2a8ae:	48 85 c0             	test   rax,rax
   2a8b1:	0f 84 3d 0e 00 00    	je     2b6f4 <JS_CallInternal+0x8b54>
   2a8b7:	f6 40 3c 01          	test   BYTE PTR [rax+0x3c],0x1
   2a8bb:	0f 84 33 0e 00 00    	je     2b6f4 <JS_CallInternal+0x8b54>
   2a8c1:	41 8b 72 04          	mov    esi,DWORD PTR [r10+0x4]
   2a8c5:	4d 89 f4             	mov    r12,r14
   2a8c8:	e8 d3 89 00 00       	call   332a0 <JS_ThrowReferenceErrorNotDefined>
   2a8cd:	e9 6e 8a ff ff       	jmp    23340 <JS_CallInternal+0x7a0>
   2a8d2:	48 8b 7f 10          	mov    rdi,QWORD PTR [rdi+0x10]
   2a8d6:	4c 89 c2             	mov    rdx,r8
   2a8d9:	e8 92 20 ff ff       	call   1c970 <__JS_FreeValueRT>
   2a8de:	e9 03 ce ff ff       	jmp    276e6 <JS_CallInternal+0x4b46>
   2a8e3:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a8ea:	48 89 8d 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],rcx
   2a8f1:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a8f5:	e8 76 20 ff ff       	call   1c970 <__JS_FreeValueRT>
   2a8fa:	48 8b 8d 50 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x1b0]
   2a901:	e9 90 cd ff ff       	jmp    27696 <JS_CallInternal+0x4af6>
   2a906:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a90d:	48 89 ca             	mov    rdx,rcx
   2a910:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a914:	e8 57 20 ff ff       	call   1c970 <__JS_FreeValueRT>
   2a919:	e9 55 a0 ff ff       	jmp    24973 <JS_CallInternal+0x1dd3>
   2a91e:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a925:	48 89 ca             	mov    rdx,rcx
   2a928:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a92c:	e8 3f 20 ff ff       	call   1c970 <__JS_FreeValueRT>
   2a931:	e9 d9 a0 ff ff       	jmp    24a0f <JS_CallInternal+0x1e6f>
   2a936:	4c 8b a5 10 fe ff ff 	mov    r12,QWORD PTR [rbp-0x1f0]
   2a93d:	e9 fe 89 ff ff       	jmp    23340 <JS_CallInternal+0x7a0>
   2a942:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a949:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a94d:	e8 1e 20 ff ff       	call   1c970 <__JS_FreeValueRT>
   2a952:	e9 57 e1 ff ff       	jmp    28aae <JS_CallInternal+0x5f0e>
   2a957:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a95e:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a962:	e8 09 20 ff ff       	call   1c970 <__JS_FreeValueRT>
   2a967:	e9 2c c9 ff ff       	jmp    27298 <JS_CallInternal+0x46f8>
   2a96c:	48 89 85 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],rax
   2a973:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a97a:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a97e:	e8 ed 1f ff ff       	call   1c970 <__JS_FreeValueRT>
   2a983:	48 8b 85 50 fe ff ff 	mov    rax,QWORD PTR [rbp-0x1b0]
   2a98a:	e9 8b 98 ff ff       	jmp    2421a <JS_CallInternal+0x167a>
   2a98f:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a996:	48 89 8d 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],rcx
   2a99d:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a9a1:	e8 ca 1f ff ff       	call   1c970 <__JS_FreeValueRT>
   2a9a6:	48 8b 8d 50 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x1b0]
   2a9ad:	e9 e7 94 ff ff       	jmp    23e99 <JS_CallInternal+0x12f9>
   2a9b2:	88 85 40 fe ff ff    	mov    BYTE PTR [rbp-0x1c0],al
   2a9b8:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a9bf:	48 89 ce             	mov    rsi,rcx
   2a9c2:	4c 89 f2             	mov    rdx,r14
   2a9c5:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a9c9:	e8 a2 1f ff ff       	call   1c970 <__JS_FreeValueRT>
   2a9ce:	0f b6 85 40 fe ff ff 	movzx  eax,BYTE PTR [rbp-0x1c0]
   2a9d5:	e9 35 c5 ff ff       	jmp    26f0f <JS_CallInternal+0x436f>
   2a9da:	48 89 85 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],rax
   2a9e1:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a9e8:	4c 89 85 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],r8
   2a9ef:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a9f3:	e8 78 1f ff ff       	call   1c970 <__JS_FreeValueRT>
   2a9f8:	4c 8b 85 40 fe ff ff 	mov    r8,QWORD PTR [rbp-0x1c0]
   2a9ff:	48 8b 85 50 fe ff ff 	mov    rax,QWORD PTR [rbp-0x1b0]
   2aa06:	e9 03 94 ff ff       	jmp    23e0e <JS_CallInternal+0x126e>
   2aa0b:	48 89 85 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],rax
   2aa12:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2aa19:	4c 89 85 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],r8
   2aa20:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2aa24:	e8 47 1f ff ff       	call   1c970 <__JS_FreeValueRT>
   2aa29:	4c 8b 85 40 fe ff ff 	mov    r8,QWORD PTR [rbp-0x1c0]
   2aa30:	48 8b 85 50 fe ff ff 	mov    rax,QWORD PTR [rbp-0x1b0]
   2aa37:	e9 ef 93 ff ff       	jmp    23e2b <JS_CallInternal+0x128b>
   2aa3c:	48 89 85 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],rax
   2aa43:	4c 89 f6             	mov    rsi,r14
   2aa46:	4c 89 ea             	mov    rdx,r13
   2aa49:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2aa50:	48 89 8d 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],rcx
   2aa57:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2aa5b:	e8 10 1f ff ff       	call   1c970 <__JS_FreeValueRT>
   2aa60:	48 8b 8d 40 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x1c0]
   2aa67:	48 8b 85 50 fe ff ff 	mov    rax,QWORD PTR [rbp-0x1b0]
   2aa6e:	e9 f5 ba ff ff       	jmp    26568 <JS_CallInternal+0x39c8>
   2aa73:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2aa7a:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2aa7e:	e8 ed 1e ff ff       	call   1c970 <__JS_FreeValueRT>
   2aa83:	e9 dc b9 ff ff       	jmp    26464 <JS_CallInternal+0x38c4>
   2aa88:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2aa8f:	48 89 ca             	mov    rdx,rcx
   2aa92:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2aa96:	e8 d5 1e ff ff       	call   1c970 <__JS_FreeValueRT>
   2aa9b:	e9 3a b0 ff ff       	jmp    25ada <JS_CallInternal+0x2f3a>
   2aaa0:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2aaa7:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2aaab:	e8 c0 1e ff ff       	call   1c970 <__JS_FreeValueRT>
   2aab0:	e9 6d b0 ff ff       	jmp    25b22 <JS_CallInternal+0x2f82>
   2aab5:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2aabc:	48 89 ca             	mov    rdx,rcx
   2aabf:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2aac3:	e8 a8 1e ff ff       	call   1c970 <__JS_FreeValueRT>
   2aac8:	e9 67 af ff ff       	jmp    25a34 <JS_CallInternal+0x2e94>
   2aacd:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2aad4:	48 89 ca             	mov    rdx,rcx
   2aad7:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2aadb:	e8 90 1e ff ff       	call   1c970 <__JS_FreeValueRT>
   2aae0:	e9 a3 af ff ff       	jmp    25a88 <JS_CallInternal+0x2ee8>
   2aae5:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2aaec:	4c 89 ee             	mov    rsi,r13
   2aaef:	4c 89 f2             	mov    rdx,r14
   2aaf2:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2aaf6:	e8 75 1e ff ff       	call   1c970 <__JS_FreeValueRT>
   2aafb:	e9 1a c9 ff ff       	jmp    2741a <JS_CallInternal+0x487a>
   2ab00:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2ab07:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2ab0b:	e8 60 1e ff ff       	call   1c970 <__JS_FreeValueRT>
   2ab10:	e9 1e e7 ff ff       	jmp    29233 <JS_CallInternal+0x6693>
   2ab15:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2ab1c:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2ab20:	e8 4b 1e ff ff       	call   1c970 <__JS_FreeValueRT>
   2ab25:	e9 e5 e6 ff ff       	jmp    2920f <JS_CallInternal+0x666f>
   2ab2a:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2ab31:	48 89 ca             	mov    rdx,rcx
   2ab34:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2ab38:	e8 33 1e ff ff       	call   1c970 <__JS_FreeValueRT>
   2ab3d:	e9 8b 9d ff ff       	jmp    248cd <JS_CallInternal+0x1d2d>
   2ab42:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2ab49:	4c 89 95 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],r10
   2ab50:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2ab54:	e8 17 1e ff ff       	call   1c970 <__JS_FreeValueRT>
   2ab59:	4c 8b 95 40 fe ff ff 	mov    r10,QWORD PTR [rbp-0x1c0]
   2ab60:	e9 89 d2 ff ff       	jmp    27dee <JS_CallInternal+0x524e>
   2ab65:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2ab6c:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2ab70:	e8 fb 1d ff ff       	call   1c970 <__JS_FreeValueRT>
   2ab75:	e9 91 d2 ff ff       	jmp    27e0b <JS_CallInternal+0x526b>
   2ab7a:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2ab81:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2ab85:	e8 e6 1d ff ff       	call   1c970 <__JS_FreeValueRT>
   2ab8a:	e9 99 d2 ff ff       	jmp    27e28 <JS_CallInternal+0x5288>
   2ab8f:	48 89 85 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],rax
   2ab96:	4c 89 ee             	mov    rsi,r13
   2ab99:	4c 89 f2             	mov    rdx,r14
   2ab9c:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2aba3:	48 89 8d 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],rcx
   2abaa:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2abae:	e8 bd 1d ff ff       	call   1c970 <__JS_FreeValueRT>
   2abb3:	48 8b 85 40 fe ff ff 	mov    rax,QWORD PTR [rbp-0x1c0]
   2abba:	48 8b 8d 50 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x1b0]
   2abc1:	e9 5d ac ff ff       	jmp    25823 <JS_CallInternal+0x2c83>
   2abc6:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2abcd:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2abd1:	e8 9a 1d ff ff       	call   1c970 <__JS_FreeValueRT>
   2abd6:	e9 a7 b8 ff ff       	jmp    26482 <JS_CallInternal+0x38e2>
   2abdb:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2abe2:	48 89 ca             	mov    rdx,rcx
   2abe5:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2abe9:	e8 82 1d ff ff       	call   1c970 <__JS_FreeValueRT>
   2abee:	e9 2c 9d ff ff       	jmp    2491f <JS_CallInternal+0x1d7f>
   2abf3:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2abfa:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2abfe:	e8 6d 1d ff ff       	call   1c970 <__JS_FreeValueRT>
   2ac03:	e9 4f 9e ff ff       	jmp    24a57 <JS_CallInternal+0x1eb7>
   2ac08:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2ac0f:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2ac13:	e8 58 1d ff ff       	call   1c970 <__JS_FreeValueRT>
   2ac18:	e9 9e 9d ff ff       	jmp    249bb <JS_CallInternal+0x1e1b>
   2ac1d:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2ac24:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2ac28:	e8 43 1d ff ff       	call   1c970 <__JS_FreeValueRT>
   2ac2d:	e9 6d 9e ff ff       	jmp    24a9f <JS_CallInternal+0x1eff>
   2ac32:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2ac39:	4c 89 c2             	mov    rdx,r8
   2ac3c:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2ac40:	e8 2b 1d ff ff       	call   1c970 <__JS_FreeValueRT>
   2ac45:	e9 07 9b ff ff       	jmp    24751 <JS_CallInternal+0x1bb1>
   2ac4a:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2ac51:	4c 89 c2             	mov    rdx,r8
   2ac54:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2ac58:	e8 13 1d ff ff       	call   1c970 <__JS_FreeValueRT>
   2ac5d:	e9 4a 9a ff ff       	jmp    246ac <JS_CallInternal+0x1b0c>
   2ac62:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2ac69:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2ac6d:	e8 fe 1c ff ff       	call   1c970 <__JS_FreeValueRT>
   2ac72:	e9 7c 9b ff ff       	jmp    247f3 <JS_CallInternal+0x1c53>
   2ac77:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2ac7e:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2ac82:	e8 e9 1c ff ff       	call   1c970 <__JS_FreeValueRT>
   2ac87:	e9 14 9b ff ff       	jmp    247a0 <JS_CallInternal+0x1c00>
   2ac8c:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2ac93:	48 89 ca             	mov    rdx,rcx
   2ac96:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2ac9a:	e8 d1 1c ff ff       	call   1c970 <__JS_FreeValueRT>
   2ac9f:	e9 05 b3 ff ff       	jmp    25fa9 <JS_CallInternal+0x3409>
   2aca4:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2acab:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2acaf:	e8 bc 1c ff ff       	call   1c970 <__JS_FreeValueRT>
   2acb4:	e9 40 b3 ff ff       	jmp    25ff9 <JS_CallInternal+0x3459>
   2acb9:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2acc0:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2acc4:	e8 a7 1c ff ff       	call   1c970 <__JS_FreeValueRT>
   2acc9:	e9 2e b2 ff ff       	jmp    25efc <JS_CallInternal+0x335c>
   2acce:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2acd5:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2acd9:	e8 92 1c ff ff       	call   1c970 <__JS_FreeValueRT>
   2acde:	e9 67 b2 ff ff       	jmp    25f4a <JS_CallInternal+0x33aa>
   2ace3:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2acea:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2acee:	e8 7d 1c ff ff       	call   1c970 <__JS_FreeValueRT>
   2acf3:	e9 db a0 ff ff       	jmp    24dd3 <JS_CallInternal+0x2233>
   2acf8:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2acff:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2ad03:	e8 68 1c ff ff       	call   1c970 <__JS_FreeValueRT>
   2ad08:	e9 d8 9d ff ff       	jmp    24ae5 <JS_CallInternal+0x1f45>
   2ad0d:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2ad14:	4c 89 c2             	mov    rdx,r8
   2ad17:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2ad1b:	e8 50 1c ff ff       	call   1c970 <__JS_FreeValueRT>
   2ad20:	e9 3b b1 ff ff       	jmp    25e60 <JS_CallInternal+0x32c0>
   2ad25:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2ad2c:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2ad30:	e8 3b 1c ff ff       	call   1c970 <__JS_FreeValueRT>
   2ad35:	e9 74 b1 ff ff       	jmp    25eae <JS_CallInternal+0x330e>
   2ad3a:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2ad41:	4c 89 c2             	mov    rdx,r8
   2ad44:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2ad48:	e8 23 1c ff ff       	call   1c970 <__JS_FreeValueRT>
   2ad4d:	e9 59 b0 ff ff       	jmp    25dab <JS_CallInternal+0x320b>
   2ad52:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2ad59:	4c 89 c2             	mov    rdx,r8
   2ad5c:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2ad60:	e8 0b 1c ff ff       	call   1c970 <__JS_FreeValueRT>
   2ad65:	e9 9c b0 ff ff       	jmp    25e06 <JS_CallInternal+0x3266>
   2ad6a:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2ad71:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2ad75:	e8 f6 1b ff ff       	call   1c970 <__JS_FreeValueRT>
   2ad7a:	e9 79 ae ff ff       	jmp    25bf8 <JS_CallInternal+0x3058>
   2ad7f:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2ad86:	4c 89 c2             	mov    rdx,r8
   2ad89:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2ad8d:	e8 de 1b ff ff       	call   1c970 <__JS_FreeValueRT>
   2ad92:	e9 b9 af ff ff       	jmp    25d50 <JS_CallInternal+0x31b0>
   2ad97:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2ad9e:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2ada2:	e8 c9 1b ff ff       	call   1c970 <__JS_FreeValueRT>
   2ada7:	e9 be ad ff ff       	jmp    25b6a <JS_CallInternal+0x2fca>
   2adac:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2adb3:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2adb7:	e8 b4 1b ff ff       	call   1c970 <__JS_FreeValueRT>
   2adbc:	e9 f1 ad ff ff       	jmp    25bb2 <JS_CallInternal+0x3012>
   2adc1:	88 85 40 fe ff ff    	mov    BYTE PTR [rbp-0x1c0],al
   2adc7:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2adce:	4c 89 ce             	mov    rsi,r9
   2add1:	4c 89 ea             	mov    rdx,r13
   2add4:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2add8:	e8 93 1b ff ff       	call   1c970 <__JS_FreeValueRT>
   2addd:	0f b6 85 40 fe ff ff 	movzx  eax,BYTE PTR [rbp-0x1c0]
   2ade4:	e9 02 c1 ff ff       	jmp    26eeb <JS_CallInternal+0x434b>
   2ade9:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2adf0:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2adf4:	e8 77 1b ff ff       	call   1c970 <__JS_FreeValueRT>
   2adf9:	e9 7f aa ff ff       	jmp    2587d <JS_CallInternal+0x2cdd>
   2adfe:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2ae05:	48 89 ca             	mov    rdx,rcx
   2ae08:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2ae0c:	e8 5f 1b ff ff       	call   1c970 <__JS_FreeValueRT>
   2ae11:	e9 ca ab ff ff       	jmp    259e0 <JS_CallInternal+0x2e40>
   2ae16:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2ae1d:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2ae21:	e8 4a 1b ff ff       	call   1c970 <__JS_FreeValueRT>
   2ae26:	e9 34 a5 ff ff       	jmp    2535f <JS_CallInternal+0x27bf>
   2ae2b:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2ae32:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2ae36:	e8 35 1b ff ff       	call   1c970 <__JS_FreeValueRT>
   2ae3b:	e9 d4 a4 ff ff       	jmp    25314 <JS_CallInternal+0x2774>
   2ae40:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2ae47:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2ae4b:	e8 20 1b ff ff       	call   1c970 <__JS_FreeValueRT>
   2ae50:	e9 4f a5 ff ff       	jmp    253a4 <JS_CallInternal+0x2804>
   2ae55:	4c 89 f3             	mov    rbx,r14
   2ae58:	4d 89 ec             	mov    r12,r13
   2ae5b:	e9 e0 84 ff ff       	jmp    23340 <JS_CallInternal+0x7a0>
   2ae60:	4c 89 f3             	mov    rbx,r14
   2ae63:	e9 d8 84 ff ff       	jmp    23340 <JS_CallInternal+0x7a0>
   2ae68:	48 8b b5 d8 fe ff ff 	mov    rsi,QWORD PTR [rbp-0x128]
   2ae6f:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2ae76:	0f b7 d1             	movzx  edx,cx
   2ae79:	31 c9                	xor    ecx,ecx
   2ae7b:	4d 89 ec             	mov    r12,r13
   2ae7e:	e8 7d 84 00 00       	call   33300 <JS_ThrowReferenceErrorUninitialized2.isra.0>
   2ae83:	e9 b8 84 ff ff       	jmp    23340 <JS_CallInternal+0x7a0>
   2ae88:	48 8b b5 d8 fe ff ff 	mov    rsi,QWORD PTR [rbp-0x128]
   2ae8f:	48 8b bd a0 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x160]
   2ae96:	0f b7 d1             	movzx  edx,cx
   2ae99:	31 c9                	xor    ecx,ecx
   2ae9b:	4d 89 ec             	mov    r12,r13
   2ae9e:	e8 5d 84 00 00       	call   33300 <JS_ThrowReferenceErrorUninitialized2.isra.0>
   2aea3:	e9 98 84 ff ff       	jmp    23340 <JS_CallInternal+0x7a0>
   2aea8:	48 8b 85 d8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x128]
   2aeaf:	48 8d 15 fc 25 0a 00 	lea    rdx,[rip+0xa25fc]        # cd4b2 <_IO_stdin_used+0x4b2>
   2aeb6:	48 8b 40 30          	mov    rax,QWORD PTR [rax+0x30]
   2aeba:	8b 44 08 04          	mov    eax,DWORD PTR [rax+rcx*1+0x4]
   2aebe:	85 c0                	test   eax,eax
   2aec0:	0f 85 7e 1b 00 00    	jne    2ca44 <JS_CallInternal+0x9ea4>
   2aec6:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2aecd:	48 8d 35 3a 26 0a 00 	lea    rsi,[rip+0xa263a]        # cd50e <_IO_stdin_used+0x50e>
   2aed4:	31 c0                	xor    eax,eax
   2aed6:	4d 89 ec             	mov    r12,r13
   2aed9:	e8 92 82 00 00       	call   33170 <JS_ThrowReferenceError>
   2aede:	e9 5d 84 ff ff       	jmp    23340 <JS_CallInternal+0x7a0>
   2aee3:	48 8b 85 d8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x128]
   2aeea:	48 8b 40 30          	mov    rax,QWORD PTR [rax+0x30]
   2aeee:	8b 44 10 04          	mov    eax,DWORD PTR [rax+rdx*1+0x4]
   2aef2:	48 8d 15 b9 25 0a 00 	lea    rdx,[rip+0xa25b9]        # cd4b2 <_IO_stdin_used+0x4b2>
   2aef9:	85 c0                	test   eax,eax
   2aefb:	0f 85 61 1b 00 00    	jne    2ca62 <JS_CallInternal+0x9ec2>
   2af01:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2af08:	48 8d 35 ff 25 0a 00 	lea    rsi,[rip+0xa25ff]        # cd50e <_IO_stdin_used+0x50e>
   2af0f:	31 c0                	xor    eax,eax
   2af11:	4d 89 ec             	mov    r12,r13
   2af14:	e8 57 82 00 00       	call   33170 <JS_ThrowReferenceError>
   2af19:	e9 22 84 ff ff       	jmp    23340 <JS_CallInternal+0x7a0>
   2af1e:	0f 85 6e 1e 00 00    	jne    2cd92 <JS_CallInternal+0xa1f2>
   2af24:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2af2b:	48 8b 47 10          	mov    rax,QWORD PTR [rdi+0x10]
   2af2f:	48 8b 80 f0 04 00 00 	mov    rax,QWORD PTR [rax+0x4f0]
   2af36:	48 85 c0             	test   rax,rax
   2af39:	0f 84 dd c9 ff ff    	je     2791c <JS_CallInternal+0x4d7c>
   2af3f:	f6 40 3c 01          	test   BYTE PTR [rax+0x3c],0x1
   2af43:	0f 84 d3 c9 ff ff    	je     2791c <JS_CallInternal+0x4d7c>
   2af49:	44 89 ee             	mov    esi,r13d
   2af4c:	e8 4f 83 00 00       	call   332a0 <JS_ThrowReferenceErrorNotDefined>
   2af51:	41 81 fd f2 00 00 00 	cmp    r13d,0xf2
   2af58:	0f 8e e2 83 ff ff    	jle    23340 <JS_CallInternal+0x7a0>
   2af5e:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2af65:	44 89 ee             	mov    esi,r13d
   2af68:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2af6c:	e8 5f e5 fe ff       	call   194d0 <JS_FreeAtom.part.0.isra.0>
   2af71:	e9 ca 83 ff ff       	jmp    23340 <JS_CallInternal+0x7a0>
   2af76:	66 2e 0f 1f 84 00 00 	cs nop WORD PTR [rax+rax*1+0x0]
   2af7d:	00 00 00 
   2af80:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2af87:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2af8b:	e8 e0 19 ff ff       	call   1c970 <__JS_FreeValueRT>
   2af90:	e9 09 ca ff ff       	jmp    2799e <JS_CallInternal+0x4dfe>
   2af95:	83 fe 08             	cmp    esi,0x8
   2af98:	0f 84 e2 1a 00 00    	je     2ca80 <JS_CallInternal+0x9ee0>
   2af9e:	83 f9 08             	cmp    ecx,0x8
   2afa1:	75 08                	jne    2afab <JS_CallInternal+0x840b>
   2afa3:	85 f6                	test   esi,esi
   2afa5:	0f 84 0d 1b 00 00    	je     2cab8 <JS_CallInternal+0x9f18>
   2afab:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   2afb2:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2afb9:	44 89 ea             	mov    edx,r13d
   2afbc:	48 89 de             	mov    rsi,rbx
   2afbf:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   2afc3:	e8 28 fe 02 00       	call   5adf0 <js_relational_slow>
   2afc8:	85 c0                	test   eax,eax
   2afca:	0f 85 70 83 ff ff    	jne    23340 <JS_CallInternal+0x7a0>
   2afd0:	48 83 eb 10          	sub    rbx,0x10
   2afd4:	e9 87 bb ff ff       	jmp    26b60 <JS_CallInternal+0x3fc0>
   2afd9:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2afe0:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2afe4:	e8 87 19 ff ff       	call   1c970 <__JS_FreeValueRT>
   2afe9:	e9 93 c9 ff ff       	jmp    27981 <JS_CallInternal+0x4de1>
   2afee:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2aff5:	48 8b 40 10          	mov    rax,QWORD PTR [rax+0x10]
   2aff9:	48 8b 80 f0 04 00 00 	mov    rax,QWORD PTR [rax+0x4f0]
   2b000:	48 85 c0             	test   rax,rax
   2b003:	0f 84 e5 14 00 00    	je     2c4ee <JS_CallInternal+0x994e>
   2b009:	f6 40 3c 01          	test   BYTE PTR [rax+0x3c],0x1
   2b00d:	0f 84 db 14 00 00    	je     2c4ee <JS_CallInternal+0x994e>
   2b013:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2b01a:	44 89 ee             	mov    esi,r13d
   2b01d:	e8 7e 82 00 00       	call   332a0 <JS_ThrowReferenceErrorNotDefined>
   2b022:	41 81 fd f2 00 00 00 	cmp    r13d,0xf2
   2b029:	0f 8e 11 83 ff ff    	jle    23340 <JS_CallInternal+0x7a0>
   2b02f:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2b036:	44 89 ee             	mov    esi,r13d
   2b039:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2b03d:	e8 8e e4 fe ff       	call   194d0 <JS_FreeAtom.part.0.isra.0>
   2b042:	e9 f9 82 ff ff       	jmp    23340 <JS_CallInternal+0x7a0>
   2b047:	41 83 f9 08          	cmp    r9d,0x8
   2b04b:	0f 84 9b 1b 00 00    	je     2cbec <JS_CallInternal+0xa04c>
   2b051:	41 83 f9 ff          	cmp    r9d,0xffffffff
   2b055:	0f 84 47 1b 00 00    	je     2cba2 <JS_CallInternal+0xa002>
   2b05b:	41 8d 41 fe          	lea    eax,[r9-0x2]
   2b05f:	83 f8 01             	cmp    eax,0x1
   2b062:	0f 86 9e 1d 00 00    	jbe    2ce06 <JS_CallInternal+0xa266>
   2b068:	41 83 f9 f9          	cmp    r9d,0xfffffff9
   2b06c:	0f 85 f5 1a 00 00    	jne    2cb67 <JS_CallInternal+0x9fc7>
   2b072:	41 83 fe f9          	cmp    r14d,0xfffffff9
   2b076:	0f 85 eb 1a 00 00    	jne    2cb67 <JS_CallInternal+0x9fc7>
   2b07c:	4c 89 ee             	mov    rsi,r13
   2b07f:	4c 89 8d 38 fe ff ff 	mov    QWORD PTR [rbp-0x1c8],r9
   2b086:	48 89 95 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],rdx
   2b08d:	e8 de cd fe ff       	call   17e70 <js_string_eq.isra.0>
   2b092:	48 8b b5 40 fe ff ff 	mov    rsi,QWORD PTR [rbp-0x1c0]
   2b099:	4c 8b 8d 38 fe ff ff 	mov    r9,QWORD PTR [rbp-0x1c8]
   2b0a0:	89 85 50 fe ff ff    	mov    DWORD PTR [rbp-0x1b0],eax
   2b0a6:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2b0ad:	4c 89 ca             	mov    rdx,r9
   2b0b0:	e8 1b 1a ff ff       	call   1cad0 <JS_FreeValue>
   2b0b5:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2b0bc:	4c 89 ee             	mov    rsi,r13
   2b0bf:	4c 89 f2             	mov    rdx,r14
   2b0c2:	e8 09 1a ff ff       	call   1cad0 <JS_FreeValue>
   2b0c7:	31 c0                	xor    eax,eax
   2b0c9:	83 bd 50 fe ff ff 01 	cmp    DWORD PTR [rbp-0x1b0],0x1
   2b0d0:	0f 95 c0             	setne  al
   2b0d3:	e9 1e c7 ff ff       	jmp    277f6 <JS_CallInternal+0x4c56>
   2b0d8:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   2b0df:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2b0e6:	48 89 de             	mov    rsi,rbx
   2b0e9:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   2b0ed:	e8 7e ac 02 00       	call   55d70 <js_shr_slow>
   2b0f2:	85 c0                	test   eax,eax
   2b0f4:	0f 85 46 82 ff ff    	jne    23340 <JS_CallInternal+0x7a0>
   2b0fa:	48 83 eb 10          	sub    rbx,0x10
   2b0fe:	e9 69 b8 ff ff       	jmp    2696c <JS_CallInternal+0x3dcc>
   2b103:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2b10a:	e8 d1 84 00 00       	call   335e0 <__js_poll_interrupts>
   2b10f:	85 c0                	test   eax,eax
   2b111:	0f 84 e7 d7 ff ff    	je     288fe <JS_CallInternal+0x5d5e>
   2b117:	4d 89 ec             	mov    r12,r13
   2b11a:	e9 21 82 ff ff       	jmp    23340 <JS_CallInternal+0x7a0>
   2b11f:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2b126:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2b12a:	e9 b0 e0 ff ff       	jmp    291df <JS_CallInternal+0x663f>
   2b12f:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2b136:	48 8d 35 bb 5c 0a 00 	lea    rsi,[rip+0xa5cbb]        # d0df8 <_IO_stdin_used+0x3df8>
   2b13d:	31 c0                	xor    eax,eax
   2b13f:	4d 89 ec             	mov    r12,r13
   2b142:	e8 29 80 00 00       	call   33170 <JS_ThrowReferenceError>
   2b147:	e9 f4 81 ff ff       	jmp    23340 <JS_CallInternal+0x7a0>
   2b14c:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2b153:	31 c0                	xor    eax,eax
   2b155:	48 8d 35 04 24 0a 00 	lea    rsi,[rip+0xa2404]        # cd560 <_IO_stdin_used+0x560>
   2b15c:	e8 ff 82 00 00       	call   33460 <JS_ThrowInternalError>
   2b161:	83 fb f6             	cmp    ebx,0xfffffff6
   2b164:	76 13                	jbe    2b179 <JS_CallInternal+0x85d9>
   2b166:	41 8b 45 fc          	mov    eax,DWORD PTR [r13-0x4]
   2b16a:	83 e8 01             	sub    eax,0x1
   2b16d:	41 89 45 fc          	mov    DWORD PTR [r13-0x4],eax
   2b171:	85 c0                	test   eax,eax
   2b173:	0f 8e b5 13 00 00    	jle    2c52e <JS_CallInternal+0x998e>
   2b179:	4c 89 f3             	mov    rbx,r14
   2b17c:	e9 bf 81 ff ff       	jmp    23340 <JS_CallInternal+0x7a0>
   2b181:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2b188:	4c 89 ee             	mov    rsi,r13
   2b18b:	4c 89 f2             	mov    rdx,r14
   2b18e:	44 89 85 50 fe ff ff 	mov    DWORD PTR [rbp-0x1b0],r8d
   2b195:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2b199:	e8 d2 17 ff ff       	call   1c970 <__JS_FreeValueRT>
   2b19e:	44 8b 85 50 fe ff ff 	mov    r8d,DWORD PTR [rbp-0x1b0]
   2b1a5:	e9 39 a0 ff ff       	jmp    251e3 <JS_CallInternal+0x2643>
   2b1aa:	ba 01 00 00 00       	mov    edx,0x1
   2b1af:	be 03 00 00 00       	mov    esi,0x3
   2b1b4:	31 ff                	xor    edi,edi
   2b1b6:	e9 07 db ff ff       	jmp    28cc2 <JS_CallInternal+0x6122>
   2b1bb:	4d 89 ec             	mov    r12,r13
   2b1be:	e9 7d 81 ff ff       	jmp    23340 <JS_CallInternal+0x7a0>
   2b1c3:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   2b1ca:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2b1d1:	44 89 ea             	mov    edx,r13d
   2b1d4:	48 89 de             	mov    rsi,rbx
   2b1d7:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   2b1db:	e8 60 ad 02 00       	call   55f40 <js_binary_logic_slow>
   2b1e0:	85 c0                	test   eax,eax
   2b1e2:	0f 85 58 81 ff ff    	jne    23340 <JS_CallInternal+0x7a0>
   2b1e8:	48 83 eb 10          	sub    rbx,0x10
   2b1ec:	e9 d3 c1 ff ff       	jmp    273c4 <JS_CallInternal+0x4824>
   2b1f1:	4c 89 f3             	mov    rbx,r14
   2b1f4:	4d 89 ec             	mov    r12,r13
   2b1f7:	e9 44 81 ff ff       	jmp    23340 <JS_CallInternal+0x7a0>
   2b1fc:	48 8b b5 d8 fe ff ff 	mov    rsi,QWORD PTR [rbp-0x128]
   2b203:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2b20a:	31 c9                	xor    ecx,ecx
   2b20c:	4d 89 ec             	mov    r12,r13
   2b20f:	e8 ec 80 00 00       	call   33300 <JS_ThrowReferenceErrorUninitialized2.isra.0>
   2b214:	e9 27 81 ff ff       	jmp    23340 <JS_CallInternal+0x7a0>
   2b219:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2b220:	48 8d 35 f9 5b 0a 00 	lea    rsi,[rip+0xa5bf9]        # d0e20 <_IO_stdin_used+0x3e20>
   2b227:	31 c0                	xor    eax,eax
   2b229:	e8 52 5e 00 00       	call   31080 <JS_ThrowTypeError>
   2b22e:	e9 0d 81 ff ff       	jmp    23340 <JS_CallInternal+0x7a0>
   2b233:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2b23a:	48 8d 35 29 23 0a 00 	lea    rsi,[rip+0xa2329]        # cd56a <_IO_stdin_used+0x56a>
   2b241:	31 c0                	xor    eax,eax
   2b243:	e8 38 5e 00 00       	call   31080 <JS_ThrowTypeError>
   2b248:	4d 8b 4e 08          	mov    r9,QWORD PTR [r14+0x8]
   2b24c:	4c 8b 6b f0          	mov    r13,QWORD PTR [rbx-0x10]
   2b250:	48 89 c1             	mov    rcx,rax
   2b253:	41 89 d0             	mov    r8d,edx
   2b256:	48 89 d0             	mov    rax,rdx
   2b259:	e9 4f ce ff ff       	jmp    280ad <JS_CallInternal+0x550d>
   2b25e:	83 fe 08             	cmp    esi,0x8
   2b261:	0f 84 00 17 00 00    	je     2c967 <JS_CallInternal+0x9dc7>
   2b267:	85 f6                	test   esi,esi
   2b269:	75 09                	jne    2b274 <JS_CallInternal+0x86d4>
   2b26b:	83 f9 08             	cmp    ecx,0x8
   2b26e:	0f 84 2b 17 00 00    	je     2c99f <JS_CallInternal+0x9dff>
   2b274:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   2b27b:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2b282:	44 89 ea             	mov    edx,r13d
   2b285:	48 89 de             	mov    rsi,rbx
   2b288:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   2b28c:	e8 5f fb 02 00       	call   5adf0 <js_relational_slow>
   2b291:	85 c0                	test   eax,eax
   2b293:	0f 85 a7 80 ff ff    	jne    23340 <JS_CallInternal+0x7a0>
   2b299:	48 83 eb 10          	sub    rbx,0x10
   2b29d:	e9 06 b9 ff ff       	jmp    26ba8 <JS_CallInternal+0x4008>
   2b2a2:	4d 89 ec             	mov    r12,r13
   2b2a5:	e9 96 80 ff ff       	jmp    23340 <JS_CallInternal+0x7a0>
   2b2aa:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2b2b1:	48 8d 35 c0 22 0a 00 	lea    rsi,[rip+0xa22c0]        # cd578 <_IO_stdin_used+0x578>
   2b2b8:	31 c0                	xor    eax,eax
   2b2ba:	e8 c1 5d 00 00       	call   31080 <JS_ThrowTypeError>
   2b2bf:	4d 8b 4e 08          	mov    r9,QWORD PTR [r14+0x8]
   2b2c3:	4d 8b 2e             	mov    r13,QWORD PTR [r14]
   2b2c6:	48 89 c1             	mov    rcx,rax
   2b2c9:	41 89 d0             	mov    r8d,edx
   2b2cc:	48 89 d0             	mov    rax,rdx
   2b2cf:	e9 d9 cd ff ff       	jmp    280ad <JS_CallInternal+0x550d>
   2b2d4:	4c 89 f3             	mov    rbx,r14
   2b2d7:	4d 89 ec             	mov    r12,r13
   2b2da:	e9 61 80 ff ff       	jmp    23340 <JS_CallInternal+0x7a0>
   2b2df:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2b2e6:	e8 f5 82 00 00       	call   335e0 <__js_poll_interrupts>
   2b2eb:	85 c0                	test   eax,eax
   2b2ed:	0f 84 2e d9 ff ff    	je     28c21 <JS_CallInternal+0x6081>
   2b2f3:	4d 89 ec             	mov    r12,r13
   2b2f6:	e9 45 80 ff ff       	jmp    23340 <JS_CallInternal+0x7a0>
   2b2fb:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2b302:	48 89 ce             	mov    rsi,rcx
   2b305:	4c 89 ea             	mov    rdx,r13
   2b308:	44 89 85 50 fe ff ff 	mov    DWORD PTR [rbp-0x1b0],r8d
   2b30f:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2b313:	e8 58 16 ff ff       	call   1c970 <__JS_FreeValueRT>
   2b318:	44 8b 85 50 fe ff ff 	mov    r8d,DWORD PTR [rbp-0x1b0]
   2b31f:	e9 e2 bc ff ff       	jmp    27006 <JS_CallInternal+0x4466>
   2b324:	41 8b 4e 14          	mov    ecx,DWORD PTR [r14+0x14]
   2b328:	e9 03 e0 ff ff       	jmp    29330 <JS_CallInternal+0x6790>
   2b32d:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2b334:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2b338:	e8 33 16 ff ff       	call   1c970 <__JS_FreeValueRT>
   2b33d:	e9 72 df ff ff       	jmp    292b4 <JS_CallInternal+0x6714>
   2b342:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2b349:	e8 92 82 00 00       	call   335e0 <__js_poll_interrupts>
   2b34e:	85 c0                	test   eax,eax
   2b350:	0f 84 cd da ff ff    	je     28e23 <JS_CallInternal+0x6283>
   2b356:	4d 89 ec             	mov    r12,r13
   2b359:	e9 e2 7f ff ff       	jmp    23340 <JS_CallInternal+0x7a0>
   2b35e:	66 0f ef c0          	pxor   xmm0,xmm0
   2b362:	f2 48 0f 2a c0       	cvtsi2sd xmm0,rax
   2b367:	f2 0f 11 43 e0       	movsd  QWORD PTR [rbx-0x20],xmm0
   2b36c:	48 8d 53 f0          	lea    rdx,[rbx-0x10]
   2b370:	b8 08 00 00 00       	mov    eax,0x8
   2b375:	e9 01 bd ff ff       	jmp    2707b <JS_CallInternal+0x44db>
   2b37a:	83 fe 08             	cmp    esi,0x8
   2b37d:	0f 84 c0 13 00 00    	je     2c743 <JS_CallInternal+0x9ba3>
   2b383:	83 f8 08             	cmp    eax,0x8
   2b386:	0f 85 0b 89 ff ff    	jne    23c97 <JS_CallInternal+0x10f7>
   2b38c:	85 f6                	test   esi,esi
   2b38e:	0f 85 03 89 ff ff    	jne    23c97 <JS_CallInternal+0x10f7>
   2b394:	66 0f ef c9          	pxor   xmm1,xmm1
   2b398:	f2 0f 2a c9          	cvtsi2sd xmm1,ecx
   2b39c:	66 48 0f 6e c2       	movq   xmm0,rdx
   2b3a1:	f2 0f 59 c1          	mulsd  xmm0,xmm1
   2b3a5:	eb c0                	jmp    2b367 <JS_CallInternal+0x87c7>
   2b3a7:	66 0f ef c0          	pxor   xmm0,xmm0
   2b3ab:	f2 48 0f 2a c0       	cvtsi2sd xmm0,rax
   2b3b0:	b8 08 00 00 00       	mov    eax,0x8
   2b3b5:	f2 0f 11 43 e0       	movsd  QWORD PTR [rbx-0x20],xmm0
   2b3ba:	e9 14 bd ff ff       	jmp    270d3 <JS_CallInternal+0x4533>
   2b3bf:	83 fa 08             	cmp    edx,0x8
   2b3c2:	0f 84 9e 13 00 00    	je     2c766 <JS_CallInternal+0x9bc6>
   2b3c8:	83 f8 08             	cmp    eax,0x8
   2b3cb:	0f 85 c6 88 ff ff    	jne    23c97 <JS_CallInternal+0x10f7>
   2b3d1:	85 d2                	test   edx,edx
   2b3d3:	0f 85 be 88 ff ff    	jne    23c97 <JS_CallInternal+0x10f7>
   2b3d9:	66 0f ef c0          	pxor   xmm0,xmm0
   2b3dd:	f2 0f 2a c7          	cvtsi2sd xmm0,edi
   2b3e1:	66 48 0f 6e c9       	movq   xmm1,rcx
   2b3e6:	f2 0f 5c c1          	subsd  xmm0,xmm1
   2b3ea:	48 8d 53 f0          	lea    rdx,[rbx-0x10]
   2b3ee:	b8 08 00 00 00       	mov    eax,0x8
   2b3f3:	f2 0f 11 43 e0       	movsd  QWORD PTR [rbx-0x20],xmm0
   2b3f8:	e9 da bc ff ff       	jmp    270d7 <JS_CallInternal+0x4537>
   2b3fd:	66 0f ef c0          	pxor   xmm0,xmm0
   2b401:	b8 08 00 00 00       	mov    eax,0x8
   2b406:	f2 48 0f 2a c2       	cvtsi2sd xmm0,rdx
   2b40b:	f2 41 0f 11 45 00    	movsd  QWORD PTR [r13+0x0],xmm0
   2b411:	e9 31 bd ff ff       	jmp    27147 <JS_CallInternal+0x45a7>
   2b416:	48 83 eb 10          	sub    rbx,0x10
   2b41a:	83 fa 08             	cmp    edx,0x8
   2b41d:	0f 84 44 18 00 00    	je     2cc67 <JS_CallInternal+0xa0c7>
   2b423:	83 fa f9             	cmp    edx,0xfffffff9
   2b426:	0f 84 e2 0a 00 00    	je     2bf0e <JS_CallInternal+0x936e>
   2b42c:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   2b433:	4c 89 48 30          	mov    QWORD PTR [rax+0x30],r9
   2b437:	49 8b 45 00          	mov    rax,QWORD PTR [r13+0x0]
   2b43b:	83 fa f6             	cmp    edx,0xfffffff6
   2b43e:	0f 87 e3 0a 00 00    	ja     2bf27 <JS_CallInternal+0x9387>
   2b444:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2b44b:	48 8d b5 70 ff ff ff 	lea    rsi,[rbp-0x90]
   2b452:	4c 89 8d 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],r9
   2b459:	48 89 85 50 ff ff ff 	mov    QWORD PTR [rbp-0xb0],rax
   2b460:	48 89 95 58 ff ff ff 	mov    QWORD PTR [rbp-0xa8],rdx
   2b467:	4c 89 85 60 ff ff ff 	mov    QWORD PTR [rbp-0xa0],r8
   2b46e:	4c 89 b5 68 ff ff ff 	mov    QWORD PTR [rbp-0x98],r14
   2b475:	e8 46 b6 02 00       	call   56ac0 <js_add_slow>
   2b47a:	4c 8b 8d 50 fe ff ff 	mov    r9,QWORD PTR [rbp-0x1b0]
   2b481:	85 c0                	test   eax,eax
   2b483:	0f 85 1d 1b 00 00    	jne    2cfa6 <JS_CallInternal+0xa406>
   2b489:	49 8b 55 08          	mov    rdx,QWORD PTR [r13+0x8]
   2b48d:	66 0f 6f 95 50 ff ff 	movdqa xmm2,XMMWORD PTR [rbp-0xb0]
   2b494:	ff 
   2b495:	49 8b 75 00          	mov    rsi,QWORD PTR [r13+0x0]
   2b499:	41 0f 11 55 00       	movups XMMWORD PTR [r13+0x0],xmm2
   2b49e:	83 fa f6             	cmp    edx,0xfffffff6
   2b4a1:	0f 86 a8 bc ff ff    	jbe    2714f <JS_CallInternal+0x45af>
   2b4a7:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   2b4aa:	83 e8 01             	sub    eax,0x1
   2b4ad:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   2b4b0:	85 c0                	test   eax,eax
   2b4b2:	0f 8f 97 bc ff ff    	jg     2714f <JS_CallInternal+0x45af>
   2b4b8:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2b4bf:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2b4c3:	e8 a8 14 ff ff       	call   1c970 <__JS_FreeValueRT>
   2b4c8:	e9 82 bc ff ff       	jmp    2714f <JS_CallInternal+0x45af>
   2b4cd:	48 8b b5 d8 fe ff ff 	mov    rsi,QWORD PTR [rbp-0x128]
   2b4d4:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2b4db:	31 c9                	xor    ecx,ecx
   2b4dd:	4d 89 ec             	mov    r12,r13
   2b4e0:	e8 1b 7e 00 00       	call   33300 <JS_ThrowReferenceErrorUninitialized2.isra.0>
   2b4e5:	e9 56 7e ff ff       	jmp    23340 <JS_CallInternal+0x7a0>
   2b4ea:	48 8b 85 d8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x128]
   2b4f1:	48 8d 15 ba 1f 0a 00 	lea    rdx,[rip+0xa1fba]        # cd4b2 <_IO_stdin_used+0x4b2>
   2b4f8:	48 8b 40 30          	mov    rax,QWORD PTR [rax+0x30]
   2b4fc:	8b 44 08 04          	mov    eax,DWORD PTR [rax+rcx*1+0x4]
   2b500:	85 c0                	test   eax,eax
   2b502:	0f 85 db 11 00 00    	jne    2c6e3 <JS_CallInternal+0x9b43>
   2b508:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2b50f:	48 8d 35 f8 1f 0a 00 	lea    rsi,[rip+0xa1ff8]        # cd50e <_IO_stdin_used+0x50e>
   2b516:	31 c0                	xor    eax,eax
   2b518:	4d 89 ec             	mov    r12,r13
   2b51b:	e8 50 7c 00 00       	call   33170 <JS_ThrowReferenceError>
   2b520:	e9 1b 7e ff ff       	jmp    23340 <JS_CallInternal+0x7a0>
   2b525:	83 fe 08             	cmp    esi,0x8
   2b528:	0f 84 99 15 00 00    	je     2cac7 <JS_CallInternal+0x9f27>
   2b52e:	83 f9 08             	cmp    ecx,0x8
   2b531:	75 08                	jne    2b53b <JS_CallInternal+0x899b>
   2b533:	85 f6                	test   esi,esi
   2b535:	0f 84 c4 15 00 00    	je     2caff <JS_CallInternal+0x9f5f>
   2b53b:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   2b542:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2b549:	44 89 ea             	mov    edx,r13d
   2b54c:	48 89 de             	mov    rsi,rbx
   2b54f:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   2b553:	e8 98 f8 02 00       	call   5adf0 <js_relational_slow>
   2b558:	85 c0                	test   eax,eax
   2b55a:	0f 85 e0 7d ff ff    	jne    23340 <JS_CallInternal+0x7a0>
   2b560:	48 83 eb 10          	sub    rbx,0x10
   2b564:	e9 3a c3 ff ff       	jmp    278a3 <JS_CallInternal+0x4d03>
   2b569:	41 83 fd 08          	cmp    r13d,0x8
   2b56d:	0f 84 a2 13 00 00    	je     2c915 <JS_CallInternal+0x9d75>
   2b573:	41 83 fd ff          	cmp    r13d,0xffffffff
   2b577:	0f 84 31 13 00 00    	je     2c8ae <JS_CallInternal+0x9d0e>
   2b57d:	41 8d 4d fe          	lea    ecx,[r13-0x2]
   2b581:	83 f9 01             	cmp    ecx,0x1
   2b584:	0f 86 84 15 00 00    	jbe    2cb0e <JS_CallInternal+0x9f6e>
   2b58a:	4c 89 85 38 fe ff ff 	mov    QWORD PTR [rbp-0x1c8],r8
   2b591:	4c 89 8d 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],r9
   2b598:	41 83 fd f9          	cmp    r13d,0xfffffff9
   2b59c:	0f 85 4e ed ff ff    	jne    2a2f0 <JS_CallInternal+0x7750>
   2b5a2:	41 83 f8 f9          	cmp    r8d,0xfffffff9
   2b5a6:	0f 85 44 ed ff ff    	jne    2a2f0 <JS_CallInternal+0x7750>
   2b5ac:	e8 bf c8 fe ff       	call   17e70 <js_string_eq.isra.0>
   2b5b1:	4c 89 f6             	mov    rsi,r14
   2b5b4:	4c 8b b5 e8 fe ff ff 	mov    r14,QWORD PTR [rbp-0x118]
   2b5bb:	4c 89 ea             	mov    rdx,r13
   2b5be:	89 85 50 fe ff ff    	mov    DWORD PTR [rbp-0x1b0],eax
   2b5c4:	4c 89 f7             	mov    rdi,r14
   2b5c7:	e8 04 15 ff ff       	call   1cad0 <JS_FreeValue>
   2b5cc:	48 8b b5 40 fe ff ff 	mov    rsi,QWORD PTR [rbp-0x1c0]
   2b5d3:	48 8b 95 38 fe ff ff 	mov    rdx,QWORD PTR [rbp-0x1c8]
   2b5da:	4c 89 f7             	mov    rdi,r14
   2b5dd:	e8 ee 14 ff ff       	call   1cad0 <JS_FreeValue>
   2b5e2:	8b 85 50 fe ff ff    	mov    eax,DWORD PTR [rbp-0x1b0]
   2b5e8:	85 c0                	test   eax,eax
   2b5ea:	0f 95 c0             	setne  al
   2b5ed:	e9 cb b4 ff ff       	jmp    26abd <JS_CallInternal+0x3f1d>
   2b5f2:	66 0f 1f 44 00 00    	nop    WORD PTR [rax+rax*1+0x0]
   2b5f8:	41 8b 45 fc          	mov    eax,DWORD PTR [r13-0x4]
   2b5fc:	83 e8 01             	sub    eax,0x1
   2b5ff:	41 89 45 fc          	mov    DWORD PTR [r13-0x4],eax
   2b603:	85 c0                	test   eax,eax
   2b605:	0f 8f 88 ed ff ff    	jg     2a393 <JS_CallInternal+0x77f3>
   2b60b:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2b612:	4c 89 ee             	mov    rsi,r13
   2b615:	4c 89 f2             	mov    rdx,r14
   2b618:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2b61c:	e8 4f 13 ff ff       	call   1c970 <__JS_FreeValueRT>
   2b621:	e9 6d ed ff ff       	jmp    2a393 <JS_CallInternal+0x77f3>
   2b626:	41 83 fd 08          	cmp    r13d,0x8
   2b62a:	0f 84 c6 0f 00 00    	je     2c5f6 <JS_CallInternal+0x9a56>
   2b630:	41 83 fd ff          	cmp    r13d,0xffffffff
   2b634:	0f 84 4d 0f 00 00    	je     2c587 <JS_CallInternal+0x99e7>
   2b63a:	41 8d 4d fe          	lea    ecx,[r13-0x2]
   2b63e:	83 f9 01             	cmp    ecx,0x1
   2b641:	0f 86 02 0f 00 00    	jbe    2c549 <JS_CallInternal+0x99a9>
   2b647:	4c 89 85 38 fe ff ff 	mov    QWORD PTR [rbp-0x1c8],r8
   2b64e:	4c 89 8d 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],r9
   2b655:	41 83 fd f9          	cmp    r13d,0xfffffff9
   2b659:	0f 85 62 ec ff ff    	jne    2a2c1 <JS_CallInternal+0x7721>
   2b65f:	41 83 f8 f9          	cmp    r8d,0xfffffff9
   2b663:	0f 85 58 ec ff ff    	jne    2a2c1 <JS_CallInternal+0x7721>
   2b669:	e8 02 c8 fe ff       	call   17e70 <js_string_eq.isra.0>
   2b66e:	4c 89 f6             	mov    rsi,r14
   2b671:	4c 8b b5 e8 fe ff ff 	mov    r14,QWORD PTR [rbp-0x118]
   2b678:	4c 89 ea             	mov    rdx,r13
   2b67b:	89 85 50 fe ff ff    	mov    DWORD PTR [rbp-0x1b0],eax
   2b681:	4c 89 f7             	mov    rdi,r14
   2b684:	e8 47 14 ff ff       	call   1cad0 <JS_FreeValue>
   2b689:	48 8b b5 40 fe ff ff 	mov    rsi,QWORD PTR [rbp-0x1c0]
   2b690:	48 8b 95 38 fe ff ff 	mov    rdx,QWORD PTR [rbp-0x1c8]
   2b697:	4c 89 f7             	mov    rdi,r14
   2b69a:	e8 31 14 ff ff       	call   1cad0 <JS_FreeValue>
   2b69f:	8b 85 50 fe ff ff    	mov    eax,DWORD PTR [rbp-0x1b0]
   2b6a5:	e9 b3 b3 ff ff       	jmp    26a5d <JS_CallInternal+0x3ebd>
   2b6aa:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2b6b1:	e8 2a 7f 00 00       	call   335e0 <__js_poll_interrupts>
   2b6b6:	85 c0                	test   eax,eax
   2b6b8:	0f 84 a7 d2 ff ff    	je     28965 <JS_CallInternal+0x5dc5>
   2b6be:	4d 89 ec             	mov    r12,r13
   2b6c1:	e9 7a 7c ff ff       	jmp    23340 <JS_CallInternal+0x7a0>
   2b6c6:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   2b6cd:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2b6d4:	44 89 ea             	mov    edx,r13d
   2b6d7:	48 89 de             	mov    rsi,rbx
   2b6da:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   2b6de:	e8 5d a8 02 00       	call   55f40 <js_binary_logic_slow>
   2b6e3:	85 c0                	test   eax,eax
   2b6e5:	0f 85 55 7c ff ff    	jne    23340 <JS_CallInternal+0x7a0>
   2b6eb:	48 83 eb 10          	sub    rbx,0x10
   2b6ef:	e9 b5 b2 ff ff       	jmp    269a9 <JS_CallInternal+0x3e09>
   2b6f4:	48 83 ec 08          	sub    rsp,0x8
   2b6f8:	41 8b 4a 04          	mov    ecx,DWORD PTR [r10+0x4]
   2b6fc:	4c 8b 43 f0          	mov    r8,QWORD PTR [rbx-0x10]
   2b700:	48 83 eb 10          	sub    rbx,0x10
   2b704:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2b70b:	4c 8b 4b 08          	mov    r9,QWORD PTR [rbx+0x8]
   2b70f:	48 8b b0 80 01 00 00 	mov    rsi,QWORD PTR [rax+0x180]
   2b716:	48 8b 90 88 01 00 00 	mov    rdx,QWORD PTR [rax+0x188]
   2b71d:	68 00 80 00 00       	push   0x8000
   2b722:	48 89 c7             	mov    rdi,rax
   2b725:	ff b0 88 01 00 00    	push   QWORD PTR [rax+0x188]
   2b72b:	ff b0 80 01 00 00    	push   QWORD PTR [rax+0x180]
   2b731:	e8 0a 28 00 00       	call   2df40 <JS_SetPropertyInternal>
   2b736:	48 83 c4 20          	add    rsp,0x20
   2b73a:	85 c0                	test   eax,eax
   2b73c:	0f 89 e4 80 ff ff    	jns    23826 <JS_CallInternal+0xc86>
   2b742:	4d 89 f4             	mov    r12,r14
   2b745:	e9 f6 7b ff ff       	jmp    23340 <JS_CallInternal+0x7a0>
   2b74a:	66 0f 1f 44 00 00    	nop    WORD PTR [rax+rax*1+0x0]
   2b750:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2b757:	48 8d 35 1a 1e 0a 00 	lea    rsi,[rip+0xa1e1a]        # cd578 <_IO_stdin_used+0x578>
   2b75e:	31 c0                	xor    eax,eax
   2b760:	e8 1b 59 00 00       	call   31080 <JS_ThrowTypeError>
   2b765:	83 bd 50 fe ff ff f6 	cmp    DWORD PTR [rbp-0x1b0],0xfffffff6
   2b76c:	76 13                	jbe    2b781 <JS_CallInternal+0x8be1>
   2b76e:	41 8b 45 fc          	mov    eax,DWORD PTR [r13-0x4]
   2b772:	83 e8 01             	sub    eax,0x1
   2b775:	41 89 45 fc          	mov    DWORD PTR [r13-0x4],eax
   2b779:	85 c0                	test   eax,eax
   2b77b:	0f 8e 99 14 00 00    	jle    2cc1a <JS_CallInternal+0xa07a>
   2b781:	41 bd ff ff ff ff    	mov    r13d,0xffffffff
   2b787:	e9 93 ca ff ff       	jmp    2821f <JS_CallInternal+0x567f>
   2b78c:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2b793:	48 8d 35 d0 1d 0a 00 	lea    rsi,[rip+0xa1dd0]        # cd56a <_IO_stdin_used+0x56a>
   2b79a:	31 c0                	xor    eax,eax
   2b79c:	e8 df 58 00 00       	call   31080 <JS_ThrowTypeError>
   2b7a1:	eb c2                	jmp    2b765 <JS_CallInternal+0x8bc5>
   2b7a3:	48 8b bd 38 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x1c8]
   2b7aa:	e8 c1 11 ff ff       	call   1c970 <__JS_FreeValueRT>
   2b7af:	e9 68 ca ff ff       	jmp    2821c <JS_CallInternal+0x567c>
   2b7b4:	41 83 fd fa          	cmp    r13d,0xfffffffa
   2b7b8:	0f 8d f7 08 00 00    	jge    2c0b5 <JS_CallInternal+0x9515>
   2b7be:	41 83 fd f8          	cmp    r13d,0xfffffff8
   2b7c2:	0f 8d 26 e8 ff ff    	jge    29fee <JS_CallInternal+0x744e>
   2b7c8:	83 e8 02             	sub    eax,0x2
   2b7cb:	83 f8 01             	cmp    eax,0x1
   2b7ce:	0f 87 c1 e7 ff ff    	ja     29f95 <JS_CallInternal+0x73f5>
   2b7d4:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2b7db:	48 8d 35 ad 1d 0a 00 	lea    rsi,[rip+0xa1dad]        # cd58f <_IO_stdin_used+0x58f>
   2b7e2:	31 c0                	xor    eax,eax
   2b7e4:	e8 97 58 00 00       	call   31080 <JS_ThrowTypeError>
   2b7e9:	e9 52 7b ff ff       	jmp    23340 <JS_CallInternal+0x7a0>
   2b7ee:	41 83 f8 08          	cmp    r8d,0x8
   2b7f2:	0f 84 6c 0e 00 00    	je     2c664 <JS_CallInternal+0x9ac4>
   2b7f8:	41 83 f8 ff          	cmp    r8d,0xffffffff
   2b7fc:	0f 84 1c 0e 00 00    	je     2c61e <JS_CallInternal+0x9a7e>
   2b802:	41 8d 48 fe          	lea    ecx,[r8-0x2]
   2b806:	83 f9 01             	cmp    ecx,0x1
   2b809:	0f 86 e1 16 00 00    	jbe    2cef0 <JS_CallInternal+0xa350>
   2b80f:	41 83 f8 f9          	cmp    r8d,0xfffffff9
   2b813:	0f 85 9f 0d 00 00    	jne    2c5b8 <JS_CallInternal+0x9a18>
   2b819:	41 83 fe f9          	cmp    r14d,0xfffffff9
   2b81d:	0f 85 95 0d 00 00    	jne    2c5b8 <JS_CallInternal+0x9a18>
   2b823:	4c 89 ee             	mov    rsi,r13
   2b826:	48 89 95 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],rdx
   2b82d:	4c 89 85 38 fe ff ff 	mov    QWORD PTR [rbp-0x1c8],r8
   2b834:	e8 37 c6 fe ff       	call   17e70 <js_string_eq.isra.0>
   2b839:	48 8b b5 40 fe ff ff 	mov    rsi,QWORD PTR [rbp-0x1c0]
   2b840:	48 8b 95 38 fe ff ff 	mov    rdx,QWORD PTR [rbp-0x1c8]
   2b847:	89 85 50 fe ff ff    	mov    DWORD PTR [rbp-0x1b0],eax
   2b84d:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2b854:	e8 77 12 ff ff       	call   1cad0 <JS_FreeValue>
   2b859:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2b860:	4c 89 ee             	mov    rsi,r13
   2b863:	4c 89 f2             	mov    rdx,r14
   2b866:	e8 65 12 ff ff       	call   1cad0 <JS_FreeValue>
   2b86b:	8b 85 50 fe ff ff    	mov    eax,DWORD PTR [rbp-0x1b0]
   2b871:	85 c0                	test   eax,eax
   2b873:	0f 95 c0             	setne  al
   2b876:	0f b6 c0             	movzx  eax,al
   2b879:	e9 cc bf ff ff       	jmp    2784a <JS_CallInternal+0x4caa>
   2b87e:	4c 89 f3             	mov    rbx,r14
   2b881:	e9 ba 7a ff ff       	jmp    23340 <JS_CallInternal+0x7a0>
   2b886:	41 8b 4e 14          	mov    ecx,DWORD PTR [r14+0x14]
   2b88a:	e9 95 db ff ff       	jmp    29424 <JS_CallInternal+0x6884>
   2b88f:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   2b896:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2b89d:	44 89 ea             	mov    edx,r13d
   2b8a0:	48 89 de             	mov    rsi,rbx
   2b8a3:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   2b8a7:	e8 94 a6 02 00       	call   55f40 <js_binary_logic_slow>
   2b8ac:	85 c0                	test   eax,eax
   2b8ae:	0f 85 8c 7a ff ff    	jne    23340 <JS_CallInternal+0x7a0>
   2b8b4:	48 83 eb 10          	sub    rbx,0x10
   2b8b8:	e9 29 c1 ff ff       	jmp    279e6 <JS_CallInternal+0x4e46>
   2b8bd:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2b8c4:	48 8b 95 50 fe ff ff 	mov    rdx,QWORD PTR [rbp-0x1b0]
   2b8cb:	4c 89 f6             	mov    rsi,r14
   2b8ce:	44 89 85 38 fe ff ff 	mov    DWORD PTR [rbp-0x1c8],r8d
   2b8d5:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2b8d9:	e8 92 10 ff ff       	call   1c970 <__JS_FreeValueRT>
   2b8de:	44 8b 85 38 fe ff ff 	mov    r8d,DWORD PTR [rbp-0x1c8]
   2b8e5:	e9 f8 b6 ff ff       	jmp    26fe2 <JS_CallInternal+0x4442>
   2b8ea:	66 0f ef c0          	pxor   xmm0,xmm0
   2b8ee:	b8 08 00 00 00       	mov    eax,0x8
   2b8f3:	f2 48 0f 2a c1       	cvtsi2sd xmm0,rcx
   2b8f8:	f2 0f 11 43 e0       	movsd  QWORD PTR [rbx-0x20],xmm0
   2b8fd:	e9 a9 b8 ff ff       	jmp    271ab <JS_CallInternal+0x460b>
   2b902:	41 83 fb 08          	cmp    r11d,0x8
   2b906:	0f 84 7d 0e 00 00    	je     2c789 <JS_CallInternal+0x9be9>
   2b90c:	83 ff 08             	cmp    edi,0x8
   2b90f:	0f 84 9a 06 00 00    	je     2bfaf <JS_CallInternal+0x940f>
   2b915:	83 c6 07             	add    esi,0x7
   2b918:	83 fe 01             	cmp    esi,0x1
   2b91b:	0f 86 8f 13 00 00    	jbe    2ccb0 <JS_CallInternal+0xa110>
   2b921:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   2b928:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2b92f:	48 89 de             	mov    rsi,rbx
   2b932:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   2b936:	e8 85 b1 02 00       	call   56ac0 <js_add_slow>
   2b93b:	85 c0                	test   eax,eax
   2b93d:	0f 85 fd 79 ff ff    	jne    23340 <JS_CallInternal+0x7a0>
   2b943:	48 83 eb 10          	sub    rbx,0x10
   2b947:	e9 67 b8 ff ff       	jmp    271b3 <JS_CallInternal+0x4613>
   2b94c:	4c 89 f3             	mov    rbx,r14
   2b94f:	e9 ec 79 ff ff       	jmp    23340 <JS_CallInternal+0x7a0>
   2b954:	4d 89 d4             	mov    r12,r10
   2b957:	e9 e4 79 ff ff       	jmp    23340 <JS_CallInternal+0x7a0>
   2b95c:	48 89 85 28 fe ff ff 	mov    QWORD PTR [rbp-0x1d8],rax
   2b963:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2b96a:	4c 89 95 38 fe ff ff 	mov    QWORD PTR [rbp-0x1c8],r10
   2b971:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2b975:	e8 f6 0f ff ff       	call   1c970 <__JS_FreeValueRT>
   2b97a:	48 8b 85 28 fe ff ff 	mov    rax,QWORD PTR [rbp-0x1d8]
   2b981:	4c 8b 95 38 fe ff ff 	mov    r10,QWORD PTR [rbp-0x1c8]
   2b988:	e9 94 cc ff ff       	jmp    28621 <JS_CallInternal+0x5a81>
   2b98d:	48 89 85 28 fe ff ff 	mov    QWORD PTR [rbp-0x1d8],rax
   2b994:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2b99b:	4c 89 95 38 fe ff ff 	mov    QWORD PTR [rbp-0x1c8],r10
   2b9a2:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2b9a6:	e8 c5 0f ff ff       	call   1c970 <__JS_FreeValueRT>
   2b9ab:	48 8b 85 28 fe ff ff 	mov    rax,QWORD PTR [rbp-0x1d8]
   2b9b2:	4c 8b 95 38 fe ff ff 	mov    r10,QWORD PTR [rbp-0x1c8]
   2b9b9:	e9 80 cc ff ff       	jmp    2863e <JS_CallInternal+0x5a9e>
   2b9be:	48 89 85 38 fe ff ff 	mov    QWORD PTR [rbp-0x1c8],rax
   2b9c5:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2b9cc:	4c 89 95 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],r10
   2b9d3:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2b9d7:	e8 94 0f ff ff       	call   1c970 <__JS_FreeValueRT>
   2b9dc:	48 8b 85 38 fe ff ff 	mov    rax,QWORD PTR [rbp-0x1c8]
   2b9e3:	4c 8b 95 50 fe ff ff 	mov    r10,QWORD PTR [rbp-0x1b0]
   2b9ea:	e9 73 cc ff ff       	jmp    28662 <JS_CallInternal+0x5ac2>
   2b9ef:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   2b9f6:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2b9fd:	44 89 ea             	mov    edx,r13d
   2ba00:	48 89 de             	mov    rsi,rbx
   2ba03:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   2ba07:	e8 34 a5 02 00       	call   55f40 <js_binary_logic_slow>
   2ba0c:	85 c0                	test   eax,eax
   2ba0e:	0f 85 2c 79 ff ff    	jne    23340 <JS_CallInternal+0x7a0>
   2ba14:	48 83 eb 10          	sub    rbx,0x10
   2ba18:	e9 ca ae ff ff       	jmp    268e7 <JS_CallInternal+0x3d47>
   2ba1d:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   2ba24:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2ba2b:	44 89 ea             	mov    edx,r13d
   2ba2e:	48 89 de             	mov    rsi,rbx
   2ba31:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   2ba35:	e8 06 a5 02 00       	call   55f40 <js_binary_logic_slow>
   2ba3a:	85 c0                	test   eax,eax
   2ba3c:	0f 85 fe 78 ff ff    	jne    23340 <JS_CallInternal+0x7a0>
   2ba42:	48 83 eb 10          	sub    rbx,0x10
   2ba46:	e9 d9 ae ff ff       	jmp    26924 <JS_CallInternal+0x3d84>
   2ba4b:	0f 85 f2 14 00 00    	jne    2cf43 <JS_CallInternal+0xa3a3>
   2ba51:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2ba58:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2ba5c:	48 8b 87 f0 04 00 00 	mov    rax,QWORD PTR [rdi+0x4f0]
   2ba63:	48 85 c0             	test   rax,rax
   2ba66:	0f 84 e5 05 00 00    	je     2c051 <JS_CallInternal+0x94b1>
   2ba6c:	f6 40 3c 01          	test   BYTE PTR [rax+0x3c],0x1
   2ba70:	0f 84 db 05 00 00    	je     2c051 <JS_CallInternal+0x94b1>
   2ba76:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2ba7d:	44 89 ee             	mov    esi,r13d
   2ba80:	e8 1b 78 00 00       	call   332a0 <JS_ThrowReferenceErrorNotDefined>
   2ba85:	41 81 fd f2 00 00 00 	cmp    r13d,0xf2
   2ba8c:	0f 8e ae 78 ff ff    	jle    23340 <JS_CallInternal+0x7a0>
   2ba92:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2ba99:	44 89 ee             	mov    esi,r13d
   2ba9c:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2baa0:	e8 2b da fe ff       	call   194d0 <JS_FreeAtom.part.0.isra.0>
   2baa5:	e9 96 78 ff ff       	jmp    23340 <JS_CallInternal+0x7a0>
   2baaa:	4c 8b bd e8 fe ff ff 	mov    r15,QWORD PTR [rbp-0x118]
   2bab1:	48 8d 75 80          	lea    rsi,[rbp-0x80]
   2bab5:	44 89 ea             	mov    edx,r13d
   2bab8:	49 8b 7f 10          	mov    rdi,QWORD PTR [r15+0x10]
   2babc:	e8 af b8 fe ff       	call   17370 <JS_AtomGetStrRT.constprop.0>
   2bac1:	48 8d 35 dd 1a 0a 00 	lea    rsi,[rip+0xa1add]        # cd5a5 <_IO_stdin_used+0x5a5>
   2bac8:	4c 89 ff             	mov    rdi,r15
   2bacb:	48 89 c2             	mov    rdx,rax
   2bace:	31 c0                	xor    eax,eax
   2bad0:	e8 9b 76 00 00       	call   33170 <JS_ThrowReferenceError>
   2bad5:	41 81 fd f2 00 00 00 	cmp    r13d,0xf2
   2badc:	0f 8e 5e 78 ff ff    	jle    23340 <JS_CallInternal+0x7a0>
   2bae2:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2bae9:	44 89 ee             	mov    esi,r13d
   2baec:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2baf0:	e8 db d9 fe ff       	call   194d0 <JS_FreeAtom.part.0.isra.0>
   2baf5:	e9 46 78 ff ff       	jmp    23340 <JS_CallInternal+0x7a0>
   2bafa:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2bb01:	e8 da 7a 00 00       	call   335e0 <__js_poll_interrupts>
   2bb06:	85 c0                	test   eax,eax
   2bb08:	0f 84 d3 d0 ff ff    	je     28be1 <JS_CallInternal+0x6041>
   2bb0e:	4d 89 ec             	mov    r12,r13
   2bb11:	e9 2a 78 ff ff       	jmp    23340 <JS_CallInternal+0x7a0>
   2bb16:	4c 8b a5 28 fe ff ff 	mov    r12,QWORD PTR [rbp-0x1d8]
   2bb1d:	e9 1e 78 ff ff       	jmp    23340 <JS_CallInternal+0x7a0>
   2bb22:	4d 89 d4             	mov    r12,r10
   2bb25:	e9 16 78 ff ff       	jmp    23340 <JS_CallInternal+0x7a0>
   2bb2a:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2bb31:	48 8d 35 40 1a 0a 00 	lea    rsi,[rip+0xa1a40]        # cd578 <_IO_stdin_used+0x578>
   2bb38:	31 c0                	xor    eax,eax
   2bb3a:	e8 41 55 00 00       	call   31080 <JS_ThrowTypeError>
   2bb3f:	e9 18 b1 ff ff       	jmp    26c5c <JS_CallInternal+0x40bc>
   2bb44:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2bb4b:	48 8d 35 18 1a 0a 00 	lea    rsi,[rip+0xa1a18]        # cd56a <_IO_stdin_used+0x56a>
   2bb52:	31 c0                	xor    eax,eax
   2bb54:	e8 27 55 00 00       	call   31080 <JS_ThrowTypeError>
   2bb59:	e9 fe b0 ff ff       	jmp    26c5c <JS_CallInternal+0x40bc>
   2bb5e:	83 fe 08             	cmp    esi,0x8
   2bb61:	0f 84 7e 0c 00 00    	je     2c7e5 <JS_CallInternal+0x9c45>
   2bb67:	85 f6                	test   esi,esi
   2bb69:	75 09                	jne    2bb74 <JS_CallInternal+0x8fd4>
   2bb6b:	83 f9 08             	cmp    ecx,0x8
   2bb6e:	0f 84 ea 0c 00 00    	je     2c85e <JS_CallInternal+0x9cbe>
   2bb74:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   2bb7b:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2bb82:	44 89 ea             	mov    edx,r13d
   2bb85:	48 89 de             	mov    rsi,rbx
   2bb88:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   2bb8c:	e8 5f f2 02 00       	call   5adf0 <js_relational_slow>
   2bb91:	85 c0                	test   eax,eax
   2bb93:	0f 85 a7 77 ff ff    	jne    23340 <JS_CallInternal+0x7a0>
   2bb99:	48 83 eb 10          	sub    rbx,0x10
   2bb9d:	e9 76 af ff ff       	jmp    26b18 <JS_CallInternal+0x3f78>
   2bba2:	44 8b 95 50 fe ff ff 	mov    r10d,DWORD PTR [rbp-0x1b0]
   2bba9:	45 85 d2             	test   r10d,r10d
   2bbac:	74 3d                	je     2bbeb <JS_CallInternal+0x904b>
   2bbae:	4c 8b a5 e8 fe ff ff 	mov    r12,QWORD PTR [rbp-0x118]
   2bbb5:	4c 89 eb             	mov    rbx,r13
   2bbb8:	4d 01 ee             	add    r14,r13
   2bbbb:	eb 09                	jmp    2bbc6 <JS_CallInternal+0x9026>
   2bbbd:	48 83 c3 10          	add    rbx,0x10
   2bbc1:	4c 39 f3             	cmp    rbx,r14
   2bbc4:	74 25                	je     2bbeb <JS_CallInternal+0x904b>
   2bbc6:	48 8b 53 08          	mov    rdx,QWORD PTR [rbx+0x8]
   2bbca:	48 8b 33             	mov    rsi,QWORD PTR [rbx]
   2bbcd:	83 fa f6             	cmp    edx,0xfffffff6
   2bbd0:	76 eb                	jbe    2bbbd <JS_CallInternal+0x901d>
   2bbd2:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   2bbd5:	83 e8 01             	sub    eax,0x1
   2bbd8:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   2bbdb:	85 c0                	test   eax,eax
   2bbdd:	7f de                	jg     2bbbd <JS_CallInternal+0x901d>
   2bbdf:	49 8b 7c 24 10       	mov    rdi,QWORD PTR [r12+0x10]
   2bbe4:	e8 87 0d ff ff       	call   1c970 <__JS_FreeValueRT>
   2bbe9:	eb d2                	jmp    2bbbd <JS_CallInternal+0x901d>
   2bbeb:	4c 8b a5 38 fe ff ff 	mov    r12,QWORD PTR [rbp-0x1c8]
   2bbf2:	4c 89 eb             	mov    rbx,r13
   2bbf5:	e9 46 77 ff ff       	jmp    23340 <JS_CallInternal+0x7a0>
   2bbfa:	4c 89 f3             	mov    rbx,r14
   2bbfd:	4d 89 ec             	mov    r12,r13
   2bc00:	e9 3b 77 ff ff       	jmp    23340 <JS_CallInternal+0x7a0>
   2bc05:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2bc0c:	e8 cf 79 00 00       	call   335e0 <__js_poll_interrupts>
   2bc11:	85 c0                	test   eax,eax
   2bc13:	0f 84 35 be ff ff    	je     27a4e <JS_CallInternal+0x4eae>
   2bc19:	4d 89 ec             	mov    r12,r13
   2bc1c:	e9 1f 77 ff ff       	jmp    23340 <JS_CallInternal+0x7a0>
   2bc21:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2bc28:	e8 b3 79 00 00       	call   335e0 <__js_poll_interrupts>
   2bc2d:	85 c0                	test   eax,eax
   2bc2f:	0f 84 54 b7 ff ff    	je     27389 <JS_CallInternal+0x47e9>
   2bc35:	4d 89 ec             	mov    r12,r13
   2bc38:	e9 03 77 ff ff       	jmp    23340 <JS_CallInternal+0x7a0>
   2bc3d:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2bc44:	48 8b 95 50 fe ff ff 	mov    rdx,QWORD PTR [rbp-0x1b0]
   2bc4b:	48 89 ce             	mov    rsi,rcx
   2bc4e:	44 89 85 38 fe ff ff 	mov    DWORD PTR [rbp-0x1c8],r8d
   2bc55:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2bc59:	e8 12 0d ff ff       	call   1c970 <__JS_FreeValueRT>
   2bc5e:	44 8b 85 38 fe ff ff 	mov    r8d,DWORD PTR [rbp-0x1c8]
   2bc65:	e9 60 95 ff ff       	jmp    251ca <JS_CallInternal+0x262a>
   2bc6a:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2bc71:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2bc75:	e8 f6 0c ff ff       	call   1c970 <__JS_FreeValueRT>
   2bc7a:	e9 be 92 ff ff       	jmp    24f3d <JS_CallInternal+0x239d>
   2bc7f:	39 c2                	cmp    edx,eax
   2bc81:	0f 85 77 df ff ff    	jne    29bfe <JS_CallInternal+0x705e>
   2bc87:	0f b6 51 10          	movzx  edx,BYTE PTR [rcx+0x10]
   2bc8b:	f7 d2                	not    edx
   2bc8d:	83 e2 12             	and    edx,0x12
   2bc90:	0f 85 68 df ff ff    	jne    29bfe <JS_CallInternal+0x705e>
   2bc96:	48 8b 79 18          	mov    rdi,QWORD PTR [rcx+0x18]
   2bc9a:	48 8b 57 30          	mov    rdx,QWORD PTR [rdi+0x30]
   2bc9e:	48 85 d2             	test   rdx,rdx
   2bca1:	74 0a                	je     2bcad <JS_CallInternal+0x910d>
   2bca3:	f6 42 10 01          	test   BYTE PTR [rdx+0x10],0x1
   2bca7:	0f 84 51 df ff ff    	je     29bfe <JS_CallInternal+0x705e>
   2bcad:	48 8b 71 20          	mov    rsi,QWORD PTR [rcx+0x20]
   2bcb1:	44 8b 56 08          	mov    r10d,DWORD PTR [rsi+0x8]
   2bcb5:	45 85 d2             	test   r10d,r10d
   2bcb8:	0f 85 40 df ff ff    	jne    29bfe <JS_CallInternal+0x705e>
   2bcbe:	8d 50 01             	lea    edx,[rax+0x1]
   2bcc1:	39 51 28             	cmp    DWORD PTR [rcx+0x28],edx
   2bcc4:	0f 82 34 df ff ff    	jb     29bfe <JS_CallInternal+0x705e>
   2bcca:	39 16                	cmp    DWORD PTR [rsi],edx
   2bccc:	73 1c                	jae    2bcea <JS_CallInternal+0x914a>
   2bcce:	44 8b 47 18          	mov    r8d,DWORD PTR [rdi+0x18]
   2bcd2:	42 f6 44 87 3f 08    	test   BYTE PTR [rdi+r8*4+0x3f],0x8
   2bcd8:	0f 84 20 df ff ff    	je     29bfe <JS_CallInternal+0x705e>
   2bcde:	89 d7                	mov    edi,edx
   2bce0:	45 31 c9             	xor    r9d,r9d
   2bce3:	48 89 3e             	mov    QWORD PTR [rsi],rdi
   2bce6:	4c 89 4e 08          	mov    QWORD PTR [rsi+0x8],r9
   2bcea:	89 51 38             	mov    DWORD PTR [rcx+0x38],edx
   2bced:	89 c0                	mov    eax,eax
   2bcef:	f3 0f 6f 4b f0       	movdqu xmm1,XMMWORD PTR [rbx-0x10]
   2bcf4:	48 c1 e0 04          	shl    rax,0x4
   2bcf8:	48 03 41 30          	add    rax,QWORD PTR [rcx+0x30]
   2bcfc:	0f 11 08             	movups XMMWORD PTR [rax],xmm1
   2bcff:	e9 a5 ca ff ff       	jmp    287a9 <JS_CallInternal+0x5c09>
   2bd04:	0f 1f 40 00          	nop    DWORD PTR [rax+0x0]
   2bd08:	4c 89 f3             	mov    rbx,r14
   2bd0b:	e9 30 76 ff ff       	jmp    23340 <JS_CallInternal+0x7a0>
   2bd10:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2bd17:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2bd1b:	e8 50 0c ff ff       	call   1c970 <__JS_FreeValueRT>
   2bd20:	e9 84 ca ff ff       	jmp    287a9 <JS_CallInternal+0x5c09>
   2bd25:	09 ca                	or     edx,ecx
   2bd27:	0f 89 41 b3 ff ff    	jns    2706e <JS_CallInternal+0x44ce>
   2bd2d:	f2 0f 10 05 6b ed 0a 	movsd  xmm0,QWORD PTR [rip+0xaed6b]        # daaa0 <typed_array_size_log2+0x28>
   2bd34:	00 
   2bd35:	e9 2d f6 ff ff       	jmp    2b367 <JS_CallInternal+0x87c7>
   2bd3a:	3d f2 00 00 00       	cmp    eax,0xf2
   2bd3f:	7e 43                	jle    2bd84 <JS_CallInternal+0x91e4>
   2bd41:	31 d2                	xor    edx,edx
   2bd43:	48 8b 8d e8 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x118]
   2bd4a:	89 c0                	mov    eax,eax
   2bd4c:	48 8b 79 10          	mov    rdi,QWORD PTR [rcx+0x10]
   2bd50:	48 8b 8f 48 04 00 00 	mov    rcx,QWORD PTR [rdi+0x448]
   2bd57:	48 8b 34 c1          	mov    rsi,QWORD PTR [rcx+rax*8]
   2bd5b:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   2bd5e:	83 e8 01             	sub    eax,0x1
   2bd61:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   2bd64:	85 c0                	test   eax,eax
   2bd66:	7f 13                	jg     2bd7b <JS_CallInternal+0x91db>
   2bd68:	48 89 95 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],rdx
   2bd6f:	e8 cc 96 fe ff       	call   15440 <JS_FreeAtomStruct>
   2bd74:	48 8b 95 50 fe ff ff 	mov    rdx,QWORD PTR [rbp-0x1b0]
   2bd7b:	48 85 d2             	test   rdx,rdx
   2bd7e:	0f 85 0d 99 ff ff    	jne    25691 <JS_CallInternal+0x2af1>
   2bd84:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2bd8b:	48 8d 35 76 4f 0a 00 	lea    rsi,[rip+0xa4f76]        # d0d08 <_IO_stdin_used+0x3d08>
   2bd92:	31 c0                	xor    eax,eax
   2bd94:	e8 e7 52 00 00       	call   31080 <JS_ThrowTypeError>
   2bd99:	48 c7 03 00 00 00 00 	mov    QWORD PTR [rbx],0x0
   2bda0:	48 c7 43 08 06 00 00 	mov    QWORD PTR [rbx+0x8],0x6
   2bda7:	00 
   2bda8:	e9 83 97 ff ff       	jmp    25530 <JS_CallInternal+0x2990>
   2bdad:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2bdb4:	4c 89 ee             	mov    rsi,r13
   2bdb7:	4c 89 f2             	mov    rdx,r14
   2bdba:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2bdbe:	e8 ad 0b ff ff       	call   1c970 <__JS_FreeValueRT>
   2bdc3:	e9 51 bd ff ff       	jmp    27b19 <JS_CallInternal+0x4f79>
   2bdc8:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2bdcf:	89 8d 50 fe ff ff    	mov    DWORD PTR [rbp-0x1b0],ecx
   2bdd5:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2bdd9:	e8 92 0b ff ff       	call   1c970 <__JS_FreeValueRT>
   2bdde:	8b 8d 50 fe ff ff    	mov    ecx,DWORD PTR [rbp-0x1b0]
   2bde4:	e9 99 b9 ff ff       	jmp    27782 <JS_CallInternal+0x4be2>
   2bde9:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2bdf0:	4c 89 f6             	mov    rsi,r14
   2bdf3:	4c 89 ea             	mov    rdx,r13
   2bdf6:	89 8d 50 fe ff ff    	mov    DWORD PTR [rbp-0x1b0],ecx
   2bdfc:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2be00:	e8 6b 0b ff ff       	call   1c970 <__JS_FreeValueRT>
   2be05:	8b 8d 50 fe ff ff    	mov    ecx,DWORD PTR [rbp-0x1b0]
   2be0b:	e9 8b b9 ff ff       	jmp    2779b <JS_CallInternal+0x4bfb>
   2be10:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2be17:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2be1b:	e8 50 0b ff ff       	call   1c970 <__JS_FreeValueRT>
   2be20:	e9 a5 c9 ff ff       	jmp    287ca <JS_CallInternal+0x5c2a>
   2be25:	8b 01                	mov    eax,DWORD PTR [rcx]
   2be27:	25 ff ff ff 03       	and    eax,0x3ffffff
   2be2c:	0f 85 48 c2 ff ff    	jne    2807a <JS_CallInternal+0x54da>
   2be32:	48 8b bd 28 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x1d8]
   2be39:	48 8d 75 80          	lea    rsi,[rbp-0x80]
   2be3d:	e8 2e b5 fe ff       	call   17370 <JS_AtomGetStrRT.constprop.0>
   2be42:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2be49:	48 8d 35 f0 4f 0a 00 	lea    rsi,[rip+0xa4ff0]        # d0e40 <_IO_stdin_used+0x3e40>
   2be50:	48 89 c2             	mov    rdx,rax
   2be53:	31 c0                	xor    eax,eax
   2be55:	e8 26 52 00 00       	call   31080 <JS_ThrowTypeError>
   2be5a:	4d 8b 4e 08          	mov    r9,QWORD PTR [r14+0x8]
   2be5e:	4d 8b 2e             	mov    r13,QWORD PTR [r14]
   2be61:	31 c9                	xor    ecx,ecx
   2be63:	41 b8 06 00 00 00    	mov    r8d,0x6
   2be69:	b8 06 00 00 00       	mov    eax,0x6
   2be6e:	e9 3a c2 ff ff       	jmp    280ad <JS_CallInternal+0x550d>
   2be73:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2be7a:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2be7e:	e8 ed 0a ff ff       	call   1c970 <__JS_FreeValueRT>
   2be83:	e9 78 bc ff ff       	jmp    27b00 <JS_CallInternal+0x4f60>
   2be88:	8b 01                	mov    eax,DWORD PTR [rcx]
   2be8a:	25 ff ff ff 03       	and    eax,0x3ffffff
   2be8f:	0f 85 3f c3 ff ff    	jne    281d4 <JS_CallInternal+0x5634>
   2be95:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2be9c:	48 8d 0d a1 12 0a 00 	lea    rcx,[rip+0xa12a1]        # cd144 <_IO_stdin_used+0x144>
   2bea3:	31 c0                	xor    eax,eax
   2bea5:	48 8d 15 94 4f 0a 00 	lea    rdx,[rip+0xa4f94]        # d0e40 <_IO_stdin_used+0x3e40>
   2beac:	e8 df 53 00 00       	call   31290 <__JS_ThrowTypeErrorAtom>
   2beb1:	e9 af f8 ff ff       	jmp    2b765 <JS_CallInternal+0x8bc5>
   2beb6:	66 2e 0f 1f 84 00 00 	cs nop WORD PTR [rax+rax*1+0x0]
   2bebd:	00 00 00 
   2bec0:	8b 85 88 fe ff ff    	mov    eax,DWORD PTR [rbp-0x178]
   2bec6:	83 e8 02             	sub    eax,0x2
   2bec9:	83 f8 01             	cmp    eax,0x1
   2becc:	0f 87 67 0d 00 00    	ja     2cc39 <JS_CallInternal+0xa099>
   2bed2:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2bed9:	48 8b 88 80 01 00 00 	mov    rcx,QWORD PTR [rax+0x180]
   2bee0:	48 8b 80 88 01 00 00 	mov    rax,QWORD PTR [rax+0x188]
   2bee7:	83 f8 f6             	cmp    eax,0xfffffff6
   2beea:	0f 86 a2 98 ff ff    	jbe    25792 <JS_CallInternal+0x2bf2>
   2bef0:	83 41 fc 01          	add    DWORD PTR [rcx-0x4],0x1
   2bef4:	e9 99 98 ff ff       	jmp    25792 <JS_CallInternal+0x2bf2>
   2bef9:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2bf00:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2bf04:	e8 67 0a ff ff       	call   1c970 <__JS_FreeValueRT>
   2bf09:	e9 9a 78 ff ff       	jmp    237a8 <JS_CallInternal+0xc08>
   2bf0e:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   2bf15:	41 83 fe f9          	cmp    r14d,0xfffffff9
   2bf19:	4c 89 48 30          	mov    QWORD PTR [rax+0x30],r9
   2bf1d:	0f 84 10 0f 00 00    	je     2ce33 <JS_CallInternal+0xa293>
   2bf23:	49 8b 45 00          	mov    rax,QWORD PTR [r13+0x0]
   2bf27:	83 40 fc 01          	add    DWORD PTR [rax-0x4],0x1
   2bf2b:	e9 14 f5 ff ff       	jmp    2b444 <JS_CallInternal+0x88a4>
   2bf30:	0f 85 70 77 ff ff    	jne    236a6 <JS_CallInternal+0xb06>
   2bf36:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2bf3d:	48 8b 47 10          	mov    rax,QWORD PTR [rdi+0x10]
   2bf41:	48 8b 80 f0 04 00 00 	mov    rax,QWORD PTR [rax+0x4f0]
   2bf48:	48 85 c0             	test   rax,rax
   2bf4b:	0f 84 e5 76 ff ff    	je     23636 <JS_CallInternal+0xa96>
   2bf51:	f6 40 3c 01          	test   BYTE PTR [rax+0x3c],0x1
   2bf55:	0f 84 db 76 ff ff    	je     23636 <JS_CallInternal+0xa96>
   2bf5b:	8b b5 38 fe ff ff    	mov    esi,DWORD PTR [rbp-0x1c8]
   2bf61:	e8 3a 73 00 00       	call   332a0 <JS_ThrowReferenceErrorNotDefined>
   2bf66:	e9 3b 77 ff ff       	jmp    236a6 <JS_CallInternal+0xb06>
   2bf6b:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2bf72:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2bf76:	e8 f5 09 ff ff       	call   1c970 <__JS_FreeValueRT>
   2bf7b:	e9 1a 77 ff ff       	jmp    2369a <JS_CallInternal+0xafa>
   2bf80:	0f 85 20 77 ff ff    	jne    236a6 <JS_CallInternal+0xb06>
   2bf86:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2bf8d:	48 8b 47 10          	mov    rax,QWORD PTR [rdi+0x10]
   2bf91:	48 8b 80 f0 04 00 00 	mov    rax,QWORD PTR [rax+0x4f0]
   2bf98:	48 85 c0             	test   rax,rax
   2bf9b:	74 06                	je     2bfa3 <JS_CallInternal+0x9403>
   2bf9d:	f6 40 3c 01          	test   BYTE PTR [rax+0x3c],0x1
   2bfa1:	75 b8                	jne    2bf5b <JS_CallInternal+0x93bb>
   2bfa3:	b8 03 00 00 00       	mov    eax,0x3
   2bfa8:	31 c9                	xor    ecx,ecx
   2bfaa:	e9 6b 77 ff ff       	jmp    2371a <JS_CallInternal+0xb7a>
   2bfaf:	45 85 db             	test   r11d,r11d
   2bfb2:	0f 85 69 f9 ff ff    	jne    2b921 <JS_CallInternal+0x8d81>
   2bfb8:	66 0f ef c9          	pxor   xmm1,xmm1
   2bfbc:	f2 41 0f 2a ca       	cvtsi2sd xmm1,r10d
   2bfc1:	66 48 0f 6e c0       	movq   xmm0,rax
   2bfc6:	f2 0f 58 c1          	addsd  xmm0,xmm1
   2bfca:	48 c7 43 e8 08 00 00 	mov    QWORD PTR [rbx-0x18],0x8
   2bfd1:	00 
   2bfd2:	48 83 eb 10          	sub    rbx,0x10
   2bfd6:	f2 0f 11 43 f0       	movsd  QWORD PTR [rbx-0x10],xmm0
   2bfdb:	e9 d3 b1 ff ff       	jmp    271b3 <JS_CallInternal+0x4613>
   2bfe0:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2bfe7:	48 89 8d 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],rcx
   2bfee:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2bff2:	e8 79 09 ff ff       	call   1c970 <__JS_FreeValueRT>
   2bff7:	48 8b 8d 50 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x1b0]
   2bffe:	e9 36 d9 ff ff       	jmp    29939 <JS_CallInternal+0x6d99>
   2c003:	89 c8                	mov    eax,ecx
   2c005:	31 d2                	xor    edx,edx
   2c007:	e9 73 b5 ff ff       	jmp    2757f <JS_CallInternal+0x49df>
   2c00c:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2c013:	4c 89 85 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],r8
   2c01a:	4c 89 8d 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],r9
   2c021:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2c025:	e8 46 09 ff ff       	call   1c970 <__JS_FreeValueRT>
   2c02a:	4c 8b 85 40 fe ff ff 	mov    r8,QWORD PTR [rbp-0x1c0]
   2c031:	4c 8b 8d 50 fe ff ff 	mov    r9,QWORD PTR [rbp-0x1b0]
   2c038:	e9 43 90 ff ff       	jmp    25080 <JS_CallInternal+0x24e0>
   2c03d:	48 8b bd c0 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x140]
   2c044:	4c 89 ee             	mov    rsi,r13
   2c047:	e8 44 47 ff ff       	call   20790 <free_var_ref>
   2c04c:	e9 da 72 ff ff       	jmp    2332b <JS_CallInternal+0x78b>
   2c051:	41 81 fd f2 00 00 00 	cmp    r13d,0xf2
   2c058:	0f 8f 8c 09 00 00    	jg     2c9ea <JS_CallInternal+0x9e4a>
   2c05e:	b8 03 00 00 00       	mov    eax,0x3
   2c063:	31 c9                	xor    ecx,ecx
   2c065:	e9 b9 c6 ff ff       	jmp    28723 <JS_CallInternal+0x5b83>
   2c06a:	4d 89 f4             	mov    r12,r14
   2c06d:	e9 ce 72 ff ff       	jmp    23340 <JS_CallInternal+0x7a0>
   2c072:	8b 12                	mov    edx,DWORD PTR [rdx]
   2c074:	81 e2 ff ff ff 03    	and    edx,0x3ffffff
   2c07a:	0f 85 31 ae ff ff    	jne    26eb1 <JS_CallInternal+0x4311>
   2c080:	31 d2                	xor    edx,edx
   2c082:	e9 3a ae ff ff       	jmp    26ec1 <JS_CallInternal+0x4321>
   2c087:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2c08e:	4c 89 ee             	mov    rsi,r13
   2c091:	4c 89 f2             	mov    rdx,r14
   2c094:	89 8d 40 fe ff ff    	mov    DWORD PTR [rbp-0x1c0],ecx
   2c09a:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2c09e:	e8 cd 08 ff ff       	call   1c970 <__JS_FreeValueRT>
   2c0a3:	8b 8d 40 fe ff ff    	mov    ecx,DWORD PTR [rbp-0x1c0]
   2c0a9:	4c 8b 95 50 fe ff ff 	mov    r10,QWORD PTR [rbp-0x1b0]
   2c0b0:	e9 e7 da ff ff       	jmp    29b9c <JS_CallInternal+0x6ffc>
   2c0b5:	45 85 ed             	test   r13d,r13d
   2c0b8:	0f 85 0a f7 ff ff    	jne    2b7c8 <JS_CallInternal+0x8c28>
   2c0be:	e9 2b df ff ff       	jmp    29fee <JS_CallInternal+0x744e>
   2c0c3:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2c0ca:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2c0ce:	e8 9d 08 ff ff       	call   1c970 <__JS_FreeValueRT>
   2c0d3:	e9 85 db ff ff       	jmp    29c5d <JS_CallInternal+0x70bd>
   2c0d8:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2c0df:	48 8d 35 92 4c 0a 00 	lea    rsi,[rip+0xa4c92]        # d0d78 <_IO_stdin_used+0x3d78>
   2c0e6:	31 c0                	xor    eax,eax
   2c0e8:	e8 93 4f 00 00       	call   31080 <JS_ThrowTypeError>
   2c0ed:	e9 4e 72 ff ff       	jmp    23340 <JS_CallInternal+0x7a0>
   2c0f2:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2c0f9:	48 89 8d 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],rcx
   2c100:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2c104:	e8 67 08 ff ff       	call   1c970 <__JS_FreeValueRT>
   2c109:	48 8b 8d 50 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x1b0]
   2c110:	e9 28 d6 ff ff       	jmp    2973d <JS_CallInternal+0x6b9d>
   2c115:	f2 0f 10 05 83 e9 0a 	movsd  xmm0,QWORD PTR [rip+0xae983]        # daaa0 <typed_array_size_log2+0x28>
   2c11c:	00 
   2c11d:	e9 b0 d5 ff ff       	jmp    296d2 <JS_CallInternal+0x6b32>
   2c122:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2c129:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2c12d:	e8 3e 08 ff ff       	call   1c970 <__JS_FreeValueRT>
   2c132:	e9 64 d5 ff ff       	jmp    2969b <JS_CallInternal+0x6afb>
   2c137:	f2 0f 10 05 d1 72 0a 	movsd  xmm0,QWORD PTR [rip+0xa72d1]        # d3410 <__PRETTY_FUNCTION__.0+0xc0>
   2c13e:	00 
   2c13f:	e9 8e d5 ff ff       	jmp    296d2 <JS_CallInternal+0x6b32>
   2c144:	83 f9 f6             	cmp    ecx,0xfffffff6
   2c147:	0f 86 61 fa ff ff    	jbe    2bbae <JS_CallInternal+0x900e>
   2c14d:	41 8b 40 fc          	mov    eax,DWORD PTR [r8-0x4]
   2c151:	83 e8 01             	sub    eax,0x1
   2c154:	41 89 40 fc          	mov    DWORD PTR [r8-0x4],eax
   2c158:	85 c0                	test   eax,eax
   2c15a:	0f 8f 4e fa ff ff    	jg     2bbae <JS_CallInternal+0x900e>
   2c160:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2c167:	4c 89 c6             	mov    rsi,r8
   2c16a:	48 89 ca             	mov    rdx,rcx
   2c16d:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2c171:	e8 fa 07 ff ff       	call   1c970 <__JS_FreeValueRT>
   2c176:	e9 33 fa ff ff       	jmp    2bbae <JS_CallInternal+0x900e>
   2c17b:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2c182:	48 89 95 38 fe ff ff 	mov    QWORD PTR [rbp-0x1c8],rdx
   2c189:	48 63 d7             	movsxd rdx,edi
   2c18c:	48 c1 e2 04          	shl    rdx,0x4
   2c190:	4c 89 8d 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],r9
   2c197:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2c19b:	48 89 d6             	mov    rsi,rdx
   2c19e:	48 89 95 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],rdx
   2c1a5:	e8 e6 87 fe ff       	call   14990 <__js_malloc>
   2c1aa:	48 8b 95 50 fe ff ff 	mov    rdx,QWORD PTR [rbp-0x1b0]
   2c1b1:	4c 8b 8d 40 fe ff ff 	mov    r9,QWORD PTR [rbp-0x1c0]
   2c1b8:	48 85 c0             	test   rax,rax
   2c1bb:	48 8b 8d 38 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x1c8]
   2c1c2:	0f 84 28 0f 00 00    	je     2d0f0 <JS_CallInternal+0xa550>
   2c1c8:	4c 8b 95 a8 fe ff ff 	mov    r10,QWORD PTR [rbp-0x158]
   2c1cf:	31 f6                	xor    esi,esi
   2c1d1:	4d 8b 44 32 08       	mov    r8,QWORD PTR [r10+rsi*1+0x8]
   2c1d6:	49 8b 3c 32          	mov    rdi,QWORD PTR [r10+rsi*1]
   2c1da:	41 83 f8 f6          	cmp    r8d,0xfffffff6
   2c1de:	76 04                	jbe    2c1e4 <JS_CallInternal+0x9644>
   2c1e0:	83 47 fc 01          	add    DWORD PTR [rdi-0x4],0x1
   2c1e4:	48 89 3c 30          	mov    QWORD PTR [rax+rsi*1],rdi
   2c1e8:	4c 89 44 30 08       	mov    QWORD PTR [rax+rsi*1+0x8],r8
   2c1ed:	48 83 c6 10          	add    rsi,0x10
   2c1f1:	48 39 f2             	cmp    rdx,rsi
   2c1f4:	75 db                	jne    2c1d1 <JS_CallInternal+0x9631>
   2c1f6:	e9 f0 93 ff ff       	jmp    255eb <JS_CallInternal+0x2a4b>
   2c1fb:	48 89 85 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],rax
   2c202:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2c209:	4c 89 c2             	mov    rdx,r8
   2c20c:	4c 89 8d 38 fe ff ff 	mov    QWORD PTR [rbp-0x1c8],r9
   2c213:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2c217:	89 8d 50 fe ff ff    	mov    DWORD PTR [rbp-0x1b0],ecx
   2c21d:	e8 4e 07 ff ff       	call   1c970 <__JS_FreeValueRT>
   2c222:	4c 8b 8d 38 fe ff ff 	mov    r9,QWORD PTR [rbp-0x1c8]
   2c229:	48 8b 85 40 fe ff ff 	mov    rax,QWORD PTR [rbp-0x1c0]
   2c230:	8b 8d 50 fe ff ff    	mov    ecx,DWORD PTR [rbp-0x1b0]
   2c236:	e9 cc dc ff ff       	jmp    29f07 <JS_CallInternal+0x7367>
   2c23b:	48 8b 8d e8 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x118]
   2c242:	48 89 c6             	mov    rsi,rax
   2c245:	4c 89 ca             	mov    rdx,r9
   2c248:	48 8b 79 10          	mov    rdi,QWORD PTR [rcx+0x10]
   2c24c:	e8 1f 07 ff ff       	call   1c970 <__JS_FreeValueRT>
   2c251:	e9 e0 dc ff ff       	jmp    29f36 <JS_CallInternal+0x7396>
   2c256:	48 8b 8d e8 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x118]
   2c25d:	48 8d 45 80          	lea    rax,[rbp-0x80]
   2c261:	89 f2                	mov    edx,esi
   2c263:	48 89 c6             	mov    rsi,rax
   2c266:	48 8b 79 10          	mov    rdi,QWORD PTR [rcx+0x10]
   2c26a:	e8 01 b1 fe ff       	call   17370 <JS_AtomGetStrRT.constprop.0>
   2c26f:	48 89 c2             	mov    rdx,rax
   2c272:	e9 71 83 ff ff       	jmp    245e8 <JS_CallInternal+0x1a48>
   2c277:	49 39 51 30          	cmp    QWORD PTR [r9+0x30],rdx
   2c27b:	0f 85 6e 7f ff ff    	jne    241ef <JS_CallInternal+0x164f>
   2c281:	8b 52 10             	mov    edx,DWORD PTR [rdx+0x10]
   2c284:	81 e2 08 00 ff ff    	and    edx,0xffff0008
   2c28a:	81 fa 00 00 01 00    	cmp    edx,0x10000
   2c290:	0f 85 59 7f ff ff    	jne    241ef <JS_CallInternal+0x164f>
   2c296:	41 80 79 10 00       	cmp    BYTE PTR [r9+0x10],0x0
   2c29b:	0f 84 4e 7f ff ff    	je     241ef <JS_CallInternal+0x164f>
   2c2a1:	41 80 7d 10 00       	cmp    BYTE PTR [r13+0x10],0x0
   2c2a6:	0f 84 43 7f ff ff    	je     241ef <JS_CallInternal+0x164f>
   2c2ac:	83 3d 61 ad 0d 00 00 	cmp    DWORD PTR [rip+0xdad61],0x0        # 107014 <qjs_experiment_proto_ic_enabled>
   2c2b3:	0f 84 36 7f ff ff    	je     241ef <JS_CallInternal+0x164f>
   2c2b9:	49 8b 36             	mov    rsi,QWORD PTR [r14]
   2c2bc:	48 c1 f9 04          	sar    rcx,0x4
   2c2c0:	48 89 8d 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],rcx
   2c2c7:	4c 39 ce             	cmp    rsi,r9
   2c2ca:	0f 84 3c 0d 00 00    	je     2d00c <JS_CallInternal+0xa46c>
   2c2d0:	41 83 41 fc 01       	add    DWORD PTR [r9-0x4],0x1
   2c2d5:	41 83 45 fc 01       	add    DWORD PTR [r13-0x4],0x1
   2c2da:	48 85 f6             	test   rsi,rsi
   2c2dd:	0f 85 f8 0c 00 00    	jne    2cfdb <JS_CallInternal+0xa43b>
   2c2e3:	49 8b 76 08          	mov    rsi,QWORD PTR [r14+0x8]
   2c2e7:	48 85 f6             	test   rsi,rsi
   2c2ea:	74 2c                	je     2c318 <JS_CallInternal+0x9778>
   2c2ec:	48 89 85 28 fe ff ff 	mov    QWORD PTR [rbp-0x1d8],rax
   2c2f3:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2c2fa:	4c 89 8d 10 fe ff ff 	mov    QWORD PTR [rbp-0x1f0],r9
   2c301:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2c305:	e8 76 20 ff ff       	call   1e380 <js_free_shape>
   2c30a:	4c 8b 8d 10 fe ff ff 	mov    r9,QWORD PTR [rbp-0x1f0]
   2c311:	48 8b 85 28 fe ff ff 	mov    rax,QWORD PTR [rbp-0x1d8]
   2c318:	66 49 0f 6e c1       	movq   xmm0,r9
   2c31d:	66 49 0f 6e f5       	movq   xmm6,r13
   2c322:	66 0f 6c c6          	punpcklqdq xmm0,xmm6
   2c326:	41 0f 11 06          	movups XMMWORD PTR [r14],xmm0
   2c32a:	8b 8d 40 fe ff ff    	mov    ecx,DWORD PTR [rbp-0x1c0]
   2c330:	41 89 4e 10          	mov    DWORD PTR [r14+0x10],ecx
   2c334:	e9 b6 7e ff ff       	jmp    241ef <JS_CallInternal+0x164f>
   2c339:	8b 52 10             	mov    edx,DWORD PTR [rdx+0x10]
   2c33c:	81 e2 08 00 ff ff    	and    edx,0xffff0008
   2c342:	81 fa 00 00 01 00    	cmp    edx,0x10000
   2c348:	0f 85 a1 7e ff ff    	jne    241ef <JS_CallInternal+0x164f>
   2c34e:	41 80 7d 10 00       	cmp    BYTE PTR [r13+0x10],0x0
   2c353:	0f 84 96 7e ff ff    	je     241ef <JS_CallInternal+0x164f>
   2c359:	49 8b 36             	mov    rsi,QWORD PTR [r14]
   2c35c:	48 c1 f9 04          	sar    rcx,0x4
   2c360:	48 89 8d 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],rcx
   2c367:	4c 39 ee             	cmp    rsi,r13
   2c36a:	0f 84 0f 0d 00 00    	je     2d07f <JS_CallInternal+0xa4df>
   2c370:	41 83 45 fc 01       	add    DWORD PTR [r13-0x4],0x1
   2c375:	48 85 f6             	test   rsi,rsi
   2c378:	0f 85 d8 09 00 00    	jne    2cd56 <JS_CallInternal+0xa1b6>
   2c37e:	49 8b 76 08          	mov    rsi,QWORD PTR [r14+0x8]
   2c382:	48 85 f6             	test   rsi,rsi
   2c385:	74 1e                	je     2c3a5 <JS_CallInternal+0x9805>
   2c387:	48 89 85 28 fe ff ff 	mov    QWORD PTR [rbp-0x1d8],rax
   2c38e:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2c395:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2c399:	e8 e2 1f ff ff       	call   1e380 <js_free_shape>
   2c39e:	48 8b 85 28 fe ff ff 	mov    rax,QWORD PTR [rbp-0x1d8]
   2c3a5:	45 31 db             	xor    r11d,r11d
   2c3a8:	4d 89 2e             	mov    QWORD PTR [r14],r13
   2c3ab:	4d 89 5e 08          	mov    QWORD PTR [r14+0x8],r11
   2c3af:	e9 76 ff ff ff       	jmp    2c32a <JS_CallInternal+0x978a>
   2c3b4:	49 39 51 30          	cmp    QWORD PTR [r9+0x30],rdx
   2c3b8:	0f 85 26 7d ff ff    	jne    240e4 <JS_CallInternal+0x1544>
   2c3be:	8b 42 10             	mov    eax,DWORD PTR [rdx+0x10]
   2c3c1:	25 08 00 ff ff       	and    eax,0xffff0008
   2c3c6:	3d 00 00 01 00       	cmp    eax,0x10000
   2c3cb:	0f 85 13 7d ff ff    	jne    240e4 <JS_CallInternal+0x1544>
   2c3d1:	41 80 79 10 00       	cmp    BYTE PTR [r9+0x10],0x0
   2c3d6:	0f 84 08 7d ff ff    	je     240e4 <JS_CallInternal+0x1544>
   2c3dc:	41 80 7d 10 00       	cmp    BYTE PTR [r13+0x10],0x0
   2c3e1:	0f 84 fd 7c ff ff    	je     240e4 <JS_CallInternal+0x1544>
   2c3e7:	83 3d 26 ac 0d 00 00 	cmp    DWORD PTR [rip+0xdac26],0x0        # 107014 <qjs_experiment_proto_ic_enabled>
   2c3ee:	0f 84 f0 7c ff ff    	je     240e4 <JS_CallInternal+0x1544>
   2c3f4:	48 c1 fe 04          	sar    rsi,0x4
   2c3f8:	48 89 b5 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],rsi
   2c3ff:	49 8b 36             	mov    rsi,QWORD PTR [r14]
   2c402:	4c 39 ce             	cmp    rsi,r9
   2c405:	0f 84 53 0c 00 00    	je     2d05e <JS_CallInternal+0xa4be>
   2c40b:	41 83 41 fc 01       	add    DWORD PTR [r9-0x4],0x1
   2c410:	41 83 45 fc 01       	add    DWORD PTR [r13-0x4],0x1
   2c415:	48 85 f6             	test   rsi,rsi
   2c418:	0f 85 0f 0c 00 00    	jne    2d02d <JS_CallInternal+0xa48d>
   2c41e:	49 8b 76 08          	mov    rsi,QWORD PTR [r14+0x8]
   2c422:	48 85 f6             	test   rsi,rsi
   2c425:	74 2c                	je     2c453 <JS_CallInternal+0x98b3>
   2c427:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2c42e:	4c 89 8d 28 fe ff ff 	mov    QWORD PTR [rbp-0x1d8],r9
   2c435:	48 89 8d 38 fe ff ff 	mov    QWORD PTR [rbp-0x1c8],rcx
   2c43c:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2c440:	e8 3b 1f ff ff       	call   1e380 <js_free_shape>
   2c445:	4c 8b 8d 28 fe ff ff 	mov    r9,QWORD PTR [rbp-0x1d8]
   2c44c:	48 8b 8d 38 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x1c8]
   2c453:	66 49 0f 6e c1       	movq   xmm0,r9
   2c458:	66 49 0f 6e fd       	movq   xmm7,r13
   2c45d:	66 0f 6c c7          	punpcklqdq xmm0,xmm7
   2c461:	41 0f 11 06          	movups XMMWORD PTR [r14],xmm0
   2c465:	8b 85 50 fe ff ff    	mov    eax,DWORD PTR [rbp-0x1b0]
   2c46b:	41 89 46 10          	mov    DWORD PTR [r14+0x10],eax
   2c46f:	e9 70 7c ff ff       	jmp    240e4 <JS_CallInternal+0x1544>
   2c474:	41 8b 42 10          	mov    eax,DWORD PTR [r10+0x10]
   2c478:	25 08 00 ff ff       	and    eax,0xffff0008
   2c47d:	3d 00 00 01 00       	cmp    eax,0x10000
   2c482:	0f 85 5c 7c ff ff    	jne    240e4 <JS_CallInternal+0x1544>
   2c488:	41 80 7d 10 00       	cmp    BYTE PTR [r13+0x10],0x0
   2c48d:	0f 84 51 7c ff ff    	je     240e4 <JS_CallInternal+0x1544>
   2c493:	48 c1 fe 04          	sar    rsi,0x4
   2c497:	48 89 b5 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],rsi
   2c49e:	49 8b 36             	mov    rsi,QWORD PTR [r14]
   2c4a1:	4c 39 ee             	cmp    rsi,r13
   2c4a4:	0f 84 79 08 00 00    	je     2cd23 <JS_CallInternal+0xa183>
   2c4aa:	41 83 45 fc 01       	add    DWORD PTR [r13-0x4],0x1
   2c4af:	48 85 f6             	test   rsi,rsi
   2c4b2:	0f 85 20 0c 00 00    	jne    2d0d8 <JS_CallInternal+0xa538>
   2c4b8:	49 8b 76 08          	mov    rsi,QWORD PTR [r14+0x8]
   2c4bc:	48 85 f6             	test   rsi,rsi
   2c4bf:	74 1e                	je     2c4df <JS_CallInternal+0x993f>
   2c4c1:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2c4c8:	48 89 8d 38 fe ff ff 	mov    QWORD PTR [rbp-0x1c8],rcx
   2c4cf:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2c4d3:	e8 a8 1e ff ff       	call   1e380 <js_free_shape>
   2c4d8:	48 8b 8d 38 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x1c8]
   2c4df:	45 31 c0             	xor    r8d,r8d
   2c4e2:	4d 89 2e             	mov    QWORD PTR [r14],r13
   2c4e5:	4d 89 46 08          	mov    QWORD PTR [r14+0x8],r8
   2c4e9:	e9 77 ff ff ff       	jmp    2c465 <JS_CallInternal+0x98c5>
   2c4ee:	48 8b 8d e8 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x118]
   2c4f5:	48 8b 91 88 01 00 00 	mov    rdx,QWORD PTR [rcx+0x188]
   2c4fc:	48 8b 81 80 01 00 00 	mov    rax,QWORD PTR [rcx+0x180]
   2c503:	83 fa f6             	cmp    edx,0xfffffff6
   2c506:	76 04                	jbe    2c50c <JS_CallInternal+0x996c>
   2c508:	83 40 fc 01          	add    DWORD PTR [rax-0x4],0x1
   2c50c:	48 89 43 d0          	mov    QWORD PTR [rbx-0x30],rax
   2c510:	48 89 53 d8          	mov    QWORD PTR [rbx-0x28],rdx
   2c514:	e9 e0 b3 ff ff       	jmp    278f9 <JS_CallInternal+0x4d59>
   2c519:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2c520:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2c524:	e8 47 04 ff ff       	call   1c970 <__JS_FreeValueRT>
   2c529:	e9 d2 c5 ff ff       	jmp    28b00 <JS_CallInternal+0x5f60>
   2c52e:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2c535:	4c 89 ee             	mov    rsi,r13
   2c538:	48 89 da             	mov    rdx,rbx
   2c53b:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2c53f:	e8 2c 04 ff ff       	call   1c970 <__JS_FreeValueRT>
   2c544:	e9 30 ec ff ff       	jmp    2b179 <JS_CallInternal+0x85d9>
   2c549:	41 8d 50 fe          	lea    edx,[r8-0x2]
   2c54d:	83 fa 01             	cmp    edx,0x1
   2c550:	0f 86 58 0a 00 00    	jbe    2cfae <JS_CallInternal+0xa40e>
   2c556:	83 c0 01             	add    eax,0x1
   2c559:	0f 85 62 dd ff ff    	jne    2a2c1 <JS_CallInternal+0x7721>
   2c55f:	41 0f b6 41 11       	movzx  eax,BYTE PTR [r9+0x11]
   2c564:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2c56b:	4c 89 c2             	mov    rdx,r8
   2c56e:	83 e0 01             	and    eax,0x1
   2c571:	89 85 50 fe ff ff    	mov    DWORD PTR [rbp-0x1b0],eax
   2c577:	e8 54 05 ff ff       	call   1cad0 <JS_FreeValue>
   2c57c:	8b 85 50 fe ff ff    	mov    eax,DWORD PTR [rbp-0x1b0]
   2c582:	e9 d6 a4 ff ff       	jmp    26a5d <JS_CallInternal+0x3ebd>
   2c587:	41 8d 50 fe          	lea    edx,[r8-0x2]
   2c58b:	83 fa 01             	cmp    edx,0x1
   2c58e:	0f 86 84 09 00 00    	jbe    2cf18 <JS_CallInternal+0xa378>
   2c594:	83 c0 01             	add    eax,0x1
   2c597:	0f 85 24 dd ff ff    	jne    2a2c1 <JS_CallInternal+0x7721>
   2c59d:	31 c0                	xor    eax,eax
   2c59f:	4d 39 ce             	cmp    r14,r9
   2c5a2:	4c 89 85 38 fe ff ff 	mov    QWORD PTR [rbp-0x1c8],r8
   2c5a9:	4c 89 8d 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],r9
   2c5b0:	0f 94 c0             	sete   al
   2c5b3:	e9 b6 f0 ff ff       	jmp    2b66e <JS_CallInternal+0x8ace>
   2c5b8:	4d 89 c1             	mov    r9,r8
   2c5bb:	48 89 d7             	mov    rdi,rdx
   2c5be:	45 31 c0             	xor    r8d,r8d
   2c5c1:	4c 89 ea             	mov    rdx,r13
   2c5c4:	4c 89 ce             	mov    rsi,r9
   2c5c7:	4c 89 f1             	mov    rcx,r14
   2c5ca:	48 89 bd 38 fe ff ff 	mov    QWORD PTR [rbp-0x1c8],rdi
   2c5d1:	4c 89 8d 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],r9
   2c5d8:	e8 53 df fe ff       	call   1a530 <js_strict_eq2.isra.0>
   2c5dd:	48 8b b5 38 fe ff ff 	mov    rsi,QWORD PTR [rbp-0x1c8]
   2c5e4:	48 8b 95 40 fe ff ff 	mov    rdx,QWORD PTR [rbp-0x1c0]
   2c5eb:	89 85 50 fe ff ff    	mov    DWORD PTR [rbp-0x1b0],eax
   2c5f1:	e9 57 f2 ff ff       	jmp    2b84d <JS_CallInternal+0x8cad>
   2c5f6:	45 85 c0             	test   r8d,r8d
   2c5f9:	0f 85 8f 00 00 00    	jne    2c68e <JS_CallInternal+0x9aee>
   2c5ff:	66 0f ef c0          	pxor   xmm0,xmm0
   2c603:	66 49 0f 6e de       	movq   xmm3,r14
   2c608:	31 d2                	xor    edx,edx
   2c60a:	f2 41 0f 2a c1       	cvtsi2sd xmm0,r9d
   2c60f:	66 0f 2e c3          	ucomisd xmm0,xmm3
   2c613:	0f 9b c2             	setnp  dl
   2c616:	0f 44 c2             	cmove  eax,edx
   2c619:	e9 3f a4 ff ff       	jmp    26a5d <JS_CallInternal+0x3ebd>
   2c61e:	31 c0                	xor    eax,eax
   2c620:	41 83 fe ff          	cmp    r14d,0xffffffff
   2c624:	75 08                	jne    2c62e <JS_CallInternal+0x9a8e>
   2c626:	31 c0                	xor    eax,eax
   2c628:	4c 39 ea             	cmp    rdx,r13
   2c62b:	0f 94 c0             	sete   al
   2c62e:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2c635:	48 89 d6             	mov    rsi,rdx
   2c638:	4c 89 c2             	mov    rdx,r8
   2c63b:	89 85 50 fe ff ff    	mov    DWORD PTR [rbp-0x1b0],eax
   2c641:	e8 8a 04 ff ff       	call   1cad0 <JS_FreeValue>
   2c646:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2c64d:	4c 89 ee             	mov    rsi,r13
   2c650:	4c 89 f2             	mov    rdx,r14
   2c653:	e8 78 04 ff ff       	call   1cad0 <JS_FreeValue>
   2c658:	48 63 85 50 fe ff ff 	movsxd rax,DWORD PTR [rbp-0x1b0]
   2c65f:	e9 e6 b1 ff ff       	jmp    2784a <JS_CallInternal+0x4caa>
   2c664:	45 85 f6             	test   r14d,r14d
   2c667:	75 4f                	jne    2c6b8 <JS_CallInternal+0x9b18>
   2c669:	66 0f ef c0          	pxor   xmm0,xmm0
   2c66d:	66 48 0f 6e f2       	movq   xmm6,rdx
   2c672:	31 c0                	xor    eax,eax
   2c674:	ba 00 00 00 00       	mov    edx,0x0
   2c679:	f2 41 0f 2a c5       	cvtsi2sd xmm0,r13d
   2c67e:	66 0f 2e c6          	ucomisd xmm0,xmm6
   2c682:	0f 9b c0             	setnp  al
   2c685:	48 0f 45 c2          	cmovne rax,rdx
   2c689:	e9 bc b1 ff ff       	jmp    2784a <JS_CallInternal+0x4caa>
   2c68e:	41 83 f8 08          	cmp    r8d,0x8
   2c692:	0f 85 29 dc ff ff    	jne    2a2c1 <JS_CallInternal+0x7721>
   2c698:	66 49 0f 6e c6       	movq   xmm0,r14
   2c69d:	66 49 0f 6e e1       	movq   xmm4,r9
   2c6a2:	31 c0                	xor    eax,eax
   2c6a4:	ba 00 00 00 00       	mov    edx,0x0
   2c6a9:	66 0f 2e c4          	ucomisd xmm0,xmm4
   2c6ad:	0f 9b c0             	setnp  al
   2c6b0:	0f 45 c2             	cmovne eax,edx
   2c6b3:	e9 a5 a3 ff ff       	jmp    26a5d <JS_CallInternal+0x3ebd>
   2c6b8:	41 83 fe 08          	cmp    r14d,0x8
   2c6bc:	0f 85 b7 06 00 00    	jne    2cd79 <JS_CallInternal+0xa1d9>
   2c6c2:	66 48 0f 6e c2       	movq   xmm0,rdx
   2c6c7:	66 49 0f 6e fd       	movq   xmm7,r13
   2c6cc:	31 c0                	xor    eax,eax
   2c6ce:	ba 00 00 00 00       	mov    edx,0x0
   2c6d3:	66 0f 2e c7          	ucomisd xmm0,xmm7
   2c6d7:	0f 9b c0             	setnp  al
   2c6da:	48 0f 45 c2          	cmovne rax,rdx
   2c6de:	e9 67 b1 ff ff       	jmp    2784a <JS_CallInternal+0x4caa>
   2c6e3:	48 8b 8d e8 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x118]
   2c6ea:	89 c2                	mov    edx,eax
   2c6ec:	48 8d 75 80          	lea    rsi,[rbp-0x80]
   2c6f0:	48 8b 79 10          	mov    rdi,QWORD PTR [rcx+0x10]
   2c6f4:	e8 77 ac fe ff       	call   17370 <JS_AtomGetStrRT.constprop.0>
   2c6f9:	48 89 c2             	mov    rdx,rax
   2c6fc:	e9 07 ee ff ff       	jmp    2b508 <JS_CallInternal+0x8968>
   2c701:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2c708:	48 89 ce             	mov    rsi,rcx
   2c70b:	48 89 da             	mov    rdx,rbx
   2c70e:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2c712:	e8 59 02 ff ff       	call   1c970 <__JS_FreeValueRT>
   2c717:	e9 ee da ff ff       	jmp    2a20a <JS_CallInternal+0x766a>
   2c71c:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2c723:	48 8b 95 38 fe ff ff 	mov    rdx,QWORD PTR [rbp-0x1c8]
   2c72a:	48 89 de             	mov    rsi,rbx
   2c72d:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2c731:	e8 3a 02 ff ff       	call   1c970 <__JS_FreeValueRT>
   2c736:	e9 f6 da ff ff       	jmp    2a231 <JS_CallInternal+0x7691>
   2c73b:	4d 89 ec             	mov    r12,r13
   2c73e:	e9 fd 6b ff ff       	jmp    23340 <JS_CallInternal+0x7a0>
   2c743:	66 48 0f 6e c9       	movq   xmm1,rcx
   2c748:	83 f8 08             	cmp    eax,0x8
   2c74b:	0f 84 4b ec ff ff    	je     2b39c <JS_CallInternal+0x87fc>
   2c751:	85 c0                	test   eax,eax
   2c753:	0f 85 3e 75 ff ff    	jne    23c97 <JS_CallInternal+0x10f7>
   2c759:	66 0f ef c0          	pxor   xmm0,xmm0
   2c75d:	f2 0f 2a c2          	cvtsi2sd xmm0,edx
   2c761:	e9 3b ec ff ff       	jmp    2b3a1 <JS_CallInternal+0x8801>
   2c766:	66 48 0f 6e c7       	movq   xmm0,rdi
   2c76b:	83 f8 08             	cmp    eax,0x8
   2c76e:	0f 84 6d ec ff ff    	je     2b3e1 <JS_CallInternal+0x8841>
   2c774:	85 c0                	test   eax,eax
   2c776:	0f 85 1b 75 ff ff    	jne    23c97 <JS_CallInternal+0x10f7>
   2c77c:	66 0f ef c9          	pxor   xmm1,xmm1
   2c780:	f2 0f 2a c9          	cvtsi2sd xmm1,ecx
   2c784:	e9 5d ec ff ff       	jmp    2b3e6 <JS_CallInternal+0x8846>
   2c789:	66 49 0f 6e ca       	movq   xmm1,r10
   2c78e:	83 ff 08             	cmp    edi,0x8
   2c791:	0f 84 2a f8 ff ff    	je     2bfc1 <JS_CallInternal+0x9421>
   2c797:	85 ff                	test   edi,edi
   2c799:	0f 85 82 f1 ff ff    	jne    2b921 <JS_CallInternal+0x8d81>
   2c79f:	66 0f ef c0          	pxor   xmm0,xmm0
   2c7a3:	f2 41 0f 2a c0       	cvtsi2sd xmm0,r8d
   2c7a8:	e9 19 f8 ff ff       	jmp    2bfc6 <JS_CallInternal+0x9426>
   2c7ad:	31 c0                	xor    eax,eax
   2c7af:	48 c7 43 08 03 00 00 	mov    QWORD PTR [rbx+0x8],0x3
   2c7b6:	00 
   2c7b7:	48 89 03             	mov    QWORD PTR [rbx],rax
   2c7ba:	e9 f0 8c ff ff       	jmp    254af <JS_CallInternal+0x290f>
   2c7bf:	48 89 03             	mov    QWORD PTR [rbx],rax
   2c7c2:	48 89 53 08          	mov    QWORD PTR [rbx+0x8],rdx
   2c7c6:	e9 65 8d ff ff       	jmp    25530 <JS_CallInternal+0x2990>
   2c7cb:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2c7d2:	48 8d 35 e0 0d 0a 00 	lea    rsi,[rip+0xa0de0]        # cd5b9 <_IO_stdin_used+0x5b9>
   2c7d9:	31 c0                	xor    eax,eax
   2c7db:	e8 a0 48 00 00       	call   31080 <JS_ThrowTypeError>
   2c7e0:	e9 5b 6b ff ff       	jmp    23340 <JS_CallInternal+0x7a0>
   2c7e5:	66 48 0f 6e ca       	movq   xmm1,rdx
   2c7ea:	83 f9 08             	cmp    ecx,0x8
   2c7ed:	74 77                	je     2c866 <JS_CallInternal+0x9cc6>
   2c7ef:	85 c9                	test   ecx,ecx
   2c7f1:	0f 85 7d f3 ff ff    	jne    2bb74 <JS_CallInternal+0x8fd4>
   2c7f7:	66 0f ef c0          	pxor   xmm0,xmm0
   2c7fb:	f2 0f 2a c0          	cvtsi2sd xmm0,eax
   2c7ff:	31 c0                	xor    eax,eax
   2c801:	66 0f 2f c8          	comisd xmm1,xmm0
   2c805:	48 c7 43 e8 01 00 00 	mov    QWORD PTR [rbx-0x18],0x1
   2c80c:	00 
   2c80d:	0f 93 c0             	setae  al
   2c810:	48 83 eb 10          	sub    rbx,0x10
   2c814:	48 89 43 f0          	mov    QWORD PTR [rbx-0x10],rax
   2c818:	e9 fb a2 ff ff       	jmp    26b18 <JS_CallInternal+0x3f78>
   2c81d:	48 8b 85 c0 fe ff ff 	mov    rax,QWORD PTR [rbp-0x140]
   2c824:	48 8b 8d d8 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x128]
   2c82b:	31 d2                	xor    edx,edx
   2c82d:	f3 0f 6f a0 d8 04 00 	movdqu xmm4,XMMWORD PTR [rax+0x4d8]
   2c834:	00 
   2c835:	0f 11 63 f0          	movups XMMWORD PTR [rbx-0x10],xmm4
   2c839:	0f 29 a5 50 fe ff ff 	movaps XMMWORD PTR [rbp-0x1b0],xmm4
   2c840:	48 89 90 d8 04 00 00 	mov    QWORD PTR [rax+0x4d8],rdx
   2c847:	48 c7 80 e0 04 00 00 	mov    QWORD PTR [rax+0x4e0],0x4
   2c84e:	04 00 00 00 
   2c852:	49 63 c5             	movsxd rax,r13d
   2c855:	48 03 41 18          	add    rax,QWORD PTR [rcx+0x18]
   2c859:	e9 03 66 ff ff       	jmp    22e61 <JS_CallInternal+0x2c1>
   2c85e:	66 0f ef c9          	pxor   xmm1,xmm1
   2c862:	f2 0f 2a ca          	cvtsi2sd xmm1,edx
   2c866:	66 48 0f 6e c0       	movq   xmm0,rax
   2c86b:	eb 92                	jmp    2c7ff <JS_CallInternal+0x9c5f>
   2c86d:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2c874:	48 8b 95 50 fe ff ff 	mov    rdx,QWORD PTR [rbp-0x1b0]
   2c87b:	4c 89 ee             	mov    rsi,r13
   2c87e:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2c882:	e8 e9 00 ff ff       	call   1c970 <__JS_FreeValueRT>
   2c887:	e9 ec a3 ff ff       	jmp    26c78 <JS_CallInternal+0x40d8>
   2c88c:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2c893:	48 8d 35 86 45 0a 00 	lea    rsi,[rip+0xa4586]        # d0e20 <_IO_stdin_used+0x3e20>
   2c89a:	31 c0                	xor    eax,eax
   2c89c:	e8 df 47 00 00       	call   31080 <JS_ThrowTypeError>
   2c8a1:	e9 9a 6a ff ff       	jmp    23340 <JS_CallInternal+0x7a0>
   2c8a6:	4d 89 ec             	mov    r12,r13
   2c8a9:	e9 92 6a ff ff       	jmp    23340 <JS_CallInternal+0x7a0>
   2c8ae:	41 8d 50 fe          	lea    edx,[r8-0x2]
   2c8b2:	83 fa 01             	cmp    edx,0x1
   2c8b5:	0f 86 e9 07 00 00    	jbe    2d0a4 <JS_CallInternal+0xa504>
   2c8bb:	83 c0 01             	add    eax,0x1
   2c8be:	0f 85 2c da ff ff    	jne    2a2f0 <JS_CallInternal+0x7750>
   2c8c4:	4d 39 ce             	cmp    r14,r9
   2c8c7:	4c 89 f6             	mov    rsi,r14
   2c8ca:	4c 8b b5 e8 fe ff ff 	mov    r14,QWORD PTR [rbp-0x118]
   2c8d1:	4c 89 ea             	mov    rdx,r13
   2c8d4:	0f 94 c0             	sete   al
   2c8d7:	4c 89 85 38 fe ff ff 	mov    QWORD PTR [rbp-0x1c8],r8
   2c8de:	4c 89 f7             	mov    rdi,r14
   2c8e1:	88 85 50 fe ff ff    	mov    BYTE PTR [rbp-0x1b0],al
   2c8e7:	4c 89 8d 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],r9
   2c8ee:	e8 dd 01 ff ff       	call   1cad0 <JS_FreeValue>
   2c8f3:	48 8b b5 40 fe ff ff 	mov    rsi,QWORD PTR [rbp-0x1c0]
   2c8fa:	48 8b 95 38 fe ff ff 	mov    rdx,QWORD PTR [rbp-0x1c8]
   2c901:	4c 89 f7             	mov    rdi,r14
   2c904:	e8 c7 01 ff ff       	call   1cad0 <JS_FreeValue>
   2c909:	0f b6 85 50 fe ff ff 	movzx  eax,BYTE PTR [rbp-0x1b0]
   2c910:	e9 a8 a1 ff ff       	jmp    26abd <JS_CallInternal+0x3f1d>
   2c915:	45 85 c0             	test   r8d,r8d
   2c918:	0f 85 90 00 00 00    	jne    2c9ae <JS_CallInternal+0x9e0e>
   2c91e:	66 0f ef c0          	pxor   xmm0,xmm0
   2c922:	66 49 0f 6e fe       	movq   xmm7,r14
   2c927:	ba 00 00 00 00       	mov    edx,0x0
   2c92c:	f2 41 0f 2a c1       	cvtsi2sd xmm0,r9d
   2c931:	66 0f 2e c7          	ucomisd xmm0,xmm7
   2c935:	0f 9b c0             	setnp  al
   2c938:	0f 45 c2             	cmovne eax,edx
   2c93b:	e9 7d a1 ff ff       	jmp    26abd <JS_CallInternal+0x3f1d>
   2c940:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2c947:	4c 89 c6             	mov    rsi,r8
   2c94a:	4c 89 e2             	mov    rdx,r12
   2c94d:	89 8d 40 fe ff ff    	mov    DWORD PTR [rbp-0x1c0],ecx
   2c953:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2c957:	e8 14 00 ff ff       	call   1c970 <__JS_FreeValueRT>
   2c95c:	8b 8d 40 fe ff ff    	mov    ecx,DWORD PTR [rbp-0x1c0]
   2c962:	e9 ce c6 ff ff       	jmp    29035 <JS_CallInternal+0x6495>
   2c967:	66 48 0f 6e c0       	movq   xmm0,rax
   2c96c:	83 f9 08             	cmp    ecx,0x8
   2c96f:	74 36                	je     2c9a7 <JS_CallInternal+0x9e07>
   2c971:	85 c9                	test   ecx,ecx
   2c973:	0f 85 fb e8 ff ff    	jne    2b274 <JS_CallInternal+0x86d4>
   2c979:	66 0f ef c9          	pxor   xmm1,xmm1
   2c97d:	f2 0f 2a ca          	cvtsi2sd xmm1,edx
   2c981:	31 c0                	xor    eax,eax
   2c983:	66 0f 2f c8          	comisd xmm1,xmm0
   2c987:	48 c7 43 e8 01 00 00 	mov    QWORD PTR [rbx-0x18],0x1
   2c98e:	00 
   2c98f:	0f 93 c0             	setae  al
   2c992:	48 83 eb 10          	sub    rbx,0x10
   2c996:	48 89 43 f0          	mov    QWORD PTR [rbx-0x10],rax
   2c99a:	e9 09 a2 ff ff       	jmp    26ba8 <JS_CallInternal+0x4008>
   2c99f:	66 0f ef c0          	pxor   xmm0,xmm0
   2c9a3:	f2 0f 2a c0          	cvtsi2sd xmm0,eax
   2c9a7:	66 48 0f 6e ca       	movq   xmm1,rdx
   2c9ac:	eb d3                	jmp    2c981 <JS_CallInternal+0x9de1>
   2c9ae:	41 83 f8 08          	cmp    r8d,0x8
   2c9b2:	0f 85 38 d9 ff ff    	jne    2a2f0 <JS_CallInternal+0x7750>
   2c9b8:	66 49 0f 6e c6       	movq   xmm0,r14
   2c9bd:	66 49 0f 6e c9       	movq   xmm1,r9
   2c9c2:	ba 00 00 00 00       	mov    edx,0x0
   2c9c7:	66 0f 2e c1          	ucomisd xmm0,xmm1
   2c9cb:	0f 9b c0             	setnp  al
   2c9ce:	0f 45 c2             	cmovne eax,edx
   2c9d1:	e9 e7 a0 ff ff       	jmp    26abd <JS_CallInternal+0x3f1d>
   2c9d6:	4d 89 ec             	mov    r12,r13
   2c9d9:	e9 62 69 ff ff       	jmp    23340 <JS_CallInternal+0x7a0>
   2c9de:	48 8b 9d 50 fe ff ff 	mov    rbx,QWORD PTR [rbp-0x1b0]
   2c9e5:	e9 56 69 ff ff       	jmp    23340 <JS_CallInternal+0x7a0>
   2c9ea:	48 8b 87 48 04 00 00 	mov    rax,QWORD PTR [rdi+0x448]
   2c9f1:	4a 8b 34 e8          	mov    rsi,QWORD PTR [rax+r13*8]
   2c9f5:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   2c9f8:	83 e8 01             	sub    eax,0x1
   2c9fb:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   2c9fe:	85 c0                	test   eax,eax
   2ca00:	0f 8f 58 f6 ff ff    	jg     2c05e <JS_CallInternal+0x94be>
   2ca06:	e8 35 8a fe ff       	call   15440 <JS_FreeAtomStruct>
   2ca0b:	e9 4e f6 ff ff       	jmp    2c05e <JS_CallInternal+0x94be>
   2ca10:	48 8b bd a0 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x160]
   2ca17:	48 8d 35 1a 43 0a 00 	lea    rsi,[rip+0xa431a]        # d0d38 <_IO_stdin_used+0x3d38>
   2ca1e:	31 c0                	xor    eax,eax
   2ca20:	e8 5b 46 00 00       	call   31080 <JS_ThrowTypeError>
   2ca25:	e9 16 69 ff ff       	jmp    23340 <JS_CallInternal+0x7a0>
   2ca2a:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2ca31:	48 8d 35 a8 0a 0a 00 	lea    rsi,[rip+0xa0aa8]        # cd4e0 <_IO_stdin_used+0x4e0>
   2ca38:	31 c0                	xor    eax,eax
   2ca3a:	e8 41 46 00 00       	call   31080 <JS_ThrowTypeError>
   2ca3f:	e9 fc 68 ff ff       	jmp    23340 <JS_CallInternal+0x7a0>
   2ca44:	48 8b 8d e8 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x118]
   2ca4b:	89 c2                	mov    edx,eax
   2ca4d:	48 8d 75 80          	lea    rsi,[rbp-0x80]
   2ca51:	48 8b 79 10          	mov    rdi,QWORD PTR [rcx+0x10]
   2ca55:	e8 16 a9 fe ff       	call   17370 <JS_AtomGetStrRT.constprop.0>
   2ca5a:	48 89 c2             	mov    rdx,rax
   2ca5d:	e9 64 e4 ff ff       	jmp    2aec6 <JS_CallInternal+0x8326>
   2ca62:	48 8b 8d e8 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x118]
   2ca69:	89 c2                	mov    edx,eax
   2ca6b:	48 8d 75 80          	lea    rsi,[rbp-0x80]
   2ca6f:	48 8b 79 10          	mov    rdi,QWORD PTR [rcx+0x10]
   2ca73:	e8 f8 a8 fe ff       	call   17370 <JS_AtomGetStrRT.constprop.0>
   2ca78:	48 89 c2             	mov    rdx,rax
   2ca7b:	e9 81 e4 ff ff       	jmp    2af01 <JS_CallInternal+0x8361>
   2ca80:	66 48 0f 6e ca       	movq   xmm1,rdx
   2ca85:	83 f9 08             	cmp    ecx,0x8
   2ca88:	74 36                	je     2cac0 <JS_CallInternal+0x9f20>
   2ca8a:	85 c9                	test   ecx,ecx
   2ca8c:	0f 85 19 e5 ff ff    	jne    2afab <JS_CallInternal+0x840b>
   2ca92:	66 0f ef c0          	pxor   xmm0,xmm0
   2ca96:	f2 0f 2a c0          	cvtsi2sd xmm0,eax
   2ca9a:	31 c0                	xor    eax,eax
   2ca9c:	66 0f 2f c8          	comisd xmm1,xmm0
   2caa0:	48 c7 43 e8 01 00 00 	mov    QWORD PTR [rbx-0x18],0x1
   2caa7:	00 
   2caa8:	0f 97 c0             	seta   al
   2caab:	48 83 eb 10          	sub    rbx,0x10
   2caaf:	48 89 43 f0          	mov    QWORD PTR [rbx-0x10],rax
   2cab3:	e9 a8 a0 ff ff       	jmp    26b60 <JS_CallInternal+0x3fc0>
   2cab8:	66 0f ef c9          	pxor   xmm1,xmm1
   2cabc:	f2 0f 2a ca          	cvtsi2sd xmm1,edx
   2cac0:	66 48 0f 6e c0       	movq   xmm0,rax
   2cac5:	eb d3                	jmp    2ca9a <JS_CallInternal+0x9efa>
   2cac7:	66 48 0f 6e c0       	movq   xmm0,rax
   2cacc:	83 f9 08             	cmp    ecx,0x8
   2cacf:	74 36                	je     2cb07 <JS_CallInternal+0x9f67>
   2cad1:	85 c9                	test   ecx,ecx
   2cad3:	0f 85 62 ea ff ff    	jne    2b53b <JS_CallInternal+0x899b>
   2cad9:	66 0f ef c9          	pxor   xmm1,xmm1
   2cadd:	f2 0f 2a ca          	cvtsi2sd xmm1,edx
   2cae1:	31 c0                	xor    eax,eax
   2cae3:	66 0f 2f c8          	comisd xmm1,xmm0
   2cae7:	48 c7 43 e8 01 00 00 	mov    QWORD PTR [rbx-0x18],0x1
   2caee:	00 
   2caef:	0f 97 c0             	seta   al
   2caf2:	48 83 eb 10          	sub    rbx,0x10
   2caf6:	48 89 43 f0          	mov    QWORD PTR [rbx-0x10],rax
   2cafa:	e9 a4 ad ff ff       	jmp    278a3 <JS_CallInternal+0x4d03>
   2caff:	66 0f ef c0          	pxor   xmm0,xmm0
   2cb03:	f2 0f 2a c0          	cvtsi2sd xmm0,eax
   2cb07:	66 48 0f 6e ca       	movq   xmm1,rdx
   2cb0c:	eb d3                	jmp    2cae1 <JS_CallInternal+0x9f41>
   2cb0e:	41 8d 50 fe          	lea    edx,[r8-0x2]
   2cb12:	83 fa 01             	cmp    edx,0x1
   2cb15:	0f 86 e1 02 00 00    	jbe    2cdfc <JS_CallInternal+0xa25c>
   2cb1b:	83 c0 01             	add    eax,0x1
   2cb1e:	0f 85 cc d7 ff ff    	jne    2a2f0 <JS_CallInternal+0x7750>
   2cb24:	41 0f b6 41 11       	movzx  eax,BYTE PTR [r9+0x11]
   2cb29:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2cb30:	4c 89 c2             	mov    rdx,r8
   2cb33:	83 e0 01             	and    eax,0x1
   2cb36:	88 85 50 fe ff ff    	mov    BYTE PTR [rbp-0x1b0],al
   2cb3c:	e8 8f ff fe ff       	call   1cad0 <JS_FreeValue>
   2cb41:	0f b6 85 50 fe ff ff 	movzx  eax,BYTE PTR [rbp-0x1b0]
   2cb48:	e9 70 9f ff ff       	jmp    26abd <JS_CallInternal+0x3f1d>
   2cb4d:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2cb54:	48 8d 35 0f 0a 0a 00 	lea    rsi,[rip+0xa0a0f]        # cd56a <_IO_stdin_used+0x56a>
   2cb5b:	31 c0                	xor    eax,eax
   2cb5d:	e8 1e 45 00 00       	call   31080 <JS_ThrowTypeError>
   2cb62:	e9 d9 67 ff ff       	jmp    23340 <JS_CallInternal+0x7a0>
   2cb67:	48 89 d7             	mov    rdi,rdx
   2cb6a:	4c 89 ce             	mov    rsi,r9
   2cb6d:	45 31 c0             	xor    r8d,r8d
   2cb70:	4c 89 ea             	mov    rdx,r13
   2cb73:	4c 89 f1             	mov    rcx,r14
   2cb76:	4c 89 8d 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],r9
   2cb7d:	48 89 bd 38 fe ff ff 	mov    QWORD PTR [rbp-0x1c8],rdi
   2cb84:	e8 a7 d9 fe ff       	call   1a530 <js_strict_eq2.isra.0>
   2cb89:	48 8b b5 38 fe ff ff 	mov    rsi,QWORD PTR [rbp-0x1c8]
   2cb90:	4c 8b 8d 40 fe ff ff 	mov    r9,QWORD PTR [rbp-0x1c0]
   2cb97:	89 85 50 fe ff ff    	mov    DWORD PTR [rbp-0x1b0],eax
   2cb9d:	e9 04 e5 ff ff       	jmp    2b0a6 <JS_CallInternal+0x8506>
   2cba2:	31 c0                	xor    eax,eax
   2cba4:	41 83 fe ff          	cmp    r14d,0xffffffff
   2cba8:	75 08                	jne    2cbb2 <JS_CallInternal+0xa012>
   2cbaa:	31 c0                	xor    eax,eax
   2cbac:	4c 39 ea             	cmp    rdx,r13
   2cbaf:	0f 94 c0             	sete   al
   2cbb2:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2cbb9:	48 89 d6             	mov    rsi,rdx
   2cbbc:	4c 89 ca             	mov    rdx,r9
   2cbbf:	89 85 50 fe ff ff    	mov    DWORD PTR [rbp-0x1b0],eax
   2cbc5:	e8 06 ff fe ff       	call   1cad0 <JS_FreeValue>
   2cbca:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2cbd1:	4c 89 ee             	mov    rsi,r13
   2cbd4:	4c 89 f2             	mov    rdx,r14
   2cbd7:	e8 f4 fe fe ff       	call   1cad0 <JS_FreeValue>
   2cbdc:	8b 85 50 fe ff ff    	mov    eax,DWORD PTR [rbp-0x1b0]
   2cbe2:	83 f0 01             	xor    eax,0x1
   2cbe5:	48 98                	cdqe
   2cbe7:	e9 0a ac ff ff       	jmp    277f6 <JS_CallInternal+0x4c56>
   2cbec:	45 85 f6             	test   r14d,r14d
   2cbef:	0f 85 90 00 00 00    	jne    2cc85 <JS_CallInternal+0xa0e5>
   2cbf5:	66 0f ef c0          	pxor   xmm0,xmm0
   2cbf9:	66 48 0f 6e d2       	movq   xmm2,rdx
   2cbfe:	31 c0                	xor    eax,eax
   2cc00:	ba 01 00 00 00       	mov    edx,0x1
   2cc05:	f2 41 0f 2a c5       	cvtsi2sd xmm0,r13d
   2cc0a:	66 0f 2e c2          	ucomisd xmm0,xmm2
   2cc0e:	0f 9a c0             	setp   al
   2cc11:	48 0f 45 c2          	cmovne rax,rdx
   2cc15:	e9 dc ab ff ff       	jmp    277f6 <JS_CallInternal+0x4c56>
   2cc1a:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2cc21:	48 8b 95 50 fe ff ff 	mov    rdx,QWORD PTR [rbp-0x1b0]
   2cc28:	4c 89 ee             	mov    rsi,r13
   2cc2b:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2cc2f:	e8 3c fd fe ff       	call   1c970 <__JS_FreeValueRT>
   2cc34:	e9 48 eb ff ff       	jmp    2b781 <JS_CallInternal+0x8be1>
   2cc39:	48 8b b5 78 fe ff ff 	mov    rsi,QWORD PTR [rbp-0x188]
   2cc40:	48 8b 95 88 fe ff ff 	mov    rdx,QWORD PTR [rbp-0x178]
   2cc47:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2cc4e:	e8 ed bc 01 00       	call   48940 <JS_ToObject>
   2cc53:	48 89 c1             	mov    rcx,rax
   2cc56:	48 89 d0             	mov    rax,rdx
   2cc59:	83 fa 06             	cmp    edx,0x6
   2cc5c:	0f 85 30 8b ff ff    	jne    25792 <JS_CallInternal+0x2bf2>
   2cc62:	e9 d9 66 ff ff       	jmp    23340 <JS_CallInternal+0x7a0>
   2cc67:	41 83 fe 08          	cmp    r14d,0x8
   2cc6b:	0f 84 46 01 00 00    	je     2cdb7 <JS_CallInternal+0xa217>
   2cc71:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   2cc78:	4c 89 48 30          	mov    QWORD PTR [rax+0x30],r9
   2cc7c:	49 8b 45 00          	mov    rax,QWORD PTR [r13+0x0]
   2cc80:	e9 bf e7 ff ff       	jmp    2b444 <JS_CallInternal+0x88a4>
   2cc85:	41 83 fe 08          	cmp    r14d,0x8
   2cc89:	0f 85 46 01 00 00    	jne    2cdd5 <JS_CallInternal+0xa235>
   2cc8f:	66 48 0f 6e c2       	movq   xmm0,rdx
   2cc94:	66 49 0f 6e dd       	movq   xmm3,r13
   2cc99:	31 c0                	xor    eax,eax
   2cc9b:	ba 01 00 00 00       	mov    edx,0x1
   2cca0:	66 0f 2e c3          	ucomisd xmm0,xmm3
   2cca4:	0f 9a c0             	setp   al
   2cca7:	48 0f 45 c2          	cmovne rax,rdx
   2ccab:	e9 46 ab ff ff       	jmp    277f6 <JS_CallInternal+0x4c56>
   2ccb0:	83 c1 07             	add    ecx,0x7
   2ccb3:	83 f9 01             	cmp    ecx,0x1
   2ccb6:	0f 87 65 ec ff ff    	ja     2b921 <JS_CallInternal+0x8d81>
   2ccbc:	4c 89 c1             	mov    rcx,r8
   2ccbf:	49 89 f8             	mov    r8,rdi
   2ccc2:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2ccc9:	4c 89 d6             	mov    rsi,r10
   2cccc:	4c 89 da             	mov    rdx,r11
   2cccf:	e8 0c 3f 01 00       	call   40be0 <JS_ConcatString>
   2ccd4:	48 89 43 e0          	mov    QWORD PTR [rbx-0x20],rax
   2ccd8:	48 8d 43 f0          	lea    rax,[rbx-0x10]
   2ccdc:	48 89 53 e8          	mov    QWORD PTR [rbx-0x18],rdx
   2cce0:	83 7b e8 06          	cmp    DWORD PTR [rbx-0x18],0x6
   2cce4:	48 89 c3             	mov    rbx,rax
   2cce7:	0f 85 c6 a4 ff ff    	jne    271b3 <JS_CallInternal+0x4613>
   2cced:	e9 4e 66 ff ff       	jmp    23340 <JS_CallInternal+0x7a0>
   2ccf2:	48 89 85 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],rax
   2ccf9:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2cd00:	4c 89 85 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],r8
   2cd07:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2cd0b:	e8 60 fc fe ff       	call   1c970 <__JS_FreeValueRT>
   2cd10:	4c 8b 85 40 fe ff ff 	mov    r8,QWORD PTR [rbp-0x1c0]
   2cd17:	48 8b 85 50 fe ff ff 	mov    rax,QWORD PTR [rbp-0x1b0]
   2cd1e:	e9 c3 d2 ff ff       	jmp    29fe6 <JS_CallInternal+0x7446>
   2cd23:	49 83 7e 08 00       	cmp    QWORD PTR [r14+0x8],0x0
   2cd28:	0f 84 37 f7 ff ff    	je     2c465 <JS_CallInternal+0x98c5>
   2cd2e:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2cd35:	41 83 45 fc 01       	add    DWORD PTR [r13-0x4],0x1
   2cd3a:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2cd3e:	48 89 8d 38 fe ff ff 	mov    QWORD PTR [rbp-0x1c8],rcx
   2cd45:	e8 36 16 ff ff       	call   1e380 <js_free_shape>
   2cd4a:	48 8b 8d 38 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x1c8]
   2cd51:	e9 62 f7 ff ff       	jmp    2c4b8 <JS_CallInternal+0x9918>
   2cd56:	48 8b 8d e8 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x118]
   2cd5d:	48 8b 79 10          	mov    rdi,QWORD PTR [rcx+0x10]
   2cd61:	48 89 85 28 fe ff ff 	mov    QWORD PTR [rbp-0x1d8],rax
   2cd68:	e8 13 16 ff ff       	call   1e380 <js_free_shape>
   2cd6d:	48 8b 85 28 fe ff ff 	mov    rax,QWORD PTR [rbp-0x1d8]
   2cd74:	e9 05 f6 ff ff       	jmp    2c37e <JS_CallInternal+0x97de>
   2cd79:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2cd80:	4c 89 ee             	mov    rsi,r13
   2cd83:	4c 89 f2             	mov    rdx,r14
   2cd86:	e8 45 fd fe ff       	call   1cad0 <JS_FreeValue>
   2cd8b:	31 c0                	xor    eax,eax
   2cd8d:	e9 b8 aa ff ff       	jmp    2784a <JS_CallInternal+0x4caa>
   2cd92:	41 81 fd f2 00 00 00 	cmp    r13d,0xf2
   2cd99:	0f 8e a1 65 ff ff    	jle    23340 <JS_CallInternal+0x7a0>
   2cd9f:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2cda6:	44 89 ee             	mov    esi,r13d
   2cda9:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2cdad:	e8 1e c7 fe ff       	call   194d0 <JS_FreeAtom.part.0.isra.0>
   2cdb2:	e9 89 65 ff ff       	jmp    23340 <JS_CallInternal+0x7a0>
   2cdb7:	66 49 0f 6e c0       	movq   xmm0,r8
   2cdbc:	f2 41 0f 58 45 00    	addsd  xmm0,QWORD PTR [r13+0x0]
   2cdc2:	49 c7 45 08 08 00 00 	mov    QWORD PTR [r13+0x8],0x8
   2cdc9:	00 
   2cdca:	f2 41 0f 11 45 00    	movsd  QWORD PTR [r13+0x0],xmm0
   2cdd0:	e9 7a a3 ff ff       	jmp    2714f <JS_CallInternal+0x45af>
   2cdd5:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2cddc:	4c 89 ee             	mov    rsi,r13
   2cddf:	4c 89 f2             	mov    rdx,r14
   2cde2:	e8 e9 fc fe ff       	call   1cad0 <JS_FreeValue>
   2cde7:	e9 a7 d5 ff ff       	jmp    2a393 <JS_CallInternal+0x77f3>
   2cdec:	4c 89 d0             	mov    rax,r10
   2cdef:	e9 14 d3 ff ff       	jmp    2a108 <JS_CallInternal+0x7568>
   2cdf4:	4d 89 f4             	mov    r12,r14
   2cdf7:	e9 44 65 ff ff       	jmp    23340 <JS_CallInternal+0x7a0>
   2cdfc:	b8 01 00 00 00       	mov    eax,0x1
   2ce01:	e9 b7 9c ff ff       	jmp    26abd <JS_CallInternal+0x3f1d>
   2ce06:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2ce0d:	4c 89 ee             	mov    rsi,r13
   2ce10:	4c 89 f2             	mov    rdx,r14
   2ce13:	4c 89 8d 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],r9
   2ce1a:	e8 b1 fc fe ff       	call   1cad0 <JS_FreeValue>
   2ce1f:	48 8b 8d 50 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x1b0]
   2ce26:	31 c0                	xor    eax,eax
   2ce28:	44 39 f1             	cmp    ecx,r14d
   2ce2b:	0f 95 c0             	setne  al
   2ce2e:	e9 c3 a9 ff ff       	jmp    277f6 <JS_CallInternal+0x4c56>
   2ce33:	49 8b 75 00          	mov    rsi,QWORD PTR [r13+0x0]
   2ce37:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2ce3e:	4c 89 c2             	mov    rdx,r8
   2ce41:	4c 89 f1             	mov    rcx,r14
   2ce44:	4c 89 8d 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],r9
   2ce4b:	4c 89 85 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],r8
   2ce52:	e8 19 80 fe ff       	call   14e70 <JS_ConcatStringInPlace>
   2ce57:	4c 8b 85 50 fe ff ff 	mov    r8,QWORD PTR [rbp-0x1b0]
   2ce5e:	4c 8b 8d 40 fe ff ff 	mov    r9,QWORD PTR [rbp-0x1c0]
   2ce65:	85 c0                	test   eax,eax
   2ce67:	75 60                	jne    2cec9 <JS_CallInternal+0xa329>
   2ce69:	49 8b 55 08          	mov    rdx,QWORD PTR [r13+0x8]
   2ce6d:	49 8b 75 00          	mov    rsi,QWORD PTR [r13+0x0]
   2ce71:	83 fa f6             	cmp    edx,0xfffffff6
   2ce74:	76 04                	jbe    2ce7a <JS_CallInternal+0xa2da>
   2ce76:	83 46 fc 01          	add    DWORD PTR [rsi-0x4],0x1
   2ce7a:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2ce81:	4c 89 c1             	mov    rcx,r8
   2ce84:	4d 89 f0             	mov    r8,r14
   2ce87:	4c 89 8d 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],r9
   2ce8e:	e8 4d 3d 01 00       	call   40be0 <JS_ConcatString>
   2ce93:	4c 8b 8d 50 fe ff ff 	mov    r9,QWORD PTR [rbp-0x1b0]
   2ce9a:	83 fa 06             	cmp    edx,0x6
   2ce9d:	49 89 c0             	mov    r8,rax
   2cea0:	49 89 d6             	mov    r14,rdx
   2cea3:	74 43                	je     2cee8 <JS_CallInternal+0xa348>
   2cea5:	49 8b 45 00          	mov    rax,QWORD PTR [r13+0x0]
   2cea9:	49 8b 55 08          	mov    rdx,QWORD PTR [r13+0x8]
   2cead:	4d 89 45 00          	mov    QWORD PTR [r13+0x0],r8
   2ceb1:	4d 89 75 08          	mov    QWORD PTR [r13+0x8],r14
   2ceb5:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2cebc:	48 89 c6             	mov    rsi,rax
   2cebf:	e8 0c fc fe ff       	call   1cad0 <JS_FreeValue>
   2cec4:	e9 86 a2 ff ff       	jmp    2714f <JS_CallInternal+0x45af>
   2cec9:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2ced0:	4c 89 c6             	mov    rsi,r8
   2ced3:	4c 89 f2             	mov    rdx,r14
   2ced6:	e8 f5 fb fe ff       	call   1cad0 <JS_FreeValue>
   2cedb:	e9 6f a2 ff ff       	jmp    2714f <JS_CallInternal+0x45af>
   2cee0:	4d 89 f4             	mov    r12,r14
   2cee3:	e9 58 64 ff ff       	jmp    23340 <JS_CallInternal+0x7a0>
   2cee8:	4d 89 cc             	mov    r12,r9
   2ceeb:	e9 50 64 ff ff       	jmp    23340 <JS_CallInternal+0x7a0>
   2cef0:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2cef7:	45 39 f0             	cmp    r8d,r14d
   2cefa:	4c 89 ee             	mov    rsi,r13
   2cefd:	4c 89 f2             	mov    rdx,r14
   2cf00:	0f 94 85 50 fe ff ff 	sete   BYTE PTR [rbp-0x1b0]
   2cf07:	e8 c4 fb fe ff       	call   1cad0 <JS_FreeValue>
   2cf0c:	0f b6 85 50 fe ff ff 	movzx  eax,BYTE PTR [rbp-0x1b0]
   2cf13:	e9 32 a9 ff ff       	jmp    2784a <JS_CallInternal+0x4caa>
   2cf18:	41 0f b6 46 11       	movzx  eax,BYTE PTR [r14+0x11]
   2cf1d:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2cf24:	4c 89 f6             	mov    rsi,r14
   2cf27:	4c 89 ea             	mov    rdx,r13
   2cf2a:	83 e0 01             	and    eax,0x1
   2cf2d:	89 85 50 fe ff ff    	mov    DWORD PTR [rbp-0x1b0],eax
   2cf33:	e8 98 fb fe ff       	call   1cad0 <JS_FreeValue>
   2cf38:	8b 85 50 fe ff ff    	mov    eax,DWORD PTR [rbp-0x1b0]
   2cf3e:	e9 1a 9b ff ff       	jmp    26a5d <JS_CallInternal+0x3ebd>
   2cf43:	41 81 fd f2 00 00 00 	cmp    r13d,0xf2
   2cf4a:	0f 8e f0 63 ff ff    	jle    23340 <JS_CallInternal+0x7a0>
   2cf50:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2cf57:	44 89 ee             	mov    esi,r13d
   2cf5a:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2cf5e:	e8 6d c5 fe ff       	call   194d0 <JS_FreeAtom.part.0.isra.0>
   2cf63:	e9 d8 63 ff ff       	jmp    23340 <JS_CallInternal+0x7a0>
   2cf68:	3d f2 00 00 00       	cmp    eax,0xf2
   2cf6d:	0f 8e 11 ee ff ff    	jle    2bd84 <JS_CallInternal+0x91e4>
   2cf73:	48 8b 8d e8 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x118]
   2cf7a:	89 c0                	mov    eax,eax
   2cf7c:	48 8b 79 10          	mov    rdi,QWORD PTR [rcx+0x10]
   2cf80:	48 8b 97 48 04 00 00 	mov    rdx,QWORD PTR [rdi+0x448]
   2cf87:	48 8b 34 c2          	mov    rsi,QWORD PTR [rdx+rax*8]
   2cf8b:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   2cf8e:	83 e8 01             	sub    eax,0x1
   2cf91:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   2cf94:	85 c0                	test   eax,eax
   2cf96:	0f 8f e8 ed ff ff    	jg     2bd84 <JS_CallInternal+0x91e4>
   2cf9c:	e8 9f 84 fe ff       	call   15440 <JS_FreeAtomStruct>
   2cfa1:	e9 de ed ff ff       	jmp    2bd84 <JS_CallInternal+0x91e4>
   2cfa6:	4d 89 cc             	mov    r12,r9
   2cfa9:	e9 92 63 ff ff       	jmp    23340 <JS_CallInternal+0x7a0>
   2cfae:	b8 01 00 00 00       	mov    eax,0x1
   2cfb3:	e9 a5 9a ff ff       	jmp    26a5d <JS_CallInternal+0x3ebd>
   2cfb8:	4c 89 eb             	mov    rbx,r13
   2cfbb:	e9 80 63 ff ff       	jmp    23340 <JS_CallInternal+0x7a0>
   2cfc0:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2cfc7:	89 ce                	mov    esi,ecx
   2cfc9:	e8 62 62 00 00       	call   33230 <JS_ThrowReferenceErrorUninitialized>
   2cfce:	e9 81 d5 ff ff       	jmp    2a554 <JS_CallInternal+0x79b4>
   2cfd3:	4d 89 f4             	mov    r12,r14
   2cfd6:	e9 65 63 ff ff       	jmp    23340 <JS_CallInternal+0x7a0>
   2cfdb:	48 8b 8d e8 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x118]
   2cfe2:	48 8b 79 10          	mov    rdi,QWORD PTR [rcx+0x10]
   2cfe6:	4c 89 8d 10 fe ff ff 	mov    QWORD PTR [rbp-0x1f0],r9
   2cfed:	48 89 85 28 fe ff ff 	mov    QWORD PTR [rbp-0x1d8],rax
   2cff4:	e8 87 13 ff ff       	call   1e380 <js_free_shape>
   2cff9:	4c 8b 8d 10 fe ff ff 	mov    r9,QWORD PTR [rbp-0x1f0]
   2d000:	48 8b 85 28 fe ff ff 	mov    rax,QWORD PTR [rbp-0x1d8]
   2d007:	e9 d7 f2 ff ff       	jmp    2c2e3 <JS_CallInternal+0x9743>
   2d00c:	4d 39 6e 08          	cmp    QWORD PTR [r14+0x8],r13
   2d010:	0f 84 14 f3 ff ff    	je     2c32a <JS_CallInternal+0x978a>
   2d016:	48 8b 8d e8 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x118]
   2d01d:	41 83 41 fc 01       	add    DWORD PTR [r9-0x4],0x1
   2d022:	41 83 45 fc 01       	add    DWORD PTR [r13-0x4],0x1
   2d027:	48 8b 79 10          	mov    rdi,QWORD PTR [rcx+0x10]
   2d02b:	eb b9                	jmp    2cfe6 <JS_CallInternal+0xa446>
   2d02d:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2d034:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2d038:	4c 89 8d 28 fe ff ff 	mov    QWORD PTR [rbp-0x1d8],r9
   2d03f:	48 89 8d 38 fe ff ff 	mov    QWORD PTR [rbp-0x1c8],rcx
   2d046:	e8 35 13 ff ff       	call   1e380 <js_free_shape>
   2d04b:	4c 8b 8d 28 fe ff ff 	mov    r9,QWORD PTR [rbp-0x1d8]
   2d052:	48 8b 8d 38 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x1c8]
   2d059:	e9 c0 f3 ff ff       	jmp    2c41e <JS_CallInternal+0x987e>
   2d05e:	4d 39 6e 08          	cmp    QWORD PTR [r14+0x8],r13
   2d062:	0f 84 fd f3 ff ff    	je     2c465 <JS_CallInternal+0x98c5>
   2d068:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2d06f:	41 83 41 fc 01       	add    DWORD PTR [r9-0x4],0x1
   2d074:	41 83 45 fc 01       	add    DWORD PTR [r13-0x4],0x1
   2d079:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2d07d:	eb b9                	jmp    2d038 <JS_CallInternal+0xa498>
   2d07f:	49 83 7e 08 00       	cmp    QWORD PTR [r14+0x8],0x0
   2d084:	0f 84 a0 f2 ff ff    	je     2c32a <JS_CallInternal+0x978a>
   2d08a:	48 8b 8d e8 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x118]
   2d091:	41 83 45 fc 01       	add    DWORD PTR [r13-0x4],0x1
   2d096:	48 8b 79 10          	mov    rdi,QWORD PTR [rcx+0x10]
   2d09a:	e9 c2 fc ff ff       	jmp    2cd61 <JS_CallInternal+0xa1c1>
   2d09f:	e8 2c 49 fe ff       	call   119d0 <__stack_chk_fail@plt>
   2d0a4:	41 0f b6 46 11       	movzx  eax,BYTE PTR [r14+0x11]
   2d0a9:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2d0b0:	4c 89 f6             	mov    rsi,r14
   2d0b3:	4c 89 ea             	mov    rdx,r13
   2d0b6:	83 e0 01             	and    eax,0x1
   2d0b9:	88 85 50 fe ff ff    	mov    BYTE PTR [rbp-0x1b0],al
   2d0bf:	e8 0c fa fe ff       	call   1cad0 <JS_FreeValue>
   2d0c4:	0f b6 85 50 fe ff ff 	movzx  eax,BYTE PTR [rbp-0x1b0]
   2d0cb:	e9 ed 99 ff ff       	jmp    26abd <JS_CallInternal+0x3f1d>
   2d0d0:	4d 89 f4             	mov    r12,r14
   2d0d3:	e9 68 62 ff ff       	jmp    23340 <JS_CallInternal+0x7a0>
   2d0d8:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2d0df:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2d0e3:	e9 56 fc ff ff       	jmp    2cd3e <JS_CallInternal+0xa19e>
   2d0e8:	4d 89 ec             	mov    r12,r13
   2d0eb:	e9 50 62 ff ff       	jmp    23340 <JS_CallInternal+0x7a0>
   2d0f0:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2d0f7:	4c 8b 60 10          	mov    r12,QWORD PTR [rax+0x10]
   2d0fb:	41 80 bc 24 e9 04 00 	cmp    BYTE PTR [r12+0x4e9],0x0
   2d102:	00 00 
   2d104:	74 53                	je     2d159 <JS_CallInternal+0xa5b9>
   2d106:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2d10d:	4c 89 ce             	mov    rsi,r9
   2d110:	48 89 ca             	mov    rdx,rcx
   2d113:	e8 b8 f9 fe ff       	call   1cad0 <JS_FreeValue>
   2d118:	31 c0                	xor    eax,eax
   2d11a:	48 c7 43 08 06 00 00 	mov    QWORD PTR [rbx+0x8],0x6
   2d121:	00 
   2d122:	48 89 03             	mov    QWORD PTR [rbx],rax
   2d125:	e9 06 84 ff ff       	jmp    25530 <JS_CallInternal+0x2990>
   2d12a:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2d131:	48 8d 35 81 04 0a 00 	lea    rsi,[rip+0xa0481]        # cd5b9 <_IO_stdin_used+0x5b9>
   2d138:	31 c0                	xor    eax,eax
   2d13a:	e8 41 3f 00 00       	call   31080 <JS_ThrowTypeError>
   2d13f:	e9 fc 61 ff ff       	jmp    23340 <JS_CallInternal+0x7a0>
   2d144:	4c 89 d0             	mov    rax,r10
   2d147:	e9 1b cd ff ff       	jmp    29e67 <JS_CallInternal+0x72c7>
   2d14c:	e8 df 60 00 00       	call   33230 <JS_ThrowReferenceErrorUninitialized>
   2d151:	4d 89 f4             	mov    r12,r14
   2d154:	e9 e7 61 ff ff       	jmp    23340 <JS_CallInternal+0x7a0>
   2d159:	41 c6 84 24 e9 04 00 	mov    BYTE PTR [r12+0x4e9],0x1
   2d160:	00 01 
   2d162:	48 89 c7             	mov    rdi,rax
   2d165:	31 c0                	xor    eax,eax
   2d167:	48 8d 35 64 03 0a 00 	lea    rsi,[rip+0xa0364]        # cd4d2 <_IO_stdin_used+0x4d2>
   2d16e:	48 89 8d 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],rcx
   2d175:	4c 89 8d 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],r9
   2d17c:	e8 df 62 00 00       	call   33460 <JS_ThrowInternalError>
   2d181:	48 8b 8d 40 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x1c0]
   2d188:	41 c6 84 24 e9 04 00 	mov    BYTE PTR [r12+0x4e9],0x0
   2d18f:	00 00 
   2d191:	4c 8b 8d 50 fe ff ff 	mov    r9,QWORD PTR [rbp-0x1b0]
   2d198:	e9 69 ff ff ff       	jmp    2d106 <JS_CallInternal+0xa566>

Disassembly of section .fini:
