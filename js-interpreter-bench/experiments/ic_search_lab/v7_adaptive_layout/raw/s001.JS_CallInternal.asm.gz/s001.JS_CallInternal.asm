
/mnt/c/Users/mzyx/Desktop/0921/js-interpreter-bench/experiments/ic_search_lab/v3_mass_search/artifacts/s001.qjs:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .plt.got:

Disassembly of section .plt.sec:

Disassembly of section .text:

0000000000022ae0 <JS_CallInternal>:
   22ae0:	55                   	push   rbp
   22ae1:	48 89 e5             	mov    rbp,rsp
   22ae4:	41 57                	push   r15
   22ae6:	41 56                	push   r14
   22ae8:	41 55                	push   r13
   22aea:	41 54                	push   r12
   22aec:	53                   	push   rbx
   22aed:	48 81 ec 48 02 00 00 	sub    rsp,0x248
   22af4:	48 8b 45 10          	mov    rax,QWORD PTR [rbp+0x10]
   22af8:	48 89 bd a0 fe ff ff 	mov    QWORD PTR [rbp-0x160],rdi
   22aff:	48 89 b5 e0 fe ff ff 	mov    QWORD PTR [rbp-0x120],rsi
   22b06:	48 89 85 70 fe ff ff 	mov    QWORD PTR [rbp-0x190],rax
   22b0d:	48 8b 45 18          	mov    rax,QWORD PTR [rbp+0x18]
   22b11:	48 89 95 d0 fe ff ff 	mov    QWORD PTR [rbp-0x130],rdx
   22b18:	48 89 85 80 fe ff ff 	mov    QWORD PTR [rbp-0x180],rax
   22b1f:	48 8b 45 20          	mov    rax,QWORD PTR [rbp+0x20]
   22b23:	48 89 8d 78 fe ff ff 	mov    QWORD PTR [rbp-0x188],rcx
   22b2a:	4c 89 85 88 fe ff ff 	mov    QWORD PTR [rbp-0x178],r8
   22b31:	44 89 8d bc fe ff ff 	mov    DWORD PTR [rbp-0x144],r9d
   22b38:	48 89 85 a8 fe ff ff 	mov    QWORD PTR [rbp-0x158],rax
   22b3f:	64 48 8b 04 25 28 00 	mov    rax,QWORD PTR fs:0x28
   22b46:	00 00 
   22b48:	48 89 45 c8          	mov    QWORD PTR [rbp-0x38],rax
   22b4c:	48 8b 47 10          	mov    rax,QWORD PTR [rdi+0x10]
   22b50:	48 89 85 c0 fe ff ff 	mov    QWORD PTR [rbp-0x140],rax
   22b57:	8b 87 a8 01 00 00    	mov    eax,DWORD PTR [rdi+0x1a8]
   22b5d:	89 85 e8 fe ff ff    	mov    DWORD PTR [rbp-0x118],eax
   22b63:	83 e8 01             	sub    eax,0x1
   22b66:	89 87 a8 01 00 00    	mov    DWORD PTR [rdi+0x1a8],eax
   22b6c:	85 c0                	test   eax,eax
   22b6e:	0f 8e 54 05 00 00    	jle    230c8 <JS_CallInternal+0x5e8>
   22b74:	83 bd d0 fe ff ff ff 	cmp    DWORD PTR [rbp-0x130],0xffffffff
   22b7b:	0f 85 7f 05 00 00    	jne    23100 <JS_CallInternal+0x620>
   22b81:	48 8b 85 e0 fe ff ff 	mov    rax,QWORD PTR [rbp-0x120]
   22b88:	0f b7 40 12          	movzx  eax,WORD PTR [rax+0x12]
   22b8c:	66 83 f8 0d          	cmp    ax,0xd
   22b90:	0f 85 99 07 00 00    	jne    2332f <JS_CallInternal+0x84f>
   22b96:	48 8b 85 e0 fe ff ff 	mov    rax,QWORD PTR [rbp-0x120]
   22b9d:	48 8b 40 28          	mov    rax,QWORD PTR [rax+0x28]
   22ba1:	48 89 85 d8 fe ff ff 	mov    QWORD PTR [rbp-0x128],rax
   22ba8:	0f b7 78 38          	movzx  edi,WORD PTR [rax+0x38]
   22bac:	8b 85 bc fe ff ff    	mov    eax,DWORD PTR [rbp-0x144]
   22bb2:	39 c7                	cmp    edi,eax
   22bb4:	0f 8f fc 01 00 00    	jg     22db6 <JS_CallInternal+0x2d6>
   22bba:	8b 45 28             	mov    eax,DWORD PTR [rbp+0x28]
   22bbd:	83 e0 02             	and    eax,0x2
   22bc0:	0f 45 c7             	cmovne eax,edi
   22bc3:	48 8b 95 d8 fe ff ff 	mov    rdx,QWORD PTR [rbp-0x128]
   22bca:	4c 8b bd c0 fe ff ff 	mov    r15,QWORD PTR [rbp-0x140]
   22bd1:	49 89 e8             	mov    r8,rbp
   22bd4:	44 0f b7 52 3a       	movzx  r10d,WORD PTR [rdx+0x3a]
   22bd9:	0f b7 72 3e          	movzx  esi,WORD PTR [rdx+0x3e]
   22bdd:	0f b7 52 40          	movzx  edx,WORD PTR [rdx+0x40]
   22be1:	89 f1                	mov    ecx,esi
   22be3:	44 01 d6             	add    esi,r10d
   22be6:	4c 89 d3             	mov    rbx,r10
   22be9:	01 c6                	add    esi,eax
   22beb:	49 89 d1             	mov    r9,rdx
   22bee:	48 63 f6             	movsxd rsi,esi
   22bf1:	48 8d 34 72          	lea    rsi,[rdx+rsi*2]
   22bf5:	48 c1 e6 03          	shl    rsi,0x3
   22bf9:	49 29 f0             	sub    r8,rsi
   22bfc:	4d 3b 87 d0 04 00 00 	cmp    r8,QWORD PTR [r15+0x4d0]
   22c03:	0f 82 d0 07 00 00    	jb     233d9 <JS_CallInternal+0x8f9>
   22c09:	4c 8b bd d8 fe ff ff 	mov    r15,QWORD PTR [rbp-0x128]
   22c10:	4c 8b 9d e0 fe ff ff 	mov    r11,QWORD PTR [rbp-0x120]
   22c17:	48 83 c6 17          	add    rsi,0x17
   22c1b:	45 0f b6 47 10       	movzx  r8d,BYTE PTR [r15+0x10]
   22c20:	44 8b bd bc fe ff ff 	mov    r15d,DWORD PTR [rbp-0x144]
   22c27:	4c 89 9d 08 ff ff ff 	mov    QWORD PTR [rbp-0xf8],r11
   22c2e:	4d 8b 5b 30          	mov    r11,QWORD PTR [r11+0x30]
   22c32:	44 89 85 3c ff ff ff 	mov    DWORD PTR [rbp-0xc4],r8d
   22c39:	49 89 f0             	mov    r8,rsi
   22c3c:	48 81 e6 00 f0 ff ff 	and    rsi,0xfffffffffffff000
   22c43:	44 89 bd 38 ff ff ff 	mov    DWORD PTR [rbp-0xc8],r15d
   22c4a:	4c 8b bd d0 fe ff ff 	mov    r15,QWORD PTR [rbp-0x130]
   22c51:	49 83 e0 f0          	and    r8,0xfffffffffffffff0
   22c55:	4c 89 9d 98 fe ff ff 	mov    QWORD PTR [rbp-0x168],r11
   22c5c:	49 89 e3             	mov    r11,rsp
   22c5f:	49 29 f3             	sub    r11,rsi
   22c62:	4c 89 bd 10 ff ff ff 	mov    QWORD PTR [rbp-0xf0],r15
   22c69:	4c 39 dc             	cmp    rsp,r11
   22c6c:	74 15                	je     22c83 <JS_CallInternal+0x1a3>
   22c6e:	48 81 ec 00 10 00 00 	sub    rsp,0x1000
   22c75:	48 83 8c 24 f8 0f 00 	or     QWORD PTR [rsp+0xff8],0x0
   22c7c:	00 00 
   22c7e:	4c 39 dc             	cmp    rsp,r11
   22c81:	75 eb                	jne    22c6e <JS_CallInternal+0x18e>
   22c83:	41 81 e0 ff 0f 00 00 	and    r8d,0xfff
   22c8a:	4c 29 c4             	sub    rsp,r8
   22c8d:	4d 85 c0             	test   r8,r8
   22c90:	74 06                	je     22c98 <JS_CallInternal+0x1b8>
   22c92:	4a 83 4c 04 f8 00    	or     QWORD PTR [rsp+r8*1-0x8],0x0
   22c98:	48 8b b5 a8 fe ff ff 	mov    rsi,QWORD PTR [rbp-0x158]
   22c9f:	4c 8d 5c 24 0f       	lea    r11,[rsp+0xf]
   22ca4:	49 83 e3 f0          	and    r11,0xfffffffffffffff0
   22ca8:	4c 89 9d 30 fe ff ff 	mov    QWORD PTR [rbp-0x1d0],r11
   22caf:	48 89 b5 90 fe ff ff 	mov    QWORD PTR [rbp-0x170],rsi
   22cb6:	85 c0                	test   eax,eax
   22cb8:	0f 85 3e 61 00 00    	jne    28dfc <JS_CallInternal+0x631c>
   22cbe:	48 98                	cdqe
   22cc0:	48 c1 e0 04          	shl    rax,0x4
   22cc4:	4c 01 d8             	add    rax,r11
   22cc7:	48 89 85 b0 fe ff ff 	mov    QWORD PTR [rbp-0x150],rax
   22cce:	48 89 85 20 ff ff ff 	mov    QWORD PTR [rbp-0xe0],rax
   22cd5:	48 8b 85 90 fe ff ff 	mov    rax,QWORD PTR [rbp-0x170]
   22cdc:	48 89 85 18 ff ff ff 	mov    QWORD PTR [rbp-0xe8],rax
   22ce3:	45 85 d2             	test   r10d,r10d
   22ce6:	74 30                	je     22d18 <JS_CallInternal+0x238>
   22ce8:	48 8b bd b0 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x150]
   22cef:	48 89 de             	mov    rsi,rbx
   22cf2:	48 c1 e6 04          	shl    rsi,0x4
   22cf6:	48 89 f8             	mov    rax,rdi
   22cf9:	48 01 fe             	add    rsi,rdi
   22cfc:	0f 1f 40 00          	nop    DWORD PTR [rax+0x0]
   22d00:	48 c7 00 00 00 00 00 	mov    QWORD PTR [rax],0x0
   22d07:	48 83 c0 10          	add    rax,0x10
   22d0b:	48 c7 40 f8 03 00 00 	mov    QWORD PTR [rax-0x8],0x3
   22d12:	00 
   22d13:	48 39 f0             	cmp    rax,rsi
   22d16:	75 e8                	jne    22d00 <JS_CallInternal+0x220>
   22d18:	0f b7 f9             	movzx  edi,cx
   22d1b:	48 8b 85 b0 fe ff ff 	mov    rax,QWORD PTR [rbp-0x150]
   22d22:	48 c1 e3 04          	shl    rbx,0x4
   22d26:	48 89 f9             	mov    rcx,rdi
   22d29:	48 01 c3             	add    rbx,rax
   22d2c:	48 c1 e1 04          	shl    rcx,0x4
   22d30:	48 8d 3c 0b          	lea    rdi,[rbx+rcx*1]
   22d34:	48 89 bd 28 ff ff ff 	mov    QWORD PTR [rbp-0xd8],rdi
   22d3b:	66 45 85 c9          	test   r9w,r9w
   22d3f:	74 0b                	je     22d4c <JS_CallInternal+0x26c>
   22d41:	48 c1 e2 03          	shl    rdx,0x3
   22d45:	31 f6                	xor    esi,esi
   22d47:	e8 64 ed fe ff       	call   11ab0 <memset@plt>
   22d4c:	48 8b 8d d8 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x128]
   22d53:	48 8b bd c0 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x140]
   22d5a:	48 89 9d 68 fe ff ff 	mov    QWORD PTR [rbp-0x198],rbx
   22d61:	48 8b 41 18          	mov    rax,QWORD PTR [rcx+0x18]
   22d65:	48 8b 49 48          	mov    rcx,QWORD PTR [rcx+0x48]
   22d69:	48 8b 97 f0 04 00 00 	mov    rdx,QWORD PTR [rdi+0x4f0]
   22d70:	48 89 8d e8 fe ff ff 	mov    QWORD PTR [rbp-0x118],rcx
   22d77:	48 8b 8d e0 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x120]
   22d7e:	48 89 95 00 ff ff ff 	mov    QWORD PTR [rbp-0x100],rdx
   22d85:	48 8d 95 00 ff ff ff 	lea    rdx,[rbp-0x100]
   22d8c:	48 89 97 f0 04 00 00 	mov    QWORD PTR [rdi+0x4f0],rdx
   22d93:	48 89 8d 60 fe ff ff 	mov    QWORD PTR [rbp-0x1a0],rcx
   22d9a:	48 89 95 c8 fe ff ff 	mov    QWORD PTR [rbp-0x138],rdx
   22da1:	4c 8d 60 01          	lea    r12,[rax+0x1]
   22da5:	0f b6 00             	movzx  eax,BYTE PTR [rax]
   22da8:	4c 8d 3d d1 cf 0d 00 	lea    r15,[rip+0xdcfd1]        # ffd80 <dispatch_table.85>
   22daf:	49 89 c5             	mov    r13,rax
   22db2:	41 ff 24 c7          	jmp    QWORD PTR [r15+rax*8]
   22db6:	89 f8                	mov    eax,edi
   22db8:	e9 06 fe ff ff       	jmp    22bc3 <JS_CallInternal+0xe3>
   22dbd:	f3 0f 1e fa          	endbr64
   22dc1:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]
   22dc8:	f3 0f 1e fa          	endbr64
   22dcc:	41 8d 85 4d ff ff ff 	lea    eax,[r13-0xb3]
   22dd3:	48 c7 43 08 00 00 00 	mov    QWORD PTR [rbx+0x8],0x0
   22dda:	00 
   22ddb:	49 83 c4 01          	add    r12,0x1
   22ddf:	48 83 c3 10          	add    rbx,0x10
   22de3:	48 89 43 f0          	mov    QWORD PTR [rbx-0x10],rax
   22de7:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   22ded:	49 89 c5             	mov    r13,rax
   22df0:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   22df4:	ff e0                	jmp    rax
   22df6:	f3 0f 1e fa          	endbr64
   22dfa:	66 0f 1f 44 00 00    	nop    WORD PTR [rax+rax*1+0x0]
   22e00:	f3 0f 1e fa          	endbr64
   22e04:	41 8b 44 24 04       	mov    eax,DWORD PTR [r12+0x4]
   22e09:	f3 0f 6f 53 f0       	movdqu xmm2,XMMWORD PTR [rbx-0x10]
   22e0e:	4d 8d 74 24 09       	lea    r14,[r12+0x9]
   22e13:	41 8b 0c 24          	mov    ecx,DWORD PTR [r12]
   22e17:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   22e1e:	89 85 28 fe ff ff    	mov    DWORD PTR [rbp-0x1d8],eax
   22e24:	41 0f b6 44 24 08    	movzx  eax,BYTE PTR [r12+0x8]
   22e2a:	0f 29 95 50 fe ff ff 	movaps XMMWORD PTR [rbp-0x1b0],xmm2
   22e31:	48 8b 95 58 fe ff ff 	mov    rdx,QWORD PTR [rbp-0x1a8]
   22e38:	88 85 40 fe ff ff    	mov    BYTE PTR [rbp-0x1c0],al
   22e3e:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   22e45:	89 8d 38 fe ff ff    	mov    DWORD PTR [rbp-0x1c8],ecx
   22e4b:	49 89 d4             	mov    r12,rdx
   22e4e:	4c 89 70 30          	mov    QWORD PTR [rax+0x30],r14
   22e52:	48 8b 85 50 fe ff ff 	mov    rax,QWORD PTR [rbp-0x1b0]
   22e59:	48 89 c6             	mov    rsi,rax
   22e5c:	48 89 85 10 fe ff ff 	mov    QWORD PTR [rbp-0x1f0],rax
   22e63:	e8 58 b3 04 00       	call   6e1c0 <JS_HasProperty>
   22e68:	85 c0                	test   eax,eax
   22e6a:	0f 88 76 07 00 00    	js     235e6 <JS_CallInternal+0xb06>
   22e70:	0f 84 95 60 00 00    	je     28f0b <JS_CallInternal+0x642b>
   22e76:	80 bd 40 fe ff ff 00 	cmp    BYTE PTR [rbp-0x1c0],0x0
   22e7d:	0f 85 d9 05 00 00    	jne    2345c <JS_CallInternal+0x97c>
   22e83:	41 83 ed 71          	sub    r13d,0x71
   22e87:	41 83 fd 04          	cmp    r13d,0x4
   22e8b:	0f 87 20 05 00 00    	ja     233b1 <JS_CallInternal+0x8d1>
   22e91:	48 8d 15 78 42 0b 00 	lea    rdx,[rip+0xb4278]        # d7110 <qjsc_repl_size+0x444>
   22e98:	4a 63 04 aa          	movsxd rax,DWORD PTR [rdx+r13*4]
   22e9c:	48 01 d0             	add    rax,rdx
   22e9f:	3e ff e0             	notrack jmp rax
   22ea2:	f3 0f 1e fa          	endbr64
   22ea6:	f3 0f 1e fa          	endbr64
   22eaa:	4c 89 a5 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],r12
   22eb1:	45 8d 95 14 ff ff ff 	lea    r10d,[r13-0xec]
   22eb8:	4d 63 da             	movsxd r11,r10d
   22ebb:	49 89 de             	mov    r14,rbx
   22ebe:	48 8b 8d 50 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x1b0]
   22ec5:	45 89 d1             	mov    r9d,r10d
   22ec8:	49 c1 e3 04          	shl    r11,0x4
   22ecc:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   22ed3:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   22eda:	41 b8 03 00 00 00    	mov    r8d,0x3
   22ee0:	4d 29 de             	sub    r14,r11
   22ee3:	4c 89 9d 38 fe ff ff 	mov    QWORD PTR [rbp-0x1c8],r11
   22eea:	49 8b 76 f0          	mov    rsi,QWORD PTR [r14-0x10]
   22eee:	49 8b 56 f8          	mov    rdx,QWORD PTR [r14-0x8]
   22ef2:	48 89 48 30          	mov    QWORD PTR [rax+0x30],rcx
   22ef6:	31 c9                	xor    ecx,ecx
   22ef8:	6a 00                	push   0x0
   22efa:	4d 8d 66 f0          	lea    r12,[r14-0x10]
   22efe:	41 56                	push   r14
   22f00:	6a 03                	push   0x3
   22f02:	6a 00                	push   0x0
   22f04:	44 89 95 40 fe ff ff 	mov    DWORD PTR [rbp-0x1c0],r10d
   22f0b:	e8 d0 fb ff ff       	call   22ae0 <JS_CallInternal>
   22f10:	48 83 c4 20          	add    rsp,0x20
   22f14:	44 8b 95 40 fe ff ff 	mov    r10d,DWORD PTR [rbp-0x1c0]
   22f1b:	4c 8b 9d 38 fe ff ff 	mov    r11,QWORD PTR [rbp-0x1c8]
   22f22:	83 fa 06             	cmp    edx,0x6
   22f25:	49 89 c1             	mov    r9,rax
   22f28:	49 89 d0             	mov    r8,rdx
   22f2b:	48 89 d1             	mov    rcx,rdx
   22f2e:	0f 84 d8 64 00 00    	je     2940c <JS_CallInternal+0x692c>
   22f34:	41 83 fd 23          	cmp    r13d,0x23
   22f38:	0f 84 95 02 00 00    	je     231d3 <JS_CallInternal+0x6f3>
   22f3e:	4d 01 de             	add    r14,r11
   22f41:	45 85 d2             	test   r10d,r10d
   22f44:	78 77                	js     22fbd <JS_CallInternal+0x4dd>
   22f46:	4d 89 e5             	mov    r13,r12
   22f49:	4d 89 f0             	mov    r8,r14
   22f4c:	48 89 95 38 fe ff ff 	mov    QWORD PTR [rbp-0x1c8],rdx
   22f53:	45 89 d4             	mov    r12d,r10d
   22f56:	49 89 c6             	mov    r14,rax
   22f59:	eb 0e                	jmp    22f69 <JS_CallInternal+0x489>
   22f5b:	0f 1f 44 00 00       	nop    DWORD PTR [rax+rax*1+0x0]
   22f60:	49 83 c5 10          	add    r13,0x10
   22f64:	4d 39 c5             	cmp    r13,r8
   22f67:	74 47                	je     22fb0 <JS_CallInternal+0x4d0>
   22f69:	49 8b 4d 08          	mov    rcx,QWORD PTR [r13+0x8]
   22f6d:	49 8b 75 00          	mov    rsi,QWORD PTR [r13+0x0]
   22f71:	83 f9 f6             	cmp    ecx,0xfffffff6
   22f74:	76 ea                	jbe    22f60 <JS_CallInternal+0x480>
   22f76:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   22f79:	8d 50 ff             	lea    edx,[rax-0x1]
   22f7c:	89 56 fc             	mov    DWORD PTR [rsi-0x4],edx
   22f7f:	85 d2                	test   edx,edx
   22f81:	7f dd                	jg     22f60 <JS_CallInternal+0x480>
   22f83:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   22f8a:	48 89 ca             	mov    rdx,rcx
   22f8d:	4c 89 85 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],r8
   22f94:	49 83 c5 10          	add    r13,0x10
   22f98:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   22f9c:	e8 ff 98 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   22fa1:	4c 8b 85 40 fe ff ff 	mov    r8,QWORD PTR [rbp-0x1c0]
   22fa8:	4d 39 c5             	cmp    r13,r8
   22fab:	75 bc                	jne    22f69 <JS_CallInternal+0x489>
   22fad:	0f 1f 00             	nop    DWORD PTR [rax]
   22fb0:	4c 8b 85 38 fe ff ff 	mov    r8,QWORD PTR [rbp-0x1c8]
   22fb7:	45 89 e2             	mov    r10d,r12d
   22fba:	4d 89 f1             	mov    r9,r14
   22fbd:	41 8d 42 01          	lea    eax,[r10+0x1]
   22fc1:	48 98                	cdqe
   22fc3:	48 c1 e0 04          	shl    rax,0x4
   22fc7:	48 89 c2             	mov    rdx,rax
   22fca:	48 89 d8             	mov    rax,rbx
   22fcd:	48 29 d0             	sub    rax,rdx
   22fd0:	4c 89 08             	mov    QWORD PTR [rax],r9
   22fd3:	48 8d 58 10          	lea    rbx,[rax+0x10]
   22fd7:	4c 89 40 08          	mov    QWORD PTR [rax+0x8],r8
   22fdb:	48 8b 85 50 fe ff ff 	mov    rax,QWORD PTR [rbp-0x1b0]
   22fe2:	4c 8d 60 01          	lea    r12,[rax+0x1]
   22fe6:	0f b6 00             	movzx  eax,BYTE PTR [rax]
   22fe9:	49 89 c5             	mov    r13,rax
   22fec:	41 ff 24 c7          	jmp    QWORD PTR [r15+rax*8]
   22ff0:	f3 0f 1e fa          	endbr64
   22ff4:	f3 0f 1e fa          	endbr64
   22ff8:	41 8b 04 24          	mov    eax,DWORD PTR [r12]
   22ffc:	31 f6                	xor    esi,esi
   22ffe:	b9 01 00 00 00       	mov    ecx,0x1
   23003:	ba 02 00 00 00       	mov    edx,0x2
   23008:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2300f:	45 0f b7 74 24 04    	movzx  r14d,WORD PTR [r12+0x4]
   23015:	89 85 50 fe ff ff    	mov    DWORD PTR [rbp-0x1b0],eax
   2301b:	49 8d 44 24 06       	lea    rax,[r12+0x6]
   23020:	48 89 85 38 fe ff ff 	mov    QWORD PTR [rbp-0x1c8],rax
   23027:	48 8d 43 10          	lea    rax,[rbx+0x10]
   2302b:	48 89 85 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],rax
   23032:	e8 d9 37 02 00       	call   46810 <JS_NewObjectProtoClass>
   23037:	48 89 53 08          	mov    QWORD PTR [rbx+0x8],rdx
   2303b:	83 7b 08 06          	cmp    DWORD PTR [rbx+0x8],0x6
   2303f:	48 89 03             	mov    QWORD PTR [rbx],rax
   23042:	0f 84 23 02 00 00    	je     2326b <JS_CallInternal+0x78b>
   23048:	41 83 fd 78          	cmp    r13d,0x78
   2304c:	0f 85 ed 01 00 00    	jne    2323f <JS_CallInternal+0x75f>
   23052:	48 8b 85 98 fe ff ff 	mov    rax,QWORD PTR [rbp-0x168]
   23059:	4e 8b 2c f0          	mov    r13,QWORD PTR [rax+r14*8]
   2305d:	41 83 45 fc 01       	add    DWORD PTR [r13-0x4],0x1
   23062:	48 8b 33             	mov    rsi,QWORD PTR [rbx]
   23065:	8b 95 50 fe ff ff    	mov    edx,DWORD PTR [rbp-0x1b0]
   2306b:	b9 22 00 00 00       	mov    ecx,0x22
   23070:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   23077:	e8 44 2f 02 00       	call   45fc0 <add_property>
   2307c:	48 85 c0             	test   rax,rax
   2307f:	0f 84 31 8f 00 00    	je     2bfb6 <JS_CallInternal+0x94d6>
   23085:	4c 89 28             	mov    QWORD PTR [rax],r13
   23088:	8b b5 50 fe ff ff    	mov    esi,DWORD PTR [rbp-0x1b0]
   2308e:	31 d2                	xor    edx,edx
   23090:	48 83 c3 20          	add    rbx,0x20
   23094:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2309b:	49 83 c4 07          	add    r12,0x7
   2309f:	e8 4c 0f 01 00       	call   33ff0 <__JS_AtomToValue>
   230a4:	48 8b 8d 40 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x1c0]
   230ab:	48 89 01             	mov    QWORD PTR [rcx],rax
   230ae:	48 89 51 08          	mov    QWORD PTR [rcx+0x8],rdx
   230b2:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   230b8:	49 89 c5             	mov    r13,rax
   230bb:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   230bf:	ff e0                	jmp    rax
   230c1:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]
   230c8:	e8 b3 00 01 00       	call   33180 <__js_poll_interrupts>
   230cd:	85 c0                	test   eax,eax
   230cf:	0f 84 9f fa ff ff    	je     22b74 <JS_CallInternal+0x94>
   230d5:	31 c0                	xor    eax,eax
   230d7:	ba 06 00 00 00       	mov    edx,0x6
   230dc:	48 8b 4d c8          	mov    rcx,QWORD PTR [rbp-0x38]
   230e0:	64 48 2b 0c 25 28 00 	sub    rcx,QWORD PTR fs:0x28
   230e7:	00 00 
   230e9:	0f 85 f9 9b 00 00    	jne    2cce8 <JS_CallInternal+0xa208>
   230ef:	48 8d 65 d8          	lea    rsp,[rbp-0x28]
   230f3:	5b                   	pop    rbx
   230f4:	41 5c                	pop    r12
   230f6:	41 5d                	pop    r13
   230f8:	41 5e                	pop    r14
   230fa:	41 5f                	pop    r15
   230fc:	5d                   	pop    rbp
   230fd:	c3                   	ret
   230fe:	66 90                	xchg   ax,ax
   23100:	f6 45 28 04          	test   BYTE PTR [rbp+0x28],0x4
   23104:	0f 84 d6 03 00 00    	je     234e0 <JS_CallInternal+0xa00>
   2310a:	48 8b 85 e0 fe ff ff 	mov    rax,QWORD PTR [rbp-0x120]
   23111:	48 8b 48 58          	mov    rcx,QWORD PTR [rax+0x58]
   23115:	48 8b 50 68          	mov    rdx,QWORD PTR [rax+0x68]
   23119:	48 8d 78 50          	lea    rdi,[rax+0x50]
   2311d:	48 89 bd c8 fe ff ff 	mov    QWORD PTR [rbp-0x138],rdi
   23124:	48 8b 59 28          	mov    rbx,QWORD PTR [rcx+0x28]
   23128:	48 89 8d 60 fe ff ff 	mov    QWORD PTR [rbp-0x1a0],rcx
   2312f:	48 8b 49 30          	mov    rcx,QWORD PTR [rcx+0x30]
   23133:	48 89 95 30 fe ff ff 	mov    QWORD PTR [rbp-0x1d0],rdx
   2313a:	48 8b 73 48          	mov    rsi,QWORD PTR [rbx+0x48]
   2313e:	48 89 9d d8 fe ff ff 	mov    QWORD PTR [rbp-0x128],rbx
   23145:	48 89 8d 98 fe ff ff 	mov    QWORD PTR [rbp-0x168],rcx
   2314c:	48 89 c1             	mov    rcx,rax
   2314f:	48 89 b5 e8 fe ff ff 	mov    QWORD PTR [rbp-0x118],rsi
   23156:	48 8b 70 70          	mov    rsi,QWORD PTR [rax+0x70]
   2315a:	0f b7 43 3a          	movzx  eax,WORD PTR [rbx+0x3a]
   2315e:	4c 8b a1 80 00 00 00 	mov    r12,QWORD PTR [rcx+0x80]
   23165:	48 89 b5 b0 fe ff ff 	mov    QWORD PTR [rbp-0x150],rsi
   2316c:	48 8b 99 90 00 00 00 	mov    rbx,QWORD PTR [rcx+0x90]
   23173:	48 c7 81 90 00 00 00 	mov    QWORD PTR [rcx+0x90],0x0
   2317a:	00 00 00 00 
   2317e:	48 c1 e0 04          	shl    rax,0x4
   23182:	48 01 f0             	add    rax,rsi
   23185:	48 8b b5 c0 fe ff ff 	mov    rsi,QWORD PTR [rbp-0x140]
   2318c:	48 89 85 68 fe ff ff 	mov    QWORD PTR [rbp-0x198],rax
   23193:	48 8b 86 f0 04 00 00 	mov    rax,QWORD PTR [rsi+0x4f0]
   2319a:	48 89 41 50          	mov    QWORD PTR [rcx+0x50],rax
   2319e:	48 89 be f0 04 00 00 	mov    QWORD PTR [rsi+0x4f0],rdi
   231a5:	8b 79 24             	mov    edi,DWORD PTR [rcx+0x24]
   231a8:	85 ff                	test   edi,edi
   231aa:	0f 84 9d 02 00 00    	je     2344d <JS_CallInternal+0x96d>
   231b0:	48 8b 85 30 fe ff ff 	mov    rax,QWORD PTR [rbp-0x1d0]
   231b7:	48 89 85 90 fe ff ff 	mov    QWORD PTR [rbp-0x170],rax
   231be:	e9 bd 00 00 00       	jmp    23280 <JS_CallInternal+0x7a0>
   231c3:	f3 0f 1e fa          	endbr64
   231c7:	48 8b 43 f0          	mov    rax,QWORD PTR [rbx-0x10]
   231cb:	48 8b 4b f8          	mov    rcx,QWORD PTR [rbx-0x8]
   231cf:	48 83 eb 10          	sub    rbx,0x10
   231d3:	48 8b bd d8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x128]
   231da:	66 83 7f 40 00       	cmp    WORD PTR [rdi+0x40],0x0
   231df:	0f 85 61 6e 00 00    	jne    2a046 <JS_CallInternal+0x7566>
   231e5:	4c 8b a5 30 fe ff ff 	mov    r12,QWORD PTR [rbp-0x1d0]
   231ec:	49 39 dc             	cmp    r12,rbx
   231ef:	0f 83 1a 01 00 00    	jae    2330f <JS_CallInternal+0x82f>
   231f5:	4c 8b ad e8 fe ff ff 	mov    r13,QWORD PTR [rbp-0x118]
   231fc:	49 89 ce             	mov    r14,rcx
   231ff:	49 89 c7             	mov    r15,rax
   23202:	eb 11                	jmp    23215 <JS_CallInternal+0x735>
   23204:	0f 1f 40 00          	nop    DWORD PTR [rax+0x0]
   23208:	49 83 c4 10          	add    r12,0x10
   2320c:	49 39 dc             	cmp    r12,rbx
   2320f:	0f 83 b9 01 00 00    	jae    233ce <JS_CallInternal+0x8ee>
   23215:	4d 8b 44 24 08       	mov    r8,QWORD PTR [r12+0x8]
   2321a:	49 8b 34 24          	mov    rsi,QWORD PTR [r12]
   2321e:	41 83 f8 f6          	cmp    r8d,0xfffffff6
   23222:	76 e4                	jbe    23208 <JS_CallInternal+0x728>
   23224:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   23227:	8d 50 ff             	lea    edx,[rax-0x1]
   2322a:	89 56 fc             	mov    DWORD PTR [rsi-0x4],edx
   2322d:	85 d2                	test   edx,edx
   2322f:	7f d7                	jg     23208 <JS_CallInternal+0x728>
   23231:	49 8b 7d 10          	mov    rdi,QWORD PTR [r13+0x10]
   23235:	4c 89 c2             	mov    rdx,r8
   23238:	e8 63 96 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2323d:	eb c9                	jmp    23208 <JS_CallInternal+0x728>
   2323f:	31 c9                	xor    ecx,ecx
   23241:	48 8b b5 c8 fe ff ff 	mov    rsi,QWORD PTR [rbp-0x138]
   23248:	41 83 fd 77          	cmp    r13d,0x77
   2324c:	41 0f b7 d6          	movzx  edx,r14w
   23250:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   23257:	0f 94 c1             	sete   cl
   2325a:	e8 11 86 02 00       	call   4b870 <get_var_ref>
   2325f:	49 89 c5             	mov    r13,rax
   23262:	48 85 c0             	test   rax,rax
   23265:	0f 85 f7 fd ff ff    	jne    23062 <JS_CallInternal+0x582>
   2326b:	48 8b 9d 40 fe ff ff 	mov    rbx,QWORD PTR [rbp-0x1c0]
   23272:	4c 8b a5 38 fe ff ff 	mov    r12,QWORD PTR [rbp-0x1c8]
   23279:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]
   23280:	48 8b 8d c0 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x140]
   23287:	83 b9 e0 04 00 00 ff 	cmp    DWORD PTR [rcx+0x4e0],0xffffffff
   2328e:	48 8b 81 d8 04 00 00 	mov    rax,QWORD PTR [rcx+0x4d8]
   23295:	75 39                	jne    232d0 <JS_CallInternal+0x7f0>
   23297:	66 83 78 12 03       	cmp    WORD PTR [rax+0x12],0x3
   2329c:	75 32                	jne    232d0 <JS_CallInternal+0x7f0>
   2329e:	48 8b 48 18          	mov    rcx,QWORD PTR [rax+0x18]
   232a2:	8b 51 18             	mov    edx,DWORD PTR [rcx+0x18]
   232a5:	89 d0                	mov    eax,edx
   232a7:	83 e0 39             	and    eax,0x39
   232aa:	8b 44 81 38          	mov    eax,DWORD PTR [rcx+rax*4+0x38]
   232ae:	48 85 c0             	test   rax,rax
   232b1:	0f 84 0c 68 00 00    	je     29ac3 <JS_CallInternal+0x6fe3>
   232b7:	48 8d 14 95 34 00 00 	lea    rdx,[rdx*4+0x34]
   232be:	00 
   232bf:	48 8d 04 c2          	lea    rax,[rdx+rax*8]
   232c3:	48 01 c8             	add    rax,rcx
   232c6:	83 78 04 39          	cmp    DWORD PTR [rax+0x4],0x39
   232ca:	0f 85 e6 67 00 00    	jne    29ab6 <JS_CallInternal+0x6fd6>
   232d0:	48 8b 85 c0 fe ff ff 	mov    rax,QWORD PTR [rbp-0x140]
   232d7:	80 b8 e8 04 00 00 00 	cmp    BYTE PTR [rax+0x4e8],0x0
   232de:	0f 84 39 01 00 00    	je     2341d <JS_CallInternal+0x93d>
   232e4:	48 8b 85 d8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x128]
   232eb:	b9 06 00 00 00       	mov    ecx,0x6
   232f0:	f6 40 11 30          	test   BYTE PTR [rax+0x11],0x30
   232f4:	b8 00 00 00 00       	mov    eax,0x0
   232f9:	0f 84 d4 fe ff ff    	je     231d3 <JS_CallInternal+0x6f3>
   232ff:	90                   	nop
   23300:	48 8b bd c8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x138]
   23307:	4c 89 67 30          	mov    QWORD PTR [rdi+0x30],r12
   2330b:	48 89 5f 40          	mov    QWORD PTR [rdi+0x40],rbx
   2330f:	48 8b 9d c8 fe ff ff 	mov    rbx,QWORD PTR [rbp-0x138]
   23316:	48 8b 13             	mov    rdx,QWORD PTR [rbx]
   23319:	48 8b 9d c0 fe ff ff 	mov    rbx,QWORD PTR [rbp-0x140]
   23320:	48 89 93 f0 04 00 00 	mov    QWORD PTR [rbx+0x4f0],rdx
   23327:	48 89 ca             	mov    rdx,rcx
   2332a:	e9 ad fd ff ff       	jmp    230dc <JS_CallInternal+0x5fc>
   2332f:	48 8b 8d c0 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x140]
   23336:	48 8d 04 80          	lea    rax,[rax+rax*4]
   2333a:	48 c1 e0 03          	shl    rax,0x3
   2333e:	48 03 81 58 04 00 00 	add    rax,QWORD PTR [rcx+0x458]
   23345:	48 8b 40 18          	mov    rax,QWORD PTR [rax+0x18]
   23349:	48 85 c0             	test   rax,rax
   2334c:	0f 84 8e 01 00 00    	je     234e0 <JS_CallInternal+0xa00>
   23352:	8b 4d 28             	mov    ecx,DWORD PTR [rbp+0x28]
   23355:	48 8b b5 e0 fe ff ff 	mov    rsi,QWORD PTR [rbp-0x120]
   2335c:	44 8b 8d bc fe ff ff 	mov    r9d,DWORD PTR [rbp-0x144]
   23363:	4c 8b 85 88 fe ff ff 	mov    r8,QWORD PTR [rbp-0x178]
   2336a:	48 8b 95 d0 fe ff ff 	mov    rdx,QWORD PTR [rbp-0x130]
   23371:	48 8b bd a0 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x160]
   23378:	51                   	push   rcx
   23379:	48 8b 8d 78 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x188]
   23380:	ff b5 a8 fe ff ff    	push   QWORD PTR [rbp-0x158]
   23386:	ff d0                	call   rax
   23388:	59                   	pop    rcx
   23389:	5e                   	pop    rsi
   2338a:	e9 4d fd ff ff       	jmp    230dc <JS_CallInternal+0x5fc>
   2338f:	8b b5 38 fe ff ff    	mov    esi,DWORD PTR [rbp-0x1c8]
   23395:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2339c:	31 d2                	xor    edx,edx
   2339e:	4c 8d 63 10          	lea    r12,[rbx+0x10]
   233a2:	e8 49 0c 01 00       	call   33ff0 <__JS_AtomToValue>
   233a7:	48 89 03             	mov    QWORD PTR [rbx],rax
   233aa:	48 89 53 08          	mov    QWORD PTR [rbx+0x8],rdx
   233ae:	4c 89 e3             	mov    rbx,r12
   233b1:	8b 85 28 fe ff ff    	mov    eax,DWORD PTR [rbp-0x1d8]
   233b7:	83 e8 05             	sub    eax,0x5
   233ba:	48 98                	cdqe
   233bc:	49 01 c6             	add    r14,rax
   233bf:	41 0f b6 06          	movzx  eax,BYTE PTR [r14]
   233c3:	4d 8d 66 01          	lea    r12,[r14+0x1]
   233c7:	49 89 c5             	mov    r13,rax
   233ca:	41 ff 24 c7          	jmp    QWORD PTR [r15+rax*8]
   233ce:	4c 89 f1             	mov    rcx,r14
   233d1:	4c 89 f8             	mov    rax,r15
   233d4:	e9 36 ff ff ff       	jmp    2330f <JS_CallInternal+0x82f>
   233d9:	48 8b bd a0 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x160]
   233e0:	48 8d 35 c4 a0 0a 00 	lea    rsi,[rip+0xaa0c4]        # cd4ab <_IO_stdin_used+0x4ab>
   233e7:	31 c0                	xor    eax,eax
   233e9:	e8 12 fc 00 00       	call   33000 <JS_ThrowInternalError>
   233ee:	e9 e9 fc ff ff       	jmp    230dc <JS_CallInternal+0x5fc>
   233f3:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   233fa:	4c 89 ee             	mov    rsi,r13
   233fd:	4c 89 f2             	mov    rdx,r14
   23400:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   23404:	e8 97 94 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   23409:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]
   23410:	41 83 fe 05          	cmp    r14d,0x5
   23414:	0f 84 ae 61 00 00    	je     295c8 <JS_CallInternal+0x6ae8>
   2341a:	4c 89 fb             	mov    rbx,r15
   2341d:	48 39 9d 68 fe ff ff 	cmp    QWORD PTR [rbp-0x198],rbx
   23424:	0f 83 ba fe ff ff    	jae    232e4 <JS_CallInternal+0x804>
   2342a:	4c 8b 73 f8          	mov    r14,QWORD PTR [rbx-0x8]
   2342e:	4c 8d 7b f0          	lea    r15,[rbx-0x10]
   23432:	4c 8b 6b f0          	mov    r13,QWORD PTR [rbx-0x10]
   23436:	41 83 fe f6          	cmp    r14d,0xfffffff6
   2343a:	76 d4                	jbe    23410 <JS_CallInternal+0x930>
   2343c:	41 8b 45 fc          	mov    eax,DWORD PTR [r13-0x4]
   23440:	83 e8 01             	sub    eax,0x1
   23443:	41 89 45 fc          	mov    DWORD PTR [r13-0x4],eax
   23447:	85 c0                	test   eax,eax
   23449:	7f c5                	jg     23410 <JS_CallInternal+0x930>
   2344b:	eb a6                	jmp    233f3 <JS_CallInternal+0x913>
   2344d:	48 89 95 90 fe ff ff 	mov    QWORD PTR [rbp-0x170],rdx
   23454:	4c 89 e0             	mov    rax,r12
   23457:	e9 45 f9 ff ff       	jmp    22da1 <JS_CallInternal+0x2c1>
   2345c:	48 83 ec 08          	sub    rsp,0x8
   23460:	4c 8b 85 50 fe ff ff 	mov    r8,QWORD PTR [rbp-0x1b0]
   23467:	48 8b b5 10 fe ff ff 	mov    rsi,QWORD PTR [rbp-0x1f0]
   2346e:	b9 f1 00 00 00       	mov    ecx,0xf1
   23473:	6a 00                	push   0x0
   23475:	4c 8b 8d 58 fe ff ff 	mov    r9,QWORD PTR [rbp-0x1a8]
   2347c:	4c 89 e2             	mov    rdx,r12
   2347f:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   23486:	e8 25 99 00 00       	call   2cdb0 <JS_GetPropertyInternal>
   2348b:	59                   	pop    rcx
   2348c:	5e                   	pop    rsi
   2348d:	49 89 c0             	mov    r8,rax
   23490:	49 89 d4             	mov    r12,rdx
   23493:	83 fa 06             	cmp    edx,0x6
   23496:	0f 84 4a 01 00 00    	je     235e6 <JS_CallInternal+0xb06>
   2349c:	83 fa ff             	cmp    edx,0xffffffff
   2349f:	0f 84 05 5a 00 00    	je     28eaa <JS_CallInternal+0x63ca>
   234a5:	83 fa f6             	cmp    edx,0xfffffff6
   234a8:	0f 86 d5 f9 ff ff    	jbe    22e83 <JS_CallInternal+0x3a3>
   234ae:	8b 40 fc             	mov    eax,DWORD PTR [rax-0x4]
   234b1:	83 e8 01             	sub    eax,0x1
   234b4:	41 89 40 fc          	mov    DWORD PTR [r8-0x4],eax
   234b8:	85 c0                	test   eax,eax
   234ba:	0f 8f c3 f9 ff ff    	jg     22e83 <JS_CallInternal+0x3a3>
   234c0:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   234c7:	4c 89 c6             	mov    rsi,r8
   234ca:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   234ce:	e8 cd 93 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   234d3:	e9 ab f9 ff ff       	jmp    22e83 <JS_CallInternal+0x3a3>
   234d8:	0f 1f 84 00 00 00 00 	nop    DWORD PTR [rax+rax*1+0x0]
   234df:	00 
   234e0:	48 8b bd a0 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x160]
   234e7:	48 8d 35 9a b6 0a 00 	lea    rsi,[rip+0xab69a]        # ceb88 <_IO_stdin_used+0x1b88>
   234ee:	31 c0                	xor    eax,eax
   234f0:	e8 2b d7 00 00       	call   30c20 <JS_ThrowTypeError>
   234f5:	e9 e2 fb ff ff       	jmp    230dc <JS_CallInternal+0x5fc>
   234fa:	48 8b 85 50 fe ff ff 	mov    rax,QWORD PTR [rbp-0x1b0]
   23501:	48 8b 95 58 fe ff ff 	mov    rdx,QWORD PTR [rbp-0x1a8]
   23508:	8b 8d 38 fe ff ff    	mov    ecx,DWORD PTR [rbp-0x1c8]
   2350e:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   23515:	48 89 c6             	mov    rsi,rax
   23518:	49 89 c5             	mov    r13,rax
   2351b:	49 89 d4             	mov    r12,rdx
   2351e:	e8 9d ac 04 00       	call   6e1c0 <JS_HasProperty>
   23523:	85 c0                	test   eax,eax
   23525:	0f 88 bb 00 00 00    	js     235e6 <JS_CallInternal+0xb06>
   2352b:	b8 03 00 00 00       	mov    eax,0x3
   23530:	b9 00 00 00 00       	mov    ecx,0x0
   23535:	0f 85 dd 76 00 00    	jne    2ac18 <JS_CallInternal+0x8138>
   2353b:	48 89 0b             	mov    QWORD PTR [rbx],rcx
   2353e:	48 83 c3 10          	add    rbx,0x10
   23542:	48 89 43 f8          	mov    QWORD PTR [rbx-0x8],rax
   23546:	e9 66 fe ff ff       	jmp    233b1 <JS_CallInternal+0x8d1>
   2354b:	48 8b 85 50 fe ff ff 	mov    rax,QWORD PTR [rbp-0x1b0]
   23552:	48 8b 95 58 fe ff ff 	mov    rdx,QWORD PTR [rbp-0x1a8]
   23559:	8b 8d 38 fe ff ff    	mov    ecx,DWORD PTR [rbp-0x1c8]
   2355f:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   23566:	48 89 c6             	mov    rsi,rax
   23569:	e8 52 ac 04 00       	call   6e1c0 <JS_HasProperty>
   2356e:	85 c0                	test   eax,eax
   23570:	0f 8e 54 88 00 00    	jle    2bdca <JS_CallInternal+0x92ea>
   23576:	48 83 ec 08          	sub    rsp,0x8
   2357a:	4c 8b 43 e0          	mov    r8,QWORD PTR [rbx-0x20]
   2357e:	4c 8b 4b e8          	mov    r9,QWORD PTR [rbx-0x18]
   23582:	4c 8d 63 e0          	lea    r12,[rbx-0x20]
   23586:	4c 8b 95 50 fe ff ff 	mov    r10,QWORD PTR [rbp-0x1b0]
   2358d:	4c 8b 9d 58 fe ff ff 	mov    r11,QWORD PTR [rbp-0x1a8]
   23594:	68 00 80 00 00       	push   0x8000
   23599:	8b 8d 38 fe ff ff    	mov    ecx,DWORD PTR [rbp-0x1c8]
   2359f:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   235a6:	41 53                	push   r11
   235a8:	4c 89 d6             	mov    rsi,r10
   235ab:	4c 89 da             	mov    rdx,r11
   235ae:	41 52                	push   r10
   235b0:	e8 2b a5 00 00       	call   2dae0 <JS_SetPropertyInternal>
   235b5:	48 8b 53 f8          	mov    rdx,QWORD PTR [rbx-0x8]
   235b9:	48 8b 73 f0          	mov    rsi,QWORD PTR [rbx-0x10]
   235bd:	48 83 c4 20          	add    rsp,0x20
   235c1:	41 89 c5             	mov    r13d,eax
   235c4:	83 fa f6             	cmp    edx,0xfffffff6
   235c7:	76 11                	jbe    235da <JS_CallInternal+0xafa>
   235c9:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   235cc:	83 e8 01             	sub    eax,0x1
   235cf:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   235d2:	85 c0                	test   eax,eax
   235d4:	0f 8e 20 88 00 00    	jle    2bdfa <JS_CallInternal+0x931a>
   235da:	4c 89 e3             	mov    rbx,r12
   235dd:	45 85 ed             	test   r13d,r13d
   235e0:	0f 89 cb fd ff ff    	jns    233b1 <JS_CallInternal+0x8d1>
   235e6:	4d 89 f4             	mov    r12,r14
   235e9:	e9 92 fc ff ff       	jmp    23280 <JS_CallInternal+0x7a0>
   235ee:	48 8b 85 50 fe ff ff 	mov    rax,QWORD PTR [rbp-0x1b0]
   235f5:	48 8b 95 58 fe ff ff 	mov    rdx,QWORD PTR [rbp-0x1a8]
   235fc:	8b 8d 38 fe ff ff    	mov    ecx,DWORD PTR [rbp-0x1c8]
   23602:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   23609:	48 89 c6             	mov    rsi,rax
   2360c:	49 89 c5             	mov    r13,rax
   2360f:	49 89 d4             	mov    r12,rdx
   23612:	e8 a9 ab 04 00       	call   6e1c0 <JS_HasProperty>
   23617:	85 c0                	test   eax,eax
   23619:	0f 8e c4 86 00 00    	jle    2bce3 <JS_CallInternal+0x9203>
   2361f:	48 83 ec 08          	sub    rsp,0x8
   23623:	8b 8d 38 fe ff ff    	mov    ecx,DWORD PTR [rbp-0x1c8]
   23629:	4c 89 ee             	mov    rsi,r13
   2362c:	4c 89 e2             	mov    rdx,r12
   2362f:	4c 8b 8d 58 fe ff ff 	mov    r9,QWORD PTR [rbp-0x1a8]
   23636:	4c 8b 85 50 fe ff ff 	mov    r8,QWORD PTR [rbp-0x1b0]
   2363d:	6a 00                	push   0x0
   2363f:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   23646:	e8 65 97 00 00       	call   2cdb0 <JS_GetPropertyInternal>
   2364b:	41 59                	pop    r9
   2364d:	41 5a                	pop    r10
   2364f:	48 89 c1             	mov    rcx,rax
   23652:	48 89 d0             	mov    rax,rdx
   23655:	83 fa 06             	cmp    edx,0x6
   23658:	74 8c                	je     235e6 <JS_CallInternal+0xb06>
   2365a:	48 8b 53 f8          	mov    rdx,QWORD PTR [rbx-0x8]
   2365e:	48 8b 73 f0          	mov    rsi,QWORD PTR [rbx-0x10]
   23662:	48 89 43 f8          	mov    QWORD PTR [rbx-0x8],rax
   23666:	48 89 4b f0          	mov    QWORD PTR [rbx-0x10],rcx
   2366a:	83 fa f6             	cmp    edx,0xfffffff6
   2366d:	0f 86 3e fd ff ff    	jbe    233b1 <JS_CallInternal+0x8d1>
   23673:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   23676:	83 e8 01             	sub    eax,0x1
   23679:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   2367c:	85 c0                	test   eax,eax
   2367e:	0f 8f 2d fd ff ff    	jg     233b1 <JS_CallInternal+0x8d1>
   23684:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2368b:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2368f:	e8 0c 92 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   23694:	e9 18 fd ff ff       	jmp    233b1 <JS_CallInternal+0x8d1>
   23699:	48 8b 85 50 fe ff ff 	mov    rax,QWORD PTR [rbp-0x1b0]
   236a0:	8b 8d 38 fe ff ff    	mov    ecx,DWORD PTR [rbp-0x1c8]
   236a6:	45 31 c0             	xor    r8d,r8d
   236a9:	48 8b 95 58 fe ff ff 	mov    rdx,QWORD PTR [rbp-0x1a8]
   236b0:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   236b7:	48 89 c6             	mov    rsi,rax
   236ba:	e8 d1 78 02 00       	call   4af90 <JS_DeleteProperty>
   236bf:	41 89 c4             	mov    r12d,eax
   236c2:	85 c0                	test   eax,eax
   236c4:	0f 88 1c ff ff ff    	js     235e6 <JS_CallInternal+0xb06>
   236ca:	48 8b 53 f8          	mov    rdx,QWORD PTR [rbx-0x8]
   236ce:	48 8b 73 f0          	mov    rsi,QWORD PTR [rbx-0x10]
   236d2:	83 fa f6             	cmp    edx,0xfffffff6
   236d5:	76 11                	jbe    236e8 <JS_CallInternal+0xc08>
   236d7:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   236da:	83 e8 01             	sub    eax,0x1
   236dd:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   236e0:	85 c0                	test   eax,eax
   236e2:	0f 8e cd 86 00 00    	jle    2bdb5 <JS_CallInternal+0x92d5>
   236e8:	31 c0                	xor    eax,eax
   236ea:	45 85 e4             	test   r12d,r12d
   236ed:	48 c7 43 f8 01 00 00 	mov    QWORD PTR [rbx-0x8],0x1
   236f4:	00 
   236f5:	0f 95 c0             	setne  al
   236f8:	48 89 43 f0          	mov    QWORD PTR [rbx-0x10],rax
   236fc:	e9 b0 fc ff ff       	jmp    233b1 <JS_CallInternal+0x8d1>
   23701:	f3 0f 1e fa          	endbr64
   23705:	f3 0f 1e fa          	endbr64
   23709:	41 0f b7 04 24       	movzx  eax,WORD PTR [r12]
   2370e:	48 8b 8d 98 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x168]
   23715:	4d 8d 74 24 02       	lea    r14,[r12+0x2]
   2371a:	48 8b 14 c1          	mov    rdx,QWORD PTR [rcx+rax*8]
   2371e:	48 8d 34 c5 00 00 00 	lea    rsi,[rax*8+0x0]
   23725:	00 
   23726:	48 8b 42 18          	mov    rax,QWORD PTR [rdx+0x18]
   2372a:	48 8b 48 08          	mov    rcx,QWORD PTR [rax+0x8]
   2372e:	83 f9 04             	cmp    ecx,0x4
   23731:	0f 84 09 62 00 00    	je     29940 <JS_CallInternal+0x6e60>
   23737:	80 7a 12 00          	cmp    BYTE PTR [rdx+0x12],0x0
   2373b:	0f 85 ff 61 00 00    	jne    29940 <JS_CallInternal+0x6e60>
   23741:	f3 0f 6f 63 f0       	movdqu xmm4,XMMWORD PTR [rbx-0x10]
   23746:	48 8b 30             	mov    rsi,QWORD PTR [rax]
   23749:	0f 11 20             	movups XMMWORD PTR [rax],xmm4
   2374c:	83 f9 f6             	cmp    ecx,0xfffffff6
   2374f:	76 11                	jbe    23762 <JS_CallInternal+0xc82>
   23751:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   23754:	83 e8 01             	sub    eax,0x1
   23757:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   2375a:	85 c0                	test   eax,eax
   2375c:	0f 8e 46 6a 00 00    	jle    2a1a8 <JS_CallInternal+0x76c8>
   23762:	48 83 eb 10          	sub    rbx,0x10
   23766:	41 0f b6 44 24 02    	movzx  eax,BYTE PTR [r12+0x2]
   2376c:	49 83 c4 03          	add    r12,0x3
   23770:	49 89 c5             	mov    r13,rax
   23773:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   23777:	ff e0                	jmp    rax
   23779:	f3 0f 1e fa          	endbr64
   2377d:	f3 0f 1e fa          	endbr64
   23781:	48 83 ec 08          	sub    rsp,0x8
   23785:	31 c0                	xor    eax,eax
   23787:	41 83 fd 54          	cmp    r13d,0x54
   2378b:	41 0f b6 4c 24 04    	movzx  ecx,BYTE PTR [r12+0x4]
   23791:	0f 94 c0             	sete   al
   23794:	41 8b 14 24          	mov    edx,DWORD PTR [r12]
   23798:	48 89 de             	mov    rsi,rbx
   2379b:	4d 8d 74 24 05       	lea    r14,[r12+0x5]
   237a0:	4c 8b 8d c8 fe ff ff 	mov    r9,QWORD PTR [rbp-0x138]
   237a7:	4c 8b 85 98 fe ff ff 	mov    r8,QWORD PTR [rbp-0x168]
   237ae:	50                   	push   rax
   237af:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   237b6:	e8 95 58 06 00       	call   89050 <js_op_define_class>
   237bb:	41 59                	pop    r9
   237bd:	41 5a                	pop    r10
   237bf:	85 c0                	test   eax,eax
   237c1:	0f 88 d1 86 00 00    	js     2be98 <JS_CallInternal+0x93b8>
   237c7:	41 0f b6 44 24 05    	movzx  eax,BYTE PTR [r12+0x5]
   237cd:	49 83 c4 06          	add    r12,0x6
   237d1:	49 89 c5             	mov    r13,rax
   237d4:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   237d8:	ff e0                	jmp    rax
   237da:	f3 0f 1e fa          	endbr64
   237de:	f3 0f 1e fa          	endbr64
   237e2:	41 83 fd 52          	cmp    r13d,0x52
   237e6:	0f 94 c0             	sete   al
   237e9:	41 0f 94 c6          	sete   r14b
   237ed:	0f b6 c0             	movzx  eax,al
   237f0:	89 85 40 fe ff ff    	mov    DWORD PTR [rbp-0x1c0],eax
   237f6:	45 84 f6             	test   r14b,r14b
   237f9:	0f 85 41 60 00 00    	jne    29840 <JS_CallInternal+0x6d60>
   237ff:	41 8b 04 24          	mov    eax,DWORD PTR [r12]
   23803:	4d 8d 6c 24 04       	lea    r13,[r12+0x4]
   23808:	89 85 50 fe ff ff    	mov    DWORD PTR [rbp-0x1b0],eax
   2380e:	8b 8d 40 fe ff ff    	mov    ecx,DWORD PTR [rbp-0x1c0]
   23814:	b8 fe ff ff ff       	mov    eax,0xfffffffe
   23819:	41 0f b6 55 00       	movzx  edx,BYTE PTR [r13+0x0]
   2381e:	bf 03 00 00 00       	mov    edi,0x3
   23823:	48 c7 85 38 fe ff ff 	mov    QWORD PTR [rbp-0x1c8],0x0
   2382a:	00 00 00 00 
   2382e:	4c 8d 63 f0          	lea    r12,[rbx-0x10]
   23832:	29 c8                	sub    eax,ecx
   23834:	48 89 bd 18 fe ff ff 	mov    QWORD PTR [rbp-0x1e8],rdi
   2383b:	48 98                	cdqe
   2383d:	48 89 bd e8 fd ff ff 	mov    QWORD PTR [rbp-0x218],rdi
   23844:	48 c7 85 28 fe ff ff 	mov    QWORD PTR [rbp-0x1d8],0x3
   2384b:	03 00 00 00 
   2384f:	48 c1 e0 04          	shl    rax,0x4
   23853:	48 8b 0c 03          	mov    rcx,QWORD PTR [rbx+rax*1]
   23857:	48 8b 44 03 08       	mov    rax,QWORD PTR [rbx+rax*1+0x8]
   2385c:	48 89 85 c0 fd ff ff 	mov    QWORD PTR [rbp-0x240],rax
   23863:	89 d0                	mov    eax,edx
   23865:	83 e0 04             	and    eax,0x4
   23868:	48 89 8d c8 fd ff ff 	mov    QWORD PTR [rbp-0x238],rcx
   2386f:	3c 01                	cmp    al,0x1
   23871:	19 c0                	sbb    eax,eax
   23873:	31 f6                	xor    esi,esi
   23875:	83 e0 fc             	and    eax,0xfffffffc
   23878:	48 89 b5 10 fe ff ff 	mov    QWORD PTR [rbp-0x1f0],rsi
   2387f:	48 89 b5 e0 fd ff ff 	mov    QWORD PTR [rbp-0x220],rsi
   23886:	05 05 45 00 00       	add    eax,0x4505
   2388b:	83 e2 03             	and    edx,0x3
   2388e:	0f 85 30 57 00 00    	jne    28fc4 <JS_CallInternal+0x64e4>
   23894:	48 8b 4b f0          	mov    rcx,QWORD PTR [rbx-0x10]
   23898:	0d 02 22 00 00       	or     eax,0x2202
   2389d:	8b b5 50 fe ff ff    	mov    esi,DWORD PTR [rbp-0x1b0]
   238a3:	89 85 24 fe ff ff    	mov    DWORD PTR [rbp-0x1dc],eax
   238a9:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   238b0:	48 89 8d 38 fe ff ff 	mov    QWORD PTR [rbp-0x1c8],rcx
   238b7:	48 8b 43 f0          	mov    rax,QWORD PTR [rbx-0x10]
   238bb:	48 8b 4b f8          	mov    rcx,QWORD PTR [rbx-0x8]
   238bf:	48 89 85 d8 fd ff ff 	mov    QWORD PTR [rbp-0x228],rax
   238c6:	48 89 8d 28 fe ff ff 	mov    QWORD PTR [rbp-0x1d8],rcx
   238cd:	48 89 8d d0 fd ff ff 	mov    QWORD PTR [rbp-0x230],rcx
   238d4:	e8 97 c8 01 00       	call   40170 <js_get_function_name>
   238d9:	49 89 d1             	mov    r9,rdx
   238dc:	41 83 f9 06          	cmp    r9d,0x6
   238e0:	0f 84 9b 69 00 00    	je     2a281 <JS_CallInternal+0x77a1>
   238e6:	48 83 ec 08          	sub    rsp,0x8
   238ea:	49 89 c0             	mov    r8,rax
   238ed:	b9 3a 00 00 00       	mov    ecx,0x3a
   238f2:	48 8b 95 d0 fd ff ff 	mov    rdx,QWORD PTR [rbp-0x230]
   238f9:	48 8b b5 d8 fd ff ff 	mov    rsi,QWORD PTR [rbp-0x228]
   23900:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   23907:	6a 01                	push   0x1
   23909:	48 89 95 b8 fd ff ff 	mov    QWORD PTR [rbp-0x248],rdx
   23910:	48 89 b5 b0 fd ff ff 	mov    QWORD PTR [rbp-0x250],rsi
   23917:	e8 84 c4 00 00       	call   2fda0 <JS_DefinePropertyValue>
   2391c:	41 5b                	pop    r11
   2391e:	5a                   	pop    rdx
   2391f:	85 c0                	test   eax,eax
   23921:	0f 88 5a 69 00 00    	js     2a281 <JS_CallInternal+0x77a1>
   23927:	4c 8b 95 c8 fd ff ff 	mov    r10,QWORD PTR [rbp-0x238]
   2392e:	48 8b 85 c0 fd ff ff 	mov    rax,QWORD PTR [rbp-0x240]
   23935:	48 8b b5 b0 fd ff ff 	mov    rsi,QWORD PTR [rbp-0x250]
   2393c:	48 8b 95 b8 fd ff ff 	mov    rdx,QWORD PTR [rbp-0x248]
   23943:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2394a:	4c 89 d1             	mov    rcx,r10
   2394d:	49 89 c0             	mov    r8,rax
   23950:	4c 89 95 d0 fd ff ff 	mov    QWORD PTR [rbp-0x230],r10
   23957:	48 89 85 d8 fd ff ff 	mov    QWORD PTR [rbp-0x228],rax
   2395e:	e8 bd a7 ff ff       	call   1e120 <js_method_set_home_object>
   23963:	8b 85 24 fe ff ff    	mov    eax,DWORD PTR [rbp-0x1dc]
   23969:	48 83 ec 08          	sub    rsp,0x8
   2396d:	8b 8d 50 fe ff ff    	mov    ecx,DWORD PTR [rbp-0x1b0]
   23973:	4c 8b 85 38 fe ff ff 	mov    r8,QWORD PTR [rbp-0x1c8]
   2397a:	4c 8b 8d 28 fe ff ff 	mov    r9,QWORD PTR [rbp-0x1d8]
   23981:	48 8b b5 d0 fd ff ff 	mov    rsi,QWORD PTR [rbp-0x230]
   23988:	48 8b 95 d8 fd ff ff 	mov    rdx,QWORD PTR [rbp-0x228]
   2398f:	50                   	push   rax
   23990:	ff b5 e8 fd ff ff    	push   QWORD PTR [rbp-0x218]
   23996:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2399d:	ff b5 e0 fd ff ff    	push   QWORD PTR [rbp-0x220]
   239a3:	ff b5 18 fe ff ff    	push   QWORD PTR [rbp-0x1e8]
   239a9:	ff b5 10 fe ff ff    	push   QWORD PTR [rbp-0x1f0]
   239af:	e8 5c b5 00 00       	call   2ef10 <JS_DefineProperty>
   239b4:	48 83 c4 30          	add    rsp,0x30
   239b8:	89 c1                	mov    ecx,eax
   239ba:	49 8b 54 24 08       	mov    rdx,QWORD PTR [r12+0x8]
   239bf:	49 8b 34 24          	mov    rsi,QWORD PTR [r12]
   239c3:	83 fa f6             	cmp    edx,0xfffffff6
   239c6:	76 11                	jbe    239d9 <JS_CallInternal+0xef9>
   239c8:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   239cb:	83 e8 01             	sub    eax,0x1
   239ce:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   239d1:	85 c0                	test   eax,eax
   239d3:	0f 8e e7 67 00 00    	jle    2a1c0 <JS_CallInternal+0x76e0>
   239d9:	45 84 f6             	test   r14b,r14b
   239dc:	0f 85 bc 57 00 00    	jne    2919e <JS_CallInternal+0x66be>
   239e2:	8b 85 40 fe ff ff    	mov    eax,DWORD PTR [rbp-0x1c0]
   239e8:	4d 8d 65 01          	lea    r12,[r13+0x1]
   239ec:	83 c0 01             	add    eax,0x1
   239ef:	48 98                	cdqe
   239f1:	48 c1 e0 04          	shl    rax,0x4
   239f5:	48 29 c3             	sub    rbx,rax
   239f8:	85 c9                	test   ecx,ecx
   239fa:	0f 88 80 f8 ff ff    	js     23280 <JS_CallInternal+0x7a0>
   23a00:	41 0f b6 45 01       	movzx  eax,BYTE PTR [r13+0x1]
   23a05:	4d 8d 65 02          	lea    r12,[r13+0x2]
   23a09:	49 89 c5             	mov    r13,rax
   23a0c:	41 ff 24 c7          	jmp    QWORD PTR [r15+rax*8]
   23a10:	f3 0f 1e fa          	endbr64
   23a14:	f3 0f 1e fa          	endbr64
   23a18:	45 0f b7 0c 24       	movzx  r9d,WORD PTR [r12]
   23a1d:	49 89 db             	mov    r11,rbx
   23a20:	49 8d 4c 24 02       	lea    rcx,[r12+0x2]
   23a25:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   23a2c:	48 89 8d 28 fe ff ff 	mov    QWORD PTR [rbp-0x1d8],rcx
   23a33:	4c 89 c8             	mov    rax,r9
   23a36:	44 89 8d 38 fe ff ff 	mov    DWORD PTR [rbp-0x1c8],r9d
   23a3d:	48 c1 e0 04          	shl    rax,0x4
   23a41:	49 29 c3             	sub    r11,rax
   23a44:	48 89 85 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],rax
   23a4b:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   23a52:	49 8b 73 f0          	mov    rsi,QWORD PTR [r11-0x10]
   23a56:	49 8b 53 f8          	mov    rdx,QWORD PTR [r11-0x8]
   23a5a:	4d 8d 73 e0          	lea    r14,[r11-0x20]
   23a5e:	48 89 48 30          	mov    QWORD PTR [rax+0x30],rcx
   23a62:	4d 8b 46 08          	mov    r8,QWORD PTR [r14+0x8]
   23a66:	49 8b 4b e0          	mov    rcx,QWORD PTR [r11-0x20]
   23a6a:	6a 00                	push   0x0
   23a6c:	41 53                	push   r11
   23a6e:	4c 89 9d 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],r11
   23a75:	6a 03                	push   0x3
   23a77:	6a 00                	push   0x0
   23a79:	e8 62 f0 ff ff       	call   22ae0 <JS_CallInternal>
   23a7e:	48 83 c4 20          	add    rsp,0x20
   23a82:	4c 8b 9d 50 fe ff ff 	mov    r11,QWORD PTR [rbp-0x1b0]
   23a89:	4c 8b 95 40 fe ff ff 	mov    r10,QWORD PTR [rbp-0x1c0]
   23a90:	83 fa 06             	cmp    edx,0x6
   23a93:	48 89 d1             	mov    rcx,rdx
   23a96:	0f 84 6b 68 00 00    	je     2a307 <JS_CallInternal+0x7827>
   23a9c:	41 83 fd 25          	cmp    r13d,0x25
   23aa0:	0f 84 2d f7 ff ff    	je     231d3 <JS_CallInternal+0x6f3>
   23aa6:	4f 8d 2c 13          	lea    r13,[r11+r10*1]
   23aaa:	48 89 9d 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],rbx
   23ab1:	4c 89 f3             	mov    rbx,r14
   23ab4:	49 89 d6             	mov    r14,rdx
   23ab7:	4c 89 a5 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],r12
   23abe:	4d 89 ec             	mov    r12,r13
   23ac1:	49 89 c5             	mov    r13,rax
   23ac4:	eb 17                	jmp    23add <JS_CallInternal+0xffd>
   23ac6:	66 2e 0f 1f 84 00 00 	cs nop WORD PTR [rax+rax*1+0x0]
   23acd:	00 00 00 
   23ad0:	48 83 c3 10          	add    rbx,0x10
   23ad4:	4c 39 e3             	cmp    rbx,r12
   23ad7:	0f 84 68 54 00 00    	je     28f45 <JS_CallInternal+0x6465>
   23add:	48 8b 4b 08          	mov    rcx,QWORD PTR [rbx+0x8]
   23ae1:	48 8b 33             	mov    rsi,QWORD PTR [rbx]
   23ae4:	83 f9 f6             	cmp    ecx,0xfffffff6
   23ae7:	76 e7                	jbe    23ad0 <JS_CallInternal+0xff0>
   23ae9:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   23aec:	8d 50 ff             	lea    edx,[rax-0x1]
   23aef:	89 56 fc             	mov    DWORD PTR [rsi-0x4],edx
   23af2:	85 d2                	test   edx,edx
   23af4:	7f da                	jg     23ad0 <JS_CallInternal+0xff0>
   23af6:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   23afd:	48 89 ca             	mov    rdx,rcx
   23b00:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   23b04:	e8 97 8d ff ff       	call   1c8a0 <__JS_FreeValueRT>
   23b09:	eb c5                	jmp    23ad0 <JS_CallInternal+0xff0>
   23b0b:	f3 0f 1e fa          	endbr64
   23b0f:	f3 0f 1e fa          	endbr64
   23b13:	31 c9                	xor    ecx,ecx
   23b15:	b8 02 00 00 00       	mov    eax,0x2
   23b1a:	e9 e1 f7 ff ff       	jmp    23300 <JS_CallInternal+0x820>
   23b1f:	f3 0f 1e fa          	endbr64
   23b23:	f3 0f 1e fa          	endbr64
   23b27:	48 8b 85 d8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x128]
   23b2e:	4c 89 e2             	mov    rdx,r12
   23b31:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   23b38:	44 89 e9             	mov    ecx,r13d
   23b3b:	48 8d 35 ce d2 0a 00 	lea    rsi,[rip+0xad2ce]        # d0e10 <_IO_stdin_used+0x3e10>
   23b42:	48 2b 50 18          	sub    rdx,QWORD PTR [rax+0x18]
   23b46:	31 c0                	xor    eax,eax
   23b48:	83 ea 01             	sub    edx,0x1
   23b4b:	e8 b0 f4 00 00       	call   33000 <JS_ThrowInternalError>
   23b50:	e9 2b f7 ff ff       	jmp    23280 <JS_CallInternal+0x7a0>
   23b55:	f3 0f 1e fa          	endbr64
   23b59:	f3 0f 1e fa          	endbr64
   23b5d:	41 0f b7 04 24       	movzx  eax,WORD PTR [r12]
   23b62:	48 8b bd 98 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x168]
   23b69:	4d 8d 74 24 02       	lea    r14,[r12+0x2]
   23b6e:	48 8d 0c c5 00 00 00 	lea    rcx,[rax*8+0x0]
   23b75:	00 
   23b76:	48 8b 04 c7          	mov    rax,QWORD PTR [rdi+rax*8]
   23b7a:	48 8b 40 18          	mov    rax,QWORD PTR [rax+0x18]
   23b7e:	48 8b 10             	mov    rdx,QWORD PTR [rax]
   23b81:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
   23b85:	83 f8 04             	cmp    eax,0x4
   23b88:	0f 84 85 67 00 00    	je     2a313 <JS_CallInternal+0x7833>
   23b8e:	83 f8 f6             	cmp    eax,0xfffffff6
   23b91:	76 04                	jbe    23b97 <JS_CallInternal+0x10b7>
   23b93:	83 42 fc 01          	add    DWORD PTR [rdx-0x4],0x1
   23b97:	48 89 13             	mov    QWORD PTR [rbx],rdx
   23b9a:	48 89 43 08          	mov    QWORD PTR [rbx+0x8],rax
   23b9e:	41 0f b6 44 24 02    	movzx  eax,BYTE PTR [r12+0x2]
   23ba4:	48 83 c3 10          	add    rbx,0x10
   23ba8:	49 83 c4 03          	add    r12,0x3
   23bac:	49 89 c5             	mov    r13,rax
   23baf:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   23bb3:	ff e0                	jmp    rax
   23bb5:	f3 0f 1e fa          	endbr64
   23bb9:	f3 0f 1e fa          	endbr64
   23bbd:	49 8d 44 24 02       	lea    rax,[r12+0x2]
   23bc2:	45 0f b7 14 24       	movzx  r10d,WORD PTR [r12]
   23bc7:	48 89 85 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],rax
   23bce:	e9 e5 f2 ff ff       	jmp    22eb8 <JS_CallInternal+0x3d8>
   23bd3:	f3 0f 1e fa          	endbr64
   23bd7:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   23bde:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   23be5:	44 89 ea             	mov    edx,r13d
   23be8:	48 89 de             	mov    rsi,rbx
   23beb:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   23bef:	e8 5c 0d 03 00       	call   54950 <js_binary_arith_slow>
   23bf4:	85 c0                	test   eax,eax
   23bf6:	0f 85 84 f6 ff ff    	jne    23280 <JS_CallInternal+0x7a0>
   23bfc:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   23c01:	48 83 eb 10          	sub    rbx,0x10
   23c05:	49 83 c4 01          	add    r12,0x1
   23c09:	49 89 c5             	mov    r13,rax
   23c0c:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   23c10:	ff e0                	jmp    rax
   23c12:	f3 0f 1e fa          	endbr64
   23c16:	45 0f b7 0c 24       	movzx  r9d,WORD PTR [r12]
   23c1b:	49 89 de             	mov    r14,rbx
   23c1e:	4d 8d 54 24 02       	lea    r10,[r12+0x2]
   23c23:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   23c2a:	4c 89 95 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],r10
   23c31:	4c 89 c8             	mov    rax,r9
   23c34:	44 89 8d 40 fe ff ff 	mov    DWORD PTR [rbp-0x1c0],r9d
   23c3b:	48 c1 e0 04          	shl    rax,0x4
   23c3f:	49 29 c6             	sub    r14,rax
   23c42:	48 89 85 38 fe ff ff 	mov    QWORD PTR [rbp-0x1c8],rax
   23c49:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   23c50:	4d 8b 46 f8          	mov    r8,QWORD PTR [r14-0x8]
   23c54:	49 8b 4e f0          	mov    rcx,QWORD PTR [r14-0x10]
   23c58:	4d 8d 6e e0          	lea    r13,[r14-0x20]
   23c5c:	49 8b 76 e0          	mov    rsi,QWORD PTR [r14-0x20]
   23c60:	49 8b 55 08          	mov    rdx,QWORD PTR [r13+0x8]
   23c64:	4c 89 50 30          	mov    QWORD PTR [rax+0x30],r10
   23c68:	6a 00                	push   0x0
   23c6a:	41 56                	push   r14
   23c6c:	e8 9f d2 06 00       	call   90f10 <JS_CallConstructorInternal>
   23c71:	41 5b                	pop    r11
   23c73:	4c 8b 95 50 fe ff ff 	mov    r10,QWORD PTR [rbp-0x1b0]
   23c7a:	83 fa 06             	cmp    edx,0x6
   23c7d:	49 89 c1             	mov    r9,rax
   23c80:	49 89 d0             	mov    r8,rdx
   23c83:	58                   	pop    rax
   23c84:	0f 84 29 70 00 00    	je     2acb3 <JS_CallInternal+0x81d3>
   23c8a:	4c 8b 9d 38 fe ff ff 	mov    r11,QWORD PTR [rbp-0x1c8]
   23c91:	4d 01 de             	add    r14,r11
   23c94:	eb 17                	jmp    23cad <JS_CallInternal+0x11cd>
   23c96:	66 2e 0f 1f 84 00 00 	cs nop WORD PTR [rax+rax*1+0x0]
   23c9d:	00 00 00 
   23ca0:	49 83 c5 10          	add    r13,0x10
   23ca4:	4d 39 f5             	cmp    r13,r14
   23ca7:	0f 84 89 53 00 00    	je     29036 <JS_CallInternal+0x6556>
   23cad:	49 8b 55 08          	mov    rdx,QWORD PTR [r13+0x8]
   23cb1:	49 8b 75 00          	mov    rsi,QWORD PTR [r13+0x0]
   23cb5:	83 fa f6             	cmp    edx,0xfffffff6
   23cb8:	76 e6                	jbe    23ca0 <JS_CallInternal+0x11c0>
   23cba:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   23cbd:	83 e8 01             	sub    eax,0x1
   23cc0:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   23cc3:	85 c0                	test   eax,eax
   23cc5:	7f d9                	jg     23ca0 <JS_CallInternal+0x11c0>
   23cc7:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   23cce:	4c 89 85 38 fe ff ff 	mov    QWORD PTR [rbp-0x1c8],r8
   23cd5:	4c 89 8d 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],r9
   23cdc:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   23ce0:	e8 bb 8b ff ff       	call   1c8a0 <__JS_FreeValueRT>
   23ce5:	4c 8b 85 38 fe ff ff 	mov    r8,QWORD PTR [rbp-0x1c8]
   23cec:	4c 8b 8d 50 fe ff ff 	mov    r9,QWORD PTR [rbp-0x1b0]
   23cf3:	eb ab                	jmp    23ca0 <JS_CallInternal+0x11c0>
   23cf5:	f3 0f 1e fa          	endbr64
   23cf9:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   23d00:	4c 8b 43 f8          	mov    r8,QWORD PTR [rbx-0x8]
   23d04:	4c 8d 73 f0          	lea    r14,[rbx-0x10]
   23d08:	48 8b 4b f0          	mov    rcx,QWORD PTR [rbx-0x10]
   23d0c:	48 8b 73 e0          	mov    rsi,QWORD PTR [rbx-0x20]
   23d10:	48 8b 53 e8          	mov    rdx,QWORD PTR [rbx-0x18]
   23d14:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   23d1b:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   23d1f:	e8 4c 51 08 00       	call   a8e70 <js_dynamic_import>
   23d24:	49 89 d0             	mov    r8,rdx
   23d27:	83 fa 06             	cmp    edx,0x6
   23d2a:	0f 84 50 f5 ff ff    	je     23280 <JS_CallInternal+0x7a0>
   23d30:	48 8b 53 e8          	mov    rdx,QWORD PTR [rbx-0x18]
   23d34:	48 8b 73 e0          	mov    rsi,QWORD PTR [rbx-0x20]
   23d38:	83 fa f6             	cmp    edx,0xfffffff6
   23d3b:	76 11                	jbe    23d4e <JS_CallInternal+0x126e>
   23d3d:	8b 4e fc             	mov    ecx,DWORD PTR [rsi-0x4]
   23d40:	83 e9 01             	sub    ecx,0x1
   23d43:	89 4e fc             	mov    DWORD PTR [rsi-0x4],ecx
   23d46:	85 c9                	test   ecx,ecx
   23d48:	0f 8e 2b 6d 00 00    	jle    2aa79 <JS_CallInternal+0x7f99>
   23d4e:	49 8b 56 08          	mov    rdx,QWORD PTR [r14+0x8]
   23d52:	49 8b 36             	mov    rsi,QWORD PTR [r14]
   23d55:	83 fa f6             	cmp    edx,0xfffffff6
   23d58:	76 11                	jbe    23d6b <JS_CallInternal+0x128b>
   23d5a:	8b 4e fc             	mov    ecx,DWORD PTR [rsi-0x4]
   23d5d:	83 e9 01             	sub    ecx,0x1
   23d60:	89 4e fc             	mov    DWORD PTR [rsi-0x4],ecx
   23d63:	85 c9                	test   ecx,ecx
   23d65:	0f 8e 3f 6d 00 00    	jle    2aaaa <JS_CallInternal+0x7fca>
   23d6b:	49 89 46 f0          	mov    QWORD PTR [r14-0x10],rax
   23d6f:	4c 89 f3             	mov    rbx,r14
   23d72:	49 83 c4 01          	add    r12,0x1
   23d76:	4d 89 46 f8          	mov    QWORD PTR [r14-0x8],r8
   23d7a:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   23d80:	49 89 c5             	mov    r13,rax
   23d83:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   23d87:	ff e0                	jmp    rax
   23d89:	f3 0f 1e fa          	endbr64
   23d8d:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   23d94:	48 8b 73 f0          	mov    rsi,QWORD PTR [rbx-0x10]
   23d98:	48 8b 53 f8          	mov    rdx,QWORD PTR [rbx-0x8]
   23d9c:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   23da3:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   23da7:	e8 34 e6 ff ff       	call   223e0 <JS_GetPrototype>
   23dac:	49 89 c6             	mov    r14,rax
   23daf:	48 89 d1             	mov    rcx,rdx
   23db2:	83 fa 06             	cmp    edx,0x6
   23db5:	0f 84 c5 f4 ff ff    	je     23280 <JS_CallInternal+0x7a0>
   23dbb:	48 8b 53 f8          	mov    rdx,QWORD PTR [rbx-0x8]
   23dbf:	48 8b 73 f0          	mov    rsi,QWORD PTR [rbx-0x10]
   23dc3:	83 fa f6             	cmp    edx,0xfffffff6
   23dc6:	76 11                	jbe    23dd9 <JS_CallInternal+0x12f9>
   23dc8:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   23dcb:	83 e8 01             	sub    eax,0x1
   23dce:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   23dd1:	85 c0                	test   eax,eax
   23dd3:	0f 8e 62 6b 00 00    	jle    2a93b <JS_CallInternal+0x7e5b>
   23dd9:	4c 89 73 f0          	mov    QWORD PTR [rbx-0x10],r14
   23ddd:	49 83 c4 01          	add    r12,0x1
   23de1:	48 89 4b f8          	mov    QWORD PTR [rbx-0x8],rcx
   23de5:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   23deb:	49 89 c5             	mov    r13,rax
   23dee:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   23df2:	ff e0                	jmp    rax
   23df4:	f3 0f 1e fa          	endbr64
   23df8:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   23dff:	4d 8d 54 24 02       	lea    r10,[r12+0x2]
   23e04:	48 8b 73 d0          	mov    rsi,QWORD PTR [rbx-0x30]
   23e08:	4c 8d 73 e0          	lea    r14,[rbx-0x20]
   23e0c:	45 0f b7 0c 24       	movzx  r9d,WORD PTR [r12]
   23e11:	48 8b 53 d8          	mov    rdx,QWORD PTR [rbx-0x28]
   23e15:	4d 89 f0             	mov    r8,r14
   23e18:	b9 02 00 00 00       	mov    ecx,0x2
   23e1d:	4c 89 50 30          	mov    QWORD PTR [rax+0x30],r10
   23e21:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   23e28:	4c 89 95 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],r10
   23e2f:	e8 3c d7 07 00       	call   a1570 <js_function_apply>
   23e34:	4c 8b 95 50 fe ff ff 	mov    r10,QWORD PTR [rbp-0x1b0]
   23e3b:	83 fa 06             	cmp    edx,0x6
   23e3e:	49 89 c1             	mov    r9,rax
   23e41:	49 89 d0             	mov    r8,rdx
   23e44:	0f 84 7c 74 00 00    	je     2b2c6 <JS_CallInternal+0x87e6>
   23e4a:	48 8b 53 d8          	mov    rdx,QWORD PTR [rbx-0x28]
   23e4e:	48 8b 73 d0          	mov    rsi,QWORD PTR [rbx-0x30]
   23e52:	83 fa f6             	cmp    edx,0xfffffff6
   23e55:	76 11                	jbe    23e68 <JS_CallInternal+0x1388>
   23e57:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   23e5a:	83 e8 01             	sub    eax,0x1
   23e5d:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   23e60:	85 c0                	test   eax,eax
   23e62:	0f 8e 5c 6a 00 00    	jle    2a8c4 <JS_CallInternal+0x7de4>
   23e68:	49 8b 56 08          	mov    rdx,QWORD PTR [r14+0x8]
   23e6c:	49 8b 36             	mov    rsi,QWORD PTR [r14]
   23e6f:	83 fa f6             	cmp    edx,0xfffffff6
   23e72:	76 11                	jbe    23e85 <JS_CallInternal+0x13a5>
   23e74:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   23e77:	83 e8 01             	sub    eax,0x1
   23e7a:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   23e7d:	85 c0                	test   eax,eax
   23e7f:	0f 8e 70 6a 00 00    	jle    2a8f5 <JS_CallInternal+0x7e15>
   23e85:	48 8b 53 f8          	mov    rdx,QWORD PTR [rbx-0x8]
   23e89:	48 8b 73 f0          	mov    rsi,QWORD PTR [rbx-0x10]
   23e8d:	83 fa f6             	cmp    edx,0xfffffff6
   23e90:	76 11                	jbe    23ea3 <JS_CallInternal+0x13c3>
   23e92:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   23e95:	83 e8 01             	sub    eax,0x1
   23e98:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   23e9b:	85 c0                	test   eax,eax
   23e9d:	0f 8e f0 69 00 00    	jle    2a893 <JS_CallInternal+0x7db3>
   23ea3:	4c 89 4b d0          	mov    QWORD PTR [rbx-0x30],r9
   23ea7:	49 83 c4 03          	add    r12,0x3
   23eab:	4c 89 43 d8          	mov    QWORD PTR [rbx-0x28],r8
   23eaf:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   23eb5:	4c 89 f3             	mov    rbx,r14
   23eb8:	49 89 c5             	mov    r13,rax
   23ebb:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   23ebf:	ff e0                	jmp    rax
   23ec1:	f3 0f 1e fa          	endbr64
   23ec5:	41 0f b7 14 24       	movzx  edx,WORD PTR [r12]
   23eca:	49 8d 4c 24 02       	lea    rcx,[r12+0x2]
   23ecf:	48 89 8d 38 fe ff ff 	mov    QWORD PTR [rbp-0x1c8],rcx
   23ed6:	31 c9                	xor    ecx,ecx
   23ed8:	49 89 d6             	mov    r14,rdx
   23edb:	89 95 50 fe ff ff    	mov    DWORD PTR [rbp-0x1b0],edx
   23ee1:	49 c1 e6 04          	shl    r14,0x4
   23ee5:	48 89 95 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],rdx
   23eec:	ba 02 00 00 00       	mov    edx,0x2
   23ef1:	4c 29 f3             	sub    rbx,r14
   23ef4:	49 89 dd             	mov    r13,rbx
   23ef7:	48 8b 9d e8 fe ff ff 	mov    rbx,QWORD PTR [rbp-0x118]
   23efe:	48 8b 73 30          	mov    rsi,QWORD PTR [rbx+0x30]
   23f02:	48 89 df             	mov    rdi,rbx
   23f05:	83 46 fc 01          	add    DWORD PTR [rsi-0x4],0x1
   23f09:	e8 82 23 02 00       	call   46290 <JS_NewObjectFromShape>
   23f0e:	49 89 c0             	mov    r8,rax
   23f11:	48 89 d1             	mov    rcx,rdx
   23f14:	83 fa 06             	cmp    edx,0x6
   23f17:	0f 84 02 76 00 00    	je     2b51f <JS_CallInternal+0x8a3f>
   23f1d:	8b 95 50 fe ff ff    	mov    edx,DWORD PTR [rbp-0x1b0]
   23f23:	85 d2                	test   edx,edx
   23f25:	0f 85 52 59 00 00    	jne    2987d <JS_CallInternal+0x6d9d>
   23f2b:	4d 89 45 00          	mov    QWORD PTR [r13+0x0],r8
   23f2f:	49 8d 5d 10          	lea    rbx,[r13+0x10]
   23f33:	49 83 c4 03          	add    r12,0x3
   23f37:	49 89 4d 08          	mov    QWORD PTR [r13+0x8],rcx
   23f3b:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   23f41:	49 89 c5             	mov    r13,rax
   23f44:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   23f48:	ff e0                	jmp    rax
   23f4a:	f3 0f 1e fa          	endbr64
   23f4e:	41 8b 04 24          	mov    eax,DWORD PTR [r12]
   23f52:	4c 8b 53 f8          	mov    r10,QWORD PTR [rbx-0x8]
   23f56:	4d 8d 5c 24 04       	lea    r11,[r12+0x4]
   23f5b:	48 8b 73 f0          	mov    rsi,QWORD PTR [rbx-0x10]
   23f5f:	4d 8d 34 04          	lea    r14,[r12+rax*1]
   23f63:	41 83 fa ff          	cmp    r10d,0xffffffff
   23f67:	0f 85 4c 72 00 00    	jne    2b1b9 <JS_CallInternal+0x86d9>
   23f6d:	8b 46 10             	mov    eax,DWORD PTR [rsi+0x10]
   23f70:	4c 8b 6e 18          	mov    r13,QWORD PTR [rsi+0x18]
   23f74:	25 08 00 ff ff       	and    eax,0xffff0008
   23f79:	3d 00 00 01 00       	cmp    eax,0x10000
   23f7e:	0f 84 7e 5f 00 00    	je     29f02 <JS_CallInternal+0x7422>
   23f84:	41 8b 4e 0c          	mov    ecx,DWORD PTR [r14+0xc]
   23f88:	48 89 f7             	mov    rdi,rsi
   23f8b:	0f 1f 44 00 00       	nop    DWORD PTR [rax+rax*1+0x0]
   23f90:	41 8b 45 18          	mov    eax,DWORD PTR [r13+0x18]
   23f94:	89 ca                	mov    edx,ecx
   23f96:	21 c2                	and    edx,eax
   23f98:	41 8b 54 95 38       	mov    edx,DWORD PTR [r13+rdx*4+0x38]
   23f9d:	48 85 d2             	test   rdx,rdx
   23fa0:	0f 84 36 4e 00 00    	je     28ddc <JS_CallInternal+0x62fc>
   23fa6:	4c 8d 04 85 34 00 00 	lea    r8,[rax*4+0x34]
   23fad:	00 
   23fae:	49 8d 04 d0          	lea    rax,[r8+rdx*8]
   23fb2:	4c 01 e8             	add    rax,r13
   23fb5:	3b 48 04             	cmp    ecx,DWORD PTR [rax+0x4]
   23fb8:	0f 85 10 4e 00 00    	jne    28dce <JS_CallInternal+0x62ee>
   23fbe:	80 78 03 3f          	cmp    BYTE PTR [rax+0x3],0x3f
   23fc2:	0f 87 fb 53 00 00    	ja     293c3 <JS_CallInternal+0x68e3>
   23fc8:	48 c1 e2 04          	shl    rdx,0x4
   23fcc:	48 8d 42 f0          	lea    rax,[rdx-0x10]
   23fd0:	48 8b 57 20          	mov    rdx,QWORD PTR [rdi+0x20]
   23fd4:	48 01 c2             	add    rdx,rax
   23fd7:	4c 8b 02             	mov    r8,QWORD PTR [rdx]
   23fda:	48 8b 52 08          	mov    rdx,QWORD PTR [rdx+0x8]
   23fde:	83 fa f6             	cmp    edx,0xfffffff6
   23fe1:	76 05                	jbe    23fe8 <JS_CallInternal+0x1508>
   23fe3:	41 83 40 fc 01       	add    DWORD PTR [r8-0x4],0x1
   23fe8:	48 39 fe             	cmp    rsi,rdi
   23feb:	0f 84 1e 7e 00 00    	je     2be0f <JS_CallInternal+0x932f>
   23ff1:	4c 89 c0             	mov    rax,r8
   23ff4:	48 89 03             	mov    QWORD PTR [rbx],rax
   23ff7:	49 83 c4 05          	add    r12,0x5
   23ffb:	48 83 c3 10          	add    rbx,0x10
   23fff:	48 89 53 f8          	mov    QWORD PTR [rbx-0x8],rdx
   24003:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   24009:	49 89 c5             	mov    r13,rax
   2400c:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   24010:	ff e0                	jmp    rax
   24012:	f3 0f 1e fa          	endbr64
   24016:	41 8b 04 24          	mov    eax,DWORD PTR [r12]
   2401a:	4c 8b 53 f8          	mov    r10,QWORD PTR [rbx-0x8]
   2401e:	48 8b 73 f0          	mov    rsi,QWORD PTR [rbx-0x10]
   24022:	4d 8d 34 04          	lea    r14,[r12+rax*1]
   24026:	49 8d 44 24 04       	lea    rax,[r12+0x4]
   2402b:	48 89 85 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],rax
   24032:	41 83 fa ff          	cmp    r10d,0xffffffff
   24036:	0f 85 9e 6d 00 00    	jne    2adda <JS_CallInternal+0x82fa>
   2403c:	8b 46 10             	mov    eax,DWORD PTR [rsi+0x10]
   2403f:	4c 8b 6e 18          	mov    r13,QWORD PTR [rsi+0x18]
   24043:	25 08 00 ff ff       	and    eax,0xffff0008
   24048:	3d 00 00 01 00       	cmp    eax,0x10000
   2404d:	0f 84 8d 5c 00 00    	je     29ce0 <JS_CallInternal+0x7200>
   24053:	41 8b 4e 0c          	mov    ecx,DWORD PTR [r14+0xc]
   24057:	48 89 f2             	mov    rdx,rsi
   2405a:	66 0f 1f 44 00 00    	nop    WORD PTR [rax+rax*1+0x0]
   24060:	41 8b 45 18          	mov    eax,DWORD PTR [r13+0x18]
   24064:	89 cf                	mov    edi,ecx
   24066:	21 c7                	and    edi,eax
   24068:	41 8b 7c bd 38       	mov    edi,DWORD PTR [r13+rdi*4+0x38]
   2406d:	48 85 ff             	test   rdi,rdi
   24070:	0f 84 38 4d 00 00    	je     28dae <JS_CallInternal+0x62ce>
   24076:	4c 8d 04 85 34 00 00 	lea    r8,[rax*4+0x34]
   2407d:	00 
   2407e:	49 8d 04 f8          	lea    rax,[r8+rdi*8]
   24082:	4c 01 e8             	add    rax,r13
   24085:	3b 48 04             	cmp    ecx,DWORD PTR [rax+0x4]
   24088:	0f 85 12 4d 00 00    	jne    28da0 <JS_CallInternal+0x62c0>
   2408e:	80 78 03 3f          	cmp    BYTE PTR [rax+0x3],0x3f
   24092:	0f 87 c2 52 00 00    	ja     2935a <JS_CallInternal+0x687a>
   24098:	48 89 f9             	mov    rcx,rdi
   2409b:	48 8b 7a 20          	mov    rdi,QWORD PTR [rdx+0x20]
   2409f:	48 c1 e1 04          	shl    rcx,0x4
   240a3:	48 83 e9 10          	sub    rcx,0x10
   240a7:	48 01 cf             	add    rdi,rcx
   240aa:	4c 8b 47 08          	mov    r8,QWORD PTR [rdi+0x8]
   240ae:	48 8b 07             	mov    rax,QWORD PTR [rdi]
   240b1:	41 83 f8 f6          	cmp    r8d,0xfffffff6
   240b5:	76 04                	jbe    240bb <JS_CallInternal+0x15db>
   240b7:	83 40 fc 01          	add    DWORD PTR [rax-0x4],0x1
   240bb:	4c 8d 5b f0          	lea    r11,[rbx-0x10]
   240bf:	48 39 f2             	cmp    rdx,rsi
   240c2:	0f 84 56 7c 00 00    	je     2bd1e <JS_CallInternal+0x923e>
   240c8:	49 89 c5             	mov    r13,rax
   240cb:	49 8b 53 08          	mov    rdx,QWORD PTR [r11+0x8]
   240cf:	49 8b 33             	mov    rsi,QWORD PTR [r11]
   240d2:	83 fa f6             	cmp    edx,0xfffffff6
   240d5:	76 11                	jbe    240e8 <JS_CallInternal+0x1608>
   240d7:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   240da:	83 e8 01             	sub    eax,0x1
   240dd:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   240e0:	85 c0                	test   eax,eax
   240e2:	0f 8e 73 6b 00 00    	jle    2ac5b <JS_CallInternal+0x817b>
   240e8:	4c 89 6b f0          	mov    QWORD PTR [rbx-0x10],r13
   240ec:	49 83 c4 05          	add    r12,0x5
   240f0:	4c 89 43 f8          	mov    QWORD PTR [rbx-0x8],r8
   240f4:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   240fa:	49 89 c5             	mov    r13,rax
   240fd:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   24101:	ff e0                	jmp    rax
   24103:	f3 0f 1e fa          	endbr64
   24107:	48 8b 43 e0          	mov    rax,QWORD PTR [rbx-0x20]
   2410b:	4c 8d 6b e0          	lea    r13,[rbx-0x20]
   2410f:	4c 8d 73 f0          	lea    r14,[rbx-0x10]
   24113:	48 8b 4b f0          	mov    rcx,QWORD PTR [rbx-0x10]
   24117:	49 8b 5e 08          	mov    rbx,QWORD PTR [r14+0x8]
   2411b:	48 89 85 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],rax
   24122:	49 8b 45 08          	mov    rax,QWORD PTR [r13+0x8]
   24126:	48 89 8d 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],rcx
   2412d:	48 89 85 38 fe ff ff 	mov    QWORD PTR [rbp-0x1c8],rax
   24134:	83 fb f9             	cmp    ebx,0xfffffff9
   24137:	0f 85 d3 5f 00 00    	jne    2a110 <JS_CallInternal+0x7630>
   2413d:	83 f8 f9             	cmp    eax,0xfffffff9
   24140:	0f 85 ca 5f 00 00    	jne    2a110 <JS_CallInternal+0x7630>
   24146:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2414d:	ba 12 00 00 00       	mov    edx,0x12
   24152:	48 8d 8d 50 ff ff ff 	lea    rcx,[rbp-0xb0]
   24159:	48 c7 85 50 ff ff ff 	mov    QWORD PTR [rbp-0xb0],0x0
   24160:	00 00 00 00 
   24164:	48 c7 85 58 ff ff ff 	mov    QWORD PTR [rbp-0xa8],0x0
   2416b:	00 00 00 00 
   2416f:	48 8b 77 48          	mov    rsi,QWORD PTR [rdi+0x48]
   24173:	83 46 fc 01          	add    DWORD PTR [rsi-0x4],0x1
   24177:	e8 14 21 02 00       	call   46290 <JS_NewObjectFromShape>
   2417c:	83 fa 06             	cmp    edx,0x6
   2417f:	0f 84 a0 5f 00 00    	je     2a125 <JS_CallInternal+0x7645>
   24185:	f3 0f 7e 85 40 fe ff 	movq   xmm0,QWORD PTR [rbp-0x1c0]
   2418c:	ff 
   2418d:	0f 16 85 50 fe ff ff 	movhps xmm0,QWORD PTR [rbp-0x1b0]
   24194:	0f 11 40 28          	movups XMMWORD PTR [rax+0x28],xmm0
   24198:	49 89 45 00          	mov    QWORD PTR [r13+0x0],rax
   2419c:	49 89 55 08          	mov    QWORD PTR [r13+0x8],rdx
   241a0:	41 83 7e f8 06       	cmp    DWORD PTR [r14-0x8],0x6
   241a5:	0f 84 27 6c 00 00    	je     2add2 <JS_CallInternal+0x82f2>
   241ab:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   241b0:	4c 89 f3             	mov    rbx,r14
   241b3:	49 83 c4 01          	add    r12,0x1
   241b7:	49 89 c5             	mov    r13,rax
   241ba:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   241be:	ff e0                	jmp    rax
   241c0:	f3 0f 1e fa          	endbr64
   241c4:	41 0f b7 04 24       	movzx  eax,WORD PTR [r12]
   241c9:	48 8b 53 f0          	mov    rdx,QWORD PTR [rbx-0x10]
   241cd:	48 8d b5 f0 fe ff ff 	lea    rsi,[rbp-0x110]
   241d4:	48 8b 8d c8 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x138]
   241db:	4c 8b ad e8 fe ff ff 	mov    r13,QWORD PTR [rbp-0x118]
   241e2:	66 89 85 38 fe ff ff 	mov    WORD PTR [rbp-0x1c8],ax
   241e9:	49 8d 44 24 02       	lea    rax,[r12+0x2]
   241ee:	48 89 41 30          	mov    QWORD PTR [rcx+0x30],rax
   241f2:	48 8b 4b f8          	mov    rcx,QWORD PTR [rbx-0x8]
   241f6:	4c 89 ef             	mov    rdi,r13
   241f9:	48 89 85 10 fe ff ff 	mov    QWORD PTR [rbp-0x1f0],rax
   24200:	48 8d 43 f0          	lea    rax,[rbx-0x10]
   24204:	48 89 85 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],rax
   2420b:	e8 60 07 06 00       	call   84970 <build_arg_list>
   24210:	49 89 c6             	mov    r14,rax
   24213:	48 85 c0             	test   rax,rax
   24216:	0f 84 fd 67 00 00    	je     2aa19 <JS_CallInternal+0x7f39>
   2421c:	f3 41 0f 6f 9d 70 01 	movdqu xmm3,XMMWORD PTR [r13+0x170]
   24223:	00 00 
   24225:	48 8b 43 e0          	mov    rax,QWORD PTR [rbx-0x20]
   24229:	41 b8 01 00 00 00    	mov    r8d,0x1
   2422f:	4c 8b 6b e8          	mov    r13,QWORD PTR [rbx-0x18]
   24233:	0f 29 9d 40 fe ff ff 	movaps XMMWORD PTR [rbp-0x1c0],xmm3
   2423a:	48 8b 95 40 fe ff ff 	mov    rdx,QWORD PTR [rbp-0x1c0]
   24241:	48 89 c7             	mov    rdi,rax
   24244:	48 8b 8d 48 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x1b8]
   2424b:	4c 89 ee             	mov    rsi,r13
   2424e:	48 89 85 28 fe ff ff 	mov    QWORD PTR [rbp-0x1d8],rax
   24255:	e8 76 62 ff ff       	call   1a4d0 <js_strict_eq2.isra.0>
   2425a:	44 8b 95 f0 fe ff ff 	mov    r10d,DWORD PTR [rbp-0x110]
   24261:	85 c0                	test   eax,eax
   24263:	0f 84 e4 59 00 00    	je     29c4d <JS_CallInternal+0x716d>
   24269:	45 85 d2             	test   r10d,r10d
   2426c:	0f 84 a6 59 00 00    	je     29c18 <JS_CallInternal+0x7138>
   24272:	49 8b 0e             	mov    rcx,QWORD PTR [r14]
   24275:	4d 8b 46 08          	mov    r8,QWORD PTR [r14+0x8]
   24279:	0f b7 85 38 fe ff ff 	movzx  eax,WORD PTR [rbp-0x1c8]
   24280:	48 83 ec 08          	sub    rsp,0x8
   24284:	31 f6                	xor    esi,esi
   24286:	44 89 95 28 fe ff ff 	mov    DWORD PTR [rbp-0x1d8],r10d
   2428d:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   24294:	41 b9 02 00 00 00    	mov    r9d,0x2
   2429a:	ba 03 00 00 00       	mov    edx,0x3
   2429f:	83 e8 02             	sub    eax,0x2
   242a2:	50                   	push   rax
   242a3:	e8 28 e1 01 00       	call   423d0 <JS_EvalObject>
   242a8:	44 8b 95 28 fe ff ff 	mov    r10d,DWORD PTR [rbp-0x1d8]
   242af:	48 89 85 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],rax
   242b6:	49 89 d5             	mov    r13,rdx
   242b9:	58                   	pop    rax
   242ba:	5a                   	pop    rdx
   242bb:	45 85 d2             	test   r10d,r10d
   242be:	0f 84 cb 6a 00 00    	je     2ad8f <JS_CallInternal+0x82af>
   242c4:	45 89 d0             	mov    r8d,r10d
   242c7:	48 8b 8d e8 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x118]
   242ce:	48 89 9d 38 fe ff ff 	mov    QWORD PTR [rbp-0x1c8],rbx
   242d5:	4c 89 f3             	mov    rbx,r14
   242d8:	49 c1 e0 04          	shl    r8,0x4
   242dc:	4c 89 a5 28 fe ff ff 	mov    QWORD PTR [rbp-0x1d8],r12
   242e3:	4d 01 f0             	add    r8,r14
   242e6:	48 8b 79 10          	mov    rdi,QWORD PTR [rcx+0x10]
   242ea:	4d 89 c4             	mov    r12,r8
   242ed:	eb 0e                	jmp    242fd <JS_CallInternal+0x181d>
   242ef:	90                   	nop
   242f0:	48 83 c3 10          	add    rbx,0x10
   242f4:	4c 39 e3             	cmp    rbx,r12
   242f7:	0f 84 9f 4d 00 00    	je     2909c <JS_CallInternal+0x65bc>
   242fd:	48 8b 4b 08          	mov    rcx,QWORD PTR [rbx+0x8]
   24301:	48 8b 33             	mov    rsi,QWORD PTR [rbx]
   24304:	83 f9 f6             	cmp    ecx,0xfffffff6
   24307:	76 e7                	jbe    242f0 <JS_CallInternal+0x1810>
   24309:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   2430c:	8d 50 ff             	lea    edx,[rax-0x1]
   2430f:	89 56 fc             	mov    DWORD PTR [rsi-0x4],edx
   24312:	85 d2                	test   edx,edx
   24314:	7f da                	jg     242f0 <JS_CallInternal+0x1810>
   24316:	48 89 ca             	mov    rdx,rcx
   24319:	e8 82 85 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2431e:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   24325:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   24329:	eb c5                	jmp    242f0 <JS_CallInternal+0x1810>
   2432b:	f3 0f 1e fa          	endbr64
   2432f:	41 0f b7 0c 24       	movzx  ecx,WORD PTR [r12]
   24334:	49 89 dd             	mov    r13,rbx
   24337:	41 0f b7 7c 24 02    	movzx  edi,WORD PTR [r12+0x2]
   2433d:	41 b8 01 00 00 00    	mov    r8d,0x1
   24343:	48 89 c8             	mov    rax,rcx
   24346:	89 8d 50 fe ff ff    	mov    DWORD PTR [rbp-0x1b0],ecx
   2434c:	49 8d 4c 24 04       	lea    rcx,[r12+0x4]
   24351:	48 c1 e0 04          	shl    rax,0x4
   24355:	66 89 bd 38 fe ff ff 	mov    WORD PTR [rbp-0x1c8],di
   2435c:	49 29 c5             	sub    r13,rax
   2435f:	49 89 c6             	mov    r14,rax
   24362:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   24369:	48 89 8d 28 fe ff ff 	mov    QWORD PTR [rbp-0x1d8],rcx
   24370:	49 8b 7d f0          	mov    rdi,QWORD PTR [r13-0x10]
   24374:	49 8b 75 f8          	mov    rsi,QWORD PTR [r13-0x8]
   24378:	48 89 48 30          	mov    QWORD PTR [rax+0x30],rcx
   2437c:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   24383:	f3 0f 6f b8 70 01 00 	movdqu xmm7,XMMWORD PTR [rax+0x170]
   2438a:	00 
   2438b:	0f 29 bd 40 fe ff ff 	movaps XMMWORD PTR [rbp-0x1c0],xmm7
   24392:	48 8b 95 40 fe ff ff 	mov    rdx,QWORD PTR [rbp-0x1c0]
   24399:	48 8b 8d 48 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x1b8]
   243a0:	e8 2b 61 ff ff       	call   1a4d0 <js_strict_eq2.isra.0>
   243a5:	85 c0                	test   eax,eax
   243a7:	0f 84 13 58 00 00    	je     29bc0 <JS_CallInternal+0x70e0>
   243ad:	8b bd 50 fe ff ff    	mov    edi,DWORD PTR [rbp-0x1b0]
   243b3:	85 ff                	test   edi,edi
   243b5:	0f 84 ee 56 00 00    	je     29aa9 <JS_CallInternal+0x6fc9>
   243bb:	49 8b 4d 00          	mov    rcx,QWORD PTR [r13+0x0]
   243bf:	4d 8b 45 08          	mov    r8,QWORD PTR [r13+0x8]
   243c3:	0f b7 85 38 fe ff ff 	movzx  eax,WORD PTR [rbp-0x1c8]
   243ca:	48 83 ec 08          	sub    rsp,0x8
   243ce:	41 b9 02 00 00 00    	mov    r9d,0x2
   243d4:	31 f6                	xor    esi,esi
   243d6:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   243dd:	ba 03 00 00 00       	mov    edx,0x3
   243e2:	83 e8 02             	sub    eax,0x2
   243e5:	50                   	push   rax
   243e6:	e8 e5 df 01 00       	call   423d0 <JS_EvalObject>
   243eb:	59                   	pop    rcx
   243ec:	5e                   	pop    rsi
   243ed:	49 89 c1             	mov    r9,rax
   243f0:	49 89 d0             	mov    r8,rdx
   243f3:	49 8d 45 f0          	lea    rax,[r13-0x10]
   243f7:	4d 01 f5             	add    r13,r14
   243fa:	49 89 c6             	mov    r14,rax
   243fd:	41 83 f8 06          	cmp    r8d,0x6
   24401:	75 1a                	jne    2441d <JS_CallInternal+0x193d>
   24403:	e9 b3 68 00 00       	jmp    2acbb <JS_CallInternal+0x81db>
   24408:	0f 1f 84 00 00 00 00 	nop    DWORD PTR [rax+rax*1+0x0]
   2440f:	00 
   24410:	49 83 c6 10          	add    r14,0x10
   24414:	4d 39 ee             	cmp    r14,r13
   24417:	0f 84 4c 4c 00 00    	je     29069 <JS_CallInternal+0x6589>
   2441d:	49 8b 56 08          	mov    rdx,QWORD PTR [r14+0x8]
   24421:	49 8b 36             	mov    rsi,QWORD PTR [r14]
   24424:	83 fa f6             	cmp    edx,0xfffffff6
   24427:	76 e7                	jbe    24410 <JS_CallInternal+0x1930>
   24429:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   2442c:	83 e8 01             	sub    eax,0x1
   2442f:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   24432:	85 c0                	test   eax,eax
   24434:	7f da                	jg     24410 <JS_CallInternal+0x1930>
   24436:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2443d:	4c 89 85 38 fe ff ff 	mov    QWORD PTR [rbp-0x1c8],r8
   24444:	4c 89 8d 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],r9
   2444b:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2444f:	e8 4c 84 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   24454:	4c 8b 85 38 fe ff ff 	mov    r8,QWORD PTR [rbp-0x1c8]
   2445b:	4c 8b 8d 40 fe ff ff 	mov    r9,QWORD PTR [rbp-0x1c0]
   24462:	eb ac                	jmp    24410 <JS_CallInternal+0x1930>
   24464:	f3 0f 1e fa          	endbr64
   24468:	41 0f b6 44 24 04    	movzx  eax,BYTE PTR [r12+0x4]
   2446e:	41 8b 34 24          	mov    esi,DWORD PTR [r12]
   24472:	49 83 c4 05          	add    r12,0x5
   24476:	3c 04                	cmp    al,0x4
   24478:	0f 87 96 5f 00 00    	ja     2a414 <JS_CallInternal+0x7934>
   2447e:	48 8d 15 9f 2c 0b 00 	lea    rdx,[rip+0xb2c9f]        # d7124 <qjsc_repl_size+0x458>
   24485:	48 63 04 82          	movsxd rax,DWORD PTR [rdx+rax*4]
   24489:	48 01 d0             	add    rax,rdx
   2448c:	3e ff e0             	notrack jmp rax
   2448f:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   24496:	48 8d 35 b3 c8 0a 00 	lea    rsi,[rip+0xac8b3]        # d0d50 <_IO_stdin_used+0x3d50>
   2449d:	31 c0                	xor    eax,eax
   2449f:	e8 6c e8 00 00       	call   32d10 <JS_ThrowReferenceError>
   244a4:	e9 d7 ed ff ff       	jmp    23280 <JS_CallInternal+0x7a0>
   244a9:	48 8d 15 ea 8f 0a 00 	lea    rdx,[rip+0xa8fea]        # cd49a <_IO_stdin_used+0x49a>
   244b0:	85 f6                	test   esi,esi
   244b2:	0f 85 bb 7c 00 00    	jne    2c173 <JS_CallInternal+0x9693>
   244b8:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   244bf:	48 8d 35 30 90 0a 00 	lea    rsi,[rip+0xa9030]        # cd4f6 <_IO_stdin_used+0x4f6>
   244c6:	31 c0                	xor    eax,eax
   244c8:	e8 43 e8 00 00       	call   32d10 <JS_ThrowReferenceError>
   244cd:	e9 ae ed ff ff       	jmp    23280 <JS_CallInternal+0x7a0>
   244d2:	4c 8b b5 e8 fe ff ff 	mov    r14,QWORD PTR [rbp-0x118]
   244d9:	48 8d 45 80          	lea    rax,[rbp-0x80]
   244dd:	89 f2                	mov    edx,esi
   244df:	48 89 c6             	mov    rsi,rax
   244e2:	49 8b 7e 10          	mov    rdi,QWORD PTR [r14+0x10]
   244e6:	e8 25 2e ff ff       	call   17310 <JS_AtomGetStrRT.constprop.0>
   244eb:	48 8d 35 ee 8f 0a 00 	lea    rsi,[rip+0xa8fee]        # cd4e0 <_IO_stdin_used+0x4e0>
   244f2:	4c 89 f7             	mov    rdi,r14
   244f5:	48 89 c2             	mov    rdx,rax
   244f8:	31 c0                	xor    eax,eax
   244fa:	e8 01 c3 00 00       	call   30800 <JS_ThrowSyntaxError>
   244ff:	e9 7c ed ff ff       	jmp    23280 <JS_CallInternal+0x7a0>
   24504:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2450b:	48 8d 35 66 c8 0a 00 	lea    rsi,[rip+0xac866]        # d0d78 <_IO_stdin_used+0x3d78>
   24512:	31 c0                	xor    eax,eax
   24514:	e8 07 c7 00 00       	call   30c20 <JS_ThrowTypeError>
   24519:	e9 62 ed ff ff       	jmp    23280 <JS_CallInternal+0x7a0>
   2451e:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   24525:	e8 b6 db 00 00       	call   320e0 <JS_ThrowTypeErrorReadOnly.part.0>
   2452a:	e9 51 ed ff ff       	jmp    23280 <JS_CallInternal+0x7a0>
   2452f:	f3 0f 1e fa          	endbr64
   24533:	48 8b 53 f8          	mov    rdx,QWORD PTR [rbx-0x8]
   24537:	41 0f b7 04 24       	movzx  eax,WORD PTR [r12]
   2453c:	48 8b 4b f0          	mov    rcx,QWORD PTR [rbx-0x10]
   24540:	83 fa f6             	cmp    edx,0xfffffff6
   24543:	76 04                	jbe    24549 <JS_CallInternal+0x1a69>
   24545:	83 41 fc 01          	add    DWORD PTR [rcx-0x4],0x1
   24549:	48 8b bd 90 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x170]
   24550:	48 c1 e0 04          	shl    rax,0x4
   24554:	48 01 f8             	add    rax,rdi
   24557:	4c 8b 40 08          	mov    r8,QWORD PTR [rax+0x8]
   2455b:	48 8b 30             	mov    rsi,QWORD PTR [rax]
   2455e:	48 89 50 08          	mov    QWORD PTR [rax+0x8],rdx
   24562:	48 89 08             	mov    QWORD PTR [rax],rcx
   24565:	41 83 f8 f6          	cmp    r8d,0xfffffff6
   24569:	76 11                	jbe    2457c <JS_CallInternal+0x1a9c>
   2456b:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   2456e:	83 e8 01             	sub    eax,0x1
   24571:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   24574:	85 c0                	test   eax,eax
   24576:	0f 8e f1 61 00 00    	jle    2a76d <JS_CallInternal+0x7c8d>
   2457c:	41 0f b6 44 24 02    	movzx  eax,BYTE PTR [r12+0x2]
   24582:	49 83 c4 03          	add    r12,0x3
   24586:	49 89 c5             	mov    r13,rax
   24589:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   2458d:	ff e0                	jmp    rax
   2458f:	f3 0f 1e fa          	endbr64
   24593:	41 0f b7 04 24       	movzx  eax,WORD PTR [r12]
   24598:	48 8b 8d 90 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x170]
   2459f:	f3 0f 6f 63 f0       	movdqu xmm4,XMMWORD PTR [rbx-0x10]
   245a4:	48 c1 e0 04          	shl    rax,0x4
   245a8:	48 01 c8             	add    rax,rcx
   245ab:	48 8b 50 08          	mov    rdx,QWORD PTR [rax+0x8]
   245af:	48 8b 30             	mov    rsi,QWORD PTR [rax]
   245b2:	0f 11 20             	movups XMMWORD PTR [rax],xmm4
   245b5:	83 fa f6             	cmp    edx,0xfffffff6
   245b8:	76 11                	jbe    245cb <JS_CallInternal+0x1aeb>
   245ba:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   245bd:	83 e8 01             	sub    eax,0x1
   245c0:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   245c3:	85 c0                	test   eax,eax
   245c5:	0f 8e ba 61 00 00    	jle    2a785 <JS_CallInternal+0x7ca5>
   245cb:	41 0f b6 44 24 02    	movzx  eax,BYTE PTR [r12+0x2]
   245d1:	48 83 eb 10          	sub    rbx,0x10
   245d5:	49 83 c4 03          	add    r12,0x3
   245d9:	49 89 c5             	mov    r13,rax
   245dc:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   245e0:	ff e0                	jmp    rax
   245e2:	f3 0f 1e fa          	endbr64
   245e6:	41 0f b7 04 24       	movzx  eax,WORD PTR [r12]
   245eb:	48 8b 8d 90 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x170]
   245f2:	48 c1 e0 04          	shl    rax,0x4
   245f6:	48 01 c8             	add    rax,rcx
   245f9:	48 8b 10             	mov    rdx,QWORD PTR [rax]
   245fc:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
   24600:	83 f8 f6             	cmp    eax,0xfffffff6
   24603:	76 04                	jbe    24609 <JS_CallInternal+0x1b29>
   24605:	83 42 fc 01          	add    DWORD PTR [rdx-0x4],0x1
   24609:	48 89 13             	mov    QWORD PTR [rbx],rdx
   2460c:	49 83 c4 03          	add    r12,0x3
   24610:	48 83 c3 10          	add    rbx,0x10
   24614:	48 89 43 f8          	mov    QWORD PTR [rbx-0x8],rax
   24618:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   2461e:	49 89 c5             	mov    r13,rax
   24621:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   24625:	ff e0                	jmp    rax
   24627:	f3 0f 1e fa          	endbr64
   2462b:	48 8b 53 f8          	mov    rdx,QWORD PTR [rbx-0x8]
   2462f:	41 0f b7 04 24       	movzx  eax,WORD PTR [r12]
   24634:	48 8b 4b f0          	mov    rcx,QWORD PTR [rbx-0x10]
   24638:	83 fa f6             	cmp    edx,0xfffffff6
   2463b:	76 04                	jbe    24641 <JS_CallInternal+0x1b61>
   2463d:	83 41 fc 01          	add    DWORD PTR [rcx-0x4],0x1
   24641:	48 8b bd b0 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x150]
   24648:	48 c1 e0 04          	shl    rax,0x4
   2464c:	48 01 f8             	add    rax,rdi
   2464f:	4c 8b 40 08          	mov    r8,QWORD PTR [rax+0x8]
   24653:	48 8b 30             	mov    rsi,QWORD PTR [rax]
   24656:	48 89 50 08          	mov    QWORD PTR [rax+0x8],rdx
   2465a:	48 89 08             	mov    QWORD PTR [rax],rcx
   2465d:	41 83 f8 f6          	cmp    r8d,0xfffffff6
   24661:	76 11                	jbe    24674 <JS_CallInternal+0x1b94>
   24663:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   24666:	83 e8 01             	sub    eax,0x1
   24669:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   2466c:	85 c0                	test   eax,eax
   2466e:	0f 8e aa 61 00 00    	jle    2a81e <JS_CallInternal+0x7d3e>
   24674:	41 0f b6 44 24 02    	movzx  eax,BYTE PTR [r12+0x2]
   2467a:	49 83 c4 03          	add    r12,0x3
   2467e:	49 89 c5             	mov    r13,rax
   24681:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   24685:	ff e0                	jmp    rax
   24687:	f3 0f 1e fa          	endbr64
   2468b:	41 0f b7 04 24       	movzx  eax,WORD PTR [r12]
   24690:	48 8b 8d b0 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x150]
   24697:	f3 0f 6f 4b f0       	movdqu xmm1,XMMWORD PTR [rbx-0x10]
   2469c:	48 c1 e0 04          	shl    rax,0x4
   246a0:	48 01 c8             	add    rax,rcx
   246a3:	48 8b 50 08          	mov    rdx,QWORD PTR [rax+0x8]
   246a7:	48 8b 30             	mov    rsi,QWORD PTR [rax]
   246aa:	0f 11 08             	movups XMMWORD PTR [rax],xmm1
   246ad:	83 fa f6             	cmp    edx,0xfffffff6
   246b0:	76 11                	jbe    246c3 <JS_CallInternal+0x1be3>
   246b2:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   246b5:	83 e8 01             	sub    eax,0x1
   246b8:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   246bb:	85 c0                	test   eax,eax
   246bd:	0f 8e 46 61 00 00    	jle    2a809 <JS_CallInternal+0x7d29>
   246c3:	41 0f b6 44 24 02    	movzx  eax,BYTE PTR [r12+0x2]
   246c9:	48 83 eb 10          	sub    rbx,0x10
   246cd:	49 83 c4 03          	add    r12,0x3
   246d1:	49 89 c5             	mov    r13,rax
   246d4:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   246d8:	ff e0                	jmp    rax
   246da:	f3 0f 1e fa          	endbr64
   246de:	41 0f b7 04 24       	movzx  eax,WORD PTR [r12]
   246e3:	48 8b 8d b0 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x150]
   246ea:	48 c1 e0 04          	shl    rax,0x4
   246ee:	48 01 c8             	add    rax,rcx
   246f1:	48 8b 10             	mov    rdx,QWORD PTR [rax]
   246f4:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
   246f8:	83 f8 f6             	cmp    eax,0xfffffff6
   246fb:	76 04                	jbe    24701 <JS_CallInternal+0x1c21>
   246fd:	83 42 fc 01          	add    DWORD PTR [rdx-0x4],0x1
   24701:	48 89 13             	mov    QWORD PTR [rbx],rdx
   24704:	49 83 c4 03          	add    r12,0x3
   24708:	48 83 c3 10          	add    rbx,0x10
   2470c:	48 89 43 f8          	mov    QWORD PTR [rbx-0x8],rax
   24710:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   24716:	49 89 c5             	mov    r13,rax
   24719:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   2471d:	ff e0                	jmp    rax
   2471f:	f3 0f 1e fa          	endbr64
   24723:	48 8b 85 90 fe ff ff 	mov    rax,QWORD PTR [rbp-0x170]
   2472a:	48 8d 4b 10          	lea    rcx,[rbx+0x10]
   2472e:	48 8b 10             	mov    rdx,QWORD PTR [rax]
   24731:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
   24735:	83 f8 f6             	cmp    eax,0xfffffff6
   24738:	76 04                	jbe    2473e <JS_CallInternal+0x1c5e>
   2473a:	83 42 fc 01          	add    DWORD PTR [rdx-0x4],0x1
   2473e:	48 89 13             	mov    QWORD PTR [rbx],rdx
   24741:	49 83 c4 01          	add    r12,0x1
   24745:	48 89 43 08          	mov    QWORD PTR [rbx+0x8],rax
   24749:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   2474f:	48 89 cb             	mov    rbx,rcx
   24752:	49 89 c5             	mov    r13,rax
   24755:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   24759:	ff e0                	jmp    rax
   2475b:	f3 0f 1e fa          	endbr64
   2475f:	48 8b 43 f8          	mov    rax,QWORD PTR [rbx-0x8]
   24763:	48 8b 53 f0          	mov    rdx,QWORD PTR [rbx-0x10]
   24767:	83 f8 f6             	cmp    eax,0xfffffff6
   2476a:	76 04                	jbe    24770 <JS_CallInternal+0x1c90>
   2476c:	83 42 fc 01          	add    DWORD PTR [rdx-0x4],0x1
   24770:	48 8b bd b0 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x150]
   24777:	48 8b 4f 38          	mov    rcx,QWORD PTR [rdi+0x38]
   2477b:	48 8b 77 30          	mov    rsi,QWORD PTR [rdi+0x30]
   2477f:	48 89 47 38          	mov    QWORD PTR [rdi+0x38],rax
   24783:	48 89 57 30          	mov    QWORD PTR [rdi+0x30],rdx
   24787:	83 f9 f6             	cmp    ecx,0xfffffff6
   2478a:	76 11                	jbe    2479d <JS_CallInternal+0x1cbd>
   2478c:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   2478f:	83 e8 01             	sub    eax,0x1
   24792:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   24795:	85 c0                	test   eax,eax
   24797:	0f 8e 54 60 00 00    	jle    2a7f1 <JS_CallInternal+0x7d11>
   2479d:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   247a2:	49 83 c4 01          	add    r12,0x1
   247a6:	49 89 c5             	mov    r13,rax
   247a9:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   247ad:	ff e0                	jmp    rax
   247af:	f3 0f 1e fa          	endbr64
   247b3:	48 8b 43 f8          	mov    rax,QWORD PTR [rbx-0x8]
   247b7:	48 8b 53 f0          	mov    rdx,QWORD PTR [rbx-0x10]
   247bb:	83 f8 f6             	cmp    eax,0xfffffff6
   247be:	76 04                	jbe    247c4 <JS_CallInternal+0x1ce4>
   247c0:	83 42 fc 01          	add    DWORD PTR [rdx-0x4],0x1
   247c4:	48 8b bd b0 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x150]
   247cb:	48 8b 4f 28          	mov    rcx,QWORD PTR [rdi+0x28]
   247cf:	48 8b 77 20          	mov    rsi,QWORD PTR [rdi+0x20]
   247d3:	48 89 47 28          	mov    QWORD PTR [rdi+0x28],rax
   247d7:	48 89 57 20          	mov    QWORD PTR [rdi+0x20],rdx
   247db:	83 f9 f6             	cmp    ecx,0xfffffff6
   247de:	76 11                	jbe    247f1 <JS_CallInternal+0x1d11>
   247e0:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   247e3:	83 e8 01             	sub    eax,0x1
   247e6:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   247e9:	85 c0                	test   eax,eax
   247eb:	0f 8e 72 60 00 00    	jle    2a863 <JS_CallInternal+0x7d83>
   247f1:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   247f6:	49 83 c4 01          	add    r12,0x1
   247fa:	49 89 c5             	mov    r13,rax
   247fd:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   24801:	ff e0                	jmp    rax
   24803:	f3 0f 1e fa          	endbr64
   24807:	48 8b 43 f8          	mov    rax,QWORD PTR [rbx-0x8]
   2480b:	48 8b 53 f0          	mov    rdx,QWORD PTR [rbx-0x10]
   2480f:	83 f8 f6             	cmp    eax,0xfffffff6
   24812:	76 04                	jbe    24818 <JS_CallInternal+0x1d38>
   24814:	83 42 fc 01          	add    DWORD PTR [rdx-0x4],0x1
   24818:	48 8b bd b0 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x150]
   2481f:	48 8b 4f 18          	mov    rcx,QWORD PTR [rdi+0x18]
   24823:	48 8b 77 10          	mov    rsi,QWORD PTR [rdi+0x10]
   24827:	48 89 47 18          	mov    QWORD PTR [rdi+0x18],rax
   2482b:	48 89 57 10          	mov    QWORD PTR [rdi+0x10],rdx
   2482f:	83 f9 f6             	cmp    ecx,0xfffffff6
   24832:	76 11                	jbe    24845 <JS_CallInternal+0x1d65>
   24834:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   24837:	83 e8 01             	sub    eax,0x1
   2483a:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   2483d:	85 c0                	test   eax,eax
   2483f:	0f 8e 36 60 00 00    	jle    2a87b <JS_CallInternal+0x7d9b>
   24845:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   2484a:	49 83 c4 01          	add    r12,0x1
   2484e:	49 89 c5             	mov    r13,rax
   24851:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   24855:	ff e0                	jmp    rax
   24857:	f3 0f 1e fa          	endbr64
   2485b:	48 8b 43 f8          	mov    rax,QWORD PTR [rbx-0x8]
   2485f:	48 8b 53 f0          	mov    rdx,QWORD PTR [rbx-0x10]
   24863:	83 f8 f6             	cmp    eax,0xfffffff6
   24866:	76 04                	jbe    2486c <JS_CallInternal+0x1d8c>
   24868:	83 42 fc 01          	add    DWORD PTR [rdx-0x4],0x1
   2486c:	48 8b bd b0 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x150]
   24873:	48 8b 4f 08          	mov    rcx,QWORD PTR [rdi+0x8]
   24877:	48 8b 37             	mov    rsi,QWORD PTR [rdi]
   2487a:	48 89 47 08          	mov    QWORD PTR [rdi+0x8],rax
   2487e:	48 89 17             	mov    QWORD PTR [rdi],rdx
   24881:	83 f9 f6             	cmp    ecx,0xfffffff6
   24884:	76 11                	jbe    24897 <JS_CallInternal+0x1db7>
   24886:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   24889:	83 e8 01             	sub    eax,0x1
   2488c:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   2488f:	85 c0                	test   eax,eax
   24891:	0f 8e 9f 5f 00 00    	jle    2a836 <JS_CallInternal+0x7d56>
   24897:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   2489c:	49 83 c4 01          	add    r12,0x1
   248a0:	49 89 c5             	mov    r13,rax
   248a3:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   248a7:	ff e0                	jmp    rax
   248a9:	f3 0f 1e fa          	endbr64
   248ad:	48 8b 85 b0 fe ff ff 	mov    rax,QWORD PTR [rbp-0x150]
   248b4:	f3 0f 6f 5b f0       	movdqu xmm3,XMMWORD PTR [rbx-0x10]
   248b9:	48 83 eb 10          	sub    rbx,0x10
   248bd:	48 8b 50 38          	mov    rdx,QWORD PTR [rax+0x38]
   248c1:	48 8b 70 30          	mov    rsi,QWORD PTR [rax+0x30]
   248c5:	0f 11 58 30          	movups XMMWORD PTR [rax+0x30],xmm3
   248c9:	83 fa f6             	cmp    edx,0xfffffff6
   248cc:	76 11                	jbe    248df <JS_CallInternal+0x1dff>
   248ce:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   248d1:	83 e8 01             	sub    eax,0x1
   248d4:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   248d7:	85 c0                	test   eax,eax
   248d9:	0f 8e 6f 5f 00 00    	jle    2a84e <JS_CallInternal+0x7d6e>
   248df:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   248e4:	49 83 c4 01          	add    r12,0x1
   248e8:	49 89 c5             	mov    r13,rax
   248eb:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   248ef:	ff e0                	jmp    rax
   248f1:	f3 0f 1e fa          	endbr64
   248f5:	48 8b 85 b0 fe ff ff 	mov    rax,QWORD PTR [rbp-0x150]
   248fc:	f3 0f 6f 7b f0       	movdqu xmm7,XMMWORD PTR [rbx-0x10]
   24901:	48 83 eb 10          	sub    rbx,0x10
   24905:	48 8b 50 28          	mov    rdx,QWORD PTR [rax+0x28]
   24909:	48 8b 70 20          	mov    rsi,QWORD PTR [rax+0x20]
   2490d:	0f 11 78 20          	movups XMMWORD PTR [rax+0x20],xmm7
   24911:	83 fa f6             	cmp    edx,0xfffffff6
   24914:	76 11                	jbe    24927 <JS_CallInternal+0x1e47>
   24916:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   24919:	83 e8 01             	sub    eax,0x1
   2491c:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   2491f:	85 c0                	test   eax,eax
   24921:	0f 8e a0 5e 00 00    	jle    2a7c7 <JS_CallInternal+0x7ce7>
   24927:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   2492c:	49 83 c4 01          	add    r12,0x1
   24930:	49 89 c5             	mov    r13,rax
   24933:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   24937:	ff e0                	jmp    rax
   24939:	f3 0f 1e fa          	endbr64
   2493d:	48 8b 85 b0 fe ff ff 	mov    rax,QWORD PTR [rbp-0x150]
   24944:	f3 0f 6f 73 f0       	movdqu xmm6,XMMWORD PTR [rbx-0x10]
   24949:	48 83 eb 10          	sub    rbx,0x10
   2494d:	48 8b 50 18          	mov    rdx,QWORD PTR [rax+0x18]
   24951:	48 8b 70 10          	mov    rsi,QWORD PTR [rax+0x10]
   24955:	0f 11 70 10          	movups XMMWORD PTR [rax+0x10],xmm6
   24959:	83 fa f6             	cmp    edx,0xfffffff6
   2495c:	76 11                	jbe    2496f <JS_CallInternal+0x1e8f>
   2495e:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   24961:	83 e8 01             	sub    eax,0x1
   24964:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   24967:	85 c0                	test   eax,eax
   24969:	0f 8e 6d 5e 00 00    	jle    2a7dc <JS_CallInternal+0x7cfc>
   2496f:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   24974:	49 83 c4 01          	add    r12,0x1
   24978:	49 89 c5             	mov    r13,rax
   2497b:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   2497f:	ff e0                	jmp    rax
   24981:	f3 0f 1e fa          	endbr64
   24985:	48 8b 85 b0 fe ff ff 	mov    rax,QWORD PTR [rbp-0x150]
   2498c:	f3 0f 6f 6b f0       	movdqu xmm5,XMMWORD PTR [rbx-0x10]
   24991:	48 83 eb 10          	sub    rbx,0x10
   24995:	48 8b 50 08          	mov    rdx,QWORD PTR [rax+0x8]
   24999:	48 8b 30             	mov    rsi,QWORD PTR [rax]
   2499c:	0f 11 28             	movups XMMWORD PTR [rax],xmm5
   2499f:	83 fa f6             	cmp    edx,0xfffffff6
   249a2:	76 11                	jbe    249b5 <JS_CallInternal+0x1ed5>
   249a4:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   249a7:	83 e8 01             	sub    eax,0x1
   249aa:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   249ad:	85 c0                	test   eax,eax
   249af:	0f 8e e5 5d 00 00    	jle    2a79a <JS_CallInternal+0x7cba>
   249b5:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   249ba:	49 83 c4 01          	add    r12,0x1
   249be:	49 89 c5             	mov    r13,rax
   249c1:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   249c5:	ff e0                	jmp    rax
   249c7:	f3 0f 1e fa          	endbr64
   249cb:	48 8b 85 b0 fe ff ff 	mov    rax,QWORD PTR [rbp-0x150]
   249d2:	48 8d 4b 10          	lea    rcx,[rbx+0x10]
   249d6:	48 8b 50 30          	mov    rdx,QWORD PTR [rax+0x30]
   249da:	48 8b 40 38          	mov    rax,QWORD PTR [rax+0x38]
   249de:	83 f8 f6             	cmp    eax,0xfffffff6
   249e1:	76 04                	jbe    249e7 <JS_CallInternal+0x1f07>
   249e3:	83 42 fc 01          	add    DWORD PTR [rdx-0x4],0x1
   249e7:	48 89 13             	mov    QWORD PTR [rbx],rdx
   249ea:	49 83 c4 01          	add    r12,0x1
   249ee:	48 89 43 08          	mov    QWORD PTR [rbx+0x8],rax
   249f2:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   249f8:	48 89 cb             	mov    rbx,rcx
   249fb:	49 89 c5             	mov    r13,rax
   249fe:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   24a02:	ff e0                	jmp    rax
   24a04:	f3 0f 1e fa          	endbr64
   24a08:	48 8b 85 b0 fe ff ff 	mov    rax,QWORD PTR [rbp-0x150]
   24a0f:	48 8d 4b 10          	lea    rcx,[rbx+0x10]
   24a13:	48 8b 50 20          	mov    rdx,QWORD PTR [rax+0x20]
   24a17:	48 8b 40 28          	mov    rax,QWORD PTR [rax+0x28]
   24a1b:	83 f8 f6             	cmp    eax,0xfffffff6
   24a1e:	76 04                	jbe    24a24 <JS_CallInternal+0x1f44>
   24a20:	83 42 fc 01          	add    DWORD PTR [rdx-0x4],0x1
   24a24:	48 89 13             	mov    QWORD PTR [rbx],rdx
   24a27:	49 83 c4 01          	add    r12,0x1
   24a2b:	48 89 43 08          	mov    QWORD PTR [rbx+0x8],rax
   24a2f:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   24a35:	48 89 cb             	mov    rbx,rcx
   24a38:	49 89 c5             	mov    r13,rax
   24a3b:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   24a3f:	ff e0                	jmp    rax
   24a41:	f3 0f 1e fa          	endbr64
   24a45:	48 8b 85 b0 fe ff ff 	mov    rax,QWORD PTR [rbp-0x150]
   24a4c:	48 8d 4b 10          	lea    rcx,[rbx+0x10]
   24a50:	48 8b 50 10          	mov    rdx,QWORD PTR [rax+0x10]
   24a54:	48 8b 40 18          	mov    rax,QWORD PTR [rax+0x18]
   24a58:	83 f8 f6             	cmp    eax,0xfffffff6
   24a5b:	76 04                	jbe    24a61 <JS_CallInternal+0x1f81>
   24a5d:	83 42 fc 01          	add    DWORD PTR [rdx-0x4],0x1
   24a61:	48 89 13             	mov    QWORD PTR [rbx],rdx
   24a64:	49 83 c4 01          	add    r12,0x1
   24a68:	48 89 43 08          	mov    QWORD PTR [rbx+0x8],rax
   24a6c:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   24a72:	48 89 cb             	mov    rbx,rcx
   24a75:	49 89 c5             	mov    r13,rax
   24a78:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   24a7c:	ff e0                	jmp    rax
   24a7e:	f3 0f 1e fa          	endbr64
   24a82:	48 8b 85 b0 fe ff ff 	mov    rax,QWORD PTR [rbp-0x150]
   24a89:	48 8d 4b 10          	lea    rcx,[rbx+0x10]
   24a8d:	48 8b 10             	mov    rdx,QWORD PTR [rax]
   24a90:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
   24a94:	83 f8 f6             	cmp    eax,0xfffffff6
   24a97:	76 04                	jbe    24a9d <JS_CallInternal+0x1fbd>
   24a99:	83 42 fc 01          	add    DWORD PTR [rdx-0x4],0x1
   24a9d:	48 89 13             	mov    QWORD PTR [rbx],rdx
   24aa0:	49 83 c4 01          	add    r12,0x1
   24aa4:	48 89 43 08          	mov    QWORD PTR [rbx+0x8],rax
   24aa8:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   24aae:	48 89 cb             	mov    rbx,rcx
   24ab1:	49 89 c5             	mov    r13,rax
   24ab4:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   24ab8:	ff e0                	jmp    rax
   24aba:	f3 0f 1e fa          	endbr64
   24abe:	48 8b 53 f8          	mov    rdx,QWORD PTR [rbx-0x8]
   24ac2:	48 8b 4b f0          	mov    rcx,QWORD PTR [rbx-0x10]
   24ac6:	83 fa f6             	cmp    edx,0xfffffff6
   24ac9:	76 04                	jbe    24acf <JS_CallInternal+0x1fef>
   24acb:	83 41 fc 01          	add    DWORD PTR [rcx-0x4],0x1
   24acf:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   24ad4:	48 8b bd b0 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x150]
   24adb:	48 c1 e0 04          	shl    rax,0x4
   24adf:	48 01 f8             	add    rax,rdi
   24ae2:	4c 8b 40 08          	mov    r8,QWORD PTR [rax+0x8]
   24ae6:	48 8b 30             	mov    rsi,QWORD PTR [rax]
   24ae9:	48 89 50 08          	mov    QWORD PTR [rax+0x8],rdx
   24aed:	48 89 08             	mov    QWORD PTR [rax],rcx
   24af0:	41 83 f8 f6          	cmp    r8d,0xfffffff6
   24af4:	76 11                	jbe    24b07 <JS_CallInternal+0x2027>
   24af6:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   24af9:	83 e8 01             	sub    eax,0x1
   24afc:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   24aff:	85 c0                	test   eax,eax
   24b01:	0f 8e a8 5c 00 00    	jle    2a7af <JS_CallInternal+0x7ccf>
   24b07:	41 0f b6 44 24 01    	movzx  eax,BYTE PTR [r12+0x1]
   24b0d:	49 83 c4 02          	add    r12,0x2
   24b11:	49 89 c5             	mov    r13,rax
   24b14:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   24b18:	ff e0                	jmp    rax
   24b1a:	f3 0f 1e fa          	endbr64
   24b1e:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   24b23:	48 8b 8d b0 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x150]
   24b2a:	48 83 eb 10          	sub    rbx,0x10
   24b2e:	f3 0f 6f 13          	movdqu xmm2,XMMWORD PTR [rbx]
   24b32:	48 c1 e0 04          	shl    rax,0x4
   24b36:	48 01 c8             	add    rax,rcx
   24b39:	48 8b 50 08          	mov    rdx,QWORD PTR [rax+0x8]
   24b3d:	48 8b 30             	mov    rsi,QWORD PTR [rax]
   24b40:	0f 11 10             	movups XMMWORD PTR [rax],xmm2
   24b43:	83 fa f6             	cmp    edx,0xfffffff6
   24b46:	76 11                	jbe    24b59 <JS_CallInternal+0x2079>
   24b48:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   24b4b:	83 e8 01             	sub    eax,0x1
   24b4e:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   24b51:	85 c0                	test   eax,eax
   24b53:	0f 8e cd 5a 00 00    	jle    2a626 <JS_CallInternal+0x7b46>
   24b59:	41 0f b6 44 24 01    	movzx  eax,BYTE PTR [r12+0x1]
   24b5f:	49 83 c4 02          	add    r12,0x2
   24b63:	49 89 c5             	mov    r13,rax
   24b66:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   24b6a:	ff e0                	jmp    rax
   24b6c:	f3 0f 1e fa          	endbr64
   24b70:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   24b75:	48 8b 8d b0 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x150]
   24b7c:	48 c1 e0 04          	shl    rax,0x4
   24b80:	48 01 c8             	add    rax,rcx
   24b83:	48 8d 4b 10          	lea    rcx,[rbx+0x10]
   24b87:	48 8b 10             	mov    rdx,QWORD PTR [rax]
   24b8a:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
   24b8e:	83 f8 f6             	cmp    eax,0xfffffff6
   24b91:	76 04                	jbe    24b97 <JS_CallInternal+0x20b7>
   24b93:	83 42 fc 01          	add    DWORD PTR [rdx-0x4],0x1
   24b97:	48 89 13             	mov    QWORD PTR [rbx],rdx
   24b9a:	49 83 c4 02          	add    r12,0x2
   24b9e:	48 89 43 08          	mov    QWORD PTR [rbx+0x8],rax
   24ba2:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   24ba8:	48 89 cb             	mov    rbx,rcx
   24bab:	49 89 c5             	mov    r13,rax
   24bae:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   24bb2:	ff e0                	jmp    rax
   24bb4:	f3 0f 1e fa          	endbr64
   24bb8:	41 0f b7 04 24       	movzx  eax,WORD PTR [r12]
   24bbd:	48 8b bd b0 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x150]
   24bc4:	4d 8d 6c 24 02       	lea    r13,[r12+0x2]
   24bc9:	48 89 c1             	mov    rcx,rax
   24bcc:	48 c1 e0 04          	shl    rax,0x4
   24bd0:	48 01 f8             	add    rax,rdi
   24bd3:	48 8b 50 08          	mov    rdx,QWORD PTR [rax+0x8]
   24bd7:	83 fa 04             	cmp    edx,0x4
   24bda:	0f 84 69 6d 00 00    	je     2b949 <JS_CallInternal+0x8e69>
   24be0:	48 8b 00             	mov    rax,QWORD PTR [rax]
   24be3:	83 fa f6             	cmp    edx,0xfffffff6
   24be6:	76 04                	jbe    24bec <JS_CallInternal+0x210c>
   24be8:	83 40 fc 01          	add    DWORD PTR [rax-0x4],0x1
   24bec:	48 89 03             	mov    QWORD PTR [rbx],rax
   24bef:	49 83 c4 03          	add    r12,0x3
   24bf3:	48 83 c3 10          	add    rbx,0x10
   24bf7:	48 89 53 f8          	mov    QWORD PTR [rbx-0x8],rdx
   24bfb:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   24c01:	49 89 c5             	mov    r13,rax
   24c04:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   24c08:	ff e0                	jmp    rax
   24c0a:	f3 0f 1e fa          	endbr64
   24c0e:	41 0f b7 04 24       	movzx  eax,WORD PTR [r12]
   24c13:	48 8b bd b0 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x150]
   24c1a:	4d 8d 6c 24 02       	lea    r13,[r12+0x2]
   24c1f:	48 89 c1             	mov    rcx,rax
   24c22:	48 c1 e0 04          	shl    rax,0x4
   24c26:	48 01 f8             	add    rax,rdi
   24c29:	48 8b 50 08          	mov    rdx,QWORD PTR [rax+0x8]
   24c2d:	83 fa 04             	cmp    edx,0x4
   24c30:	0f 84 54 6e 00 00    	je     2ba8a <JS_CallInternal+0x8faa>
   24c36:	48 8b 00             	mov    rax,QWORD PTR [rax]
   24c39:	83 fa f6             	cmp    edx,0xfffffff6
   24c3c:	76 04                	jbe    24c42 <JS_CallInternal+0x2162>
   24c3e:	83 40 fc 01          	add    DWORD PTR [rax-0x4],0x1
   24c42:	48 89 03             	mov    QWORD PTR [rbx],rax
   24c45:	49 83 c4 03          	add    r12,0x3
   24c49:	48 83 c3 10          	add    rbx,0x10
   24c4d:	48 89 53 f8          	mov    QWORD PTR [rbx-0x8],rdx
   24c51:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   24c57:	49 89 c5             	mov    r13,rax
   24c5a:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   24c5e:	ff e0                	jmp    rax
   24c60:	f3 0f 1e fa          	endbr64
   24c64:	41 0f b7 04 24       	movzx  eax,WORD PTR [r12]
   24c69:	48 8b 8d b0 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x150]
   24c70:	48 c1 e0 04          	shl    rax,0x4
   24c74:	48 01 c8             	add    rax,rcx
   24c77:	48 8b 50 08          	mov    rdx,QWORD PTR [rax+0x8]
   24c7b:	48 8b 30             	mov    rsi,QWORD PTR [rax]
   24c7e:	48 c7 40 08 04 00 00 	mov    QWORD PTR [rax+0x8],0x4
   24c85:	00 
   24c86:	48 c7 00 00 00 00 00 	mov    QWORD PTR [rax],0x0
   24c8d:	83 fa f6             	cmp    edx,0xfffffff6
   24c90:	76 11                	jbe    24ca3 <JS_CallInternal+0x21c3>
   24c92:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   24c95:	83 e8 01             	sub    eax,0x1
   24c98:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   24c9b:	85 c0                	test   eax,eax
   24c9d:	0f 8e 6e 59 00 00    	jle    2a611 <JS_CallInternal+0x7b31>
   24ca3:	41 0f b6 44 24 02    	movzx  eax,BYTE PTR [r12+0x2]
   24ca9:	49 83 c4 03          	add    r12,0x3
   24cad:	49 89 c5             	mov    r13,rax
   24cb0:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   24cb4:	ff e0                	jmp    rax
   24cb6:	f3 0f 1e fa          	endbr64
   24cba:	41 0f b7 04 24       	movzx  eax,WORD PTR [r12]
   24cbf:	48 8b 8d 98 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x168]
   24cc6:	4d 8d 6c 24 02       	lea    r13,[r12+0x2]
   24ccb:	48 8d 14 c5 00 00 00 	lea    rdx,[rax*8+0x0]
   24cd2:	00 
   24cd3:	48 8b 04 c1          	mov    rax,QWORD PTR [rcx+rax*8]
   24cd7:	48 8b 40 18          	mov    rax,QWORD PTR [rax+0x18]
   24cdb:	83 78 08 04          	cmp    DWORD PTR [rax+0x8],0x4
   24cdf:	0f 85 39 61 00 00    	jne    2ae1e <JS_CallInternal+0x833e>
   24ce5:	f3 0f 6f 7b f0       	movdqu xmm7,XMMWORD PTR [rbx-0x10]
   24cea:	49 83 c4 03          	add    r12,0x3
   24cee:	48 83 eb 10          	sub    rbx,0x10
   24cf2:	0f 11 38             	movups XMMWORD PTR [rax],xmm7
   24cf5:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   24cfb:	49 89 c5             	mov    r13,rax
   24cfe:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   24d02:	ff e0                	jmp    rax
   24d04:	f3 0f 1e fa          	endbr64
   24d08:	41 0f b7 04 24       	movzx  eax,WORD PTR [r12]
   24d0d:	48 8b bd 98 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x168]
   24d14:	4d 8d 6c 24 02       	lea    r13,[r12+0x2]
   24d19:	48 8d 0c c5 00 00 00 	lea    rcx,[rax*8+0x0]
   24d20:	00 
   24d21:	48 8b 04 c7          	mov    rax,QWORD PTR [rdi+rax*8]
   24d25:	48 8b 40 18          	mov    rax,QWORD PTR [rax+0x18]
   24d29:	48 8b 50 08          	mov    rdx,QWORD PTR [rax+0x8]
   24d2d:	83 fa 04             	cmp    edx,0x4
   24d30:	0f 84 23 69 00 00    	je     2b659 <JS_CallInternal+0x8b79>
   24d36:	f3 0f 6f 73 f0       	movdqu xmm6,XMMWORD PTR [rbx-0x10]
   24d3b:	48 8b 30             	mov    rsi,QWORD PTR [rax]
   24d3e:	0f 11 30             	movups XMMWORD PTR [rax],xmm6
   24d41:	83 fa f6             	cmp    edx,0xfffffff6
   24d44:	76 11                	jbe    24d57 <JS_CallInternal+0x2277>
   24d46:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   24d49:	83 e8 01             	sub    eax,0x1
   24d4c:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   24d4f:	85 c0                	test   eax,eax
   24d51:	0f 8e b2 57 00 00    	jle    2a509 <JS_CallInternal+0x7a29>
   24d57:	41 0f b6 44 24 02    	movzx  eax,BYTE PTR [r12+0x2]
   24d5d:	48 83 eb 10          	sub    rbx,0x10
   24d61:	49 83 c4 03          	add    r12,0x3
   24d65:	49 89 c5             	mov    r13,rax
   24d68:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   24d6c:	ff e0                	jmp    rax
   24d6e:	f3 0f 1e fa          	endbr64
   24d72:	48 8b 73 f0          	mov    rsi,QWORD PTR [rbx-0x10]
   24d76:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   24d7d:	4c 8d 43 f0          	lea    r8,[rbx-0x10]
   24d81:	49 8b 50 08          	mov    rdx,QWORD PTR [r8+0x8]
   24d85:	e8 36 6c ff ff       	call   1b9c0 <js_operator_typeof>
   24d8a:	83 f8 1b             	cmp    eax,0x1b
   24d8d:	74 61                	je     24df0 <JS_CallInternal+0x2310>
   24d8f:	49 8b 50 08          	mov    rdx,QWORD PTR [r8+0x8]
   24d93:	49 8b 30             	mov    rsi,QWORD PTR [r8]
   24d96:	83 fa f6             	cmp    edx,0xfffffff6
   24d99:	76 11                	jbe    24dac <JS_CallInternal+0x22cc>
   24d9b:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   24d9e:	83 e8 01             	sub    eax,0x1
   24da1:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   24da4:	85 c0                	test   eax,eax
   24da6:	0f 8e 4e 49 00 00    	jle    296fa <JS_CallInternal+0x6c1a>
   24dac:	48 c7 43 f0 00 00 00 	mov    QWORD PTR [rbx-0x10],0x0
   24db3:	00 
   24db4:	49 83 c4 01          	add    r12,0x1
   24db8:	48 c7 43 f8 01 00 00 	mov    QWORD PTR [rbx-0x8],0x1
   24dbf:	00 
   24dc0:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   24dc6:	49 89 c5             	mov    r13,rax
   24dc9:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   24dcd:	ff e0                	jmp    rax
   24dcf:	f3 0f 1e fa          	endbr64
   24dd3:	48 8b 73 f0          	mov    rsi,QWORD PTR [rbx-0x10]
   24dd7:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   24dde:	4c 8d 43 f0          	lea    r8,[rbx-0x10]
   24de2:	49 8b 50 08          	mov    rdx,QWORD PTR [r8+0x8]
   24de6:	e8 d5 6b ff ff       	call   1b9c0 <js_operator_typeof>
   24deb:	83 f8 49             	cmp    eax,0x49
   24dee:	75 9f                	jne    24d8f <JS_CallInternal+0x22af>
   24df0:	49 8b 50 08          	mov    rdx,QWORD PTR [r8+0x8]
   24df4:	49 8b 30             	mov    rsi,QWORD PTR [r8]
   24df7:	83 fa f6             	cmp    edx,0xfffffff6
   24dfa:	76 11                	jbe    24e0d <JS_CallInternal+0x232d>
   24dfc:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   24dff:	83 e8 01             	sub    eax,0x1
   24e02:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   24e05:	85 c0                	test   eax,eax
   24e07:	0f 8e 17 69 00 00    	jle    2b724 <JS_CallInternal+0x8c44>
   24e0d:	48 c7 43 f0 01 00 00 	mov    QWORD PTR [rbx-0x10],0x1
   24e14:	00 
   24e15:	49 83 c4 01          	add    r12,0x1
   24e19:	48 c7 43 f8 01 00 00 	mov    QWORD PTR [rbx-0x8],0x1
   24e20:	00 
   24e21:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   24e27:	49 89 c5             	mov    r13,rax
   24e2a:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   24e2e:	ff e0                	jmp    rax
   24e30:	f3 0f 1e fa          	endbr64
   24e34:	31 c9                	xor    ecx,ecx
   24e36:	b8 03 00 00 00       	mov    eax,0x3
   24e3b:	e9 c0 e4 ff ff       	jmp    23300 <JS_CallInternal+0x820>
   24e40:	f3 0f 1e fa          	endbr64
   24e44:	b9 03 00 00 00       	mov    ecx,0x3
   24e49:	31 c0                	xor    eax,eax
   24e4b:	e9 b0 e4 ff ff       	jmp    23300 <JS_CallInternal+0x820>
   24e50:	f3 0f 1e fa          	endbr64
   24e54:	83 7b f8 02          	cmp    DWORD PTR [rbx-0x8],0x2
   24e58:	74 b3                	je     24e0d <JS_CallInternal+0x232d>
   24e5a:	4c 8d 43 f0          	lea    r8,[rbx-0x10]
   24e5e:	e9 2c ff ff ff       	jmp    24d8f <JS_CallInternal+0x22af>
   24e63:	f3 0f 1e fa          	endbr64
   24e67:	83 7b f8 03          	cmp    DWORD PTR [rbx-0x8],0x3
   24e6b:	75 ed                	jne    24e5a <JS_CallInternal+0x237a>
   24e6d:	eb 9e                	jmp    24e0d <JS_CallInternal+0x232d>
   24e6f:	f3 0f 1e fa          	endbr64
   24e73:	8b 43 f8             	mov    eax,DWORD PTR [rbx-0x8]
   24e76:	83 e8 02             	sub    eax,0x2
   24e79:	83 f8 01             	cmp    eax,0x1
   24e7c:	77 dc                	ja     24e5a <JS_CallInternal+0x237a>
   24e7e:	eb 8d                	jmp    24e0d <JS_CallInternal+0x232d>
   24e80:	f3 0f 1e fa          	endbr64
   24e84:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   24e89:	49 83 c4 01          	add    r12,0x1
   24e8d:	49 89 c5             	mov    r13,rax
   24e90:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   24e94:	ff e0                	jmp    rax
   24e96:	f3 0f 1e fa          	endbr64
   24e9a:	31 c9                	xor    ecx,ecx
   24e9c:	b8 01 00 00 00       	mov    eax,0x1
   24ea1:	e9 5a e4 ff ff       	jmp    23300 <JS_CallInternal+0x820>
   24ea6:	f3 0f 1e fa          	endbr64
   24eaa:	31 c9                	xor    ecx,ecx
   24eac:	31 c0                	xor    eax,eax
   24eae:	e9 4d e4 ff ff       	jmp    23300 <JS_CallInternal+0x820>
   24eb3:	f3 0f 1e fa          	endbr64
   24eb7:	e9 44 df ff ff       	jmp    22e00 <JS_CallInternal+0x320>
   24ebc:	f3 0f 1e fa          	endbr64
   24ec0:	e9 3b df ff ff       	jmp    22e00 <JS_CallInternal+0x320>
   24ec5:	f3 0f 1e fa          	endbr64
   24ec9:	e9 32 df ff ff       	jmp    22e00 <JS_CallInternal+0x320>
   24ece:	f3 0f 1e fa          	endbr64
   24ed2:	48 8b 43 f8          	mov    rax,QWORD PTR [rbx-0x8]
   24ed6:	83 f8 fa             	cmp    eax,0xfffffffa
   24ed9:	0f 8d 45 46 00 00    	jge    29524 <JS_CallInternal+0x6a44>
   24edf:	83 f8 f8             	cmp    eax,0xfffffff8
   24ee2:	0f 8c 44 46 00 00    	jl     2952c <JS_CallInternal+0x6a4c>
   24ee8:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   24eed:	49 83 c4 01          	add    r12,0x1
   24ef1:	49 89 c5             	mov    r13,rax
   24ef4:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   24ef8:	ff e0                	jmp    rax
   24efa:	f3 0f 1e fa          	endbr64
   24efe:	83 7b f8 ff          	cmp    DWORD PTR [rbx-0x8],0xffffffff
   24f02:	74 54                	je     24f58 <JS_CallInternal+0x2478>
   24f04:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   24f0b:	48 8b 73 f0          	mov    rsi,QWORD PTR [rbx-0x10]
   24f0f:	48 8b 53 f8          	mov    rdx,QWORD PTR [rbx-0x8]
   24f13:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   24f1a:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   24f1e:	e8 4d 34 02 00       	call   48370 <JS_ToObject>
   24f23:	49 89 c1             	mov    r9,rax
   24f26:	49 89 d0             	mov    r8,rdx
   24f29:	83 fa 06             	cmp    edx,0x6
   24f2c:	0f 84 4e e3 ff ff    	je     23280 <JS_CallInternal+0x7a0>
   24f32:	48 8b 53 f8          	mov    rdx,QWORD PTR [rbx-0x8]
   24f36:	48 8b 73 f0          	mov    rsi,QWORD PTR [rbx-0x10]
   24f3a:	83 fa f6             	cmp    edx,0xfffffff6
   24f3d:	76 11                	jbe    24f50 <JS_CallInternal+0x2470>
   24f3f:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   24f42:	83 e8 01             	sub    eax,0x1
   24f45:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   24f48:	85 c0                	test   eax,eax
   24f4a:	0f 8e e2 70 00 00    	jle    2c032 <JS_CallInternal+0x9552>
   24f50:	4c 89 4b f0          	mov    QWORD PTR [rbx-0x10],r9
   24f54:	4c 89 43 f8          	mov    QWORD PTR [rbx-0x8],r8
   24f58:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   24f5d:	49 83 c4 01          	add    r12,0x1
   24f61:	49 89 c5             	mov    r13,rax
   24f64:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   24f68:	ff e0                	jmp    rax
   24f6a:	f3 0f 1e fa          	endbr64
   24f6e:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   24f75:	4d 8d 6c 24 04       	lea    r13,[r12+0x4]
   24f7a:	45 8b 34 24          	mov    r14d,DWORD PTR [r12]
   24f7e:	4c 89 68 30          	mov    QWORD PTR [rax+0x30],r13
   24f82:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   24f89:	44 89 f1             	mov    ecx,r14d
   24f8c:	48 8b 80 90 01 00 00 	mov    rax,QWORD PTR [rax+0x190]
   24f93:	48 8b 50 18          	mov    rdx,QWORD PTR [rax+0x18]
   24f97:	8b 42 18             	mov    eax,DWORD PTR [rdx+0x18]
   24f9a:	21 c1                	and    ecx,eax
   24f9c:	8b 4c 8a 38          	mov    ecx,DWORD PTR [rdx+rcx*4+0x38]
   24fa0:	48 85 c9             	test   rcx,rcx
   24fa3:	0f 84 f6 4e 00 00    	je     29e9f <JS_CallInternal+0x73bf>
   24fa9:	48 8d 34 85 34 00 00 	lea    rsi,[rax*4+0x34]
   24fb0:	00 
   24fb1:	48 8d 04 ce          	lea    rax,[rsi+rcx*8]
   24fb5:	48 01 d0             	add    rax,rdx
   24fb8:	44 3b 70 04          	cmp    r14d,DWORD PTR [rax+0x4]
   24fbc:	0f 85 cf 4e 00 00    	jne    29e91 <JS_CallInternal+0x73b1>
   24fc2:	31 c0                	xor    eax,eax
   24fc4:	48 89 03             	mov    QWORD PTR [rbx],rax
   24fc7:	49 83 c4 05          	add    r12,0x5
   24fcb:	48 83 c3 10          	add    rbx,0x10
   24fcf:	48 c7 43 f8 01 00 00 	mov    QWORD PTR [rbx-0x8],0x1
   24fd6:	00 
   24fd7:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   24fdd:	49 89 c5             	mov    r13,rax
   24fe0:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   24fe4:	ff e0                	jmp    rax
   24fe6:	f3 0f 1e fa          	endbr64
   24fea:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   24ff1:	4c 8b 6b f0          	mov    r13,QWORD PTR [rbx-0x10]
   24ff5:	4c 8b 73 f8          	mov    r14,QWORD PTR [rbx-0x8]
   24ff9:	48 8b 4b e8          	mov    rcx,QWORD PTR [rbx-0x18]
   24ffd:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   25001:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   25008:	4c 89 ee             	mov    rsi,r13
   2500b:	48 8b 43 e0          	mov    rax,QWORD PTR [rbx-0x20]
   2500f:	4c 89 f2             	mov    rdx,r14
   25012:	48 89 8d 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],rcx
   25019:	48 89 85 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],rax
   25020:	e8 bb e4 01 00       	call   434e0 <JS_ValueToAtom>
   25025:	89 c1                	mov    ecx,eax
   25027:	85 c0                	test   eax,eax
   25029:	0f 84 51 e2 ff ff    	je     23280 <JS_CallInternal+0x7a0>
   2502f:	48 8b b5 40 fe ff ff 	mov    rsi,QWORD PTR [rbp-0x1c0]
   25036:	48 8b 95 50 fe ff ff 	mov    rdx,QWORD PTR [rbp-0x1b0]
   2503d:	41 b8 00 80 00 00    	mov    r8d,0x8000
   25043:	89 85 38 fe ff ff    	mov    DWORD PTR [rbp-0x1c8],eax
   25049:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   25050:	e8 3b 5f 02 00       	call   4af90 <JS_DeleteProperty>
   25055:	8b 8d 38 fe ff ff    	mov    ecx,DWORD PTR [rbp-0x1c8]
   2505b:	41 89 c0             	mov    r8d,eax
   2505e:	81 f9 f2 00 00 00    	cmp    ecx,0xf2
   25064:	0f 8f d6 4e 00 00    	jg     29f40 <JS_CallInternal+0x7460>
   2506a:	45 85 c0             	test   r8d,r8d
   2506d:	0f 88 0d e2 ff ff    	js     23280 <JS_CallInternal+0x7a0>
   25073:	83 bd 50 fe ff ff f6 	cmp    DWORD PTR [rbp-0x1b0],0xfffffff6
   2507a:	76 1e                	jbe    2509a <JS_CallInternal+0x25ba>
   2507c:	48 8b 8d 40 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x1c0]
   25083:	8b 41 fc             	mov    eax,DWORD PTR [rcx-0x4]
   25086:	89 85 38 fe ff ff    	mov    DWORD PTR [rbp-0x1c8],eax
   2508c:	83 e8 01             	sub    eax,0x1
   2508f:	89 41 fc             	mov    DWORD PTR [rcx-0x4],eax
   25092:	85 c0                	test   eax,eax
   25094:	0f 8e 51 61 00 00    	jle    2b1eb <JS_CallInternal+0x870b>
   2509a:	41 83 fe f6          	cmp    r14d,0xfffffff6
   2509e:	76 13                	jbe    250b3 <JS_CallInternal+0x25d3>
   250a0:	41 8b 45 fc          	mov    eax,DWORD PTR [r13-0x4]
   250a4:	83 e8 01             	sub    eax,0x1
   250a7:	41 89 45 fc          	mov    DWORD PTR [r13-0x4],eax
   250ab:	85 c0                	test   eax,eax
   250ad:	0f 8e 0f 61 00 00    	jle    2b1c2 <JS_CallInternal+0x86e2>
   250b3:	31 c0                	xor    eax,eax
   250b5:	45 85 c0             	test   r8d,r8d
   250b8:	48 c7 43 e8 01 00 00 	mov    QWORD PTR [rbx-0x18],0x1
   250bf:	00 
   250c0:	0f 95 c0             	setne  al
   250c3:	48 83 eb 10          	sub    rbx,0x10
   250c7:	49 83 c4 01          	add    r12,0x1
   250cb:	48 89 43 f0          	mov    QWORD PTR [rbx-0x10],rax
   250cf:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   250d5:	49 89 c5             	mov    r13,rax
   250d8:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   250dc:	ff e0                	jmp    rax
   250de:	f3 0f 1e fa          	endbr64
   250e2:	48 8b 43 d8          	mov    rax,QWORD PTR [rbx-0x28]
   250e6:	48 8b 53 d0          	mov    rdx,QWORD PTR [rbx-0x30]
   250ea:	83 f8 f6             	cmp    eax,0xfffffff6
   250ed:	76 04                	jbe    250f3 <JS_CallInternal+0x2613>
   250ef:	83 42 fc 01          	add    DWORD PTR [rdx-0x4],0x1
   250f3:	48 89 43 08          	mov    QWORD PTR [rbx+0x8],rax
   250f7:	48 8b 43 e8          	mov    rax,QWORD PTR [rbx-0x18]
   250fb:	48 89 13             	mov    QWORD PTR [rbx],rdx
   250fe:	48 8b 53 e0          	mov    rdx,QWORD PTR [rbx-0x20]
   25102:	83 f8 f6             	cmp    eax,0xfffffff6
   25105:	76 04                	jbe    2510b <JS_CallInternal+0x262b>
   25107:	83 42 fc 01          	add    DWORD PTR [rdx-0x4],0x1
   2510b:	48 89 43 18          	mov    QWORD PTR [rbx+0x18],rax
   2510f:	48 8b 43 f8          	mov    rax,QWORD PTR [rbx-0x8]
   25113:	48 89 53 10          	mov    QWORD PTR [rbx+0x10],rdx
   25117:	48 8b 53 f0          	mov    rdx,QWORD PTR [rbx-0x10]
   2511b:	83 f8 f6             	cmp    eax,0xfffffff6
   2511e:	76 04                	jbe    25124 <JS_CallInternal+0x2644>
   25120:	83 42 fc 01          	add    DWORD PTR [rdx-0x4],0x1
   25124:	48 89 53 20          	mov    QWORD PTR [rbx+0x20],rdx
   25128:	49 83 c4 01          	add    r12,0x1
   2512c:	48 83 c3 30          	add    rbx,0x30
   25130:	48 89 43 f8          	mov    QWORD PTR [rbx-0x8],rax
   25134:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   2513a:	49 89 c5             	mov    r13,rax
   2513d:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   25141:	ff e0                	jmp    rax
   25143:	f3 0f 1e fa          	endbr64
   25147:	48 8b 43 e8          	mov    rax,QWORD PTR [rbx-0x18]
   2514b:	48 8b 53 e0          	mov    rdx,QWORD PTR [rbx-0x20]
   2514f:	83 f8 f6             	cmp    eax,0xfffffff6
   25152:	76 04                	jbe    25158 <JS_CallInternal+0x2678>
   25154:	83 42 fc 01          	add    DWORD PTR [rdx-0x4],0x1
   25158:	48 89 43 08          	mov    QWORD PTR [rbx+0x8],rax
   2515c:	48 8b 43 f8          	mov    rax,QWORD PTR [rbx-0x8]
   25160:	48 89 13             	mov    QWORD PTR [rbx],rdx
   25163:	48 8b 53 f0          	mov    rdx,QWORD PTR [rbx-0x10]
   25167:	83 f8 f6             	cmp    eax,0xfffffff6
   2516a:	76 04                	jbe    25170 <JS_CallInternal+0x2690>
   2516c:	83 42 fc 01          	add    DWORD PTR [rdx-0x4],0x1
   25170:	48 89 53 10          	mov    QWORD PTR [rbx+0x10],rdx
   25174:	49 83 c4 01          	add    r12,0x1
   25178:	48 83 c3 20          	add    rbx,0x20
   2517c:	48 89 43 f8          	mov    QWORD PTR [rbx-0x8],rax
   25180:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   25186:	49 89 c5             	mov    r13,rax
   25189:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   2518d:	ff e0                	jmp    rax
   2518f:	f3 0f 1e fa          	endbr64
   25193:	48 8b 43 f8          	mov    rax,QWORD PTR [rbx-0x8]
   25197:	48 8b 53 f0          	mov    rdx,QWORD PTR [rbx-0x10]
   2519b:	83 f8 f6             	cmp    eax,0xfffffff6
   2519e:	76 04                	jbe    251a4 <JS_CallInternal+0x26c4>
   251a0:	83 42 fc 01          	add    DWORD PTR [rdx-0x4],0x1
   251a4:	48 89 13             	mov    QWORD PTR [rbx],rdx
   251a7:	49 83 c4 01          	add    r12,0x1
   251ab:	48 83 c3 10          	add    rbx,0x10
   251af:	48 89 43 f8          	mov    QWORD PTR [rbx-0x8],rax
   251b3:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   251b9:	49 89 c5             	mov    r13,rax
   251bc:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   251c0:	ff e0                	jmp    rax
   251c2:	f3 0f 1e fa          	endbr64
   251c6:	48 8b 53 d8          	mov    rdx,QWORD PTR [rbx-0x28]
   251ca:	48 8b 73 d0          	mov    rsi,QWORD PTR [rbx-0x30]
   251ce:	83 fa f6             	cmp    edx,0xfffffff6
   251d1:	76 11                	jbe    251e4 <JS_CallInternal+0x2704>
   251d3:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   251d6:	83 e8 01             	sub    eax,0x1
   251d9:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   251dc:	85 c0                	test   eax,eax
   251de:	0f 8e ac 53 00 00    	jle    2a590 <JS_CallInternal+0x7ab0>
   251e4:	f3 0f 6f 73 e0       	movdqu xmm6,XMMWORD PTR [rbx-0x20]
   251e9:	f3 0f 6f 7b f0       	movdqu xmm7,XMMWORD PTR [rbx-0x10]
   251ee:	49 83 c4 01          	add    r12,0x1
   251f2:	48 83 eb 10          	sub    rbx,0x10
   251f6:	0f 11 73 e0          	movups XMMWORD PTR [rbx-0x20],xmm6
   251fa:	0f 11 7b f0          	movups XMMWORD PTR [rbx-0x10],xmm7
   251fe:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   25204:	49 89 c5             	mov    r13,rax
   25207:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   2520b:	ff e0                	jmp    rax
   2520d:	f3 0f 1e fa          	endbr64
   25211:	48 8b 53 e8          	mov    rdx,QWORD PTR [rbx-0x18]
   25215:	48 8b 73 e0          	mov    rsi,QWORD PTR [rbx-0x20]
   25219:	83 fa f6             	cmp    edx,0xfffffff6
   2521c:	76 11                	jbe    2522f <JS_CallInternal+0x274f>
   2521e:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   25221:	83 e8 01             	sub    eax,0x1
   25224:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   25227:	85 c0                	test   eax,eax
   25229:	0f 8e 4c 53 00 00    	jle    2a57b <JS_CallInternal+0x7a9b>
   2522f:	f3 0f 6f 6b f0       	movdqu xmm5,XMMWORD PTR [rbx-0x10]
   25234:	49 83 c4 01          	add    r12,0x1
   25238:	48 83 eb 10          	sub    rbx,0x10
   2523c:	0f 11 6b f0          	movups XMMWORD PTR [rbx-0x10],xmm5
   25240:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   25246:	49 89 c5             	mov    r13,rax
   25249:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   2524d:	ff e0                	jmp    rax
   2524f:	f3 0f 1e fa          	endbr64
   25253:	48 8b 53 f8          	mov    rdx,QWORD PTR [rbx-0x8]
   25257:	48 83 eb 10          	sub    rbx,0x10
   2525b:	48 8b 33             	mov    rsi,QWORD PTR [rbx]
   2525e:	83 fa f6             	cmp    edx,0xfffffff6
   25261:	76 11                	jbe    25274 <JS_CallInternal+0x2794>
   25263:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   25266:	83 e8 01             	sub    eax,0x1
   25269:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   2526c:	85 c0                	test   eax,eax
   2526e:	0f 8e 31 53 00 00    	jle    2a5a5 <JS_CallInternal+0x7ac5>
   25274:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   25279:	49 83 c4 01          	add    r12,0x1
   2527d:	49 89 c5             	mov    r13,rax
   25280:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   25284:	ff e0                	jmp    rax
   25286:	f3 0f 1e fa          	endbr64
   2528a:	8b 8d bc fe ff ff    	mov    ecx,DWORD PTR [rbp-0x144]
   25290:	41 0f b7 04 24       	movzx  eax,WORD PTR [r12]
   25295:	4d 8d 6c 24 02       	lea    r13,[r12+0x2]
   2529a:	4c 8d 73 10          	lea    r14,[rbx+0x10]
   2529e:	48 8b bd a8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x158]
   252a5:	39 c8                	cmp    eax,ecx
   252a7:	0f 4f c1             	cmovg  eax,ecx
   252aa:	48 63 d0             	movsxd rdx,eax
   252ad:	29 c1                	sub    ecx,eax
   252af:	48 c1 e2 04          	shl    rdx,0x4
   252b3:	89 ce                	mov    esi,ecx
   252b5:	48 01 fa             	add    rdx,rdi
   252b8:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   252bf:	e8 ac 48 02 00       	call   49b70 <js_create_array>
   252c4:	48 89 53 08          	mov    QWORD PTR [rbx+0x8],rdx
   252c8:	83 7b 08 06          	cmp    DWORD PTR [rbx+0x8],0x6
   252cc:	48 89 03             	mov    QWORD PTR [rbx],rax
   252cf:	0f 84 0b 65 00 00    	je     2b7e0 <JS_CallInternal+0x8d00>
   252d5:	41 0f b6 44 24 02    	movzx  eax,BYTE PTR [r12+0x2]
   252db:	4c 89 f3             	mov    rbx,r14
   252de:	49 83 c4 03          	add    r12,0x3
   252e2:	49 89 c5             	mov    r13,rax
   252e5:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   252e9:	ff e0                	jmp    rax
   252eb:	f3 0f 1e fa          	endbr64
   252ef:	41 80 3c 24 06       	cmp    BYTE PTR [r12],0x6
   252f4:	4d 8d 74 24 01       	lea    r14,[r12+0x1]
   252f9:	0f 87 c5 cc fe ff    	ja     11fc4 <JS_CallInternal.cold>
   252ff:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   25304:	48 8d 15 2d 1e 0b 00 	lea    rdx,[rip+0xb1e2d]        # d7138 <qjsc_repl_size+0x46c>
   2530b:	48 63 04 82          	movsxd rax,DWORD PTR [rdx+rax*4]
   2530f:	48 01 d0             	add    rax,rdx
   25312:	3e ff e0             	notrack jmp rax
   25315:	31 f6                	xor    esi,esi
   25317:	b9 01 00 00 00       	mov    ecx,0x1
   2531c:	4c 8d 6b 10          	lea    r13,[rbx+0x10]
   25320:	ba 02 00 00 00       	mov    edx,0x2
   25325:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2532c:	e8 df 14 02 00       	call   46810 <JS_NewObjectProtoClass>
   25331:	48 89 53 08          	mov    QWORD PTR [rbx+0x8],rdx
   25335:	83 7b 08 06          	cmp    DWORD PTR [rbx+0x8],0x6
   25339:	48 89 03             	mov    QWORD PTR [rbx],rax
   2533c:	0f 84 e9 00 00 00    	je     2542b <JS_CallInternal+0x294b>
   25342:	4c 89 eb             	mov    rbx,r13
   25345:	41 0f b6 44 24 01    	movzx  eax,BYTE PTR [r12+0x1]
   2534b:	49 83 c4 02          	add    r12,0x2
   2534f:	49 89 c5             	mov    r13,rax
   25352:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   25356:	ff e0                	jmp    rax
   25358:	48 8b 85 60 fe ff ff 	mov    rax,QWORD PTR [rbp-0x1a0]
   2535f:	48 8d 53 10          	lea    rdx,[rbx+0x10]
   25363:	48 8b 40 38          	mov    rax,QWORD PTR [rax+0x38]
   25367:	48 85 c0             	test   rax,rax
   2536a:	0f 84 67 74 00 00    	je     2c7d7 <JS_CallInternal+0x9cf7>
   25370:	83 40 fc 01          	add    DWORD PTR [rax-0x4],0x1
   25374:	48 89 03             	mov    QWORD PTR [rbx],rax
   25377:	48 c7 43 08 ff ff ff 	mov    QWORD PTR [rbx+0x8],0xffffffffffffffff
   2537e:	ff 
   2537f:	48 89 d3             	mov    rbx,rdx
   25382:	eb c1                	jmp    25345 <JS_CallInternal+0x2865>
   25384:	83 bd 80 fe ff ff f6 	cmp    DWORD PTR [rbp-0x180],0xfffffff6
   2538b:	48 8d 43 10          	lea    rax,[rbx+0x10]
   2538f:	76 0b                	jbe    2539c <JS_CallInternal+0x28bc>
   25391:	48 8b 8d 70 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x190]
   25398:	83 41 fc 01          	add    DWORD PTR [rcx-0x4],0x1
   2539c:	48 8b 8d 70 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x190]
   253a3:	48 89 0b             	mov    QWORD PTR [rbx],rcx
   253a6:	48 8b 8d 80 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x180]
   253ad:	48 89 4b 08          	mov    QWORD PTR [rbx+0x8],rcx
   253b1:	48 89 c3             	mov    rbx,rax
   253b4:	eb 8f                	jmp    25345 <JS_CallInternal+0x2865>
   253b6:	48 8b bd c8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x138]
   253bd:	48 8d 4b 10          	lea    rcx,[rbx+0x10]
   253c1:	48 8b 57 10          	mov    rdx,QWORD PTR [rdi+0x10]
   253c5:	48 8b 47 08          	mov    rax,QWORD PTR [rdi+0x8]
   253c9:	83 fa f6             	cmp    edx,0xfffffff6
   253cc:	76 04                	jbe    253d2 <JS_CallInternal+0x28f2>
   253ce:	83 40 fc 01          	add    DWORD PTR [rax-0x4],0x1
   253d2:	48 89 03             	mov    QWORD PTR [rbx],rax
   253d5:	48 89 53 08          	mov    QWORD PTR [rbx+0x8],rdx
   253d9:	48 89 cb             	mov    rbx,rcx
   253dc:	e9 64 ff ff ff       	jmp    25345 <JS_CallInternal+0x2865>
   253e1:	48 8b 85 d8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x128]
   253e8:	48 8b 8d c8 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x138]
   253ef:	4c 8d 6b 10          	lea    r13,[rbx+0x10]
   253f3:	48 8b 95 a8 fe ff ff 	mov    rdx,QWORD PTR [rbp-0x158]
   253fa:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   25401:	44 0f b7 40 38       	movzx  r8d,WORD PTR [rax+0x38]
   25406:	8b 85 bc fe ff ff    	mov    eax,DWORD PTR [rbp-0x144]
   2540c:	41 39 c0             	cmp    r8d,eax
   2540f:	89 c6                	mov    esi,eax
   25411:	44 0f 4f c0          	cmovg  r8d,eax
   25415:	e8 26 66 02 00       	call   4ba40 <js_build_mapped_arguments>
   2541a:	48 89 53 08          	mov    QWORD PTR [rbx+0x8],rdx
   2541e:	83 7b 08 06          	cmp    DWORD PTR [rbx+0x8],0x6
   25422:	48 89 03             	mov    QWORD PTR [rbx],rax
   25425:	0f 85 17 ff ff ff    	jne    25342 <JS_CallInternal+0x2862>
   2542b:	4c 89 eb             	mov    rbx,r13
   2542e:	4d 89 f4             	mov    r12,r14
   25431:	e9 4a de ff ff       	jmp    23280 <JS_CallInternal+0x7a0>
   25436:	48 8b 8d e8 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x118]
   2543d:	8b 85 bc fe ff ff    	mov    eax,DWORD PTR [rbp-0x144]
   25443:	4c 8d 6b 10          	lea    r13,[rbx+0x10]
   25447:	48 c7 85 58 ff ff ff 	mov    QWORD PTR [rbp-0xa8],0x0
   2544e:	00 00 00 00 
   25452:	48 8b 91 58 01 00 00 	mov    rdx,QWORD PTR [rcx+0x158]
   25459:	48 89 85 50 ff ff ff 	mov    QWORD PTR [rbp-0xb0],rax
   25460:	48 8b 81 50 01 00 00 	mov    rax,QWORD PTR [rcx+0x150]
   25467:	83 fa f6             	cmp    edx,0xfffffff6
   2546a:	76 04                	jbe    25470 <JS_CallInternal+0x2990>
   2546c:	83 40 fc 01          	add    DWORD PTR [rax-0x4],0x1
   25470:	48 8b 8d e8 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x118]
   25477:	48 89 85 60 ff ff ff 	mov    QWORD PTR [rbp-0xa0],rax
   2547e:	48 89 95 68 ff ff ff 	mov    QWORD PTR [rbp-0x98],rdx
   25485:	48 8b 81 60 01 00 00 	mov    rax,QWORD PTR [rcx+0x160]
   2548c:	83 b9 68 01 00 00 f6 	cmp    DWORD PTR [rcx+0x168],0xfffffff6
   25493:	48 89 85 70 ff ff ff 	mov    QWORD PTR [rbp-0x90],rax
   2549a:	76 04                	jbe    254a0 <JS_CallInternal+0x29c0>
   2549c:	83 40 fc 02          	add    DWORD PTR [rax-0x4],0x2
   254a0:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   254a7:	48 8d 8d 50 ff ff ff 	lea    rcx,[rbp-0xb0]
   254ae:	ba 08 00 00 00       	mov    edx,0x8
   254b3:	48 89 85 78 ff ff ff 	mov    QWORD PTR [rbp-0x88],rax
   254ba:	48 8b 77 38          	mov    rsi,QWORD PTR [rdi+0x38]
   254be:	83 46 fc 01          	add    DWORD PTR [rsi-0x4],0x1
   254c2:	e8 c9 0d 02 00       	call   46290 <JS_NewObjectFromShape>
   254c7:	49 89 c1             	mov    r9,rax
   254ca:	48 89 d1             	mov    rcx,rdx
   254cd:	83 fa 06             	cmp    edx,0x6
   254d0:	0f 84 13 73 00 00    	je     2c7e9 <JS_CallInternal+0x9d09>
   254d6:	8b bd bc fe ff ff    	mov    edi,DWORD PTR [rbp-0x144]
   254dc:	31 c0                	xor    eax,eax
   254de:	85 ff                	test   edi,edi
   254e0:	0f 8f 3b 6a 00 00    	jg     2bf21 <JS_CallInternal+0x9441>
   254e6:	49 89 41 30          	mov    QWORD PTR [r9+0x30],rax
   254ea:	8b 85 bc fe ff ff    	mov    eax,DWORD PTR [rbp-0x144]
   254f0:	41 89 41 38          	mov    DWORD PTR [r9+0x38],eax
   254f4:	4c 89 0b             	mov    QWORD PTR [rbx],r9
   254f7:	48 89 4b 08          	mov    QWORD PTR [rbx+0x8],rcx
   254fb:	4c 89 eb             	mov    rbx,r13
   254fe:	e9 42 fe ff ff       	jmp    25345 <JS_CallInternal+0x2865>
   25503:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2550a:	31 f6                	xor    esi,esi
   2550c:	4c 8d 6b 10          	lea    r13,[rbx+0x10]
   25510:	e8 7b d4 ff ff       	call   22990 <JS_GetScriptOrModuleName>
   25515:	85 c0                	test   eax,eax
   25517:	0f 84 88 67 00 00    	je     2bca5 <JS_CallInternal+0x91c5>
   2551d:	48 8b 8d e8 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x118]
   25524:	48 8b 91 b8 01 00 00 	mov    rdx,QWORD PTR [rcx+0x1b8]
   2552b:	48 81 c1 b0 01 00 00 	add    rcx,0x1b0
   25532:	48 39 d1             	cmp    rcx,rdx
   25535:	75 16                	jne    2554d <JS_CallInternal+0x2a6d>
   25537:	e9 c2 75 00 00       	jmp    2cafe <JS_CallInternal+0xa01e>
   2553c:	0f 1f 40 00          	nop    DWORD PTR [rax+0x0]
   25540:	48 8b 52 08          	mov    rdx,QWORD PTR [rdx+0x8]
   25544:	48 39 d1             	cmp    rcx,rdx
   25547:	0f 84 0e 67 00 00    	je     2bc5b <JS_CallInternal+0x917b>
   2554d:	3b 42 f8             	cmp    eax,DWORD PTR [rdx-0x8]
   25550:	75 ee                	jne    25540 <JS_CallInternal+0x2a60>
   25552:	48 83 ea 18          	sub    rdx,0x18
   25556:	3d f2 00 00 00       	cmp    eax,0xf2
   2555b:	0f 8f 03 67 00 00    	jg     2bc64 <JS_CallInternal+0x9184>
   25561:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   25568:	48 89 d6             	mov    rsi,rdx
   2556b:	e8 f0 d4 ff ff       	call   22a60 <JS_GetImportMeta>
   25570:	48 89 03             	mov    QWORD PTR [rbx],rax
   25573:	48 89 53 08          	mov    QWORD PTR [rbx+0x8],rdx
   25577:	83 fa 06             	cmp    edx,0x6
   2557a:	0f 85 c2 fd ff ff    	jne    25342 <JS_CallInternal+0x2862>
   25580:	e9 a6 fe ff ff       	jmp    2542b <JS_CallInternal+0x294b>
   25585:	0f 1f 00             	nop    DWORD PTR [rax]
   25588:	f3 0f 1e fa          	endbr64
   2558c:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   25593:	b9 01 00 00 00       	mov    ecx,0x1
   25598:	4c 8d 73 10          	lea    r14,[rbx+0x10]
   2559c:	48 8b 47 58          	mov    rax,QWORD PTR [rdi+0x58]
   255a0:	48 8b 70 10          	mov    rsi,QWORD PTR [rax+0x10]
   255a4:	48 8b 50 18          	mov    rdx,QWORD PTR [rax+0x18]
   255a8:	e8 63 12 02 00       	call   46810 <JS_NewObjectProtoClass>
   255ad:	48 89 53 08          	mov    QWORD PTR [rbx+0x8],rdx
   255b1:	83 7b 08 06          	cmp    DWORD PTR [rbx+0x8],0x6
   255b5:	48 89 03             	mov    QWORD PTR [rbx],rax
   255b8:	0f 84 0c 58 00 00    	je     2adca <JS_CallInternal+0x82ea>
   255be:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   255c3:	4c 89 f3             	mov    rbx,r14
   255c6:	49 83 c4 01          	add    r12,0x1
   255ca:	49 89 c5             	mov    r13,rax
   255cd:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   255d1:	ff e0                	jmp    rax
   255d3:	f3 0f 1e fa          	endbr64
   255d7:	48 c7 03 01 00 00 00 	mov    QWORD PTR [rbx],0x1
   255de:	49 83 c4 01          	add    r12,0x1
   255e2:	48 83 c3 10          	add    rbx,0x10
   255e6:	48 c7 43 f8 01 00 00 	mov    QWORD PTR [rbx-0x8],0x1
   255ed:	00 
   255ee:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   255f4:	49 89 c5             	mov    r13,rax
   255f7:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   255fb:	ff e0                	jmp    rax
   255fd:	f3 0f 1e fa          	endbr64
   25601:	48 c7 03 00 00 00 00 	mov    QWORD PTR [rbx],0x0
   25608:	49 83 c4 01          	add    r12,0x1
   2560c:	48 83 c3 10          	add    rbx,0x10
   25610:	48 c7 43 f8 01 00 00 	mov    QWORD PTR [rbx-0x8],0x1
   25617:	00 
   25618:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   2561e:	49 89 c5             	mov    r13,rax
   25621:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   25625:	ff e0                	jmp    rax
   25627:	f3 0f 1e fa          	endbr64
   2562b:	48 8b 85 d8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x128]
   25632:	f6 40 10 01          	test   BYTE PTR [rax+0x10],0x1
   25636:	0f 85 76 3f 00 00    	jne    295b2 <JS_CallInternal+0x6ad2>
   2563c:	83 bd 88 fe ff ff ff 	cmp    DWORD PTR [rbp-0x178],0xffffffff
   25643:	0f 85 9b 69 00 00    	jne    2bfe4 <JS_CallInternal+0x9504>
   25649:	48 8b 85 78 fe ff ff 	mov    rax,QWORD PTR [rbp-0x188]
   25650:	83 40 fc 01          	add    DWORD PTR [rax-0x4],0x1
   25654:	48 8b 85 88 fe ff ff 	mov    rax,QWORD PTR [rbp-0x178]
   2565b:	48 8b 8d 78 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x188]
   25662:	48 89 0b             	mov    QWORD PTR [rbx],rcx
   25665:	49 83 c4 01          	add    r12,0x1
   25669:	48 83 c3 10          	add    rbx,0x10
   2566d:	48 89 43 f8          	mov    QWORD PTR [rbx-0x8],rax
   25671:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   25677:	49 89 c5             	mov    r13,rax
   2567a:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   2567e:	ff e0                	jmp    rax
   25680:	f3 0f 1e fa          	endbr64
   25684:	48 8b 73 e0          	mov    rsi,QWORD PTR [rbx-0x20]
   25688:	48 8b 7b e8          	mov    rdi,QWORD PTR [rbx-0x18]
   2568c:	48 8b 4b f0          	mov    rcx,QWORD PTR [rbx-0x10]
   25690:	4c 8b 43 f8          	mov    r8,QWORD PTR [rbx-0x8]
   25694:	49 89 f5             	mov    r13,rsi
   25697:	49 89 fe             	mov    r14,rdi
   2569a:	83 ff ff             	cmp    edi,0xffffffff
   2569d:	0f 85 dd 42 00 00    	jne    29980 <JS_CallInternal+0x6ea0>
   256a3:	45 85 c0             	test   r8d,r8d
   256a6:	0f 85 d4 42 00 00    	jne    29980 <JS_CallInternal+0x6ea0>
   256ac:	66 83 7e 12 02       	cmp    WORD PTR [rsi+0x12],0x2
   256b1:	0f 85 c9 42 00 00    	jne    29980 <JS_CallInternal+0x6ea0>
   256b7:	3b 4e 38             	cmp    ecx,DWORD PTR [rsi+0x38]
   256ba:	0f 83 c0 42 00 00    	jae    29980 <JS_CallInternal+0x6ea0>
   256c0:	89 c8                	mov    eax,ecx
   256c2:	48 c1 e0 04          	shl    rax,0x4
   256c6:	48 03 46 30          	add    rax,QWORD PTR [rsi+0x30]
   256ca:	48 8b 08             	mov    rcx,QWORD PTR [rax]
   256cd:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
   256d1:	83 f8 f6             	cmp    eax,0xfffffff6
   256d4:	76 04                	jbe    256da <JS_CallInternal+0x2bfa>
   256d6:	83 41 fc 01          	add    DWORD PTR [rcx-0x4],0x1
   256da:	41 83 fe f6          	cmp    r14d,0xfffffff6
   256de:	76 13                	jbe    256f3 <JS_CallInternal+0x2c13>
   256e0:	41 8b 7d fc          	mov    edi,DWORD PTR [r13-0x4]
   256e4:	8d 57 ff             	lea    edx,[rdi-0x1]
   256e7:	41 89 55 fc          	mov    DWORD PTR [r13-0x4],edx
   256eb:	85 d2                	test   edx,edx
   256ed:	0f 8e e8 53 00 00    	jle    2aadb <JS_CallInternal+0x7ffb>
   256f3:	48 89 4b e0          	mov    QWORD PTR [rbx-0x20],rcx
   256f7:	49 83 c4 01          	add    r12,0x1
   256fb:	48 83 eb 10          	sub    rbx,0x10
   256ff:	48 89 43 f8          	mov    QWORD PTR [rbx-0x8],rax
   25703:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   25709:	49 89 c5             	mov    r13,rax
   2570c:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   25710:	ff e0                	jmp    rax
   25712:	f3 0f 1e fa          	endbr64
   25716:	48 8b 85 98 fe ff ff 	mov    rax,QWORD PTR [rbp-0x168]
   2571d:	f3 0f 6f 73 f0       	movdqu xmm6,XMMWORD PTR [rbx-0x10]
   25722:	48 83 eb 10          	sub    rbx,0x10
   25726:	48 8b 00             	mov    rax,QWORD PTR [rax]
   25729:	48 8b 40 18          	mov    rax,QWORD PTR [rax+0x18]
   2572d:	48 8b 50 08          	mov    rdx,QWORD PTR [rax+0x8]
   25731:	48 8b 30             	mov    rsi,QWORD PTR [rax]
   25734:	0f 11 30             	movups XMMWORD PTR [rax],xmm6
   25737:	83 fa f6             	cmp    edx,0xfffffff6
   2573a:	76 11                	jbe    2574d <JS_CallInternal+0x2c6d>
   2573c:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   2573f:	83 e8 01             	sub    eax,0x1
   25742:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   25745:	85 c0                	test   eax,eax
   25747:	0f 8e d1 4d 00 00    	jle    2a51e <JS_CallInternal+0x7a3e>
   2574d:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   25752:	49 83 c4 01          	add    r12,0x1
   25756:	49 89 c5             	mov    r13,rax
   25759:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   2575d:	ff e0                	jmp    rax
   2575f:	f3 0f 1e fa          	endbr64
   25763:	48 8b 85 98 fe ff ff 	mov    rax,QWORD PTR [rbp-0x168]
   2576a:	48 8d 4b 10          	lea    rcx,[rbx+0x10]
   2576e:	48 8b 40 10          	mov    rax,QWORD PTR [rax+0x10]
   25772:	48 8b 40 18          	mov    rax,QWORD PTR [rax+0x18]
   25776:	48 8b 10             	mov    rdx,QWORD PTR [rax]
   25779:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
   2577d:	83 f8 f6             	cmp    eax,0xfffffff6
   25780:	76 04                	jbe    25786 <JS_CallInternal+0x2ca6>
   25782:	83 42 fc 01          	add    DWORD PTR [rdx-0x4],0x1
   25786:	48 89 13             	mov    QWORD PTR [rbx],rdx
   25789:	49 83 c4 01          	add    r12,0x1
   2578d:	48 89 43 08          	mov    QWORD PTR [rbx+0x8],rax
   25791:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   25797:	48 89 cb             	mov    rbx,rcx
   2579a:	49 89 c5             	mov    r13,rax
   2579d:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   257a1:	ff e0                	jmp    rax
   257a3:	f3 0f 1e fa          	endbr64
   257a7:	48 8b 85 98 fe ff ff 	mov    rax,QWORD PTR [rbp-0x168]
   257ae:	48 8d 4b 10          	lea    rcx,[rbx+0x10]
   257b2:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
   257b6:	48 8b 40 18          	mov    rax,QWORD PTR [rax+0x18]
   257ba:	48 8b 10             	mov    rdx,QWORD PTR [rax]
   257bd:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
   257c1:	83 f8 f6             	cmp    eax,0xfffffff6
   257c4:	76 04                	jbe    257ca <JS_CallInternal+0x2cea>
   257c6:	83 42 fc 01          	add    DWORD PTR [rdx-0x4],0x1
   257ca:	48 89 13             	mov    QWORD PTR [rbx],rdx
   257cd:	49 83 c4 01          	add    r12,0x1
   257d1:	48 89 43 08          	mov    QWORD PTR [rbx+0x8],rax
   257d5:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   257db:	48 89 cb             	mov    rbx,rcx
   257de:	49 89 c5             	mov    r13,rax
   257e1:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   257e5:	ff e0                	jmp    rax
   257e7:	f3 0f 1e fa          	endbr64
   257eb:	48 8b 85 98 fe ff ff 	mov    rax,QWORD PTR [rbp-0x168]
   257f2:	48 8d 4b 10          	lea    rcx,[rbx+0x10]
   257f6:	48 8b 40 18          	mov    rax,QWORD PTR [rax+0x18]
   257fa:	48 8b 40 18          	mov    rax,QWORD PTR [rax+0x18]
   257fe:	48 8b 10             	mov    rdx,QWORD PTR [rax]
   25801:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
   25805:	83 f8 f6             	cmp    eax,0xfffffff6
   25808:	76 04                	jbe    2580e <JS_CallInternal+0x2d2e>
   2580a:	83 42 fc 01          	add    DWORD PTR [rdx-0x4],0x1
   2580e:	48 89 13             	mov    QWORD PTR [rbx],rdx
   25811:	49 83 c4 01          	add    r12,0x1
   25815:	48 89 43 08          	mov    QWORD PTR [rbx+0x8],rax
   25819:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   2581f:	48 89 cb             	mov    rbx,rcx
   25822:	49 89 c5             	mov    r13,rax
   25825:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   25829:	ff e0                	jmp    rax
   2582b:	f3 0f 1e fa          	endbr64
   2582f:	48 8b 85 98 fe ff ff 	mov    rax,QWORD PTR [rbp-0x168]
   25836:	48 8d 4b 10          	lea    rcx,[rbx+0x10]
   2583a:	48 8b 00             	mov    rax,QWORD PTR [rax]
   2583d:	48 8b 40 18          	mov    rax,QWORD PTR [rax+0x18]
   25841:	48 8b 10             	mov    rdx,QWORD PTR [rax]
   25844:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
   25848:	83 f8 f6             	cmp    eax,0xfffffff6
   2584b:	76 04                	jbe    25851 <JS_CallInternal+0x2d71>
   2584d:	83 42 fc 01          	add    DWORD PTR [rdx-0x4],0x1
   25851:	48 89 13             	mov    QWORD PTR [rbx],rdx
   25854:	49 83 c4 01          	add    r12,0x1
   25858:	48 89 43 08          	mov    QWORD PTR [rbx+0x8],rax
   2585c:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   25862:	48 89 cb             	mov    rbx,rcx
   25865:	49 89 c5             	mov    r13,rax
   25868:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   2586c:	ff e0                	jmp    rax
   2586e:	f3 0f 1e fa          	endbr64
   25872:	48 8b 43 f8          	mov    rax,QWORD PTR [rbx-0x8]
   25876:	48 8b 53 f0          	mov    rdx,QWORD PTR [rbx-0x10]
   2587a:	83 f8 f6             	cmp    eax,0xfffffff6
   2587d:	76 04                	jbe    25883 <JS_CallInternal+0x2da3>
   2587f:	83 42 fc 01          	add    DWORD PTR [rdx-0x4],0x1
   25883:	48 8b bd 90 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x170]
   2588a:	48 8b 4f 38          	mov    rcx,QWORD PTR [rdi+0x38]
   2588e:	48 8b 77 30          	mov    rsi,QWORD PTR [rdi+0x30]
   25892:	48 89 47 38          	mov    QWORD PTR [rdi+0x38],rax
   25896:	48 89 57 30          	mov    QWORD PTR [rdi+0x30],rdx
   2589a:	83 f9 f6             	cmp    ecx,0xfffffff6
   2589d:	76 11                	jbe    258b0 <JS_CallInternal+0x2dd0>
   2589f:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   258a2:	83 e8 01             	sub    eax,0x1
   258a5:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   258a8:	85 c0                	test   eax,eax
   258aa:	0f 8e 83 4c 00 00    	jle    2a533 <JS_CallInternal+0x7a53>
   258b0:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   258b5:	49 83 c4 01          	add    r12,0x1
   258b9:	49 89 c5             	mov    r13,rax
   258bc:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   258c0:	ff e0                	jmp    rax
   258c2:	f3 0f 1e fa          	endbr64
   258c6:	48 8b 43 f8          	mov    rax,QWORD PTR [rbx-0x8]
   258ca:	48 8b 53 f0          	mov    rdx,QWORD PTR [rbx-0x10]
   258ce:	83 f8 f6             	cmp    eax,0xfffffff6
   258d1:	76 04                	jbe    258d7 <JS_CallInternal+0x2df7>
   258d3:	83 42 fc 01          	add    DWORD PTR [rdx-0x4],0x1
   258d7:	48 8b bd 90 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x170]
   258de:	48 8b 4f 28          	mov    rcx,QWORD PTR [rdi+0x28]
   258e2:	48 8b 77 20          	mov    rsi,QWORD PTR [rdi+0x20]
   258e6:	48 89 47 28          	mov    QWORD PTR [rdi+0x28],rax
   258ea:	48 89 57 20          	mov    QWORD PTR [rdi+0x20],rdx
   258ee:	83 f9 f6             	cmp    ecx,0xfffffff6
   258f1:	76 11                	jbe    25904 <JS_CallInternal+0x2e24>
   258f3:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   258f6:	83 e8 01             	sub    eax,0x1
   258f9:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   258fc:	85 c0                	test   eax,eax
   258fe:	0f 8e 47 4c 00 00    	jle    2a54b <JS_CallInternal+0x7a6b>
   25904:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   25909:	49 83 c4 01          	add    r12,0x1
   2590d:	49 89 c5             	mov    r13,rax
   25910:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   25914:	ff e0                	jmp    rax
   25916:	f3 0f 1e fa          	endbr64
   2591a:	48 8b 43 f8          	mov    rax,QWORD PTR [rbx-0x8]
   2591e:	48 8b 53 f0          	mov    rdx,QWORD PTR [rbx-0x10]
   25922:	83 f8 f6             	cmp    eax,0xfffffff6
   25925:	76 04                	jbe    2592b <JS_CallInternal+0x2e4b>
   25927:	83 42 fc 01          	add    DWORD PTR [rdx-0x4],0x1
   2592b:	48 8b bd 90 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x170]
   25932:	48 8b 4f 18          	mov    rcx,QWORD PTR [rdi+0x18]
   25936:	48 8b 77 10          	mov    rsi,QWORD PTR [rdi+0x10]
   2593a:	48 89 47 18          	mov    QWORD PTR [rdi+0x18],rax
   2593e:	48 89 57 10          	mov    QWORD PTR [rdi+0x10],rdx
   25942:	83 f9 f6             	cmp    ecx,0xfffffff6
   25945:	76 11                	jbe    25958 <JS_CallInternal+0x2e78>
   25947:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   2594a:	83 e8 01             	sub    eax,0x1
   2594d:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   25950:	85 c0                	test   eax,eax
   25952:	0f 8e 0b 4c 00 00    	jle    2a563 <JS_CallInternal+0x7a83>
   25958:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   2595d:	49 83 c4 01          	add    r12,0x1
   25961:	49 89 c5             	mov    r13,rax
   25964:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   25968:	ff e0                	jmp    rax
   2596a:	f3 0f 1e fa          	endbr64
   2596e:	48 8b 43 f8          	mov    rax,QWORD PTR [rbx-0x8]
   25972:	48 8b 53 f0          	mov    rdx,QWORD PTR [rbx-0x10]
   25976:	83 f8 f6             	cmp    eax,0xfffffff6
   25979:	76 04                	jbe    2597f <JS_CallInternal+0x2e9f>
   2597b:	83 42 fc 01          	add    DWORD PTR [rdx-0x4],0x1
   2597f:	48 8b bd 90 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x170]
   25986:	48 8b 4f 08          	mov    rcx,QWORD PTR [rdi+0x8]
   2598a:	48 8b 37             	mov    rsi,QWORD PTR [rdi]
   2598d:	48 89 47 08          	mov    QWORD PTR [rdi+0x8],rax
   25991:	48 89 17             	mov    QWORD PTR [rdi],rdx
   25994:	83 f9 f6             	cmp    ecx,0xfffffff6
   25997:	76 11                	jbe    259aa <JS_CallInternal+0x2eca>
   25999:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   2599c:	83 e8 01             	sub    eax,0x1
   2599f:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   259a2:	85 c0                	test   eax,eax
   259a4:	0f 8e 2d 4d 00 00    	jle    2a6d7 <JS_CallInternal+0x7bf7>
   259aa:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   259af:	49 83 c4 01          	add    r12,0x1
   259b3:	49 89 c5             	mov    r13,rax
   259b6:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   259ba:	ff e0                	jmp    rax
   259bc:	f3 0f 1e fa          	endbr64
   259c0:	48 8b 85 90 fe ff ff 	mov    rax,QWORD PTR [rbp-0x170]
   259c7:	f3 0f 6f 4b f0       	movdqu xmm1,XMMWORD PTR [rbx-0x10]
   259cc:	48 83 eb 10          	sub    rbx,0x10
   259d0:	48 8b 50 08          	mov    rdx,QWORD PTR [rax+0x8]
   259d4:	48 8b 30             	mov    rsi,QWORD PTR [rax]
   259d7:	0f 11 08             	movups XMMWORD PTR [rax],xmm1
   259da:	83 fa f6             	cmp    edx,0xfffffff6
   259dd:	76 11                	jbe    259f0 <JS_CallInternal+0x2f10>
   259df:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   259e2:	83 e8 01             	sub    eax,0x1
   259e5:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   259e8:	85 c0                	test   eax,eax
   259ea:	0f 8e d2 4c 00 00    	jle    2a6c2 <JS_CallInternal+0x7be2>
   259f0:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   259f5:	49 83 c4 01          	add    r12,0x1
   259f9:	49 89 c5             	mov    r13,rax
   259fc:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   25a00:	ff e0                	jmp    rax
   25a02:	f3 0f 1e fa          	endbr64
   25a06:	48 8b 85 90 fe ff ff 	mov    rax,QWORD PTR [rbp-0x170]
   25a0d:	f3 0f 6f 53 f0       	movdqu xmm2,XMMWORD PTR [rbx-0x10]
   25a12:	48 83 eb 10          	sub    rbx,0x10
   25a16:	48 8b 50 28          	mov    rdx,QWORD PTR [rax+0x28]
   25a1a:	48 8b 70 20          	mov    rsi,QWORD PTR [rax+0x20]
   25a1e:	0f 11 50 20          	movups XMMWORD PTR [rax+0x20],xmm2
   25a22:	83 fa f6             	cmp    edx,0xfffffff6
   25a25:	76 11                	jbe    25a38 <JS_CallInternal+0x2f58>
   25a27:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   25a2a:	83 e8 01             	sub    eax,0x1
   25a2d:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   25a30:	85 c0                	test   eax,eax
   25a32:	0f 8e 75 4c 00 00    	jle    2a6ad <JS_CallInternal+0x7bcd>
   25a38:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   25a3d:	49 83 c4 01          	add    r12,0x1
   25a41:	49 89 c5             	mov    r13,rax
   25a44:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   25a48:	ff e0                	jmp    rax
   25a4a:	f3 0f 1e fa          	endbr64
   25a4e:	48 8b 85 90 fe ff ff 	mov    rax,QWORD PTR [rbp-0x170]
   25a55:	48 8d 4b 10          	lea    rcx,[rbx+0x10]
   25a59:	48 8b 50 20          	mov    rdx,QWORD PTR [rax+0x20]
   25a5d:	48 8b 40 28          	mov    rax,QWORD PTR [rax+0x28]
   25a61:	83 f8 f6             	cmp    eax,0xfffffff6
   25a64:	76 04                	jbe    25a6a <JS_CallInternal+0x2f8a>
   25a66:	83 42 fc 01          	add    DWORD PTR [rdx-0x4],0x1
   25a6a:	48 89 13             	mov    QWORD PTR [rbx],rdx
   25a6d:	49 83 c4 01          	add    r12,0x1
   25a71:	48 89 43 08          	mov    QWORD PTR [rbx+0x8],rax
   25a75:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   25a7b:	48 89 cb             	mov    rbx,rcx
   25a7e:	49 89 c5             	mov    r13,rax
   25a81:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   25a85:	ff e0                	jmp    rax
   25a87:	f3 0f 1e fa          	endbr64
   25a8b:	48 8b 85 90 fe ff ff 	mov    rax,QWORD PTR [rbp-0x170]
   25a92:	48 8d 4b 10          	lea    rcx,[rbx+0x10]
   25a96:	48 8b 50 10          	mov    rdx,QWORD PTR [rax+0x10]
   25a9a:	48 8b 40 18          	mov    rax,QWORD PTR [rax+0x18]
   25a9e:	83 f8 f6             	cmp    eax,0xfffffff6
   25aa1:	76 04                	jbe    25aa7 <JS_CallInternal+0x2fc7>
   25aa3:	83 42 fc 01          	add    DWORD PTR [rdx-0x4],0x1
   25aa7:	48 89 13             	mov    QWORD PTR [rbx],rdx
   25aaa:	49 83 c4 01          	add    r12,0x1
   25aae:	48 89 43 08          	mov    QWORD PTR [rbx+0x8],rax
   25ab2:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   25ab8:	48 89 cb             	mov    rbx,rcx
   25abb:	49 89 c5             	mov    r13,rax
   25abe:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   25ac2:	ff e0                	jmp    rax
   25ac4:	f3 0f 1e fa          	endbr64
   25ac8:	48 8b 85 90 fe ff ff 	mov    rax,QWORD PTR [rbp-0x170]
   25acf:	48 8d 4b 10          	lea    rcx,[rbx+0x10]
   25ad3:	48 8b 50 30          	mov    rdx,QWORD PTR [rax+0x30]
   25ad7:	48 8b 40 38          	mov    rax,QWORD PTR [rax+0x38]
   25adb:	83 f8 f6             	cmp    eax,0xfffffff6
   25ade:	76 04                	jbe    25ae4 <JS_CallInternal+0x3004>
   25ae0:	83 42 fc 01          	add    DWORD PTR [rdx-0x4],0x1
   25ae4:	48 89 13             	mov    QWORD PTR [rbx],rdx
   25ae7:	49 83 c4 01          	add    r12,0x1
   25aeb:	48 89 43 08          	mov    QWORD PTR [rbx+0x8],rax
   25aef:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   25af5:	48 89 cb             	mov    rbx,rcx
   25af8:	49 89 c5             	mov    r13,rax
   25afb:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   25aff:	ff e0                	jmp    rax
   25b01:	f3 0f 1e fa          	endbr64
   25b05:	48 8b 85 90 fe ff ff 	mov    rax,QWORD PTR [rbp-0x170]
   25b0c:	f3 0f 6f 6b f0       	movdqu xmm5,XMMWORD PTR [rbx-0x10]
   25b11:	48 83 eb 10          	sub    rbx,0x10
   25b15:	48 8b 50 38          	mov    rdx,QWORD PTR [rax+0x38]
   25b19:	48 8b 70 30          	mov    rsi,QWORD PTR [rax+0x30]
   25b1d:	0f 11 68 30          	movups XMMWORD PTR [rax+0x30],xmm5
   25b21:	83 fa f6             	cmp    edx,0xfffffff6
   25b24:	76 11                	jbe    25b37 <JS_CallInternal+0x3057>
   25b26:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   25b29:	83 e8 01             	sub    eax,0x1
   25b2c:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   25b2f:	85 c0                	test   eax,eax
   25b31:	0f 8e 61 4b 00 00    	jle    2a698 <JS_CallInternal+0x7bb8>
   25b37:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   25b3c:	49 83 c4 01          	add    r12,0x1
   25b40:	49 89 c5             	mov    r13,rax
   25b43:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   25b47:	ff e0                	jmp    rax
   25b49:	f3 0f 1e fa          	endbr64
   25b4d:	48 8b 85 90 fe ff ff 	mov    rax,QWORD PTR [rbp-0x170]
   25b54:	f3 0f 6f 63 f0       	movdqu xmm4,XMMWORD PTR [rbx-0x10]
   25b59:	48 83 eb 10          	sub    rbx,0x10
   25b5d:	48 8b 50 18          	mov    rdx,QWORD PTR [rax+0x18]
   25b61:	48 8b 70 10          	mov    rsi,QWORD PTR [rax+0x10]
   25b65:	0f 11 60 10          	movups XMMWORD PTR [rax+0x10],xmm4
   25b69:	83 fa f6             	cmp    edx,0xfffffff6
   25b6c:	76 11                	jbe    25b7f <JS_CallInternal+0x309f>
   25b6e:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   25b71:	83 e8 01             	sub    eax,0x1
   25b74:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   25b77:	85 c0                	test   eax,eax
   25b79:	0f 8e bc 4a 00 00    	jle    2a63b <JS_CallInternal+0x7b5b>
   25b7f:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   25b84:	49 83 c4 01          	add    r12,0x1
   25b88:	49 89 c5             	mov    r13,rax
   25b8b:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   25b8f:	ff e0                	jmp    rax
   25b91:	f3 0f 1e fa          	endbr64
   25b95:	41 0f b7 04 24       	movzx  eax,WORD PTR [r12]
   25b9a:	48 8b 8d 98 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x168]
   25ba1:	48 8b 04 c1          	mov    rax,QWORD PTR [rcx+rax*8]
   25ba5:	48 8b 40 18          	mov    rax,QWORD PTR [rax+0x18]
   25ba9:	48 8b 10             	mov    rdx,QWORD PTR [rax]
   25bac:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
   25bb0:	83 f8 f6             	cmp    eax,0xfffffff6
   25bb3:	76 04                	jbe    25bb9 <JS_CallInternal+0x30d9>
   25bb5:	83 42 fc 01          	add    DWORD PTR [rdx-0x4],0x1
   25bb9:	48 89 13             	mov    QWORD PTR [rbx],rdx
   25bbc:	49 83 c4 03          	add    r12,0x3
   25bc0:	48 83 c3 10          	add    rbx,0x10
   25bc4:	48 89 43 f8          	mov    QWORD PTR [rbx-0x8],rax
   25bc8:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   25bce:	49 89 c5             	mov    r13,rax
   25bd1:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   25bd5:	ff e0                	jmp    rax
   25bd7:	f3 0f 1e fa          	endbr64
   25bdb:	48 8b 53 f8          	mov    rdx,QWORD PTR [rbx-0x8]
   25bdf:	48 8b 4b f0          	mov    rcx,QWORD PTR [rbx-0x10]
   25be3:	83 fa f6             	cmp    edx,0xfffffff6
   25be6:	76 04                	jbe    25bec <JS_CallInternal+0x310c>
   25be8:	83 41 fc 01          	add    DWORD PTR [rcx-0x4],0x1
   25bec:	48 8b 85 98 fe ff ff 	mov    rax,QWORD PTR [rbp-0x168]
   25bf3:	48 8b 40 18          	mov    rax,QWORD PTR [rax+0x18]
   25bf7:	48 8b 40 18          	mov    rax,QWORD PTR [rax+0x18]
   25bfb:	4c 8b 40 08          	mov    r8,QWORD PTR [rax+0x8]
   25bff:	48 8b 30             	mov    rsi,QWORD PTR [rax]
   25c02:	48 89 50 08          	mov    QWORD PTR [rax+0x8],rdx
   25c06:	48 89 08             	mov    QWORD PTR [rax],rcx
   25c09:	41 83 f8 f6          	cmp    r8d,0xfffffff6
   25c0d:	76 11                	jbe    25c20 <JS_CallInternal+0x3140>
   25c0f:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   25c12:	83 e8 01             	sub    eax,0x1
   25c15:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   25c18:	85 c0                	test   eax,eax
   25c1a:	0f 8e 30 4a 00 00    	jle    2a650 <JS_CallInternal+0x7b70>
   25c20:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   25c25:	49 83 c4 01          	add    r12,0x1
   25c29:	49 89 c5             	mov    r13,rax
   25c2c:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   25c30:	ff e0                	jmp    rax
   25c32:	f3 0f 1e fa          	endbr64
   25c36:	48 8b 53 f8          	mov    rdx,QWORD PTR [rbx-0x8]
   25c3a:	48 8b 4b f0          	mov    rcx,QWORD PTR [rbx-0x10]
   25c3e:	83 fa f6             	cmp    edx,0xfffffff6
   25c41:	76 04                	jbe    25c47 <JS_CallInternal+0x3167>
   25c43:	83 41 fc 01          	add    DWORD PTR [rcx-0x4],0x1
   25c47:	48 8b 85 98 fe ff ff 	mov    rax,QWORD PTR [rbp-0x168]
   25c4e:	48 8b 40 10          	mov    rax,QWORD PTR [rax+0x10]
   25c52:	48 8b 40 18          	mov    rax,QWORD PTR [rax+0x18]
   25c56:	4c 8b 40 08          	mov    r8,QWORD PTR [rax+0x8]
   25c5a:	48 8b 30             	mov    rsi,QWORD PTR [rax]
   25c5d:	48 89 50 08          	mov    QWORD PTR [rax+0x8],rdx
   25c61:	48 89 08             	mov    QWORD PTR [rax],rcx
   25c64:	41 83 f8 f6          	cmp    r8d,0xfffffff6
   25c68:	76 11                	jbe    25c7b <JS_CallInternal+0x319b>
   25c6a:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   25c6d:	83 e8 01             	sub    eax,0x1
   25c70:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   25c73:	85 c0                	test   eax,eax
   25c75:	0f 8e ed 49 00 00    	jle    2a668 <JS_CallInternal+0x7b88>
   25c7b:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   25c80:	49 83 c4 01          	add    r12,0x1
   25c84:	49 89 c5             	mov    r13,rax
   25c87:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   25c8b:	ff e0                	jmp    rax
   25c8d:	f3 0f 1e fa          	endbr64
   25c91:	48 8b 53 f8          	mov    rdx,QWORD PTR [rbx-0x8]
   25c95:	48 8b 4b f0          	mov    rcx,QWORD PTR [rbx-0x10]
   25c99:	83 fa f6             	cmp    edx,0xfffffff6
   25c9c:	76 04                	jbe    25ca2 <JS_CallInternal+0x31c2>
   25c9e:	83 41 fc 01          	add    DWORD PTR [rcx-0x4],0x1
   25ca2:	48 8b 85 98 fe ff ff 	mov    rax,QWORD PTR [rbp-0x168]
   25ca9:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
   25cad:	48 8b 40 18          	mov    rax,QWORD PTR [rax+0x18]
   25cb1:	4c 8b 40 08          	mov    r8,QWORD PTR [rax+0x8]
   25cb5:	48 8b 30             	mov    rsi,QWORD PTR [rax]
   25cb8:	48 89 50 08          	mov    QWORD PTR [rax+0x8],rdx
   25cbc:	48 89 08             	mov    QWORD PTR [rax],rcx
   25cbf:	41 83 f8 f6          	cmp    r8d,0xfffffff6
   25cc3:	76 11                	jbe    25cd6 <JS_CallInternal+0x31f6>
   25cc5:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   25cc8:	83 e8 01             	sub    eax,0x1
   25ccb:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   25cce:	85 c0                	test   eax,eax
   25cd0:	0f 8e aa 49 00 00    	jle    2a680 <JS_CallInternal+0x7ba0>
   25cd6:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   25cdb:	49 83 c4 01          	add    r12,0x1
   25cdf:	49 89 c5             	mov    r13,rax
   25ce2:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   25ce6:	ff e0                	jmp    rax
   25ce8:	f3 0f 1e fa          	endbr64
   25cec:	48 8b 53 f8          	mov    rdx,QWORD PTR [rbx-0x8]
   25cf0:	48 8b 4b f0          	mov    rcx,QWORD PTR [rbx-0x10]
   25cf4:	83 fa f6             	cmp    edx,0xfffffff6
   25cf7:	76 04                	jbe    25cfd <JS_CallInternal+0x321d>
   25cf9:	83 41 fc 01          	add    DWORD PTR [rcx-0x4],0x1
   25cfd:	48 8b 85 98 fe ff ff 	mov    rax,QWORD PTR [rbp-0x168]
   25d04:	48 8b 00             	mov    rax,QWORD PTR [rax]
   25d07:	48 8b 40 18          	mov    rax,QWORD PTR [rax+0x18]
   25d0b:	4c 8b 40 08          	mov    r8,QWORD PTR [rax+0x8]
   25d0f:	48 8b 30             	mov    rsi,QWORD PTR [rax]
   25d12:	48 89 50 08          	mov    QWORD PTR [rax+0x8],rdx
   25d16:	48 89 08             	mov    QWORD PTR [rax],rcx
   25d19:	41 83 f8 f6          	cmp    r8d,0xfffffff6
   25d1d:	76 11                	jbe    25d30 <JS_CallInternal+0x3250>
   25d1f:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   25d22:	83 e8 01             	sub    eax,0x1
   25d25:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   25d28:	85 c0                	test   eax,eax
   25d2a:	0f 8e 8a 48 00 00    	jle    2a5ba <JS_CallInternal+0x7ada>
   25d30:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   25d35:	49 83 c4 01          	add    r12,0x1
   25d39:	49 89 c5             	mov    r13,rax
   25d3c:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   25d40:	ff e0                	jmp    rax
   25d42:	f3 0f 1e fa          	endbr64
   25d46:	48 8b 85 98 fe ff ff 	mov    rax,QWORD PTR [rbp-0x168]
   25d4d:	f3 0f 6f 5b f0       	movdqu xmm3,XMMWORD PTR [rbx-0x10]
   25d52:	48 83 eb 10          	sub    rbx,0x10
   25d56:	48 8b 40 10          	mov    rax,QWORD PTR [rax+0x10]
   25d5a:	48 8b 40 18          	mov    rax,QWORD PTR [rax+0x18]
   25d5e:	48 8b 50 08          	mov    rdx,QWORD PTR [rax+0x8]
   25d62:	48 8b 30             	mov    rsi,QWORD PTR [rax]
   25d65:	0f 11 18             	movups XMMWORD PTR [rax],xmm3
   25d68:	83 fa f6             	cmp    edx,0xfffffff6
   25d6b:	76 11                	jbe    25d7e <JS_CallInternal+0x329e>
   25d6d:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   25d70:	83 e8 01             	sub    eax,0x1
   25d73:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   25d76:	85 c0                	test   eax,eax
   25d78:	0f 8e 69 48 00 00    	jle    2a5e7 <JS_CallInternal+0x7b07>
   25d7e:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   25d83:	49 83 c4 01          	add    r12,0x1
   25d87:	49 89 c5             	mov    r13,rax
   25d8a:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   25d8e:	ff e0                	jmp    rax
   25d90:	f3 0f 1e fa          	endbr64
   25d94:	48 8b 85 98 fe ff ff 	mov    rax,QWORD PTR [rbp-0x168]
   25d9b:	f3 0f 6f 4b f0       	movdqu xmm1,XMMWORD PTR [rbx-0x10]
   25da0:	48 83 eb 10          	sub    rbx,0x10
   25da4:	48 8b 40 18          	mov    rax,QWORD PTR [rax+0x18]
   25da8:	48 8b 40 18          	mov    rax,QWORD PTR [rax+0x18]
   25dac:	48 8b 50 08          	mov    rdx,QWORD PTR [rax+0x8]
   25db0:	48 8b 30             	mov    rsi,QWORD PTR [rax]
   25db3:	0f 11 08             	movups XMMWORD PTR [rax],xmm1
   25db6:	83 fa f6             	cmp    edx,0xfffffff6
   25db9:	76 11                	jbe    25dcc <JS_CallInternal+0x32ec>
   25dbb:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   25dbe:	83 e8 01             	sub    eax,0x1
   25dc1:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   25dc4:	85 c0                	test   eax,eax
   25dc6:	0f 8e 06 48 00 00    	jle    2a5d2 <JS_CallInternal+0x7af2>
   25dcc:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   25dd1:	49 83 c4 01          	add    r12,0x1
   25dd5:	49 89 c5             	mov    r13,rax
   25dd8:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   25ddc:	ff e0                	jmp    rax
   25dde:	f3 0f 1e fa          	endbr64
   25de2:	48 8b 85 98 fe ff ff 	mov    rax,QWORD PTR [rbp-0x168]
   25de9:	f3 0f 6f 7b f0       	movdqu xmm7,XMMWORD PTR [rbx-0x10]
   25dee:	48 83 eb 10          	sub    rbx,0x10
   25df2:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
   25df6:	48 8b 40 18          	mov    rax,QWORD PTR [rax+0x18]
   25dfa:	48 8b 50 08          	mov    rdx,QWORD PTR [rax+0x8]
   25dfe:	48 8b 30             	mov    rsi,QWORD PTR [rax]
   25e01:	0f 11 38             	movups XMMWORD PTR [rax],xmm7
   25e04:	83 fa f6             	cmp    edx,0xfffffff6
   25e07:	76 11                	jbe    25e1a <JS_CallInternal+0x333a>
   25e09:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   25e0c:	83 e8 01             	sub    eax,0x1
   25e0f:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   25e12:	85 c0                	test   eax,eax
   25e14:	0f 8e e2 47 00 00    	jle    2a5fc <JS_CallInternal+0x7b1c>
   25e1a:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   25e1f:	49 83 c4 01          	add    r12,0x1
   25e23:	49 89 c5             	mov    r13,rax
   25e26:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   25e2a:	ff e0                	jmp    rax
   25e2c:	f3 0f 1e fa          	endbr64
   25e30:	48 8b 53 f8          	mov    rdx,QWORD PTR [rbx-0x8]
   25e34:	41 0f b7 04 24       	movzx  eax,WORD PTR [r12]
   25e39:	48 8b 7b f0          	mov    rdi,QWORD PTR [rbx-0x10]
   25e3d:	83 fa f6             	cmp    edx,0xfffffff6
   25e40:	76 04                	jbe    25e46 <JS_CallInternal+0x3366>
   25e42:	83 47 fc 01          	add    DWORD PTR [rdi-0x4],0x1
   25e46:	48 8b 8d 98 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x168]
   25e4d:	48 8b 04 c1          	mov    rax,QWORD PTR [rcx+rax*8]
   25e51:	48 8b 40 18          	mov    rax,QWORD PTR [rax+0x18]
   25e55:	48 8b 48 08          	mov    rcx,QWORD PTR [rax+0x8]
   25e59:	48 8b 30             	mov    rsi,QWORD PTR [rax]
   25e5c:	48 89 50 08          	mov    QWORD PTR [rax+0x8],rdx
   25e60:	48 89 38             	mov    QWORD PTR [rax],rdi
   25e63:	83 f9 f6             	cmp    ecx,0xfffffff6
   25e66:	76 11                	jbe    25e79 <JS_CallInternal+0x3399>
   25e68:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   25e6b:	83 e8 01             	sub    eax,0x1
   25e6e:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   25e71:	85 c0                	test   eax,eax
   25e73:	0f 8e 12 4d 00 00    	jle    2ab8b <JS_CallInternal+0x80ab>
   25e79:	41 0f b6 44 24 02    	movzx  eax,BYTE PTR [r12+0x2]
   25e7f:	49 83 c4 03          	add    r12,0x3
   25e83:	49 89 c5             	mov    r13,rax
   25e86:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   25e8a:	ff e0                	jmp    rax
   25e8c:	f3 0f 1e fa          	endbr64
   25e90:	41 0f b7 04 24       	movzx  eax,WORD PTR [r12]
   25e95:	48 8b bd 98 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x168]
   25e9c:	4d 8d 6c 24 02       	lea    r13,[r12+0x2]
   25ea1:	48 8d 0c c5 00 00 00 	lea    rcx,[rax*8+0x0]
   25ea8:	00 
   25ea9:	48 8b 04 c7          	mov    rax,QWORD PTR [rdi+rax*8]
   25ead:	48 8b 40 18          	mov    rax,QWORD PTR [rax+0x18]
   25eb1:	48 8b 10             	mov    rdx,QWORD PTR [rax]
   25eb4:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
   25eb8:	83 f8 04             	cmp    eax,0x4
   25ebb:	0f 84 22 4f 00 00    	je     2ade3 <JS_CallInternal+0x8303>
   25ec1:	83 f8 f6             	cmp    eax,0xfffffff6
   25ec4:	76 04                	jbe    25eca <JS_CallInternal+0x33ea>
   25ec6:	83 42 fc 01          	add    DWORD PTR [rdx-0x4],0x1
   25eca:	48 89 13             	mov    QWORD PTR [rbx],rdx
   25ecd:	49 83 c4 03          	add    r12,0x3
   25ed1:	48 83 c3 10          	add    rbx,0x10
   25ed5:	48 89 43 f8          	mov    QWORD PTR [rbx-0x8],rax
   25ed9:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   25edf:	49 89 c5             	mov    r13,rax
   25ee2:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   25ee6:	ff e0                	jmp    rax
   25ee8:	f3 0f 1e fa          	endbr64
   25eec:	41 0f b7 04 24       	movzx  eax,WORD PTR [r12]
   25ef1:	48 8b 8d 98 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x168]
   25ef8:	f3 0f 6f 63 f0       	movdqu xmm4,XMMWORD PTR [rbx-0x10]
   25efd:	48 8b 04 c1          	mov    rax,QWORD PTR [rcx+rax*8]
   25f01:	48 8b 40 18          	mov    rax,QWORD PTR [rax+0x18]
   25f05:	48 8b 50 08          	mov    rdx,QWORD PTR [rax+0x8]
   25f09:	48 8b 30             	mov    rsi,QWORD PTR [rax]
   25f0c:	0f 11 20             	movups XMMWORD PTR [rax],xmm4
   25f0f:	83 fa f6             	cmp    edx,0xfffffff6
   25f12:	76 11                	jbe    25f25 <JS_CallInternal+0x3445>
   25f14:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   25f17:	83 e8 01             	sub    eax,0x1
   25f1a:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   25f1d:	85 c0                	test   eax,eax
   25f1f:	0f 8e 7e 4c 00 00    	jle    2aba3 <JS_CallInternal+0x80c3>
   25f25:	41 0f b6 44 24 02    	movzx  eax,BYTE PTR [r12+0x2]
   25f2b:	48 83 eb 10          	sub    rbx,0x10
   25f2f:	49 83 c4 03          	add    r12,0x3
   25f33:	49 89 c5             	mov    r13,rax
   25f36:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   25f3a:	ff e0                	jmp    rax
   25f3c:	f3 0f 1e fa          	endbr64
   25f40:	e9 61 cf ff ff       	jmp    22ea6 <JS_CallInternal+0x3c6>
   25f45:	f3 0f 1e fa          	endbr64
   25f49:	e9 58 cf ff ff       	jmp    22ea6 <JS_CallInternal+0x3c6>
   25f4e:	f3 0f 1e fa          	endbr64
   25f52:	41 8b 04 24          	mov    eax,DWORD PTR [r12]
   25f56:	48 8b 8d d8 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x128]
   25f5d:	48 c1 e0 04          	shl    rax,0x4
   25f61:	48 03 41 50          	add    rax,QWORD PTR [rcx+0x50]
   25f65:	48 8b 50 08          	mov    rdx,QWORD PTR [rax+0x8]
   25f69:	48 8b 30             	mov    rsi,QWORD PTR [rax]
   25f6c:	83 fa f6             	cmp    edx,0xfffffff6
   25f6f:	76 04                	jbe    25f75 <JS_CallInternal+0x3495>
   25f71:	83 46 fc 01          	add    DWORD PTR [rsi-0x4],0x1
   25f75:	4c 8b 85 c8 fe ff ff 	mov    r8,QWORD PTR [rbp-0x138]
   25f7c:	45 31 c9             	xor    r9d,r9d
   25f7f:	4d 8d 6c 24 04       	lea    r13,[r12+0x4]
   25f84:	4c 8d 73 10          	lea    r14,[rbx+0x10]
   25f88:	48 8b 8d 98 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x168]
   25f8f:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   25f96:	e8 15 67 02 00       	call   4c6b0 <js_closure>
   25f9b:	48 89 53 08          	mov    QWORD PTR [rbx+0x8],rdx
   25f9f:	83 7b 08 06          	cmp    DWORD PTR [rbx+0x8],0x6
   25fa3:	48 89 03             	mov    QWORD PTR [rbx],rax
   25fa6:	0f 84 fc 4c 00 00    	je     2aca8 <JS_CallInternal+0x81c8>
   25fac:	41 0f b6 44 24 04    	movzx  eax,BYTE PTR [r12+0x4]
   25fb2:	4c 89 f3             	mov    rbx,r14
   25fb5:	49 83 c4 05          	add    r12,0x5
   25fb9:	49 89 c5             	mov    r13,rax
   25fbc:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   25fc0:	ff e0                	jmp    rax
   25fc2:	f3 0f 1e fa          	endbr64
   25fc6:	f3 0f 6f 4b c0       	movdqu xmm1,XMMWORD PTR [rbx-0x40]
   25fcb:	f3 0f 6f 43 d0       	movdqu xmm0,XMMWORD PTR [rbx-0x30]
   25fd0:	49 83 c4 01          	add    r12,0x1
   25fd4:	f3 0f 6f 6b e0       	movdqu xmm5,XMMWORD PTR [rbx-0x20]
   25fd9:	f3 0f 6f 73 f0       	movdqu xmm6,XMMWORD PTR [rbx-0x10]
   25fde:	0f 11 4b e0          	movups XMMWORD PTR [rbx-0x20],xmm1
   25fe2:	0f 11 6b c0          	movups XMMWORD PTR [rbx-0x40],xmm5
   25fe6:	0f 11 73 d0          	movups XMMWORD PTR [rbx-0x30],xmm6
   25fea:	0f 11 43 f0          	movups XMMWORD PTR [rbx-0x10],xmm0
   25fee:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   25ff4:	49 89 c5             	mov    r13,rax
   25ff7:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   25ffb:	ff e0                	jmp    rax
   25ffd:	f3 0f 1e fa          	endbr64
   26001:	f3 0f 6f 43 e0       	movdqu xmm0,XMMWORD PTR [rbx-0x20]
   26006:	f3 0f 6f 53 f0       	movdqu xmm2,XMMWORD PTR [rbx-0x10]
   2600b:	49 83 c4 01          	add    r12,0x1
   2600f:	0f 11 53 e0          	movups XMMWORD PTR [rbx-0x20],xmm2
   26013:	0f 11 43 f0          	movups XMMWORD PTR [rbx-0x10],xmm0
   26017:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   2601d:	49 89 c5             	mov    r13,rax
   26020:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   26024:	ff e0                	jmp    rax
   26026:	f3 0f 1e fa          	endbr64
   2602a:	f3 0f 6f 43 e0       	movdqu xmm0,XMMWORD PTR [rbx-0x20]
   2602f:	f3 0f 6f 5b d0       	movdqu xmm3,XMMWORD PTR [rbx-0x30]
   26034:	49 83 c4 01          	add    r12,0x1
   26038:	f3 0f 6f 4b c0       	movdqu xmm1,XMMWORD PTR [rbx-0x40]
   2603d:	f3 0f 6f 63 b0       	movdqu xmm4,XMMWORD PTR [rbx-0x50]
   26042:	0f 11 5b e0          	movups XMMWORD PTR [rbx-0x20],xmm3
   26046:	0f 11 4b d0          	movups XMMWORD PTR [rbx-0x30],xmm1
   2604a:	0f 11 63 c0          	movups XMMWORD PTR [rbx-0x40],xmm4
   2604e:	0f 11 43 b0          	movups XMMWORD PTR [rbx-0x50],xmm0
   26052:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   26058:	49 89 c5             	mov    r13,rax
   2605b:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   2605f:	ff e0                	jmp    rax
   26061:	f3 0f 1e fa          	endbr64
   26065:	f3 0f 6f 43 e0       	movdqu xmm0,XMMWORD PTR [rbx-0x20]
   2606a:	f3 0f 6f 73 d0       	movdqu xmm6,XMMWORD PTR [rbx-0x30]
   2606f:	49 83 c4 01          	add    r12,0x1
   26073:	f3 0f 6f 7b c0       	movdqu xmm7,XMMWORD PTR [rbx-0x40]
   26078:	0f 11 73 e0          	movups XMMWORD PTR [rbx-0x20],xmm6
   2607c:	0f 11 7b d0          	movups XMMWORD PTR [rbx-0x30],xmm7
   26080:	0f 11 43 c0          	movups XMMWORD PTR [rbx-0x40],xmm0
   26084:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   2608a:	49 89 c5             	mov    r13,rax
   2608d:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   26091:	ff e0                	jmp    rax
   26093:	f3 0f 1e fa          	endbr64
   26097:	f3 0f 6f 43 f0       	movdqu xmm0,XMMWORD PTR [rbx-0x10]
   2609c:	f3 0f 6f 53 e0       	movdqu xmm2,XMMWORD PTR [rbx-0x20]
   260a1:	49 83 c4 01          	add    r12,0x1
   260a5:	f3 0f 6f 6b d0       	movdqu xmm5,XMMWORD PTR [rbx-0x30]
   260aa:	0f 11 53 f0          	movups XMMWORD PTR [rbx-0x10],xmm2
   260ae:	0f 11 6b e0          	movups XMMWORD PTR [rbx-0x20],xmm5
   260b2:	0f 11 43 d0          	movups XMMWORD PTR [rbx-0x30],xmm0
   260b6:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   260bc:	49 89 c5             	mov    r13,rax
   260bf:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   260c3:	ff e0                	jmp    rax
   260c5:	f3 0f 1e fa          	endbr64
   260c9:	f3 0f 6f 43 b0       	movdqu xmm0,XMMWORD PTR [rbx-0x50]
   260ce:	f3 0f 6f 7b c0       	movdqu xmm7,XMMWORD PTR [rbx-0x40]
   260d3:	49 83 c4 01          	add    r12,0x1
   260d7:	f3 0f 6f 5b d0       	movdqu xmm3,XMMWORD PTR [rbx-0x30]
   260dc:	f3 0f 6f 4b e0       	movdqu xmm1,XMMWORD PTR [rbx-0x20]
   260e1:	f3 0f 6f 63 f0       	movdqu xmm4,XMMWORD PTR [rbx-0x10]
   260e6:	0f 11 7b b0          	movups XMMWORD PTR [rbx-0x50],xmm7
   260ea:	0f 11 5b c0          	movups XMMWORD PTR [rbx-0x40],xmm3
   260ee:	0f 11 4b d0          	movups XMMWORD PTR [rbx-0x30],xmm1
   260f2:	0f 11 63 e0          	movups XMMWORD PTR [rbx-0x20],xmm4
   260f6:	0f 11 43 f0          	movups XMMWORD PTR [rbx-0x10],xmm0
   260fa:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   26100:	49 89 c5             	mov    r13,rax
   26103:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   26107:	ff e0                	jmp    rax
   26109:	f3 0f 1e fa          	endbr64
   2610d:	f3 0f 6f 43 c0       	movdqu xmm0,XMMWORD PTR [rbx-0x40]
   26112:	f3 0f 6f 63 d0       	movdqu xmm4,XMMWORD PTR [rbx-0x30]
   26117:	49 83 c4 01          	add    r12,0x1
   2611b:	f3 0f 6f 6b e0       	movdqu xmm5,XMMWORD PTR [rbx-0x20]
   26120:	f3 0f 6f 73 f0       	movdqu xmm6,XMMWORD PTR [rbx-0x10]
   26125:	0f 11 63 c0          	movups XMMWORD PTR [rbx-0x40],xmm4
   26129:	0f 11 6b d0          	movups XMMWORD PTR [rbx-0x30],xmm5
   2612d:	0f 11 73 e0          	movups XMMWORD PTR [rbx-0x20],xmm6
   26131:	0f 11 43 f0          	movups XMMWORD PTR [rbx-0x10],xmm0
   26135:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   2613b:	49 89 c5             	mov    r13,rax
   2613e:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   26142:	ff e0                	jmp    rax
   26144:	f3 0f 1e fa          	endbr64
   26148:	f3 0f 6f 43 d0       	movdqu xmm0,XMMWORD PTR [rbx-0x30]
   2614d:	f3 0f 6f 7b e0       	movdqu xmm7,XMMWORD PTR [rbx-0x20]
   26152:	49 83 c4 01          	add    r12,0x1
   26156:	f3 0f 6f 5b f0       	movdqu xmm3,XMMWORD PTR [rbx-0x10]
   2615b:	0f 11 7b d0          	movups XMMWORD PTR [rbx-0x30],xmm7
   2615f:	0f 11 5b e0          	movups XMMWORD PTR [rbx-0x20],xmm3
   26163:	0f 11 43 f0          	movups XMMWORD PTR [rbx-0x10],xmm0
   26167:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   2616d:	49 89 c5             	mov    r13,rax
   26170:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   26174:	ff e0                	jmp    rax
   26176:	f3 0f 1e fa          	endbr64
   2617a:	f3 0f 6f 43 e0       	movdqu xmm0,XMMWORD PTR [rbx-0x20]
   2617f:	f3 0f 6f 73 d0       	movdqu xmm6,XMMWORD PTR [rbx-0x30]
   26184:	49 83 c4 01          	add    r12,0x1
   26188:	0f 11 73 e0          	movups XMMWORD PTR [rbx-0x20],xmm6
   2618c:	0f 11 43 d0          	movups XMMWORD PTR [rbx-0x30],xmm0
   26190:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   26196:	49 89 c5             	mov    r13,rax
   26199:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   2619d:	ff e0                	jmp    rax
   2619f:	f3 0f 1e fa          	endbr64
   261a3:	f3 0f 6f 7b f0       	movdqu xmm7,XMMWORD PTR [rbx-0x10]
   261a8:	f3 0f 6f 5b e0       	movdqu xmm3,XMMWORD PTR [rbx-0x20]
   261ad:	f3 0f 6f 63 d0       	movdqu xmm4,XMMWORD PTR [rbx-0x30]
   261b2:	f3 0f 6f 6b c0       	movdqu xmm5,XMMWORD PTR [rbx-0x40]
   261b7:	0f 11 3b             	movups XMMWORD PTR [rbx],xmm7
   261ba:	48 8b 43 08          	mov    rax,QWORD PTR [rbx+0x8]
   261be:	48 8b 53 f0          	mov    rdx,QWORD PTR [rbx-0x10]
   261c2:	0f 11 63 e0          	movups XMMWORD PTR [rbx-0x20],xmm4
   261c6:	0f 11 5b f0          	movups XMMWORD PTR [rbx-0x10],xmm3
   261ca:	0f 11 6b d0          	movups XMMWORD PTR [rbx-0x30],xmm5
   261ce:	83 f8 f6             	cmp    eax,0xfffffff6
   261d1:	76 04                	jbe    261d7 <JS_CallInternal+0x36f7>
   261d3:	83 42 fc 01          	add    DWORD PTR [rdx-0x4],0x1
   261d7:	48 89 53 c0          	mov    QWORD PTR [rbx-0x40],rdx
   261db:	49 83 c4 01          	add    r12,0x1
   261df:	48 83 c3 10          	add    rbx,0x10
   261e3:	48 89 43 b8          	mov    QWORD PTR [rbx-0x48],rax
   261e7:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   261ed:	49 89 c5             	mov    r13,rax
   261f0:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   261f4:	ff e0                	jmp    rax
   261f6:	f3 0f 1e fa          	endbr64
   261fa:	f3 0f 6f 63 f0       	movdqu xmm4,XMMWORD PTR [rbx-0x10]
   261ff:	f3 0f 6f 6b e0       	movdqu xmm5,XMMWORD PTR [rbx-0x20]
   26204:	f3 0f 6f 73 d0       	movdqu xmm6,XMMWORD PTR [rbx-0x30]
   26209:	48 8b 53 f0          	mov    rdx,QWORD PTR [rbx-0x10]
   2620d:	0f 11 23             	movups XMMWORD PTR [rbx],xmm4
   26210:	48 8b 43 08          	mov    rax,QWORD PTR [rbx+0x8]
   26214:	0f 11 6b f0          	movups XMMWORD PTR [rbx-0x10],xmm5
   26218:	0f 11 73 e0          	movups XMMWORD PTR [rbx-0x20],xmm6
   2621c:	83 f8 f6             	cmp    eax,0xfffffff6
   2621f:	76 04                	jbe    26225 <JS_CallInternal+0x3745>
   26221:	83 42 fc 01          	add    DWORD PTR [rdx-0x4],0x1
   26225:	48 89 53 d0          	mov    QWORD PTR [rbx-0x30],rdx
   26229:	49 83 c4 01          	add    r12,0x1
   2622d:	48 83 c3 10          	add    rbx,0x10
   26231:	48 89 43 c8          	mov    QWORD PTR [rbx-0x38],rax
   26235:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   2623b:	49 89 c5             	mov    r13,rax
   2623e:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   26242:	ff e0                	jmp    rax
   26244:	f3 0f 1e fa          	endbr64
   26248:	f3 0f 6f 73 f0       	movdqu xmm6,XMMWORD PTR [rbx-0x10]
   2624d:	f3 0f 6f 7b e0       	movdqu xmm7,XMMWORD PTR [rbx-0x20]
   26252:	48 8b 53 f0          	mov    rdx,QWORD PTR [rbx-0x10]
   26256:	0f 11 33             	movups XMMWORD PTR [rbx],xmm6
   26259:	48 8b 43 08          	mov    rax,QWORD PTR [rbx+0x8]
   2625d:	0f 11 7b f0          	movups XMMWORD PTR [rbx-0x10],xmm7
   26261:	83 f8 f6             	cmp    eax,0xfffffff6
   26264:	76 04                	jbe    2626a <JS_CallInternal+0x378a>
   26266:	83 42 fc 01          	add    DWORD PTR [rdx-0x4],0x1
   2626a:	48 89 53 e0          	mov    QWORD PTR [rbx-0x20],rdx
   2626e:	49 83 c4 01          	add    r12,0x1
   26272:	48 83 c3 10          	add    rbx,0x10
   26276:	48 89 43 d8          	mov    QWORD PTR [rbx-0x28],rax
   2627a:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   26280:	49 89 c5             	mov    r13,rax
   26283:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   26287:	ff e0                	jmp    rax
   26289:	f3 0f 1e fa          	endbr64
   2628d:	f3 0f 6f 6b f0       	movdqu xmm5,XMMWORD PTR [rbx-0x10]
   26292:	48 8b 43 e8          	mov    rax,QWORD PTR [rbx-0x18]
   26296:	48 8b 53 e0          	mov    rdx,QWORD PTR [rbx-0x20]
   2629a:	0f 11 2b             	movups XMMWORD PTR [rbx],xmm5
   2629d:	83 f8 f6             	cmp    eax,0xfffffff6
   262a0:	76 04                	jbe    262a6 <JS_CallInternal+0x37c6>
   262a2:	83 42 fc 01          	add    DWORD PTR [rdx-0x4],0x1
   262a6:	48 89 53 f0          	mov    QWORD PTR [rbx-0x10],rdx
   262aa:	49 83 c4 01          	add    r12,0x1
   262ae:	48 83 c3 10          	add    rbx,0x10
   262b2:	48 89 43 e8          	mov    QWORD PTR [rbx-0x18],rax
   262b6:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   262bc:	49 89 c5             	mov    r13,rax
   262bf:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   262c3:	ff e0                	jmp    rax
   262c5:	f3 0f 1e fa          	endbr64
   262c9:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   262d0:	48 8b 73 f0          	mov    rsi,QWORD PTR [rbx-0x10]
   262d4:	48 83 eb 10          	sub    rbx,0x10
   262d8:	48 8b 53 08          	mov    rdx,QWORD PTR [rbx+0x8]
   262dc:	e8 2f c0 ff ff       	call   22310 <JS_Throw>
   262e1:	e9 9a cf ff ff       	jmp    23280 <JS_CallInternal+0x7a0>
   262e6:	f3 0f 1e fa          	endbr64
   262ea:	48 8b 4b f0          	mov    rcx,QWORD PTR [rbx-0x10]
   262ee:	48 8b 73 e0          	mov    rsi,QWORD PTR [rbx-0x20]
   262f2:	4c 8d 6b f0          	lea    r13,[rbx-0x10]
   262f6:	4c 8d 73 e0          	lea    r14,[rbx-0x20]
   262fa:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   26301:	49 8b 56 08          	mov    rdx,QWORD PTR [r14+0x8]
   26305:	4d 8b 45 08          	mov    r8,QWORD PTR [r13+0x8]
   26309:	e8 02 3d 02 00       	call   4a010 <JS_AddBrand>
   2630e:	85 c0                	test   eax,eax
   26310:	0f 88 6a cf ff ff    	js     23280 <JS_CallInternal+0x7a0>
   26316:	49 8b 56 08          	mov    rdx,QWORD PTR [r14+0x8]
   2631a:	48 8b 73 e0          	mov    rsi,QWORD PTR [rbx-0x20]
   2631e:	83 fa f6             	cmp    edx,0xfffffff6
   26321:	76 11                	jbe    26334 <JS_CallInternal+0x3854>
   26323:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   26326:	83 e8 01             	sub    eax,0x1
   26329:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   2632c:	85 c0                	test   eax,eax
   2632e:	0f 8e 4a 49 00 00    	jle    2ac7e <JS_CallInternal+0x819e>
   26334:	49 8b 55 08          	mov    rdx,QWORD PTR [r13+0x8]
   26338:	49 8b 75 00          	mov    rsi,QWORD PTR [r13+0x0]
   2633c:	83 fa f6             	cmp    edx,0xfffffff6
   2633f:	76 11                	jbe    26352 <JS_CallInternal+0x3872>
   26341:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   26344:	83 e8 01             	sub    eax,0x1
   26347:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   2634a:	85 c0                	test   eax,eax
   2634c:	0f 8e 41 49 00 00    	jle    2ac93 <JS_CallInternal+0x81b3>
   26352:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   26357:	4c 89 f3             	mov    rbx,r14
   2635a:	49 83 c4 01          	add    r12,0x1
   2635e:	49 89 c5             	mov    r13,rax
   26361:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   26365:	ff e0                	jmp    rax
   26367:	f3 0f 1e fa          	endbr64
   2636b:	48 8b 4b f0          	mov    rcx,QWORD PTR [rbx-0x10]
   2636f:	48 8b 73 e0          	mov    rsi,QWORD PTR [rbx-0x20]
   26373:	48 8b 53 e8          	mov    rdx,QWORD PTR [rbx-0x18]
   26377:	4c 8b 43 f8          	mov    r8,QWORD PTR [rbx-0x8]
   2637b:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   26382:	e8 19 af 00 00       	call   312a0 <JS_CheckBrand>
   26387:	85 c0                	test   eax,eax
   26389:	0f 88 f1 ce ff ff    	js     23280 <JS_CallInternal+0x7a0>
   2638f:	0f 84 0c 63 00 00    	je     2c6a1 <JS_CallInternal+0x9bc1>
   26395:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   2639a:	49 83 c4 01          	add    r12,0x1
   2639e:	49 89 c5             	mov    r13,rax
   263a1:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   263a5:	ff e0                	jmp    rax
   263a7:	f3 0f 1e fa          	endbr64
   263ab:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   263b2:	83 bd 80 fe ff ff 03 	cmp    DWORD PTR [rbp-0x180],0x3
   263b9:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   263bd:	0f 84 07 5c 00 00    	je     2bfca <JS_CallInternal+0x94ea>
   263c3:	48 8b b5 e0 fe ff ff 	mov    rsi,QWORD PTR [rbp-0x120]
   263ca:	48 8b 95 d0 fe ff ff 	mov    rdx,QWORD PTR [rbp-0x130]
   263d1:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   263d8:	e8 03 c0 ff ff       	call   223e0 <JS_GetPrototype>
   263dd:	49 89 c6             	mov    r14,rax
   263e0:	49 89 d5             	mov    r13,rdx
   263e3:	83 fa 06             	cmp    edx,0x6
   263e6:	0f 84 94 ce ff ff    	je     23280 <JS_CallInternal+0x7a0>
   263ec:	6a 02                	push   0x2
   263ee:	44 8b 8d bc fe ff ff 	mov    r9d,DWORD PTR [rbp-0x144]
   263f5:	48 89 c6             	mov    rsi,rax
   263f8:	ff b5 a8 fe ff ff    	push   QWORD PTR [rbp-0x158]
   263fe:	48 8b 8d 70 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x190]
   26405:	4c 8b 85 80 fe ff ff 	mov    r8,QWORD PTR [rbp-0x180]
   2640c:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   26413:	e8 f8 aa 06 00       	call   90f10 <JS_CallConstructorInternal>
   26418:	41 58                	pop    r8
   2641a:	41 59                	pop    r9
   2641c:	48 89 d1             	mov    rcx,rdx
   2641f:	41 83 fd f6          	cmp    r13d,0xfffffff6
   26423:	76 13                	jbe    26438 <JS_CallInternal+0x3958>
   26425:	41 8b 7e fc          	mov    edi,DWORD PTR [r14-0x4]
   26429:	8d 57 ff             	lea    edx,[rdi-0x1]
   2642c:	41 89 56 fc          	mov    DWORD PTR [r14-0x4],edx
   26430:	85 d2                	test   edx,edx
   26432:	0f 8e 26 45 00 00    	jle    2a95e <JS_CallInternal+0x7e7e>
   26438:	83 f9 06             	cmp    ecx,0x6
   2643b:	0f 84 3f ce ff ff    	je     23280 <JS_CallInternal+0x7a0>
   26441:	48 89 03             	mov    QWORD PTR [rbx],rax
   26444:	49 83 c4 01          	add    r12,0x1
   26448:	48 83 c3 10          	add    rbx,0x10
   2644c:	48 89 4b f8          	mov    QWORD PTR [rbx-0x8],rcx
   26450:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   26456:	49 89 c5             	mov    r13,rax
   26459:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   2645d:	ff e0                	jmp    rax
   2645f:	f3 0f 1e fa          	endbr64
   26463:	83 bd 80 fe ff ff 03 	cmp    DWORD PTR [rbp-0x180],0x3
   2646a:	0f 84 5a 5b 00 00    	je     2bfca <JS_CallInternal+0x94ea>
   26470:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   26475:	49 83 c4 01          	add    r12,0x1
   26479:	49 89 c5             	mov    r13,rax
   2647c:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   26480:	ff e0                	jmp    rax
   26482:	f3 0f 1e fa          	endbr64
   26486:	48 8b 43 f8          	mov    rax,QWORD PTR [rbx-0x8]
   2648a:	83 f8 ff             	cmp    eax,0xffffffff
   2648d:	0f 84 1f 35 00 00    	je     299b2 <JS_CallInternal+0x6ed2>
   26493:	83 f8 03             	cmp    eax,0x3
   26496:	0f 85 2d 5e 00 00    	jne    2c2c9 <JS_CallInternal+0x97e9>
   2649c:	b8 01 00 00 00       	mov    eax,0x1
   264a1:	48 89 03             	mov    QWORD PTR [rbx],rax
   264a4:	49 83 c4 01          	add    r12,0x1
   264a8:	48 83 c3 10          	add    rbx,0x10
   264ac:	48 c7 43 f8 01 00 00 	mov    QWORD PTR [rbx-0x8],0x1
   264b3:	00 
   264b4:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   264ba:	49 89 c5             	mov    r13,rax
   264bd:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   264c1:	ff e0                	jmp    rax
   264c3:	f3 0f 1e fa          	endbr64
   264c7:	b9 03 00 00 00       	mov    ecx,0x3
   264cc:	31 c0                	xor    eax,eax
   264ce:	e9 00 cd ff ff       	jmp    231d3 <JS_CallInternal+0x6f3>
   264d3:	f3 0f 1e fa          	endbr64
   264d7:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   264dc:	48 8b 8d d8 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x128]
   264e3:	4d 8d 6c 24 01       	lea    r13,[r12+0x1]
   264e8:	48 c1 e0 04          	shl    rax,0x4
   264ec:	48 03 41 50          	add    rax,QWORD PTR [rcx+0x50]
   264f0:	48 8b 50 08          	mov    rdx,QWORD PTR [rax+0x8]
   264f4:	48 8b 30             	mov    rsi,QWORD PTR [rax]
   264f7:	83 fa f6             	cmp    edx,0xfffffff6
   264fa:	76 04                	jbe    26500 <JS_CallInternal+0x3a20>
   264fc:	83 46 fc 01          	add    DWORD PTR [rsi-0x4],0x1
   26500:	4c 8b 85 c8 fe ff ff 	mov    r8,QWORD PTR [rbp-0x138]
   26507:	48 8b 8d 98 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x168]
   2650e:	45 31 c9             	xor    r9d,r9d
   26511:	4c 8d 73 10          	lea    r14,[rbx+0x10]
   26515:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2651c:	e8 8f 61 02 00       	call   4c6b0 <js_closure>
   26521:	48 89 53 08          	mov    QWORD PTR [rbx+0x8],rdx
   26525:	83 7b 08 06          	cmp    DWORD PTR [rbx+0x8],0x6
   26529:	48 89 03             	mov    QWORD PTR [rbx],rax
   2652c:	0f 84 7e 49 00 00    	je     2aeb0 <JS_CallInternal+0x83d0>
   26532:	41 0f b6 44 24 01    	movzx  eax,BYTE PTR [r12+0x1]
   26538:	4c 89 f3             	mov    rbx,r14
   2653b:	49 83 c4 02          	add    r12,0x2
   2653f:	49 89 c5             	mov    r13,rax
   26542:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   26546:	ff e0                	jmp    rax
   26548:	f3 0f 1e fa          	endbr64
   2654c:	48 8b 8d d8 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x128]
   26553:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   26558:	48 c1 e0 04          	shl    rax,0x4
   2655c:	48 03 41 50          	add    rax,QWORD PTR [rcx+0x50]
   26560:	48 8d 4b 10          	lea    rcx,[rbx+0x10]
   26564:	48 8b 10             	mov    rdx,QWORD PTR [rax]
   26567:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
   2656b:	83 f8 f6             	cmp    eax,0xfffffff6
   2656e:	76 04                	jbe    26574 <JS_CallInternal+0x3a94>
   26570:	83 42 fc 01          	add    DWORD PTR [rdx-0x4],0x1
   26574:	48 89 13             	mov    QWORD PTR [rbx],rdx
   26577:	49 83 c4 02          	add    r12,0x2
   2657b:	48 89 43 08          	mov    QWORD PTR [rbx+0x8],rax
   2657f:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   26585:	48 89 cb             	mov    rbx,rcx
   26588:	49 89 c5             	mov    r13,rax
   2658b:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   2658f:	ff e0                	jmp    rax
   26591:	f3 0f 1e fa          	endbr64
   26595:	41 0f bf 04 24       	movsx  eax,WORD PTR [r12]
   2659a:	48 83 c3 10          	add    rbx,0x10
   2659e:	49 83 c4 03          	add    r12,0x3
   265a2:	48 c7 43 f8 00 00 00 	mov    QWORD PTR [rbx-0x8],0x0
   265a9:	00 
   265aa:	48 89 43 f0          	mov    QWORD PTR [rbx-0x10],rax
   265ae:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   265b4:	49 89 c5             	mov    r13,rax
   265b7:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   265bb:	ff e0                	jmp    rax
   265bd:	f3 0f 1e fa          	endbr64
   265c1:	41 0f be 04 24       	movsx  eax,BYTE PTR [r12]
   265c6:	48 83 c3 10          	add    rbx,0x10
   265ca:	49 83 c4 02          	add    r12,0x2
   265ce:	48 c7 43 f8 00 00 00 	mov    QWORD PTR [rbx-0x8],0x0
   265d5:	00 
   265d6:	48 89 43 f0          	mov    QWORD PTR [rbx-0x10],rax
   265da:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   265e0:	49 89 c5             	mov    r13,rax
   265e3:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   265e7:	ff e0                	jmp    rax
   265e9:	f3 0f 1e fa          	endbr64
   265ed:	e9 d6 c7 ff ff       	jmp    22dc8 <JS_CallInternal+0x2e8>
   265f2:	f3 0f 1e fa          	endbr64
   265f6:	e9 cd c7 ff ff       	jmp    22dc8 <JS_CallInternal+0x2e8>
   265fb:	f3 0f 1e fa          	endbr64
   265ff:	e9 c4 c7 ff ff       	jmp    22dc8 <JS_CallInternal+0x2e8>
   26604:	f3 0f 1e fa          	endbr64
   26608:	e9 bb c7 ff ff       	jmp    22dc8 <JS_CallInternal+0x2e8>
   2660d:	f3 0f 1e fa          	endbr64
   26611:	e9 b2 c7 ff ff       	jmp    22dc8 <JS_CallInternal+0x2e8>
   26616:	f3 0f 1e fa          	endbr64
   2661a:	e9 a9 c7 ff ff       	jmp    22dc8 <JS_CallInternal+0x2e8>
   2661f:	f3 0f 1e fa          	endbr64
   26623:	e9 a0 c7 ff ff       	jmp    22dc8 <JS_CallInternal+0x2e8>
   26628:	f3 0f 1e fa          	endbr64
   2662c:	48 8b 8d d8 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x128]
   26633:	41 8b 04 24          	mov    eax,DWORD PTR [r12]
   26637:	48 c1 e0 04          	shl    rax,0x4
   2663b:	48 03 41 50          	add    rax,QWORD PTR [rcx+0x50]
   2663f:	48 8d 4b 10          	lea    rcx,[rbx+0x10]
   26643:	48 8b 10             	mov    rdx,QWORD PTR [rax]
   26646:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
   2664a:	83 f8 f6             	cmp    eax,0xfffffff6
   2664d:	76 04                	jbe    26653 <JS_CallInternal+0x3b73>
   2664f:	83 42 fc 01          	add    DWORD PTR [rdx-0x4],0x1
   26653:	48 89 13             	mov    QWORD PTR [rbx],rdx
   26656:	49 83 c4 05          	add    r12,0x5
   2665a:	48 89 43 08          	mov    QWORD PTR [rbx+0x8],rax
   2665e:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   26664:	48 89 cb             	mov    rbx,rcx
   26667:	49 89 c5             	mov    r13,rax
   2666a:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   2666e:	ff e0                	jmp    rax
   26670:	f3 0f 1e fa          	endbr64
   26674:	49 63 04 24          	movsxd rax,DWORD PTR [r12]
   26678:	48 c7 43 08 07 00 00 	mov    QWORD PTR [rbx+0x8],0x7
   2667f:	00 
   26680:	49 83 c4 05          	add    r12,0x5
   26684:	48 83 c3 10          	add    rbx,0x10
   26688:	48 89 43 f0          	mov    QWORD PTR [rbx-0x10],rax
   2668c:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   26692:	49 89 c5             	mov    r13,rax
   26695:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   26699:	ff e0                	jmp    rax
   2669b:	f3 0f 1e fa          	endbr64
   2669f:	41 8b 04 24          	mov    eax,DWORD PTR [r12]
   266a3:	48 c7 43 08 00 00 00 	mov    QWORD PTR [rbx+0x8],0x0
   266aa:	00 
   266ab:	49 83 c4 05          	add    r12,0x5
   266af:	48 83 c3 10          	add    rbx,0x10
   266b3:	48 89 43 f0          	mov    QWORD PTR [rbx-0x10],rax
   266b7:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   266bd:	49 89 c5             	mov    r13,rax
   266c0:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   266c4:	ff e0                	jmp    rax
   266c6:	f3 0f 1e fa          	endbr64
   266ca:	48 c7 03 00 00 00 00 	mov    QWORD PTR [rbx],0x0
   266d1:	49 83 c4 01          	add    r12,0x1
   266d5:	48 83 c3 10          	add    rbx,0x10
   266d9:	48 c7 43 f8 02 00 00 	mov    QWORD PTR [rbx-0x8],0x2
   266e0:	00 
   266e1:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   266e7:	49 89 c5             	mov    r13,rax
   266ea:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   266ee:	ff e0                	jmp    rax
   266f0:	f3 0f 1e fa          	endbr64
   266f4:	48 c7 03 00 00 00 00 	mov    QWORD PTR [rbx],0x0
   266fb:	49 83 c4 01          	add    r12,0x1
   266ff:	48 83 c3 10          	add    rbx,0x10
   26703:	48 c7 43 f8 03 00 00 	mov    QWORD PTR [rbx-0x8],0x3
   2670a:	00 
   2670b:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   26711:	49 89 c5             	mov    r13,rax
   26714:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   26718:	ff e0                	jmp    rax
   2671a:	f3 0f 1e fa          	endbr64
   2671e:	41 8b 34 24          	mov    esi,DWORD PTR [r12]
   26722:	31 d2                	xor    edx,edx
   26724:	4c 8d 73 10          	lea    r14,[rbx+0x10]
   26728:	49 83 c4 05          	add    r12,0x5
   2672c:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   26733:	e8 b8 d8 00 00       	call   33ff0 <__JS_AtomToValue>
   26738:	48 89 03             	mov    QWORD PTR [rbx],rax
   2673b:	48 89 53 08          	mov    QWORD PTR [rbx+0x8],rdx
   2673f:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   26745:	4c 89 f3             	mov    rbx,r14
   26748:	49 89 c5             	mov    r13,rax
   2674b:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   2674f:	ff e0                	jmp    rax
   26751:	f3 0f 1e fa          	endbr64
   26755:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2675c:	ba 01 00 00 00       	mov    edx,0x1
   26761:	4c 8d 73 10          	lea    r14,[rbx+0x10]
   26765:	49 83 c4 01          	add    r12,0x1
   26769:	be 2f 00 00 00       	mov    esi,0x2f
   2676e:	e8 7d d8 00 00       	call   33ff0 <__JS_AtomToValue>
   26773:	48 89 03             	mov    QWORD PTR [rbx],rax
   26776:	48 89 53 08          	mov    QWORD PTR [rbx+0x8],rdx
   2677a:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   26780:	4c 89 f3             	mov    rbx,r14
   26783:	49 89 c5             	mov    r13,rax
   26786:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   2678a:	ff e0                	jmp    rax
   2678c:	f3 0f 1e fa          	endbr64
   26790:	48 8b 53 f8          	mov    rdx,QWORD PTR [rbx-0x8]
   26794:	0b 53 e8             	or     edx,DWORD PTR [rbx-0x18]
   26797:	48 8b 43 e0          	mov    rax,QWORD PTR [rbx-0x20]
   2679b:	48 8b 4b f0          	mov    rcx,QWORD PTR [rbx-0x10]
   2679f:	0f 85 32 4d 00 00    	jne    2b4d7 <JS_CallInternal+0x89f7>
   267a5:	21 c8                	and    eax,ecx
   267a7:	48 c7 43 e8 00 00 00 	mov    QWORD PTR [rbx-0x18],0x0
   267ae:	00 
   267af:	48 83 eb 10          	sub    rbx,0x10
   267b3:	48 89 43 f0          	mov    QWORD PTR [rbx-0x10],rax
   267b7:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   267bc:	49 83 c4 01          	add    r12,0x1
   267c0:	49 89 c5             	mov    r13,rax
   267c3:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   267c7:	ff e0                	jmp    rax
   267c9:	f3 0f 1e fa          	endbr64
   267cd:	48 8b 53 f8          	mov    rdx,QWORD PTR [rbx-0x8]
   267d1:	0b 53 e8             	or     edx,DWORD PTR [rbx-0x18]
   267d4:	48 8b 43 e0          	mov    rax,QWORD PTR [rbx-0x20]
   267d8:	48 8b 4b f0          	mov    rcx,QWORD PTR [rbx-0x10]
   267dc:	0f 85 4b 48 00 00    	jne    2b02d <JS_CallInternal+0x854d>
   267e2:	d3 f8                	sar    eax,cl
   267e4:	48 c7 43 e8 00 00 00 	mov    QWORD PTR [rbx-0x18],0x0
   267eb:	00 
   267ec:	48 83 eb 10          	sub    rbx,0x10
   267f0:	48 89 43 f0          	mov    QWORD PTR [rbx-0x10],rax
   267f4:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   267f9:	49 83 c4 01          	add    r12,0x1
   267fd:	49 89 c5             	mov    r13,rax
   26800:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   26804:	ff e0                	jmp    rax
   26806:	f3 0f 1e fa          	endbr64
   2680a:	48 8b 53 f8          	mov    rdx,QWORD PTR [rbx-0x8]
   2680e:	0b 53 e8             	or     edx,DWORD PTR [rbx-0x18]
   26811:	48 8b 43 e0          	mov    rax,QWORD PTR [rbx-0x20]
   26815:	48 8b 4b f0          	mov    rcx,QWORD PTR [rbx-0x10]
   26819:	0f 85 34 50 00 00    	jne    2b853 <JS_CallInternal+0x8d73>
   2681f:	d3 e8                	shr    eax,cl
   26821:	85 c0                	test   eax,eax
   26823:	0f 88 41 30 00 00    	js     2986a <JS_CallInternal+0x6d8a>
   26829:	66 0f 6e c0          	movd   xmm0,eax
   2682d:	31 c0                	xor    eax,eax
   2682f:	48 89 43 e8          	mov    QWORD PTR [rbx-0x18],rax
   26833:	48 83 eb 10          	sub    rbx,0x10
   26837:	66 0f d6 43 f0       	movq   QWORD PTR [rbx-0x10],xmm0
   2683c:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   26841:	49 83 c4 01          	add    r12,0x1
   26845:	49 89 c5             	mov    r13,rax
   26848:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   2684c:	ff e0                	jmp    rax
   2684e:	f3 0f 1e fa          	endbr64
   26852:	49 63 04 24          	movsxd rax,DWORD PTR [r12]
   26856:	48 8b 8d d8 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x128]
   2685d:	49 8d 54 24 04       	lea    rdx,[r12+0x4]
   26862:	48 83 c3 10          	add    rbx,0x10
   26866:	2b 51 18             	sub    edx,DWORD PTR [rcx+0x18]
   26869:	4c 01 e0             	add    rax,r12
   2686c:	48 c7 43 f8 00 00 00 	mov    QWORD PTR [rbx-0x8],0x0
   26873:	00 
   26874:	48 89 53 f0          	mov    QWORD PTR [rbx-0x10],rdx
   26878:	4c 8d 60 01          	lea    r12,[rax+0x1]
   2687c:	0f b6 00             	movzx  eax,BYTE PTR [rax]
   2687f:	49 89 c5             	mov    r13,rax
   26882:	41 ff 24 c7          	jmp    QWORD PTR [r15+rax*8]
   26886:	f3 0f 1e fa          	endbr64
   2688a:	49 63 04 24          	movsxd rax,DWORD PTR [r12]
   2688e:	48 8b 8d d8 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x128]
   26895:	48 83 c3 10          	add    rbx,0x10
   26899:	4c 01 e0             	add    rax,r12
   2689c:	2b 41 18             	sub    eax,DWORD PTR [rcx+0x18]
   2689f:	48 c7 43 f8 05 00 00 	mov    QWORD PTR [rbx-0x8],0x5
   268a6:	00 
   268a7:	49 83 c4 05          	add    r12,0x5
   268ab:	48 89 43 f0          	mov    QWORD PTR [rbx-0x10],rax
   268af:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   268b5:	49 89 c5             	mov    r13,rax
   268b8:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   268bc:	ff e0                	jmp    rax
   268be:	f3 0f 1e fa          	endbr64
   268c2:	4c 8b 73 e0          	mov    r14,QWORD PTR [rbx-0x20]
   268c6:	4c 8b 4b f0          	mov    r9,QWORD PTR [rbx-0x10]
   268ca:	4c 8b 43 f8          	mov    r8,QWORD PTR [rbx-0x8]
   268ce:	4c 8b 6b e8          	mov    r13,QWORD PTR [rbx-0x18]
   268d2:	4c 89 f7             	mov    rdi,r14
   268d5:	4c 89 ce             	mov    rsi,r9
   268d8:	4c 89 c0             	mov    rax,r8
   268db:	45 85 ed             	test   r13d,r13d
   268de:	0f 85 8c 47 00 00    	jne    2b070 <JS_CallInternal+0x8590>
   268e4:	45 85 c0             	test   r8d,r8d
   268e7:	0f 85 87 2d 00 00    	jne    29674 <JS_CallInternal+0x6b94>
   268ed:	31 c0                	xor    eax,eax
   268ef:	45 39 ce             	cmp    r14d,r9d
   268f2:	0f 94 c0             	sete   al
   268f5:	83 f8 01             	cmp    eax,0x1
   268f8:	48 c7 43 e8 01 00 00 	mov    QWORD PTR [rbx-0x18],0x1
   268ff:	00 
   26900:	0f 95 c0             	setne  al
   26903:	0f b6 c0             	movzx  eax,al
   26906:	48 89 43 e0          	mov    QWORD PTR [rbx-0x20],rax
   2690a:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   2690f:	48 83 eb 10          	sub    rbx,0x10
   26913:	49 83 c4 01          	add    r12,0x1
   26917:	49 89 c5             	mov    r13,rax
   2691a:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   2691e:	ff e0                	jmp    rax
   26920:	f3 0f 1e fa          	endbr64
   26924:	4c 8b 73 e0          	mov    r14,QWORD PTR [rbx-0x20]
   26928:	4c 8b 4b f0          	mov    r9,QWORD PTR [rbx-0x10]
   2692c:	4c 8b 43 f8          	mov    r8,QWORD PTR [rbx-0x8]
   26930:	4c 8b 6b e8          	mov    r13,QWORD PTR [rbx-0x18]
   26934:	4c 89 f7             	mov    rdi,r14
   26937:	4c 89 ce             	mov    rsi,r9
   2693a:	4c 89 c0             	mov    rax,r8
   2693d:	45 85 ed             	test   r13d,r13d
   26940:	0f 85 0d 4e 00 00    	jne    2b753 <JS_CallInternal+0x8c73>
   26946:	45 85 c0             	test   r8d,r8d
   26949:	0f 85 f9 2c 00 00    	jne    29648 <JS_CallInternal+0x6b68>
   2694f:	45 39 ce             	cmp    r14d,r9d
   26952:	0f 94 c0             	sete   al
   26955:	0f b6 c0             	movzx  eax,al
   26958:	48 c7 43 e8 01 00 00 	mov    QWORD PTR [rbx-0x18],0x1
   2695f:	00 
   26960:	48 89 43 e0          	mov    QWORD PTR [rbx-0x20],rax
   26964:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   26969:	48 83 eb 10          	sub    rbx,0x10
   2696d:	49 83 c4 01          	add    r12,0x1
   26971:	49 89 c5             	mov    r13,rax
   26974:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   26978:	ff e0                	jmp    rax
   2697a:	f3 0f 1e fa          	endbr64
   2697e:	48 8b 4b f8          	mov    rcx,QWORD PTR [rbx-0x8]
   26982:	83 7b d8 ff          	cmp    DWORD PTR [rbx-0x28],0xffffffff
   26986:	4c 8d 73 e0          	lea    r14,[rbx-0x20]
   2698a:	4c 8b 43 d0          	mov    r8,QWORD PTR [rbx-0x30]
   2698e:	48 8b 73 e0          	mov    rsi,QWORD PTR [rbx-0x20]
   26992:	4c 8b 6b f0          	mov    r13,QWORD PTR [rbx-0x10]
   26996:	49 8b 46 08          	mov    rax,QWORD PTR [r14+0x8]
   2699a:	48 89 8d 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],rcx
   269a1:	0f 85 5e 4b 00 00    	jne    2b505 <JS_CallInternal+0x8a25>
   269a7:	83 f8 f8             	cmp    eax,0xfffffff8
   269aa:	0f 85 c0 4a 00 00    	jne    2b470 <JS_CallInternal+0x8990>
   269b0:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   269b7:	4c 89 85 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],r8
   269be:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   269c2:	e8 89 01 ff ff       	call   16b50 <js_get_atom_index>
   269c7:	4c 8b 85 40 fe ff ff 	mov    r8,QWORD PTR [rbp-0x1c0]
   269ce:	89 c6                	mov    esi,eax
   269d0:	49 8b 48 18          	mov    rcx,QWORD PTR [r8+0x18]
   269d4:	89 f2                	mov    edx,esi
   269d6:	8b 41 18             	mov    eax,DWORD PTR [rcx+0x18]
   269d9:	21 c2                	and    edx,eax
   269db:	8b 54 91 38          	mov    edx,DWORD PTR [rcx+rdx*4+0x38]
   269df:	48 85 d2             	test   rdx,rdx
   269e2:	0f 84 4d 27 00 00    	je     29135 <JS_CallInternal+0x6655>
   269e8:	48 8d 3c 85 34 00 00 	lea    rdi,[rax*4+0x34]
   269ef:	00 
   269f0:	48 8d 04 d7          	lea    rax,[rdi+rdx*8]
   269f4:	48 01 c8             	add    rax,rcx
   269f7:	3b 70 04             	cmp    esi,DWORD PTR [rax+0x4]
   269fa:	0f 85 27 27 00 00    	jne    29127 <JS_CallInternal+0x6647>
   26a00:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   26a07:	48 8d 0d 36 67 0a 00 	lea    rcx,[rip+0xa6736]        # cd144 <_IO_stdin_used+0x144>
   26a0e:	48 8d 15 23 a4 0a 00 	lea    rdx,[rip+0xaa423]        # d0e38 <_IO_stdin_used+0x3e38>
   26a15:	31 c0                	xor    eax,eax
   26a17:	e8 14 a4 00 00       	call   30e30 <__JS_ThrowTypeErrorAtom>
   26a1c:	83 bd 50 fe ff ff f6 	cmp    DWORD PTR [rbp-0x1b0],0xfffffff6
   26a23:	76 13                	jbe    26a38 <JS_CallInternal+0x3f58>
   26a25:	41 8b 45 fc          	mov    eax,DWORD PTR [r13-0x4]
   26a29:	83 e8 01             	sub    eax,0x1
   26a2c:	41 89 45 fc          	mov    DWORD PTR [r13-0x4],eax
   26a30:	85 c0                	test   eax,eax
   26a32:	0f 8e 2c 5c 00 00    	jle    2c664 <JS_CallInternal+0x9b84>
   26a38:	49 8b 56 08          	mov    rdx,QWORD PTR [r14+0x8]
   26a3c:	49 8b 36             	mov    rsi,QWORD PTR [r14]
   26a3f:	4c 89 f3             	mov    rbx,r14
   26a42:	83 fa f6             	cmp    edx,0xfffffff6
   26a45:	0f 86 35 c8 ff ff    	jbe    23280 <JS_CallInternal+0x7a0>
   26a4b:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   26a4e:	83 e8 01             	sub    eax,0x1
   26a51:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   26a54:	85 c0                	test   eax,eax
   26a56:	0f 8f 24 c8 ff ff    	jg     23280 <JS_CallInternal+0x7a0>
   26a5c:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   26a63:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   26a67:	e8 34 5e ff ff       	call   1c8a0 <__JS_FreeValueRT>
   26a6c:	e9 0f c8 ff ff       	jmp    23280 <JS_CallInternal+0x7a0>
   26a71:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]
   26a78:	f3 0f 1e fa          	endbr64
   26a7c:	48 8d 43 e0          	lea    rax,[rbx-0x20]
   26a80:	4c 8d 73 f0          	lea    r14,[rbx-0x10]
   26a84:	4c 8b 28             	mov    r13,QWORD PTR [rax]
   26a87:	48 83 eb 30          	sub    rbx,0x30
   26a8b:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
   26a8f:	83 7b 08 ff          	cmp    DWORD PTR [rbx+0x8],0xffffffff
   26a93:	48 8b 13             	mov    rdx,QWORD PTR [rbx]
   26a96:	49 8b 36             	mov    rsi,QWORD PTR [r14]
   26a99:	48 89 85 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],rax
   26aa0:	49 8b 4e 08          	mov    rcx,QWORD PTR [r14+0x8]
   26aa4:	0f 85 e0 49 00 00    	jne    2b48a <JS_CallInternal+0x89aa>
   26aaa:	83 f9 f8             	cmp    ecx,0xfffffff8
   26aad:	0f 85 86 4c 00 00    	jne    2b739 <JS_CallInternal+0x8c59>
   26ab3:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   26aba:	48 89 95 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],rdx
   26ac1:	48 8b 40 10          	mov    rax,QWORD PTR [rax+0x10]
   26ac5:	48 89 c7             	mov    rdi,rax
   26ac8:	48 89 85 38 fe ff ff 	mov    QWORD PTR [rbp-0x1c8],rax
   26acf:	e8 7c 00 ff ff       	call   16b50 <js_get_atom_index>
   26ad4:	48 8b 95 40 fe ff ff 	mov    rdx,QWORD PTR [rbp-0x1c0]
   26adb:	89 c6                	mov    esi,eax
   26add:	48 8b 7a 18          	mov    rdi,QWORD PTR [rdx+0x18]
   26ae1:	8b 4f 18             	mov    ecx,DWORD PTR [rdi+0x18]
   26ae4:	21 c8                	and    eax,ecx
   26ae6:	8b 44 87 38          	mov    eax,DWORD PTR [rdi+rax*4+0x38]
   26aea:	48 85 c0             	test   rax,rax
   26aed:	0f 84 cc 4f 00 00    	je     2babf <JS_CallInternal+0x8fdf>
   26af3:	4c 8d 04 8d 34 00 00 	lea    r8,[rcx*4+0x34]
   26afa:	00 
   26afb:	49 8d 0c c0          	lea    rcx,[r8+rax*8]
   26aff:	48 01 f9             	add    rcx,rdi
   26b02:	3b 71 04             	cmp    esi,DWORD PTR [rcx+0x4]
   26b05:	0f 85 a7 4f 00 00    	jne    2bab2 <JS_CallInternal+0x8fd2>
   26b0b:	48 8b 52 20          	mov    rdx,QWORD PTR [rdx+0x20]
   26b0f:	48 c1 e0 04          	shl    rax,0x4
   26b13:	48 8b 8d 50 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x1b0]
   26b1a:	48 8d 44 02 f0       	lea    rax,[rdx+rax*1-0x10]
   26b1f:	48 8b 50 08          	mov    rdx,QWORD PTR [rax+0x8]
   26b23:	48 8b 30             	mov    rsi,QWORD PTR [rax]
   26b26:	48 89 48 08          	mov    QWORD PTR [rax+0x8],rcx
   26b2a:	4c 89 28             	mov    QWORD PTR [rax],r13
   26b2d:	83 fa f6             	cmp    edx,0xfffffff6
   26b30:	76 11                	jbe    26b43 <JS_CallInternal+0x4063>
   26b32:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   26b35:	83 e8 01             	sub    eax,0x1
   26b38:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   26b3b:	85 c0                	test   eax,eax
   26b3d:	0f 8e 83 49 00 00    	jle    2b4c6 <JS_CallInternal+0x89e6>
   26b43:	45 31 ed             	xor    r13d,r13d
   26b46:	48 8b 53 08          	mov    rdx,QWORD PTR [rbx+0x8]
   26b4a:	48 8b 33             	mov    rsi,QWORD PTR [rbx]
   26b4d:	83 fa f6             	cmp    edx,0xfffffff6
   26b50:	76 11                	jbe    26b63 <JS_CallInternal+0x4083>
   26b52:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   26b55:	83 e8 01             	sub    eax,0x1
   26b58:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   26b5b:	85 c0                	test   eax,eax
   26b5d:	0f 8e d6 38 00 00    	jle    2a439 <JS_CallInternal+0x7959>
   26b63:	49 8b 56 08          	mov    rdx,QWORD PTR [r14+0x8]
   26b67:	49 8b 36             	mov    rsi,QWORD PTR [r14]
   26b6a:	83 fa f6             	cmp    edx,0xfffffff6
   26b6d:	76 11                	jbe    26b80 <JS_CallInternal+0x40a0>
   26b6f:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   26b72:	83 e8 01             	sub    eax,0x1
   26b75:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   26b78:	85 c0                	test   eax,eax
   26b7a:	0f 8e e3 38 00 00    	jle    2a463 <JS_CallInternal+0x7983>
   26b80:	41 83 fd ff          	cmp    r13d,0xffffffff
   26b84:	0f 84 f6 c6 ff ff    	je     23280 <JS_CallInternal+0x7a0>
   26b8a:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   26b8f:	49 83 c4 01          	add    r12,0x1
   26b93:	49 89 c5             	mov    r13,rax
   26b96:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   26b9a:	ff e0                	jmp    rax
   26b9c:	f3 0f 1e fa          	endbr64
   26ba0:	44 8b 4b f8          	mov    r9d,DWORD PTR [rbx-0x8]
   26ba4:	48 8b 43 f0          	mov    rax,QWORD PTR [rbx-0x10]
   26ba8:	45 85 c9             	test   r9d,r9d
   26bab:	0f 85 60 2c 00 00    	jne    29811 <JS_CallInternal+0x6d31>
   26bb1:	3d ff ff ff 7f       	cmp    eax,0x7fffffff
   26bb6:	0f 84 55 2c 00 00    	je     29811 <JS_CallInternal+0x6d31>
   26bbc:	83 c0 01             	add    eax,0x1
   26bbf:	48 c7 43 08 00 00 00 	mov    QWORD PTR [rbx+0x8],0x0
   26bc6:	00 
   26bc7:	48 89 03             	mov    QWORD PTR [rbx],rax
   26bca:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   26bcf:	48 83 c3 10          	add    rbx,0x10
   26bd3:	49 83 c4 01          	add    r12,0x1
   26bd7:	49 89 c5             	mov    r13,rax
   26bda:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   26bde:	ff e0                	jmp    rax
   26be0:	f3 0f 1e fa          	endbr64
   26be4:	44 8b 53 f8          	mov    r10d,DWORD PTR [rbx-0x8]
   26be8:	48 8b 43 f0          	mov    rax,QWORD PTR [rbx-0x10]
   26bec:	45 85 d2             	test   r10d,r10d
   26bef:	0f 85 7b 2b 00 00    	jne    29770 <JS_CallInternal+0x6c90>
   26bf5:	3d 00 00 00 80       	cmp    eax,0x80000000
   26bfa:	0f 84 70 2b 00 00    	je     29770 <JS_CallInternal+0x6c90>
   26c00:	83 e8 01             	sub    eax,0x1
   26c03:	48 c7 43 f8 00 00 00 	mov    QWORD PTR [rbx-0x8],0x0
   26c0a:	00 
   26c0b:	48 89 43 f0          	mov    QWORD PTR [rbx-0x10],rax
   26c0f:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   26c14:	49 83 c4 01          	add    r12,0x1
   26c18:	49 89 c5             	mov    r13,rax
   26c1b:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   26c1f:	ff e0                	jmp    rax
   26c21:	f3 0f 1e fa          	endbr64
   26c25:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   26c2c:	4c 8b 73 f8          	mov    r14,QWORD PTR [rbx-0x8]
   26c30:	48 8b 73 f0          	mov    rsi,QWORD PTR [rbx-0x10]
   26c34:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   26c38:	41 83 fe ff          	cmp    r14d,0xffffffff
   26c3c:	0f 85 c5 56 00 00    	jne    2c307 <JS_CallInternal+0x9827>
   26c42:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   26c49:	48 8d 8d f0 fe ff ff 	lea    rcx,[rbp-0x110]
   26c50:	4c 89 f2             	mov    rdx,r14
   26c53:	48 89 b5 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],rsi
   26c5a:	e8 c1 66 00 00       	call   2d320 <JS_IteratorGetCompleteValue>
   26c5f:	48 89 c1             	mov    rcx,rax
   26c62:	49 89 d5             	mov    r13,rdx
   26c65:	83 fa 06             	cmp    edx,0x6
   26c68:	0f 84 12 c6 ff ff    	je     23280 <JS_CallInternal+0x7a0>
   26c6e:	48 8b b5 50 fe ff ff 	mov    rsi,QWORD PTR [rbp-0x1b0]
   26c75:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   26c78:	83 e8 01             	sub    eax,0x1
   26c7b:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   26c7e:	85 c0                	test   eax,eax
   26c80:	0f 8e 4a 3d 00 00    	jle    2a9d0 <JS_CallInternal+0x7ef0>
   26c86:	8b bd f0 fe ff ff    	mov    edi,DWORD PTR [rbp-0x110]
   26c8c:	31 c0                	xor    eax,eax
   26c8e:	4c 89 6b f8          	mov    QWORD PTR [rbx-0x8],r13
   26c92:	48 c7 43 e0 00 00 00 	mov    QWORD PTR [rbx-0x20],0x0
   26c99:	00 
   26c9a:	85 ff                	test   edi,edi
   26c9c:	48 c7 43 e8 05 00 00 	mov    QWORD PTR [rbx-0x18],0x5
   26ca3:	00 
   26ca4:	0f 95 c0             	setne  al
   26ca7:	48 89 4b f0          	mov    QWORD PTR [rbx-0x10],rcx
   26cab:	49 83 c4 01          	add    r12,0x1
   26caf:	48 83 c3 10          	add    rbx,0x10
   26cb3:	48 89 43 f0          	mov    QWORD PTR [rbx-0x10],rax
   26cb7:	48 c7 43 f8 01 00 00 	mov    QWORD PTR [rbx-0x8],0x1
   26cbe:	00 
   26cbf:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   26cc5:	49 89 c5             	mov    r13,rax
   26cc8:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   26ccc:	ff e0                	jmp    rax
   26cce:	f3 0f 1e fa          	endbr64
   26cd2:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   26cd9:	4c 8b 6b e8          	mov    r13,QWORD PTR [rbx-0x18]
   26cdd:	4c 8b 4b e0          	mov    r9,QWORD PTR [rbx-0x20]
   26ce1:	4c 8b 73 f8          	mov    r14,QWORD PTR [rbx-0x8]
   26ce5:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   26ce9:	48 8b 43 f0          	mov    rax,QWORD PTR [rbx-0x10]
   26ced:	48 89 85 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],rax
   26cf4:	41 83 fd ff          	cmp    r13d,0xffffffff
   26cf8:	0f 85 ef 5f 00 00    	jne    2cced <JS_CallInternal+0xa20d>
   26cfe:	41 83 fe ff          	cmp    r14d,0xffffffff
   26d02:	0f 84 b1 2c 00 00    	je     299b9 <JS_CallInternal+0x6ed9>
   26d08:	48 8b b5 50 fe ff ff 	mov    rsi,QWORD PTR [rbp-0x1b0]
   26d0f:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   26d16:	4c 89 f2             	mov    rdx,r14
   26d19:	4c 89 8d 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],r9
   26d20:	e8 bb c7 01 00       	call   434e0 <JS_ValueToAtom>
   26d25:	85 c0                	test   eax,eax
   26d27:	0f 84 53 c5 ff ff    	je     23280 <JS_CallInternal+0x7a0>
   26d2d:	4c 8b 8d 40 fe ff ff 	mov    r9,QWORD PTR [rbp-0x1c0]
   26d34:	89 c2                	mov    edx,eax
   26d36:	49 8b 49 18          	mov    rcx,QWORD PTR [r9+0x18]
   26d3a:	8b 71 18             	mov    esi,DWORD PTR [rcx+0x18]
   26d3d:	21 f2                	and    edx,esi
   26d3f:	8b 54 91 38          	mov    edx,DWORD PTR [rcx+rdx*4+0x38]
   26d43:	48 85 d2             	test   rdx,rdx
   26d46:	0f 84 79 54 00 00    	je     2c1c5 <JS_CallInternal+0x96e5>
   26d4c:	48 8d 34 b5 34 00 00 	lea    rsi,[rsi*4+0x34]
   26d53:	00 
   26d54:	48 8d 14 d6          	lea    rdx,[rsi+rdx*8]
   26d58:	48 01 ca             	add    rdx,rcx
   26d5b:	3b 42 04             	cmp    eax,DWORD PTR [rdx+0x4]
   26d5e:	0f 85 53 54 00 00    	jne    2c1b7 <JS_CallInternal+0x96d7>
   26d64:	3d f2 00 00 00       	cmp    eax,0xf2
   26d69:	0f 8f 49 35 00 00    	jg     2a2b8 <JS_CallInternal+0x77d8>
   26d6f:	48 85 d2             	test   rdx,rdx
   26d72:	0f 95 c0             	setne  al
   26d75:	41 83 fd f6          	cmp    r13d,0xfffffff6
   26d79:	76 13                	jbe    26d8e <JS_CallInternal+0x42ae>
   26d7b:	41 8b 49 fc          	mov    ecx,DWORD PTR [r9-0x4]
   26d7f:	8d 51 ff             	lea    edx,[rcx-0x1]
   26d82:	41 89 51 fc          	mov    DWORD PTR [r9-0x4],edx
   26d86:	85 d2                	test   edx,edx
   26d88:	0f 8e 53 37 00 00    	jle    2a4e1 <JS_CallInternal+0x7a01>
   26d8e:	41 83 fe f6          	cmp    r14d,0xfffffff6
   26d92:	76 1e                	jbe    26db2 <JS_CallInternal+0x42d2>
   26d94:	48 8b 8d 50 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x1b0]
   26d9b:	8b 79 fc             	mov    edi,DWORD PTR [rcx-0x4]
   26d9e:	8d 57 ff             	lea    edx,[rdi-0x1]
   26da1:	89 bd 40 fe ff ff    	mov    DWORD PTR [rbp-0x1c0],edi
   26da7:	89 51 fc             	mov    DWORD PTR [rcx-0x4],edx
   26daa:	85 d2                	test   edx,edx
   26dac:	0f 8e 3d 39 00 00    	jle    2a6ef <JS_CallInternal+0x7c0f>
   26db2:	0f b6 c0             	movzx  eax,al
   26db5:	48 c7 43 e8 01 00 00 	mov    QWORD PTR [rbx-0x18],0x1
   26dbc:	00 
   26dbd:	49 83 c4 01          	add    r12,0x1
   26dc1:	48 83 eb 10          	sub    rbx,0x10
   26dc5:	48 89 43 f0          	mov    QWORD PTR [rbx-0x10],rax
   26dc9:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   26dcf:	49 89 c5             	mov    r13,rax
   26dd2:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   26dd6:	ff e0                	jmp    rax
   26dd8:	f3 0f 1e fa          	endbr64
   26ddc:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   26de3:	4c 8b 6b f8          	mov    r13,QWORD PTR [rbx-0x8]
   26de7:	4c 8b 73 e0          	mov    r14,QWORD PTR [rbx-0x20]
   26deb:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   26def:	48 8b 43 e8          	mov    rax,QWORD PTR [rbx-0x18]
   26df3:	48 89 85 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],rax
   26dfa:	48 8b 43 f0          	mov    rax,QWORD PTR [rbx-0x10]
   26dfe:	48 89 85 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],rax
   26e05:	41 83 fd ff          	cmp    r13d,0xffffffff
   26e09:	0f 85 3d 55 00 00    	jne    2c34c <JS_CallInternal+0x986c>
   26e0f:	48 8b 95 50 fe ff ff 	mov    rdx,QWORD PTR [rbp-0x1b0]
   26e16:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   26e1d:	4c 89 f6             	mov    rsi,r14
   26e20:	e8 bb c6 01 00       	call   434e0 <JS_ValueToAtom>
   26e25:	89 c1                	mov    ecx,eax
   26e27:	85 c0                	test   eax,eax
   26e29:	0f 84 51 c4 ff ff    	je     23280 <JS_CallInternal+0x7a0>
   26e2f:	48 8b b5 40 fe ff ff 	mov    rsi,QWORD PTR [rbp-0x1c0]
   26e36:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   26e3d:	4c 89 ea             	mov    rdx,r13
   26e40:	89 85 38 fe ff ff    	mov    DWORD PTR [rbp-0x1c8],eax
   26e46:	e8 75 73 04 00       	call   6e1c0 <JS_HasProperty>
   26e4b:	8b 8d 38 fe ff ff    	mov    ecx,DWORD PTR [rbp-0x1c8]
   26e51:	41 89 c0             	mov    r8d,eax
   26e54:	81 f9 f2 00 00 00    	cmp    ecx,0xf2
   26e5a:	0f 8f b9 2e 00 00    	jg     29d19 <JS_CallInternal+0x7239>
   26e60:	45 85 c0             	test   r8d,r8d
   26e63:	0f 88 17 c4 ff ff    	js     23280 <JS_CallInternal+0x7a0>
   26e69:	83 bd 50 fe ff ff f6 	cmp    DWORD PTR [rbp-0x1b0],0xfffffff6
   26e70:	76 13                	jbe    26e85 <JS_CallInternal+0x43a5>
   26e72:	41 8b 46 fc          	mov    eax,DWORD PTR [r14-0x4]
   26e76:	83 e8 01             	sub    eax,0x1
   26e79:	41 89 46 fc          	mov    DWORD PTR [r14-0x4],eax
   26e7d:	85 c0                	test   eax,eax
   26e7f:	0f 8e a7 47 00 00    	jle    2b62c <JS_CallInternal+0x8b4c>
   26e85:	41 83 fd f6          	cmp    r13d,0xfffffff6
   26e89:	76 1e                	jbe    26ea9 <JS_CallInternal+0x43c9>
   26e8b:	48 8b 8d 40 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x1c0]
   26e92:	8b 41 fc             	mov    eax,DWORD PTR [rcx-0x4]
   26e95:	89 85 50 fe ff ff    	mov    DWORD PTR [rbp-0x1b0],eax
   26e9b:	83 e8 01             	sub    eax,0x1
   26e9e:	89 41 fc             	mov    DWORD PTR [rcx-0x4],eax
   26ea1:	85 c0                	test   eax,eax
   26ea3:	0f 8e 6f 4b 00 00    	jle    2ba18 <JS_CallInternal+0x8f38>
   26ea9:	31 c0                	xor    eax,eax
   26eab:	45 85 c0             	test   r8d,r8d
   26eae:	48 c7 43 e8 01 00 00 	mov    QWORD PTR [rbx-0x18],0x1
   26eb5:	00 
   26eb6:	0f 95 c0             	setne  al
   26eb9:	48 83 eb 10          	sub    rbx,0x10
   26ebd:	49 83 c4 01          	add    r12,0x1
   26ec1:	48 89 43 f0          	mov    QWORD PTR [rbx-0x10],rax
   26ec5:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   26ecb:	49 89 c5             	mov    r13,rax
   26ece:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   26ed2:	ff e0                	jmp    rax
   26ed4:	f3 0f 1e fa          	endbr64
   26ed8:	48 8b 43 f8          	mov    rax,QWORD PTR [rbx-0x8]
   26edc:	48 8b 73 e8          	mov    rsi,QWORD PTR [rbx-0x18]
   26ee0:	48 8b 4b e0          	mov    rcx,QWORD PTR [rbx-0x20]
   26ee4:	48 8b 53 f0          	mov    rdx,QWORD PTR [rbx-0x10]
   26ee8:	89 c7                	mov    edi,eax
   26eea:	09 f7                	or     edi,esi
   26eec:	0f 85 6b 4b 00 00    	jne    2ba5d <JS_CallInternal+0x8f7d>
   26ef2:	48 63 f2             	movsxd rsi,edx
   26ef5:	48 63 c1             	movsxd rax,ecx
   26ef8:	48 0f af c6          	imul   rax,rsi
   26efc:	48 63 f0             	movsxd rsi,eax
   26eff:	48 39 c6             	cmp    rsi,rax
   26f02:	0f 85 39 4b 00 00    	jne    2ba41 <JS_CallInternal+0x8f61>
   26f08:	48 85 f6             	test   rsi,rsi
   26f0b:	0f 84 cf 4b 00 00    	je     2bae0 <JS_CallInternal+0x9000>
   26f11:	83 e0 ff             	and    eax,0xffffffff
   26f14:	48 8d 53 f0          	lea    rdx,[rbx-0x10]
   26f18:	48 89 43 e0          	mov    QWORD PTR [rbx-0x20],rax
   26f1c:	31 c0                	xor    eax,eax
   26f1e:	48 89 43 e8          	mov    QWORD PTR [rbx-0x18],rax
   26f22:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   26f27:	48 89 d3             	mov    rbx,rdx
   26f2a:	49 83 c4 01          	add    r12,0x1
   26f2e:	49 89 c5             	mov    r13,rax
   26f31:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   26f35:	ff e0                	jmp    rax
   26f37:	f3 0f 1e fa          	endbr64
   26f3b:	48 8b 43 f8          	mov    rax,QWORD PTR [rbx-0x8]
   26f3f:	48 8b 53 e8          	mov    rdx,QWORD PTR [rbx-0x18]
   26f43:	48 8b 7b e0          	mov    rdi,QWORD PTR [rbx-0x20]
   26f47:	48 8b 4b f0          	mov    rcx,QWORD PTR [rbx-0x10]
   26f4b:	89 c6                	mov    esi,eax
   26f4d:	09 d6                	or     esi,edx
   26f4f:	0f 85 64 46 00 00    	jne    2b5b9 <JS_CallInternal+0x8ad9>
   26f55:	89 fa                	mov    edx,edi
   26f57:	48 63 f1             	movsxd rsi,ecx
   26f5a:	48 63 c7             	movsxd rax,edi
   26f5d:	29 ca                	sub    edx,ecx
   26f5f:	48 29 f0             	sub    rax,rsi
   26f62:	48 63 ca             	movsxd rcx,edx
   26f65:	48 39 c1             	cmp    rcx,rax
   26f68:	0f 85 33 46 00 00    	jne    2b5a1 <JS_CallInternal+0x8ac1>
   26f6e:	89 d0                	mov    eax,edx
   26f70:	48 89 43 e0          	mov    QWORD PTR [rbx-0x20],rax
   26f74:	31 c0                	xor    eax,eax
   26f76:	48 8d 53 f0          	lea    rdx,[rbx-0x10]
   26f7a:	48 89 43 e8          	mov    QWORD PTR [rbx-0x18],rax
   26f7e:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   26f83:	48 89 d3             	mov    rbx,rdx
   26f86:	49 83 c4 01          	add    r12,0x1
   26f8a:	49 89 c5             	mov    r13,rax
   26f8d:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   26f91:	ff e0                	jmp    rax
   26f93:	f3 0f 1e fa          	endbr64
   26f97:	45 0f b6 2c 24       	movzx  r13d,BYTE PTR [r12]
   26f9c:	48 8b 85 b0 fe ff ff 	mov    rax,QWORD PTR [rbp-0x150]
   26fa3:	4d 8d 4c 24 01       	lea    r9,[r12+0x1]
   26fa8:	4c 8b 73 f8          	mov    r14,QWORD PTR [rbx-0x8]
   26fac:	4c 8b 43 f0          	mov    r8,QWORD PTR [rbx-0x10]
   26fb0:	49 c1 e5 04          	shl    r13,0x4
   26fb4:	49 01 c5             	add    r13,rax
   26fb7:	44 89 f1             	mov    ecx,r14d
   26fba:	49 8b 55 08          	mov    rdx,QWORD PTR [r13+0x8]
   26fbe:	09 d1                	or     ecx,edx
   26fc0:	0f 85 cb 43 00 00    	jne    2b391 <JS_CallInternal+0x88b1>
   26fc6:	49 8b 45 00          	mov    rax,QWORD PTR [r13+0x0]
   26fca:	49 63 c8             	movsxd rcx,r8d
   26fcd:	48 63 d0             	movsxd rdx,eax
   26fd0:	44 01 c0             	add    eax,r8d
   26fd3:	48 01 ca             	add    rdx,rcx
   26fd6:	48 63 c8             	movsxd rcx,eax
   26fd9:	48 39 d1             	cmp    rcx,rdx
   26fdc:	0f 85 96 43 00 00    	jne    2b378 <JS_CallInternal+0x8898>
   26fe2:	89 c0                	mov    eax,eax
   26fe4:	49 89 45 00          	mov    QWORD PTR [r13+0x0],rax
   26fe8:	31 c0                	xor    eax,eax
   26fea:	49 89 45 08          	mov    QWORD PTR [r13+0x8],rax
   26fee:	48 83 eb 10          	sub    rbx,0x10
   26ff2:	41 0f b6 44 24 01    	movzx  eax,BYTE PTR [r12+0x1]
   26ff8:	49 83 c4 02          	add    r12,0x2
   26ffc:	49 89 c5             	mov    r13,rax
   26fff:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   27003:	ff e0                	jmp    rax
   27005:	f3 0f 1e fa          	endbr64
   27009:	48 8b 7b f8          	mov    rdi,QWORD PTR [rbx-0x8]
   2700d:	4c 8b 5b e8          	mov    r11,QWORD PTR [rbx-0x18]
   27011:	4c 8b 43 f0          	mov    r8,QWORD PTR [rbx-0x10]
   27015:	4c 8b 53 e0          	mov    r10,QWORD PTR [rbx-0x20]
   27019:	41 89 fe             	mov    r14d,edi
   2701c:	4c 89 de             	mov    rsi,r11
   2701f:	48 89 f9             	mov    rcx,rdi
   27022:	45 09 de             	or     r14d,r11d
   27025:	4c 89 c0             	mov    rax,r8
   27028:	0f 85 46 42 00 00    	jne    2b274 <JS_CallInternal+0x8794>
   2702e:	49 63 ca             	movsxd rcx,r10d
   27031:	49 63 f0             	movsxd rsi,r8d
   27034:	44 01 d0             	add    eax,r10d
   27037:	48 01 f1             	add    rcx,rsi
   2703a:	48 63 d0             	movsxd rdx,eax
   2703d:	48 39 ca             	cmp    rdx,rcx
   27040:	0f 85 16 42 00 00    	jne    2b25c <JS_CallInternal+0x877c>
   27046:	89 c0                	mov    eax,eax
   27048:	48 89 43 e0          	mov    QWORD PTR [rbx-0x20],rax
   2704c:	31 c0                	xor    eax,eax
   2704e:	48 89 43 e8          	mov    QWORD PTR [rbx-0x18],rax
   27052:	48 83 eb 10          	sub    rbx,0x10
   27056:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   2705b:	49 83 c4 01          	add    r12,0x1
   2705f:	49 89 c5             	mov    r13,rax
   27062:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   27066:	ff e0                	jmp    rax
   27068:	f3 0f 1e fa          	endbr64
   2706c:	8b 7b f8             	mov    edi,DWORD PTR [rbx-0x8]
   2706f:	48 8b 43 f0          	mov    rax,QWORD PTR [rbx-0x10]
   27073:	85 ff                	test   edi,edi
   27075:	0f 85 1a 2b 00 00    	jne    29b95 <JS_CallInternal+0x70b5>
   2707b:	f7 d0                	not    eax
   2707d:	48 c7 43 f8 00 00 00 	mov    QWORD PTR [rbx-0x8],0x0
   27084:	00 
   27085:	48 89 43 f0          	mov    QWORD PTR [rbx-0x10],rax
   27089:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   2708e:	49 83 c4 01          	add    r12,0x1
   27092:	49 89 c5             	mov    r13,rax
   27095:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   27099:	ff e0                	jmp    rax
   2709b:	f3 0f 1e fa          	endbr64
   2709f:	45 0f b6 2c 24       	movzx  r13d,BYTE PTR [r12]
   270a4:	48 8b 85 b0 fe ff ff 	mov    rax,QWORD PTR [rbp-0x150]
   270ab:	4d 8d 74 24 01       	lea    r14,[r12+0x1]
   270b0:	49 c1 e5 04          	shl    r13,0x4
   270b4:	49 01 c5             	add    r13,rax
   270b7:	f3 41 0f 6f 6d 00    	movdqu xmm5,XMMWORD PTR [r13+0x0]
   270bd:	0f 29 ad f0 fe ff ff 	movaps XMMWORD PTR [rbp-0x110],xmm5
   270c4:	48 8b 95 f8 fe ff ff 	mov    rdx,QWORD PTR [rbp-0x108]
   270cb:	48 8b 85 f0 fe ff ff 	mov    rax,QWORD PTR [rbp-0x110]
   270d2:	85 d2                	test   edx,edx
   270d4:	0f 85 3e 23 00 00    	jne    29418 <JS_CallInternal+0x6938>
   270da:	3d 00 00 00 80       	cmp    eax,0x80000000
   270df:	0f 84 33 23 00 00    	je     29418 <JS_CallInternal+0x6938>
   270e5:	83 e8 01             	sub    eax,0x1
   270e8:	49 c7 45 08 00 00 00 	mov    QWORD PTR [r13+0x8],0x0
   270ef:	00 
   270f0:	49 89 45 00          	mov    QWORD PTR [r13+0x0],rax
   270f4:	41 0f b6 44 24 01    	movzx  eax,BYTE PTR [r12+0x1]
   270fa:	49 83 c4 02          	add    r12,0x2
   270fe:	49 89 c5             	mov    r13,rax
   27101:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   27105:	ff e0                	jmp    rax
   27107:	f3 0f 1e fa          	endbr64
   2710b:	48 8b 8d e8 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x118]
   27112:	4d 63 2c 24          	movsxd r13,DWORD PTR [r12]
   27116:	8b 81 a8 01 00 00    	mov    eax,DWORD PTR [rcx+0x1a8]
   2711c:	4d 01 e5             	add    r13,r12
   2711f:	89 85 50 fe ff ff    	mov    DWORD PTR [rbp-0x1b0],eax
   27125:	83 e8 01             	sub    eax,0x1
   27128:	89 81 a8 01 00 00    	mov    DWORD PTR [rcx+0x1a8],eax
   2712e:	85 c0                	test   eax,eax
   27130:	0f 8e 43 40 00 00    	jle    2b179 <JS_CallInternal+0x8699>
   27136:	41 0f b6 45 00       	movzx  eax,BYTE PTR [r13+0x0]
   2713b:	4d 8d 65 01          	lea    r12,[r13+0x1]
   2713f:	49 89 c5             	mov    r13,rax
   27142:	41 ff 24 c7          	jmp    QWORD PTR [r15+rax*8]
   27146:	f3 0f 1e fa          	endbr64
   2714a:	48 8b 4b f8          	mov    rcx,QWORD PTR [rbx-0x8]
   2714e:	48 8b 73 e8          	mov    rsi,QWORD PTR [rbx-0x18]
   27152:	48 8b 43 e0          	mov    rax,QWORD PTR [rbx-0x20]
   27156:	48 8b 53 f0          	mov    rdx,QWORD PTR [rbx-0x10]
   2715a:	89 cf                	mov    edi,ecx
   2715c:	09 f7                	or     edi,esi
   2715e:	0f 85 7a 47 00 00    	jne    2b8de <JS_CallInternal+0x8dfe>
   27164:	39 d0                	cmp    eax,edx
   27166:	48 c7 43 e8 01 00 00 	mov    QWORD PTR [rbx-0x18],0x1
   2716d:	00 
   2716e:	0f 9e c0             	setle  al
   27171:	48 83 eb 10          	sub    rbx,0x10
   27175:	0f b6 c0             	movzx  eax,al
   27178:	48 89 43 f0          	mov    QWORD PTR [rbx-0x10],rax
   2717c:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   27181:	49 83 c4 01          	add    r12,0x1
   27185:	49 89 c5             	mov    r13,rax
   27188:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   2718c:	ff e0                	jmp    rax
   2718e:	f3 0f 1e fa          	endbr64
   27192:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   27199:	4c 8b 73 f8          	mov    r14,QWORD PTR [rbx-0x8]
   2719d:	4c 8b 6b f0          	mov    r13,QWORD PTR [rbx-0x10]
   271a1:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   271a5:	41 83 fe ff          	cmp    r14d,0xffffffff
   271a9:	0f 84 65 24 00 00    	je     29614 <JS_CallInternal+0x6b34>
   271af:	41 83 fe 02          	cmp    r14d,0x2
   271b3:	0f 84 5b 24 00 00    	je     29614 <JS_CallInternal+0x6b34>
   271b9:	41 83 fe f6          	cmp    r14d,0xfffffff6
   271bd:	76 13                	jbe    271d2 <JS_CallInternal+0x46f2>
   271bf:	41 8b 45 fc          	mov    eax,DWORD PTR [r13-0x4]
   271c3:	83 e8 01             	sub    eax,0x1
   271c6:	41 89 45 fc          	mov    DWORD PTR [r13-0x4],eax
   271ca:	85 c0                	test   eax,eax
   271cc:	0f 8e e6 39 00 00    	jle    2abb8 <JS_CallInternal+0x80d8>
   271d2:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   271d7:	48 83 eb 10          	sub    rbx,0x10
   271db:	49 83 c4 01          	add    r12,0x1
   271df:	49 89 c5             	mov    r13,rax
   271e2:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   271e6:	ff e0                	jmp    rax
   271e8:	f3 0f 1e fa          	endbr64
   271ec:	48 8b 43 f8          	mov    rax,QWORD PTR [rbx-0x8]
   271f0:	0b 43 e8             	or     eax,DWORD PTR [rbx-0x18]
   271f3:	48 8b 4b e0          	mov    rcx,QWORD PTR [rbx-0x20]
   271f7:	48 8b 53 f0          	mov    rdx,QWORD PTR [rbx-0x10]
   271fb:	0f 85 d6 c9 ff ff    	jne    23bd7 <JS_CallInternal+0x10f7>
   27201:	89 c8                	mov    eax,ecx
   27203:	89 d6                	mov    esi,edx
   27205:	85 c9                	test   ecx,ecx
   27207:	0f 88 ca c9 ff ff    	js     23bd7 <JS_CallInternal+0x10f7>
   2720d:	85 d2                	test   edx,edx
   2720f:	0f 8e c2 c9 ff ff    	jle    23bd7 <JS_CallInternal+0x10f7>
   27215:	99                   	cdq
   27216:	48 c7 43 e8 00 00 00 	mov    QWORD PTR [rbx-0x18],0x0
   2721d:	00 
   2721e:	49 83 c4 01          	add    r12,0x1
   27222:	48 83 eb 10          	sub    rbx,0x10
   27226:	f7 fe                	idiv   esi
   27228:	48 63 d2             	movsxd rdx,edx
   2722b:	48 89 53 f0          	mov    QWORD PTR [rbx-0x10],rdx
   2722f:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   27235:	49 89 c5             	mov    r13,rax
   27238:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   2723c:	ff e0                	jmp    rax
   2723e:	f3 0f 1e fa          	endbr64
   27242:	48 8b 43 f8          	mov    rax,QWORD PTR [rbx-0x8]
   27246:	48 8b 53 f0          	mov    rdx,QWORD PTR [rbx-0x10]
   2724a:	a9 f7 ff ff ff       	test   eax,0xfffffff7
   2724f:	74 1b                	je     2726c <JS_CallInternal+0x478c>
   27251:	83 e8 01             	sub    eax,0x1
   27254:	83 f8 01             	cmp    eax,0x1
   27257:	0f 87 2e 30 00 00    	ja     2a28b <JS_CallInternal+0x77ab>
   2725d:	83 e2 ff             	and    edx,0xffffffff
   27260:	48 c7 43 f8 00 00 00 	mov    QWORD PTR [rbx-0x8],0x0
   27267:	00 
   27268:	48 89 53 f0          	mov    QWORD PTR [rbx-0x10],rdx
   2726c:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   27271:	49 83 c4 01          	add    r12,0x1
   27275:	49 89 c5             	mov    r13,rax
   27278:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   2727c:	ff e0                	jmp    rax
   2727e:	f3 0f 1e fa          	endbr64
   27282:	48 8b 43 f8          	mov    rax,QWORD PTR [rbx-0x8]
   27286:	0b 43 e8             	or     eax,DWORD PTR [rbx-0x18]
   27289:	48 8b 4b e0          	mov    rcx,QWORD PTR [rbx-0x20]
   2728d:	48 8b 53 f0          	mov    rdx,QWORD PTR [rbx-0x10]
   27291:	0f 85 40 c9 ff ff    	jne    23bd7 <JS_CallInternal+0x10f7>
   27297:	66 0f ef c0          	pxor   xmm0,xmm0
   2729b:	66 0f ef c9          	pxor   xmm1,xmm1
   2729f:	f2 0f 2a c1          	cvtsi2sd xmm0,ecx
   272a3:	f2 0f 2a ca          	cvtsi2sd xmm1,edx
   272a7:	f2 0f 5e c1          	divsd  xmm0,xmm1
   272ab:	66 0f 2f 05 55 c1 0a 	comisd xmm0,QWORD PTR [rip+0xac155]        # d3408 <__PRETTY_FUNCTION__.0+0xc8>
   272b2:	00 
   272b3:	66 48 0f 7e c0       	movq   rax,xmm0
   272b8:	0f 82 d6 1e 00 00    	jb     29194 <JS_CallInternal+0x66b4>
   272be:	f2 0f 10 0d 4a c1 0a 	movsd  xmm1,QWORD PTR [rip+0xac14a]        # d3410 <__PRETTY_FUNCTION__.0+0xd0>
   272c5:	00 
   272c6:	66 0f 2f c8          	comisd xmm1,xmm0
   272ca:	0f 82 c4 1e 00 00    	jb     29194 <JS_CallInternal+0x66b4>
   272d0:	f2 0f 2c c8          	cvttsd2si ecx,xmm0
   272d4:	66 0f ef c9          	pxor   xmm1,xmm1
   272d8:	ba 08 00 00 00       	mov    edx,0x8
   272dd:	f2 0f 2a c9          	cvtsi2sd xmm1,ecx
   272e1:	66 48 0f 7e ce       	movq   rsi,xmm1
   272e6:	48 39 f0             	cmp    rax,rsi
   272e9:	0f 84 7b 4e 00 00    	je     2c16a <JS_CallInternal+0x968a>
   272ef:	48 89 43 e0          	mov    QWORD PTR [rbx-0x20],rax
   272f3:	49 83 c4 01          	add    r12,0x1
   272f7:	48 83 eb 10          	sub    rbx,0x10
   272fb:	48 89 53 f8          	mov    QWORD PTR [rbx-0x8],rdx
   272ff:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   27305:	49 89 c5             	mov    r13,rax
   27308:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   2730c:	ff e0                	jmp    rax
   2730e:	f3 0f 1e fa          	endbr64
   27312:	44 8b 5b f8          	mov    r11d,DWORD PTR [rbx-0x8]
   27316:	48 8b 43 f0          	mov    rax,QWORD PTR [rbx-0x10]
   2731a:	45 85 db             	test   r11d,r11d
   2731d:	0f 85 ec 23 00 00    	jne    2970f <JS_CallInternal+0x6c2f>
   27323:	3d ff ff ff 7f       	cmp    eax,0x7fffffff
   27328:	0f 84 e1 23 00 00    	je     2970f <JS_CallInternal+0x6c2f>
   2732e:	83 c0 01             	add    eax,0x1
   27331:	48 c7 43 f8 00 00 00 	mov    QWORD PTR [rbx-0x8],0x0
   27338:	00 
   27339:	48 89 43 f0          	mov    QWORD PTR [rbx-0x10],rax
   2733d:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   27342:	49 83 c4 01          	add    r12,0x1
   27346:	49 89 c5             	mov    r13,rax
   27349:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   2734d:	ff e0                	jmp    rax
   2734f:	f3 0f 1e fa          	endbr64
   27353:	48 8b 53 f8          	mov    rdx,QWORD PTR [rbx-0x8]
   27357:	48 8b 43 f0          	mov    rax,QWORD PTR [rbx-0x10]
   2735b:	83 fa 02             	cmp    edx,0x2
   2735e:	0f 87 26 22 00 00    	ja     2958a <JS_CallInternal+0x6aaa>
   27364:	85 c0                	test   eax,eax
   27366:	0f 84 3c 4a 00 00    	je     2bda8 <JS_CallInternal+0x92c8>
   2736c:	3d 00 00 00 80       	cmp    eax,0x80000000
   27371:	0f 84 14 4b 00 00    	je     2be8b <JS_CallInternal+0x93ab>
   27377:	f7 d8                	neg    eax
   27379:	48 c7 43 f8 00 00 00 	mov    QWORD PTR [rbx-0x8],0x0
   27380:	00 
   27381:	48 89 43 f0          	mov    QWORD PTR [rbx-0x10],rax
   27385:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   2738a:	49 83 c4 01          	add    r12,0x1
   2738e:	49 89 c5             	mov    r13,rax
   27391:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   27395:	ff e0                	jmp    rax
   27397:	f3 0f 1e fa          	endbr64
   2739b:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   273a2:	4c 8d 6b f0          	lea    r13,[rbx-0x10]
   273a6:	48 8b 4b c0          	mov    rcx,QWORD PTR [rbx-0x40]
   273aa:	48 c7 85 00 fe ff ff 	mov    QWORD PTR [rbp-0x200],0x0
   273b1:	00 00 00 00 
   273b5:	4c 8b 43 c8          	mov    r8,QWORD PTR [rbx-0x38]
   273b9:	48 8b 73 d0          	mov    rsi,QWORD PTR [rbx-0x30]
   273bd:	41 b9 01 00 00 00    	mov    r9d,0x1
   273c3:	48 c7 85 08 fe ff ff 	mov    QWORD PTR [rbp-0x1f8],0x3
   273ca:	03 00 00 00 
   273ce:	48 8b 53 d8          	mov    rdx,QWORD PTR [rbx-0x28]
   273d2:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   273d9:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   273dd:	6a 02                	push   0x2
   273df:	41 55                	push   r13
   273e1:	ff b5 08 fe ff ff    	push   QWORD PTR [rbp-0x1f8]
   273e7:	ff b5 00 fe ff ff    	push   QWORD PTR [rbp-0x200]
   273ed:	e8 ee b6 ff ff       	call   22ae0 <JS_CallInternal>
   273f2:	48 83 c4 20          	add    rsp,0x20
   273f6:	48 89 c1             	mov    rcx,rax
   273f9:	49 89 d6             	mov    r14,rdx
   273fc:	83 fa 06             	cmp    edx,0x6
   273ff:	0f 84 7b be ff ff    	je     23280 <JS_CallInternal+0x7a0>
   27405:	48 8b 53 f8          	mov    rdx,QWORD PTR [rbx-0x8]
   27409:	48 8b 73 f0          	mov    rsi,QWORD PTR [rbx-0x10]
   2740d:	83 fa f6             	cmp    edx,0xfffffff6
   27410:	76 11                	jbe    27423 <JS_CallInternal+0x4943>
   27412:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   27415:	83 e8 01             	sub    eax,0x1
   27418:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   2741b:	85 c0                	test   eax,eax
   2741d:	0f 8e 55 30 00 00    	jle    2a478 <JS_CallInternal+0x7998>
   27423:	48 89 4b f0          	mov    QWORD PTR [rbx-0x10],rcx
   27427:	49 83 c4 01          	add    r12,0x1
   2742b:	4c 89 73 f8          	mov    QWORD PTR [rbx-0x8],r14
   2742f:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   27435:	49 89 c5             	mov    r13,rax
   27438:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   2743c:	ff e0                	jmp    rax
   2743e:	f3 0f 1e fa          	endbr64
   27442:	48 8b 53 e8          	mov    rdx,QWORD PTR [rbx-0x18]
   27446:	4c 8d 6b e0          	lea    r13,[rbx-0x20]
   2744a:	48 8b 73 e0          	mov    rsi,QWORD PTR [rbx-0x20]
   2744e:	83 fa f6             	cmp    edx,0xfffffff6
   27451:	76 11                	jbe    27464 <JS_CallInternal+0x4984>
   27453:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   27456:	83 e8 01             	sub    eax,0x1
   27459:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   2745c:	85 c0                	test   eax,eax
   2745e:	0f 8e 37 30 00 00    	jle    2a49b <JS_CallInternal+0x79bb>
   27464:	48 8b 43 d8          	mov    rax,QWORD PTR [rbx-0x28]
   27468:	48 83 eb 30          	sub    rbx,0x30
   2746c:	83 f8 03             	cmp    eax,0x3
   2746f:	74 45                	je     274b6 <JS_CallInternal+0x49d6>
   27471:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   27478:	48 8b 33             	mov    rsi,QWORD PTR [rbx]
   2747b:	31 c9                	xor    ecx,ecx
   2747d:	48 8b 53 08          	mov    rdx,QWORD PTR [rbx+0x8]
   27481:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   27488:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   2748c:	e8 df 9a 00 00       	call   30f70 <JS_IteratorClose>
   27491:	85 c0                	test   eax,eax
   27493:	0f 85 0f 58 00 00    	jne    2cca8 <JS_CallInternal+0xa1c8>
   27499:	48 8b 53 08          	mov    rdx,QWORD PTR [rbx+0x8]
   2749d:	48 8b 33             	mov    rsi,QWORD PTR [rbx]
   274a0:	83 fa f6             	cmp    edx,0xfffffff6
   274a3:	76 11                	jbe    274b6 <JS_CallInternal+0x49d6>
   274a5:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   274a8:	83 e8 01             	sub    eax,0x1
   274ab:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   274ae:	85 c0                	test   eax,eax
   274b0:	0f 8e 16 4d 00 00    	jle    2c1cc <JS_CallInternal+0x96ec>
   274b6:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   274bb:	49 83 c4 01          	add    r12,0x1
   274bf:	49 89 c5             	mov    r13,rax
   274c2:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   274c6:	ff e0                	jmp    rax
   274c8:	f3 0f 1e fa          	endbr64
   274cc:	4c 8b 43 f8          	mov    r8,QWORD PTR [rbx-0x8]
   274d0:	48 8b 73 f0          	mov    rsi,QWORD PTR [rbx-0x10]
   274d4:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   274db:	4c 89 c2             	mov    rdx,r8
   274de:	e8 dd 44 ff ff       	call   1b9c0 <js_operator_typeof>
   274e3:	41 89 c5             	mov    r13d,eax
   274e6:	41 83 f8 f6          	cmp    r8d,0xfffffff6
   274ea:	76 11                	jbe    274fd <JS_CallInternal+0x4a1d>
   274ec:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   274ef:	83 e8 01             	sub    eax,0x1
   274f2:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   274f5:	85 c0                	test   eax,eax
   274f7:	0f 8e 98 34 00 00    	jle    2a995 <JS_CallInternal+0x7eb5>
   274fd:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   27504:	44 89 ee             	mov    esi,r13d
   27507:	ba 01 00 00 00       	mov    edx,0x1
   2750c:	49 83 c4 01          	add    r12,0x1
   27510:	e8 db ca 00 00       	call   33ff0 <__JS_AtomToValue>
   27515:	48 89 43 f0          	mov    QWORD PTR [rbx-0x10],rax
   27519:	48 89 53 f8          	mov    QWORD PTR [rbx-0x8],rdx
   2751d:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   27523:	49 89 c5             	mov    r13,rax
   27526:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   2752a:	ff e0                	jmp    rax
   2752c:	f3 0f 1e fa          	endbr64
   27530:	83 7b f8 ff          	cmp    DWORD PTR [rbx-0x8],0xffffffff
   27534:	0f 85 8d 37 00 00    	jne    2acc7 <JS_CallInternal+0x81e7>
   2753a:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   2753f:	49 83 c4 01          	add    r12,0x1
   27543:	49 89 c5             	mov    r13,rax
   27546:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   2754a:	ff e0                	jmp    rax
   2754c:	f3 0f 1e fa          	endbr64
   27550:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   27557:	48 8b 73 e0          	mov    rsi,QWORD PTR [rbx-0x20]
   2755b:	48 8b 53 e8          	mov    rdx,QWORD PTR [rbx-0x18]
   2755f:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   27566:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   2756a:	48 8d 43 e0          	lea    rax,[rbx-0x20]
   2756e:	48 89 85 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],rax
   27575:	e8 66 bf 01 00       	call   434e0 <JS_ValueToAtom>
   2757a:	41 89 c5             	mov    r13d,eax
   2757d:	45 85 ed             	test   r13d,r13d
   27580:	0f 84 fa bc ff ff    	je     23280 <JS_CallInternal+0x7a0>
   27586:	83 7b d8 03          	cmp    DWORD PTR [rbx-0x28],0x3
   2758a:	0f 84 44 3a 00 00    	je     2afd4 <JS_CallInternal+0x84f4>
   27590:	48 8b 73 d0          	mov    rsi,QWORD PTR [rbx-0x30]
   27594:	48 8b 53 d8          	mov    rdx,QWORD PTR [rbx-0x28]
   27598:	44 89 e9             	mov    ecx,r13d
   2759b:	4c 8d 73 d0          	lea    r14,[rbx-0x30]
   2759f:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   275a6:	e8 15 6c 04 00       	call   6e1c0 <JS_HasProperty>
   275ab:	85 c0                	test   eax,eax
   275ad:	0f 8e c9 39 00 00    	jle    2af7c <JS_CallInternal+0x849c>
   275b3:	48 83 ec 08          	sub    rsp,0x8
   275b7:	4c 8b 43 f0          	mov    r8,QWORD PTR [rbx-0x10]
   275bb:	4c 8b 4b f8          	mov    r9,QWORD PTR [rbx-0x8]
   275bf:	44 89 e9             	mov    ecx,r13d
   275c2:	49 8b 36             	mov    rsi,QWORD PTR [r14]
   275c5:	49 8b 56 08          	mov    rdx,QWORD PTR [r14+0x8]
   275c9:	68 00 80 00 00       	push   0x8000
   275ce:	41 ff 76 08          	push   QWORD PTR [r14+0x8]
   275d2:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   275d9:	41 ff 36             	push   QWORD PTR [r14]
   275dc:	e8 ff 64 00 00       	call   2dae0 <JS_SetPropertyInternal>
   275e1:	48 83 c4 20          	add    rsp,0x20
   275e5:	89 c3                	mov    ebx,eax
   275e7:	41 81 fd f2 00 00 00 	cmp    r13d,0xf2
   275ee:	0f 8f 89 2a 00 00    	jg     2a07d <JS_CallInternal+0x759d>
   275f4:	48 8b 85 50 fe ff ff 	mov    rax,QWORD PTR [rbp-0x1b0]
   275fb:	48 8b 50 08          	mov    rdx,QWORD PTR [rax+0x8]
   275ff:	48 8b 30             	mov    rsi,QWORD PTR [rax]
   27602:	83 fa f6             	cmp    edx,0xfffffff6
   27605:	76 11                	jbe    27618 <JS_CallInternal+0x4b38>
   27607:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   2760a:	83 e8 01             	sub    eax,0x1
   2760d:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   27610:	85 c0                	test   eax,eax
   27612:	0f 8e 74 3f 00 00    	jle    2b58c <JS_CallInternal+0x8aac>
   27618:	49 8b 56 08          	mov    rdx,QWORD PTR [r14+0x8]
   2761c:	49 8b 36             	mov    rsi,QWORD PTR [r14]
   2761f:	83 fa f6             	cmp    edx,0xfffffff6
   27622:	76 11                	jbe    27635 <JS_CallInternal+0x4b55>
   27624:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   27627:	83 e8 01             	sub    eax,0x1
   2762a:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   2762d:	85 c0                	test   eax,eax
   2762f:	0f 8e 26 3a 00 00    	jle    2b05b <JS_CallInternal+0x857b>
   27635:	85 db                	test   ebx,ebx
   27637:	0f 88 6d 44 00 00    	js     2baaa <JS_CallInternal+0x8fca>
   2763d:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   27642:	4c 89 f3             	mov    rbx,r14
   27645:	49 83 c4 01          	add    r12,0x1
   27649:	49 89 c5             	mov    r13,rax
   2764c:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   27650:	ff e0                	jmp    rax
   27652:	f3 0f 1e fa          	endbr64
   27656:	48 8b 53 f8          	mov    rdx,QWORD PTR [rbx-0x8]
   2765a:	0b 53 e8             	or     edx,DWORD PTR [rbx-0x18]
   2765d:	48 8b 43 e0          	mov    rax,QWORD PTR [rbx-0x20]
   27661:	48 8b 4b f0          	mov    rcx,QWORD PTR [rbx-0x10]
   27665:	0f 85 63 3c 00 00    	jne    2b2ce <JS_CallInternal+0x87ee>
   2766b:	d3 e0                	shl    eax,cl
   2766d:	48 c7 43 e8 00 00 00 	mov    QWORD PTR [rbx-0x18],0x0
   27674:	00 
   27675:	48 83 eb 10          	sub    rbx,0x10
   27679:	48 89 43 f0          	mov    QWORD PTR [rbx-0x10],rax
   2767d:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   27682:	49 83 c4 01          	add    r12,0x1
   27686:	49 89 c5             	mov    r13,rax
   27689:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   2768d:	ff e0                	jmp    rax
   2768f:	f3 0f 1e fa          	endbr64
   27693:	48 8b 4b f0          	mov    rcx,QWORD PTR [rbx-0x10]
   27697:	83 7b f8 03          	cmp    DWORD PTR [rbx-0x8],0x3
   2769b:	4d 8d 6c 24 04       	lea    r13,[r12+0x4]
   276a0:	48 8b 53 f8          	mov    rdx,QWORD PTR [rbx-0x8]
   276a4:	48 89 c8             	mov    rax,rcx
   276a7:	0f 87 d4 24 00 00    	ja     29b81 <JS_CallInternal+0x70a1>
   276ad:	48 83 eb 10          	sub    rbx,0x10
   276b1:	85 c0                	test   eax,eax
   276b3:	75 0c                	jne    276c1 <JS_CallInternal+0x4be1>
   276b5:	41 8b 04 24          	mov    eax,DWORD PTR [r12]
   276b9:	83 e8 04             	sub    eax,0x4
   276bc:	48 98                	cdqe
   276be:	49 01 c5             	add    r13,rax
   276c1:	48 8b 8d e8 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x118]
   276c8:	8b 81 a8 01 00 00    	mov    eax,DWORD PTR [rcx+0x1a8]
   276ce:	89 85 50 fe ff ff    	mov    DWORD PTR [rbp-0x1b0],eax
   276d4:	83 e8 01             	sub    eax,0x1
   276d7:	89 81 a8 01 00 00    	mov    DWORD PTR [rcx+0x1a8],eax
   276dd:	85 c0                	test   eax,eax
   276df:	0f 8e 0f 3a 00 00    	jle    2b0f4 <JS_CallInternal+0x8614>
   276e5:	41 0f b6 45 00       	movzx  eax,BYTE PTR [r13+0x0]
   276ea:	4d 8d 65 01          	lea    r12,[r13+0x1]
   276ee:	49 89 c5             	mov    r13,rax
   276f1:	41 ff 24 c7          	jmp    QWORD PTR [r15+rax*8]
   276f5:	f3 0f 1e fa          	endbr64
   276f9:	48 8b 4b f8          	mov    rcx,QWORD PTR [rbx-0x8]
   276fd:	48 8b 73 e8          	mov    rsi,QWORD PTR [rbx-0x18]
   27701:	48 8b 53 e0          	mov    rdx,QWORD PTR [rbx-0x20]
   27705:	48 8b 43 f0          	mov    rax,QWORD PTR [rbx-0x10]
   27709:	89 cf                	mov    edi,ecx
   2770b:	09 f7                	or     edi,esi
   2770d:	0f 85 21 3c 00 00    	jne    2b334 <JS_CallInternal+0x8854>
   27713:	39 c2                	cmp    edx,eax
   27715:	48 c7 43 e8 01 00 00 	mov    QWORD PTR [rbx-0x18],0x1
   2771c:	00 
   2771d:	0f 9d c0             	setge  al
   27720:	48 83 eb 10          	sub    rbx,0x10
   27724:	0f b6 c0             	movzx  eax,al
   27727:	48 89 43 f0          	mov    QWORD PTR [rbx-0x10],rax
   2772b:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   27730:	49 83 c4 01          	add    r12,0x1
   27734:	49 89 c5             	mov    r13,rax
   27737:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   2773b:	ff e0                	jmp    rax
   2773d:	f3 0f 1e fa          	endbr64
   27741:	4c 8b 73 e8          	mov    r14,QWORD PTR [rbx-0x18]
   27745:	41 8b 0c 24          	mov    ecx,DWORD PTR [r12]
   27749:	4d 8d 54 24 04       	lea    r10,[r12+0x4]
   2774e:	48 8b 43 e0          	mov    rax,QWORD PTR [rbx-0x20]
   27752:	48 8b 53 e8          	mov    rdx,QWORD PTR [rbx-0x18]
   27756:	4c 8b 6b e0          	mov    r13,QWORD PTR [rbx-0x20]
   2775a:	41 83 fe ff          	cmp    r14d,0xffffffff
   2775e:	0f 85 af 23 00 00    	jne    29b13 <JS_CallInternal+0x7033>
   27764:	4d 8b 4d 18          	mov    r9,QWORD PTR [r13+0x18]
   27768:	41 8b 79 18          	mov    edi,DWORD PTR [r9+0x18]
   2776c:	89 fe                	mov    esi,edi
   2776e:	21 ce                	and    esi,ecx
   27770:	41 8b 74 b1 38       	mov    esi,DWORD PTR [r9+rsi*4+0x38]
   27775:	48 85 f6             	test   rsi,rsi
   27778:	0f 84 95 23 00 00    	je     29b13 <JS_CallInternal+0x7033>
   2777e:	48 8d 3c bd 34 00 00 	lea    rdi,[rdi*4+0x34]
   27785:	00 
   27786:	4c 8d 04 f7          	lea    r8,[rdi+rsi*8]
   2778a:	4d 01 c8             	add    r8,r9
   2778d:	41 39 48 04          	cmp    DWORD PTR [r8+0x4],ecx
   27791:	0f 85 6d 23 00 00    	jne    29b04 <JS_CallInternal+0x7024>
   27797:	49 8b 7d 20          	mov    rdi,QWORD PTR [r13+0x20]
   2779b:	48 c1 e6 04          	shl    rsi,0x4
   2779f:	48 8d 7c 37 f0       	lea    rdi,[rdi+rsi*1-0x10]
   277a4:	41 0f b6 70 03       	movzx  esi,BYTE PTR [r8+0x3]
   277a9:	40 c0 ee 02          	shr    sil,0x2
   277ad:	83 e6 3a             	and    esi,0x3a
   277b0:	40 80 fe 02          	cmp    sil,0x2
   277b4:	0f 85 59 23 00 00    	jne    29b13 <JS_CallInternal+0x7033>
   277ba:	48 8b 57 08          	mov    rdx,QWORD PTR [rdi+0x8]
   277be:	f3 0f 6f 73 f0       	movdqu xmm6,XMMWORD PTR [rbx-0x10]
   277c3:	48 8b 37             	mov    rsi,QWORD PTR [rdi]
   277c6:	0f 11 37             	movups XMMWORD PTR [rdi],xmm6
   277c9:	83 fa f6             	cmp    edx,0xfffffff6
   277cc:	76 11                	jbe    277df <JS_CallInternal+0x4cff>
   277ce:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   277d1:	83 e8 01             	sub    eax,0x1
   277d4:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   277d7:	85 c0                	test   eax,eax
   277d9:	0f 8e d7 43 00 00    	jle    2bbb6 <JS_CallInternal+0x90d6>
   277df:	41 83 fe f6          	cmp    r14d,0xfffffff6
   277e3:	76 13                	jbe    277f8 <JS_CallInternal+0x4d18>
   277e5:	41 8b 45 fc          	mov    eax,DWORD PTR [r13-0x4]
   277e9:	83 e8 01             	sub    eax,0x1
   277ec:	41 89 45 fc          	mov    DWORD PTR [r13-0x4],eax
   277f0:	85 c0                	test   eax,eax
   277f2:	0f 8e d3 43 00 00    	jle    2bbcb <JS_CallInternal+0x90eb>
   277f8:	48 83 eb 20          	sub    rbx,0x20
   277fc:	41 0f b6 44 24 04    	movzx  eax,BYTE PTR [r12+0x4]
   27802:	49 83 c4 05          	add    r12,0x5
   27806:	49 89 c5             	mov    r13,rax
   27809:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   2780d:	ff e0                	jmp    rax
   2780f:	f3 0f 1e fa          	endbr64
   27813:	45 0f b6 2c 24       	movzx  r13d,BYTE PTR [r12]
   27818:	48 8b 85 b0 fe ff ff 	mov    rax,QWORD PTR [rbp-0x150]
   2781f:	4d 8d 74 24 01       	lea    r14,[r12+0x1]
   27824:	49 c1 e5 04          	shl    r13,0x4
   27828:	49 01 c5             	add    r13,rax
   2782b:	f3 41 0f 6f 55 00    	movdqu xmm2,XMMWORD PTR [r13+0x0]
   27831:	0f 29 95 f0 fe ff ff 	movaps XMMWORD PTR [rbp-0x110],xmm2
   27838:	48 8b 95 f8 fe ff ff 	mov    rdx,QWORD PTR [rbp-0x108]
   2783f:	48 8b 85 f0 fe ff ff 	mov    rax,QWORD PTR [rbp-0x110]
   27846:	85 d2                	test   edx,edx
   27848:	0f 85 50 1c 00 00    	jne    2949e <JS_CallInternal+0x69be>
   2784e:	3d ff ff ff 7f       	cmp    eax,0x7fffffff
   27853:	0f 84 45 1c 00 00    	je     2949e <JS_CallInternal+0x69be>
   27859:	83 c0 01             	add    eax,0x1
   2785c:	49 c7 45 08 00 00 00 	mov    QWORD PTR [r13+0x8],0x0
   27863:	00 
   27864:	49 89 45 00          	mov    QWORD PTR [r13+0x0],rax
   27868:	41 0f b6 44 24 01    	movzx  eax,BYTE PTR [r12+0x1]
   2786e:	49 83 c4 02          	add    r12,0x2
   27872:	49 89 c5             	mov    r13,rax
   27875:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   27879:	ff e0                	jmp    rax
   2787b:	f3 0f 1e fa          	endbr64
   2787f:	44 8b 43 f8          	mov    r8d,DWORD PTR [rbx-0x8]
   27883:	48 8b 43 f0          	mov    rax,QWORD PTR [rbx-0x10]
   27887:	45 85 c0             	test   r8d,r8d
   2788a:	0f 85 b0 1e 00 00    	jne    29740 <JS_CallInternal+0x6c60>
   27890:	3d 00 00 00 80       	cmp    eax,0x80000000
   27895:	0f 84 a5 1e 00 00    	je     29740 <JS_CallInternal+0x6c60>
   2789b:	83 e8 01             	sub    eax,0x1
   2789e:	48 c7 43 08 00 00 00 	mov    QWORD PTR [rbx+0x8],0x0
   278a5:	00 
   278a6:	48 89 03             	mov    QWORD PTR [rbx],rax
   278a9:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   278ae:	48 83 c3 10          	add    rbx,0x10
   278b2:	49 83 c4 01          	add    r12,0x1
   278b6:	49 89 c5             	mov    r13,rax
   278b9:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   278bd:	ff e0                	jmp    rax
   278bf:	f3 0f 1e fa          	endbr64
   278c3:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   278ca:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   278d1:	31 d2                	xor    edx,edx
   278d3:	48 89 de             	mov    rsi,rbx
   278d6:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   278da:	e8 a1 e1 06 00       	call   95a80 <js_for_of_start>
   278df:	85 c0                	test   eax,eax
   278e1:	0f 85 99 b9 ff ff    	jne    23280 <JS_CallInternal+0x7a0>
   278e7:	48 c7 43 10 00 00 00 	mov    QWORD PTR [rbx+0x10],0x0
   278ee:	00 
   278ef:	49 83 c4 01          	add    r12,0x1
   278f3:	48 83 c3 20          	add    rbx,0x20
   278f7:	48 c7 43 f8 05 00 00 	mov    QWORD PTR [rbx-0x8],0x5
   278fe:	00 
   278ff:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   27905:	49 89 c5             	mov    r13,rax
   27908:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   2790c:	ff e0                	jmp    rax
   2790e:	f3 0f 1e fa          	endbr64
   27912:	48 8b 53 e0          	mov    rdx,QWORD PTR [rbx-0x20]
   27916:	4c 8b 4b e8          	mov    r9,QWORD PTR [rbx-0x18]
   2791a:	4c 8b 6b f0          	mov    r13,QWORD PTR [rbx-0x10]
   2791e:	4c 8b 73 f8          	mov    r14,QWORD PTR [rbx-0x8]
   27922:	48 89 d7             	mov    rdi,rdx
   27925:	45 85 c9             	test   r9d,r9d
   27928:	0f 85 b3 33 00 00    	jne    2ace1 <JS_CallInternal+0x8201>
   2792e:	45 85 f6             	test   r14d,r14d
   27931:	0f 85 67 1d 00 00    	jne    2969e <JS_CallInternal+0x6bbe>
   27937:	31 c0                	xor    eax,eax
   27939:	44 39 ea             	cmp    edx,r13d
   2793c:	0f 95 c0             	setne  al
   2793f:	48 89 43 e0          	mov    QWORD PTR [rbx-0x20],rax
   27943:	49 83 c4 01          	add    r12,0x1
   27947:	48 83 eb 10          	sub    rbx,0x10
   2794b:	48 c7 43 f8 01 00 00 	mov    QWORD PTR [rbx-0x8],0x1
   27952:	00 
   27953:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   27959:	49 89 c5             	mov    r13,rax
   2795c:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   27960:	ff e0                	jmp    rax
   27962:	f3 0f 1e fa          	endbr64
   27966:	48 8b 53 e0          	mov    rdx,QWORD PTR [rbx-0x20]
   2796a:	4c 8b 43 e8          	mov    r8,QWORD PTR [rbx-0x18]
   2796e:	4c 8b 6b f0          	mov    r13,QWORD PTR [rbx-0x10]
   27972:	4c 8b 73 f8          	mov    r14,QWORD PTR [rbx-0x8]
   27976:	48 89 d7             	mov    rdi,rdx
   27979:	45 85 c0             	test   r8d,r8d
   2797c:	0f 85 12 3d 00 00    	jne    2b694 <JS_CallInternal+0x8bb4>
   27982:	45 85 f6             	test   r14d,r14d
   27985:	0f 85 41 1d 00 00    	jne    296cc <JS_CallInternal+0x6bec>
   2798b:	31 c0                	xor    eax,eax
   2798d:	44 39 ea             	cmp    edx,r13d
   27990:	0f 94 c0             	sete   al
   27993:	48 89 43 e0          	mov    QWORD PTR [rbx-0x20],rax
   27997:	49 83 c4 01          	add    r12,0x1
   2799b:	48 83 eb 10          	sub    rbx,0x10
   2799f:	48 c7 43 f8 01 00 00 	mov    QWORD PTR [rbx-0x8],0x1
   279a6:	00 
   279a7:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   279ad:	49 89 c5             	mov    r13,rax
   279b0:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   279b4:	ff e0                	jmp    rax
   279b6:	f3 0f 1e fa          	endbr64
   279ba:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   279c1:	4c 8b 73 f0          	mov    r14,QWORD PTR [rbx-0x10]
   279c5:	4c 8b 6b f8          	mov    r13,QWORD PTR [rbx-0x8]
   279c9:	48 8b 73 e0          	mov    rsi,QWORD PTR [rbx-0x20]
   279cd:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   279d1:	48 8b 53 e8          	mov    rdx,QWORD PTR [rbx-0x18]
   279d5:	4c 89 f1             	mov    rcx,r14
   279d8:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   279df:	4d 89 e8             	mov    r8,r13
   279e2:	48 89 b5 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],rsi
   279e9:	48 89 95 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],rdx
   279f0:	e8 1b ba 00 00       	call   33410 <JS_IsInstanceOf>
   279f5:	89 c1                	mov    ecx,eax
   279f7:	85 c0                	test   eax,eax
   279f9:	0f 88 81 b8 ff ff    	js     23280 <JS_CallInternal+0x7a0>
   279ff:	48 8b 95 50 fe ff ff 	mov    rdx,QWORD PTR [rbp-0x1b0]
   27a06:	83 fa f6             	cmp    edx,0xfffffff6
   27a09:	76 18                	jbe    27a23 <JS_CallInternal+0x4f43>
   27a0b:	48 8b b5 40 fe ff ff 	mov    rsi,QWORD PTR [rbp-0x1c0]
   27a12:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   27a15:	83 e8 01             	sub    eax,0x1
   27a18:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   27a1b:	85 c0                	test   eax,eax
   27a1d:	0f 8e 72 41 00 00    	jle    2bb95 <JS_CallInternal+0x90b5>
   27a23:	41 83 fd f6          	cmp    r13d,0xfffffff6
   27a27:	76 13                	jbe    27a3c <JS_CallInternal+0x4f5c>
   27a29:	41 8b 46 fc          	mov    eax,DWORD PTR [r14-0x4]
   27a2d:	83 e8 01             	sub    eax,0x1
   27a30:	41 89 46 fc          	mov    DWORD PTR [r14-0x4],eax
   27a34:	85 c0                	test   eax,eax
   27a36:	0f 8e f8 41 00 00    	jle    2bc34 <JS_CallInternal+0x9154>
   27a3c:	31 c0                	xor    eax,eax
   27a3e:	85 c9                	test   ecx,ecx
   27a40:	48 c7 43 e8 01 00 00 	mov    QWORD PTR [rbx-0x18],0x1
   27a47:	00 
   27a48:	0f 95 c0             	setne  al
   27a4b:	48 83 eb 10          	sub    rbx,0x10
   27a4f:	49 83 c4 01          	add    r12,0x1
   27a53:	48 89 43 f0          	mov    QWORD PTR [rbx-0x10],rax
   27a57:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   27a5d:	49 89 c5             	mov    r13,rax
   27a60:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   27a64:	ff e0                	jmp    rax
   27a66:	f3 0f 1e fa          	endbr64
   27a6a:	48 8b 53 f8          	mov    rdx,QWORD PTR [rbx-0x8]
   27a6e:	0b 53 e8             	or     edx,DWORD PTR [rbx-0x18]
   27a71:	48 8b 43 e0          	mov    rax,QWORD PTR [rbx-0x20]
   27a75:	48 8b 4b f0          	mov    rcx,QWORD PTR [rbx-0x10]
   27a79:	0f 85 cc 36 00 00    	jne    2b14b <JS_CallInternal+0x866b>
   27a7f:	31 c8                	xor    eax,ecx
   27a81:	48 c7 43 e8 00 00 00 	mov    QWORD PTR [rbx-0x18],0x0
   27a88:	00 
   27a89:	48 83 eb 10          	sub    rbx,0x10
   27a8d:	48 89 43 f0          	mov    QWORD PTR [rbx-0x10],rax
   27a91:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   27a96:	49 83 c4 01          	add    r12,0x1
   27a9a:	49 89 c5             	mov    r13,rax
   27a9d:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   27aa1:	ff e0                	jmp    rax
   27aa3:	f3 0f 1e fa          	endbr64
   27aa7:	48 8b 53 f8          	mov    rdx,QWORD PTR [rbx-0x8]
   27aab:	0b 53 e8             	or     edx,DWORD PTR [rbx-0x18]
   27aae:	48 8b 43 e0          	mov    rax,QWORD PTR [rbx-0x20]
   27ab2:	48 8b 4b f0          	mov    rcx,QWORD PTR [rbx-0x10]
   27ab6:	0f 85 2f 3d 00 00    	jne    2b7eb <JS_CallInternal+0x8d0b>
   27abc:	09 c8                	or     eax,ecx
   27abe:	48 c7 43 e8 00 00 00 	mov    QWORD PTR [rbx-0x18],0x0
   27ac5:	00 
   27ac6:	48 83 eb 10          	sub    rbx,0x10
   27aca:	48 89 43 f0          	mov    QWORD PTR [rbx-0x10],rax
   27ace:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   27ad3:	49 83 c4 01          	add    r12,0x1
   27ad7:	49 89 c5             	mov    r13,rax
   27ada:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   27ade:	ff e0                	jmp    rax
   27ae0:	f3 0f 1e fa          	endbr64
   27ae4:	41 0f b6 3c 24       	movzx  edi,BYTE PTR [r12]
   27ae9:	48 8b 8d c8 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x138]
   27af0:	4d 8d 6c 24 01       	lea    r13,[r12+0x1]
   27af5:	45 31 c9             	xor    r9d,r9d
   27af8:	89 fa                	mov    edx,edi
   27afa:	89 f8                	mov    eax,edi
   27afc:	4c 89 69 30          	mov    QWORD PTR [rcx+0x30],r13
   27b00:	c1 fa 02             	sar    edx,0x2
   27b03:	83 e0 03             	and    eax,0x3
   27b06:	83 e2 07             	and    edx,0x7
   27b09:	f7 d0                	not    eax
   27b0b:	f7 d2                	not    edx
   27b0d:	48 98                	cdqe
   27b0f:	48 63 d2             	movsxd rdx,edx
   27b12:	48 c1 e0 04          	shl    rax,0x4
   27b16:	48 c1 e2 04          	shl    rdx,0x4
   27b1a:	48 01 d8             	add    rax,rbx
   27b1d:	48 01 da             	add    rdx,rbx
   27b20:	48 8b 30             	mov    rsi,QWORD PTR [rax]
   27b23:	48 8b 0a             	mov    rcx,QWORD PTR [rdx]
   27b26:	4c 8b 42 08          	mov    r8,QWORD PTR [rdx+0x8]
   27b2a:	48 8b 50 08          	mov    rdx,QWORD PTR [rax+0x8]
   27b2e:	89 f8                	mov    eax,edi
   27b30:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   27b37:	c1 f8 05             	sar    eax,0x5
   27b3a:	f7 d0                	not    eax
   27b3c:	48 98                	cdqe
   27b3e:	48 c1 e0 04          	shl    rax,0x4
   27b42:	ff 74 03 08          	push   QWORD PTR [rbx+rax*1+0x8]
   27b46:	ff 34 03             	push   QWORD PTR [rbx+rax*1]
   27b49:	e8 c2 39 06 00       	call   8b510 <JS_CopyDataProperties>
   27b4e:	41 5e                	pop    r14
   27b50:	5a                   	pop    rdx
   27b51:	85 c0                	test   eax,eax
   27b53:	0f 85 57 49 00 00    	jne    2c4b0 <JS_CallInternal+0x99d0>
   27b59:	41 0f b6 44 24 01    	movzx  eax,BYTE PTR [r12+0x1]
   27b5f:	49 83 c4 02          	add    r12,0x2
   27b63:	49 89 c5             	mov    r13,rax
   27b66:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   27b6a:	ff e0                	jmp    rax
   27b6c:	f3 0f 1e fa          	endbr64
   27b70:	48 8b 4b f8          	mov    rcx,QWORD PTR [rbx-0x8]
   27b74:	48 8b 73 e8          	mov    rsi,QWORD PTR [rbx-0x18]
   27b78:	48 8b 53 e0          	mov    rdx,QWORD PTR [rbx-0x20]
   27b7c:	48 8b 43 f0          	mov    rax,QWORD PTR [rbx-0x10]
   27b80:	89 cf                	mov    edi,ecx
   27b82:	09 f7                	or     edi,esi
   27b84:	0f 85 8e 36 00 00    	jne    2b218 <JS_CallInternal+0x8738>
   27b8a:	39 c2                	cmp    edx,eax
   27b8c:	48 c7 43 e8 01 00 00 	mov    QWORD PTR [rbx-0x18],0x1
   27b93:	00 
   27b94:	0f 9f c0             	setg   al
   27b97:	48 83 eb 10          	sub    rbx,0x10
   27b9b:	0f b6 c0             	movzx  eax,al
   27b9e:	48 89 43 f0          	mov    QWORD PTR [rbx-0x10],rax
   27ba2:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   27ba7:	49 83 c4 01          	add    r12,0x1
   27bab:	49 89 c5             	mov    r13,rax
   27bae:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   27bb2:	ff e0                	jmp    rax
   27bb4:	f3 0f 1e fa          	endbr64
   27bb8:	48 8b 8d d8 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x128]
   27bbf:	41 0f b7 04 24       	movzx  eax,WORD PTR [r12]
   27bc4:	0f b7 51 38          	movzx  edx,WORD PTR [rcx+0x38]
   27bc8:	4c 8b 51 28          	mov    r10,QWORD PTR [rcx+0x28]
   27bcc:	01 d0                	add    eax,edx
   27bce:	48 98                	cdqe
   27bd0:	48 8d 04 40          	lea    rax,[rax+rax*2]
   27bd4:	49 8d 04 82          	lea    rax,[r10+rax*4]
   27bd8:	44 0f b7 68 0a       	movzx  r13d,WORD PTR [rax+0xa]
   27bdd:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   27be4:	48 8b 48 28          	mov    rcx,QWORD PTR [rax+0x28]
   27be8:	49 c1 e5 03          	shl    r13,0x3
   27bec:	4c 01 e9             	add    rcx,r13
   27bef:	4c 8b 31             	mov    r14,QWORD PTR [rcx]
   27bf2:	4d 85 f6             	test   r14,r14
   27bf5:	74 50                	je     27c47 <JS_CallInternal+0x5167>
   27bf7:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   27bfe:	48 8b 7f 10          	mov    rdi,QWORD PTR [rdi+0x10]
   27c02:	f6 40 3c 04          	test   BYTE PTR [rax+0x3c],0x4
   27c06:	0f 85 b5 27 00 00    	jne    2a3c1 <JS_CallInternal+0x78e1>
   27c0c:	49 8b 56 18          	mov    rdx,QWORD PTR [r14+0x18]
   27c10:	48 8b 02             	mov    rax,QWORD PTR [rdx]
   27c13:	48 8b 52 08          	mov    rdx,QWORD PTR [rdx+0x8]
   27c17:	83 fa f6             	cmp    edx,0xfffffff6
   27c1a:	76 04                	jbe    27c20 <JS_CallInternal+0x5140>
   27c1c:	83 40 fc 01          	add    DWORD PTR [rax-0x4],0x1
   27c20:	49 8d 7e 20          	lea    rdi,[r14+0x20]
   27c24:	66 48 0f 6e e0       	movq   xmm4,rax
   27c29:	49 89 56 28          	mov    QWORD PTR [r14+0x28],rdx
   27c2d:	66 48 0f 6e c7       	movq   xmm0,rdi
   27c32:	41 c6 46 10 01       	mov    BYTE PTR [r14+0x10],0x1
   27c37:	66 0f 6c c4          	punpcklqdq xmm0,xmm4
   27c3b:	41 0f 11 46 18       	movups XMMWORD PTR [r14+0x18],xmm0
   27c40:	48 c7 01 00 00 00 00 	mov    QWORD PTR [rcx],0x0
   27c47:	41 0f b6 44 24 02    	movzx  eax,BYTE PTR [r12+0x2]
   27c4d:	49 83 c4 03          	add    r12,0x3
   27c51:	49 89 c5             	mov    r13,rax
   27c54:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   27c58:	ff e0                	jmp    rax
   27c5a:	f3 0f 1e fa          	endbr64
   27c5e:	48 8b 4b f8          	mov    rcx,QWORD PTR [rbx-0x8]
   27c62:	48 8b 73 e8          	mov    rsi,QWORD PTR [rbx-0x18]
   27c66:	48 8b 43 e0          	mov    rax,QWORD PTR [rbx-0x20]
   27c6a:	48 8b 53 f0          	mov    rdx,QWORD PTR [rbx-0x10]
   27c6e:	89 cf                	mov    edi,ecx
   27c70:	09 f7                	or     edi,esi
   27c72:	0f 85 22 3c 00 00    	jne    2b89a <JS_CallInternal+0x8dba>
   27c78:	39 d0                	cmp    eax,edx
   27c7a:	48 c7 43 e8 01 00 00 	mov    QWORD PTR [rbx-0x18],0x1
   27c81:	00 
   27c82:	0f 9c c0             	setl   al
   27c85:	48 83 eb 10          	sub    rbx,0x10
   27c89:	0f b6 c0             	movzx  eax,al
   27c8c:	48 89 43 f0          	mov    QWORD PTR [rbx-0x10],rax
   27c90:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   27c95:	49 83 c4 01          	add    r12,0x1
   27c99:	49 89 c5             	mov    r13,rax
   27c9c:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   27ca0:	ff e0                	jmp    rax
   27ca2:	f3 0f 1e fa          	endbr64
   27ca6:	83 7b f8 03          	cmp    DWORD PTR [rbx-0x8],0x3
   27caa:	48 8b 53 f0          	mov    rdx,QWORD PTR [rbx-0x10]
   27cae:	48 8b 43 f8          	mov    rax,QWORD PTR [rbx-0x8]
   27cb2:	0f 87 11 20 00 00    	ja     29cc9 <JS_CallInternal+0x71e9>
   27cb8:	31 c0                	xor    eax,eax
   27cba:	85 d2                	test   edx,edx
   27cbc:	0f 95 c0             	setne  al
   27cbf:	85 c0                	test   eax,eax
   27cc1:	48 c7 43 f8 01 00 00 	mov    QWORD PTR [rbx-0x8],0x1
   27cc8:	00 
   27cc9:	0f 94 c0             	sete   al
   27ccc:	49 83 c4 01          	add    r12,0x1
   27cd0:	0f b6 c0             	movzx  eax,al
   27cd3:	48 89 43 f0          	mov    QWORD PTR [rbx-0x10],rax
   27cd7:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   27cdd:	49 89 c5             	mov    r13,rax
   27ce0:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   27ce4:	ff e0                	jmp    rax
   27ce6:	f3 0f 1e fa          	endbr64
   27cea:	45 0f b6 34 24       	movzx  r14d,BYTE PTR [r12]
   27cef:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   27cf6:	4d 8d 6c 24 01       	lea    r13,[r12+0x1]
   27cfb:	4c 8b 43 c0          	mov    r8,QWORD PTR [rbx-0x40]
   27cff:	4c 8b 4b c8          	mov    r9,QWORD PTR [rbx-0x38]
   27d03:	4c 89 68 30          	mov    QWORD PTR [rax+0x30],r13
   27d07:	44 89 f0             	mov    eax,r14d
   27d0a:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   27d11:	83 e0 01             	and    eax,0x1
   27d14:	4c 89 c6             	mov    rsi,r8
   27d17:	4c 89 ca             	mov    rdx,r9
   27d1a:	3c 01                	cmp    al,0x1
   27d1c:	19 c9                	sbb    ecx,ecx
   27d1e:	48 83 ec 08          	sub    rsp,0x8
   27d22:	6a 00                	push   0x0
   27d24:	83 e1 ef             	and    ecx,0xffffffef
   27d27:	83 c1 17             	add    ecx,0x17
   27d2a:	e8 81 50 00 00       	call   2cdb0 <JS_GetPropertyInternal>
   27d2f:	59                   	pop    rcx
   27d30:	5e                   	pop    rsi
   27d31:	83 fa 06             	cmp    edx,0x6
   27d34:	0f 84 f7 26 00 00    	je     2a431 <JS_CallInternal+0x7951>
   27d3a:	8d 72 fe             	lea    esi,[rdx-0x2]
   27d3d:	b9 01 00 00 00       	mov    ecx,0x1
   27d42:	83 fe 01             	cmp    esi,0x1
   27d45:	0f 87 55 1a 00 00    	ja     297a0 <JS_CallInternal+0x6cc0>
   27d4b:	48 89 0b             	mov    QWORD PTR [rbx],rcx
   27d4e:	49 83 c4 02          	add    r12,0x2
   27d52:	48 83 c3 10          	add    rbx,0x10
   27d56:	48 c7 43 f8 01 00 00 	mov    QWORD PTR [rbx-0x8],0x1
   27d5d:	00 
   27d5e:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   27d64:	49 89 c5             	mov    r13,rax
   27d67:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   27d6b:	ff e0                	jmp    rax
   27d6d:	f3 0f 1e fa          	endbr64
   27d71:	4c 8b 6b f0          	mov    r13,QWORD PTR [rbx-0x10]
   27d75:	4c 8d 73 f0          	lea    r14,[rbx-0x10]
   27d79:	48 8b 5b f8          	mov    rbx,QWORD PTR [rbx-0x8]
   27d7d:	4c 39 b5 68 fe ff ff 	cmp    QWORD PTR [rbp-0x198],r14
   27d84:	0f 83 0c 12 00 00    	jae    28f96 <JS_CallInternal+0x64b6>
   27d8a:	48 89 d8             	mov    rax,rbx
   27d8d:	4c 89 a5 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],r12
   27d94:	4c 89 f3             	mov    rbx,r14
   27d97:	4c 8b a5 68 fe ff ff 	mov    r12,QWORD PTR [rbp-0x198]
   27d9e:	49 89 c6             	mov    r14,rax
   27da1:	eb 0e                	jmp    27db1 <JS_CallInternal+0x52d1>
   27da3:	0f 1f 44 00 00       	nop    DWORD PTR [rax+rax*1+0x0]
   27da8:	49 39 dc             	cmp    r12,rbx
   27dab:	0f 83 d5 11 00 00    	jae    28f86 <JS_CallInternal+0x64a6>
   27db1:	83 7b f8 05          	cmp    DWORD PTR [rbx-0x8],0x5
   27db5:	0f 84 cb 11 00 00    	je     28f86 <JS_CallInternal+0x64a6>
   27dbb:	48 8b 4b f8          	mov    rcx,QWORD PTR [rbx-0x8]
   27dbf:	48 83 eb 10          	sub    rbx,0x10
   27dc3:	48 8b 33             	mov    rsi,QWORD PTR [rbx]
   27dc6:	83 f9 f6             	cmp    ecx,0xfffffff6
   27dc9:	76 dd                	jbe    27da8 <JS_CallInternal+0x52c8>
   27dcb:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   27dce:	8d 50 ff             	lea    edx,[rax-0x1]
   27dd1:	89 56 fc             	mov    DWORD PTR [rsi-0x4],edx
   27dd4:	85 d2                	test   edx,edx
   27dd6:	7f d0                	jg     27da8 <JS_CallInternal+0x52c8>
   27dd8:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   27ddf:	48 89 ca             	mov    rdx,rcx
   27de2:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   27de6:	e8 b5 4a ff ff       	call   1c8a0 <__JS_FreeValueRT>
   27deb:	eb bb                	jmp    27da8 <JS_CallInternal+0x52c8>
   27ded:	f3 0f 1e fa          	endbr64
   27df1:	48 8b 43 e8          	mov    rax,QWORD PTR [rbx-0x18]
   27df5:	4c 8b 6b f8          	mov    r13,QWORD PTR [rbx-0x8]
   27df9:	83 f8 ff             	cmp    eax,0xffffffff
   27dfc:	0f 85 d6 1f 00 00    	jne    29dd8 <JS_CallInternal+0x72f8>
   27e02:	45 85 ed             	test   r13d,r13d
   27e05:	0f 85 45 36 00 00    	jne    2b450 <JS_CallInternal+0x8970>
   27e0b:	48 8b 53 e0          	mov    rdx,QWORD PTR [rbx-0x20]
   27e0f:	48 8b 43 f0          	mov    rax,QWORD PTR [rbx-0x10]
   27e13:	66 83 7a 12 02       	cmp    WORD PTR [rdx+0x12],0x2
   27e18:	0f 85 2f 20 00 00    	jne    29e4d <JS_CallInternal+0x736d>
   27e1e:	3b 42 38             	cmp    eax,DWORD PTR [rdx+0x38]
   27e21:	0f 83 26 20 00 00    	jae    29e4d <JS_CallInternal+0x736d>
   27e27:	89 c0                	mov    eax,eax
   27e29:	48 c1 e0 04          	shl    rax,0x4
   27e2d:	48 03 42 30          	add    rax,QWORD PTR [rdx+0x30]
   27e31:	48 8b 08             	mov    rcx,QWORD PTR [rax]
   27e34:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
   27e38:	83 f8 f6             	cmp    eax,0xfffffff6
   27e3b:	76 04                	jbe    27e41 <JS_CallInternal+0x5361>
   27e3d:	83 41 fc 01          	add    DWORD PTR [rcx-0x4],0x1
   27e41:	48 89 0b             	mov    QWORD PTR [rbx],rcx
   27e44:	49 83 c4 01          	add    r12,0x1
   27e48:	48 83 c3 10          	add    rbx,0x10
   27e4c:	48 89 43 f8          	mov    QWORD PTR [rbx-0x8],rax
   27e50:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   27e56:	49 89 c5             	mov    r13,rax
   27e59:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   27e5d:	ff e0                	jmp    rax
   27e5f:	f3 0f 1e fa          	endbr64
   27e63:	83 7b e8 ff          	cmp    DWORD PTR [rbx-0x18],0xffffffff
   27e67:	48 8b 73 e0          	mov    rsi,QWORD PTR [rbx-0x20]
   27e6b:	48 8b 4b e8          	mov    rcx,QWORD PTR [rbx-0x18]
   27e6f:	4c 8b 43 f0          	mov    r8,QWORD PTR [rbx-0x10]
   27e73:	48 8b 7b f8          	mov    rdi,QWORD PTR [rbx-0x8]
   27e77:	0f 85 e3 1b 00 00    	jne    29a60 <JS_CallInternal+0x6f80>
   27e7d:	85 ff                	test   edi,edi
   27e7f:	0f 85 db 1b 00 00    	jne    29a60 <JS_CallInternal+0x6f80>
   27e85:	66 83 7e 12 02       	cmp    WORD PTR [rsi+0x12],0x2
   27e8a:	0f 85 d0 1b 00 00    	jne    29a60 <JS_CallInternal+0x6f80>
   27e90:	44 3b 46 38          	cmp    r8d,DWORD PTR [rsi+0x38]
   27e94:	0f 83 c6 1b 00 00    	jae    29a60 <JS_CallInternal+0x6f80>
   27e9a:	44 89 c0             	mov    eax,r8d
   27e9d:	48 c1 e0 04          	shl    rax,0x4
   27ea1:	48 03 46 30          	add    rax,QWORD PTR [rsi+0x30]
   27ea5:	48 8b 10             	mov    rdx,QWORD PTR [rax]
   27ea8:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
   27eac:	83 f8 f6             	cmp    eax,0xfffffff6
   27eaf:	76 04                	jbe    27eb5 <JS_CallInternal+0x53d5>
   27eb1:	83 42 fc 01          	add    DWORD PTR [rdx-0x4],0x1
   27eb5:	48 89 53 f0          	mov    QWORD PTR [rbx-0x10],rdx
   27eb9:	49 83 c4 01          	add    r12,0x1
   27ebd:	48 89 43 f8          	mov    QWORD PTR [rbx-0x8],rax
   27ec1:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   27ec7:	49 89 c5             	mov    r13,rax
   27eca:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   27ece:	ff e0                	jmp    rax
   27ed0:	f3 0f 1e fa          	endbr64
   27ed4:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   27edb:	48 8b 73 f0          	mov    rsi,QWORD PTR [rbx-0x10]
   27edf:	4c 8d 73 f0          	lea    r14,[rbx-0x10]
   27ee3:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   27eea:	49 8b 56 08          	mov    rdx,QWORD PTR [r14+0x8]
   27eee:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   27ef2:	e8 e9 b5 01 00       	call   434e0 <JS_ValueToAtom>
   27ef7:	41 89 c5             	mov    r13d,eax
   27efa:	45 85 ed             	test   r13d,r13d
   27efd:	0f 84 7d b3 ff ff    	je     23280 <JS_CallInternal+0x7a0>
   27f03:	48 83 ec 08          	sub    rsp,0x8
   27f07:	4c 8d 53 e0          	lea    r10,[rbx-0x20]
   27f0b:	48 8d 43 d0          	lea    rax,[rbx-0x30]
   27f0f:	4c 8b 43 d0          	mov    r8,QWORD PTR [rbx-0x30]
   27f13:	4c 89 95 38 fe ff ff 	mov    QWORD PTR [rbp-0x1c8],r10
   27f1a:	4c 8b 4b d8          	mov    r9,QWORD PTR [rbx-0x28]
   27f1e:	44 89 e9             	mov    ecx,r13d
   27f21:	48 8b 73 e0          	mov    rsi,QWORD PTR [rbx-0x20]
   27f25:	48 89 85 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],rax
   27f2c:	48 8b 53 e8          	mov    rdx,QWORD PTR [rbx-0x18]
   27f30:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   27f37:	6a 00                	push   0x0
   27f39:	e8 72 4e 00 00       	call   2cdb0 <JS_GetPropertyInternal>
   27f3e:	41 81 fd f2 00 00 00 	cmp    r13d,0xf2
   27f45:	4c 8b 95 38 fe ff ff 	mov    r10,QWORD PTR [rbp-0x1c8]
   27f4c:	48 89 85 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],rax
   27f53:	48 89 d0             	mov    rax,rdx
   27f56:	5a                   	pop    rdx
   27f57:	59                   	pop    rcx
   27f58:	0f 8f 34 1e 00 00    	jg     29d92 <JS_CallInternal+0x72b2>
   27f5e:	83 f8 06             	cmp    eax,0x6
   27f61:	0f 84 19 b3 ff ff    	je     23280 <JS_CallInternal+0x7a0>
   27f67:	49 8b 56 08          	mov    rdx,QWORD PTR [r14+0x8]
   27f6b:	49 8b 36             	mov    rsi,QWORD PTR [r14]
   27f6e:	83 fa f6             	cmp    edx,0xfffffff6
   27f71:	76 11                	jbe    27f84 <JS_CallInternal+0x54a4>
   27f73:	8b 4e fc             	mov    ecx,DWORD PTR [rsi-0x4]
   27f76:	83 e9 01             	sub    ecx,0x1
   27f79:	89 4e fc             	mov    DWORD PTR [rsi-0x4],ecx
   27f7c:	85 c9                	test   ecx,ecx
   27f7e:	0f 8e c7 2f 00 00    	jle    2af4b <JS_CallInternal+0x846b>
   27f84:	49 8b 52 08          	mov    rdx,QWORD PTR [r10+0x8]
   27f88:	49 8b 32             	mov    rsi,QWORD PTR [r10]
   27f8b:	83 fa f6             	cmp    edx,0xfffffff6
   27f8e:	76 11                	jbe    27fa1 <JS_CallInternal+0x54c1>
   27f90:	8b 4e fc             	mov    ecx,DWORD PTR [rsi-0x4]
   27f93:	83 e9 01             	sub    ecx,0x1
   27f96:	89 4e fc             	mov    DWORD PTR [rsi-0x4],ecx
   27f99:	85 c9                	test   ecx,ecx
   27f9b:	0f 8e 48 2f 00 00    	jle    2aee9 <JS_CallInternal+0x8409>
   27fa1:	48 8b 8d 50 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x1b0]
   27fa8:	48 8b 51 08          	mov    rdx,QWORD PTR [rcx+0x8]
   27fac:	48 8b 31             	mov    rsi,QWORD PTR [rcx]
   27faf:	83 fa f6             	cmp    edx,0xfffffff6
   27fb2:	76 11                	jbe    27fc5 <JS_CallInternal+0x54e5>
   27fb4:	8b 4e fc             	mov    ecx,DWORD PTR [rsi-0x4]
   27fb7:	83 e9 01             	sub    ecx,0x1
   27fba:	89 4e fc             	mov    DWORD PTR [rsi-0x4],ecx
   27fbd:	85 c9                	test   ecx,ecx
   27fbf:	0f 8e 55 2f 00 00    	jle    2af1a <JS_CallInternal+0x843a>
   27fc5:	48 8b 8d 40 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x1c0]
   27fcc:	48 89 43 d8          	mov    QWORD PTR [rbx-0x28],rax
   27fd0:	49 83 c4 01          	add    r12,0x1
   27fd4:	48 89 4b d0          	mov    QWORD PTR [rbx-0x30],rcx
   27fd8:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   27fde:	4c 89 d3             	mov    rbx,r10
   27fe1:	49 89 c5             	mov    r13,rax
   27fe4:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   27fe8:	ff e0                	jmp    rax
   27fea:	f3 0f 1e fa          	endbr64
   27fee:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   27ff5:	48 8b 73 f0          	mov    rsi,QWORD PTR [rbx-0x10]
   27ff9:	48 8b 53 f8          	mov    rdx,QWORD PTR [rbx-0x8]
   27ffd:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   28004:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   28008:	e8 d3 b4 01 00       	call   434e0 <JS_ValueToAtom>
   2800d:	41 89 c5             	mov    r13d,eax
   28010:	45 85 ed             	test   r13d,r13d
   28013:	0f 84 67 b2 ff ff    	je     23280 <JS_CallInternal+0x7a0>
   28019:	48 8b 53 e8          	mov    rdx,QWORD PTR [rbx-0x18]
   2801d:	83 fa 03             	cmp    edx,0x3
   28020:	0f 84 a2 39 00 00    	je     2b9c8 <JS_CallInternal+0x8ee8>
   28026:	48 8b 73 e0          	mov    rsi,QWORD PTR [rbx-0x20]
   2802a:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   28031:	44 89 e9             	mov    ecx,r13d
   28034:	e8 87 61 04 00       	call   6e1c0 <JS_HasProperty>
   28039:	85 c0                	test   eax,eax
   2803b:	0f 8e 28 39 00 00    	jle    2b969 <JS_CallInternal+0x8e89>
   28041:	48 83 ec 08          	sub    rsp,0x8
   28045:	4c 8b 43 e0          	mov    r8,QWORD PTR [rbx-0x20]
   28049:	4c 8b 4b e8          	mov    r9,QWORD PTR [rbx-0x18]
   2804d:	44 89 e9             	mov    ecx,r13d
   28050:	6a 00                	push   0x0
   28052:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   28059:	4c 89 c6             	mov    rsi,r8
   2805c:	4c 89 ca             	mov    rdx,r9
   2805f:	e8 4c 4d 00 00       	call   2cdb0 <JS_GetPropertyInternal>
   28064:	5e                   	pop    rsi
   28065:	5f                   	pop    rdi
   28066:	48 89 c1             	mov    rcx,rax
   28069:	49 89 d6             	mov    r14,rdx
   2806c:	48 89 d0             	mov    rax,rdx
   2806f:	41 81 fd f2 00 00 00 	cmp    r13d,0xf2
   28076:	0f 8f 7d 1f 00 00    	jg     29ff9 <JS_CallInternal+0x7519>
   2807c:	41 83 fe 06          	cmp    r14d,0x6
   28080:	0f 84 fa b1 ff ff    	je     23280 <JS_CallInternal+0x7a0>
   28086:	48 89 0b             	mov    QWORD PTR [rbx],rcx
   28089:	49 83 c4 01          	add    r12,0x1
   2808d:	48 83 c3 10          	add    rbx,0x10
   28091:	48 89 43 f8          	mov    QWORD PTR [rbx-0x8],rax
   28095:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   2809b:	49 89 c5             	mov    r13,rax
   2809e:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   280a2:	ff e0                	jmp    rax
   280a4:	f3 0f 1e fa          	endbr64
   280a8:	83 7b d8 ff          	cmp    DWORD PTR [rbx-0x28],0xffffffff
   280ac:	0f 85 41 19 00 00    	jne    299f3 <JS_CallInternal+0x6f13>
   280b2:	44 8b 5b e8          	mov    r11d,DWORD PTR [rbx-0x18]
   280b6:	45 85 db             	test   r11d,r11d
   280b9:	0f 85 34 19 00 00    	jne    299f3 <JS_CallInternal+0x6f13>
   280bf:	48 8b 4b d0          	mov    rcx,QWORD PTR [rbx-0x30]
   280c3:	48 8b 43 e0          	mov    rax,QWORD PTR [rbx-0x20]
   280c7:	66 83 79 12 02       	cmp    WORD PTR [rcx+0x12],0x2
   280cc:	0f 85 21 19 00 00    	jne    299f3 <JS_CallInternal+0x6f13>
   280d2:	8b 51 38             	mov    edx,DWORD PTR [rcx+0x38]
   280d5:	39 d0                	cmp    eax,edx
   280d7:	0f 83 18 3a 00 00    	jae    2baf5 <JS_CallInternal+0x9015>
   280dd:	89 c0                	mov    eax,eax
   280df:	f3 0f 6f 6b f0       	movdqu xmm5,XMMWORD PTR [rbx-0x10]
   280e4:	48 c1 e0 04          	shl    rax,0x4
   280e8:	48 03 41 30          	add    rax,QWORD PTR [rcx+0x30]
   280ec:	48 8b 50 08          	mov    rdx,QWORD PTR [rax+0x8]
   280f0:	48 8b 30             	mov    rsi,QWORD PTR [rax]
   280f3:	0f 11 28             	movups XMMWORD PTR [rax],xmm5
   280f6:	83 fa f6             	cmp    edx,0xfffffff6
   280f9:	76 11                	jbe    2810c <JS_CallInternal+0x562c>
   280fb:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   280fe:	83 e8 01             	sub    eax,0x1
   28101:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   28104:	85 c0                	test   eax,eax
   28106:	0f 8e c2 3b 00 00    	jle    2bcce <JS_CallInternal+0x91ee>
   2810c:	48 8b 53 d8          	mov    rdx,QWORD PTR [rbx-0x28]
   28110:	48 83 eb 30          	sub    rbx,0x30
   28114:	48 8b 33             	mov    rsi,QWORD PTR [rbx]
   28117:	83 fa f6             	cmp    edx,0xfffffff6
   2811a:	76 11                	jbe    2812d <JS_CallInternal+0x564d>
   2811c:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   2811f:	83 e8 01             	sub    eax,0x1
   28122:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   28125:	85 c0                	test   eax,eax
   28127:	0f 8e 53 3a 00 00    	jle    2bb80 <JS_CallInternal+0x90a0>
   2812d:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   28132:	49 83 c4 01          	add    r12,0x1
   28136:	49 89 c5             	mov    r13,rax
   28139:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   2813d:	ff e0                	jmp    rax
   2813f:	f3 0f 1e fa          	endbr64
   28143:	48 8b 4b f0          	mov    rcx,QWORD PTR [rbx-0x10]
   28147:	83 7b f8 03          	cmp    DWORD PTR [rbx-0x8],0x3
   2814b:	4d 8d 6c 24 01       	lea    r13,[r12+0x1]
   28150:	48 8b 53 f8          	mov    rdx,QWORD PTR [rbx-0x8]
   28154:	48 89 c8             	mov    rax,rcx
   28157:	0f 87 dc 1a 00 00    	ja     29c39 <JS_CallInternal+0x7159>
   2815d:	48 83 eb 10          	sub    rbx,0x10
   28161:	85 c0                	test   eax,eax
   28163:	75 0d                	jne    28172 <JS_CallInternal+0x5692>
   28165:	41 0f be 04 24       	movsx  eax,BYTE PTR [r12]
   2816a:	83 e8 01             	sub    eax,0x1
   2816d:	48 98                	cdqe
   2816f:	49 01 c5             	add    r13,rax
   28172:	48 8b 8d e8 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x118]
   28179:	8b 81 a8 01 00 00    	mov    eax,DWORD PTR [rcx+0x1a8]
   2817f:	89 85 50 fe ff ff    	mov    DWORD PTR [rbp-0x1b0],eax
   28185:	83 e8 01             	sub    eax,0x1
   28188:	89 81 a8 01 00 00    	mov    DWORD PTR [rcx+0x1a8],eax
   2818e:	85 c0                	test   eax,eax
   28190:	0f 8e 07 30 00 00    	jle    2b19d <JS_CallInternal+0x86bd>
   28196:	41 0f b6 45 00       	movzx  eax,BYTE PTR [r13+0x0]
   2819b:	4d 8d 65 01          	lea    r12,[r13+0x1]
   2819f:	49 89 c5             	mov    r13,rax
   281a2:	41 ff 24 c7          	jmp    QWORD PTR [r15+rax*8]
   281a6:	f3 0f 1e fa          	endbr64
   281aa:	48 8b 4b f0          	mov    rcx,QWORD PTR [rbx-0x10]
   281ae:	83 7b f8 03          	cmp    DWORD PTR [rbx-0x8],0x3
   281b2:	4d 8d 6c 24 01       	lea    r13,[r12+0x1]
   281b7:	48 8b 53 f8          	mov    rdx,QWORD PTR [rbx-0x8]
   281bb:	48 89 c8             	mov    rax,rcx
   281be:	0f 87 61 1a 00 00    	ja     29c25 <JS_CallInternal+0x7145>
   281c4:	48 83 eb 10          	sub    rbx,0x10
   281c8:	85 c0                	test   eax,eax
   281ca:	74 0d                	je     281d9 <JS_CallInternal+0x56f9>
   281cc:	41 0f be 04 24       	movsx  eax,BYTE PTR [r12]
   281d1:	83 e8 01             	sub    eax,0x1
   281d4:	48 98                	cdqe
   281d6:	49 01 c5             	add    r13,rax
   281d9:	48 8b 8d e8 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x118]
   281e0:	8b 81 a8 01 00 00    	mov    eax,DWORD PTR [rcx+0x1a8]
   281e6:	89 85 50 fe ff ff    	mov    DWORD PTR [rbp-0x1b0],eax
   281ec:	83 e8 01             	sub    eax,0x1
   281ef:	89 81 a8 01 00 00    	mov    DWORD PTR [rcx+0x1a8],eax
   281f5:	85 c0                	test   eax,eax
   281f7:	0f 8e ff 30 00 00    	jle    2b2fc <JS_CallInternal+0x881c>
   281fd:	41 0f b6 45 00       	movzx  eax,BYTE PTR [r13+0x0]
   28202:	4d 8d 65 01          	lea    r12,[r13+0x1]
   28206:	49 89 c5             	mov    r13,rax
   28209:	41 ff 24 c7          	jmp    QWORD PTR [r15+rax*8]
   2820d:	f3 0f 1e fa          	endbr64
   28211:	48 8b 8d e8 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x118]
   28218:	4d 0f be 2c 24       	movsx  r13,BYTE PTR [r12]
   2821d:	8b 81 a8 01 00 00    	mov    eax,DWORD PTR [rcx+0x1a8]
   28223:	4d 01 e5             	add    r13,r12
   28226:	89 85 50 fe ff ff    	mov    DWORD PTR [rbp-0x1b0],eax
   2822c:	83 e8 01             	sub    eax,0x1
   2822f:	89 81 a8 01 00 00    	mov    DWORD PTR [rcx+0x1a8],eax
   28235:	85 c0                	test   eax,eax
   28237:	0f 8e e5 36 00 00    	jle    2b922 <JS_CallInternal+0x8e42>
   2823d:	41 0f b6 45 00       	movzx  eax,BYTE PTR [r13+0x0]
   28242:	4d 8d 65 01          	lea    r12,[r13+0x1]
   28246:	49 89 c5             	mov    r13,rax
   28249:	41 ff 24 c7          	jmp    QWORD PTR [r15+rax*8]
   2824d:	f3 0f 1e fa          	endbr64
   28251:	48 8d 43 e0          	lea    rax,[rbx-0x20]
   28255:	83 7b e8 ff          	cmp    DWORD PTR [rbx-0x18],0xffffffff
   28259:	4c 8d 73 f0          	lea    r14,[rbx-0x10]
   2825d:	4c 8b 43 e0          	mov    r8,QWORD PTR [rbx-0x20]
   28261:	4c 8b 6b f0          	mov    r13,QWORD PTR [rbx-0x10]
   28265:	4d 8b 4e 08          	mov    r9,QWORD PTR [r14+0x8]
   28269:	48 89 85 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],rax
   28270:	0f 85 29 2b 00 00    	jne    2ad9f <JS_CallInternal+0x82bf>
   28276:	41 83 f9 f8          	cmp    r9d,0xfffffff8
   2827a:	0f 85 a1 2e 00 00    	jne    2b121 <JS_CallInternal+0x8641>
   28280:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   28287:	4c 89 ee             	mov    rsi,r13
   2828a:	4c 89 85 38 fe ff ff 	mov    QWORD PTR [rbp-0x1c8],r8
   28291:	4c 89 8d 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],r9
   28298:	48 8b 40 10          	mov    rax,QWORD PTR [rax+0x10]
   2829c:	48 89 c7             	mov    rdi,rax
   2829f:	48 89 85 28 fe ff ff 	mov    QWORD PTR [rbp-0x1d8],rax
   282a6:	e8 a5 e8 fe ff       	call   16b50 <js_get_atom_index>
   282ab:	4c 8b 85 38 fe ff ff 	mov    r8,QWORD PTR [rbp-0x1c8]
   282b2:	89 c2                	mov    edx,eax
   282b4:	49 8b 70 18          	mov    rsi,QWORD PTR [r8+0x18]
   282b8:	8b 4e 18             	mov    ecx,DWORD PTR [rsi+0x18]
   282bb:	21 c8                	and    eax,ecx
   282bd:	8b 44 86 38          	mov    eax,DWORD PTR [rsi+rax*4+0x38]
   282c1:	48 85 c0             	test   rax,rax
   282c4:	0f 84 29 39 00 00    	je     2bbf3 <JS_CallInternal+0x9113>
   282ca:	4c 8b 8d 40 fe ff ff 	mov    r9,QWORD PTR [rbp-0x1c0]
   282d1:	48 8d 3c 8d 34 00 00 	lea    rdi,[rcx*4+0x34]
   282d8:	00 
   282d9:	48 8d 0c c7          	lea    rcx,[rdi+rax*8]
   282dd:	48 01 f1             	add    rcx,rsi
   282e0:	3b 51 04             	cmp    edx,DWORD PTR [rcx+0x4]
   282e3:	0f 85 fd 38 00 00    	jne    2bbe6 <JS_CallInternal+0x9106>
   282e9:	49 8b 50 20          	mov    rdx,QWORD PTR [r8+0x20]
   282ed:	48 c1 e0 04          	shl    rax,0x4
   282f1:	48 8d 44 02 f0       	lea    rax,[rdx+rax*1-0x10]
   282f6:	48 8b 10             	mov    rdx,QWORD PTR [rax]
   282f9:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
   282fd:	83 f8 f6             	cmp    eax,0xfffffff6
   28300:	76 04                	jbe    28306 <JS_CallInternal+0x5826>
   28302:	83 42 fc 01          	add    DWORD PTR [rdx-0x4],0x1
   28306:	48 89 d1             	mov    rcx,rdx
   28309:	41 89 c0             	mov    r8d,eax
   2830c:	41 83 f9 f6          	cmp    r9d,0xfffffff6
   28310:	76 13                	jbe    28325 <JS_CallInternal+0x5845>
   28312:	41 8b 7d fc          	mov    edi,DWORD PTR [r13-0x4]
   28316:	8d 57 ff             	lea    edx,[rdi-0x1]
   28319:	41 89 55 fc          	mov    DWORD PTR [r13-0x4],edx
   2831d:	85 d2                	test   edx,edx
   2831f:	0f 8e ae 28 00 00    	jle    2abd3 <JS_CallInternal+0x80f3>
   28325:	48 8b bd 50 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x1b0]
   2832c:	48 8b 57 08          	mov    rdx,QWORD PTR [rdi+0x8]
   28330:	48 8b 37             	mov    rsi,QWORD PTR [rdi]
   28333:	83 fa f6             	cmp    edx,0xfffffff6
   28336:	76 11                	jbe    28349 <JS_CallInternal+0x5869>
   28338:	8b 7e fc             	mov    edi,DWORD PTR [rsi-0x4]
   2833b:	83 ef 01             	sub    edi,0x1
   2833e:	89 7e fc             	mov    DWORD PTR [rsi-0x4],edi
   28341:	85 ff                	test   edi,edi
   28343:	0f 8e f1 26 00 00    	jle    2aa3a <JS_CallInternal+0x7f5a>
   28349:	48 89 4b e0          	mov    QWORD PTR [rbx-0x20],rcx
   2834d:	48 89 43 e8          	mov    QWORD PTR [rbx-0x18],rax
   28351:	4c 89 f3             	mov    rbx,r14
   28354:	41 83 f8 06          	cmp    r8d,0x6
   28358:	0f 84 22 af ff ff    	je     23280 <JS_CallInternal+0x7a0>
   2835e:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   28363:	49 83 c4 01          	add    r12,0x1
   28367:	49 89 c5             	mov    r13,rax
   2836a:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   2836e:	ff e0                	jmp    rax
   28370:	f3 0f 1e fa          	endbr64
   28374:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   2837b:	48 8b 4b d0          	mov    rcx,QWORD PTR [rbx-0x30]
   2837f:	45 31 c9             	xor    r9d,r9d
   28382:	48 c7 85 f0 fd ff ff 	mov    QWORD PTR [rbp-0x210],0x0
   28389:	00 00 00 00 
   2838d:	48 c7 85 f8 fd ff ff 	mov    QWORD PTR [rbp-0x208],0x3
   28394:	03 00 00 00 
   28398:	4c 8b 43 d8          	mov    r8,QWORD PTR [rbx-0x28]
   2839c:	48 8b 73 e0          	mov    rsi,QWORD PTR [rbx-0x20]
   283a0:	48 8b 53 e8          	mov    rdx,QWORD PTR [rbx-0x18]
   283a4:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   283a8:	48 c7 43 f0 00 00 00 	mov    QWORD PTR [rbx-0x10],0x0
   283af:	00 
   283b0:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   283b7:	48 c7 43 f8 03 00 00 	mov    QWORD PTR [rbx-0x8],0x3
   283be:	00 
   283bf:	6a 02                	push   0x2
   283c1:	6a 00                	push   0x0
   283c3:	ff b5 f8 fd ff ff    	push   QWORD PTR [rbp-0x208]
   283c9:	ff b5 f0 fd ff ff    	push   QWORD PTR [rbp-0x210]
   283cf:	e8 0c a7 ff ff       	call   22ae0 <JS_CallInternal>
   283d4:	48 83 c4 20          	add    rsp,0x20
   283d8:	83 fa 06             	cmp    edx,0x6
   283db:	0f 84 9f ae ff ff    	je     23280 <JS_CallInternal+0x7a0>
   283e1:	48 89 03             	mov    QWORD PTR [rbx],rax
   283e4:	49 83 c4 01          	add    r12,0x1
   283e8:	48 83 c3 10          	add    rbx,0x10
   283ec:	48 89 53 f8          	mov    QWORD PTR [rbx-0x8],rdx
   283f0:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   283f6:	49 89 c5             	mov    r13,rax
   283f9:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   283fd:	ff e0                	jmp    rax
   283ff:	f3 0f 1e fa          	endbr64
   28403:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   2840a:	41 0f b6 0c 24       	movzx  ecx,BYTE PTR [r12]
   2840f:	4d 8d 74 24 01       	lea    r14,[r12+0x1]
   28414:	c7 85 f0 fe ff ff 01 	mov    DWORD PTR [rbp-0x110],0x1
   2841b:	00 00 00 
   2841e:	4c 89 70 30          	mov    QWORD PTR [rax+0x30],r14
   28422:	b8 fd ff ff ff       	mov    eax,0xfffffffd
   28427:	29 c8                	sub    eax,ecx
   28429:	48 98                	cdqe
   2842b:	48 c1 e0 04          	shl    rax,0x4
   2842f:	4c 8d 2c 03          	lea    r13,[rbx+rax*1]
   28433:	49 8b 55 08          	mov    rdx,QWORD PTR [r13+0x8]
   28437:	83 fa 03             	cmp    edx,0x3
   2843a:	0f 84 d0 2c 00 00    	je     2b110 <JS_CallInternal+0x8630>
   28440:	b8 fe ff ff ff       	mov    eax,0xfffffffe
   28445:	49 8b 75 00          	mov    rsi,QWORD PTR [r13+0x0]
   28449:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   28450:	4c 8d 8d f0 fe ff ff 	lea    r9,[rbp-0x110]
   28457:	29 c8                	sub    eax,ecx
   28459:	48 98                	cdqe
   2845b:	48 c1 e0 04          	shl    rax,0x4
   2845f:	48 01 d8             	add    rax,rbx
   28462:	48 8b 08             	mov    rcx,QWORD PTR [rax]
   28465:	4c 8b 40 08          	mov    r8,QWORD PTR [rax+0x8]
   28469:	e8 02 ed 06 00       	call   97170 <JS_IteratorNext.constprop.0>
   2846e:	49 89 d1             	mov    r9,rdx
   28471:	48 89 c7             	mov    rdi,rax
   28474:	48 89 d6             	mov    rsi,rdx
   28477:	83 fa 06             	cmp    edx,0x6
   2847a:	0f 84 01 1b 00 00    	je     29f81 <JS_CallInternal+0x74a1>
   28480:	8b 8d f0 fe ff ff    	mov    ecx,DWORD PTR [rbp-0x110]
   28486:	31 d2                	xor    edx,edx
   28488:	85 c9                	test   ecx,ecx
   2848a:	0f 85 00 1b 00 00    	jne    29f90 <JS_CallInternal+0x74b0>
   28490:	48 89 3b             	mov    QWORD PTR [rbx],rdi
   28493:	49 83 c4 02          	add    r12,0x2
   28497:	48 83 c3 20          	add    rbx,0x20
   2849b:	48 89 73 e8          	mov    QWORD PTR [rbx-0x18],rsi
   2849f:	48 89 53 f0          	mov    QWORD PTR [rbx-0x10],rdx
   284a3:	48 c7 43 f8 01 00 00 	mov    QWORD PTR [rbx-0x8],0x1
   284aa:	00 
   284ab:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   284b1:	49 89 c5             	mov    r13,rax
   284b4:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   284b8:	ff e0                	jmp    rax
   284ba:	f3 0f 1e fa          	endbr64
   284be:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   284c5:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   284cc:	ba 01 00 00 00       	mov    edx,0x1
   284d1:	48 89 de             	mov    rsi,rbx
   284d4:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   284d8:	e8 a3 d5 06 00       	call   95a80 <js_for_of_start>
   284dd:	85 c0                	test   eax,eax
   284df:	0f 85 9b ad ff ff    	jne    23280 <JS_CallInternal+0x7a0>
   284e5:	48 c7 43 10 00 00 00 	mov    QWORD PTR [rbx+0x10],0x0
   284ec:	00 
   284ed:	49 83 c4 01          	add    r12,0x1
   284f1:	48 83 c3 20          	add    rbx,0x20
   284f5:	48 c7 43 f8 05 00 00 	mov    QWORD PTR [rbx-0x8],0x5
   284fc:	00 
   284fd:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   28503:	49 89 c5             	mov    r13,rax
   28506:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   2850a:	ff e0                	jmp    rax
   2850c:	f3 0f 1e fa          	endbr64
   28510:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   28517:	48 8b 73 f0          	mov    rsi,QWORD PTR [rbx-0x10]
   2851b:	48 8b 53 f8          	mov    rdx,QWORD PTR [rbx-0x8]
   2851f:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   28526:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   2852a:	e8 d1 51 04 00       	call   6d700 <build_for_in_iterator>
   2852f:	48 89 53 f8          	mov    QWORD PTR [rbx-0x8],rdx
   28533:	83 7b f8 06          	cmp    DWORD PTR [rbx-0x8],0x6
   28537:	48 89 43 f0          	mov    QWORD PTR [rbx-0x10],rax
   2853b:	0f 84 3f ad ff ff    	je     23280 <JS_CallInternal+0x7a0>
   28541:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   28546:	49 83 c4 01          	add    r12,0x1
   2854a:	49 89 c5             	mov    r13,rax
   2854d:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   28551:	ff e0                	jmp    rax
   28553:	f3 0f 1e fa          	endbr64
   28557:	44 8b 4b f8          	mov    r9d,DWORD PTR [rbx-0x8]
   2855b:	48 8b 43 f0          	mov    rax,QWORD PTR [rbx-0x10]
   2855f:	45 85 c9             	test   r9d,r9d
   28562:	0f 85 1f 1e 00 00    	jne    2a387 <JS_CallInternal+0x78a7>
   28568:	48 8b 8d d8 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x128]
   2856f:	3b 41 20             	cmp    eax,DWORD PTR [rcx+0x20]
   28572:	0f 83 0f 1e 00 00    	jae    2a387 <JS_CallInternal+0x78a7>
   28578:	48 8b 8d d8 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x128]
   2857f:	89 c0                	mov    eax,eax
   28581:	48 83 eb 10          	sub    rbx,0x10
   28585:	48 03 41 18          	add    rax,QWORD PTR [rcx+0x18]
   28589:	4c 8d 60 01          	lea    r12,[rax+0x1]
   2858d:	0f b6 00             	movzx  eax,BYTE PTR [rax]
   28590:	49 89 c5             	mov    r13,rax
   28593:	41 ff 24 c7          	jmp    QWORD PTR [r15+rax*8]
   28597:	f3 0f 1e fa          	endbr64
   2859b:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   285a2:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   285a9:	48 89 de             	mov    rsi,rbx
   285ac:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   285b0:	e8 eb 53 04 00       	call   6d9a0 <js_for_in_next>
   285b5:	85 c0                	test   eax,eax
   285b7:	0f 85 c3 ac ff ff    	jne    23280 <JS_CallInternal+0x7a0>
   285bd:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   285c2:	48 83 c3 20          	add    rbx,0x20
   285c6:	49 83 c4 01          	add    r12,0x1
   285ca:	49 89 c5             	mov    r13,rax
   285cd:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   285d1:	ff e0                	jmp    rax
   285d3:	f3 0f 1e fa          	endbr64
   285d7:	e9 18 aa ff ff       	jmp    22ff4 <JS_CallInternal+0x514>
   285dc:	f3 0f 1e fa          	endbr64
   285e0:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   285e7:	4d 8d 6c 24 04       	lea    r13,[r12+0x4]
   285ec:	41 8b 34 24          	mov    esi,DWORD PTR [r12]
   285f0:	48 89 da             	mov    rdx,rbx
   285f3:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   285fa:	4c 89 68 30          	mov    QWORD PTR [rax+0x30],r13
   285fe:	e8 2d 5d 04 00       	call   6e330 <JS_GetGlobalVarRef>
   28603:	85 c0                	test   eax,eax
   28605:	0f 85 dd 43 00 00    	jne    2c9e8 <JS_CallInternal+0x9f08>
   2860b:	41 0f b6 44 24 04    	movzx  eax,BYTE PTR [r12+0x4]
   28611:	48 83 c3 20          	add    rbx,0x20
   28615:	49 83 c4 05          	add    r12,0x5
   28619:	49 89 c5             	mov    r13,rax
   2861c:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   28620:	ff e0                	jmp    rax
   28622:	f3 0f 1e fa          	endbr64
   28626:	41 0f b7 04 24       	movzx  eax,WORD PTR [r12]
   2862b:	48 8b 8d b0 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x150]
   28632:	4d 8d 6c 24 02       	lea    r13,[r12+0x2]
   28637:	48 89 c2             	mov    rdx,rax
   2863a:	48 c1 e0 04          	shl    rax,0x4
   2863e:	48 01 c8             	add    rax,rcx
   28641:	48 8b 48 08          	mov    rcx,QWORD PTR [rax+0x8]
   28645:	83 f9 04             	cmp    ecx,0x4
   28648:	0f 84 cb 31 00 00    	je     2b819 <JS_CallInternal+0x8d39>
   2864e:	48 8b 53 f8          	mov    rdx,QWORD PTR [rbx-0x8]
   28652:	48 8b 73 f0          	mov    rsi,QWORD PTR [rbx-0x10]
   28656:	83 fa f6             	cmp    edx,0xfffffff6
   28659:	76 04                	jbe    2865f <JS_CallInternal+0x5b7f>
   2865b:	83 46 fc 01          	add    DWORD PTR [rsi-0x4],0x1
   2865f:	4c 8b 00             	mov    r8,QWORD PTR [rax]
   28662:	48 89 50 08          	mov    QWORD PTR [rax+0x8],rdx
   28666:	48 89 30             	mov    QWORD PTR [rax],rsi
   28669:	83 f9 f6             	cmp    ecx,0xfffffff6
   2866c:	76 13                	jbe    28681 <JS_CallInternal+0x5ba1>
   2866e:	41 8b 40 fc          	mov    eax,DWORD PTR [r8-0x4]
   28672:	83 e8 01             	sub    eax,0x1
   28675:	41 89 40 fc          	mov    DWORD PTR [r8-0x4],eax
   28679:	85 c0                	test   eax,eax
   2867b:	0f 8e 96 20 00 00    	jle    2a717 <JS_CallInternal+0x7c37>
   28681:	41 0f b6 44 24 02    	movzx  eax,BYTE PTR [r12+0x2]
   28687:	49 83 c4 03          	add    r12,0x3
   2868b:	49 89 c5             	mov    r13,rax
   2868e:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   28692:	ff e0                	jmp    rax
   28694:	f3 0f 1e fa          	endbr64
   28698:	4c 8b 43 e8          	mov    r8,QWORD PTR [rbx-0x18]
   2869c:	48 8b 4b e0          	mov    rcx,QWORD PTR [rbx-0x20]
   286a0:	4c 8d 73 f0          	lea    r14,[rbx-0x10]
   286a4:	41 83 f8 f6          	cmp    r8d,0xfffffff6
   286a8:	76 04                	jbe    286ae <JS_CallInternal+0x5bce>
   286aa:	83 41 fc 01          	add    DWORD PTR [rcx-0x4],0x1
   286ae:	48 8b 73 d0          	mov    rsi,QWORD PTR [rbx-0x30]
   286b2:	48 8b 53 d8          	mov    rdx,QWORD PTR [rbx-0x28]
   286b6:	41 ff 76 08          	push   QWORD PTR [r14+0x8]
   286ba:	41 b9 07 40 00 00    	mov    r9d,0x4007
   286c0:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   286c7:	41 ff 36             	push   QWORD PTR [r14]
   286ca:	e8 a1 af 01 00       	call   43670 <JS_DefinePropertyValueValue>
   286cf:	59                   	pop    rcx
   286d0:	5e                   	pop    rsi
   286d1:	85 c0                	test   eax,eax
   286d3:	0f 88 bc 2a 00 00    	js     2b195 <JS_CallInternal+0x86b5>
   286d9:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   286de:	4c 89 f3             	mov    rbx,r14
   286e1:	49 83 c4 01          	add    r12,0x1
   286e5:	49 89 c5             	mov    r13,rax
   286e8:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   286ec:	ff e0                	jmp    rax
   286ee:	f3 0f 1e fa          	endbr64
   286f2:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   286f9:	83 7b d8 ff          	cmp    DWORD PTR [rbx-0x28],0xffffffff
   286fd:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   28701:	0f 85 a8 3b 00 00    	jne    2c2af <JS_CallInternal+0x97cf>
   28707:	48 8b 73 e0          	mov    rsi,QWORD PTR [rbx-0x20]
   2870b:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   28712:	4c 8d 73 e0          	lea    r14,[rbx-0x20]
   28716:	49 8b 56 08          	mov    rdx,QWORD PTR [r14+0x8]
   2871a:	e8 c1 ad 01 00       	call   434e0 <JS_ValueToAtom>
   2871f:	41 89 c5             	mov    r13d,eax
   28722:	45 85 ed             	test   r13d,r13d
   28725:	0f 84 55 ab ff ff    	je     23280 <JS_CallInternal+0x7a0>
   2872b:	48 83 ec 08          	sub    rsp,0x8
   2872f:	4c 8d 53 d0          	lea    r10,[rbx-0x30]
   28733:	48 8d 43 c0          	lea    rax,[rbx-0x40]
   28737:	4c 8b 43 f0          	mov    r8,QWORD PTR [rbx-0x10]
   2873b:	4c 89 95 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],r10
   28742:	4c 8b 4b f8          	mov    r9,QWORD PTR [rbx-0x8]
   28746:	44 89 e9             	mov    ecx,r13d
   28749:	48 8b 73 d0          	mov    rsi,QWORD PTR [rbx-0x30]
   2874d:	48 8b 53 d8          	mov    rdx,QWORD PTR [rbx-0x28]
   28751:	48 89 85 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],rax
   28758:	68 00 80 00 00       	push   0x8000
   2875d:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   28764:	ff 73 c8             	push   QWORD PTR [rbx-0x38]
   28767:	ff 73 c0             	push   QWORD PTR [rbx-0x40]
   2876a:	e8 71 53 00 00       	call   2dae0 <JS_SetPropertyInternal>
   2876f:	48 83 c4 20          	add    rsp,0x20
   28773:	41 81 fd f2 00 00 00 	cmp    r13d,0xf2
   2877a:	4c 8b 95 40 fe ff ff 	mov    r10,QWORD PTR [rbp-0x1c0]
   28781:	89 c3                	mov    ebx,eax
   28783:	0f 8f d1 15 00 00    	jg     29d5a <JS_CallInternal+0x727a>
   28789:	48 8b 85 50 fe ff ff 	mov    rax,QWORD PTR [rbp-0x1b0]
   28790:	48 8b 50 08          	mov    rdx,QWORD PTR [rax+0x8]
   28794:	48 8b 30             	mov    rsi,QWORD PTR [rax]
   28797:	83 fa f6             	cmp    edx,0xfffffff6
   2879a:	76 11                	jbe    287ad <JS_CallInternal+0x5ccd>
   2879c:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   2879f:	83 e8 01             	sub    eax,0x1
   287a2:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   287a5:	85 c0                	test   eax,eax
   287a7:	0f 8e 49 22 00 00    	jle    2a9f6 <JS_CallInternal+0x7f16>
   287ad:	49 8b 52 08          	mov    rdx,QWORD PTR [r10+0x8]
   287b1:	49 8b 32             	mov    rsi,QWORD PTR [r10]
   287b4:	83 fa f6             	cmp    edx,0xfffffff6
   287b7:	76 11                	jbe    287ca <JS_CallInternal+0x5cea>
   287b9:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   287bc:	83 e8 01             	sub    eax,0x1
   287bf:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   287c2:	85 c0                	test   eax,eax
   287c4:	0f 8e dc 21 00 00    	jle    2a9a6 <JS_CallInternal+0x7ec6>
   287ca:	49 8b 56 08          	mov    rdx,QWORD PTR [r14+0x8]
   287ce:	49 8b 36             	mov    rsi,QWORD PTR [r14]
   287d1:	83 fa f6             	cmp    edx,0xfffffff6
   287d4:	76 11                	jbe    287e7 <JS_CallInternal+0x5d07>
   287d6:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   287d9:	83 e8 01             	sub    eax,0x1
   287dc:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   287df:	85 c0                	test   eax,eax
   287e1:	0f 8e d4 21 00 00    	jle    2a9bb <JS_CallInternal+0x7edb>
   287e7:	85 db                	test   ebx,ebx
   287e9:	0f 88 8e 41 00 00    	js     2c97d <JS_CallInternal+0x9e9d>
   287ef:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   287f4:	48 8b 9d 50 fe ff ff 	mov    rbx,QWORD PTR [rbp-0x1b0]
   287fb:	49 83 c4 01          	add    r12,0x1
   287ff:	49 89 c5             	mov    r13,rax
   28802:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   28806:	ff e0                	jmp    rax
   28808:	f3 0f 1e fa          	endbr64
   2880c:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   28813:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2881a:	48 89 de             	mov    rsi,rbx
   2881d:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   28821:	e8 da 23 07 00       	call   9ac00 <js_append_enumerate>
   28826:	85 c0                	test   eax,eax
   28828:	0f 85 52 aa ff ff    	jne    23280 <JS_CallInternal+0x7a0>
   2882e:	48 8b 53 f8          	mov    rdx,QWORD PTR [rbx-0x8]
   28832:	48 83 eb 10          	sub    rbx,0x10
   28836:	48 8b 33             	mov    rsi,QWORD PTR [rbx]
   28839:	83 fa f6             	cmp    edx,0xfffffff6
   2883c:	76 11                	jbe    2884f <JS_CallInternal+0x5d6f>
   2883e:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   28841:	83 e8 01             	sub    eax,0x1
   28844:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   28847:	85 c0                	test   eax,eax
   28849:	0f 8e d7 20 00 00    	jle    2a926 <JS_CallInternal+0x7e46>
   2884f:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   28854:	49 83 c4 01          	add    r12,0x1
   28858:	49 89 c5             	mov    r13,rax
   2885b:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   2885f:	ff e0                	jmp    rax
   28861:	f3 0f 1e fa          	endbr64
   28865:	48 8b 4b f0          	mov    rcx,QWORD PTR [rbx-0x10]
   28869:	83 7b f8 03          	cmp    DWORD PTR [rbx-0x8],0x3
   2886d:	4d 8d 6c 24 04       	lea    r13,[r12+0x4]
   28872:	48 8b 53 f8          	mov    rdx,QWORD PTR [rbx-0x8]
   28876:	48 89 c8             	mov    rax,rcx
   28879:	0f 87 36 14 00 00    	ja     29cb5 <JS_CallInternal+0x71d5>
   2887f:	48 83 eb 10          	sub    rbx,0x10
   28883:	85 c0                	test   eax,eax
   28885:	74 0c                	je     28893 <JS_CallInternal+0x5db3>
   28887:	41 8b 04 24          	mov    eax,DWORD PTR [r12]
   2888b:	83 e8 04             	sub    eax,0x4
   2888e:	48 98                	cdqe
   28890:	49 01 c5             	add    r13,rax
   28893:	48 8b 8d e8 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x118]
   2889a:	8b 81 a8 01 00 00    	mov    eax,DWORD PTR [rcx+0x1a8]
   288a0:	89 85 50 fe ff ff    	mov    DWORD PTR [rbp-0x1b0],eax
   288a6:	83 e8 01             	sub    eax,0x1
   288a9:	89 81 a8 01 00 00    	mov    DWORD PTR [rcx+0x1a8],eax
   288af:	85 c0                	test   eax,eax
   288b1:	0f 8e 61 2a 00 00    	jle    2b318 <JS_CallInternal+0x8838>
   288b7:	41 0f b6 45 00       	movzx  eax,BYTE PTR [r13+0x0]
   288bc:	4d 8d 65 01          	lea    r12,[r13+0x1]
   288c0:	49 89 c5             	mov    r13,rax
   288c3:	41 ff 24 c7          	jmp    QWORD PTR [r15+rax*8]
   288c7:	f3 0f 1e fa          	endbr64
   288cb:	48 8b 8d e8 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x118]
   288d2:	4d 0f bf 2c 24       	movsx  r13,WORD PTR [r12]
   288d7:	8b 81 a8 01 00 00    	mov    eax,DWORD PTR [rcx+0x1a8]
   288dd:	4d 01 e5             	add    r13,r12
   288e0:	89 85 50 fe ff ff    	mov    DWORD PTR [rbp-0x1b0],eax
   288e6:	83 e8 01             	sub    eax,0x1
   288e9:	89 81 a8 01 00 00    	mov    DWORD PTR [rcx+0x1a8],eax
   288ef:	85 c0                	test   eax,eax
   288f1:	0f 8e 87 2f 00 00    	jle    2b87e <JS_CallInternal+0x8d9e>
   288f7:	41 0f b6 45 00       	movzx  eax,BYTE PTR [r13+0x0]
   288fc:	4d 8d 65 01          	lea    r12,[r13+0x1]
   28900:	49 89 c5             	mov    r13,rax
   28903:	41 ff 24 c7          	jmp    QWORD PTR [r15+rax*8]
   28907:	f3 0f 1e fa          	endbr64
   2890b:	41 8b 0c 24          	mov    ecx,DWORD PTR [r12]
   2890f:	48 8b 73 f0          	mov    rsi,QWORD PTR [rbx-0x10]
   28913:	4d 8d 6c 24 04       	lea    r13,[r12+0x4]
   28918:	48 8b 53 f8          	mov    rdx,QWORD PTR [rbx-0x8]
   2891c:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   28923:	e8 08 bc 00 00       	call   34530 <JS_DefineObjectName.constprop.0>
   28928:	85 c0                	test   eax,eax
   2892a:	0f 88 8e 29 00 00    	js     2b2be <JS_CallInternal+0x87de>
   28930:	41 0f b6 44 24 04    	movzx  eax,BYTE PTR [r12+0x4]
   28936:	49 83 c4 05          	add    r12,0x5
   2893a:	49 89 c5             	mov    r13,rax
   2893d:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   28941:	ff e0                	jmp    rax
   28943:	f3 0f 1e fa          	endbr64
   28947:	41 0f b7 04 24       	movzx  eax,WORD PTR [r12]
   2894c:	48 8b 8d b0 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x150]
   28953:	4d 8d 6c 24 02       	lea    r13,[r12+0x2]
   28958:	48 c1 e0 04          	shl    rax,0x4
   2895c:	48 01 c8             	add    rax,rcx
   2895f:	83 78 08 04          	cmp    DWORD PTR [rax+0x8],0x4
   28963:	0f 85 09 24 00 00    	jne    2ad72 <JS_CallInternal+0x8292>
   28969:	f3 0f 6f 4b f0       	movdqu xmm1,XMMWORD PTR [rbx-0x10]
   2896e:	49 83 c4 03          	add    r12,0x3
   28972:	48 83 eb 10          	sub    rbx,0x10
   28976:	0f 11 08             	movups XMMWORD PTR [rax],xmm1
   28979:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   2897f:	49 89 c5             	mov    r13,rax
   28982:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   28986:	ff e0                	jmp    rax
   28988:	f3 0f 1e fa          	endbr64
   2898c:	48 8b 7b f8          	mov    rdi,QWORD PTR [rbx-0x8]
   28990:	41 8b 34 24          	mov    esi,DWORD PTR [r12]
   28994:	4d 8d 6c 24 04       	lea    r13,[r12+0x4]
   28999:	4c 8b 53 f0          	mov    r10,QWORD PTR [rbx-0x10]
   2899d:	83 ff ff             	cmp    edi,0xffffffff
   289a0:	0f 85 15 09 00 00    	jne    292bb <JS_CallInternal+0x67db>
   289a6:	4c 89 d1             	mov    rcx,r10
   289a9:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]
   289b0:	48 8b 51 18          	mov    rdx,QWORD PTR [rcx+0x18]
   289b4:	8b 42 18             	mov    eax,DWORD PTR [rdx+0x18]
   289b7:	41 89 c0             	mov    r8d,eax
   289ba:	41 21 f0             	and    r8d,esi
   289bd:	46 8b 44 82 38       	mov    r8d,DWORD PTR [rdx+r8*4+0x38]
   289c2:	4d 85 c0             	test   r8,r8
   289c5:	0f 84 b2 03 00 00    	je     28d7d <JS_CallInternal+0x629d>
   289cb:	4c 8d 0c 85 34 00 00 	lea    r9,[rax*4+0x34]
   289d2:	00 
   289d3:	4b 8d 04 c1          	lea    rax,[r9+r8*8]
   289d7:	48 01 d0             	add    rax,rdx
   289da:	39 70 04             	cmp    DWORD PTR [rax+0x4],esi
   289dd:	0f 85 8a 03 00 00    	jne    28d6d <JS_CallInternal+0x628d>
   289e3:	80 78 03 3f          	cmp    BYTE PTR [rax+0x3],0x3f
   289e7:	0f 87 ce 08 00 00    	ja     292bb <JS_CallInternal+0x67db>
   289ed:	48 8b 41 20          	mov    rax,QWORD PTR [rcx+0x20]
   289f1:	49 c1 e0 04          	shl    r8,0x4
   289f5:	4a 8d 54 00 f0       	lea    rdx,[rax+r8*1-0x10]
   289fa:	48 8b 02             	mov    rax,QWORD PTR [rdx]
   289fd:	48 8b 52 08          	mov    rdx,QWORD PTR [rdx+0x8]
   28a01:	83 fa f6             	cmp    edx,0xfffffff6
   28a04:	76 04                	jbe    28a0a <JS_CallInternal+0x5f2a>
   28a06:	83 40 fc 01          	add    DWORD PTR [rax-0x4],0x1
   28a0a:	48 89 03             	mov    QWORD PTR [rbx],rax
   28a0d:	49 83 c4 05          	add    r12,0x5
   28a11:	48 83 c3 10          	add    rbx,0x10
   28a15:	48 89 53 f8          	mov    QWORD PTR [rbx-0x8],rdx
   28a19:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   28a1f:	49 89 c5             	mov    r13,rax
   28a22:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   28a26:	ff e0                	jmp    rax
   28a28:	f3 0f 1e fa          	endbr64
   28a2c:	41 0f b7 04 24       	movzx  eax,WORD PTR [r12]
   28a31:	48 8b 8d b0 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x150]
   28a38:	4d 8d 6c 24 02       	lea    r13,[r12+0x2]
   28a3d:	48 89 c2             	mov    rdx,rax
   28a40:	48 c1 e0 04          	shl    rax,0x4
   28a44:	48 01 c8             	add    rax,rcx
   28a47:	48 8b 48 08          	mov    rcx,QWORD PTR [rax+0x8]
   28a4b:	83 f9 04             	cmp    ecx,0x4
   28a4e:	0f 84 e2 2d 00 00    	je     2b836 <JS_CallInternal+0x8d56>
   28a54:	f3 0f 6f 5b f0       	movdqu xmm3,XMMWORD PTR [rbx-0x10]
   28a59:	48 8b 30             	mov    rsi,QWORD PTR [rax]
   28a5c:	0f 11 18             	movups XMMWORD PTR [rax],xmm3
   28a5f:	83 f9 f6             	cmp    ecx,0xfffffff6
   28a62:	76 11                	jbe    28a75 <JS_CallInternal+0x5f95>
   28a64:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   28a67:	83 e8 01             	sub    eax,0x1
   28a6a:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   28a6d:	85 c0                	test   eax,eax
   28a6f:	0f 8e bd 1c 00 00    	jle    2a732 <JS_CallInternal+0x7c52>
   28a75:	41 0f b6 44 24 02    	movzx  eax,BYTE PTR [r12+0x2]
   28a7b:	48 83 eb 10          	sub    rbx,0x10
   28a7f:	49 83 c4 03          	add    r12,0x3
   28a83:	49 89 c5             	mov    r13,rax
   28a86:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   28a8a:	ff e0                	jmp    rax
   28a8c:	f3 0f 1e fa          	endbr64
   28a90:	48 8b 4b e0          	mov    rcx,QWORD PTR [rbx-0x20]
   28a94:	48 8b 73 f0          	mov    rsi,QWORD PTR [rbx-0x10]
   28a98:	49 83 c4 01          	add    r12,0x1
   28a9c:	48 8b 53 f8          	mov    rdx,QWORD PTR [rbx-0x8]
   28aa0:	4c 8b 43 e8          	mov    r8,QWORD PTR [rbx-0x18]
   28aa4:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   28aab:	e8 70 56 ff ff       	call   1e120 <js_method_set_home_object>
   28ab0:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   28ab6:	49 89 c5             	mov    r13,rax
   28ab9:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   28abd:	ff e0                	jmp    rax
   28abf:	f3 0f 1e fa          	endbr64
   28ac3:	48 8b 4b e0          	mov    rcx,QWORD PTR [rbx-0x20]
   28ac7:	48 8b 73 f0          	mov    rsi,QWORD PTR [rbx-0x10]
   28acb:	48 8b 53 f8          	mov    rdx,QWORD PTR [rbx-0x8]
   28acf:	4c 8b 43 e8          	mov    r8,QWORD PTR [rbx-0x18]
   28ad3:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   28ada:	e8 81 ad 01 00       	call   43860 <JS_DefineObjectNameComputed.constprop.0>
   28adf:	85 c0                	test   eax,eax
   28ae1:	0f 88 99 a7 ff ff    	js     23280 <JS_CallInternal+0x7a0>
   28ae7:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   28aec:	49 83 c4 01          	add    r12,0x1
   28af0:	49 89 c5             	mov    r13,rax
   28af3:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   28af7:	ff e0                	jmp    rax
   28af9:	f3 0f 1e fa          	endbr64
   28afd:	48 83 ec 08          	sub    rsp,0x8
   28b01:	41 8b 0c 24          	mov    ecx,DWORD PTR [r12]
   28b05:	48 8b 73 e0          	mov    rsi,QWORD PTR [rbx-0x20]
   28b09:	4c 8d 73 f0          	lea    r14,[rbx-0x10]
   28b0d:	4c 8b 43 f0          	mov    r8,QWORD PTR [rbx-0x10]
   28b11:	4c 8b 4b f8          	mov    r9,QWORD PTR [rbx-0x8]
   28b15:	4d 8d 6c 24 04       	lea    r13,[r12+0x4]
   28b1a:	48 8b 53 e8          	mov    rdx,QWORD PTR [rbx-0x18]
   28b1e:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   28b25:	68 07 40 00 00       	push   0x4007
   28b2a:	e8 71 72 00 00       	call   2fda0 <JS_DefinePropertyValue>
   28b2f:	59                   	pop    rcx
   28b30:	5e                   	pop    rsi
   28b31:	85 c0                	test   eax,eax
   28b33:	0f 88 05 2e 00 00    	js     2b93e <JS_CallInternal+0x8e5e>
   28b39:	41 0f b6 44 24 04    	movzx  eax,BYTE PTR [r12+0x4]
   28b3f:	4c 89 f3             	mov    rbx,r14
   28b42:	49 83 c4 05          	add    r12,0x5
   28b46:	49 89 c5             	mov    r13,rax
   28b49:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   28b4d:	ff e0                	jmp    rax
   28b4f:	f3 0f 1e fa          	endbr64
   28b53:	41 8b 34 24          	mov    esi,DWORD PTR [r12]
   28b57:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   28b5e:	4d 8d 6c 24 04       	lea    r13,[r12+0x4]
   28b63:	e8 a8 af 00 00       	call   33b10 <JS_NewSymbolFromAtom.constprop.0>
   28b68:	83 fa 06             	cmp    edx,0x6
   28b6b:	0f 84 d7 28 00 00    	je     2b448 <JS_CallInternal+0x8968>
   28b71:	48 89 03             	mov    QWORD PTR [rbx],rax
   28b74:	49 83 c4 05          	add    r12,0x5
   28b78:	48 83 c3 10          	add    rbx,0x10
   28b7c:	48 89 53 f8          	mov    QWORD PTR [rbx-0x8],rdx
   28b80:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   28b86:	49 89 c5             	mov    r13,rax
   28b89:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   28b8d:	ff e0                	jmp    rax
   28b8f:	f3 0f 1e fa          	endbr64
   28b93:	48 8b 7b f8          	mov    rdi,QWORD PTR [rbx-0x8]
   28b97:	48 8b 73 f0          	mov    rsi,QWORD PTR [rbx-0x10]
   28b9b:	83 ff ff             	cmp    edi,0xffffffff
   28b9e:	0f 85 57 06 00 00    	jne    291fb <JS_CallInternal+0x671b>
   28ba4:	48 89 f1             	mov    rcx,rsi
   28ba7:	66 0f 1f 84 00 00 00 	nop    WORD PTR [rax+rax*1+0x0]
   28bae:	00 00 
   28bb0:	48 8b 51 18          	mov    rdx,QWORD PTR [rcx+0x18]
   28bb4:	8b 42 18             	mov    eax,DWORD PTR [rdx+0x18]
   28bb7:	41 89 c0             	mov    r8d,eax
   28bba:	41 83 e0 32          	and    r8d,0x32
   28bbe:	46 8b 44 82 38       	mov    r8d,DWORD PTR [rdx+r8*4+0x38]
   28bc3:	4d 85 c0             	test   r8,r8
   28bc6:	0f 84 79 01 00 00    	je     28d45 <JS_CallInternal+0x6265>
   28bcc:	4c 8d 0c 85 34 00 00 	lea    r9,[rax*4+0x34]
   28bd3:	00 
   28bd4:	4b 8d 04 c1          	lea    rax,[r9+r8*8]
   28bd8:	48 01 d0             	add    rax,rdx
   28bdb:	83 78 04 32          	cmp    DWORD PTR [rax+0x4],0x32
   28bdf:	0f 85 50 01 00 00    	jne    28d35 <JS_CallInternal+0x6255>
   28be5:	80 78 03 3f          	cmp    BYTE PTR [rax+0x3],0x3f
   28be9:	0f 87 0c 06 00 00    	ja     291fb <JS_CallInternal+0x671b>
   28bef:	48 8b 41 20          	mov    rax,QWORD PTR [rcx+0x20]
   28bf3:	49 c1 e0 04          	shl    r8,0x4
   28bf7:	4a 8d 44 00 f0       	lea    rax,[rax+r8*1-0x10]
   28bfc:	48 8b 48 08          	mov    rcx,QWORD PTR [rax+0x8]
   28c00:	4c 8b 30             	mov    r14,QWORD PTR [rax]
   28c03:	83 f9 f6             	cmp    ecx,0xfffffff6
   28c06:	76 05                	jbe    28c0d <JS_CallInternal+0x612d>
   28c08:	41 83 46 fc 01       	add    DWORD PTR [r14-0x4],0x1
   28c0d:	4c 8d 6b f0          	lea    r13,[rbx-0x10]
   28c11:	49 8b 55 08          	mov    rdx,QWORD PTR [r13+0x8]
   28c15:	49 8b 75 00          	mov    rsi,QWORD PTR [r13+0x0]
   28c19:	83 fa f6             	cmp    edx,0xfffffff6
   28c1c:	76 11                	jbe    28c2f <JS_CallInternal+0x614f>
   28c1e:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   28c21:	83 e8 01             	sub    eax,0x1
   28c24:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   28c27:	85 c0                	test   eax,eax
   28c29:	0f 8e 1b 1b 00 00    	jle    2a74a <JS_CallInternal+0x7c6a>
   28c2f:	4c 89 73 f0          	mov    QWORD PTR [rbx-0x10],r14
   28c33:	49 83 c4 01          	add    r12,0x1
   28c37:	48 89 4b f8          	mov    QWORD PTR [rbx-0x8],rcx
   28c3b:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   28c41:	49 89 c5             	mov    r13,rax
   28c44:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   28c48:	ff e0                	jmp    rax
   28c4a:	f3 0f 1e fa          	endbr64
   28c4e:	48 8b 7b f8          	mov    rdi,QWORD PTR [rbx-0x8]
   28c52:	41 8b 34 24          	mov    esi,DWORD PTR [r12]
   28c56:	4d 8d 74 24 04       	lea    r14,[r12+0x4]
   28c5b:	4c 8b 53 f0          	mov    r10,QWORD PTR [rbx-0x10]
   28c5f:	83 ff ff             	cmp    edi,0xffffffff
   28c62:	0f 85 9f 06 00 00    	jne    29307 <JS_CallInternal+0x6827>
   28c68:	4c 89 d1             	mov    rcx,r10
   28c6b:	0f 1f 44 00 00       	nop    DWORD PTR [rax+rax*1+0x0]
   28c70:	48 8b 51 18          	mov    rdx,QWORD PTR [rcx+0x18]
   28c74:	8b 42 18             	mov    eax,DWORD PTR [rdx+0x18]
   28c77:	41 89 c0             	mov    r8d,eax
   28c7a:	41 21 f0             	and    r8d,esi
   28c7d:	46 8b 44 82 38       	mov    r8d,DWORD PTR [rdx+r8*4+0x38]
   28c82:	4d 85 c0             	test   r8,r8
   28c85:	0f 84 85 00 00 00    	je     28d10 <JS_CallInternal+0x6230>
   28c8b:	4c 8d 0c 85 34 00 00 	lea    r9,[rax*4+0x34]
   28c92:	00 
   28c93:	4b 8d 04 c1          	lea    rax,[r9+r8*8]
   28c97:	48 01 d0             	add    rax,rdx
   28c9a:	39 70 04             	cmp    DWORD PTR [rax+0x4],esi
   28c9d:	75 65                	jne    28d04 <JS_CallInternal+0x6224>
   28c9f:	80 78 03 3f          	cmp    BYTE PTR [rax+0x3],0x3f
   28ca3:	0f 87 5e 06 00 00    	ja     29307 <JS_CallInternal+0x6827>
   28ca9:	48 8b 41 20          	mov    rax,QWORD PTR [rcx+0x20]
   28cad:	49 c1 e0 04          	shl    r8,0x4
   28cb1:	4a 8d 54 00 f0       	lea    rdx,[rax+r8*1-0x10]
   28cb6:	4c 8b 42 08          	mov    r8,QWORD PTR [rdx+0x8]
   28cba:	48 8b 02             	mov    rax,QWORD PTR [rdx]
   28cbd:	41 83 f8 f6          	cmp    r8d,0xfffffff6
   28cc1:	76 04                	jbe    28cc7 <JS_CallInternal+0x61e7>
   28cc3:	83 40 fc 01          	add    DWORD PTR [rax-0x4],0x1
   28cc7:	4c 8d 6b f0          	lea    r13,[rbx-0x10]
   28ccb:	49 8b 55 08          	mov    rdx,QWORD PTR [r13+0x8]
   28ccf:	49 8b 75 00          	mov    rsi,QWORD PTR [r13+0x0]
   28cd3:	83 fa f6             	cmp    edx,0xfffffff6
   28cd6:	76 11                	jbe    28ce9 <JS_CallInternal+0x6209>
   28cd8:	8b 4e fc             	mov    ecx,DWORD PTR [rsi-0x4]
   28cdb:	83 e9 01             	sub    ecx,0x1
   28cde:	89 4e fc             	mov    DWORD PTR [rsi-0x4],ecx
   28ce1:	85 c9                	test   ecx,ecx
   28ce3:	0f 8e c7 17 00 00    	jle    2a4b0 <JS_CallInternal+0x79d0>
   28ce9:	48 89 43 f0          	mov    QWORD PTR [rbx-0x10],rax
   28ced:	49 83 c4 05          	add    r12,0x5
   28cf1:	4c 89 43 f8          	mov    QWORD PTR [rbx-0x8],r8
   28cf5:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   28cfb:	49 89 c5             	mov    r13,rax
   28cfe:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   28d02:	ff e0                	jmp    rax
   28d04:	44 8b 00             	mov    r8d,DWORD PTR [rax]
   28d07:	41 81 e0 ff ff ff 03 	and    r8d,0x3ffffff
   28d0e:	75 83                	jne    28c93 <JS_CallInternal+0x61b3>
   28d10:	f6 41 10 08          	test   BYTE PTR [rcx+0x10],0x8
   28d14:	0f 85 e3 05 00 00    	jne    292fd <JS_CallInternal+0x681d>
   28d1a:	48 8b 4a 30          	mov    rcx,QWORD PTR [rdx+0x30]
   28d1e:	48 85 c9             	test   rcx,rcx
   28d21:	0f 85 49 ff ff ff    	jne    28c70 <JS_CallInternal+0x6190>
   28d27:	4c 8d 6b f0          	lea    r13,[rbx-0x10]
   28d2b:	41 b8 03 00 00 00    	mov    r8d,0x3
   28d31:	31 c0                	xor    eax,eax
   28d33:	eb 96                	jmp    28ccb <JS_CallInternal+0x61eb>
   28d35:	44 8b 00             	mov    r8d,DWORD PTR [rax]
   28d38:	41 81 e0 ff ff ff 03 	and    r8d,0x3ffffff
   28d3f:	0f 85 8f fe ff ff    	jne    28bd4 <JS_CallInternal+0x60f4>
   28d45:	f6 41 10 08          	test   BYTE PTR [rcx+0x10],0x8
   28d49:	0f 85 a2 04 00 00    	jne    291f1 <JS_CallInternal+0x6711>
   28d4f:	48 8b 4a 30          	mov    rcx,QWORD PTR [rdx+0x30]
   28d53:	48 85 c9             	test   rcx,rcx
   28d56:	0f 85 54 fe ff ff    	jne    28bb0 <JS_CallInternal+0x60d0>
   28d5c:	4c 8d 6b f0          	lea    r13,[rbx-0x10]
   28d60:	b9 03 00 00 00       	mov    ecx,0x3
   28d65:	45 31 f6             	xor    r14d,r14d
   28d68:	e9 a4 fe ff ff       	jmp    28c11 <JS_CallInternal+0x6131>
   28d6d:	44 8b 00             	mov    r8d,DWORD PTR [rax]
   28d70:	41 81 e0 ff ff ff 03 	and    r8d,0x3ffffff
   28d77:	0f 85 56 fc ff ff    	jne    289d3 <JS_CallInternal+0x5ef3>
   28d7d:	f6 41 10 08          	test   BYTE PTR [rcx+0x10],0x8
   28d81:	0f 85 2a 05 00 00    	jne    292b1 <JS_CallInternal+0x67d1>
   28d87:	48 8b 4a 30          	mov    rcx,QWORD PTR [rdx+0x30]
   28d8b:	48 85 c9             	test   rcx,rcx
   28d8e:	0f 85 1c fc ff ff    	jne    289b0 <JS_CallInternal+0x5ed0>
   28d94:	ba 03 00 00 00       	mov    edx,0x3
   28d99:	31 c0                	xor    eax,eax
   28d9b:	e9 6a fc ff ff       	jmp    28a0a <JS_CallInternal+0x5f2a>
   28da0:	8b 38                	mov    edi,DWORD PTR [rax]
   28da2:	81 e7 ff ff ff 03    	and    edi,0x3ffffff
   28da8:	0f 85 d0 b2 ff ff    	jne    2407e <JS_CallInternal+0x159e>
   28dae:	f6 42 10 08          	test   BYTE PTR [rdx+0x10],0x8
   28db2:	0f 85 98 05 00 00    	jne    29350 <JS_CallInternal+0x6870>
   28db8:	49 8b 55 30          	mov    rdx,QWORD PTR [r13+0x30]
   28dbc:	48 85 d2             	test   rdx,rdx
   28dbf:	0f 84 3d 16 00 00    	je     2a402 <JS_CallInternal+0x7922>
   28dc5:	4c 8b 6a 18          	mov    r13,QWORD PTR [rdx+0x18]
   28dc9:	e9 92 b2 ff ff       	jmp    24060 <JS_CallInternal+0x1580>
   28dce:	8b 10                	mov    edx,DWORD PTR [rax]
   28dd0:	81 e2 ff ff ff 03    	and    edx,0x3ffffff
   28dd6:	0f 85 d2 b1 ff ff    	jne    23fae <JS_CallInternal+0x14ce>
   28ddc:	f6 47 10 08          	test   BYTE PTR [rdi+0x10],0x8
   28de0:	0f 85 d3 05 00 00    	jne    293b9 <JS_CallInternal+0x68d9>
   28de6:	49 8b 7d 30          	mov    rdi,QWORD PTR [r13+0x30]
   28dea:	48 85 ff             	test   rdi,rdi
   28ded:	0f 84 c2 15 00 00    	je     2a3b5 <JS_CallInternal+0x78d5>
   28df3:	4c 8b 6f 18          	mov    r13,QWORD PTR [rdi+0x18]
   28df7:	e9 94 b1 ff ff       	jmp    23f90 <JS_CallInternal+0x14b0>
   28dfc:	8b b5 bc fe ff ff    	mov    esi,DWORD PTR [rbp-0x144]
   28e02:	39 f7                	cmp    edi,esi
   28e04:	41 89 f5             	mov    r13d,esi
   28e07:	44 0f 4e ef          	cmovle r13d,edi
   28e0b:	45 85 ed             	test   r13d,r13d
   28e0e:	0f 8e 2c 14 00 00    	jle    2a240 <JS_CallInternal+0x7760>
   28e14:	4c 8b bd a8 fe ff ff 	mov    r15,QWORD PTR [rbp-0x158]
   28e1b:	4d 63 f5             	movsxd r14,r13d
   28e1e:	4d 8d 43 08          	lea    r8,[r11+0x8]
   28e22:	49 c1 e6 04          	shl    r14,0x4
   28e26:	4c 89 fe             	mov    rsi,r15
   28e29:	4d 01 fe             	add    r14,r15
   28e2c:	0f 1f 40 00          	nop    DWORD PTR [rax+0x0]
   28e30:	4c 8b 66 08          	mov    r12,QWORD PTR [rsi+0x8]
   28e34:	4c 8b 3e             	mov    r15,QWORD PTR [rsi]
   28e37:	41 83 fc f6          	cmp    r12d,0xfffffff6
   28e3b:	76 05                	jbe    28e42 <JS_CallInternal+0x6362>
   28e3d:	41 83 47 fc 01       	add    DWORD PTR [r15-0x4],0x1
   28e42:	48 83 c6 10          	add    rsi,0x10
   28e46:	4d 89 78 f8          	mov    QWORD PTR [r8-0x8],r15
   28e4a:	49 83 c0 10          	add    r8,0x10
   28e4e:	4d 89 60 f0          	mov    QWORD PTR [r8-0x10],r12
   28e52:	4c 39 f6             	cmp    rsi,r14
   28e55:	75 d9                	jne    28e30 <JS_CallInternal+0x6350>
   28e57:	44 39 ef             	cmp    edi,r13d
   28e5a:	7e 3c                	jle    28e98 <JS_CallInternal+0x63b8>
   28e5c:	44 8d 47 ff          	lea    r8d,[rdi-0x1]
   28e60:	4d 63 e5             	movsxd r12,r13d
   28e63:	45 29 e8             	sub    r8d,r13d
   28e66:	4c 89 e6             	mov    rsi,r12
   28e69:	4d 01 e0             	add    r8,r12
   28e6c:	48 c1 e6 04          	shl    rsi,0x4
   28e70:	49 c1 e0 04          	shl    r8,0x4
   28e74:	4c 01 de             	add    rsi,r11
   28e77:	4f 8d 44 03 10       	lea    r8,[r11+r8*1+0x10]
   28e7c:	0f 1f 40 00          	nop    DWORD PTR [rax+0x0]
   28e80:	48 c7 06 00 00 00 00 	mov    QWORD PTR [rsi],0x0
   28e87:	48 83 c6 10          	add    rsi,0x10
   28e8b:	48 c7 46 f8 03 00 00 	mov    QWORD PTR [rsi-0x8],0x3
   28e92:	00 
   28e93:	4c 39 c6             	cmp    rsi,r8
   28e96:	75 e8                	jne    28e80 <JS_CallInternal+0x63a0>
   28e98:	89 bd 38 ff ff ff    	mov    DWORD PTR [rbp-0xc8],edi
   28e9e:	4c 89 9d 90 fe ff ff 	mov    QWORD PTR [rbp-0x170],r11
   28ea5:	e9 14 9e ff ff       	jmp    22cbe <JS_CallInternal+0x1de>
   28eaa:	48 83 ec 08          	sub    rsp,0x8
   28eae:	8b 8d 38 fe ff ff    	mov    ecx,DWORD PTR [rbp-0x1c8]
   28eb4:	49 89 d1             	mov    r9,rdx
   28eb7:	48 89 c6             	mov    rsi,rax
   28eba:	6a 00                	push   0x0
   28ebc:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   28ec3:	48 89 85 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],rax
   28eca:	e8 e1 3e 00 00       	call   2cdb0 <JS_GetPropertyInternal>
   28ecf:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   28ed6:	48 89 c6             	mov    rsi,rax
   28ed9:	e8 f2 5b ff ff       	call   1ead0 <JS_ToBoolFree>
   28ede:	4c 8b 85 40 fe ff ff 	mov    r8,QWORD PTR [rbp-0x1c0]
   28ee5:	89 c1                	mov    ecx,eax
   28ee7:	41 8b 40 fc          	mov    eax,DWORD PTR [r8-0x4]
   28eeb:	83 e8 01             	sub    eax,0x1
   28eee:	41 89 40 fc          	mov    DWORD PTR [r8-0x4],eax
   28ef2:	41 5b                	pop    r11
   28ef4:	5a                   	pop    rdx
   28ef5:	85 c0                	test   eax,eax
   28ef7:	0f 8e f7 36 00 00    	jle    2c5f4 <JS_CallInternal+0x9b14>
   28efd:	85 c9                	test   ecx,ecx
   28eff:	0f 88 e1 a6 ff ff    	js     235e6 <JS_CallInternal+0xb06>
   28f05:	0f 84 78 9f ff ff    	je     22e83 <JS_CallInternal+0x3a3>
   28f0b:	48 8b 53 f8          	mov    rdx,QWORD PTR [rbx-0x8]
   28f0f:	48 83 eb 10          	sub    rbx,0x10
   28f13:	48 8b 33             	mov    rsi,QWORD PTR [rbx]
   28f16:	83 fa f6             	cmp    edx,0xfffffff6
   28f19:	0f 86 a0 a4 ff ff    	jbe    233bf <JS_CallInternal+0x8df>
   28f1f:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   28f22:	83 e8 01             	sub    eax,0x1
   28f25:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   28f28:	85 c0                	test   eax,eax
   28f2a:	0f 8f 8f a4 ff ff    	jg     233bf <JS_CallInternal+0x8df>
   28f30:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   28f37:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   28f3b:	e8 60 39 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   28f40:	e9 7a a4 ff ff       	jmp    233bf <JS_CallInternal+0x8df>
   28f45:	8b 85 38 fe ff ff    	mov    eax,DWORD PTR [rbp-0x1c8]
   28f4b:	48 8b 9d 50 fe ff ff 	mov    rbx,QWORD PTR [rbp-0x1b0]
   28f52:	4c 8b a5 40 fe ff ff 	mov    r12,QWORD PTR [rbp-0x1c0]
   28f59:	83 c0 02             	add    eax,0x2
   28f5c:	48 98                	cdqe
   28f5e:	49 83 c4 03          	add    r12,0x3
   28f62:	48 c1 e0 04          	shl    rax,0x4
   28f66:	48 29 c3             	sub    rbx,rax
   28f69:	48 89 da             	mov    rdx,rbx
   28f6c:	48 8d 5b 10          	lea    rbx,[rbx+0x10]
   28f70:	4c 89 2a             	mov    QWORD PTR [rdx],r13
   28f73:	4c 89 72 08          	mov    QWORD PTR [rdx+0x8],r14
   28f77:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   28f7d:	49 89 c5             	mov    r13,rax
   28f80:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   28f84:	ff e0                	jmp    rax
   28f86:	4c 89 f0             	mov    rax,r14
   28f89:	4c 8b a5 50 fe ff ff 	mov    r12,QWORD PTR [rbp-0x1b0]
   28f90:	49 89 de             	mov    r14,rbx
   28f93:	48 89 c3             	mov    rbx,rax
   28f96:	48 8b 85 68 fe ff ff 	mov    rax,QWORD PTR [rbp-0x198]
   28f9d:	49 39 c6             	cmp    r14,rax
   28fa0:	0f 84 51 26 00 00    	je     2b5f7 <JS_CallInternal+0x8b17>
   28fa6:	4d 89 6e f0          	mov    QWORD PTR [r14-0x10],r13
   28faa:	49 83 c4 01          	add    r12,0x1
   28fae:	49 89 5e f8          	mov    QWORD PTR [r14-0x8],rbx
   28fb2:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   28fb8:	4c 89 f3             	mov    rbx,r14
   28fbb:	49 89 c5             	mov    r13,rax
   28fbe:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   28fc2:	ff e0                	jmp    rax
   28fc4:	80 fa 01             	cmp    dl,0x1
   28fc7:	0f 84 7b 02 00 00    	je     29248 <JS_CallInternal+0x6768>
   28fcd:	80 cc 10             	or     ah,0x10
   28fd0:	f3 0f 6f 53 f0       	movdqu xmm2,XMMWORD PTR [rbx-0x10]
   28fd5:	8b b5 50 fe ff ff    	mov    esi,DWORD PTR [rbp-0x1b0]
   28fdb:	89 85 24 fe ff ff    	mov    DWORD PTR [rbp-0x1dc],eax
   28fe1:	49 8b 04 24          	mov    rax,QWORD PTR [r12]
   28fe5:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   28fec:	0f 29 95 e0 fd ff ff 	movaps XMMWORD PTR [rbp-0x220],xmm2
   28ff3:	48 89 85 d8 fd ff ff 	mov    QWORD PTR [rbp-0x228],rax
   28ffa:	49 8b 44 24 08       	mov    rax,QWORD PTR [r12+0x8]
   28fff:	48 89 85 d0 fd ff ff 	mov    QWORD PTR [rbp-0x230],rax
   29006:	e8 65 71 01 00       	call   40170 <js_get_function_name>
   2900b:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   29012:	4c 8d 05 2b 41 0a 00 	lea    r8,[rip+0xa412b]        # cd144 <_IO_stdin_used+0x144>
   29019:	48 8d 35 52 45 0a 00 	lea    rsi,[rip+0xa4552]        # cd572 <_IO_stdin_used+0x572>
   29020:	49 89 d1             	mov    r9,rdx
   29023:	48 89 c2             	mov    rdx,rax
   29026:	4c 89 c9             	mov    rcx,r9
   29029:	e8 d2 6f 01 00       	call   40000 <JS_ConcatString3>
   2902e:	49 89 d1             	mov    r9,rdx
   29031:	e9 a6 a8 ff ff       	jmp    238dc <JS_CallInternal+0xdfc>
   29036:	8b 85 40 fe ff ff    	mov    eax,DWORD PTR [rbp-0x1c0]
   2903c:	49 83 c4 03          	add    r12,0x3
   29040:	83 c0 02             	add    eax,0x2
   29043:	48 98                	cdqe
   29045:	48 c1 e0 04          	shl    rax,0x4
   29049:	48 29 c3             	sub    rbx,rax
   2904c:	48 89 da             	mov    rdx,rbx
   2904f:	48 8d 5b 10          	lea    rbx,[rbx+0x10]
   29053:	4c 89 0a             	mov    QWORD PTR [rdx],r9
   29056:	4c 89 42 08          	mov    QWORD PTR [rdx+0x8],r8
   2905a:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   29060:	49 89 c5             	mov    r13,rax
   29063:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   29067:	ff e0                	jmp    rax
   29069:	8b 85 50 fe ff ff    	mov    eax,DWORD PTR [rbp-0x1b0]
   2906f:	49 83 c4 05          	add    r12,0x5
   29073:	83 c0 01             	add    eax,0x1
   29076:	48 98                	cdqe
   29078:	48 c1 e0 04          	shl    rax,0x4
   2907c:	48 29 c3             	sub    rbx,rax
   2907f:	48 89 da             	mov    rdx,rbx
   29082:	48 8d 5b 10          	lea    rbx,[rbx+0x10]
   29086:	4c 89 0a             	mov    QWORD PTR [rdx],r9
   29089:	4c 89 42 08          	mov    QWORD PTR [rdx+0x8],r8
   2908d:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   29093:	49 89 c5             	mov    r13,rax
   29096:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   2909a:	ff e0                	jmp    rax
   2909c:	48 8b 9d 38 fe ff ff 	mov    rbx,QWORD PTR [rbp-0x1c8]
   290a3:	4c 8b a5 28 fe ff ff 	mov    r12,QWORD PTR [rbp-0x1d8]
   290aa:	4c 89 f6             	mov    rsi,r14
   290ad:	e8 ee b9 fe ff       	call   14aa0 <__js_free>
   290b2:	41 83 fd 06          	cmp    r13d,0x6
   290b6:	0f 84 5d 19 00 00    	je     2aa19 <JS_CallInternal+0x7f39>
   290bc:	48 8b 53 e8          	mov    rdx,QWORD PTR [rbx-0x18]
   290c0:	48 8b 73 e0          	mov    rsi,QWORD PTR [rbx-0x20]
   290c4:	83 fa f6             	cmp    edx,0xfffffff6
   290c7:	76 11                	jbe    290da <JS_CallInternal+0x65fa>
   290c9:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   290cc:	83 e8 01             	sub    eax,0x1
   290cf:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   290d2:	85 c0                	test   eax,eax
   290d4:	0f 8e 4b 19 00 00    	jle    2aa25 <JS_CallInternal+0x7f45>
   290da:	48 8b 85 50 fe ff ff 	mov    rax,QWORD PTR [rbp-0x1b0]
   290e1:	48 8b 50 08          	mov    rdx,QWORD PTR [rax+0x8]
   290e5:	48 8b 30             	mov    rsi,QWORD PTR [rax]
   290e8:	83 fa f6             	cmp    edx,0xfffffff6
   290eb:	76 11                	jbe    290fe <JS_CallInternal+0x661e>
   290ed:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   290f0:	83 e8 01             	sub    eax,0x1
   290f3:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   290f6:	85 c0                	test   eax,eax
   290f8:	0f 8e 50 13 00 00    	jle    2a44e <JS_CallInternal+0x796e>
   290fe:	48 8b 85 40 fe ff ff 	mov    rax,QWORD PTR [rbp-0x1c0]
   29105:	4c 89 6b e8          	mov    QWORD PTR [rbx-0x18],r13
   29109:	49 83 c4 03          	add    r12,0x3
   2910d:	48 89 43 e0          	mov    QWORD PTR [rbx-0x20],rax
   29111:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   29117:	48 8b 9d 50 fe ff ff 	mov    rbx,QWORD PTR [rbp-0x1b0]
   2911e:	49 89 c5             	mov    r13,rax
   29121:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   29125:	ff e0                	jmp    rax
   29127:	8b 10                	mov    edx,DWORD PTR [rax]
   29129:	81 e2 ff ff ff 03    	and    edx,0x3ffffff
   2912f:	0f 85 bb d8 ff ff    	jne    269f0 <JS_CallInternal+0x3f10>
   29135:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2913c:	89 f2                	mov    edx,esi
   2913e:	b9 07 00 00 00       	mov    ecx,0x7
   29143:	4c 89 c6             	mov    rsi,r8
   29146:	e8 75 ce 01 00       	call   45fc0 <add_property>
   2914b:	48 85 c0             	test   rax,rax
   2914e:	0f 84 c8 d8 ff ff    	je     26a1c <JS_CallInternal+0x3f3c>
   29154:	48 8b 8d 50 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x1b0]
   2915b:	4c 89 28             	mov    QWORD PTR [rax],r13
   2915e:	48 89 48 08          	mov    QWORD PTR [rax+0x8],rcx
   29162:	49 8b 56 08          	mov    rdx,QWORD PTR [r14+0x8]
   29166:	49 8b 36             	mov    rsi,QWORD PTR [r14]
   29169:	83 fa f6             	cmp    edx,0xfffffff6
   2916c:	76 11                	jbe    2917f <JS_CallInternal+0x669f>
   2916e:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   29171:	83 e8 01             	sub    eax,0x1
   29174:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   29177:	85 c0                	test   eax,eax
   29179:	0f 8e f8 23 00 00    	jle    2b577 <JS_CallInternal+0x8a97>
   2917f:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   29184:	4c 89 f3             	mov    rbx,r14
   29187:	49 83 c4 01          	add    r12,0x1
   2918b:	49 89 c5             	mov    r13,rax
   2918e:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   29192:	ff e0                	jmp    rax
   29194:	ba 08 00 00 00       	mov    edx,0x8
   29199:	e9 51 e1 ff ff       	jmp    272ef <JS_CallInternal+0x480f>
   2919e:	81 bd 50 fe ff ff f2 	cmp    DWORD PTR [rbp-0x1b0],0xf2
   291a5:	00 00 00 
   291a8:	0f 8f 33 10 00 00    	jg     2a1e1 <JS_CallInternal+0x7701>
   291ae:	48 8b 53 e8          	mov    rdx,QWORD PTR [rbx-0x18]
   291b2:	48 8b 73 e0          	mov    rsi,QWORD PTR [rbx-0x20]
   291b6:	83 fa f6             	cmp    edx,0xfffffff6
   291b9:	0f 86 23 a8 ff ff    	jbe    239e2 <JS_CallInternal+0xf02>
   291bf:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   291c2:	83 e8 01             	sub    eax,0x1
   291c5:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   291c8:	85 c0                	test   eax,eax
   291ca:	0f 8f 12 a8 ff ff    	jg     239e2 <JS_CallInternal+0xf02>
   291d0:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   291d7:	89 8d 50 fe ff ff    	mov    DWORD PTR [rbp-0x1b0],ecx
   291dd:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   291e1:	e8 ba 36 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   291e6:	8b 8d 50 fe ff ff    	mov    ecx,DWORD PTR [rbp-0x1b0]
   291ec:	e9 f1 a7 ff ff       	jmp    239e2 <JS_CallInternal+0xf02>
   291f1:	48 89 ce             	mov    rsi,rcx
   291f4:	48 c7 c7 ff ff ff ff 	mov    rdi,0xffffffffffffffff
   291fb:	48 83 ec 08          	sub    rsp,0x8
   291ff:	4c 8b 43 f0          	mov    r8,QWORD PTR [rbx-0x10]
   29203:	4c 8b 4b f8          	mov    r9,QWORD PTR [rbx-0x8]
   29207:	48 89 fa             	mov    rdx,rdi
   2920a:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   29211:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   29218:	b9 32 00 00 00       	mov    ecx,0x32
   2921d:	4c 8d 6b f0          	lea    r13,[rbx-0x10]
   29221:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   29225:	6a 00                	push   0x0
   29227:	e8 84 3b 00 00       	call   2cdb0 <JS_GetPropertyInternal>
   2922c:	5f                   	pop    rdi
   2922d:	41 58                	pop    r8
   2922f:	49 89 c6             	mov    r14,rax
   29232:	48 89 d1             	mov    rcx,rdx
   29235:	83 fa 06             	cmp    edx,0x6
   29238:	0f 85 d3 f9 ff ff    	jne    28c11 <JS_CallInternal+0x6131>
   2923e:	e9 3d a0 ff ff       	jmp    23280 <JS_CallInternal+0x7a0>
   29243:	0f 1f 44 00 00       	nop    DWORD PTR [rax+rax*1+0x0]
   29248:	80 cc 08             	or     ah,0x8
   2924b:	f3 0f 6f 7b f0       	movdqu xmm7,XMMWORD PTR [rbx-0x10]
   29250:	8b b5 50 fe ff ff    	mov    esi,DWORD PTR [rbp-0x1b0]
   29256:	89 85 24 fe ff ff    	mov    DWORD PTR [rbp-0x1dc],eax
   2925c:	49 8b 04 24          	mov    rax,QWORD PTR [r12]
   29260:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   29267:	0f 29 bd 10 fe ff ff 	movaps XMMWORD PTR [rbp-0x1f0],xmm7
   2926e:	48 89 85 d8 fd ff ff 	mov    QWORD PTR [rbp-0x228],rax
   29275:	49 8b 44 24 08       	mov    rax,QWORD PTR [r12+0x8]
   2927a:	48 89 85 d0 fd ff ff 	mov    QWORD PTR [rbp-0x230],rax
   29281:	e8 ea 6e 01 00       	call   40170 <js_get_function_name>
   29286:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2928d:	4c 8d 05 b0 3e 0a 00 	lea    r8,[rip+0xa3eb0]        # cd144 <_IO_stdin_used+0x144>
   29294:	48 8d 35 d2 42 0a 00 	lea    rsi,[rip+0xa42d2]        # cd56d <_IO_stdin_used+0x56d>
   2929b:	49 89 d1             	mov    r9,rdx
   2929e:	48 89 c2             	mov    rdx,rax
   292a1:	4c 89 c9             	mov    rcx,r9
   292a4:	e8 57 6d 01 00       	call   40000 <JS_ConcatString3>
   292a9:	49 89 d1             	mov    r9,rdx
   292ac:	e9 2b a6 ff ff       	jmp    238dc <JS_CallInternal+0xdfc>
   292b1:	49 89 ca             	mov    r10,rcx
   292b4:	48 c7 c7 ff ff ff ff 	mov    rdi,0xffffffffffffffff
   292bb:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   292c2:	48 83 ec 08          	sub    rsp,0x8
   292c6:	48 89 fa             	mov    rdx,rdi
   292c9:	89 f1                	mov    ecx,esi
   292cb:	4c 8b 4b f8          	mov    r9,QWORD PTR [rbx-0x8]
   292cf:	4c 8b 43 f0          	mov    r8,QWORD PTR [rbx-0x10]
   292d3:	4c 89 d6             	mov    rsi,r10
   292d6:	4c 89 68 30          	mov    QWORD PTR [rax+0x30],r13
   292da:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   292e1:	6a 00                	push   0x0
   292e3:	e8 c8 3a 00 00       	call   2cdb0 <JS_GetPropertyInternal>
   292e8:	41 59                	pop    r9
   292ea:	41 5a                	pop    r10
   292ec:	83 fa 06             	cmp    edx,0x6
   292ef:	0f 85 15 f7 ff ff    	jne    28a0a <JS_CallInternal+0x5f2a>
   292f5:	4d 89 ec             	mov    r12,r13
   292f8:	e9 83 9f ff ff       	jmp    23280 <JS_CallInternal+0x7a0>
   292fd:	49 89 ca             	mov    r10,rcx
   29300:	48 c7 c7 ff ff ff ff 	mov    rdi,0xffffffffffffffff
   29307:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   2930e:	48 83 ec 08          	sub    rsp,0x8
   29312:	48 89 fa             	mov    rdx,rdi
   29315:	89 f1                	mov    ecx,esi
   29317:	4c 8b 43 f0          	mov    r8,QWORD PTR [rbx-0x10]
   2931b:	4c 8b 4b f8          	mov    r9,QWORD PTR [rbx-0x8]
   2931f:	4c 89 d6             	mov    rsi,r10
   29322:	4c 8d 6b f0          	lea    r13,[rbx-0x10]
   29326:	4c 89 70 30          	mov    QWORD PTR [rax+0x30],r14
   2932a:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   29331:	6a 00                	push   0x0
   29333:	e8 78 3a 00 00       	call   2cdb0 <JS_GetPropertyInternal>
   29338:	41 5b                	pop    r11
   2933a:	49 89 d0             	mov    r8,rdx
   2933d:	5a                   	pop    rdx
   2933e:	41 83 f8 06          	cmp    r8d,0x6
   29342:	0f 85 83 f9 ff ff    	jne    28ccb <JS_CallInternal+0x61eb>
   29348:	4d 89 f4             	mov    r12,r14
   2934b:	e9 30 9f ff ff       	jmp    23280 <JS_CallInternal+0x7a0>
   29350:	48 89 d6             	mov    rsi,rdx
   29353:	49 c7 c2 ff ff ff ff 	mov    r10,0xffffffffffffffff
   2935a:	48 83 ec 08          	sub    rsp,0x8
   2935e:	4c 8d 5b f0          	lea    r11,[rbx-0x10]
   29362:	4c 8b 43 f0          	mov    r8,QWORD PTR [rbx-0x10]
   29366:	4c 8b 4b f8          	mov    r9,QWORD PTR [rbx-0x8]
   2936a:	48 8b bd 50 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x1b0]
   29371:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   29378:	4c 89 9d 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],r11
   2937f:	4c 89 d2             	mov    rdx,r10
   29382:	48 89 78 30          	mov    QWORD PTR [rax+0x30],rdi
   29386:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2938d:	6a 00                	push   0x0
   2938f:	e8 1c 3a 00 00       	call   2cdb0 <JS_GetPropertyInternal>
   29394:	5f                   	pop    rdi
   29395:	4c 8b 9d 40 fe ff ff 	mov    r11,QWORD PTR [rbp-0x1c0]
   2939c:	83 fa 06             	cmp    edx,0x6
   2939f:	49 89 c5             	mov    r13,rax
   293a2:	49 89 d0             	mov    r8,rdx
   293a5:	41 59                	pop    r9
   293a7:	0f 85 1e ad ff ff    	jne    240cb <JS_CallInternal+0x15eb>
   293ad:	4c 8b a5 50 fe ff ff 	mov    r12,QWORD PTR [rbp-0x1b0]
   293b4:	e9 c7 9e ff ff       	jmp    23280 <JS_CallInternal+0x7a0>
   293b9:	48 89 fe             	mov    rsi,rdi
   293bc:	49 c7 c2 ff ff ff ff 	mov    r10,0xffffffffffffffff
   293c3:	48 83 ec 08          	sub    rsp,0x8
   293c7:	4c 8b 43 f0          	mov    r8,QWORD PTR [rbx-0x10]
   293cb:	4c 8b 4b f8          	mov    r9,QWORD PTR [rbx-0x8]
   293cf:	4c 89 d2             	mov    rdx,r10
   293d2:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   293d9:	4c 89 9d 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],r11
   293e0:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   293e7:	4c 89 58 30          	mov    QWORD PTR [rax+0x30],r11
   293eb:	6a 00                	push   0x0
   293ed:	e8 be 39 00 00       	call   2cdb0 <JS_GetPropertyInternal>
   293f2:	59                   	pop    rcx
   293f3:	4c 8b 9d 50 fe ff ff 	mov    r11,QWORD PTR [rbp-0x1b0]
   293fa:	83 fa 06             	cmp    edx,0x6
   293fd:	5e                   	pop    rsi
   293fe:	0f 85 f0 ab ff ff    	jne    23ff4 <JS_CallInternal+0x1514>
   29404:	4d 89 dc             	mov    r12,r11
   29407:	e9 74 9e ff ff       	jmp    23280 <JS_CallInternal+0x7a0>
   2940c:	4c 8b a5 50 fe ff ff 	mov    r12,QWORD PTR [rbp-0x1b0]
   29413:	e9 68 9e ff ff       	jmp    23280 <JS_CallInternal+0x7a0>
   29418:	48 8b 8d c8 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x138]
   2941f:	4c 89 71 30          	mov    QWORD PTR [rcx+0x30],r14
   29423:	83 fa f6             	cmp    edx,0xfffffff6
   29426:	76 04                	jbe    2942c <JS_CallInternal+0x694c>
   29428:	83 40 fc 01          	add    DWORD PTR [rax-0x4],0x1
   2942c:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   29433:	48 89 95 f8 fe ff ff 	mov    QWORD PTR [rbp-0x108],rdx
   2943a:	48 8d b5 00 ff ff ff 	lea    rsi,[rbp-0x100]
   29441:	ba 8c 00 00 00       	mov    edx,0x8c
   29446:	48 89 85 f0 fe ff ff 	mov    QWORD PTR [rbp-0x110],rax
   2944d:	e8 7e c1 02 00       	call   555d0 <js_unary_arith_slow>
   29452:	85 c0                	test   eax,eax
   29454:	0f 85 5b 37 00 00    	jne    2cbb5 <JS_CallInternal+0xa0d5>
   2945a:	49 8b 55 08          	mov    rdx,QWORD PTR [r13+0x8]
   2945e:	66 0f 6f a5 f0 fe ff 	movdqa xmm4,XMMWORD PTR [rbp-0x110]
   29465:	ff 
   29466:	49 8b 75 00          	mov    rsi,QWORD PTR [r13+0x0]
   2946a:	41 0f 11 65 00       	movups XMMWORD PTR [r13+0x0],xmm4
   2946f:	83 fa f6             	cmp    edx,0xfffffff6
   29472:	0f 86 7c dc ff ff    	jbe    270f4 <JS_CallInternal+0x4614>
   29478:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   2947b:	83 e8 01             	sub    eax,0x1
   2947e:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   29481:	85 c0                	test   eax,eax
   29483:	0f 8f 6b dc ff ff    	jg     270f4 <JS_CallInternal+0x4614>
   29489:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   29490:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   29494:	e8 07 34 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   29499:	e9 56 dc ff ff       	jmp    270f4 <JS_CallInternal+0x4614>
   2949e:	48 8b 8d c8 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x138]
   294a5:	4c 89 71 30          	mov    QWORD PTR [rcx+0x30],r14
   294a9:	83 fa f6             	cmp    edx,0xfffffff6
   294ac:	76 04                	jbe    294b2 <JS_CallInternal+0x69d2>
   294ae:	83 40 fc 01          	add    DWORD PTR [rax-0x4],0x1
   294b2:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   294b9:	48 89 95 f8 fe ff ff 	mov    QWORD PTR [rbp-0x108],rdx
   294c0:	48 8d b5 00 ff ff ff 	lea    rsi,[rbp-0x100]
   294c7:	ba 8d 00 00 00       	mov    edx,0x8d
   294cc:	48 89 85 f0 fe ff ff 	mov    QWORD PTR [rbp-0x110],rax
   294d3:	e8 f8 c0 02 00       	call   555d0 <js_unary_arith_slow>
   294d8:	85 c0                	test   eax,eax
   294da:	0f 85 57 38 00 00    	jne    2cd37 <JS_CallInternal+0xa257>
   294e0:	49 8b 55 08          	mov    rdx,QWORD PTR [r13+0x8]
   294e4:	66 0f 6f 9d f0 fe ff 	movdqa xmm3,XMMWORD PTR [rbp-0x110]
   294eb:	ff 
   294ec:	49 8b 75 00          	mov    rsi,QWORD PTR [r13+0x0]
   294f0:	41 0f 11 5d 00       	movups XMMWORD PTR [r13+0x0],xmm3
   294f5:	83 fa f6             	cmp    edx,0xfffffff6
   294f8:	0f 86 6a e3 ff ff    	jbe    27868 <JS_CallInternal+0x4d88>
   294fe:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   29501:	83 e8 01             	sub    eax,0x1
   29504:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   29507:	85 c0                	test   eax,eax
   29509:	0f 8f 59 e3 ff ff    	jg     27868 <JS_CallInternal+0x4d88>
   2950f:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   29516:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2951a:	e8 81 33 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2951f:	e9 44 e3 ff ff       	jmp    27868 <JS_CallInternal+0x4d88>
   29524:	85 c0                	test   eax,eax
   29526:	0f 84 bc b9 ff ff    	je     24ee8 <JS_CallInternal+0x2408>
   2952c:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   29533:	48 8b 73 f0          	mov    rsi,QWORD PTR [rbx-0x10]
   29537:	b9 01 00 00 00       	mov    ecx,0x1
   2953c:	48 8b 53 f8          	mov    rdx,QWORD PTR [rbx-0x8]
   29540:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   29547:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   2954b:	e8 b0 63 01 00       	call   3f900 <JS_ToStringInternal>
   29550:	48 89 c1             	mov    rcx,rax
   29553:	49 89 d5             	mov    r13,rdx
   29556:	83 fa 06             	cmp    edx,0x6
   29559:	0f 84 21 9d ff ff    	je     23280 <JS_CallInternal+0x7a0>
   2955f:	48 8b 53 f8          	mov    rdx,QWORD PTR [rbx-0x8]
   29563:	48 8b 73 f0          	mov    rsi,QWORD PTR [rbx-0x10]
   29567:	83 fa f6             	cmp    edx,0xfffffff6
   2956a:	76 11                	jbe    2957d <JS_CallInternal+0x6a9d>
   2956c:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   2956f:	83 e8 01             	sub    eax,0x1
   29572:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   29575:	85 c0                	test   eax,eax
   29577:	0f 8e 93 2b 00 00    	jle    2c110 <JS_CallInternal+0x9630>
   2957d:	48 89 4b f0          	mov    QWORD PTR [rbx-0x10],rcx
   29581:	4c 89 6b f8          	mov    QWORD PTR [rbx-0x8],r13
   29585:	e9 5e b9 ff ff       	jmp    24ee8 <JS_CallInternal+0x2408>
   2958a:	83 fa 08             	cmp    edx,0x8
   2958d:	0f 85 e8 0b 00 00    	jne    2a17b <JS_CallInternal+0x769b>
   29593:	66 48 0f 6e c0       	movq   xmm0,rax
   29598:	66 0f 57 05 00 15 0b 	xorpd  xmm0,XMMWORD PTR [rip+0xb1500]        # daaa0 <typed_array_size_log2+0x28>
   2959f:	00 
   295a0:	48 c7 43 f8 08 00 00 	mov    QWORD PTR [rbx-0x8],0x8
   295a7:	00 
   295a8:	f2 0f 11 43 f0       	movsd  QWORD PTR [rbx-0x10],xmm0
   295ad:	e9 d3 dd ff ff       	jmp    27385 <JS_CallInternal+0x48a5>
   295b2:	83 bd 88 fe ff ff f6 	cmp    DWORD PTR [rbp-0x178],0xfffffff6
   295b9:	0f 86 95 c0 ff ff    	jbe    25654 <JS_CallInternal+0x2b74>
   295bf:	e9 85 c0 ff ff       	jmp    25649 <JS_CallInternal+0x2b69>
   295c4:	0f 1f 40 00          	nop    DWORD PTR [rax+0x0]
   295c8:	45 85 ed             	test   r13d,r13d
   295cb:	0f 85 7e 2f 00 00    	jne    2c54f <JS_CallInternal+0x9a6f>
   295d1:	48 8b 53 e8          	mov    rdx,QWORD PTR [rbx-0x18]
   295d5:	48 8b 73 e0          	mov    rsi,QWORD PTR [rbx-0x20]
   295d9:	4c 8d 6b e0          	lea    r13,[rbx-0x20]
   295dd:	83 fa f6             	cmp    edx,0xfffffff6
   295e0:	76 11                	jbe    295f3 <JS_CallInternal+0x6b13>
   295e2:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   295e5:	83 e8 01             	sub    eax,0x1
   295e8:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   295eb:	85 c0                	test   eax,eax
   295ed:	0f 8e 2a 2a 00 00    	jle    2c01d <JS_CallInternal+0x953d>
   295f3:	48 8b 73 d0          	mov    rsi,QWORD PTR [rbx-0x30]
   295f7:	48 8b 53 d8          	mov    rdx,QWORD PTR [rbx-0x28]
   295fb:	b9 01 00 00 00       	mov    ecx,0x1
   29600:	4c 89 eb             	mov    rbx,r13
   29603:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2960a:	e8 61 79 00 00       	call   30f70 <JS_IteratorClose>
   2960f:	e9 09 9e ff ff       	jmp    2341d <JS_CallInternal+0x93d>
   29614:	48 8b 73 e0          	mov    rsi,QWORD PTR [rbx-0x20]
   29618:	48 8b 53 e8          	mov    rdx,QWORD PTR [rbx-0x18]
   2961c:	4c 89 e9             	mov    rcx,r13
   2961f:	4d 89 f0             	mov    r8,r14
   29622:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   29629:	41 b9 01 00 00 00    	mov    r9d,0x1
   2962f:	e8 9c 2e 01 00       	call   3c4d0 <JS_SetPrototypeInternal>
   29634:	85 c0                	test   eax,eax
   29636:	0f 89 7d db ff ff    	jns    271b9 <JS_CallInternal+0x46d9>
   2963c:	e9 3f 9c ff ff       	jmp    23280 <JS_CallInternal+0x7a0>
   29641:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]
   29648:	41 83 f8 08          	cmp    r8d,0x8
   2964c:	0f 85 5c 0a 00 00    	jne    2a0ae <JS_CallInternal+0x75ce>
   29652:	66 0f ef c0          	pxor   xmm0,xmm0
   29656:	66 49 0f 6e d1       	movq   xmm2,r9
   2965b:	ba 00 00 00 00       	mov    edx,0x0
   29660:	f2 41 0f 2a c6       	cvtsi2sd xmm0,r14d
   29665:	66 0f 2e c2          	ucomisd xmm0,xmm2
   29669:	0f 9b c0             	setnp  al
   2966c:	0f 45 c2             	cmovne eax,edx
   2966f:	e9 e1 d2 ff ff       	jmp    26955 <JS_CallInternal+0x3e75>
   29674:	41 83 f8 08          	cmp    r8d,0x8
   29678:	0f 85 62 0a 00 00    	jne    2a0e0 <JS_CallInternal+0x7600>
   2967e:	66 0f ef c0          	pxor   xmm0,xmm0
   29682:	66 49 0f 6e f9       	movq   xmm7,r9
   29687:	31 c0                	xor    eax,eax
   29689:	f2 41 0f 2a c6       	cvtsi2sd xmm0,r14d
   2968e:	66 0f 2e c7          	ucomisd xmm0,xmm7
   29692:	0f 9b c0             	setnp  al
   29695:	41 0f 45 c5          	cmovne eax,r13d
   29699:	e9 57 d2 ff ff       	jmp    268f5 <JS_CallInternal+0x3e15>
   2969e:	41 83 fe 08          	cmp    r14d,0x8
   296a2:	0f 85 7c 0b 00 00    	jne    2a224 <JS_CallInternal+0x7744>
   296a8:	66 0f ef c0          	pxor   xmm0,xmm0
   296ac:	66 49 0f 6e f5       	movq   xmm6,r13
   296b1:	31 c0                	xor    eax,eax
   296b3:	f2 0f 2a c2          	cvtsi2sd xmm0,edx
   296b7:	ba 01 00 00 00       	mov    edx,0x1
   296bc:	66 0f 2e c6          	ucomisd xmm0,xmm6
   296c0:	0f 9a c0             	setp   al
   296c3:	48 0f 45 c2          	cmovne rax,rdx
   296c7:	e9 73 e2 ff ff       	jmp    2793f <JS_CallInternal+0x4e5f>
   296cc:	41 83 fe 08          	cmp    r14d,0x8
   296d0:	0f 85 72 0b 00 00    	jne    2a248 <JS_CallInternal+0x7768>
   296d6:	66 0f ef c0          	pxor   xmm0,xmm0
   296da:	66 49 0f 6e dd       	movq   xmm3,r13
   296df:	31 c0                	xor    eax,eax
   296e1:	f2 0f 2a c2          	cvtsi2sd xmm0,edx
   296e5:	ba 00 00 00 00       	mov    edx,0x0
   296ea:	66 0f 2e c3          	ucomisd xmm0,xmm3
   296ee:	0f 9b c0             	setnp  al
   296f1:	48 0f 45 c2          	cmovne rax,rdx
   296f5:	e9 99 e2 ff ff       	jmp    27993 <JS_CallInternal+0x4eb3>
   296fa:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   29701:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   29705:	e8 96 31 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2970a:	e9 9d b6 ff ff       	jmp    24dac <JS_CallInternal+0x22cc>
   2970f:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   29716:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2971d:	44 89 ea             	mov    edx,r13d
   29720:	48 89 de             	mov    rsi,rbx
   29723:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   29727:	e8 a4 be 02 00       	call   555d0 <js_unary_arith_slow>
   2972c:	85 c0                	test   eax,eax
   2972e:	0f 84 09 dc ff ff    	je     2733d <JS_CallInternal+0x485d>
   29734:	e9 47 9b ff ff       	jmp    23280 <JS_CallInternal+0x7a0>
   29739:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]
   29740:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   29747:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2974e:	44 89 ea             	mov    edx,r13d
   29751:	48 89 de             	mov    rsi,rbx
   29754:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   29758:	e8 13 c3 02 00       	call   55a70 <js_post_inc_slow>
   2975d:	85 c0                	test   eax,eax
   2975f:	0f 84 44 e1 ff ff    	je     278a9 <JS_CallInternal+0x4dc9>
   29765:	e9 16 9b ff ff       	jmp    23280 <JS_CallInternal+0x7a0>
   2976a:	66 0f 1f 44 00 00    	nop    WORD PTR [rax+rax*1+0x0]
   29770:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   29777:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2977e:	44 89 ea             	mov    edx,r13d
   29781:	48 89 de             	mov    rsi,rbx
   29784:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   29788:	e8 43 be 02 00       	call   555d0 <js_unary_arith_slow>
   2978d:	85 c0                	test   eax,eax
   2978f:	0f 84 7a d4 ff ff    	je     26c0f <JS_CallInternal+0x412f>
   29795:	e9 e6 9a ff ff       	jmp    23280 <JS_CallInternal+0x7a0>
   2979a:	66 0f 1f 44 00 00    	nop    WORD PTR [rax+rax*1+0x0]
   297a0:	41 83 e6 02          	and    r14d,0x2
   297a4:	48 8d 4b c0          	lea    rcx,[rbx-0x40]
   297a8:	48 8b 73 c0          	mov    rsi,QWORD PTR [rbx-0x40]
   297ac:	4c 8b 41 08          	mov    r8,QWORD PTR [rcx+0x8]
   297b0:	0f 84 eb 0b 00 00    	je     2a3a1 <JS_CallInternal+0x78c1>
   297b6:	48 83 ec 08          	sub    rsp,0x8
   297ba:	45 31 c9             	xor    r9d,r9d
   297bd:	6a 00                	push   0x0
   297bf:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   297c6:	48 89 f1             	mov    rcx,rsi
   297c9:	48 89 c6             	mov    rsi,rax
   297cc:	e8 6f 35 00 00       	call   2cd40 <JS_CallFree>
   297d1:	41 5a                	pop    r10
   297d3:	41 5b                	pop    r11
   297d5:	48 89 c1             	mov    rcx,rax
   297d8:	49 89 d6             	mov    r14,rdx
   297db:	83 fa 06             	cmp    edx,0x6
   297de:	0f 84 4d 0c 00 00    	je     2a431 <JS_CallInternal+0x7951>
   297e4:	48 8b 53 f8          	mov    rdx,QWORD PTR [rbx-0x8]
   297e8:	48 8b 73 f0          	mov    rsi,QWORD PTR [rbx-0x10]
   297ec:	83 fa f6             	cmp    edx,0xfffffff6
   297ef:	76 11                	jbe    29802 <JS_CallInternal+0x6d22>
   297f1:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   297f4:	83 e8 01             	sub    eax,0x1
   297f7:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   297fa:	85 c0                	test   eax,eax
   297fc:	0f 8e 92 29 00 00    	jle    2c194 <JS_CallInternal+0x96b4>
   29802:	48 89 4b f0          	mov    QWORD PTR [rbx-0x10],rcx
   29806:	31 c9                	xor    ecx,ecx
   29808:	4c 89 73 f8          	mov    QWORD PTR [rbx-0x8],r14
   2980c:	e9 3a e5 ff ff       	jmp    27d4b <JS_CallInternal+0x526b>
   29811:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   29818:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2981f:	44 89 ea             	mov    edx,r13d
   29822:	48 89 de             	mov    rsi,rbx
   29825:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   29829:	e8 42 c2 02 00       	call   55a70 <js_post_inc_slow>
   2982e:	85 c0                	test   eax,eax
   29830:	0f 84 94 d3 ff ff    	je     26bca <JS_CallInternal+0x40ea>
   29836:	e9 45 9a ff ff       	jmp    23280 <JS_CallInternal+0x7a0>
   2983b:	0f 1f 44 00 00       	nop    DWORD PTR [rax+rax*1+0x0]
   29840:	48 8b 73 e0          	mov    rsi,QWORD PTR [rbx-0x20]
   29844:	48 8b 53 e8          	mov    rdx,QWORD PTR [rbx-0x18]
   29848:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2984f:	e8 8c 9c 01 00       	call   434e0 <JS_ValueToAtom>
   29854:	89 85 50 fe ff ff    	mov    DWORD PTR [rbp-0x1b0],eax
   2985a:	85 c0                	test   eax,eax
   2985c:	0f 84 1e 9a ff ff    	je     23280 <JS_CallInternal+0x7a0>
   29862:	4d 89 e5             	mov    r13,r12
   29865:	e9 a4 9f ff ff       	jmp    2380e <JS_CallInternal+0xd2e>
   2986a:	66 0f ef c0          	pxor   xmm0,xmm0
   2986e:	f2 48 0f 2a c0       	cvtsi2sd xmm0,rax
   29873:	b8 08 00 00 00       	mov    eax,0x8
   29878:	e9 b2 cf ff ff       	jmp    2682f <JS_CallInternal+0x3d4f>
   2987d:	4c 89 c6             	mov    rsi,r8
   29880:	48 89 df             	mov    rdi,rbx
   29883:	48 89 8d 10 fe ff ff 	mov    QWORD PTR [rbp-0x1f0],rcx
   2988a:	4c 89 85 28 fe ff ff 	mov    QWORD PTR [rbp-0x1d8],r8
   29891:	e8 2a 23 01 00       	call   3bbc0 <expand_fast_array>
   29896:	4c 8b 85 28 fe ff ff 	mov    r8,QWORD PTR [rbp-0x1d8]
   2989d:	48 8b 8d 10 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x1f0]
   298a4:	85 c0                	test   eax,eax
   298a6:	0f 88 87 28 00 00    	js     2c133 <JS_CallInternal+0x9653>
   298ac:	8b 85 50 fe ff ff    	mov    eax,DWORD PTR [rbp-0x1b0]
   298b2:	41 89 40 38          	mov    DWORD PTR [r8+0x38],eax
   298b6:	31 c0                	xor    eax,eax
   298b8:	0f 1f 84 00 00 00 00 	nop    DWORD PTR [rax+rax*1+0x0]
   298bf:	00 
   298c0:	f3 41 0f 6f 5c 05 00 	movdqu xmm3,XMMWORD PTR [r13+rax*1+0x0]
   298c7:	49 8b 50 30          	mov    rdx,QWORD PTR [r8+0x30]
   298cb:	0f 11 1c 02          	movups XMMWORD PTR [rdx+rax*1],xmm3
   298cf:	48 83 c0 10          	add    rax,0x10
   298d3:	4c 39 f0             	cmp    rax,r14
   298d6:	75 e8                	jne    298c0 <JS_CallInternal+0x6de0>
   298d8:	49 8b 40 20          	mov    rax,QWORD PTR [r8+0x20]
   298dc:	48 8b 9d 40 fe ff ff 	mov    rbx,QWORD PTR [rbp-0x1c0]
   298e3:	48 8b 50 08          	mov    rdx,QWORD PTR [rax+0x8]
   298e7:	48 8b 30             	mov    rsi,QWORD PTR [rax]
   298ea:	48 c7 40 08 00 00 00 	mov    QWORD PTR [rax+0x8],0x0
   298f1:	00 
   298f2:	48 89 18             	mov    QWORD PTR [rax],rbx
   298f5:	83 fa f6             	cmp    edx,0xfffffff6
   298f8:	0f 86 2d a6 ff ff    	jbe    23f2b <JS_CallInternal+0x144b>
   298fe:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   29901:	83 e8 01             	sub    eax,0x1
   29904:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   29907:	85 c0                	test   eax,eax
   29909:	0f 8f 1c a6 ff ff    	jg     23f2b <JS_CallInternal+0x144b>
   2990f:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   29916:	48 89 8d 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],rcx
   2991d:	4c 89 85 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],r8
   29924:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   29928:	e8 73 2f ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2992d:	48 8b 8d 40 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x1c0]
   29934:	4c 8b 85 50 fe ff ff 	mov    r8,QWORD PTR [rbp-0x1b0]
   2993b:	e9 eb a5 ff ff       	jmp    23f2b <JS_CallInternal+0x144b>
   29940:	48 8b bd d8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x128]
   29947:	48 03 77 30          	add    rsi,QWORD PTR [rdi+0x30]
   2994b:	80 7a 11 00          	cmp    BYTE PTR [rdx+0x11],0x0
   2994f:	0f 84 bd 11 00 00    	je     2ab12 <JS_CallInternal+0x8032>
   29955:	41 83 fd 3a          	cmp    r13d,0x3a
   29959:	0f 84 e2 9d ff ff    	je     23741 <JS_CallInternal+0xc61>
   2995f:	8b 76 04             	mov    esi,DWORD PTR [rsi+0x4]
   29962:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   29969:	83 f9 04             	cmp    ecx,0x4
   2996c:	0f 84 53 32 00 00    	je     2cbc5 <JS_CallInternal+0xa0e5>
   29972:	e8 69 87 00 00       	call   320e0 <JS_ThrowTypeErrorReadOnly.part.0>
   29977:	4d 89 f4             	mov    r12,r14
   2997a:	e9 01 99 ff ff       	jmp    23280 <JS_CallInternal+0x7a0>
   2997f:	90                   	nop
   29980:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   29987:	48 89 fa             	mov    rdx,rdi
   2998a:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   29991:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   29995:	e8 86 3a 00 00       	call   2d420 <JS_GetPropertyValue>
   2999a:	48 89 c1             	mov    rcx,rax
   2999d:	48 89 d0             	mov    rax,rdx
   299a0:	83 fa 06             	cmp    edx,0x6
   299a3:	0f 85 31 bd ff ff    	jne    256da <JS_CallInternal+0x2bfa>
   299a9:	48 83 eb 10          	sub    rbx,0x10
   299ad:	e9 ce 98 ff ff       	jmp    23280 <JS_CallInternal+0x7a0>
   299b2:	31 c0                	xor    eax,eax
   299b4:	e9 e8 ca ff ff       	jmp    264a1 <JS_CallInternal+0x39c1>
   299b9:	48 8b 8d 50 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x1b0]
   299c0:	4d 89 f0             	mov    r8,r14
   299c3:	4c 89 ce             	mov    rsi,r9
   299c6:	4c 89 ea             	mov    rdx,r13
   299c9:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   299d0:	4c 89 8d 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],r9
   299d7:	e8 c4 78 00 00       	call   312a0 <JS_CheckBrand>
   299dc:	85 c0                	test   eax,eax
   299de:	0f 88 9c 98 ff ff    	js     23280 <JS_CallInternal+0x7a0>
   299e4:	4c 8b 8d 40 fe ff ff 	mov    r9,QWORD PTR [rbp-0x1c0]
   299eb:	0f 95 c0             	setne  al
   299ee:	e9 82 d3 ff ff       	jmp    26d75 <JS_CallInternal+0x4295>
   299f3:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   299fa:	48 8d 7b f0          	lea    rdi,[rbx-0x10]
   299fe:	41 b9 00 80 00 00    	mov    r9d,0x8000
   29a04:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   29a08:	48 8d 43 e0          	lea    rax,[rbx-0x20]
   29a0c:	4c 8b 40 08          	mov    r8,QWORD PTR [rax+0x8]
   29a10:	48 83 eb 30          	sub    rbx,0x30
   29a14:	48 8b 33             	mov    rsi,QWORD PTR [rbx]
   29a17:	48 8b 53 08          	mov    rdx,QWORD PTR [rbx+0x8]
   29a1b:	48 8b 08             	mov    rcx,QWORD PTR [rax]
   29a1e:	ff 77 08             	push   QWORD PTR [rdi+0x8]
   29a21:	ff 37                	push   QWORD PTR [rdi]
   29a23:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   29a2a:	e8 c1 4d 00 00       	call   2e7f0 <JS_SetPropertyValue>
   29a2f:	48 8b 53 08          	mov    rdx,QWORD PTR [rbx+0x8]
   29a33:	5f                   	pop    rdi
   29a34:	48 8b 33             	mov    rsi,QWORD PTR [rbx]
   29a37:	41 89 c5             	mov    r13d,eax
   29a3a:	41 58                	pop    r8
   29a3c:	83 fa f6             	cmp    edx,0xfffffff6
   29a3f:	76 11                	jbe    29a52 <JS_CallInternal+0x6f72>
   29a41:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   29a44:	83 e8 01             	sub    eax,0x1
   29a47:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   29a4a:	85 c0                	test   eax,eax
   29a4c:	0f 8e 4f 25 00 00    	jle    2bfa1 <JS_CallInternal+0x94c1>
   29a52:	45 85 ed             	test   r13d,r13d
   29a55:	0f 89 d2 e6 ff ff    	jns    2812d <JS_CallInternal+0x564d>
   29a5b:	e9 20 98 ff ff       	jmp    23280 <JS_CallInternal+0x7a0>
   29a60:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   29a67:	48 89 ca             	mov    rdx,rcx
   29a6a:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   29a6e:	4c 89 c0             	mov    rax,r8
   29a71:	49 89 f8             	mov    r8,rdi
   29a74:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   29a7b:	48 89 c1             	mov    rcx,rax
   29a7e:	e8 9d 39 00 00       	call   2d420 <JS_GetPropertyValue>
   29a83:	48 89 c1             	mov    rcx,rax
   29a86:	48 89 d0             	mov    rax,rdx
   29a89:	48 89 ca             	mov    rdx,rcx
   29a8c:	83 f8 06             	cmp    eax,0x6
   29a8f:	0f 85 20 e4 ff ff    	jne    27eb5 <JS_CallInternal+0x53d5>
   29a95:	45 31 c0             	xor    r8d,r8d
   29a98:	48 c7 43 f8 03 00 00 	mov    QWORD PTR [rbx-0x8],0x3
   29a9f:	00 
   29aa0:	4c 89 43 f0          	mov    QWORD PTR [rbx-0x10],r8
   29aa4:	e9 d7 97 ff ff       	jmp    23280 <JS_CallInternal+0x7a0>
   29aa9:	31 c9                	xor    ecx,ecx
   29aab:	41 b8 03 00 00 00    	mov    r8d,0x3
   29ab1:	e9 0d a9 ff ff       	jmp    243c3 <JS_CallInternal+0x18e3>
   29ab6:	8b 00                	mov    eax,DWORD PTR [rax]
   29ab8:	25 ff ff ff 03       	and    eax,0x3ffffff
   29abd:	0f 85 fc 97 ff ff    	jne    232bf <JS_CallInternal+0x7df>
   29ac3:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   29aca:	48 83 ec 08          	sub    rsp,0x8
   29ace:	31 c9                	xor    ecx,ecx
   29ad0:	45 31 c9             	xor    r9d,r9d
   29ad3:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   29ada:	45 31 c0             	xor    r8d,r8d
   29add:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   29ae1:	48 8b 85 c0 fe ff ff 	mov    rax,QWORD PTR [rbp-0x140]
   29ae8:	48 8b b0 d8 04 00 00 	mov    rsi,QWORD PTR [rax+0x4d8]
   29aef:	48 8b 90 e0 04 00 00 	mov    rdx,QWORD PTR [rax+0x4e0]
   29af6:	6a 00                	push   0x0
   29af8:	e8 63 64 00 00       	call   2ff60 <build_backtrace>
   29afd:	59                   	pop    rcx
   29afe:	5e                   	pop    rsi
   29aff:	e9 cc 97 ff ff       	jmp    232d0 <JS_CallInternal+0x7f0>
   29b04:	41 8b 30             	mov    esi,DWORD PTR [r8]
   29b07:	81 e6 ff ff ff 03    	and    esi,0x3ffffff
   29b0d:	0f 85 73 dc ff ff    	jne    27786 <JS_CallInternal+0x4ca6>
   29b13:	48 83 ec 08          	sub    rsp,0x8
   29b17:	4c 8b 43 f0          	mov    r8,QWORD PTR [rbx-0x10]
   29b1b:	4c 8b 4b f8          	mov    r9,QWORD PTR [rbx-0x8]
   29b1f:	48 89 c6             	mov    rsi,rax
   29b22:	48 8b bd c8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x138]
   29b29:	4c 89 95 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],r10
   29b30:	4c 89 57 30          	mov    QWORD PTR [rdi+0x30],r10
   29b34:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   29b3b:	68 00 80 00 00       	push   0x8000
   29b40:	52                   	push   rdx
   29b41:	50                   	push   rax
   29b42:	e8 99 3f 00 00       	call   2dae0 <JS_SetPropertyInternal>
   29b47:	48 83 c4 20          	add    rsp,0x20
   29b4b:	41 83 fe f6          	cmp    r14d,0xfffffff6
   29b4f:	4c 8b 95 50 fe ff ff 	mov    r10,QWORD PTR [rbp-0x1b0]
   29b56:	89 c1                	mov    ecx,eax
   29b58:	76 13                	jbe    29b6d <JS_CallInternal+0x708d>
   29b5a:	41 8b 45 fc          	mov    eax,DWORD PTR [r13-0x4]
   29b5e:	83 e8 01             	sub    eax,0x1
   29b61:	41 89 45 fc          	mov    DWORD PTR [r13-0x4],eax
   29b65:	85 c0                	test   eax,eax
   29b67:	0f 8e 75 25 00 00    	jle    2c0e2 <JS_CallInternal+0x9602>
   29b6d:	48 83 eb 20          	sub    rbx,0x20
   29b71:	85 c9                	test   ecx,ecx
   29b73:	0f 89 83 dc ff ff    	jns    277fc <JS_CallInternal+0x4d1c>
   29b79:	4d 89 d4             	mov    r12,r10
   29b7c:	e9 ff 96 ff ff       	jmp    23280 <JS_CallInternal+0x7a0>
   29b81:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   29b88:	48 89 ce             	mov    rsi,rcx
   29b8b:	e8 40 4f ff ff       	call   1ead0 <JS_ToBoolFree>
   29b90:	e9 18 db ff ff       	jmp    276ad <JS_CallInternal+0x4bcd>
   29b95:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   29b9c:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   29ba3:	48 89 de             	mov    rsi,rbx
   29ba6:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   29baa:	e8 31 bf 02 00       	call   55ae0 <js_not_slow>
   29baf:	85 c0                	test   eax,eax
   29bb1:	0f 84 d2 d4 ff ff    	je     27089 <JS_CallInternal+0x45a9>
   29bb7:	e9 c4 96 ff ff       	jmp    23280 <JS_CallInternal+0x7a0>
   29bbc:	0f 1f 40 00          	nop    DWORD PTR [rax+0x0]
   29bc0:	49 8b 75 f0          	mov    rsi,QWORD PTR [r13-0x10]
   29bc4:	49 8b 55 f8          	mov    rdx,QWORD PTR [r13-0x8]
   29bc8:	41 b8 03 00 00 00    	mov    r8d,0x3
   29bce:	31 c9                	xor    ecx,ecx
   29bd0:	44 8b 8d 50 fe ff ff 	mov    r9d,DWORD PTR [rbp-0x1b0]
   29bd7:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   29bde:	48 c7 85 90 fd ff ff 	mov    QWORD PTR [rbp-0x270],0x0
   29be5:	00 00 00 00 
   29be9:	48 c7 85 98 fd ff ff 	mov    QWORD PTR [rbp-0x268],0x3
   29bf0:	03 00 00 00 
   29bf4:	6a 00                	push   0x0
   29bf6:	41 55                	push   r13
   29bf8:	ff b5 98 fd ff ff    	push   QWORD PTR [rbp-0x268]
   29bfe:	ff b5 90 fd ff ff    	push   QWORD PTR [rbp-0x270]
   29c04:	e8 d7 8e ff ff       	call   22ae0 <JS_CallInternal>
   29c09:	48 83 c4 20          	add    rsp,0x20
   29c0d:	49 89 c1             	mov    r9,rax
   29c10:	49 89 d0             	mov    r8,rdx
   29c13:	e9 db a7 ff ff       	jmp    243f3 <JS_CallInternal+0x1913>
   29c18:	31 c9                	xor    ecx,ecx
   29c1a:	41 b8 03 00 00 00    	mov    r8d,0x3
   29c20:	e9 54 a6 ff ff       	jmp    24279 <JS_CallInternal+0x1799>
   29c25:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   29c2c:	48 89 ce             	mov    rsi,rcx
   29c2f:	e8 9c 4e ff ff       	call   1ead0 <JS_ToBoolFree>
   29c34:	e9 8b e5 ff ff       	jmp    281c4 <JS_CallInternal+0x56e4>
   29c39:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   29c40:	48 89 ce             	mov    rsi,rcx
   29c43:	e8 88 4e ff ff       	call   1ead0 <JS_ToBoolFree>
   29c48:	e9 10 e5 ff ff       	jmp    2815d <JS_CallInternal+0x567d>
   29c4d:	48 8b b5 28 fe ff ff 	mov    rsi,QWORD PTR [rbp-0x1d8]
   29c54:	45 89 d1             	mov    r9d,r10d
   29c57:	4c 89 ea             	mov    rdx,r13
   29c5a:	31 c9                	xor    ecx,ecx
   29c5c:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   29c63:	41 b8 03 00 00 00    	mov    r8d,0x3
   29c69:	48 c7 85 a0 fd ff ff 	mov    QWORD PTR [rbp-0x260],0x0
   29c70:	00 00 00 00 
   29c74:	48 c7 85 a8 fd ff ff 	mov    QWORD PTR [rbp-0x258],0x3
   29c7b:	03 00 00 00 
   29c7f:	6a 02                	push   0x2
   29c81:	41 56                	push   r14
   29c83:	ff b5 a8 fd ff ff    	push   QWORD PTR [rbp-0x258]
   29c89:	ff b5 a0 fd ff ff    	push   QWORD PTR [rbp-0x260]
   29c8f:	44 89 95 38 fe ff ff 	mov    DWORD PTR [rbp-0x1c8],r10d
   29c96:	e8 45 8e ff ff       	call   22ae0 <JS_CallInternal>
   29c9b:	44 8b 95 38 fe ff ff 	mov    r10d,DWORD PTR [rbp-0x1c8]
   29ca2:	48 83 c4 20          	add    rsp,0x20
   29ca6:	48 89 85 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],rax
   29cad:	49 89 d5             	mov    r13,rdx
   29cb0:	e9 06 a6 ff ff       	jmp    242bb <JS_CallInternal+0x17db>
   29cb5:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   29cbc:	48 89 ce             	mov    rsi,rcx
   29cbf:	e8 0c 4e ff ff       	call   1ead0 <JS_ToBoolFree>
   29cc4:	e9 b6 eb ff ff       	jmp    2887f <JS_CallInternal+0x5d9f>
   29cc9:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   29cd0:	48 89 d6             	mov    rsi,rdx
   29cd3:	48 89 c2             	mov    rdx,rax
   29cd6:	e8 f5 4d ff ff       	call   1ead0 <JS_ToBoolFree>
   29cdb:	e9 df df ff ff       	jmp    27cbf <JS_CallInternal+0x51df>
   29ce0:	4d 39 2e             	cmp    QWORD PTR [r14],r13
   29ce3:	0f 85 6a a3 ff ff    	jne    24053 <JS_CallInternal+0x1573>
   29ce9:	41 8b 46 08          	mov    eax,DWORD PTR [r14+0x8]
   29ced:	83 f8 ff             	cmp    eax,0xffffffff
   29cf0:	0f 84 5d a3 ff ff    	je     24053 <JS_CallInternal+0x1573>
   29cf6:	48 c1 e0 04          	shl    rax,0x4
   29cfa:	48 03 46 20          	add    rax,QWORD PTR [rsi+0x20]
   29cfe:	4c 8b 40 08          	mov    r8,QWORD PTR [rax+0x8]
   29d02:	4c 8b 28             	mov    r13,QWORD PTR [rax]
   29d05:	41 83 f8 f6          	cmp    r8d,0xfffffff6
   29d09:	76 05                	jbe    29d10 <JS_CallInternal+0x7230>
   29d0b:	41 83 45 fc 01       	add    DWORD PTR [r13-0x4],0x1
   29d10:	4c 8d 5b f0          	lea    r11,[rbx-0x10]
   29d14:	e9 b2 a3 ff ff       	jmp    240cb <JS_CallInternal+0x15eb>
   29d19:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   29d20:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   29d24:	89 c8                	mov    eax,ecx
   29d26:	48 8b 97 48 04 00 00 	mov    rdx,QWORD PTR [rdi+0x448]
   29d2d:	48 8b 34 c2          	mov    rsi,QWORD PTR [rdx+rax*8]
   29d31:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   29d34:	83 e8 01             	sub    eax,0x1
   29d37:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   29d3a:	85 c0                	test   eax,eax
   29d3c:	0f 8f 1e d1 ff ff    	jg     26e60 <JS_CallInternal+0x4380>
   29d42:	44 89 85 38 fe ff ff 	mov    DWORD PTR [rbp-0x1c8],r8d
   29d49:	e8 b2 b6 fe ff       	call   15400 <JS_FreeAtomStruct>
   29d4e:	44 8b 85 38 fe ff ff 	mov    r8d,DWORD PTR [rbp-0x1c8]
   29d55:	e9 06 d1 ff ff       	jmp    26e60 <JS_CallInternal+0x4380>
   29d5a:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   29d61:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   29d65:	48 8b 87 48 04 00 00 	mov    rax,QWORD PTR [rdi+0x448]
   29d6c:	4a 8b 34 e8          	mov    rsi,QWORD PTR [rax+r13*8]
   29d70:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   29d73:	83 e8 01             	sub    eax,0x1
   29d76:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   29d79:	85 c0                	test   eax,eax
   29d7b:	0f 8f 08 ea ff ff    	jg     28789 <JS_CallInternal+0x5ca9>
   29d81:	e8 7a b6 fe ff       	call   15400 <JS_FreeAtomStruct>
   29d86:	4c 8b 95 40 fe ff ff 	mov    r10,QWORD PTR [rbp-0x1c0]
   29d8d:	e9 f7 e9 ff ff       	jmp    28789 <JS_CallInternal+0x5ca9>
   29d92:	48 8b 8d e8 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x118]
   29d99:	48 8b 79 10          	mov    rdi,QWORD PTR [rcx+0x10]
   29d9d:	48 8b 97 48 04 00 00 	mov    rdx,QWORD PTR [rdi+0x448]
   29da4:	4a 8b 34 ea          	mov    rsi,QWORD PTR [rdx+r13*8]
   29da8:	8b 4e fc             	mov    ecx,DWORD PTR [rsi-0x4]
   29dab:	8d 51 ff             	lea    edx,[rcx-0x1]
   29dae:	89 56 fc             	mov    DWORD PTR [rsi-0x4],edx
   29db1:	85 d2                	test   edx,edx
   29db3:	0f 8f a5 e1 ff ff    	jg     27f5e <JS_CallInternal+0x547e>
   29db9:	48 89 85 28 fe ff ff 	mov    QWORD PTR [rbp-0x1d8],rax
   29dc0:	e8 3b b6 fe ff       	call   15400 <JS_FreeAtomStruct>
   29dc5:	48 8b 85 28 fe ff ff 	mov    rax,QWORD PTR [rbp-0x1d8]
   29dcc:	4c 8b 95 38 fe ff ff 	mov    r10,QWORD PTR [rbp-0x1c8]
   29dd3:	e9 86 e1 ff ff       	jmp    27f5e <JS_CallInternal+0x547e>
   29dd8:	41 83 fd fa          	cmp    r13d,0xfffffffa
   29ddc:	0f 8d 81 22 00 00    	jge    2c063 <JS_CallInternal+0x9583>
   29de2:	41 83 fd f8          	cmp    r13d,0xfffffff8
   29de6:	7d 65                	jge    29e4d <JS_CallInternal+0x736d>
   29de8:	83 e8 02             	sub    eax,0x2
   29deb:	83 f8 01             	cmp    eax,0x1
   29dee:	0f 86 ed 23 00 00    	jbe    2c1e1 <JS_CallInternal+0x9701>
   29df4:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   29dfb:	48 8b 73 f0          	mov    rsi,QWORD PTR [rbx-0x10]
   29dff:	b9 01 00 00 00       	mov    ecx,0x1
   29e04:	48 8b 53 f8          	mov    rdx,QWORD PTR [rbx-0x8]
   29e08:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   29e0f:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   29e13:	e8 e8 5a 01 00       	call   3f900 <JS_ToStringInternal>
   29e18:	49 89 d0             	mov    r8,rdx
   29e1b:	49 89 d5             	mov    r13,rdx
   29e1e:	83 fa 06             	cmp    edx,0x6
   29e21:	0f 84 59 94 ff ff    	je     23280 <JS_CallInternal+0x7a0>
   29e27:	48 8b 53 f8          	mov    rdx,QWORD PTR [rbx-0x8]
   29e2b:	48 8b 73 f0          	mov    rsi,QWORD PTR [rbx-0x10]
   29e2f:	83 fa f6             	cmp    edx,0xfffffff6
   29e32:	76 11                	jbe    29e45 <JS_CallInternal+0x7365>
   29e34:	8b 4e fc             	mov    ecx,DWORD PTR [rsi-0x4]
   29e37:	83 e9 01             	sub    ecx,0x1
   29e3a:	89 4e fc             	mov    DWORD PTR [rsi-0x4],ecx
   29e3d:	85 c9                	test   ecx,ecx
   29e3f:	0f 8e 3a 26 00 00    	jle    2c47f <JS_CallInternal+0x999f>
   29e45:	48 89 43 f0          	mov    QWORD PTR [rbx-0x10],rax
   29e49:	4c 89 43 f8          	mov    QWORD PTR [rbx-0x8],r8
   29e4d:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   29e54:	48 8b 4b f0          	mov    rcx,QWORD PTR [rbx-0x10]
   29e58:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   29e5c:	41 83 fd f6          	cmp    r13d,0xfffffff6
   29e60:	76 04                	jbe    29e66 <JS_CallInternal+0x7386>
   29e62:	83 41 fc 01          	add    DWORD PTR [rcx-0x4],0x1
   29e66:	48 8b 73 e0          	mov    rsi,QWORD PTR [rbx-0x20]
   29e6a:	48 8b 53 e8          	mov    rdx,QWORD PTR [rbx-0x18]
   29e6e:	4d 89 e8             	mov    r8,r13
   29e71:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   29e78:	e8 a3 35 00 00       	call   2d420 <JS_GetPropertyValue>
   29e7d:	48 89 c1             	mov    rcx,rax
   29e80:	48 89 d0             	mov    rax,rdx
   29e83:	83 fa 06             	cmp    edx,0x6
   29e86:	0f 85 b5 df ff ff    	jne    27e41 <JS_CallInternal+0x5361>
   29e8c:	e9 ef 93 ff ff       	jmp    23280 <JS_CallInternal+0x7a0>
   29e91:	8b 08                	mov    ecx,DWORD PTR [rax]
   29e93:	81 e1 ff ff ff 03    	and    ecx,0x3ffffff
   29e99:	0f 85 12 b1 ff ff    	jne    24fb1 <JS_CallInternal+0x24d1>
   29e9f:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   29ea6:	44 89 f1             	mov    ecx,r14d
   29ea9:	48 8b b7 80 01 00 00 	mov    rsi,QWORD PTR [rdi+0x180]
   29eb0:	48 8b 97 88 01 00 00 	mov    rdx,QWORD PTR [rdi+0x188]
   29eb7:	e8 04 43 04 00       	call   6e1c0 <JS_HasProperty>
   29ebc:	85 c0                	test   eax,eax
   29ebe:	0f 88 43 2e 00 00    	js     2cd07 <JS_CallInternal+0xa227>
   29ec4:	b8 01 00 00 00       	mov    eax,0x1
   29ec9:	0f 84 f5 b0 ff ff    	je     24fc4 <JS_CallInternal+0x24e4>
   29ecf:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   29ed6:	45 31 c0             	xor    r8d,r8d
   29ed9:	44 89 f1             	mov    ecx,r14d
   29edc:	48 8b b7 80 01 00 00 	mov    rsi,QWORD PTR [rdi+0x180]
   29ee3:	48 8b 97 88 01 00 00 	mov    rdx,QWORD PTR [rdi+0x188]
   29eea:	e8 a1 10 02 00       	call   4af90 <JS_DeleteProperty>
   29eef:	85 c0                	test   eax,eax
   29ef1:	0f 88 4d 24 00 00    	js     2c344 <JS_CallInternal+0x9864>
   29ef7:	0f 95 c0             	setne  al
   29efa:	0f b6 c0             	movzx  eax,al
   29efd:	e9 c2 b0 ff ff       	jmp    24fc4 <JS_CallInternal+0x24e4>
   29f02:	4d 39 2e             	cmp    QWORD PTR [r14],r13
   29f05:	0f 85 79 a0 ff ff    	jne    23f84 <JS_CallInternal+0x14a4>
   29f0b:	41 8b 46 08          	mov    eax,DWORD PTR [r14+0x8]
   29f0f:	83 f8 ff             	cmp    eax,0xffffffff
   29f12:	0f 84 6c a0 ff ff    	je     23f84 <JS_CallInternal+0x14a4>
   29f18:	89 c2                	mov    edx,eax
   29f1a:	48 c1 e2 04          	shl    rdx,0x4
   29f1e:	48 03 56 20          	add    rdx,QWORD PTR [rsi+0x20]
   29f22:	48 8b 02             	mov    rax,QWORD PTR [rdx]
   29f25:	48 8b 52 08          	mov    rdx,QWORD PTR [rdx+0x8]
   29f29:	83 fa f6             	cmp    edx,0xfffffff6
   29f2c:	0f 86 c2 a0 ff ff    	jbe    23ff4 <JS_CallInternal+0x1514>
   29f32:	83 40 fc 01          	add    DWORD PTR [rax-0x4],0x1
   29f36:	e9 b9 a0 ff ff       	jmp    23ff4 <JS_CallInternal+0x1514>
   29f3b:	0f 1f 44 00 00       	nop    DWORD PTR [rax+rax*1+0x0]
   29f40:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   29f47:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   29f4b:	89 c8                	mov    eax,ecx
   29f4d:	48 8b 97 48 04 00 00 	mov    rdx,QWORD PTR [rdi+0x448]
   29f54:	48 8b 34 c2          	mov    rsi,QWORD PTR [rdx+rax*8]
   29f58:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   29f5b:	83 e8 01             	sub    eax,0x1
   29f5e:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   29f61:	85 c0                	test   eax,eax
   29f63:	0f 8f 01 b1 ff ff    	jg     2506a <JS_CallInternal+0x258a>
   29f69:	44 89 85 38 fe ff ff 	mov    DWORD PTR [rbp-0x1c8],r8d
   29f70:	e8 8b b4 fe ff       	call   15400 <JS_FreeAtomStruct>
   29f75:	44 8b 85 38 fe ff ff 	mov    r8d,DWORD PTR [rbp-0x1c8]
   29f7c:	e9 e9 b0 ff ff       	jmp    2506a <JS_CallInternal+0x258a>
   29f81:	c7 85 f0 fe ff ff ff 	mov    DWORD PTR [rbp-0x110],0xffffffff
   29f88:	ff ff ff 
   29f8b:	b9 ff ff ff ff       	mov    ecx,0xffffffff
   29f90:	4d 8b 45 08          	mov    r8,QWORD PTR [r13+0x8]
   29f94:	49 8b 75 00          	mov    rsi,QWORD PTR [r13+0x0]
   29f98:	41 83 f8 f6          	cmp    r8d,0xfffffff6
   29f9c:	76 11                	jbe    29faf <JS_CallInternal+0x74cf>
   29f9e:	8b 7e fc             	mov    edi,DWORD PTR [rsi-0x4]
   29fa1:	8d 57 ff             	lea    edx,[rdi-0x1]
   29fa4:	89 56 fc             	mov    DWORD PTR [rsi-0x4],edx
   29fa7:	85 d2                	test   edx,edx
   29fa9:	0f 8e c2 20 00 00    	jle    2c071 <JS_CallInternal+0x9591>
   29faf:	49 c7 45 00 00 00 00 	mov    QWORD PTR [r13+0x0],0x0
   29fb6:	00 
   29fb7:	49 c7 45 08 03 00 00 	mov    QWORD PTR [r13+0x8],0x3
   29fbe:	00 
   29fbf:	85 c9                	test   ecx,ecx
   29fc1:	0f 88 d0 2a 00 00    	js     2ca97 <JS_CallInternal+0x9fb7>
   29fc7:	41 83 f9 f6          	cmp    r9d,0xfffffff6
   29fcb:	76 11                	jbe    29fde <JS_CallInternal+0x74fe>
   29fcd:	8b 48 fc             	mov    ecx,DWORD PTR [rax-0x4]
   29fd0:	8d 51 ff             	lea    edx,[rcx-0x1]
   29fd3:	89 50 fc             	mov    DWORD PTR [rax-0x4],edx
   29fd6:	85 d2                	test   edx,edx
   29fd8:	0f 8e 0f 1f 00 00    	jle    2beed <JS_CallInternal+0x940d>
   29fde:	44 8b 85 f0 fe ff ff 	mov    r8d,DWORD PTR [rbp-0x110]
   29fe5:	31 d2                	xor    edx,edx
   29fe7:	be 03 00 00 00       	mov    esi,0x3
   29fec:	45 85 c0             	test   r8d,r8d
   29fef:	0f 95 c2             	setne  dl
   29ff2:	31 ff                	xor    edi,edi
   29ff4:	e9 97 e4 ff ff       	jmp    28490 <JS_CallInternal+0x59b0>
   29ff9:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2a000:	48 8b 7f 10          	mov    rdi,QWORD PTR [rdi+0x10]
   2a004:	48 8b 97 48 04 00 00 	mov    rdx,QWORD PTR [rdi+0x448]
   2a00b:	4a 8b 34 ea          	mov    rsi,QWORD PTR [rdx+r13*8]
   2a00f:	8b 56 fc             	mov    edx,DWORD PTR [rsi-0x4]
   2a012:	83 ea 01             	sub    edx,0x1
   2a015:	89 56 fc             	mov    DWORD PTR [rsi-0x4],edx
   2a018:	85 d2                	test   edx,edx
   2a01a:	0f 8f 5c e0 ff ff    	jg     2807c <JS_CallInternal+0x559c>
   2a020:	48 89 8d 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],rcx
   2a027:	4c 89 b5 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],r14
   2a02e:	e8 cd b3 fe ff       	call   15400 <JS_FreeAtomStruct>
   2a033:	48 8b 8d 40 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x1c0]
   2a03a:	48 8b 85 50 fe ff ff 	mov    rax,QWORD PTR [rbp-0x1b0]
   2a041:	e9 36 e0 ff ff       	jmp    2807c <JS_CallInternal+0x559c>
   2a046:	48 89 fe             	mov    rsi,rdi
   2a049:	48 8b 95 c8 fe ff ff 	mov    rdx,QWORD PTR [rbp-0x138]
   2a050:	48 8b bd c0 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x140]
   2a057:	48 89 85 d0 fe ff ff 	mov    QWORD PTR [rbp-0x130],rax
   2a05e:	48 89 8d e0 fe ff ff 	mov    QWORD PTR [rbp-0x120],rcx
   2a065:	e8 86 63 ff ff       	call   203f0 <close_var_refs>
   2a06a:	48 8b 85 d0 fe ff ff 	mov    rax,QWORD PTR [rbp-0x130]
   2a071:	48 8b 8d e0 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x120]
   2a078:	e9 68 91 ff ff       	jmp    231e5 <JS_CallInternal+0x705>
   2a07d:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a084:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a088:	48 8b 87 48 04 00 00 	mov    rax,QWORD PTR [rdi+0x448]
   2a08f:	4a 8b 34 e8          	mov    rsi,QWORD PTR [rax+r13*8]
   2a093:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   2a096:	83 e8 01             	sub    eax,0x1
   2a099:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   2a09c:	85 c0                	test   eax,eax
   2a09e:	0f 8f 50 d5 ff ff    	jg     275f4 <JS_CallInternal+0x4b14>
   2a0a4:	e8 57 b3 fe ff       	call   15400 <JS_FreeAtomStruct>
   2a0a9:	e9 46 d5 ff ff       	jmp    275f4 <JS_CallInternal+0x4b14>
   2a0ae:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   2a0b5:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2a0bc:	31 d2                	xor    edx,edx
   2a0be:	48 89 de             	mov    rsi,rbx
   2a0c1:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   2a0c5:	e8 d6 11 03 00       	call   5b2a0 <js_eq_slow>
   2a0ca:	85 c0                	test   eax,eax
   2a0cc:	0f 84 92 c8 ff ff    	je     26964 <JS_CallInternal+0x3e84>
   2a0d2:	e9 a9 91 ff ff       	jmp    23280 <JS_CallInternal+0x7a0>
   2a0d7:	66 0f 1f 84 00 00 00 	nop    WORD PTR [rax+rax*1+0x0]
   2a0de:	00 00 
   2a0e0:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   2a0e7:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2a0ee:	ba 01 00 00 00       	mov    edx,0x1
   2a0f3:	48 89 de             	mov    rsi,rbx
   2a0f6:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   2a0fa:	e8 a1 11 03 00       	call   5b2a0 <js_eq_slow>
   2a0ff:	85 c0                	test   eax,eax
   2a101:	0f 84 03 c8 ff ff    	je     2690a <JS_CallInternal+0x3e2a>
   2a107:	e9 74 91 ff ff       	jmp    23280 <JS_CallInternal+0x7a0>
   2a10c:	0f 1f 40 00          	nop    DWORD PTR [rax+0x0]
   2a110:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2a117:	48 8d 35 08 34 0a 00 	lea    rsi,[rip+0xa3408]        # cd526 <_IO_stdin_used+0x526>
   2a11e:	31 c0                	xor    eax,eax
   2a120:	e8 fb 6a 00 00       	call   30c20 <JS_ThrowTypeError>
   2a125:	83 fb f6             	cmp    ebx,0xfffffff6
   2a128:	76 1e                	jbe    2a148 <JS_CallInternal+0x7668>
   2a12a:	48 8b 8d 50 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x1b0]
   2a131:	8b 41 fc             	mov    eax,DWORD PTR [rcx-0x4]
   2a134:	89 85 28 fe ff ff    	mov    DWORD PTR [rbp-0x1d8],eax
   2a13a:	83 e8 01             	sub    eax,0x1
   2a13d:	89 41 fc             	mov    DWORD PTR [rcx-0x4],eax
   2a140:	85 c0                	test   eax,eax
   2a142:	0f 8e 91 24 00 00    	jle    2c5d9 <JS_CallInternal+0x9af9>
   2a148:	83 bd 38 fe ff ff f6 	cmp    DWORD PTR [rbp-0x1c8],0xfffffff6
   2a14f:	76 1e                	jbe    2a16f <JS_CallInternal+0x768f>
   2a151:	48 8b 8d 40 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x1c0]
   2a158:	8b 41 fc             	mov    eax,DWORD PTR [rcx-0x4]
   2a15b:	89 85 50 fe ff ff    	mov    DWORD PTR [rbp-0x1b0],eax
   2a161:	83 e8 01             	sub    eax,0x1
   2a164:	89 41 fc             	mov    DWORD PTR [rcx-0x4],eax
   2a167:	85 c0                	test   eax,eax
   2a169:	0f 8e d6 24 00 00    	jle    2c645 <JS_CallInternal+0x9b65>
   2a16f:	ba 06 00 00 00       	mov    edx,0x6
   2a174:	31 c0                	xor    eax,eax
   2a176:	e9 1d a0 ff ff       	jmp    24198 <JS_CallInternal+0x16b8>
   2a17b:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   2a182:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2a189:	44 89 ea             	mov    edx,r13d
   2a18c:	48 89 de             	mov    rsi,rbx
   2a18f:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   2a193:	e8 38 b4 02 00       	call   555d0 <js_unary_arith_slow>
   2a198:	85 c0                	test   eax,eax
   2a19a:	0f 84 e5 d1 ff ff    	je     27385 <JS_CallInternal+0x48a5>
   2a1a0:	e9 db 90 ff ff       	jmp    23280 <JS_CallInternal+0x7a0>
   2a1a5:	0f 1f 00             	nop    DWORD PTR [rax]
   2a1a8:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a1af:	48 89 ca             	mov    rdx,rcx
   2a1b2:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a1b6:	e8 e5 26 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2a1bb:	e9 a2 95 ff ff       	jmp    23762 <JS_CallInternal+0xc82>
   2a1c0:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a1c7:	89 8d 38 fe ff ff    	mov    DWORD PTR [rbp-0x1c8],ecx
   2a1cd:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a1d1:	e8 ca 26 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2a1d6:	8b 8d 38 fe ff ff    	mov    ecx,DWORD PTR [rbp-0x1c8]
   2a1dc:	e9 f8 97 ff ff       	jmp    239d9 <JS_CallInternal+0xef9>
   2a1e1:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a1e8:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a1ec:	8b 85 50 fe ff ff    	mov    eax,DWORD PTR [rbp-0x1b0]
   2a1f2:	48 8b 97 48 04 00 00 	mov    rdx,QWORD PTR [rdi+0x448]
   2a1f9:	48 8b 34 c2          	mov    rsi,QWORD PTR [rdx+rax*8]
   2a1fd:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   2a200:	83 e8 01             	sub    eax,0x1
   2a203:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   2a206:	85 c0                	test   eax,eax
   2a208:	0f 8f a0 ef ff ff    	jg     291ae <JS_CallInternal+0x66ce>
   2a20e:	89 8d 50 fe ff ff    	mov    DWORD PTR [rbp-0x1b0],ecx
   2a214:	e8 e7 b1 fe ff       	call   15400 <JS_FreeAtomStruct>
   2a219:	8b 8d 50 fe ff ff    	mov    ecx,DWORD PTR [rbp-0x1b0]
   2a21f:	e9 8a ef ff ff       	jmp    291ae <JS_CallInternal+0x66ce>
   2a224:	41 83 fe f6          	cmp    r14d,0xfffffff6
   2a228:	0f 87 8d 0c 00 00    	ja     2aebb <JS_CallInternal+0x83db>
   2a22e:	b8 01 00 00 00       	mov    eax,0x1
   2a233:	e9 07 d7 ff ff       	jmp    2793f <JS_CallInternal+0x4e5f>
   2a238:	0f 1f 84 00 00 00 00 	nop    DWORD PTR [rax+rax*1+0x0]
   2a23f:	00 
   2a240:	45 31 ed             	xor    r13d,r13d
   2a243:	e9 0f ec ff ff       	jmp    28e57 <JS_CallInternal+0x6377>
   2a248:	41 83 fe f6          	cmp    r14d,0xfffffff6
   2a24c:	76 0f                	jbe    2a25d <JS_CallInternal+0x777d>
   2a24e:	41 8b 45 fc          	mov    eax,DWORD PTR [r13-0x4]
   2a252:	83 e8 01             	sub    eax,0x1
   2a255:	41 89 45 fc          	mov    DWORD PTR [r13-0x4],eax
   2a259:	85 c0                	test   eax,eax
   2a25b:	7e 07                	jle    2a264 <JS_CallInternal+0x7784>
   2a25d:	31 c0                	xor    eax,eax
   2a25f:	e9 2f d7 ff ff       	jmp    27993 <JS_CallInternal+0x4eb3>
   2a264:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a26b:	4c 89 ee             	mov    rsi,r13
   2a26e:	4c 89 f2             	mov    rdx,r14
   2a271:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a275:	e8 26 26 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2a27a:	31 c0                	xor    eax,eax
   2a27c:	e9 12 d7 ff ff       	jmp    27993 <JS_CallInternal+0x4eb3>
   2a281:	b9 ff ff ff ff       	mov    ecx,0xffffffff
   2a286:	e9 2f 97 ff ff       	jmp    239ba <JS_CallInternal+0xeda>
   2a28b:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   2a292:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2a299:	44 89 ea             	mov    edx,r13d
   2a29c:	48 89 de             	mov    rsi,rbx
   2a29f:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   2a2a3:	e8 28 b3 02 00       	call   555d0 <js_unary_arith_slow>
   2a2a8:	85 c0                	test   eax,eax
   2a2aa:	0f 84 bc cf ff ff    	je     2726c <JS_CallInternal+0x478c>
   2a2b0:	e9 cb 8f ff ff       	jmp    23280 <JS_CallInternal+0x7a0>
   2a2b5:	0f 1f 00             	nop    DWORD PTR [rax]
   2a2b8:	48 8b 8d e8 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x118]
   2a2bf:	89 c0                	mov    eax,eax
   2a2c1:	48 8b 79 10          	mov    rdi,QWORD PTR [rcx+0x10]
   2a2c5:	48 8b 8f 48 04 00 00 	mov    rcx,QWORD PTR [rdi+0x448]
   2a2cc:	48 8b 34 c1          	mov    rsi,QWORD PTR [rcx+rax*8]
   2a2d0:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   2a2d3:	83 e8 01             	sub    eax,0x1
   2a2d6:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   2a2d9:	85 c0                	test   eax,eax
   2a2db:	0f 8f 8e ca ff ff    	jg     26d6f <JS_CallInternal+0x428f>
   2a2e1:	4c 89 8d 38 fe ff ff 	mov    QWORD PTR [rbp-0x1c8],r9
   2a2e8:	48 89 95 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],rdx
   2a2ef:	e8 0c b1 fe ff       	call   15400 <JS_FreeAtomStruct>
   2a2f4:	4c 8b 8d 38 fe ff ff 	mov    r9,QWORD PTR [rbp-0x1c8]
   2a2fb:	48 8b 95 40 fe ff ff 	mov    rdx,QWORD PTR [rbp-0x1c0]
   2a302:	e9 68 ca ff ff       	jmp    26d6f <JS_CallInternal+0x428f>
   2a307:	4c 8b a5 28 fe ff ff 	mov    r12,QWORD PTR [rbp-0x1d8]
   2a30e:	e9 6d 8f ff ff       	jmp    23280 <JS_CallInternal+0x7a0>
   2a313:	48 8b bd d8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x128]
   2a31a:	48 8b 47 30          	mov    rax,QWORD PTR [rdi+0x30]
   2a31e:	48 01 c8             	add    rax,rcx
   2a321:	8b 48 04             	mov    ecx,DWORD PTR [rax+0x4]
   2a324:	f6 00 08             	test   BYTE PTR [rax],0x8
   2a327:	0f 85 83 29 00 00    	jne    2ccb0 <JS_CallInternal+0xa1d0>
   2a32d:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2a334:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   2a33b:	48 83 ec 08          	sub    rsp,0x8
   2a33f:	41 83 ed 37          	sub    r13d,0x37
   2a343:	4c 89 70 30          	mov    QWORD PTR [rax+0x30],r14
   2a347:	4c 8b 87 80 01 00 00 	mov    r8,QWORD PTR [rdi+0x180]
   2a34e:	4c 8b 8f 88 01 00 00 	mov    r9,QWORD PTR [rdi+0x188]
   2a355:	48 8b b7 80 01 00 00 	mov    rsi,QWORD PTR [rdi+0x180]
   2a35c:	48 8b 97 88 01 00 00 	mov    rdx,QWORD PTR [rdi+0x188]
   2a363:	41 55                	push   r13
   2a365:	e8 46 2a 00 00       	call   2cdb0 <JS_GetPropertyInternal>
   2a36a:	48 89 53 08          	mov    QWORD PTR [rbx+0x8],rdx
   2a36e:	83 7b 08 06          	cmp    DWORD PTR [rbx+0x8],0x6
   2a372:	48 89 03             	mov    QWORD PTR [rbx],rax
   2a375:	41 5b                	pop    r11
   2a377:	41 5d                	pop    r13
   2a379:	0f 85 1f 98 ff ff    	jne    23b9e <JS_CallInternal+0x10be>
   2a37f:	4d 89 f4             	mov    r12,r14
   2a382:	e9 f9 8e ff ff       	jmp    23280 <JS_CallInternal+0x7a0>
   2a387:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2a38e:	48 8d 35 a1 31 0a 00 	lea    rsi,[rip+0xa31a1]        # cd536 <_IO_stdin_used+0x536>
   2a395:	31 c0                	xor    eax,eax
   2a397:	e8 64 8c 00 00       	call   33000 <JS_ThrowInternalError>
   2a39c:	e9 df 8e ff ff       	jmp    23280 <JS_CallInternal+0x7a0>
   2a3a1:	48 83 ec 08          	sub    rsp,0x8
   2a3a5:	48 8d 4b f0          	lea    rcx,[rbx-0x10]
   2a3a9:	41 b9 01 00 00 00    	mov    r9d,0x1
   2a3af:	51                   	push   rcx
   2a3b0:	e9 0a f4 ff ff       	jmp    297bf <JS_CallInternal+0x6cdf>
   2a3b5:	ba 03 00 00 00       	mov    edx,0x3
   2a3ba:	31 c0                	xor    eax,eax
   2a3bc:	e9 33 9c ff ff       	jmp    23ff4 <JS_CallInternal+0x1514>
   2a3c1:	48 89 c6             	mov    rsi,rax
   2a3c4:	8b 40 ac             	mov    eax,DWORD PTR [rax-0x54]
   2a3c7:	89 85 50 fe ff ff    	mov    DWORD PTR [rbp-0x1b0],eax
   2a3cd:	83 e8 01             	sub    eax,0x1
   2a3d0:	89 46 ac             	mov    DWORD PTR [rsi-0x54],eax
   2a3d3:	0f 85 33 d8 ff ff    	jne    27c0c <JS_CallInternal+0x512c>
   2a3d9:	80 bf a0 04 00 00 02 	cmp    BYTE PTR [rdi+0x4a0],0x2
   2a3e0:	0f 84 26 d8 ff ff    	je     27c0c <JS_CallInternal+0x512c>
   2a3e6:	48 83 ee 50          	sub    rsi,0x50
   2a3ea:	e8 41 5f ff ff       	call   20330 <async_func_free.part.0>
   2a3ef:	48 8b b5 c8 fe ff ff 	mov    rsi,QWORD PTR [rbp-0x138]
   2a3f6:	48 8b 4e 28          	mov    rcx,QWORD PTR [rsi+0x28]
   2a3fa:	4c 01 e9             	add    rcx,r13
   2a3fd:	e9 0a d8 ff ff       	jmp    27c0c <JS_CallInternal+0x512c>
   2a402:	4c 8d 5b f0          	lea    r11,[rbx-0x10]
   2a406:	41 b8 03 00 00 00    	mov    r8d,0x3
   2a40c:	45 31 ed             	xor    r13d,r13d
   2a40f:	e9 b7 9c ff ff       	jmp    240cb <JS_CallInternal+0x15eb>
   2a414:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2a41b:	0f b6 d0             	movzx  edx,al
   2a41e:	31 c0                	xor    eax,eax
   2a420:	48 8d 35 e5 30 0a 00 	lea    rsi,[rip+0xa30e5]        # cd50c <_IO_stdin_used+0x50c>
   2a427:	e8 d4 8b 00 00       	call   33000 <JS_ThrowInternalError>
   2a42c:	e9 4f 8e ff ff       	jmp    23280 <JS_CallInternal+0x7a0>
   2a431:	4d 89 ec             	mov    r12,r13
   2a434:	e9 47 8e ff ff       	jmp    23280 <JS_CallInternal+0x7a0>
   2a439:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a440:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a444:	e8 57 24 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2a449:	e9 15 c7 ff ff       	jmp    26b63 <JS_CallInternal+0x4083>
   2a44e:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a455:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a459:	e8 42 24 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2a45e:	e9 9b ec ff ff       	jmp    290fe <JS_CallInternal+0x661e>
   2a463:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a46a:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a46e:	e8 2d 24 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2a473:	e9 08 c7 ff ff       	jmp    26b80 <JS_CallInternal+0x40a0>
   2a478:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a47f:	48 89 8d 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],rcx
   2a486:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a48a:	e8 11 24 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2a48f:	48 8b 8d 50 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x1b0]
   2a496:	e9 88 cf ff ff       	jmp    27423 <JS_CallInternal+0x4943>
   2a49b:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a4a2:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a4a6:	e8 f5 23 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2a4ab:	e9 b4 cf ff ff       	jmp    27464 <JS_CallInternal+0x4984>
   2a4b0:	48 89 85 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],rax
   2a4b7:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a4be:	4c 89 85 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],r8
   2a4c5:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a4c9:	e8 d2 23 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2a4ce:	4c 8b 85 40 fe ff ff 	mov    r8,QWORD PTR [rbp-0x1c0]
   2a4d5:	48 8b 85 50 fe ff ff 	mov    rax,QWORD PTR [rbp-0x1b0]
   2a4dc:	e9 08 e8 ff ff       	jmp    28ce9 <JS_CallInternal+0x6209>
   2a4e1:	88 85 40 fe ff ff    	mov    BYTE PTR [rbp-0x1c0],al
   2a4e7:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a4ee:	4c 89 ce             	mov    rsi,r9
   2a4f1:	4c 89 ea             	mov    rdx,r13
   2a4f4:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a4f8:	e8 a3 23 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2a4fd:	0f b6 85 40 fe ff ff 	movzx  eax,BYTE PTR [rbp-0x1c0]
   2a504:	e9 85 c8 ff ff       	jmp    26d8e <JS_CallInternal+0x42ae>
   2a509:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a510:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a514:	e8 87 23 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2a519:	e9 39 a8 ff ff       	jmp    24d57 <JS_CallInternal+0x2277>
   2a51e:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a525:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a529:	e8 72 23 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2a52e:	e9 1a b2 ff ff       	jmp    2574d <JS_CallInternal+0x2c6d>
   2a533:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a53a:	48 89 ca             	mov    rdx,rcx
   2a53d:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a541:	e8 5a 23 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2a546:	e9 65 b3 ff ff       	jmp    258b0 <JS_CallInternal+0x2dd0>
   2a54b:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a552:	48 89 ca             	mov    rdx,rcx
   2a555:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a559:	e8 42 23 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2a55e:	e9 a1 b3 ff ff       	jmp    25904 <JS_CallInternal+0x2e24>
   2a563:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a56a:	48 89 ca             	mov    rdx,rcx
   2a56d:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a571:	e8 2a 23 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2a576:	e9 dd b3 ff ff       	jmp    25958 <JS_CallInternal+0x2e78>
   2a57b:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a582:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a586:	e8 15 23 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2a58b:	e9 9f ac ff ff       	jmp    2522f <JS_CallInternal+0x274f>
   2a590:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a597:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a59b:	e8 00 23 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2a5a0:	e9 3f ac ff ff       	jmp    251e4 <JS_CallInternal+0x2704>
   2a5a5:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a5ac:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a5b0:	e8 eb 22 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2a5b5:	e9 ba ac ff ff       	jmp    25274 <JS_CallInternal+0x2794>
   2a5ba:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a5c1:	4c 89 c2             	mov    rdx,r8
   2a5c4:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a5c8:	e8 d3 22 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2a5cd:	e9 5e b7 ff ff       	jmp    25d30 <JS_CallInternal+0x3250>
   2a5d2:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a5d9:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a5dd:	e8 be 22 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2a5e2:	e9 e5 b7 ff ff       	jmp    25dcc <JS_CallInternal+0x32ec>
   2a5e7:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a5ee:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a5f2:	e8 a9 22 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2a5f7:	e9 82 b7 ff ff       	jmp    25d7e <JS_CallInternal+0x329e>
   2a5fc:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a603:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a607:	e8 94 22 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2a60c:	e9 09 b8 ff ff       	jmp    25e1a <JS_CallInternal+0x333a>
   2a611:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a618:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a61c:	e8 7f 22 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2a621:	e9 7d a6 ff ff       	jmp    24ca3 <JS_CallInternal+0x21c3>
   2a626:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a62d:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a631:	e8 6a 22 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2a636:	e9 1e a5 ff ff       	jmp    24b59 <JS_CallInternal+0x2079>
   2a63b:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a642:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a646:	e8 55 22 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2a64b:	e9 2f b5 ff ff       	jmp    25b7f <JS_CallInternal+0x309f>
   2a650:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a657:	4c 89 c2             	mov    rdx,r8
   2a65a:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a65e:	e8 3d 22 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2a663:	e9 b8 b5 ff ff       	jmp    25c20 <JS_CallInternal+0x3140>
   2a668:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a66f:	4c 89 c2             	mov    rdx,r8
   2a672:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a676:	e8 25 22 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2a67b:	e9 fb b5 ff ff       	jmp    25c7b <JS_CallInternal+0x319b>
   2a680:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a687:	4c 89 c2             	mov    rdx,r8
   2a68a:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a68e:	e8 0d 22 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2a693:	e9 3e b6 ff ff       	jmp    25cd6 <JS_CallInternal+0x31f6>
   2a698:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a69f:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a6a3:	e8 f8 21 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2a6a8:	e9 8a b4 ff ff       	jmp    25b37 <JS_CallInternal+0x3057>
   2a6ad:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a6b4:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a6b8:	e8 e3 21 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2a6bd:	e9 76 b3 ff ff       	jmp    25a38 <JS_CallInternal+0x2f58>
   2a6c2:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a6c9:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a6cd:	e8 ce 21 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2a6d2:	e9 19 b3 ff ff       	jmp    259f0 <JS_CallInternal+0x2f10>
   2a6d7:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a6de:	48 89 ca             	mov    rdx,rcx
   2a6e1:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a6e5:	e8 b6 21 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2a6ea:	e9 bb b2 ff ff       	jmp    259aa <JS_CallInternal+0x2eca>
   2a6ef:	88 85 40 fe ff ff    	mov    BYTE PTR [rbp-0x1c0],al
   2a6f5:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a6fc:	48 89 ce             	mov    rsi,rcx
   2a6ff:	4c 89 f2             	mov    rdx,r14
   2a702:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a706:	e8 95 21 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2a70b:	0f b6 85 40 fe ff ff 	movzx  eax,BYTE PTR [rbp-0x1c0]
   2a712:	e9 9b c6 ff ff       	jmp    26db2 <JS_CallInternal+0x42d2>
   2a717:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a71e:	4c 89 c6             	mov    rsi,r8
   2a721:	48 89 ca             	mov    rdx,rcx
   2a724:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a728:	e8 73 21 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2a72d:	e9 4f df ff ff       	jmp    28681 <JS_CallInternal+0x5ba1>
   2a732:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a739:	48 89 ca             	mov    rdx,rcx
   2a73c:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a740:	e8 5b 21 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2a745:	e9 2b e3 ff ff       	jmp    28a75 <JS_CallInternal+0x5f95>
   2a74a:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a751:	48 89 8d 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],rcx
   2a758:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a75c:	e8 3f 21 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2a761:	48 8b 8d 50 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x1b0]
   2a768:	e9 c2 e4 ff ff       	jmp    28c2f <JS_CallInternal+0x614f>
   2a76d:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a774:	4c 89 c2             	mov    rdx,r8
   2a777:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a77b:	e8 20 21 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2a780:	e9 f7 9d ff ff       	jmp    2457c <JS_CallInternal+0x1a9c>
   2a785:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a78c:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a790:	e8 0b 21 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2a795:	e9 31 9e ff ff       	jmp    245cb <JS_CallInternal+0x1aeb>
   2a79a:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a7a1:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a7a5:	e8 f6 20 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2a7aa:	e9 06 a2 ff ff       	jmp    249b5 <JS_CallInternal+0x1ed5>
   2a7af:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a7b6:	4c 89 c2             	mov    rdx,r8
   2a7b9:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a7bd:	e8 de 20 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2a7c2:	e9 40 a3 ff ff       	jmp    24b07 <JS_CallInternal+0x2027>
   2a7c7:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a7ce:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a7d2:	e8 c9 20 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2a7d7:	e9 4b a1 ff ff       	jmp    24927 <JS_CallInternal+0x1e47>
   2a7dc:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a7e3:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a7e7:	e8 b4 20 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2a7ec:	e9 7e a1 ff ff       	jmp    2496f <JS_CallInternal+0x1e8f>
   2a7f1:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a7f8:	48 89 ca             	mov    rdx,rcx
   2a7fb:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a7ff:	e8 9c 20 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2a804:	e9 94 9f ff ff       	jmp    2479d <JS_CallInternal+0x1cbd>
   2a809:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a810:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a814:	e8 87 20 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2a819:	e9 a5 9e ff ff       	jmp    246c3 <JS_CallInternal+0x1be3>
   2a81e:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a825:	4c 89 c2             	mov    rdx,r8
   2a828:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a82c:	e8 6f 20 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2a831:	e9 3e 9e ff ff       	jmp    24674 <JS_CallInternal+0x1b94>
   2a836:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a83d:	48 89 ca             	mov    rdx,rcx
   2a840:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a844:	e8 57 20 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2a849:	e9 49 a0 ff ff       	jmp    24897 <JS_CallInternal+0x1db7>
   2a84e:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a855:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a859:	e8 42 20 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2a85e:	e9 7c a0 ff ff       	jmp    248df <JS_CallInternal+0x1dff>
   2a863:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a86a:	48 89 ca             	mov    rdx,rcx
   2a86d:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a871:	e8 2a 20 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2a876:	e9 76 9f ff ff       	jmp    247f1 <JS_CallInternal+0x1d11>
   2a87b:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a882:	48 89 ca             	mov    rdx,rcx
   2a885:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a889:	e8 12 20 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2a88e:	e9 b2 9f ff ff       	jmp    24845 <JS_CallInternal+0x1d65>
   2a893:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a89a:	4c 89 85 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],r8
   2a8a1:	4c 89 8d 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],r9
   2a8a8:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a8ac:	e8 ef 1f ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2a8b1:	4c 8b 85 40 fe ff ff 	mov    r8,QWORD PTR [rbp-0x1c0]
   2a8b8:	4c 8b 8d 50 fe ff ff 	mov    r9,QWORD PTR [rbp-0x1b0]
   2a8bf:	e9 df 95 ff ff       	jmp    23ea3 <JS_CallInternal+0x13c3>
   2a8c4:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a8cb:	4c 89 85 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],r8
   2a8d2:	4c 89 8d 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],r9
   2a8d9:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a8dd:	e8 be 1f ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2a8e2:	4c 8b 85 40 fe ff ff 	mov    r8,QWORD PTR [rbp-0x1c0]
   2a8e9:	4c 8b 8d 50 fe ff ff 	mov    r9,QWORD PTR [rbp-0x1b0]
   2a8f0:	e9 73 95 ff ff       	jmp    23e68 <JS_CallInternal+0x1388>
   2a8f5:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a8fc:	4c 89 85 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],r8
   2a903:	4c 89 8d 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],r9
   2a90a:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a90e:	e8 8d 1f ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2a913:	4c 8b 85 40 fe ff ff 	mov    r8,QWORD PTR [rbp-0x1c0]
   2a91a:	4c 8b 8d 50 fe ff ff 	mov    r9,QWORD PTR [rbp-0x1b0]
   2a921:	e9 5f 95 ff ff       	jmp    23e85 <JS_CallInternal+0x13a5>
   2a926:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a92d:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a931:	e8 6a 1f ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2a936:	e9 14 df ff ff       	jmp    2884f <JS_CallInternal+0x5d6f>
   2a93b:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a942:	48 89 8d 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],rcx
   2a949:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a94d:	e8 4e 1f ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2a952:	48 8b 8d 50 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x1b0]
   2a959:	e9 7b 94 ff ff       	jmp    23dd9 <JS_CallInternal+0x12f9>
   2a95e:	48 89 85 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],rax
   2a965:	4c 89 f6             	mov    rsi,r14
   2a968:	4c 89 ea             	mov    rdx,r13
   2a96b:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a972:	48 89 8d 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],rcx
   2a979:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a97d:	e8 1e 1f ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2a982:	48 8b 8d 40 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x1c0]
   2a989:	48 8b 85 50 fe ff ff 	mov    rax,QWORD PTR [rbp-0x1b0]
   2a990:	e9 a3 ba ff ff       	jmp    26438 <JS_CallInternal+0x3958>
   2a995:	48 8b 7f 10          	mov    rdi,QWORD PTR [rdi+0x10]
   2a999:	4c 89 c2             	mov    rdx,r8
   2a99c:	e8 ff 1e ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2a9a1:	e9 57 cb ff ff       	jmp    274fd <JS_CallInternal+0x4a1d>
   2a9a6:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a9ad:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a9b1:	e8 ea 1e ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2a9b6:	e9 0f de ff ff       	jmp    287ca <JS_CallInternal+0x5cea>
   2a9bb:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a9c2:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a9c6:	e8 d5 1e ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2a9cb:	e9 17 de ff ff       	jmp    287e7 <JS_CallInternal+0x5d07>
   2a9d0:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a9d7:	4c 89 f2             	mov    rdx,r14
   2a9da:	48 89 8d 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],rcx
   2a9e1:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a9e5:	e8 b6 1e ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2a9ea:	48 8b 8d 50 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x1b0]
   2a9f1:	e9 90 c2 ff ff       	jmp    26c86 <JS_CallInternal+0x41a6>
   2a9f6:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a9fd:	4c 89 95 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],r10
   2aa04:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2aa08:	e8 93 1e ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2aa0d:	4c 8b 95 40 fe ff ff 	mov    r10,QWORD PTR [rbp-0x1c0]
   2aa14:	e9 94 dd ff ff       	jmp    287ad <JS_CallInternal+0x5ccd>
   2aa19:	4c 8b a5 10 fe ff ff 	mov    r12,QWORD PTR [rbp-0x1f0]
   2aa20:	e9 5b 88 ff ff       	jmp    23280 <JS_CallInternal+0x7a0>
   2aa25:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2aa2c:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2aa30:	e8 6b 1e ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2aa35:	e9 a0 e6 ff ff       	jmp    290da <JS_CallInternal+0x65fa>
   2aa3a:	48 89 85 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],rax
   2aa41:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2aa48:	44 89 85 38 fe ff ff 	mov    DWORD PTR [rbp-0x1c8],r8d
   2aa4f:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2aa53:	48 89 8d 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],rcx
   2aa5a:	e8 41 1e ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2aa5f:	44 8b 85 38 fe ff ff 	mov    r8d,DWORD PTR [rbp-0x1c8]
   2aa66:	48 8b 85 40 fe ff ff 	mov    rax,QWORD PTR [rbp-0x1c0]
   2aa6d:	48 8b 8d 50 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x1b0]
   2aa74:	e9 d0 d8 ff ff       	jmp    28349 <JS_CallInternal+0x5869>
   2aa79:	48 89 85 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],rax
   2aa80:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2aa87:	4c 89 85 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],r8
   2aa8e:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2aa92:	e8 09 1e ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2aa97:	4c 8b 85 40 fe ff ff 	mov    r8,QWORD PTR [rbp-0x1c0]
   2aa9e:	48 8b 85 50 fe ff ff 	mov    rax,QWORD PTR [rbp-0x1b0]
   2aaa5:	e9 a4 92 ff ff       	jmp    23d4e <JS_CallInternal+0x126e>
   2aaaa:	48 89 85 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],rax
   2aab1:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2aab8:	4c 89 85 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],r8
   2aabf:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2aac3:	e8 d8 1d ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2aac8:	4c 8b 85 40 fe ff ff 	mov    r8,QWORD PTR [rbp-0x1c0]
   2aacf:	48 8b 85 50 fe ff ff 	mov    rax,QWORD PTR [rbp-0x1b0]
   2aad6:	e9 90 92 ff ff       	jmp    23d6b <JS_CallInternal+0x128b>
   2aadb:	48 89 85 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],rax
   2aae2:	4c 89 ee             	mov    rsi,r13
   2aae5:	4c 89 f2             	mov    rdx,r14
   2aae8:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2aaef:	48 89 8d 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],rcx
   2aaf6:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2aafa:	e8 a1 1d ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2aaff:	48 8b 85 40 fe ff ff 	mov    rax,QWORD PTR [rbp-0x1c0]
   2ab06:	48 8b 8d 50 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x1b0]
   2ab0d:	e9 e1 ab ff ff       	jmp    256f3 <JS_CallInternal+0x2c13>
   2ab12:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   2ab19:	8b 4e 04             	mov    ecx,DWORD PTR [rsi+0x4]
   2ab1c:	48 89 b5 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],rsi
   2ab23:	4c 8b ad e8 fe ff ff 	mov    r13,QWORD PTR [rbp-0x118]
   2ab2a:	4c 89 70 30          	mov    QWORD PTR [rax+0x30],r14
   2ab2e:	49 8b b5 80 01 00 00 	mov    rsi,QWORD PTR [r13+0x180]
   2ab35:	49 8b 95 88 01 00 00 	mov    rdx,QWORD PTR [r13+0x188]
   2ab3c:	4c 89 ef             	mov    rdi,r13
   2ab3f:	e8 7c 36 04 00       	call   6e1c0 <JS_HasProperty>
   2ab44:	85 c0                	test   eax,eax
   2ab46:	0f 88 71 20 00 00    	js     2cbbd <JS_CallInternal+0xa0dd>
   2ab4c:	4c 8b 95 50 fe ff ff 	mov    r10,QWORD PTR [rbp-0x1b0]
   2ab53:	0f 85 00 03 00 00    	jne    2ae59 <JS_CallInternal+0x8379>
   2ab59:	49 8b 45 10          	mov    rax,QWORD PTR [r13+0x10]
   2ab5d:	4c 89 ef             	mov    rdi,r13
   2ab60:	48 8b 80 f0 04 00 00 	mov    rax,QWORD PTR [rax+0x4f0]
   2ab67:	48 85 c0             	test   rax,rax
   2ab6a:	0f 84 e9 02 00 00    	je     2ae59 <JS_CallInternal+0x8379>
   2ab70:	f6 40 3c 01          	test   BYTE PTR [rax+0x3c],0x1
   2ab74:	0f 84 df 02 00 00    	je     2ae59 <JS_CallInternal+0x8379>
   2ab7a:	41 8b 72 04          	mov    esi,DWORD PTR [r10+0x4]
   2ab7e:	4d 89 f4             	mov    r12,r14
   2ab81:	e8 ba 82 00 00       	call   32e40 <JS_ThrowReferenceErrorNotDefined>
   2ab86:	e9 f5 86 ff ff       	jmp    23280 <JS_CallInternal+0x7a0>
   2ab8b:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2ab92:	48 89 ca             	mov    rdx,rcx
   2ab95:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2ab99:	e8 02 1d ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2ab9e:	e9 d6 b2 ff ff       	jmp    25e79 <JS_CallInternal+0x3399>
   2aba3:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2abaa:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2abae:	e8 ed 1c ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2abb3:	e9 6d b3 ff ff       	jmp    25f25 <JS_CallInternal+0x3445>
   2abb8:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2abbf:	4c 89 ee             	mov    rsi,r13
   2abc2:	4c 89 f2             	mov    rdx,r14
   2abc5:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2abc9:	e8 d2 1c ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2abce:	e9 ff c5 ff ff       	jmp    271d2 <JS_CallInternal+0x46f2>
   2abd3:	48 89 85 38 fe ff ff 	mov    QWORD PTR [rbp-0x1c8],rax
   2abda:	4c 89 ee             	mov    rsi,r13
   2abdd:	4c 89 ca             	mov    rdx,r9
   2abe0:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2abe7:	44 89 85 28 fe ff ff 	mov    DWORD PTR [rbp-0x1d8],r8d
   2abee:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2abf2:	48 89 8d 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],rcx
   2abf9:	e8 a2 1c ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2abfe:	44 8b 85 28 fe ff ff 	mov    r8d,DWORD PTR [rbp-0x1d8]
   2ac05:	48 8b 85 38 fe ff ff 	mov    rax,QWORD PTR [rbp-0x1c8]
   2ac0c:	48 8b 8d 40 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x1c0]
   2ac13:	e9 0d d7 ff ff       	jmp    28325 <JS_CallInternal+0x5845>
   2ac18:	48 83 ec 08          	sub    rsp,0x8
   2ac1c:	8b 8d 38 fe ff ff    	mov    ecx,DWORD PTR [rbp-0x1c8]
   2ac22:	4c 89 ee             	mov    rsi,r13
   2ac25:	4c 89 e2             	mov    rdx,r12
   2ac28:	4c 8b 85 50 fe ff ff 	mov    r8,QWORD PTR [rbp-0x1b0]
   2ac2f:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2ac36:	6a 00                	push   0x0
   2ac38:	4c 8b 8d 58 fe ff ff 	mov    r9,QWORD PTR [rbp-0x1a8]
   2ac3f:	e8 6c 21 00 00       	call   2cdb0 <JS_GetPropertyInternal>
   2ac44:	5f                   	pop    rdi
   2ac45:	41 58                	pop    r8
   2ac47:	48 89 c1             	mov    rcx,rax
   2ac4a:	48 89 d0             	mov    rax,rdx
   2ac4d:	83 fa 06             	cmp    edx,0x6
   2ac50:	0f 85 e5 88 ff ff    	jne    2353b <JS_CallInternal+0xa5b>
   2ac56:	e9 8b 89 ff ff       	jmp    235e6 <JS_CallInternal+0xb06>
   2ac5b:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2ac62:	4c 89 85 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],r8
   2ac69:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2ac6d:	e8 2e 1c ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2ac72:	4c 8b 85 50 fe ff ff 	mov    r8,QWORD PTR [rbp-0x1b0]
   2ac79:	e9 6a 94 ff ff       	jmp    240e8 <JS_CallInternal+0x1608>
   2ac7e:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2ac85:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2ac89:	e8 12 1c ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2ac8e:	e9 a1 b6 ff ff       	jmp    26334 <JS_CallInternal+0x3854>
   2ac93:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2ac9a:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2ac9e:	e8 fd 1b ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2aca3:	e9 aa b6 ff ff       	jmp    26352 <JS_CallInternal+0x3872>
   2aca8:	4c 89 f3             	mov    rbx,r14
   2acab:	4d 89 ec             	mov    r12,r13
   2acae:	e9 cd 85 ff ff       	jmp    23280 <JS_CallInternal+0x7a0>
   2acb3:	4d 89 d4             	mov    r12,r10
   2acb6:	e9 c5 85 ff ff       	jmp    23280 <JS_CallInternal+0x7a0>
   2acbb:	4c 8b a5 28 fe ff ff 	mov    r12,QWORD PTR [rbp-0x1d8]
   2acc2:	e9 b9 85 ff ff       	jmp    23280 <JS_CallInternal+0x7a0>
   2acc7:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2acce:	48 8d 35 f3 60 0a 00 	lea    rsi,[rip+0xa60f3]        # d0dc8 <_IO_stdin_used+0x3dc8>
   2acd5:	31 c0                	xor    eax,eax
   2acd7:	e8 44 5f 00 00       	call   30c20 <JS_ThrowTypeError>
   2acdc:	e9 9f 85 ff ff       	jmp    23280 <JS_CallInternal+0x7a0>
   2ace1:	41 83 f9 08          	cmp    r9d,0x8
   2ace5:	0f 84 27 1c 00 00    	je     2c912 <JS_CallInternal+0x9e32>
   2aceb:	41 83 f9 ff          	cmp    r9d,0xffffffff
   2acef:	0f 84 d3 1b 00 00    	je     2c8c8 <JS_CallInternal+0x9de8>
   2acf5:	41 8d 41 fe          	lea    eax,[r9-0x2]
   2acf9:	83 f8 01             	cmp    eax,0x1
   2acfc:	0f 86 68 1d 00 00    	jbe    2ca6a <JS_CallInternal+0x9f8a>
   2ad02:	41 83 f9 f9          	cmp    r9d,0xfffffff9
   2ad06:	0f 85 81 1b 00 00    	jne    2c88d <JS_CallInternal+0x9dad>
   2ad0c:	41 83 fe f9          	cmp    r14d,0xfffffff9
   2ad10:	0f 85 77 1b 00 00    	jne    2c88d <JS_CallInternal+0x9dad>
   2ad16:	4c 89 ee             	mov    rsi,r13
   2ad19:	4c 89 8d 38 fe ff ff 	mov    QWORD PTR [rbp-0x1c8],r9
   2ad20:	48 89 95 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],rdx
   2ad27:	e8 e4 d0 fe ff       	call   17e10 <js_string_eq.isra.0>
   2ad2c:	48 8b b5 40 fe ff ff 	mov    rsi,QWORD PTR [rbp-0x1c0]
   2ad33:	4c 8b 8d 38 fe ff ff 	mov    r9,QWORD PTR [rbp-0x1c8]
   2ad3a:	89 85 50 fe ff ff    	mov    DWORD PTR [rbp-0x1b0],eax
   2ad40:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2ad47:	4c 89 ca             	mov    rdx,r9
   2ad4a:	e8 b1 1c ff ff       	call   1ca00 <JS_FreeValue>
   2ad4f:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2ad56:	4c 89 ee             	mov    rsi,r13
   2ad59:	4c 89 f2             	mov    rdx,r14
   2ad5c:	e8 9f 1c ff ff       	call   1ca00 <JS_FreeValue>
   2ad61:	31 c0                	xor    eax,eax
   2ad63:	83 bd 50 fe ff ff 01 	cmp    DWORD PTR [rbp-0x1b0],0x1
   2ad6a:	0f 95 c0             	setne  al
   2ad6d:	e9 cd cb ff ff       	jmp    2793f <JS_CallInternal+0x4e5f>
   2ad72:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2ad79:	48 8d 35 20 60 0a 00 	lea    rsi,[rip+0xa6020]        # d0da0 <_IO_stdin_used+0x3da0>
   2ad80:	31 c0                	xor    eax,eax
   2ad82:	4d 89 ec             	mov    r12,r13
   2ad85:	e8 86 7f 00 00       	call   32d10 <JS_ThrowReferenceError>
   2ad8a:	e9 f1 84 ff ff       	jmp    23280 <JS_CallInternal+0x7a0>
   2ad8f:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2ad96:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2ad9a:	e9 0b e3 ff ff       	jmp    290aa <JS_CallInternal+0x65ca>
   2ad9f:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2ada6:	48 8d 35 a5 27 0a 00 	lea    rsi,[rip+0xa27a5]        # cd552 <_IO_stdin_used+0x552>
   2adad:	31 c0                	xor    eax,eax
   2adaf:	e8 6c 5e 00 00       	call   30c20 <JS_ThrowTypeError>
   2adb4:	4d 8b 4e 08          	mov    r9,QWORD PTR [r14+0x8]
   2adb8:	4c 8b 6b f0          	mov    r13,QWORD PTR [rbx-0x10]
   2adbc:	48 89 c1             	mov    rcx,rax
   2adbf:	41 89 d0             	mov    r8d,edx
   2adc2:	48 89 d0             	mov    rax,rdx
   2adc5:	e9 42 d5 ff ff       	jmp    2830c <JS_CallInternal+0x582c>
   2adca:	4c 89 f3             	mov    rbx,r14
   2adcd:	e9 ae 84 ff ff       	jmp    23280 <JS_CallInternal+0x7a0>
   2add2:	4c 89 f3             	mov    rbx,r14
   2add5:	e9 a6 84 ff ff       	jmp    23280 <JS_CallInternal+0x7a0>
   2adda:	41 8b 4e 0c          	mov    ecx,DWORD PTR [r14+0xc]
   2adde:	e9 77 e5 ff ff       	jmp    2935a <JS_CallInternal+0x687a>
   2ade3:	48 8b 85 d8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x128]
   2adea:	48 8d 15 a9 26 0a 00 	lea    rdx,[rip+0xa26a9]        # cd49a <_IO_stdin_used+0x49a>
   2adf1:	48 8b 40 30          	mov    rax,QWORD PTR [rax+0x30]
   2adf5:	8b 44 08 04          	mov    eax,DWORD PTR [rax+rcx*1+0x4]
   2adf9:	85 c0                	test   eax,eax
   2adfb:	0f 85 32 16 00 00    	jne    2c433 <JS_CallInternal+0x9953>
   2ae01:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2ae08:	48 8d 35 e7 26 0a 00 	lea    rsi,[rip+0xa26e7]        # cd4f6 <_IO_stdin_used+0x4f6>
   2ae0f:	31 c0                	xor    eax,eax
   2ae11:	4d 89 ec             	mov    r12,r13
   2ae14:	e8 f7 7e 00 00       	call   32d10 <JS_ThrowReferenceError>
   2ae19:	e9 62 84 ff ff       	jmp    23280 <JS_CallInternal+0x7a0>
   2ae1e:	48 8b 85 d8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x128]
   2ae25:	48 8b 40 30          	mov    rax,QWORD PTR [rax+0x30]
   2ae29:	8b 44 10 04          	mov    eax,DWORD PTR [rax+rdx*1+0x4]
   2ae2d:	48 8d 15 66 26 0a 00 	lea    rdx,[rip+0xa2666]        # cd49a <_IO_stdin_used+0x49a>
   2ae34:	85 c0                	test   eax,eax
   2ae36:	0f 85 54 17 00 00    	jne    2c590 <JS_CallInternal+0x9ab0>
   2ae3c:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2ae43:	48 8d 35 ac 26 0a 00 	lea    rsi,[rip+0xa26ac]        # cd4f6 <_IO_stdin_used+0x4f6>
   2ae4a:	31 c0                	xor    eax,eax
   2ae4c:	4d 89 ec             	mov    r12,r13
   2ae4f:	e8 bc 7e 00 00       	call   32d10 <JS_ThrowReferenceError>
   2ae54:	e9 27 84 ff ff       	jmp    23280 <JS_CallInternal+0x7a0>
   2ae59:	48 83 ec 08          	sub    rsp,0x8
   2ae5d:	41 8b 4a 04          	mov    ecx,DWORD PTR [r10+0x4]
   2ae61:	4c 8b 43 f0          	mov    r8,QWORD PTR [rbx-0x10]
   2ae65:	48 83 eb 10          	sub    rbx,0x10
   2ae69:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2ae70:	4c 8b 4b 08          	mov    r9,QWORD PTR [rbx+0x8]
   2ae74:	48 8b b0 80 01 00 00 	mov    rsi,QWORD PTR [rax+0x180]
   2ae7b:	48 8b 90 88 01 00 00 	mov    rdx,QWORD PTR [rax+0x188]
   2ae82:	68 00 80 00 00       	push   0x8000
   2ae87:	48 89 c7             	mov    rdi,rax
   2ae8a:	ff b0 88 01 00 00    	push   QWORD PTR [rax+0x188]
   2ae90:	ff b0 80 01 00 00    	push   QWORD PTR [rax+0x180]
   2ae96:	e8 45 2c 00 00       	call   2dae0 <JS_SetPropertyInternal>
   2ae9b:	48 83 c4 20          	add    rsp,0x20
   2ae9f:	85 c0                	test   eax,eax
   2aea1:	0f 89 bf 88 ff ff    	jns    23766 <JS_CallInternal+0xc86>
   2aea7:	4d 89 f4             	mov    r12,r14
   2aeaa:	e9 d1 83 ff ff       	jmp    23280 <JS_CallInternal+0x7a0>
   2aeaf:	90                   	nop
   2aeb0:	4c 89 f3             	mov    rbx,r14
   2aeb3:	4d 89 ec             	mov    r12,r13
   2aeb6:	e9 c5 83 ff ff       	jmp    23280 <JS_CallInternal+0x7a0>
   2aebb:	41 8b 45 fc          	mov    eax,DWORD PTR [r13-0x4]
   2aebf:	83 e8 01             	sub    eax,0x1
   2aec2:	41 89 45 fc          	mov    DWORD PTR [r13-0x4],eax
   2aec6:	85 c0                	test   eax,eax
   2aec8:	0f 8f 60 f3 ff ff    	jg     2a22e <JS_CallInternal+0x774e>
   2aece:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2aed5:	4c 89 ee             	mov    rsi,r13
   2aed8:	4c 89 f2             	mov    rdx,r14
   2aedb:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2aedf:	e8 bc 19 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2aee4:	e9 45 f3 ff ff       	jmp    2a22e <JS_CallInternal+0x774e>
   2aee9:	48 89 85 28 fe ff ff 	mov    QWORD PTR [rbp-0x1d8],rax
   2aef0:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2aef7:	4c 89 95 38 fe ff ff 	mov    QWORD PTR [rbp-0x1c8],r10
   2aefe:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2af02:	e8 99 19 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2af07:	48 8b 85 28 fe ff ff 	mov    rax,QWORD PTR [rbp-0x1d8]
   2af0e:	4c 8b 95 38 fe ff ff 	mov    r10,QWORD PTR [rbp-0x1c8]
   2af15:	e9 87 d0 ff ff       	jmp    27fa1 <JS_CallInternal+0x54c1>
   2af1a:	48 89 85 38 fe ff ff 	mov    QWORD PTR [rbp-0x1c8],rax
   2af21:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2af28:	4c 89 95 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],r10
   2af2f:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2af33:	e8 68 19 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2af38:	48 8b 85 38 fe ff ff 	mov    rax,QWORD PTR [rbp-0x1c8]
   2af3f:	4c 8b 95 50 fe ff ff 	mov    r10,QWORD PTR [rbp-0x1b0]
   2af46:	e9 7a d0 ff ff       	jmp    27fc5 <JS_CallInternal+0x54e5>
   2af4b:	48 89 85 28 fe ff ff 	mov    QWORD PTR [rbp-0x1d8],rax
   2af52:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2af59:	4c 89 95 38 fe ff ff 	mov    QWORD PTR [rbp-0x1c8],r10
   2af60:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2af64:	e8 37 19 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2af69:	48 8b 85 28 fe ff ff 	mov    rax,QWORD PTR [rbp-0x1d8]
   2af70:	4c 8b 95 38 fe ff ff 	mov    r10,QWORD PTR [rbp-0x1c8]
   2af77:	e9 08 d0 ff ff       	jmp    27f84 <JS_CallInternal+0x54a4>
   2af7c:	0f 85 41 1d 00 00    	jne    2ccc3 <JS_CallInternal+0xa1e3>
   2af82:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2af89:	48 8b 47 10          	mov    rax,QWORD PTR [rdi+0x10]
   2af8d:	48 8b 80 f0 04 00 00 	mov    rax,QWORD PTR [rax+0x4f0]
   2af94:	48 85 c0             	test   rax,rax
   2af97:	0f 84 16 c6 ff ff    	je     275b3 <JS_CallInternal+0x4ad3>
   2af9d:	f6 40 3c 01          	test   BYTE PTR [rax+0x3c],0x1
   2afa1:	0f 84 0c c6 ff ff    	je     275b3 <JS_CallInternal+0x4ad3>
   2afa7:	44 89 ee             	mov    esi,r13d
   2afaa:	e8 91 7e 00 00       	call   32e40 <JS_ThrowReferenceErrorNotDefined>
   2afaf:	41 81 fd f2 00 00 00 	cmp    r13d,0xf2
   2afb6:	0f 8e c4 82 ff ff    	jle    23280 <JS_CallInternal+0x7a0>
   2afbc:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2afc3:	44 89 ee             	mov    esi,r13d
   2afc6:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2afca:	e8 a1 e4 fe ff       	call   19470 <JS_FreeAtom.part.0.isra.0>
   2afcf:	e9 ac 82 ff ff       	jmp    23280 <JS_CallInternal+0x7a0>
   2afd4:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2afdb:	48 8b 40 10          	mov    rax,QWORD PTR [rax+0x10]
   2afdf:	48 8b 80 f0 04 00 00 	mov    rax,QWORD PTR [rax+0x4f0]
   2afe6:	48 85 c0             	test   rax,rax
   2afe9:	0f 84 b1 0e 00 00    	je     2bea0 <JS_CallInternal+0x93c0>
   2afef:	f6 40 3c 01          	test   BYTE PTR [rax+0x3c],0x1
   2aff3:	0f 84 a7 0e 00 00    	je     2bea0 <JS_CallInternal+0x93c0>
   2aff9:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2b000:	44 89 ee             	mov    esi,r13d
   2b003:	e8 38 7e 00 00       	call   32e40 <JS_ThrowReferenceErrorNotDefined>
   2b008:	41 81 fd f2 00 00 00 	cmp    r13d,0xf2
   2b00f:	0f 8e 6b 82 ff ff    	jle    23280 <JS_CallInternal+0x7a0>
   2b015:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2b01c:	44 89 ee             	mov    esi,r13d
   2b01f:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2b023:	e8 48 e4 fe ff       	call   19470 <JS_FreeAtom.part.0.isra.0>
   2b028:	e9 53 82 ff ff       	jmp    23280 <JS_CallInternal+0x7a0>
   2b02d:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   2b034:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2b03b:	44 89 ea             	mov    edx,r13d
   2b03e:	48 89 de             	mov    rsi,rbx
   2b041:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   2b045:	e8 36 ae 02 00       	call   55e80 <js_binary_logic_slow>
   2b04a:	85 c0                	test   eax,eax
   2b04c:	0f 85 2e 82 ff ff    	jne    23280 <JS_CallInternal+0x7a0>
   2b052:	48 83 eb 10          	sub    rbx,0x10
   2b056:	e9 99 b7 ff ff       	jmp    267f4 <JS_CallInternal+0x3d14>
   2b05b:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2b062:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2b066:	e8 35 18 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2b06b:	e9 c5 c5 ff ff       	jmp    27635 <JS_CallInternal+0x4b55>
   2b070:	41 83 fd 08          	cmp    r13d,0x8
   2b074:	0f 84 ad 14 00 00    	je     2c527 <JS_CallInternal+0x9a47>
   2b07a:	41 83 fd ff          	cmp    r13d,0xffffffff
   2b07e:	0f 84 72 14 00 00    	je     2c4f6 <JS_CallInternal+0x9a16>
   2b084:	41 8d 4d fe          	lea    ecx,[r13-0x2]
   2b088:	83 f9 01             	cmp    ecx,0x1
   2b08b:	0f 86 27 14 00 00    	jbe    2c4b8 <JS_CallInternal+0x99d8>
   2b091:	4c 89 85 38 fe ff ff 	mov    QWORD PTR [rbp-0x1c8],r8
   2b098:	4c 89 8d 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],r9
   2b09f:	41 83 fd f9          	cmp    r13d,0xfffffff9
   2b0a3:	0f 85 37 f0 ff ff    	jne    2a0e0 <JS_CallInternal+0x7600>
   2b0a9:	41 83 f8 f9          	cmp    r8d,0xfffffff9
   2b0ad:	0f 85 2d f0 ff ff    	jne    2a0e0 <JS_CallInternal+0x7600>
   2b0b3:	e8 58 cd fe ff       	call   17e10 <js_string_eq.isra.0>
   2b0b8:	4c 89 f6             	mov    rsi,r14
   2b0bb:	4c 8b b5 e8 fe ff ff 	mov    r14,QWORD PTR [rbp-0x118]
   2b0c2:	4c 89 ea             	mov    rdx,r13
   2b0c5:	89 85 50 fe ff ff    	mov    DWORD PTR [rbp-0x1b0],eax
   2b0cb:	4c 89 f7             	mov    rdi,r14
   2b0ce:	e8 2d 19 ff ff       	call   1ca00 <JS_FreeValue>
   2b0d3:	48 8b b5 40 fe ff ff 	mov    rsi,QWORD PTR [rbp-0x1c0]
   2b0da:	48 8b 95 38 fe ff ff 	mov    rdx,QWORD PTR [rbp-0x1c8]
   2b0e1:	4c 89 f7             	mov    rdi,r14
   2b0e4:	e8 17 19 ff ff       	call   1ca00 <JS_FreeValue>
   2b0e9:	8b 85 50 fe ff ff    	mov    eax,DWORD PTR [rbp-0x1b0]
   2b0ef:	e9 01 b8 ff ff       	jmp    268f5 <JS_CallInternal+0x3e15>
   2b0f4:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2b0fb:	e8 80 80 00 00       	call   33180 <__js_poll_interrupts>
   2b100:	85 c0                	test   eax,eax
   2b102:	0f 84 dd c5 ff ff    	je     276e5 <JS_CallInternal+0x4c05>
   2b108:	4d 89 ec             	mov    r12,r13
   2b10b:	e9 70 81 ff ff       	jmp    23280 <JS_CallInternal+0x7a0>
   2b110:	ba 01 00 00 00       	mov    edx,0x1
   2b115:	be 03 00 00 00       	mov    esi,0x3
   2b11a:	31 ff                	xor    edi,edi
   2b11c:	e9 6f d3 ff ff       	jmp    28490 <JS_CallInternal+0x59b0>
   2b121:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2b128:	48 8d 35 31 24 0a 00 	lea    rsi,[rip+0xa2431]        # cd560 <_IO_stdin_used+0x560>
   2b12f:	31 c0                	xor    eax,eax
   2b131:	e8 ea 5a 00 00       	call   30c20 <JS_ThrowTypeError>
   2b136:	4d 8b 4e 08          	mov    r9,QWORD PTR [r14+0x8]
   2b13a:	4d 8b 2e             	mov    r13,QWORD PTR [r14]
   2b13d:	48 89 c1             	mov    rcx,rax
   2b140:	41 89 d0             	mov    r8d,edx
   2b143:	48 89 d0             	mov    rax,rdx
   2b146:	e9 c1 d1 ff ff       	jmp    2830c <JS_CallInternal+0x582c>
   2b14b:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   2b152:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2b159:	44 89 ea             	mov    edx,r13d
   2b15c:	48 89 de             	mov    rsi,rbx
   2b15f:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   2b163:	e8 18 ad 02 00       	call   55e80 <js_binary_logic_slow>
   2b168:	85 c0                	test   eax,eax
   2b16a:	0f 85 10 81 ff ff    	jne    23280 <JS_CallInternal+0x7a0>
   2b170:	48 83 eb 10          	sub    rbx,0x10
   2b174:	e9 18 c9 ff ff       	jmp    27a91 <JS_CallInternal+0x4fb1>
   2b179:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2b180:	e8 fb 7f 00 00       	call   33180 <__js_poll_interrupts>
   2b185:	85 c0                	test   eax,eax
   2b187:	0f 84 a9 bf ff ff    	je     27136 <JS_CallInternal+0x4656>
   2b18d:	4d 89 ec             	mov    r12,r13
   2b190:	e9 eb 80 ff ff       	jmp    23280 <JS_CallInternal+0x7a0>
   2b195:	4c 89 f3             	mov    rbx,r14
   2b198:	e9 e3 80 ff ff       	jmp    23280 <JS_CallInternal+0x7a0>
   2b19d:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2b1a4:	e8 d7 7f 00 00       	call   33180 <__js_poll_interrupts>
   2b1a9:	85 c0                	test   eax,eax
   2b1ab:	0f 84 e5 cf ff ff    	je     28196 <JS_CallInternal+0x56b6>
   2b1b1:	4d 89 ec             	mov    r12,r13
   2b1b4:	e9 c7 80 ff ff       	jmp    23280 <JS_CallInternal+0x7a0>
   2b1b9:	41 8b 4e 0c          	mov    ecx,DWORD PTR [r14+0xc]
   2b1bd:	e9 01 e2 ff ff       	jmp    293c3 <JS_CallInternal+0x68e3>
   2b1c2:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2b1c9:	4c 89 ee             	mov    rsi,r13
   2b1cc:	4c 89 f2             	mov    rdx,r14
   2b1cf:	44 89 85 50 fe ff ff 	mov    DWORD PTR [rbp-0x1b0],r8d
   2b1d6:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2b1da:	e8 c1 16 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2b1df:	44 8b 85 50 fe ff ff 	mov    r8d,DWORD PTR [rbp-0x1b0]
   2b1e6:	e9 c8 9e ff ff       	jmp    250b3 <JS_CallInternal+0x25d3>
   2b1eb:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2b1f2:	48 8b 95 50 fe ff ff 	mov    rdx,QWORD PTR [rbp-0x1b0]
   2b1f9:	48 89 ce             	mov    rsi,rcx
   2b1fc:	44 89 85 38 fe ff ff 	mov    DWORD PTR [rbp-0x1c8],r8d
   2b203:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2b207:	e8 94 16 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2b20c:	44 8b 85 38 fe ff ff 	mov    r8d,DWORD PTR [rbp-0x1c8]
   2b213:	e9 82 9e ff ff       	jmp    2509a <JS_CallInternal+0x25ba>
   2b218:	83 fe 08             	cmp    esi,0x8
   2b21b:	0f 84 00 11 00 00    	je     2c321 <JS_CallInternal+0x9841>
   2b221:	85 f6                	test   esi,esi
   2b223:	75 09                	jne    2b22e <JS_CallInternal+0x874e>
   2b225:	83 f9 08             	cmp    ecx,0x8
   2b228:	0f 84 cd 0f 00 00    	je     2c1fb <JS_CallInternal+0x971b>
   2b22e:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   2b235:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2b23c:	44 89 ea             	mov    edx,r13d
   2b23f:	48 89 de             	mov    rsi,rbx
   2b242:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   2b246:	e8 e5 fa 02 00       	call   5ad30 <js_relational_slow>
   2b24b:	85 c0                	test   eax,eax
   2b24d:	0f 85 2d 80 ff ff    	jne    23280 <JS_CallInternal+0x7a0>
   2b253:	48 83 eb 10          	sub    rbx,0x10
   2b257:	e9 46 c9 ff ff       	jmp    27ba2 <JS_CallInternal+0x50c2>
   2b25c:	66 0f ef c0          	pxor   xmm0,xmm0
   2b260:	b8 08 00 00 00       	mov    eax,0x8
   2b265:	f2 48 0f 2a c1       	cvtsi2sd xmm0,rcx
   2b26a:	f2 0f 11 43 e0       	movsd  QWORD PTR [rbx-0x20],xmm0
   2b26f:	e9 da bd ff ff       	jmp    2704e <JS_CallInternal+0x456e>
   2b274:	41 83 fb 08          	cmp    r11d,0x8
   2b278:	0f 84 65 10 00 00    	je     2c2e3 <JS_CallInternal+0x9803>
   2b27e:	83 ff 08             	cmp    edi,0x8
   2b281:	0f 84 2a 0e 00 00    	je     2c0b1 <JS_CallInternal+0x95d1>
   2b287:	83 c6 07             	add    esi,0x7
   2b28a:	83 fe 01             	cmp    esi,0x1
   2b28d:	0f 86 93 0f 00 00    	jbe    2c226 <JS_CallInternal+0x9746>
   2b293:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   2b29a:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2b2a1:	48 89 de             	mov    rsi,rbx
   2b2a4:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   2b2a8:	e8 53 b7 02 00       	call   56a00 <js_add_slow>
   2b2ad:	85 c0                	test   eax,eax
   2b2af:	0f 85 cb 7f ff ff    	jne    23280 <JS_CallInternal+0x7a0>
   2b2b5:	48 83 eb 10          	sub    rbx,0x10
   2b2b9:	e9 98 bd ff ff       	jmp    27056 <JS_CallInternal+0x4576>
   2b2be:	4d 89 ec             	mov    r12,r13
   2b2c1:	e9 ba 7f ff ff       	jmp    23280 <JS_CallInternal+0x7a0>
   2b2c6:	4d 89 d4             	mov    r12,r10
   2b2c9:	e9 b2 7f ff ff       	jmp    23280 <JS_CallInternal+0x7a0>
   2b2ce:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   2b2d5:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2b2dc:	44 89 ea             	mov    edx,r13d
   2b2df:	48 89 de             	mov    rsi,rbx
   2b2e2:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   2b2e6:	e8 95 ab 02 00       	call   55e80 <js_binary_logic_slow>
   2b2eb:	85 c0                	test   eax,eax
   2b2ed:	0f 85 8d 7f ff ff    	jne    23280 <JS_CallInternal+0x7a0>
   2b2f3:	48 83 eb 10          	sub    rbx,0x10
   2b2f7:	e9 81 c3 ff ff       	jmp    2767d <JS_CallInternal+0x4b9d>
   2b2fc:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2b303:	e8 78 7e 00 00       	call   33180 <__js_poll_interrupts>
   2b308:	85 c0                	test   eax,eax
   2b30a:	0f 84 ed ce ff ff    	je     281fd <JS_CallInternal+0x571d>
   2b310:	4d 89 ec             	mov    r12,r13
   2b313:	e9 68 7f ff ff       	jmp    23280 <JS_CallInternal+0x7a0>
   2b318:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2b31f:	e8 5c 7e 00 00       	call   33180 <__js_poll_interrupts>
   2b324:	85 c0                	test   eax,eax
   2b326:	0f 84 8b d5 ff ff    	je     288b7 <JS_CallInternal+0x5dd7>
   2b32c:	4d 89 ec             	mov    r12,r13
   2b32f:	e9 4c 7f ff ff       	jmp    23280 <JS_CallInternal+0x7a0>
   2b334:	83 fe 08             	cmp    esi,0x8
   2b337:	0f 84 2b 0f 00 00    	je     2c268 <JS_CallInternal+0x9788>
   2b33d:	85 f6                	test   esi,esi
   2b33f:	75 09                	jne    2b34a <JS_CallInternal+0x886a>
   2b341:	83 f9 08             	cmp    ecx,0x8
   2b344:	0f 84 56 0f 00 00    	je     2c2a0 <JS_CallInternal+0x97c0>
   2b34a:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   2b351:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2b358:	44 89 ea             	mov    edx,r13d
   2b35b:	48 89 de             	mov    rsi,rbx
   2b35e:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   2b362:	e8 c9 f9 02 00       	call   5ad30 <js_relational_slow>
   2b367:	85 c0                	test   eax,eax
   2b369:	0f 85 11 7f ff ff    	jne    23280 <JS_CallInternal+0x7a0>
   2b36f:	48 83 eb 10          	sub    rbx,0x10
   2b373:	e9 b3 c3 ff ff       	jmp    2772b <JS_CallInternal+0x4c4b>
   2b378:	66 0f ef c0          	pxor   xmm0,xmm0
   2b37c:	b8 08 00 00 00       	mov    eax,0x8
   2b381:	f2 48 0f 2a c2       	cvtsi2sd xmm0,rdx
   2b386:	f2 41 0f 11 45 00    	movsd  QWORD PTR [r13+0x0],xmm0
   2b38c:	e9 59 bc ff ff       	jmp    26fea <JS_CallInternal+0x450a>
   2b391:	48 83 eb 10          	sub    rbx,0x10
   2b395:	83 fa 08             	cmp    edx,0x8
   2b398:	0f 84 e5 12 00 00    	je     2c683 <JS_CallInternal+0x9ba3>
   2b39e:	83 fa f9             	cmp    edx,0xfffffff9
   2b3a1:	0f 84 24 0b 00 00    	je     2becb <JS_CallInternal+0x93eb>
   2b3a7:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   2b3ae:	4c 89 48 30          	mov    QWORD PTR [rax+0x30],r9
   2b3b2:	49 8b 45 00          	mov    rax,QWORD PTR [r13+0x0]
   2b3b6:	83 fa f6             	cmp    edx,0xfffffff6
   2b3b9:	0f 87 25 0b 00 00    	ja     2bee4 <JS_CallInternal+0x9404>
   2b3bf:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2b3c6:	48 8d b5 70 ff ff ff 	lea    rsi,[rbp-0x90]
   2b3cd:	4c 89 8d 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],r9
   2b3d4:	48 89 85 50 ff ff ff 	mov    QWORD PTR [rbp-0xb0],rax
   2b3db:	48 89 95 58 ff ff ff 	mov    QWORD PTR [rbp-0xa8],rdx
   2b3e2:	4c 89 85 60 ff ff ff 	mov    QWORD PTR [rbp-0xa0],r8
   2b3e9:	4c 89 b5 68 ff ff ff 	mov    QWORD PTR [rbp-0x98],r14
   2b3f0:	e8 0b b6 02 00       	call   56a00 <js_add_slow>
   2b3f5:	4c 8b 8d 50 fe ff ff 	mov    r9,QWORD PTR [rbp-0x1b0]
   2b3fc:	85 c0                	test   eax,eax
   2b3fe:	0f 85 e7 17 00 00    	jne    2cbeb <JS_CallInternal+0xa10b>
   2b404:	49 8b 55 08          	mov    rdx,QWORD PTR [r13+0x8]
   2b408:	66 0f 6f bd 50 ff ff 	movdqa xmm7,XMMWORD PTR [rbp-0xb0]
   2b40f:	ff 
   2b410:	49 8b 75 00          	mov    rsi,QWORD PTR [r13+0x0]
   2b414:	41 0f 11 7d 00       	movups XMMWORD PTR [r13+0x0],xmm7
   2b419:	83 fa f6             	cmp    edx,0xfffffff6
   2b41c:	0f 86 d0 bb ff ff    	jbe    26ff2 <JS_CallInternal+0x4512>
   2b422:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   2b425:	83 e8 01             	sub    eax,0x1
   2b428:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   2b42b:	85 c0                	test   eax,eax
   2b42d:	0f 8f bf bb ff ff    	jg     26ff2 <JS_CallInternal+0x4512>
   2b433:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2b43a:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2b43e:	e8 5d 14 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2b443:	e9 aa bb ff ff       	jmp    26ff2 <JS_CallInternal+0x4512>
   2b448:	4d 89 ec             	mov    r12,r13
   2b44b:	e9 30 7e ff ff       	jmp    23280 <JS_CallInternal+0x7a0>
   2b450:	41 83 fd fa          	cmp    r13d,0xfffffffa
   2b454:	0f 8d 9a e9 ff ff    	jge    29df4 <JS_CallInternal+0x7314>
   2b45a:	41 83 fd f8          	cmp    r13d,0xfffffff8
   2b45e:	0f 8c 90 e9 ff ff    	jl     29df4 <JS_CallInternal+0x7314>
   2b464:	e9 e4 e9 ff ff       	jmp    29e4d <JS_CallInternal+0x736d>
   2b469:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]
   2b470:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2b477:	48 8d 35 e2 20 0a 00 	lea    rsi,[rip+0xa20e2]        # cd560 <_IO_stdin_used+0x560>
   2b47e:	31 c0                	xor    eax,eax
   2b480:	e8 9b 57 00 00       	call   30c20 <JS_ThrowTypeError>
   2b485:	e9 92 b5 ff ff       	jmp    26a1c <JS_CallInternal+0x3f3c>
   2b48a:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2b491:	48 8d 35 ba 20 0a 00 	lea    rsi,[rip+0xa20ba]        # cd552 <_IO_stdin_used+0x552>
   2b498:	31 c0                	xor    eax,eax
   2b49a:	e8 81 57 00 00       	call   30c20 <JS_ThrowTypeError>
   2b49f:	83 bd 50 fe ff ff f6 	cmp    DWORD PTR [rbp-0x1b0],0xfffffff6
   2b4a6:	76 13                	jbe    2b4bb <JS_CallInternal+0x89db>
   2b4a8:	41 8b 45 fc          	mov    eax,DWORD PTR [r13-0x4]
   2b4ac:	83 e8 01             	sub    eax,0x1
   2b4af:	41 89 45 fc          	mov    DWORD PTR [r13-0x4],eax
   2b4b3:	85 c0                	test   eax,eax
   2b4b5:	0f 8e 6c 13 00 00    	jle    2c827 <JS_CallInternal+0x9d47>
   2b4bb:	41 bd ff ff ff ff    	mov    r13d,0xffffffff
   2b4c1:	e9 80 b6 ff ff       	jmp    26b46 <JS_CallInternal+0x4066>
   2b4c6:	48 8b bd 38 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x1c8]
   2b4cd:	e8 ce 13 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2b4d2:	e9 6c b6 ff ff       	jmp    26b43 <JS_CallInternal+0x4063>
   2b4d7:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   2b4de:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2b4e5:	44 89 ea             	mov    edx,r13d
   2b4e8:	48 89 de             	mov    rsi,rbx
   2b4eb:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   2b4ef:	e8 8c a9 02 00       	call   55e80 <js_binary_logic_slow>
   2b4f4:	85 c0                	test   eax,eax
   2b4f6:	0f 85 84 7d ff ff    	jne    23280 <JS_CallInternal+0x7a0>
   2b4fc:	48 83 eb 10          	sub    rbx,0x10
   2b500:	e9 b2 b2 ff ff       	jmp    267b7 <JS_CallInternal+0x3cd7>
   2b505:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2b50c:	48 8d 35 3f 20 0a 00 	lea    rsi,[rip+0xa203f]        # cd552 <_IO_stdin_used+0x552>
   2b513:	31 c0                	xor    eax,eax
   2b515:	e8 06 57 00 00       	call   30c20 <JS_ThrowTypeError>
   2b51a:	e9 fd b4 ff ff       	jmp    26a1c <JS_CallInternal+0x3f3c>
   2b51f:	44 8b 95 50 fe ff ff 	mov    r10d,DWORD PTR [rbp-0x1b0]
   2b526:	45 85 d2             	test   r10d,r10d
   2b529:	74 3d                	je     2b568 <JS_CallInternal+0x8a88>
   2b52b:	4c 8b a5 e8 fe ff ff 	mov    r12,QWORD PTR [rbp-0x118]
   2b532:	4c 89 eb             	mov    rbx,r13
   2b535:	4d 01 ee             	add    r14,r13
   2b538:	eb 09                	jmp    2b543 <JS_CallInternal+0x8a63>
   2b53a:	48 83 c3 10          	add    rbx,0x10
   2b53e:	4c 39 f3             	cmp    rbx,r14
   2b541:	74 25                	je     2b568 <JS_CallInternal+0x8a88>
   2b543:	48 8b 53 08          	mov    rdx,QWORD PTR [rbx+0x8]
   2b547:	48 8b 33             	mov    rsi,QWORD PTR [rbx]
   2b54a:	83 fa f6             	cmp    edx,0xfffffff6
   2b54d:	76 eb                	jbe    2b53a <JS_CallInternal+0x8a5a>
   2b54f:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   2b552:	83 e8 01             	sub    eax,0x1
   2b555:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   2b558:	85 c0                	test   eax,eax
   2b55a:	7f de                	jg     2b53a <JS_CallInternal+0x8a5a>
   2b55c:	49 8b 7c 24 10       	mov    rdi,QWORD PTR [r12+0x10]
   2b561:	e8 3a 13 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2b566:	eb d2                	jmp    2b53a <JS_CallInternal+0x8a5a>
   2b568:	4c 8b a5 38 fe ff ff 	mov    r12,QWORD PTR [rbp-0x1c8]
   2b56f:	4c 89 eb             	mov    rbx,r13
   2b572:	e9 09 7d ff ff       	jmp    23280 <JS_CallInternal+0x7a0>
   2b577:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2b57e:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2b582:	e8 19 13 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2b587:	e9 f3 db ff ff       	jmp    2917f <JS_CallInternal+0x669f>
   2b58c:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2b593:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2b597:	e8 04 13 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2b59c:	e9 77 c0 ff ff       	jmp    27618 <JS_CallInternal+0x4b38>
   2b5a1:	66 0f ef c0          	pxor   xmm0,xmm0
   2b5a5:	f2 48 0f 2a c0       	cvtsi2sd xmm0,rax
   2b5aa:	b8 08 00 00 00       	mov    eax,0x8
   2b5af:	f2 0f 11 43 e0       	movsd  QWORD PTR [rbx-0x20],xmm0
   2b5b4:	e9 bd b9 ff ff       	jmp    26f76 <JS_CallInternal+0x4496>
   2b5b9:	83 fa 08             	cmp    edx,0x8
   2b5bc:	0f 84 7a 13 00 00    	je     2c93c <JS_CallInternal+0x9e5c>
   2b5c2:	83 f8 08             	cmp    eax,0x8
   2b5c5:	0f 85 0c 86 ff ff    	jne    23bd7 <JS_CallInternal+0x10f7>
   2b5cb:	85 d2                	test   edx,edx
   2b5cd:	0f 85 04 86 ff ff    	jne    23bd7 <JS_CallInternal+0x10f7>
   2b5d3:	66 0f ef c0          	pxor   xmm0,xmm0
   2b5d7:	f2 0f 2a c7          	cvtsi2sd xmm0,edi
   2b5db:	66 48 0f 6e c9       	movq   xmm1,rcx
   2b5e0:	f2 0f 5c c1          	subsd  xmm0,xmm1
   2b5e4:	48 8d 53 f0          	lea    rdx,[rbx-0x10]
   2b5e8:	b8 08 00 00 00       	mov    eax,0x8
   2b5ed:	f2 0f 11 43 e0       	movsd  QWORD PTR [rbx-0x20],xmm0
   2b5f2:	e9 83 b9 ff ff       	jmp    26f7a <JS_CallInternal+0x449a>
   2b5f7:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2b5fe:	31 c0                	xor    eax,eax
   2b600:	48 8d 35 41 1f 0a 00 	lea    rsi,[rip+0xa1f41]        # cd548 <_IO_stdin_used+0x548>
   2b607:	e8 f4 79 00 00       	call   33000 <JS_ThrowInternalError>
   2b60c:	83 fb f6             	cmp    ebx,0xfffffff6
   2b60f:	76 13                	jbe    2b624 <JS_CallInternal+0x8b44>
   2b611:	41 8b 45 fc          	mov    eax,DWORD PTR [r13-0x4]
   2b615:	83 e8 01             	sub    eax,0x1
   2b618:	41 89 45 fc          	mov    DWORD PTR [r13-0x4],eax
   2b61c:	85 c0                	test   eax,eax
   2b61e:	0f 8e 42 0d 00 00    	jle    2c366 <JS_CallInternal+0x9886>
   2b624:	4c 89 f3             	mov    rbx,r14
   2b627:	e9 54 7c ff ff       	jmp    23280 <JS_CallInternal+0x7a0>
   2b62c:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2b633:	48 8b 95 50 fe ff ff 	mov    rdx,QWORD PTR [rbp-0x1b0]
   2b63a:	4c 89 f6             	mov    rsi,r14
   2b63d:	44 89 85 38 fe ff ff 	mov    DWORD PTR [rbp-0x1c8],r8d
   2b644:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2b648:	e8 53 12 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2b64d:	44 8b 85 38 fe ff ff 	mov    r8d,DWORD PTR [rbp-0x1c8]
   2b654:	e9 2c b8 ff ff       	jmp    26e85 <JS_CallInternal+0x43a5>
   2b659:	48 8b 85 d8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x128]
   2b660:	48 8d 15 33 1e 0a 00 	lea    rdx,[rip+0xa1e33]        # cd49a <_IO_stdin_used+0x49a>
   2b667:	48 8b 40 30          	mov    rax,QWORD PTR [rax+0x30]
   2b66b:	8b 44 08 04          	mov    eax,DWORD PTR [rax+rcx*1+0x4]
   2b66f:	85 c0                	test   eax,eax
   2b671:	0f 85 e8 12 00 00    	jne    2c95f <JS_CallInternal+0x9e7f>
   2b677:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2b67e:	48 8d 35 71 1e 0a 00 	lea    rsi,[rip+0xa1e71]        # cd4f6 <_IO_stdin_used+0x4f6>
   2b685:	31 c0                	xor    eax,eax
   2b687:	4d 89 ec             	mov    r12,r13
   2b68a:	e8 81 76 00 00       	call   32d10 <JS_ThrowReferenceError>
   2b68f:	e9 ec 7b ff ff       	jmp    23280 <JS_CallInternal+0x7a0>
   2b694:	41 83 f8 08          	cmp    r8d,0x8
   2b698:	0f 84 67 0d 00 00    	je     2c405 <JS_CallInternal+0x9925>
   2b69e:	41 83 f8 ff          	cmp    r8d,0xffffffff
   2b6a2:	0f 84 17 0d 00 00    	je     2c3bf <JS_CallInternal+0x98df>
   2b6a8:	41 8d 48 fe          	lea    ecx,[r8-0x2]
   2b6ac:	83 f9 01             	cmp    ecx,0x1
   2b6af:	0f 86 5a 16 00 00    	jbe    2cd0f <JS_CallInternal+0xa22f>
   2b6b5:	41 83 f8 f9          	cmp    r8d,0xfffffff9
   2b6b9:	0f 85 c2 0c 00 00    	jne    2c381 <JS_CallInternal+0x98a1>
   2b6bf:	41 83 fe f9          	cmp    r14d,0xfffffff9
   2b6c3:	0f 85 b8 0c 00 00    	jne    2c381 <JS_CallInternal+0x98a1>
   2b6c9:	4c 89 ee             	mov    rsi,r13
   2b6cc:	48 89 95 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],rdx
   2b6d3:	4c 89 85 38 fe ff ff 	mov    QWORD PTR [rbp-0x1c8],r8
   2b6da:	e8 31 c7 fe ff       	call   17e10 <js_string_eq.isra.0>
   2b6df:	48 8b b5 40 fe ff ff 	mov    rsi,QWORD PTR [rbp-0x1c0]
   2b6e6:	48 8b 95 38 fe ff ff 	mov    rdx,QWORD PTR [rbp-0x1c8]
   2b6ed:	89 85 50 fe ff ff    	mov    DWORD PTR [rbp-0x1b0],eax
   2b6f3:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2b6fa:	e8 01 13 ff ff       	call   1ca00 <JS_FreeValue>
   2b6ff:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2b706:	4c 89 ee             	mov    rsi,r13
   2b709:	4c 89 f2             	mov    rdx,r14
   2b70c:	e8 ef 12 ff ff       	call   1ca00 <JS_FreeValue>
   2b711:	8b 85 50 fe ff ff    	mov    eax,DWORD PTR [rbp-0x1b0]
   2b717:	85 c0                	test   eax,eax
   2b719:	0f 95 c0             	setne  al
   2b71c:	0f b6 c0             	movzx  eax,al
   2b71f:	e9 6f c2 ff ff       	jmp    27993 <JS_CallInternal+0x4eb3>
   2b724:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2b72b:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2b72f:	e8 6c 11 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2b734:	e9 d4 96 ff ff       	jmp    24e0d <JS_CallInternal+0x232d>
   2b739:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2b740:	48 8d 35 19 1e 0a 00 	lea    rsi,[rip+0xa1e19]        # cd560 <_IO_stdin_used+0x560>
   2b747:	31 c0                	xor    eax,eax
   2b749:	e8 d2 54 00 00       	call   30c20 <JS_ThrowTypeError>
   2b74e:	e9 4c fd ff ff       	jmp    2b49f <JS_CallInternal+0x89bf>
   2b753:	41 83 fd 08          	cmp    r13d,0x8
   2b757:	0f 84 c5 0f 00 00    	je     2c722 <JS_CallInternal+0x9c42>
   2b75d:	41 83 fd ff          	cmp    r13d,0xffffffff
   2b761:	0f 84 54 0f 00 00    	je     2c6bb <JS_CallInternal+0x9bdb>
   2b767:	41 8d 4d fe          	lea    ecx,[r13-0x2]
   2b76b:	83 f9 01             	cmp    ecx,0x1
   2b76e:	0f 86 d9 0f 00 00    	jbe    2c74d <JS_CallInternal+0x9c6d>
   2b774:	4c 89 85 38 fe ff ff 	mov    QWORD PTR [rbp-0x1c8],r8
   2b77b:	4c 89 8d 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],r9
   2b782:	41 83 fd f9          	cmp    r13d,0xfffffff9
   2b786:	0f 85 22 e9 ff ff    	jne    2a0ae <JS_CallInternal+0x75ce>
   2b78c:	41 83 f8 f9          	cmp    r8d,0xfffffff9
   2b790:	0f 85 18 e9 ff ff    	jne    2a0ae <JS_CallInternal+0x75ce>
   2b796:	e8 75 c6 fe ff       	call   17e10 <js_string_eq.isra.0>
   2b79b:	4c 89 f6             	mov    rsi,r14
   2b79e:	4c 8b b5 e8 fe ff ff 	mov    r14,QWORD PTR [rbp-0x118]
   2b7a5:	4c 89 ea             	mov    rdx,r13
   2b7a8:	89 85 50 fe ff ff    	mov    DWORD PTR [rbp-0x1b0],eax
   2b7ae:	4c 89 f7             	mov    rdi,r14
   2b7b1:	e8 4a 12 ff ff       	call   1ca00 <JS_FreeValue>
   2b7b6:	48 8b b5 40 fe ff ff 	mov    rsi,QWORD PTR [rbp-0x1c0]
   2b7bd:	48 8b 95 38 fe ff ff 	mov    rdx,QWORD PTR [rbp-0x1c8]
   2b7c4:	4c 89 f7             	mov    rdi,r14
   2b7c7:	e8 34 12 ff ff       	call   1ca00 <JS_FreeValue>
   2b7cc:	8b 85 50 fe ff ff    	mov    eax,DWORD PTR [rbp-0x1b0]
   2b7d2:	85 c0                	test   eax,eax
   2b7d4:	0f 95 c0             	setne  al
   2b7d7:	e9 79 b1 ff ff       	jmp    26955 <JS_CallInternal+0x3e75>
   2b7dc:	0f 1f 40 00          	nop    DWORD PTR [rax+0x0]
   2b7e0:	4c 89 f3             	mov    rbx,r14
   2b7e3:	4d 89 ec             	mov    r12,r13
   2b7e6:	e9 95 7a ff ff       	jmp    23280 <JS_CallInternal+0x7a0>
   2b7eb:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   2b7f2:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2b7f9:	44 89 ea             	mov    edx,r13d
   2b7fc:	48 89 de             	mov    rsi,rbx
   2b7ff:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   2b803:	e8 78 a6 02 00       	call   55e80 <js_binary_logic_slow>
   2b808:	85 c0                	test   eax,eax
   2b80a:	0f 85 70 7a ff ff    	jne    23280 <JS_CallInternal+0x7a0>
   2b810:	48 83 eb 10          	sub    rbx,0x10
   2b814:	e9 b5 c2 ff ff       	jmp    27ace <JS_CallInternal+0x4fee>
   2b819:	48 8b b5 d8 fe ff ff 	mov    rsi,QWORD PTR [rbp-0x128]
   2b820:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2b827:	31 c9                	xor    ecx,ecx
   2b829:	4d 89 ec             	mov    r12,r13
   2b82c:	e8 6f 76 00 00       	call   32ea0 <JS_ThrowReferenceErrorUninitialized2.isra.0>
   2b831:	e9 4a 7a ff ff       	jmp    23280 <JS_CallInternal+0x7a0>
   2b836:	48 8b b5 d8 fe ff ff 	mov    rsi,QWORD PTR [rbp-0x128]
   2b83d:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2b844:	31 c9                	xor    ecx,ecx
   2b846:	4d 89 ec             	mov    r12,r13
   2b849:	e8 52 76 00 00       	call   32ea0 <JS_ThrowReferenceErrorUninitialized2.isra.0>
   2b84e:	e9 2d 7a ff ff       	jmp    23280 <JS_CallInternal+0x7a0>
   2b853:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   2b85a:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2b861:	48 89 de             	mov    rsi,rbx
   2b864:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   2b868:	e8 43 a4 02 00       	call   55cb0 <js_shr_slow>
   2b86d:	85 c0                	test   eax,eax
   2b86f:	0f 85 0b 7a ff ff    	jne    23280 <JS_CallInternal+0x7a0>
   2b875:	48 83 eb 10          	sub    rbx,0x10
   2b879:	e9 be af ff ff       	jmp    2683c <JS_CallInternal+0x3d5c>
   2b87e:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2b885:	e8 f6 78 00 00       	call   33180 <__js_poll_interrupts>
   2b88a:	85 c0                	test   eax,eax
   2b88c:	0f 84 65 d0 ff ff    	je     288f7 <JS_CallInternal+0x5e17>
   2b892:	4d 89 ec             	mov    r12,r13
   2b895:	e9 e6 79 ff ff       	jmp    23280 <JS_CallInternal+0x7a0>
   2b89a:	83 fe 08             	cmp    esi,0x8
   2b89d:	0f 84 0d 11 00 00    	je     2c9b0 <JS_CallInternal+0x9ed0>
   2b8a3:	83 f9 08             	cmp    ecx,0x8
   2b8a6:	75 08                	jne    2b8b0 <JS_CallInternal+0x8dd0>
   2b8a8:	85 f6                	test   esi,esi
   2b8aa:	0f 84 40 11 00 00    	je     2c9f0 <JS_CallInternal+0x9f10>
   2b8b0:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   2b8b7:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2b8be:	44 89 ea             	mov    edx,r13d
   2b8c1:	48 89 de             	mov    rsi,rbx
   2b8c4:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   2b8c8:	e8 63 f4 02 00       	call   5ad30 <js_relational_slow>
   2b8cd:	85 c0                	test   eax,eax
   2b8cf:	0f 85 ab 79 ff ff    	jne    23280 <JS_CallInternal+0x7a0>
   2b8d5:	48 83 eb 10          	sub    rbx,0x10
   2b8d9:	e9 b2 c3 ff ff       	jmp    27c90 <JS_CallInternal+0x51b0>
   2b8de:	83 fe 08             	cmp    esi,0x8
   2b8e1:	0f 84 5f 0f 00 00    	je     2c846 <JS_CallInternal+0x9d66>
   2b8e7:	85 f6                	test   esi,esi
   2b8e9:	75 09                	jne    2b8f4 <JS_CallInternal+0x8e14>
   2b8eb:	83 f9 08             	cmp    ecx,0x8
   2b8ee:	0f 84 8a 0f 00 00    	je     2c87e <JS_CallInternal+0x9d9e>
   2b8f4:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   2b8fb:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2b902:	44 89 ea             	mov    edx,r13d
   2b905:	48 89 de             	mov    rsi,rbx
   2b908:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   2b90c:	e8 1f f4 02 00       	call   5ad30 <js_relational_slow>
   2b911:	85 c0                	test   eax,eax
   2b913:	0f 85 67 79 ff ff    	jne    23280 <JS_CallInternal+0x7a0>
   2b919:	48 83 eb 10          	sub    rbx,0x10
   2b91d:	e9 5a b8 ff ff       	jmp    2717c <JS_CallInternal+0x469c>
   2b922:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2b929:	e8 52 78 00 00       	call   33180 <__js_poll_interrupts>
   2b92e:	85 c0                	test   eax,eax
   2b930:	0f 84 07 c9 ff ff    	je     2823d <JS_CallInternal+0x575d>
   2b936:	4d 89 ec             	mov    r12,r13
   2b939:	e9 42 79 ff ff       	jmp    23280 <JS_CallInternal+0x7a0>
   2b93e:	4c 89 f3             	mov    rbx,r14
   2b941:	4d 89 ec             	mov    r12,r13
   2b944:	e9 37 79 ff ff       	jmp    23280 <JS_CallInternal+0x7a0>
   2b949:	48 8b b5 d8 fe ff ff 	mov    rsi,QWORD PTR [rbp-0x128]
   2b950:	48 8b bd a0 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x160]
   2b957:	0f b7 d1             	movzx  edx,cx
   2b95a:	31 c9                	xor    ecx,ecx
   2b95c:	4d 89 ec             	mov    r12,r13
   2b95f:	e8 3c 75 00 00       	call   32ea0 <JS_ThrowReferenceErrorUninitialized2.isra.0>
   2b964:	e9 17 79 ff ff       	jmp    23280 <JS_CallInternal+0x7a0>
   2b969:	0f 85 30 11 00 00    	jne    2ca9f <JS_CallInternal+0x9fbf>
   2b96f:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2b976:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2b97a:	48 8b 87 f0 04 00 00 	mov    rax,QWORD PTR [rdi+0x4f0]
   2b981:	48 85 c0             	test   rax,rax
   2b984:	0f 84 7e 05 00 00    	je     2bf08 <JS_CallInternal+0x9428>
   2b98a:	f6 40 3c 01          	test   BYTE PTR [rax+0x3c],0x1
   2b98e:	0f 84 74 05 00 00    	je     2bf08 <JS_CallInternal+0x9428>
   2b994:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2b99b:	44 89 ee             	mov    esi,r13d
   2b99e:	e8 9d 74 00 00       	call   32e40 <JS_ThrowReferenceErrorNotDefined>
   2b9a3:	41 81 fd f2 00 00 00 	cmp    r13d,0xf2
   2b9aa:	0f 8e d0 78 ff ff    	jle    23280 <JS_CallInternal+0x7a0>
   2b9b0:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2b9b7:	44 89 ee             	mov    esi,r13d
   2b9ba:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2b9be:	e8 ad da fe ff       	call   19470 <JS_FreeAtom.part.0.isra.0>
   2b9c3:	e9 b8 78 ff ff       	jmp    23280 <JS_CallInternal+0x7a0>
   2b9c8:	4c 8b b5 e8 fe ff ff 	mov    r14,QWORD PTR [rbp-0x118]
   2b9cf:	48 8d 75 80          	lea    rsi,[rbp-0x80]
   2b9d3:	44 89 ea             	mov    edx,r13d
   2b9d6:	49 8b 7e 10          	mov    rdi,QWORD PTR [r14+0x10]
   2b9da:	e8 31 b9 fe ff       	call   17310 <JS_AtomGetStrRT.constprop.0>
   2b9df:	48 8d 35 a7 1b 0a 00 	lea    rsi,[rip+0xa1ba7]        # cd58d <_IO_stdin_used+0x58d>
   2b9e6:	4c 89 f7             	mov    rdi,r14
   2b9e9:	48 89 c2             	mov    rdx,rax
   2b9ec:	31 c0                	xor    eax,eax
   2b9ee:	e8 1d 73 00 00       	call   32d10 <JS_ThrowReferenceError>
   2b9f3:	41 81 fd f2 00 00 00 	cmp    r13d,0xf2
   2b9fa:	0f 8e 80 78 ff ff    	jle    23280 <JS_CallInternal+0x7a0>
   2ba00:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2ba07:	44 89 ee             	mov    esi,r13d
   2ba0a:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2ba0e:	e8 5d da fe ff       	call   19470 <JS_FreeAtom.part.0.isra.0>
   2ba13:	e9 68 78 ff ff       	jmp    23280 <JS_CallInternal+0x7a0>
   2ba18:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2ba1f:	48 89 ce             	mov    rsi,rcx
   2ba22:	4c 89 ea             	mov    rdx,r13
   2ba25:	44 89 85 50 fe ff ff 	mov    DWORD PTR [rbp-0x1b0],r8d
   2ba2c:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2ba30:	e8 6b 0e ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2ba35:	44 8b 85 50 fe ff ff 	mov    r8d,DWORD PTR [rbp-0x1b0]
   2ba3c:	e9 68 b4 ff ff       	jmp    26ea9 <JS_CallInternal+0x43c9>
   2ba41:	66 0f ef c0          	pxor   xmm0,xmm0
   2ba45:	f2 48 0f 2a c0       	cvtsi2sd xmm0,rax
   2ba4a:	f2 0f 11 43 e0       	movsd  QWORD PTR [rbx-0x20],xmm0
   2ba4f:	48 8d 53 f0          	lea    rdx,[rbx-0x10]
   2ba53:	b8 08 00 00 00       	mov    eax,0x8
   2ba58:	e9 c1 b4 ff ff       	jmp    26f1e <JS_CallInternal+0x443e>
   2ba5d:	83 fe 08             	cmp    esi,0x8
   2ba60:	0f 84 26 0d 00 00    	je     2c78c <JS_CallInternal+0x9cac>
   2ba66:	83 f8 08             	cmp    eax,0x8
   2ba69:	0f 85 68 81 ff ff    	jne    23bd7 <JS_CallInternal+0x10f7>
   2ba6f:	85 f6                	test   esi,esi
   2ba71:	0f 85 60 81 ff ff    	jne    23bd7 <JS_CallInternal+0x10f7>
   2ba77:	66 0f ef c9          	pxor   xmm1,xmm1
   2ba7b:	f2 0f 2a c9          	cvtsi2sd xmm1,ecx
   2ba7f:	66 48 0f 6e c2       	movq   xmm0,rdx
   2ba84:	f2 0f 59 c1          	mulsd  xmm0,xmm1
   2ba88:	eb c0                	jmp    2ba4a <JS_CallInternal+0x8f6a>
   2ba8a:	48 8b b5 d8 fe ff ff 	mov    rsi,QWORD PTR [rbp-0x128]
   2ba91:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2ba98:	0f b7 d1             	movzx  edx,cx
   2ba9b:	31 c9                	xor    ecx,ecx
   2ba9d:	4d 89 ec             	mov    r12,r13
   2baa0:	e8 fb 73 00 00       	call   32ea0 <JS_ThrowReferenceErrorUninitialized2.isra.0>
   2baa5:	e9 d6 77 ff ff       	jmp    23280 <JS_CallInternal+0x7a0>
   2baaa:	4c 89 f3             	mov    rbx,r14
   2baad:	e9 ce 77 ff ff       	jmp    23280 <JS_CallInternal+0x7a0>
   2bab2:	8b 01                	mov    eax,DWORD PTR [rcx]
   2bab4:	25 ff ff ff 03       	and    eax,0x3ffffff
   2bab9:	0f 85 3c b0 ff ff    	jne    26afb <JS_CallInternal+0x401b>
   2babf:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2bac6:	48 8d 0d 77 16 0a 00 	lea    rcx,[rip+0xa1677]        # cd144 <_IO_stdin_used+0x144>
   2bacd:	31 c0                	xor    eax,eax
   2bacf:	48 8d 15 12 53 0a 00 	lea    rdx,[rip+0xa5312]        # d0de8 <_IO_stdin_used+0x3de8>
   2bad6:	e8 55 53 00 00       	call   30e30 <__JS_ThrowTypeErrorAtom>
   2badb:	e9 bf f9 ff ff       	jmp    2b49f <JS_CallInternal+0x89bf>
   2bae0:	09 ca                	or     edx,ecx
   2bae2:	0f 89 29 b4 ff ff    	jns    26f11 <JS_CallInternal+0x4431>
   2bae8:	f2 0f 10 05 b0 ef 0a 	movsd  xmm0,QWORD PTR [rip+0xaefb0]        # daaa0 <typed_array_size_log2+0x28>
   2baef:	00 
   2baf0:	e9 55 ff ff ff       	jmp    2ba4a <JS_CallInternal+0x8f6a>
   2baf5:	39 c2                	cmp    edx,eax
   2baf7:	0f 85 f6 de ff ff    	jne    299f3 <JS_CallInternal+0x6f13>
   2bafd:	0f b6 51 10          	movzx  edx,BYTE PTR [rcx+0x10]
   2bb01:	f7 d2                	not    edx
   2bb03:	83 e2 12             	and    edx,0x12
   2bb06:	0f 85 e7 de ff ff    	jne    299f3 <JS_CallInternal+0x6f13>
   2bb0c:	48 8b 79 18          	mov    rdi,QWORD PTR [rcx+0x18]
   2bb10:	48 8b 57 30          	mov    rdx,QWORD PTR [rdi+0x30]
   2bb14:	48 85 d2             	test   rdx,rdx
   2bb17:	74 0a                	je     2bb23 <JS_CallInternal+0x9043>
   2bb19:	f6 42 10 01          	test   BYTE PTR [rdx+0x10],0x1
   2bb1d:	0f 84 d0 de ff ff    	je     299f3 <JS_CallInternal+0x6f13>
   2bb23:	48 8b 71 20          	mov    rsi,QWORD PTR [rcx+0x20]
   2bb27:	44 8b 56 08          	mov    r10d,DWORD PTR [rsi+0x8]
   2bb2b:	45 85 d2             	test   r10d,r10d
   2bb2e:	0f 85 bf de ff ff    	jne    299f3 <JS_CallInternal+0x6f13>
   2bb34:	8d 50 01             	lea    edx,[rax+0x1]
   2bb37:	39 51 28             	cmp    DWORD PTR [rcx+0x28],edx
   2bb3a:	0f 82 b3 de ff ff    	jb     299f3 <JS_CallInternal+0x6f13>
   2bb40:	39 16                	cmp    DWORD PTR [rsi],edx
   2bb42:	73 1c                	jae    2bb60 <JS_CallInternal+0x9080>
   2bb44:	44 8b 47 18          	mov    r8d,DWORD PTR [rdi+0x18]
   2bb48:	42 f6 44 87 3f 08    	test   BYTE PTR [rdi+r8*4+0x3f],0x8
   2bb4e:	0f 84 9f de ff ff    	je     299f3 <JS_CallInternal+0x6f13>
   2bb54:	89 d7                	mov    edi,edx
   2bb56:	45 31 c9             	xor    r9d,r9d
   2bb59:	48 89 3e             	mov    QWORD PTR [rsi],rdi
   2bb5c:	4c 89 4e 08          	mov    QWORD PTR [rsi+0x8],r9
   2bb60:	89 51 38             	mov    DWORD PTR [rcx+0x38],edx
   2bb63:	89 c0                	mov    eax,eax
   2bb65:	f3 0f 6f 73 f0       	movdqu xmm6,XMMWORD PTR [rbx-0x10]
   2bb6a:	48 c1 e0 04          	shl    rax,0x4
   2bb6e:	48 03 41 30          	add    rax,QWORD PTR [rcx+0x30]
   2bb72:	0f 11 30             	movups XMMWORD PTR [rax],xmm6
   2bb75:	e9 92 c5 ff ff       	jmp    2810c <JS_CallInternal+0x562c>
   2bb7a:	66 0f 1f 44 00 00    	nop    WORD PTR [rax+rax*1+0x0]
   2bb80:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2bb87:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2bb8b:	e8 10 0d ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2bb90:	e9 98 c5 ff ff       	jmp    2812d <JS_CallInternal+0x564d>
   2bb95:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2bb9c:	89 8d 50 fe ff ff    	mov    DWORD PTR [rbp-0x1b0],ecx
   2bba2:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2bba6:	e8 f5 0c ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2bbab:	8b 8d 50 fe ff ff    	mov    ecx,DWORD PTR [rbp-0x1b0]
   2bbb1:	e9 6d be ff ff       	jmp    27a23 <JS_CallInternal+0x4f43>
   2bbb6:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2bbbd:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2bbc1:	e8 da 0c ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2bbc6:	e9 14 bc ff ff       	jmp    277df <JS_CallInternal+0x4cff>
   2bbcb:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2bbd2:	4c 89 ee             	mov    rsi,r13
   2bbd5:	4c 89 f2             	mov    rdx,r14
   2bbd8:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2bbdc:	e8 bf 0c ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2bbe1:	e9 12 bc ff ff       	jmp    277f8 <JS_CallInternal+0x4d18>
   2bbe6:	8b 01                	mov    eax,DWORD PTR [rcx]
   2bbe8:	25 ff ff ff 03       	and    eax,0x3ffffff
   2bbed:	0f 85 e6 c6 ff ff    	jne    282d9 <JS_CallInternal+0x57f9>
   2bbf3:	48 8b bd 28 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x1d8]
   2bbfa:	48 8d 75 80          	lea    rsi,[rbp-0x80]
   2bbfe:	e8 0d b7 fe ff       	call   17310 <JS_AtomGetStrRT.constprop.0>
   2bc03:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2bc0a:	48 8d 35 d7 51 0a 00 	lea    rsi,[rip+0xa51d7]        # d0de8 <_IO_stdin_used+0x3de8>
   2bc11:	48 89 c2             	mov    rdx,rax
   2bc14:	31 c0                	xor    eax,eax
   2bc16:	e8 05 50 00 00       	call   30c20 <JS_ThrowTypeError>
   2bc1b:	4d 8b 4e 08          	mov    r9,QWORD PTR [r14+0x8]
   2bc1f:	4d 8b 2e             	mov    r13,QWORD PTR [r14]
   2bc22:	31 c9                	xor    ecx,ecx
   2bc24:	41 b8 06 00 00 00    	mov    r8d,0x6
   2bc2a:	b8 06 00 00 00       	mov    eax,0x6
   2bc2f:	e9 d8 c6 ff ff       	jmp    2830c <JS_CallInternal+0x582c>
   2bc34:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2bc3b:	4c 89 f6             	mov    rsi,r14
   2bc3e:	4c 89 ea             	mov    rdx,r13
   2bc41:	89 8d 50 fe ff ff    	mov    DWORD PTR [rbp-0x1b0],ecx
   2bc47:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2bc4b:	e8 50 0c ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2bc50:	8b 8d 50 fe ff ff    	mov    ecx,DWORD PTR [rbp-0x1b0]
   2bc56:	e9 e1 bd ff ff       	jmp    27a3c <JS_CallInternal+0x4f5c>
   2bc5b:	3d f2 00 00 00       	cmp    eax,0xf2
   2bc60:	7e 43                	jle    2bca5 <JS_CallInternal+0x91c5>
   2bc62:	31 d2                	xor    edx,edx
   2bc64:	48 8b 8d e8 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x118]
   2bc6b:	89 c0                	mov    eax,eax
   2bc6d:	48 8b 79 10          	mov    rdi,QWORD PTR [rcx+0x10]
   2bc71:	48 8b 8f 48 04 00 00 	mov    rcx,QWORD PTR [rdi+0x448]
   2bc78:	48 8b 34 c1          	mov    rsi,QWORD PTR [rcx+rax*8]
   2bc7c:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   2bc7f:	83 e8 01             	sub    eax,0x1
   2bc82:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   2bc85:	85 c0                	test   eax,eax
   2bc87:	7f 13                	jg     2bc9c <JS_CallInternal+0x91bc>
   2bc89:	48 89 95 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],rdx
   2bc90:	e8 6b 97 fe ff       	call   15400 <JS_FreeAtomStruct>
   2bc95:	48 8b 95 50 fe ff ff 	mov    rdx,QWORD PTR [rbp-0x1b0]
   2bc9c:	48 85 d2             	test   rdx,rdx
   2bc9f:	0f 85 bc 98 ff ff    	jne    25561 <JS_CallInternal+0x2a81>
   2bca5:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2bcac:	48 8d 35 fd 4f 0a 00 	lea    rsi,[rip+0xa4ffd]        # d0cb0 <_IO_stdin_used+0x3cb0>
   2bcb3:	31 c0                	xor    eax,eax
   2bcb5:	e8 66 4f 00 00       	call   30c20 <JS_ThrowTypeError>
   2bcba:	48 c7 03 00 00 00 00 	mov    QWORD PTR [rbx],0x0
   2bcc1:	48 c7 43 08 06 00 00 	mov    QWORD PTR [rbx+0x8],0x6
   2bcc8:	00 
   2bcc9:	e9 5d 97 ff ff       	jmp    2542b <JS_CallInternal+0x294b>
   2bcce:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2bcd5:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2bcd9:	e8 c2 0b ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2bcde:	e9 29 c4 ff ff       	jmp    2810c <JS_CallInternal+0x562c>
   2bce3:	0f 85 fd 78 ff ff    	jne    235e6 <JS_CallInternal+0xb06>
   2bce9:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2bcf0:	48 8b 47 10          	mov    rax,QWORD PTR [rdi+0x10]
   2bcf4:	48 8b 80 f0 04 00 00 	mov    rax,QWORD PTR [rax+0x4f0]
   2bcfb:	48 85 c0             	test   rax,rax
   2bcfe:	0f 84 17 0b 00 00    	je     2c81b <JS_CallInternal+0x9d3b>
   2bd04:	f6 40 3c 01          	test   BYTE PTR [rax+0x3c],0x1
   2bd08:	0f 84 0d 0b 00 00    	je     2c81b <JS_CallInternal+0x9d3b>
   2bd0e:	8b b5 38 fe ff ff    	mov    esi,DWORD PTR [rbp-0x1c8]
   2bd14:	e8 27 71 00 00       	call   32e40 <JS_ThrowReferenceErrorNotDefined>
   2bd19:	e9 c8 78 ff ff       	jmp    235e6 <JS_CallInternal+0xb06>
   2bd1e:	8b 52 10             	mov    edx,DWORD PTR [rdx+0x10]
   2bd21:	81 e2 08 00 ff ff    	and    edx,0xffff0008
   2bd27:	81 fa 00 00 01 00    	cmp    edx,0x10000
   2bd2d:	0f 85 95 83 ff ff    	jne    240c8 <JS_CallInternal+0x15e8>
   2bd33:	41 80 7d 10 00       	cmp    BYTE PTR [r13+0x10],0x0
   2bd38:	0f 84 8a 83 ff ff    	je     240c8 <JS_CallInternal+0x15e8>
   2bd3e:	49 8b 36             	mov    rsi,QWORD PTR [r14]
   2bd41:	48 c1 f9 04          	sar    rcx,0x4
   2bd45:	4c 39 ee             	cmp    rsi,r13
   2bd48:	74 55                	je     2bd9f <JS_CallInternal+0x92bf>
   2bd4a:	41 83 45 fc 01       	add    DWORD PTR [r13-0x4],0x1
   2bd4f:	48 85 f6             	test   rsi,rsi
   2bd52:	74 48                	je     2bd9c <JS_CallInternal+0x92bc>
   2bd54:	48 89 85 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],rax
   2bd5b:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2bd62:	48 89 8d 28 fe ff ff 	mov    QWORD PTR [rbp-0x1d8],rcx
   2bd69:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2bd6d:	4c 89 9d 38 fe ff ff 	mov    QWORD PTR [rbp-0x1c8],r11
   2bd74:	4c 89 85 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],r8
   2bd7b:	e8 30 25 ff ff       	call   1e2b0 <js_free_shape>
   2bd80:	48 8b 8d 28 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x1d8]
   2bd87:	4c 8b 9d 38 fe ff ff 	mov    r11,QWORD PTR [rbp-0x1c8]
   2bd8e:	48 8b 85 40 fe ff ff 	mov    rax,QWORD PTR [rbp-0x1c0]
   2bd95:	4c 8b 85 50 fe ff ff 	mov    r8,QWORD PTR [rbp-0x1b0]
   2bd9c:	4d 89 2e             	mov    QWORD PTR [r14],r13
   2bd9f:	41 89 4e 08          	mov    DWORD PTR [r14+0x8],ecx
   2bda3:	e9 20 83 ff ff       	jmp    240c8 <JS_CallInternal+0x15e8>
   2bda8:	f2 0f 10 05 f0 ec 0a 	movsd  xmm0,QWORD PTR [rip+0xaecf0]        # daaa0 <typed_array_size_log2+0x28>
   2bdaf:	00 
   2bdb0:	e9 eb d7 ff ff       	jmp    295a0 <JS_CallInternal+0x6ac0>
   2bdb5:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2bdbc:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2bdc0:	e8 db 0a ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2bdc5:	e9 1e 79 ff ff       	jmp    236e8 <JS_CallInternal+0xc08>
   2bdca:	0f 85 16 78 ff ff    	jne    235e6 <JS_CallInternal+0xb06>
   2bdd0:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2bdd7:	48 8b 47 10          	mov    rax,QWORD PTR [rdi+0x10]
   2bddb:	48 8b 80 f0 04 00 00 	mov    rax,QWORD PTR [rax+0x4f0]
   2bde2:	48 85 c0             	test   rax,rax
   2bde5:	0f 84 8b 77 ff ff    	je     23576 <JS_CallInternal+0xa96>
   2bdeb:	f6 40 3c 01          	test   BYTE PTR [rax+0x3c],0x1
   2bdef:	0f 84 81 77 ff ff    	je     23576 <JS_CallInternal+0xa96>
   2bdf5:	e9 14 ff ff ff       	jmp    2bd0e <JS_CallInternal+0x922e>
   2bdfa:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2be01:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2be05:	e8 96 0a ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2be0a:	e9 cb 77 ff ff       	jmp    235da <JS_CallInternal+0xafa>
   2be0f:	8b 4e 10             	mov    ecx,DWORD PTR [rsi+0x10]
   2be12:	81 e1 08 00 ff ff    	and    ecx,0xffff0008
   2be18:	81 f9 00 00 01 00    	cmp    ecx,0x10000
   2be1e:	0f 85 cd 81 ff ff    	jne    23ff1 <JS_CallInternal+0x1511>
   2be24:	41 80 7d 10 00       	cmp    BYTE PTR [r13+0x10],0x0
   2be29:	0f 84 c2 81 ff ff    	je     23ff1 <JS_CallInternal+0x1511>
   2be2f:	49 8b 36             	mov    rsi,QWORD PTR [r14]
   2be32:	48 c1 f8 04          	sar    rax,0x4
   2be36:	4c 39 ee             	cmp    rsi,r13
   2be39:	74 47                	je     2be82 <JS_CallInternal+0x93a2>
   2be3b:	41 83 45 fc 01       	add    DWORD PTR [r13-0x4],0x1
   2be40:	48 85 f6             	test   rsi,rsi
   2be43:	74 3a                	je     2be7f <JS_CallInternal+0x939f>
   2be45:	48 89 85 38 fe ff ff 	mov    QWORD PTR [rbp-0x1c8],rax
   2be4c:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2be53:	4c 89 85 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],r8
   2be5a:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2be5e:	48 89 95 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],rdx
   2be65:	e8 46 24 ff ff       	call   1e2b0 <js_free_shape>
   2be6a:	48 8b 85 38 fe ff ff 	mov    rax,QWORD PTR [rbp-0x1c8]
   2be71:	4c 8b 85 40 fe ff ff 	mov    r8,QWORD PTR [rbp-0x1c0]
   2be78:	48 8b 95 50 fe ff ff 	mov    rdx,QWORD PTR [rbp-0x1b0]
   2be7f:	4d 89 2e             	mov    QWORD PTR [r14],r13
   2be82:	41 89 46 08          	mov    DWORD PTR [r14+0x8],eax
   2be86:	e9 66 81 ff ff       	jmp    23ff1 <JS_CallInternal+0x1511>
   2be8b:	f2 0f 10 05 6d 75 0a 	movsd  xmm0,QWORD PTR [rip+0xa756d]        # d3400 <__PRETTY_FUNCTION__.0+0xc0>
   2be92:	00 
   2be93:	e9 08 d7 ff ff       	jmp    295a0 <JS_CallInternal+0x6ac0>
   2be98:	4d 89 f4             	mov    r12,r14
   2be9b:	e9 e0 73 ff ff       	jmp    23280 <JS_CallInternal+0x7a0>
   2bea0:	48 8b 8d e8 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x118]
   2bea7:	48 8b 91 88 01 00 00 	mov    rdx,QWORD PTR [rcx+0x188]
   2beae:	48 8b 81 80 01 00 00 	mov    rax,QWORD PTR [rcx+0x180]
   2beb5:	83 fa f6             	cmp    edx,0xfffffff6
   2beb8:	76 04                	jbe    2bebe <JS_CallInternal+0x93de>
   2beba:	83 40 fc 01          	add    DWORD PTR [rax-0x4],0x1
   2bebe:	48 89 43 d0          	mov    QWORD PTR [rbx-0x30],rax
   2bec2:	48 89 53 d8          	mov    QWORD PTR [rbx-0x28],rdx
   2bec6:	e9 c5 b6 ff ff       	jmp    27590 <JS_CallInternal+0x4ab0>
   2becb:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   2bed2:	41 83 fe f9          	cmp    r14d,0xfffffff9
   2bed6:	4c 89 48 30          	mov    QWORD PTR [rax+0x30],r9
   2beda:	0f 84 13 0d 00 00    	je     2cbf3 <JS_CallInternal+0xa113>
   2bee0:	49 8b 45 00          	mov    rax,QWORD PTR [r13+0x0]
   2bee4:	83 40 fc 01          	add    DWORD PTR [rax-0x4],0x1
   2bee8:	e9 d2 f4 ff ff       	jmp    2b3bf <JS_CallInternal+0x88df>
   2beed:	48 8b 8d e8 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x118]
   2bef4:	48 89 c6             	mov    rsi,rax
   2bef7:	4c 89 ca             	mov    rdx,r9
   2befa:	48 8b 79 10          	mov    rdi,QWORD PTR [rcx+0x10]
   2befe:	e8 9d 09 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2bf03:	e9 d6 e0 ff ff       	jmp    29fde <JS_CallInternal+0x74fe>
   2bf08:	41 81 fd f2 00 00 00 	cmp    r13d,0xf2
   2bf0f:	0f 8f e0 08 00 00    	jg     2c7f5 <JS_CallInternal+0x9d15>
   2bf15:	b8 03 00 00 00       	mov    eax,0x3
   2bf1a:	31 c9                	xor    ecx,ecx
   2bf1c:	e9 65 c1 ff ff       	jmp    28086 <JS_CallInternal+0x55a6>
   2bf21:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2bf28:	48 89 95 38 fe ff ff 	mov    QWORD PTR [rbp-0x1c8],rdx
   2bf2f:	48 63 d7             	movsxd rdx,edi
   2bf32:	48 c1 e2 04          	shl    rdx,0x4
   2bf36:	4c 89 8d 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],r9
   2bf3d:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2bf41:	48 89 d6             	mov    rsi,rdx
   2bf44:	48 89 95 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],rdx
   2bf4b:	e8 00 8a fe ff       	call   14950 <__js_malloc>
   2bf50:	48 8b 95 50 fe ff ff 	mov    rdx,QWORD PTR [rbp-0x1b0]
   2bf57:	4c 8b 8d 40 fe ff ff 	mov    r9,QWORD PTR [rbp-0x1c0]
   2bf5e:	48 85 c0             	test   rax,rax
   2bf61:	48 8b 8d 38 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x1c8]
   2bf68:	0f 84 56 0b 00 00    	je     2cac4 <JS_CallInternal+0x9fe4>
   2bf6e:	4c 8b 95 a8 fe ff ff 	mov    r10,QWORD PTR [rbp-0x158]
   2bf75:	31 f6                	xor    esi,esi
   2bf77:	4d 8b 44 32 08       	mov    r8,QWORD PTR [r10+rsi*1+0x8]
   2bf7c:	49 8b 3c 32          	mov    rdi,QWORD PTR [r10+rsi*1]
   2bf80:	41 83 f8 f6          	cmp    r8d,0xfffffff6
   2bf84:	76 04                	jbe    2bf8a <JS_CallInternal+0x94aa>
   2bf86:	83 47 fc 01          	add    DWORD PTR [rdi-0x4],0x1
   2bf8a:	48 89 3c 30          	mov    QWORD PTR [rax+rsi*1],rdi
   2bf8e:	4c 89 44 30 08       	mov    QWORD PTR [rax+rsi*1+0x8],r8
   2bf93:	48 83 c6 10          	add    rsi,0x10
   2bf97:	48 39 f2             	cmp    rdx,rsi
   2bf9a:	75 db                	jne    2bf77 <JS_CallInternal+0x9497>
   2bf9c:	e9 45 95 ff ff       	jmp    254e6 <JS_CallInternal+0x2a06>
   2bfa1:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2bfa8:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2bfac:	e8 ef 08 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2bfb1:	e9 9c da ff ff       	jmp    29a52 <JS_CallInternal+0x6f72>
   2bfb6:	48 8b bd c0 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x140]
   2bfbd:	4c 89 ee             	mov    rsi,r13
   2bfc0:	e8 0b 47 ff ff       	call   206d0 <free_var_ref>
   2bfc5:	e9 a1 72 ff ff       	jmp    2326b <JS_CallInternal+0x78b>
   2bfca:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2bfd1:	48 8d 35 48 4d 0a 00 	lea    rsi,[rip+0xa4d48]        # d0d20 <_IO_stdin_used+0x3d20>
   2bfd8:	31 c0                	xor    eax,eax
   2bfda:	e8 41 4c 00 00       	call   30c20 <JS_ThrowTypeError>
   2bfdf:	e9 9c 72 ff ff       	jmp    23280 <JS_CallInternal+0x7a0>
   2bfe4:	8b 85 88 fe ff ff    	mov    eax,DWORD PTR [rbp-0x178]
   2bfea:	83 e8 02             	sub    eax,0x2
   2bfed:	83 f8 01             	cmp    eax,0x1
   2bff0:	0f 87 5b 04 00 00    	ja     2c451 <JS_CallInternal+0x9971>
   2bff6:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2bffd:	48 8b 88 80 01 00 00 	mov    rcx,QWORD PTR [rax+0x180]
   2c004:	48 8b 80 88 01 00 00 	mov    rax,QWORD PTR [rax+0x188]
   2c00b:	83 f8 f6             	cmp    eax,0xfffffff6
   2c00e:	0f 86 4e 96 ff ff    	jbe    25662 <JS_CallInternal+0x2b82>
   2c014:	83 41 fc 01          	add    DWORD PTR [rcx-0x4],0x1
   2c018:	e9 45 96 ff ff       	jmp    25662 <JS_CallInternal+0x2b82>
   2c01d:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2c024:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2c028:	e8 73 08 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2c02d:	e9 c1 d5 ff ff       	jmp    295f3 <JS_CallInternal+0x6b13>
   2c032:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2c039:	4c 89 85 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],r8
   2c040:	4c 89 8d 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],r9
   2c047:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2c04b:	e8 50 08 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2c050:	4c 8b 85 40 fe ff ff 	mov    r8,QWORD PTR [rbp-0x1c0]
   2c057:	4c 8b 8d 50 fe ff ff 	mov    r9,QWORD PTR [rbp-0x1b0]
   2c05e:	e9 ed 8e ff ff       	jmp    24f50 <JS_CallInternal+0x2470>
   2c063:	45 85 ed             	test   r13d,r13d
   2c066:	0f 85 7c dd ff ff    	jne    29de8 <JS_CallInternal+0x7308>
   2c06c:	e9 dc dd ff ff       	jmp    29e4d <JS_CallInternal+0x736d>
   2c071:	48 89 85 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],rax
   2c078:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2c07f:	4c 89 c2             	mov    rdx,r8
   2c082:	4c 89 8d 38 fe ff ff 	mov    QWORD PTR [rbp-0x1c8],r9
   2c089:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2c08d:	89 8d 50 fe ff ff    	mov    DWORD PTR [rbp-0x1b0],ecx
   2c093:	e8 08 08 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2c098:	4c 8b 8d 38 fe ff ff 	mov    r9,QWORD PTR [rbp-0x1c8]
   2c09f:	48 8b 85 40 fe ff ff 	mov    rax,QWORD PTR [rbp-0x1c0]
   2c0a6:	8b 8d 50 fe ff ff    	mov    ecx,DWORD PTR [rbp-0x1b0]
   2c0ac:	e9 fe de ff ff       	jmp    29faf <JS_CallInternal+0x74cf>
   2c0b1:	45 85 db             	test   r11d,r11d
   2c0b4:	0f 85 d9 f1 ff ff    	jne    2b293 <JS_CallInternal+0x87b3>
   2c0ba:	66 0f ef c9          	pxor   xmm1,xmm1
   2c0be:	f2 41 0f 2a ca       	cvtsi2sd xmm1,r10d
   2c0c3:	66 48 0f 6e c0       	movq   xmm0,rax
   2c0c8:	f2 0f 58 c1          	addsd  xmm0,xmm1
   2c0cc:	48 c7 43 e8 08 00 00 	mov    QWORD PTR [rbx-0x18],0x8
   2c0d3:	00 
   2c0d4:	48 83 eb 10          	sub    rbx,0x10
   2c0d8:	f2 0f 11 43 f0       	movsd  QWORD PTR [rbx-0x10],xmm0
   2c0dd:	e9 74 af ff ff       	jmp    27056 <JS_CallInternal+0x4576>
   2c0e2:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2c0e9:	4c 89 ee             	mov    rsi,r13
   2c0ec:	4c 89 f2             	mov    rdx,r14
   2c0ef:	89 8d 40 fe ff ff    	mov    DWORD PTR [rbp-0x1c0],ecx
   2c0f5:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2c0f9:	e8 a2 07 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2c0fe:	8b 8d 40 fe ff ff    	mov    ecx,DWORD PTR [rbp-0x1c0]
   2c104:	4c 8b 95 50 fe ff ff 	mov    r10,QWORD PTR [rbp-0x1b0]
   2c10b:	e9 5d da ff ff       	jmp    29b6d <JS_CallInternal+0x708d>
   2c110:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2c117:	48 89 8d 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],rcx
   2c11e:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2c122:	e8 79 07 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2c127:	48 8b 8d 50 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x1b0]
   2c12e:	e9 4a d4 ff ff       	jmp    2957d <JS_CallInternal+0x6a9d>
   2c133:	83 f9 f6             	cmp    ecx,0xfffffff6
   2c136:	0f 86 ef f3 ff ff    	jbe    2b52b <JS_CallInternal+0x8a4b>
   2c13c:	41 8b 40 fc          	mov    eax,DWORD PTR [r8-0x4]
   2c140:	83 e8 01             	sub    eax,0x1
   2c143:	41 89 40 fc          	mov    DWORD PTR [r8-0x4],eax
   2c147:	85 c0                	test   eax,eax
   2c149:	0f 8f dc f3 ff ff    	jg     2b52b <JS_CallInternal+0x8a4b>
   2c14f:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2c156:	4c 89 c6             	mov    rsi,r8
   2c159:	48 89 ca             	mov    rdx,rcx
   2c15c:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2c160:	e8 3b 07 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2c165:	e9 c1 f3 ff ff       	jmp    2b52b <JS_CallInternal+0x8a4b>
   2c16a:	89 c8                	mov    eax,ecx
   2c16c:	31 d2                	xor    edx,edx
   2c16e:	e9 7c b1 ff ff       	jmp    272ef <JS_CallInternal+0x480f>
   2c173:	48 8b 8d e8 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x118]
   2c17a:	48 8d 45 80          	lea    rax,[rbp-0x80]
   2c17e:	89 f2                	mov    edx,esi
   2c180:	48 89 c6             	mov    rsi,rax
   2c183:	48 8b 79 10          	mov    rdi,QWORD PTR [rcx+0x10]
   2c187:	e8 84 b1 fe ff       	call   17310 <JS_AtomGetStrRT.constprop.0>
   2c18c:	48 89 c2             	mov    rdx,rax
   2c18f:	e9 24 83 ff ff       	jmp    244b8 <JS_CallInternal+0x19d8>
   2c194:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2c19b:	48 89 8d 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],rcx
   2c1a2:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2c1a6:	e8 f5 06 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2c1ab:	48 8b 8d 50 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x1b0]
   2c1b2:	e9 4b d6 ff ff       	jmp    29802 <JS_CallInternal+0x6d22>
   2c1b7:	8b 12                	mov    edx,DWORD PTR [rdx]
   2c1b9:	81 e2 ff ff ff 03    	and    edx,0x3ffffff
   2c1bf:	0f 85 8f ab ff ff    	jne    26d54 <JS_CallInternal+0x4274>
   2c1c5:	31 d2                	xor    edx,edx
   2c1c7:	e9 98 ab ff ff       	jmp    26d64 <JS_CallInternal+0x4284>
   2c1cc:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2c1d3:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2c1d7:	e8 c4 06 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2c1dc:	e9 d5 b2 ff ff       	jmp    274b6 <JS_CallInternal+0x49d6>
   2c1e1:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2c1e8:	48 8d 35 88 13 0a 00 	lea    rsi,[rip+0xa1388]        # cd577 <_IO_stdin_used+0x577>
   2c1ef:	31 c0                	xor    eax,eax
   2c1f1:	e8 2a 4a 00 00       	call   30c20 <JS_ThrowTypeError>
   2c1f6:	e9 85 70 ff ff       	jmp    23280 <JS_CallInternal+0x7a0>
   2c1fb:	66 0f ef c9          	pxor   xmm1,xmm1
   2c1ff:	f2 0f 2a ca          	cvtsi2sd xmm1,edx
   2c203:	66 48 0f 6e c0       	movq   xmm0,rax
   2c208:	31 c0                	xor    eax,eax
   2c20a:	66 0f 2f c8          	comisd xmm1,xmm0
   2c20e:	48 c7 43 e8 01 00 00 	mov    QWORD PTR [rbx-0x18],0x1
   2c215:	00 
   2c216:	0f 97 c0             	seta   al
   2c219:	48 83 eb 10          	sub    rbx,0x10
   2c21d:	48 89 43 f0          	mov    QWORD PTR [rbx-0x10],rax
   2c221:	e9 7c b9 ff ff       	jmp    27ba2 <JS_CallInternal+0x50c2>
   2c226:	83 c1 07             	add    ecx,0x7
   2c229:	83 f9 01             	cmp    ecx,0x1
   2c22c:	0f 87 61 f0 ff ff    	ja     2b293 <JS_CallInternal+0x87b3>
   2c232:	4c 89 c1             	mov    rcx,r8
   2c235:	49 89 f8             	mov    r8,rdi
   2c238:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2c23f:	4c 89 d6             	mov    rsi,r10
   2c242:	4c 89 da             	mov    rdx,r11
   2c245:	e8 a6 3f 01 00       	call   401f0 <JS_ConcatString>
   2c24a:	48 89 43 e0          	mov    QWORD PTR [rbx-0x20],rax
   2c24e:	48 8d 43 f0          	lea    rax,[rbx-0x10]
   2c252:	48 89 53 e8          	mov    QWORD PTR [rbx-0x18],rdx
   2c256:	83 7b e8 06          	cmp    DWORD PTR [rbx-0x18],0x6
   2c25a:	48 89 c3             	mov    rbx,rax
   2c25d:	0f 85 f3 ad ff ff    	jne    27056 <JS_CallInternal+0x4576>
   2c263:	e9 18 70 ff ff       	jmp    23280 <JS_CallInternal+0x7a0>
   2c268:	66 48 0f 6e ca       	movq   xmm1,rdx
   2c26d:	83 f9 08             	cmp    ecx,0x8
   2c270:	74 36                	je     2c2a8 <JS_CallInternal+0x97c8>
   2c272:	85 c9                	test   ecx,ecx
   2c274:	0f 85 d0 f0 ff ff    	jne    2b34a <JS_CallInternal+0x886a>
   2c27a:	66 0f ef c0          	pxor   xmm0,xmm0
   2c27e:	f2 0f 2a c0          	cvtsi2sd xmm0,eax
   2c282:	31 c0                	xor    eax,eax
   2c284:	66 0f 2f c8          	comisd xmm1,xmm0
   2c288:	48 c7 43 e8 01 00 00 	mov    QWORD PTR [rbx-0x18],0x1
   2c28f:	00 
   2c290:	0f 93 c0             	setae  al
   2c293:	48 83 eb 10          	sub    rbx,0x10
   2c297:	48 89 43 f0          	mov    QWORD PTR [rbx-0x10],rax
   2c29b:	e9 8b b4 ff ff       	jmp    2772b <JS_CallInternal+0x4c4b>
   2c2a0:	66 0f ef c9          	pxor   xmm1,xmm1
   2c2a4:	f2 0f 2a ca          	cvtsi2sd xmm1,edx
   2c2a8:	66 48 0f 6e c0       	movq   xmm0,rax
   2c2ad:	eb d3                	jmp    2c282 <JS_CallInternal+0x97a2>
   2c2af:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2c2b6:	48 8d 35 95 12 0a 00 	lea    rsi,[rip+0xa1295]        # cd552 <_IO_stdin_used+0x552>
   2c2bd:	31 c0                	xor    eax,eax
   2c2bf:	e8 5c 49 00 00       	call   30c20 <JS_ThrowTypeError>
   2c2c4:	e9 b7 6f ff ff       	jmp    23280 <JS_CallInternal+0x7a0>
   2c2c9:	48 8b bd a0 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x160]
   2c2d0:	48 8d 35 09 4a 0a 00 	lea    rsi,[rip+0xa4a09]        # d0ce0 <_IO_stdin_used+0x3ce0>
   2c2d7:	31 c0                	xor    eax,eax
   2c2d9:	e8 42 49 00 00       	call   30c20 <JS_ThrowTypeError>
   2c2de:	e9 9d 6f ff ff       	jmp    23280 <JS_CallInternal+0x7a0>
   2c2e3:	66 49 0f 6e ca       	movq   xmm1,r10
   2c2e8:	83 ff 08             	cmp    edi,0x8
   2c2eb:	0f 84 d2 fd ff ff    	je     2c0c3 <JS_CallInternal+0x95e3>
   2c2f1:	85 ff                	test   edi,edi
   2c2f3:	0f 85 9a ef ff ff    	jne    2b293 <JS_CallInternal+0x87b3>
   2c2f9:	66 0f ef c0          	pxor   xmm0,xmm0
   2c2fd:	f2 41 0f 2a c0       	cvtsi2sd xmm0,r8d
   2c302:	e9 c1 fd ff ff       	jmp    2c0c8 <JS_CallInternal+0x95e8>
   2c307:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2c30e:	48 8d 35 b3 4a 0a 00 	lea    rsi,[rip+0xa4ab3]        # d0dc8 <_IO_stdin_used+0x3dc8>
   2c315:	31 c0                	xor    eax,eax
   2c317:	e8 04 49 00 00       	call   30c20 <JS_ThrowTypeError>
   2c31c:	e9 5f 6f ff ff       	jmp    23280 <JS_CallInternal+0x7a0>
   2c321:	66 48 0f 6e ca       	movq   xmm1,rdx
   2c326:	83 f9 08             	cmp    ecx,0x8
   2c329:	0f 84 d4 fe ff ff    	je     2c203 <JS_CallInternal+0x9723>
   2c32f:	85 c9                	test   ecx,ecx
   2c331:	0f 85 f7 ee ff ff    	jne    2b22e <JS_CallInternal+0x874e>
   2c337:	66 0f ef c0          	pxor   xmm0,xmm0
   2c33b:	f2 0f 2a c0          	cvtsi2sd xmm0,eax
   2c33f:	e9 c4 fe ff ff       	jmp    2c208 <JS_CallInternal+0x9728>
   2c344:	4d 89 ec             	mov    r12,r13
   2c347:	e9 34 6f ff ff       	jmp    23280 <JS_CallInternal+0x7a0>
   2c34c:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2c353:	48 8d 35 47 12 0a 00 	lea    rsi,[rip+0xa1247]        # cd5a1 <_IO_stdin_used+0x5a1>
   2c35a:	31 c0                	xor    eax,eax
   2c35c:	e8 bf 48 00 00       	call   30c20 <JS_ThrowTypeError>
   2c361:	e9 1a 6f ff ff       	jmp    23280 <JS_CallInternal+0x7a0>
   2c366:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2c36d:	4c 89 ee             	mov    rsi,r13
   2c370:	48 89 da             	mov    rdx,rbx
   2c373:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2c377:	e8 24 05 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2c37c:	e9 a3 f2 ff ff       	jmp    2b624 <JS_CallInternal+0x8b44>
   2c381:	4d 89 c1             	mov    r9,r8
   2c384:	48 89 d7             	mov    rdi,rdx
   2c387:	45 31 c0             	xor    r8d,r8d
   2c38a:	4c 89 ea             	mov    rdx,r13
   2c38d:	4c 89 ce             	mov    rsi,r9
   2c390:	4c 89 f1             	mov    rcx,r14
   2c393:	48 89 bd 38 fe ff ff 	mov    QWORD PTR [rbp-0x1c8],rdi
   2c39a:	4c 89 8d 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],r9
   2c3a1:	e8 2a e1 fe ff       	call   1a4d0 <js_strict_eq2.isra.0>
   2c3a6:	48 8b b5 38 fe ff ff 	mov    rsi,QWORD PTR [rbp-0x1c8]
   2c3ad:	48 8b 95 40 fe ff ff 	mov    rdx,QWORD PTR [rbp-0x1c0]
   2c3b4:	89 85 50 fe ff ff    	mov    DWORD PTR [rbp-0x1b0],eax
   2c3ba:	e9 34 f3 ff ff       	jmp    2b6f3 <JS_CallInternal+0x8c13>
   2c3bf:	31 c0                	xor    eax,eax
   2c3c1:	41 83 fe ff          	cmp    r14d,0xffffffff
   2c3c5:	75 08                	jne    2c3cf <JS_CallInternal+0x98ef>
   2c3c7:	31 c0                	xor    eax,eax
   2c3c9:	4c 39 ea             	cmp    rdx,r13
   2c3cc:	0f 94 c0             	sete   al
   2c3cf:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2c3d6:	48 89 d6             	mov    rsi,rdx
   2c3d9:	4c 89 c2             	mov    rdx,r8
   2c3dc:	89 85 50 fe ff ff    	mov    DWORD PTR [rbp-0x1b0],eax
   2c3e2:	e8 19 06 ff ff       	call   1ca00 <JS_FreeValue>
   2c3e7:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2c3ee:	4c 89 ee             	mov    rsi,r13
   2c3f1:	4c 89 f2             	mov    rdx,r14
   2c3f4:	e8 07 06 ff ff       	call   1ca00 <JS_FreeValue>
   2c3f9:	48 63 85 50 fe ff ff 	movsxd rax,DWORD PTR [rbp-0x1b0]
   2c400:	e9 8e b5 ff ff       	jmp    27993 <JS_CallInternal+0x4eb3>
   2c405:	45 85 f6             	test   r14d,r14d
   2c408:	0f 85 a0 01 00 00    	jne    2c5ae <JS_CallInternal+0x9ace>
   2c40e:	66 0f ef c0          	pxor   xmm0,xmm0
   2c412:	66 48 0f 6e e2       	movq   xmm4,rdx
   2c417:	31 c0                	xor    eax,eax
   2c419:	ba 00 00 00 00       	mov    edx,0x0
   2c41e:	f2 41 0f 2a c5       	cvtsi2sd xmm0,r13d
   2c423:	66 0f 2e c4          	ucomisd xmm0,xmm4
   2c427:	0f 9b c0             	setnp  al
   2c42a:	48 0f 45 c2          	cmovne rax,rdx
   2c42e:	e9 60 b5 ff ff       	jmp    27993 <JS_CallInternal+0x4eb3>
   2c433:	48 8b 8d e8 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x118]
   2c43a:	89 c2                	mov    edx,eax
   2c43c:	48 8d 75 80          	lea    rsi,[rbp-0x80]
   2c440:	48 8b 79 10          	mov    rdi,QWORD PTR [rcx+0x10]
   2c444:	e8 c7 ae fe ff       	call   17310 <JS_AtomGetStrRT.constprop.0>
   2c449:	48 89 c2             	mov    rdx,rax
   2c44c:	e9 b0 e9 ff ff       	jmp    2ae01 <JS_CallInternal+0x8321>
   2c451:	48 8b b5 78 fe ff ff 	mov    rsi,QWORD PTR [rbp-0x188]
   2c458:	48 8b 95 88 fe ff ff 	mov    rdx,QWORD PTR [rbp-0x178]
   2c45f:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2c466:	e8 05 bf 01 00       	call   48370 <JS_ToObject>
   2c46b:	48 89 c1             	mov    rcx,rax
   2c46e:	48 89 d0             	mov    rax,rdx
   2c471:	83 fa 06             	cmp    edx,0x6
   2c474:	0f 85 e8 91 ff ff    	jne    25662 <JS_CallInternal+0x2b82>
   2c47a:	e9 01 6e ff ff       	jmp    23280 <JS_CallInternal+0x7a0>
   2c47f:	48 89 85 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],rax
   2c486:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2c48d:	4c 89 85 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],r8
   2c494:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2c498:	e8 03 04 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2c49d:	4c 8b 85 40 fe ff ff 	mov    r8,QWORD PTR [rbp-0x1c0]
   2c4a4:	48 8b 85 50 fe ff ff 	mov    rax,QWORD PTR [rbp-0x1b0]
   2c4ab:	e9 95 d9 ff ff       	jmp    29e45 <JS_CallInternal+0x7365>
   2c4b0:	4d 89 ec             	mov    r12,r13
   2c4b3:	e9 c8 6d ff ff       	jmp    23280 <JS_CallInternal+0x7a0>
   2c4b8:	41 8d 50 fe          	lea    edx,[r8-0x2]
   2c4bc:	83 fa 01             	cmp    edx,0x1
   2c4bf:	0f 86 bb 06 00 00    	jbe    2cb80 <JS_CallInternal+0xa0a0>
   2c4c5:	83 c0 01             	add    eax,0x1
   2c4c8:	0f 85 12 dc ff ff    	jne    2a0e0 <JS_CallInternal+0x7600>
   2c4ce:	41 0f b6 41 11       	movzx  eax,BYTE PTR [r9+0x11]
   2c4d3:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2c4da:	4c 89 c2             	mov    rdx,r8
   2c4dd:	83 e0 01             	and    eax,0x1
   2c4e0:	89 85 50 fe ff ff    	mov    DWORD PTR [rbp-0x1b0],eax
   2c4e6:	e8 15 05 ff ff       	call   1ca00 <JS_FreeValue>
   2c4eb:	8b 85 50 fe ff ff    	mov    eax,DWORD PTR [rbp-0x1b0]
   2c4f1:	e9 ff a3 ff ff       	jmp    268f5 <JS_CallInternal+0x3e15>
   2c4f6:	41 8d 50 fe          	lea    edx,[r8-0x2]
   2c4fa:	83 fa 01             	cmp    edx,0x1
   2c4fd:	0f 86 87 06 00 00    	jbe    2cb8a <JS_CallInternal+0xa0aa>
   2c503:	83 c0 01             	add    eax,0x1
   2c506:	0f 85 d4 db ff ff    	jne    2a0e0 <JS_CallInternal+0x7600>
   2c50c:	31 c0                	xor    eax,eax
   2c50e:	4d 39 ce             	cmp    r14,r9
   2c511:	4c 89 85 38 fe ff ff 	mov    QWORD PTR [rbp-0x1c8],r8
   2c518:	4c 89 8d 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],r9
   2c51f:	0f 94 c0             	sete   al
   2c522:	e9 91 eb ff ff       	jmp    2b0b8 <JS_CallInternal+0x85d8>
   2c527:	45 85 c0             	test   r8d,r8d
   2c52a:	0f 85 eb 00 00 00    	jne    2c61b <JS_CallInternal+0x9b3b>
   2c530:	66 0f ef c0          	pxor   xmm0,xmm0
   2c534:	66 49 0f 6e ce       	movq   xmm1,r14
   2c539:	31 d2                	xor    edx,edx
   2c53b:	f2 41 0f 2a c1       	cvtsi2sd xmm0,r9d
   2c540:	66 0f 2e c1          	ucomisd xmm0,xmm1
   2c544:	0f 9b c2             	setnp  dl
   2c547:	0f 44 c2             	cmove  eax,edx
   2c54a:	e9 a6 a3 ff ff       	jmp    268f5 <JS_CallInternal+0x3e15>
   2c54f:	48 8b 85 c0 fe ff ff 	mov    rax,QWORD PTR [rbp-0x140]
   2c556:	48 8b 8d d8 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x128]
   2c55d:	31 d2                	xor    edx,edx
   2c55f:	f3 0f 6f 90 d8 04 00 	movdqu xmm2,XMMWORD PTR [rax+0x4d8]
   2c566:	00 
   2c567:	0f 11 53 f0          	movups XMMWORD PTR [rbx-0x10],xmm2
   2c56b:	0f 29 95 50 fe ff ff 	movaps XMMWORD PTR [rbp-0x1b0],xmm2
   2c572:	48 89 90 d8 04 00 00 	mov    QWORD PTR [rax+0x4d8],rdx
   2c579:	48 c7 80 e0 04 00 00 	mov    QWORD PTR [rax+0x4e0],0x4
   2c580:	04 00 00 00 
   2c584:	49 63 c5             	movsxd rax,r13d
   2c587:	48 03 41 18          	add    rax,QWORD PTR [rcx+0x18]
   2c58b:	e9 11 68 ff ff       	jmp    22da1 <JS_CallInternal+0x2c1>
   2c590:	48 8b 8d e8 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x118]
   2c597:	89 c2                	mov    edx,eax
   2c599:	48 8d 75 80          	lea    rsi,[rbp-0x80]
   2c59d:	48 8b 79 10          	mov    rdi,QWORD PTR [rcx+0x10]
   2c5a1:	e8 6a ad fe ff       	call   17310 <JS_AtomGetStrRT.constprop.0>
   2c5a6:	48 89 c2             	mov    rdx,rax
   2c5a9:	e9 8e e8 ff ff       	jmp    2ae3c <JS_CallInternal+0x835c>
   2c5ae:	41 83 fe 08          	cmp    r14d,0x8
   2c5b2:	0f 85 1a 06 00 00    	jne    2cbd2 <JS_CallInternal+0xa0f2>
   2c5b8:	66 48 0f 6e c2       	movq   xmm0,rdx
   2c5bd:	66 49 0f 6e ed       	movq   xmm5,r13
   2c5c2:	31 c0                	xor    eax,eax
   2c5c4:	ba 00 00 00 00       	mov    edx,0x0
   2c5c9:	66 0f 2e c5          	ucomisd xmm0,xmm5
   2c5cd:	0f 9b c0             	setnp  al
   2c5d0:	48 0f 45 c2          	cmovne rax,rdx
   2c5d4:	e9 ba b3 ff ff       	jmp    27993 <JS_CallInternal+0x4eb3>
   2c5d9:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2c5e0:	48 89 ce             	mov    rsi,rcx
   2c5e3:	48 89 da             	mov    rdx,rbx
   2c5e6:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2c5ea:	e8 b1 02 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2c5ef:	e9 54 db ff ff       	jmp    2a148 <JS_CallInternal+0x7668>
   2c5f4:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2c5fb:	4c 89 c6             	mov    rsi,r8
   2c5fe:	4c 89 e2             	mov    rdx,r12
   2c601:	89 8d 40 fe ff ff    	mov    DWORD PTR [rbp-0x1c0],ecx
   2c607:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2c60b:	e8 90 02 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2c610:	8b 8d 40 fe ff ff    	mov    ecx,DWORD PTR [rbp-0x1c0]
   2c616:	e9 e2 c8 ff ff       	jmp    28efd <JS_CallInternal+0x641d>
   2c61b:	41 83 f8 08          	cmp    r8d,0x8
   2c61f:	0f 85 bb da ff ff    	jne    2a0e0 <JS_CallInternal+0x7600>
   2c625:	66 49 0f 6e c6       	movq   xmm0,r14
   2c62a:	66 49 0f 6e d1       	movq   xmm2,r9
   2c62f:	31 c0                	xor    eax,eax
   2c631:	ba 00 00 00 00       	mov    edx,0x0
   2c636:	66 0f 2e c2          	ucomisd xmm0,xmm2
   2c63a:	0f 9b c0             	setnp  al
   2c63d:	0f 45 c2             	cmovne eax,edx
   2c640:	e9 b0 a2 ff ff       	jmp    268f5 <JS_CallInternal+0x3e15>
   2c645:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2c64c:	48 8b 95 38 fe ff ff 	mov    rdx,QWORD PTR [rbp-0x1c8]
   2c653:	48 89 ce             	mov    rsi,rcx
   2c656:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2c65a:	e8 41 02 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2c65f:	e9 0b db ff ff       	jmp    2a16f <JS_CallInternal+0x768f>
   2c664:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2c66b:	48 8b 95 50 fe ff ff 	mov    rdx,QWORD PTR [rbp-0x1b0]
   2c672:	4c 89 ee             	mov    rsi,r13
   2c675:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2c679:	e8 22 02 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2c67e:	e9 b5 a3 ff ff       	jmp    26a38 <JS_CallInternal+0x3f58>
   2c683:	41 83 fe 08          	cmp    r14d,0x8
   2c687:	0f 84 89 03 00 00    	je     2ca16 <JS_CallInternal+0x9f36>
   2c68d:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   2c694:	4c 89 48 30          	mov    QWORD PTR [rax+0x30],r9
   2c698:	49 8b 45 00          	mov    rax,QWORD PTR [r13+0x0]
   2c69c:	e9 1e ed ff ff       	jmp    2b3bf <JS_CallInternal+0x88df>
   2c6a1:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2c6a8:	48 8d 35 19 0e 0a 00 	lea    rsi,[rip+0xa0e19]        # cd4c8 <_IO_stdin_used+0x4c8>
   2c6af:	31 c0                	xor    eax,eax
   2c6b1:	e8 6a 45 00 00       	call   30c20 <JS_ThrowTypeError>
   2c6b6:	e9 c5 6b ff ff       	jmp    23280 <JS_CallInternal+0x7a0>
   2c6bb:	41 8d 50 fe          	lea    edx,[r8-0x2]
   2c6bf:	83 fa 01             	cmp    edx,0x1
   2c6c2:	0f 86 6c 03 00 00    	jbe    2ca34 <JS_CallInternal+0x9f54>
   2c6c8:	83 c0 01             	add    eax,0x1
   2c6cb:	0f 85 dd d9 ff ff    	jne    2a0ae <JS_CallInternal+0x75ce>
   2c6d1:	4d 39 ce             	cmp    r14,r9
   2c6d4:	4c 89 f6             	mov    rsi,r14
   2c6d7:	4c 8b b5 e8 fe ff ff 	mov    r14,QWORD PTR [rbp-0x118]
   2c6de:	4c 89 ea             	mov    rdx,r13
   2c6e1:	0f 94 c0             	sete   al
   2c6e4:	4c 89 85 38 fe ff ff 	mov    QWORD PTR [rbp-0x1c8],r8
   2c6eb:	4c 89 f7             	mov    rdi,r14
   2c6ee:	88 85 50 fe ff ff    	mov    BYTE PTR [rbp-0x1b0],al
   2c6f4:	4c 89 8d 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],r9
   2c6fb:	e8 00 03 ff ff       	call   1ca00 <JS_FreeValue>
   2c700:	48 8b b5 40 fe ff ff 	mov    rsi,QWORD PTR [rbp-0x1c0]
   2c707:	48 8b 95 38 fe ff ff 	mov    rdx,QWORD PTR [rbp-0x1c8]
   2c70e:	4c 89 f7             	mov    rdi,r14
   2c711:	e8 ea 02 ff ff       	call   1ca00 <JS_FreeValue>
   2c716:	0f b6 85 50 fe ff ff 	movzx  eax,BYTE PTR [rbp-0x1b0]
   2c71d:	e9 33 a2 ff ff       	jmp    26955 <JS_CallInternal+0x3e75>
   2c722:	45 85 c0             	test   r8d,r8d
   2c725:	0f 85 84 00 00 00    	jne    2c7af <JS_CallInternal+0x9ccf>
   2c72b:	66 0f ef c0          	pxor   xmm0,xmm0
   2c72f:	66 49 0f 6e ee       	movq   xmm5,r14
   2c734:	ba 00 00 00 00       	mov    edx,0x0
   2c739:	f2 41 0f 2a c1       	cvtsi2sd xmm0,r9d
   2c73e:	66 0f 2e c5          	ucomisd xmm0,xmm5
   2c742:	0f 9b c0             	setnp  al
   2c745:	0f 45 c2             	cmovne eax,edx
   2c748:	e9 08 a2 ff ff       	jmp    26955 <JS_CallInternal+0x3e75>
   2c74d:	41 8d 50 fe          	lea    edx,[r8-0x2]
   2c751:	83 fa 01             	cmp    edx,0x1
   2c754:	0f 86 06 03 00 00    	jbe    2ca60 <JS_CallInternal+0x9f80>
   2c75a:	83 c0 01             	add    eax,0x1
   2c75d:	0f 85 4b d9 ff ff    	jne    2a0ae <JS_CallInternal+0x75ce>
   2c763:	41 0f b6 41 11       	movzx  eax,BYTE PTR [r9+0x11]
   2c768:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2c76f:	4c 89 c2             	mov    rdx,r8
   2c772:	83 e0 01             	and    eax,0x1
   2c775:	88 85 50 fe ff ff    	mov    BYTE PTR [rbp-0x1b0],al
   2c77b:	e8 80 02 ff ff       	call   1ca00 <JS_FreeValue>
   2c780:	0f b6 85 50 fe ff ff 	movzx  eax,BYTE PTR [rbp-0x1b0]
   2c787:	e9 c9 a1 ff ff       	jmp    26955 <JS_CallInternal+0x3e75>
   2c78c:	66 48 0f 6e c9       	movq   xmm1,rcx
   2c791:	83 f8 08             	cmp    eax,0x8
   2c794:	0f 84 e5 f2 ff ff    	je     2ba7f <JS_CallInternal+0x8f9f>
   2c79a:	85 c0                	test   eax,eax
   2c79c:	0f 85 35 74 ff ff    	jne    23bd7 <JS_CallInternal+0x10f7>
   2c7a2:	66 0f ef c0          	pxor   xmm0,xmm0
   2c7a6:	f2 0f 2a c2          	cvtsi2sd xmm0,edx
   2c7aa:	e9 d5 f2 ff ff       	jmp    2ba84 <JS_CallInternal+0x8fa4>
   2c7af:	41 83 f8 08          	cmp    r8d,0x8
   2c7b3:	0f 85 f5 d8 ff ff    	jne    2a0ae <JS_CallInternal+0x75ce>
   2c7b9:	66 49 0f 6e c6       	movq   xmm0,r14
   2c7be:	66 49 0f 6e f1       	movq   xmm6,r9
   2c7c3:	ba 00 00 00 00       	mov    edx,0x0
   2c7c8:	66 0f 2e c6          	ucomisd xmm0,xmm6
   2c7cc:	0f 9b c0             	setnp  al
   2c7cf:	0f 45 c2             	cmovne eax,edx
   2c7d2:	e9 7e a1 ff ff       	jmp    26955 <JS_CallInternal+0x3e75>
   2c7d7:	31 c0                	xor    eax,eax
   2c7d9:	48 c7 43 08 03 00 00 	mov    QWORD PTR [rbx+0x8],0x3
   2c7e0:	00 
   2c7e1:	48 89 03             	mov    QWORD PTR [rbx],rax
   2c7e4:	e9 96 8b ff ff       	jmp    2537f <JS_CallInternal+0x289f>
   2c7e9:	48 89 03             	mov    QWORD PTR [rbx],rax
   2c7ec:	48 89 53 08          	mov    QWORD PTR [rbx+0x8],rdx
   2c7f0:	e9 36 8c ff ff       	jmp    2542b <JS_CallInternal+0x294b>
   2c7f5:	48 8b 87 48 04 00 00 	mov    rax,QWORD PTR [rdi+0x448]
   2c7fc:	4a 8b 34 e8          	mov    rsi,QWORD PTR [rax+r13*8]
   2c800:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   2c803:	83 e8 01             	sub    eax,0x1
   2c806:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   2c809:	85 c0                	test   eax,eax
   2c80b:	0f 8f 04 f7 ff ff    	jg     2bf15 <JS_CallInternal+0x9435>
   2c811:	e8 ea 8b fe ff       	call   15400 <JS_FreeAtomStruct>
   2c816:	e9 fa f6 ff ff       	jmp    2bf15 <JS_CallInternal+0x9435>
   2c81b:	b8 03 00 00 00       	mov    eax,0x3
   2c820:	31 c9                	xor    ecx,ecx
   2c822:	e9 33 6e ff ff       	jmp    2365a <JS_CallInternal+0xb7a>
   2c827:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2c82e:	48 8b 95 50 fe ff ff 	mov    rdx,QWORD PTR [rbp-0x1b0]
   2c835:	4c 89 ee             	mov    rsi,r13
   2c838:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2c83c:	e8 5f 00 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2c841:	e9 75 ec ff ff       	jmp    2b4bb <JS_CallInternal+0x89db>
   2c846:	66 48 0f 6e c0       	movq   xmm0,rax
   2c84b:	83 f9 08             	cmp    ecx,0x8
   2c84e:	74 36                	je     2c886 <JS_CallInternal+0x9da6>
   2c850:	85 c9                	test   ecx,ecx
   2c852:	0f 85 9c f0 ff ff    	jne    2b8f4 <JS_CallInternal+0x8e14>
   2c858:	66 0f ef c9          	pxor   xmm1,xmm1
   2c85c:	f2 0f 2a ca          	cvtsi2sd xmm1,edx
   2c860:	31 c0                	xor    eax,eax
   2c862:	66 0f 2f c8          	comisd xmm1,xmm0
   2c866:	48 c7 43 e8 01 00 00 	mov    QWORD PTR [rbx-0x18],0x1
   2c86d:	00 
   2c86e:	0f 93 c0             	setae  al
   2c871:	48 83 eb 10          	sub    rbx,0x10
   2c875:	48 89 43 f0          	mov    QWORD PTR [rbx-0x10],rax
   2c879:	e9 fe a8 ff ff       	jmp    2717c <JS_CallInternal+0x469c>
   2c87e:	66 0f ef c0          	pxor   xmm0,xmm0
   2c882:	f2 0f 2a c0          	cvtsi2sd xmm0,eax
   2c886:	66 48 0f 6e ca       	movq   xmm1,rdx
   2c88b:	eb d3                	jmp    2c860 <JS_CallInternal+0x9d80>
   2c88d:	48 89 d7             	mov    rdi,rdx
   2c890:	4c 89 ce             	mov    rsi,r9
   2c893:	45 31 c0             	xor    r8d,r8d
   2c896:	4c 89 ea             	mov    rdx,r13
   2c899:	4c 89 f1             	mov    rcx,r14
   2c89c:	4c 89 8d 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],r9
   2c8a3:	48 89 bd 38 fe ff ff 	mov    QWORD PTR [rbp-0x1c8],rdi
   2c8aa:	e8 21 dc fe ff       	call   1a4d0 <js_strict_eq2.isra.0>
   2c8af:	48 8b b5 38 fe ff ff 	mov    rsi,QWORD PTR [rbp-0x1c8]
   2c8b6:	4c 8b 8d 40 fe ff ff 	mov    r9,QWORD PTR [rbp-0x1c0]
   2c8bd:	89 85 50 fe ff ff    	mov    DWORD PTR [rbp-0x1b0],eax
   2c8c3:	e9 78 e4 ff ff       	jmp    2ad40 <JS_CallInternal+0x8260>
   2c8c8:	31 c0                	xor    eax,eax
   2c8ca:	41 83 fe ff          	cmp    r14d,0xffffffff
   2c8ce:	75 08                	jne    2c8d8 <JS_CallInternal+0x9df8>
   2c8d0:	31 c0                	xor    eax,eax
   2c8d2:	4c 39 ea             	cmp    rdx,r13
   2c8d5:	0f 94 c0             	sete   al
   2c8d8:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2c8df:	48 89 d6             	mov    rsi,rdx
   2c8e2:	4c 89 ca             	mov    rdx,r9
   2c8e5:	89 85 50 fe ff ff    	mov    DWORD PTR [rbp-0x1b0],eax
   2c8eb:	e8 10 01 ff ff       	call   1ca00 <JS_FreeValue>
   2c8f0:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2c8f7:	4c 89 ee             	mov    rsi,r13
   2c8fa:	4c 89 f2             	mov    rdx,r14
   2c8fd:	e8 fe 00 ff ff       	call   1ca00 <JS_FreeValue>
   2c902:	8b 85 50 fe ff ff    	mov    eax,DWORD PTR [rbp-0x1b0]
   2c908:	83 f0 01             	xor    eax,0x1
   2c90b:	48 98                	cdqe
   2c90d:	e9 2d b0 ff ff       	jmp    2793f <JS_CallInternal+0x4e5f>
   2c912:	45 85 f6             	test   r14d,r14d
   2c915:	75 72                	jne    2c989 <JS_CallInternal+0x9ea9>
   2c917:	66 0f ef c0          	pxor   xmm0,xmm0
   2c91b:	66 48 0f 6e fa       	movq   xmm7,rdx
   2c920:	31 c0                	xor    eax,eax
   2c922:	ba 01 00 00 00       	mov    edx,0x1
   2c927:	f2 41 0f 2a c5       	cvtsi2sd xmm0,r13d
   2c92c:	66 0f 2e c7          	ucomisd xmm0,xmm7
   2c930:	0f 9a c0             	setp   al
   2c933:	48 0f 45 c2          	cmovne rax,rdx
   2c937:	e9 03 b0 ff ff       	jmp    2793f <JS_CallInternal+0x4e5f>
   2c93c:	66 48 0f 6e c7       	movq   xmm0,rdi
   2c941:	83 f8 08             	cmp    eax,0x8
   2c944:	0f 84 91 ec ff ff    	je     2b5db <JS_CallInternal+0x8afb>
   2c94a:	85 c0                	test   eax,eax
   2c94c:	0f 85 85 72 ff ff    	jne    23bd7 <JS_CallInternal+0x10f7>
   2c952:	66 0f ef c9          	pxor   xmm1,xmm1
   2c956:	f2 0f 2a c9          	cvtsi2sd xmm1,ecx
   2c95a:	e9 81 ec ff ff       	jmp    2b5e0 <JS_CallInternal+0x8b00>
   2c95f:	48 8b 8d e8 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x118]
   2c966:	89 c2                	mov    edx,eax
   2c968:	48 8d 75 80          	lea    rsi,[rbp-0x80]
   2c96c:	48 8b 79 10          	mov    rdi,QWORD PTR [rcx+0x10]
   2c970:	e8 9b a9 fe ff       	call   17310 <JS_AtomGetStrRT.constprop.0>
   2c975:	48 89 c2             	mov    rdx,rax
   2c978:	e9 fa ec ff ff       	jmp    2b677 <JS_CallInternal+0x8b97>
   2c97d:	48 8b 9d 50 fe ff ff 	mov    rbx,QWORD PTR [rbp-0x1b0]
   2c984:	e9 f7 68 ff ff       	jmp    23280 <JS_CallInternal+0x7a0>
   2c989:	41 83 fe 08          	cmp    r14d,0x8
   2c98d:	75 70                	jne    2c9ff <JS_CallInternal+0x9f1f>
   2c98f:	66 48 0f 6e c2       	movq   xmm0,rdx
   2c994:	66 49 0f 6e cd       	movq   xmm1,r13
   2c999:	31 c0                	xor    eax,eax
   2c99b:	ba 01 00 00 00       	mov    edx,0x1
   2c9a0:	66 0f 2e c1          	ucomisd xmm0,xmm1
   2c9a4:	0f 9a c0             	setp   al
   2c9a7:	48 0f 45 c2          	cmovne rax,rdx
   2c9ab:	e9 8f af ff ff       	jmp    2793f <JS_CallInternal+0x4e5f>
   2c9b0:	66 48 0f 6e c0       	movq   xmm0,rax
   2c9b5:	83 f9 08             	cmp    ecx,0x8
   2c9b8:	74 3e                	je     2c9f8 <JS_CallInternal+0x9f18>
   2c9ba:	85 c9                	test   ecx,ecx
   2c9bc:	0f 85 ee ee ff ff    	jne    2b8b0 <JS_CallInternal+0x8dd0>
   2c9c2:	66 0f ef c9          	pxor   xmm1,xmm1
   2c9c6:	f2 0f 2a ca          	cvtsi2sd xmm1,edx
   2c9ca:	31 c0                	xor    eax,eax
   2c9cc:	66 0f 2f c8          	comisd xmm1,xmm0
   2c9d0:	48 c7 43 e8 01 00 00 	mov    QWORD PTR [rbx-0x18],0x1
   2c9d7:	00 
   2c9d8:	0f 97 c0             	seta   al
   2c9db:	48 83 eb 10          	sub    rbx,0x10
   2c9df:	48 89 43 f0          	mov    QWORD PTR [rbx-0x10],rax
   2c9e3:	e9 a8 b2 ff ff       	jmp    27c90 <JS_CallInternal+0x51b0>
   2c9e8:	4d 89 ec             	mov    r12,r13
   2c9eb:	e9 90 68 ff ff       	jmp    23280 <JS_CallInternal+0x7a0>
   2c9f0:	66 0f ef c0          	pxor   xmm0,xmm0
   2c9f4:	f2 0f 2a c0          	cvtsi2sd xmm0,eax
   2c9f8:	66 48 0f 6e ca       	movq   xmm1,rdx
   2c9fd:	eb cb                	jmp    2c9ca <JS_CallInternal+0x9eea>
   2c9ff:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2ca06:	4c 89 ee             	mov    rsi,r13
   2ca09:	4c 89 f2             	mov    rdx,r14
   2ca0c:	e8 ef ff fe ff       	call   1ca00 <JS_FreeValue>
   2ca11:	e9 18 d8 ff ff       	jmp    2a22e <JS_CallInternal+0x774e>
   2ca16:	66 49 0f 6e c0       	movq   xmm0,r8
   2ca1b:	f2 41 0f 58 45 00    	addsd  xmm0,QWORD PTR [r13+0x0]
   2ca21:	49 c7 45 08 08 00 00 	mov    QWORD PTR [r13+0x8],0x8
   2ca28:	00 
   2ca29:	f2 41 0f 11 45 00    	movsd  QWORD PTR [r13+0x0],xmm0
   2ca2f:	e9 be a5 ff ff       	jmp    26ff2 <JS_CallInternal+0x4512>
   2ca34:	41 0f b6 46 11       	movzx  eax,BYTE PTR [r14+0x11]
   2ca39:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2ca40:	4c 89 f6             	mov    rsi,r14
   2ca43:	4c 89 ea             	mov    rdx,r13
   2ca46:	83 e0 01             	and    eax,0x1
   2ca49:	88 85 50 fe ff ff    	mov    BYTE PTR [rbp-0x1b0],al
   2ca4f:	e8 ac ff fe ff       	call   1ca00 <JS_FreeValue>
   2ca54:	0f b6 85 50 fe ff ff 	movzx  eax,BYTE PTR [rbp-0x1b0]
   2ca5b:	e9 f5 9e ff ff       	jmp    26955 <JS_CallInternal+0x3e75>
   2ca60:	b8 01 00 00 00       	mov    eax,0x1
   2ca65:	e9 eb 9e ff ff       	jmp    26955 <JS_CallInternal+0x3e75>
   2ca6a:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2ca71:	4c 89 ee             	mov    rsi,r13
   2ca74:	4c 89 f2             	mov    rdx,r14
   2ca77:	4c 89 8d 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],r9
   2ca7e:	e8 7d ff fe ff       	call   1ca00 <JS_FreeValue>
   2ca83:	48 8b 8d 50 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x1b0]
   2ca8a:	31 c0                	xor    eax,eax
   2ca8c:	44 39 f1             	cmp    ecx,r14d
   2ca8f:	0f 95 c0             	setne  al
   2ca92:	e9 a8 ae ff ff       	jmp    2793f <JS_CallInternal+0x4e5f>
   2ca97:	4d 89 f4             	mov    r12,r14
   2ca9a:	e9 e1 67 ff ff       	jmp    23280 <JS_CallInternal+0x7a0>
   2ca9f:	41 81 fd f2 00 00 00 	cmp    r13d,0xf2
   2caa6:	0f 8e d4 67 ff ff    	jle    23280 <JS_CallInternal+0x7a0>
   2caac:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2cab3:	44 89 ee             	mov    esi,r13d
   2cab6:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2caba:	e8 b1 c9 fe ff       	call   19470 <JS_FreeAtom.part.0.isra.0>
   2cabf:	e9 bc 67 ff ff       	jmp    23280 <JS_CallInternal+0x7a0>
   2cac4:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2cacb:	4c 8b 60 10          	mov    r12,QWORD PTR [rax+0x10]
   2cacf:	41 80 bc 24 e9 04 00 	cmp    BYTE PTR [r12+0x4e9],0x0
   2cad6:	00 00 
   2cad8:	74 62                	je     2cb3c <JS_CallInternal+0xa05c>
   2cada:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2cae1:	4c 89 ce             	mov    rsi,r9
   2cae4:	48 89 ca             	mov    rdx,rcx
   2cae7:	e8 14 ff fe ff       	call   1ca00 <JS_FreeValue>
   2caec:	31 c0                	xor    eax,eax
   2caee:	48 c7 43 08 06 00 00 	mov    QWORD PTR [rbx+0x8],0x6
   2caf5:	00 
   2caf6:	48 89 03             	mov    QWORD PTR [rbx],rax
   2caf9:	e9 2d 89 ff ff       	jmp    2542b <JS_CallInternal+0x294b>
   2cafe:	3d f2 00 00 00       	cmp    eax,0xf2
   2cb03:	0f 8e 9c f1 ff ff    	jle    2bca5 <JS_CallInternal+0x91c5>
   2cb09:	48 8b 8d e8 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x118]
   2cb10:	89 c0                	mov    eax,eax
   2cb12:	48 8b 79 10          	mov    rdi,QWORD PTR [rcx+0x10]
   2cb16:	48 8b 97 48 04 00 00 	mov    rdx,QWORD PTR [rdi+0x448]
   2cb1d:	48 8b 34 c2          	mov    rsi,QWORD PTR [rdx+rax*8]
   2cb21:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   2cb24:	83 e8 01             	sub    eax,0x1
   2cb27:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   2cb2a:	85 c0                	test   eax,eax
   2cb2c:	0f 8f 73 f1 ff ff    	jg     2bca5 <JS_CallInternal+0x91c5>
   2cb32:	e8 c9 88 fe ff       	call   15400 <JS_FreeAtomStruct>
   2cb37:	e9 69 f1 ff ff       	jmp    2bca5 <JS_CallInternal+0x91c5>
   2cb3c:	41 c6 84 24 e9 04 00 	mov    BYTE PTR [r12+0x4e9],0x1
   2cb43:	00 01 
   2cb45:	48 89 c7             	mov    rdi,rax
   2cb48:	31 c0                	xor    eax,eax
   2cb4a:	48 8d 35 69 09 0a 00 	lea    rsi,[rip+0xa0969]        # cd4ba <_IO_stdin_used+0x4ba>
   2cb51:	48 89 8d 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],rcx
   2cb58:	4c 89 8d 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],r9
   2cb5f:	e8 9c 64 00 00       	call   33000 <JS_ThrowInternalError>
   2cb64:	48 8b 8d 40 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x1c0]
   2cb6b:	41 c6 84 24 e9 04 00 	mov    BYTE PTR [r12+0x4e9],0x0
   2cb72:	00 00 
   2cb74:	4c 8b 8d 50 fe ff ff 	mov    r9,QWORD PTR [rbp-0x1b0]
   2cb7b:	e9 5a ff ff ff       	jmp    2cada <JS_CallInternal+0x9ffa>
   2cb80:	b8 01 00 00 00       	mov    eax,0x1
   2cb85:	e9 6b 9d ff ff       	jmp    268f5 <JS_CallInternal+0x3e15>
   2cb8a:	41 0f b6 46 11       	movzx  eax,BYTE PTR [r14+0x11]
   2cb8f:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2cb96:	4c 89 f6             	mov    rsi,r14
   2cb99:	4c 89 ea             	mov    rdx,r13
   2cb9c:	83 e0 01             	and    eax,0x1
   2cb9f:	89 85 50 fe ff ff    	mov    DWORD PTR [rbp-0x1b0],eax
   2cba5:	e8 56 fe fe ff       	call   1ca00 <JS_FreeValue>
   2cbaa:	8b 85 50 fe ff ff    	mov    eax,DWORD PTR [rbp-0x1b0]
   2cbb0:	e9 40 9d ff ff       	jmp    268f5 <JS_CallInternal+0x3e15>
   2cbb5:	4d 89 f4             	mov    r12,r14
   2cbb8:	e9 c3 66 ff ff       	jmp    23280 <JS_CallInternal+0x7a0>
   2cbbd:	4d 89 f4             	mov    r12,r14
   2cbc0:	e9 bb 66 ff ff       	jmp    23280 <JS_CallInternal+0x7a0>
   2cbc5:	e8 06 62 00 00       	call   32dd0 <JS_ThrowReferenceErrorUninitialized>
   2cbca:	4d 89 f4             	mov    r12,r14
   2cbcd:	e9 ae 66 ff ff       	jmp    23280 <JS_CallInternal+0x7a0>
   2cbd2:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2cbd9:	4c 89 ee             	mov    rsi,r13
   2cbdc:	4c 89 f2             	mov    rdx,r14
   2cbdf:	e8 1c fe fe ff       	call   1ca00 <JS_FreeValue>
   2cbe4:	31 c0                	xor    eax,eax
   2cbe6:	e9 a8 ad ff ff       	jmp    27993 <JS_CallInternal+0x4eb3>
   2cbeb:	4d 89 cc             	mov    r12,r9
   2cbee:	e9 8d 66 ff ff       	jmp    23280 <JS_CallInternal+0x7a0>
   2cbf3:	49 8b 75 00          	mov    rsi,QWORD PTR [r13+0x0]
   2cbf7:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2cbfe:	4c 89 c2             	mov    rdx,r8
   2cc01:	4c 89 f1             	mov    rcx,r14
   2cc04:	4c 89 8d 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],r9
   2cc0b:	4c 89 85 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],r8
   2cc12:	e8 19 82 fe ff       	call   14e30 <JS_ConcatStringInPlace>
   2cc17:	4c 8b 85 50 fe ff ff 	mov    r8,QWORD PTR [rbp-0x1b0]
   2cc1e:	4c 8b 8d 40 fe ff ff 	mov    r9,QWORD PTR [rbp-0x1c0]
   2cc25:	85 c0                	test   eax,eax
   2cc27:	75 60                	jne    2cc89 <JS_CallInternal+0xa1a9>
   2cc29:	49 8b 55 08          	mov    rdx,QWORD PTR [r13+0x8]
   2cc2d:	49 8b 75 00          	mov    rsi,QWORD PTR [r13+0x0]
   2cc31:	83 fa f6             	cmp    edx,0xfffffff6
   2cc34:	76 04                	jbe    2cc3a <JS_CallInternal+0xa15a>
   2cc36:	83 46 fc 01          	add    DWORD PTR [rsi-0x4],0x1
   2cc3a:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2cc41:	4c 89 c1             	mov    rcx,r8
   2cc44:	4d 89 f0             	mov    r8,r14
   2cc47:	4c 89 8d 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],r9
   2cc4e:	e8 9d 35 01 00       	call   401f0 <JS_ConcatString>
   2cc53:	4c 8b 8d 50 fe ff ff 	mov    r9,QWORD PTR [rbp-0x1b0]
   2cc5a:	83 fa 06             	cmp    edx,0x6
   2cc5d:	49 89 c0             	mov    r8,rax
   2cc60:	49 89 d6             	mov    r14,rdx
   2cc63:	74 3b                	je     2cca0 <JS_CallInternal+0xa1c0>
   2cc65:	49 8b 45 00          	mov    rax,QWORD PTR [r13+0x0]
   2cc69:	49 8b 55 08          	mov    rdx,QWORD PTR [r13+0x8]
   2cc6d:	4d 89 45 00          	mov    QWORD PTR [r13+0x0],r8
   2cc71:	4d 89 75 08          	mov    QWORD PTR [r13+0x8],r14
   2cc75:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2cc7c:	48 89 c6             	mov    rsi,rax
   2cc7f:	e8 7c fd fe ff       	call   1ca00 <JS_FreeValue>
   2cc84:	e9 69 a3 ff ff       	jmp    26ff2 <JS_CallInternal+0x4512>
   2cc89:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2cc90:	4c 89 c6             	mov    rsi,r8
   2cc93:	4c 89 f2             	mov    rdx,r14
   2cc96:	e8 65 fd fe ff       	call   1ca00 <JS_FreeValue>
   2cc9b:	e9 52 a3 ff ff       	jmp    26ff2 <JS_CallInternal+0x4512>
   2cca0:	4d 89 cc             	mov    r12,r9
   2cca3:	e9 d8 65 ff ff       	jmp    23280 <JS_CallInternal+0x7a0>
   2cca8:	4c 89 eb             	mov    rbx,r13
   2ccab:	e9 d0 65 ff ff       	jmp    23280 <JS_CallInternal+0x7a0>
   2ccb0:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2ccb7:	89 ce                	mov    esi,ecx
   2ccb9:	e8 12 61 00 00       	call   32dd0 <JS_ThrowReferenceErrorUninitialized>
   2ccbe:	e9 bc d6 ff ff       	jmp    2a37f <JS_CallInternal+0x789f>
   2ccc3:	41 81 fd f2 00 00 00 	cmp    r13d,0xf2
   2ccca:	0f 8e b0 65 ff ff    	jle    23280 <JS_CallInternal+0x7a0>
   2ccd0:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2ccd7:	44 89 ee             	mov    esi,r13d
   2ccda:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2ccde:	e8 8d c7 fe ff       	call   19470 <JS_FreeAtom.part.0.isra.0>
   2cce3:	e9 98 65 ff ff       	jmp    23280 <JS_CallInternal+0x7a0>
   2cce8:	e8 e3 4c fe ff       	call   119d0 <__stack_chk_fail@plt>
   2cced:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2ccf4:	48 8d 35 a6 08 0a 00 	lea    rsi,[rip+0xa08a6]        # cd5a1 <_IO_stdin_used+0x5a1>
   2ccfb:	31 c0                	xor    eax,eax
   2ccfd:	e8 1e 3f 00 00       	call   30c20 <JS_ThrowTypeError>
   2cd02:	e9 79 65 ff ff       	jmp    23280 <JS_CallInternal+0x7a0>
   2cd07:	4d 89 ec             	mov    r12,r13
   2cd0a:	e9 71 65 ff ff       	jmp    23280 <JS_CallInternal+0x7a0>
   2cd0f:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2cd16:	45 39 f0             	cmp    r8d,r14d
   2cd19:	4c 89 ee             	mov    rsi,r13
   2cd1c:	4c 89 f2             	mov    rdx,r14
   2cd1f:	0f 94 85 50 fe ff ff 	sete   BYTE PTR [rbp-0x1b0]
   2cd26:	e8 d5 fc fe ff       	call   1ca00 <JS_FreeValue>
   2cd2b:	0f b6 85 50 fe ff ff 	movzx  eax,BYTE PTR [rbp-0x1b0]
   2cd32:	e9 5c ac ff ff       	jmp    27993 <JS_CallInternal+0x4eb3>
   2cd37:	4d 89 f4             	mov    r12,r14
   2cd3a:	e9 41 65 ff ff       	jmp    23280 <JS_CallInternal+0x7a0>

Disassembly of section .fini:
