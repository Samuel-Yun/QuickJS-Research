
/mnt/c/Users/mzyx/Desktop/0921/js-interpreter-bench/experiments/ic_search_lab/v7_adaptive_layout/artifacts/IO2_LAYOUT.qjs:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .plt.got:

Disassembly of section .plt.sec:

Disassembly of section .text:

0000000000022b00 <JS_CallInternal>:
   22b00:	55                   	push   rbp
   22b01:	48 89 e5             	mov    rbp,rsp
   22b04:	41 57                	push   r15
   22b06:	41 56                	push   r14
   22b08:	41 55                	push   r13
   22b0a:	41 54                	push   r12
   22b0c:	53                   	push   rbx
   22b0d:	48 81 ec 48 02 00 00 	sub    rsp,0x248
   22b14:	48 8b 45 10          	mov    rax,QWORD PTR [rbp+0x10]
   22b18:	48 89 bd a0 fe ff ff 	mov    QWORD PTR [rbp-0x160],rdi
   22b1f:	48 89 b5 e0 fe ff ff 	mov    QWORD PTR [rbp-0x120],rsi
   22b26:	48 89 85 70 fe ff ff 	mov    QWORD PTR [rbp-0x190],rax
   22b2d:	48 8b 45 18          	mov    rax,QWORD PTR [rbp+0x18]
   22b31:	48 89 95 d0 fe ff ff 	mov    QWORD PTR [rbp-0x130],rdx
   22b38:	48 89 85 80 fe ff ff 	mov    QWORD PTR [rbp-0x180],rax
   22b3f:	48 8b 45 20          	mov    rax,QWORD PTR [rbp+0x20]
   22b43:	48 89 8d 78 fe ff ff 	mov    QWORD PTR [rbp-0x188],rcx
   22b4a:	4c 89 85 88 fe ff ff 	mov    QWORD PTR [rbp-0x178],r8
   22b51:	44 89 8d bc fe ff ff 	mov    DWORD PTR [rbp-0x144],r9d
   22b58:	48 89 85 a8 fe ff ff 	mov    QWORD PTR [rbp-0x158],rax
   22b5f:	64 48 8b 04 25 28 00 	mov    rax,QWORD PTR fs:0x28
   22b66:	00 00 
   22b68:	48 89 45 c8          	mov    QWORD PTR [rbp-0x38],rax
   22b6c:	48 8b 47 10          	mov    rax,QWORD PTR [rdi+0x10]
   22b70:	48 89 85 c0 fe ff ff 	mov    QWORD PTR [rbp-0x140],rax
   22b77:	8b 87 a8 01 00 00    	mov    eax,DWORD PTR [rdi+0x1a8]
   22b7d:	89 85 e8 fe ff ff    	mov    DWORD PTR [rbp-0x118],eax
   22b83:	83 e8 01             	sub    eax,0x1
   22b86:	89 87 a8 01 00 00    	mov    DWORD PTR [rdi+0x1a8],eax
   22b8c:	85 c0                	test   eax,eax
   22b8e:	0f 8e 54 05 00 00    	jle    230e8 <JS_CallInternal+0x5e8>
   22b94:	83 bd d0 fe ff ff ff 	cmp    DWORD PTR [rbp-0x130],0xffffffff
   22b9b:	0f 85 7f 05 00 00    	jne    23120 <JS_CallInternal+0x620>
   22ba1:	48 8b 85 e0 fe ff ff 	mov    rax,QWORD PTR [rbp-0x120]
   22ba8:	0f b7 40 12          	movzx  eax,WORD PTR [rax+0x12]
   22bac:	66 83 f8 0d          	cmp    ax,0xd
   22bb0:	0f 85 99 07 00 00    	jne    2334f <JS_CallInternal+0x84f>
   22bb6:	48 8b 85 e0 fe ff ff 	mov    rax,QWORD PTR [rbp-0x120]
   22bbd:	48 8b 40 28          	mov    rax,QWORD PTR [rax+0x28]
   22bc1:	48 89 85 d8 fe ff ff 	mov    QWORD PTR [rbp-0x128],rax
   22bc8:	0f b7 78 38          	movzx  edi,WORD PTR [rax+0x38]
   22bcc:	8b 85 bc fe ff ff    	mov    eax,DWORD PTR [rbp-0x144]
   22bd2:	39 c7                	cmp    edi,eax
   22bd4:	0f 8f fc 01 00 00    	jg     22dd6 <JS_CallInternal+0x2d6>
   22bda:	8b 45 28             	mov    eax,DWORD PTR [rbp+0x28]
   22bdd:	83 e0 02             	and    eax,0x2
   22be0:	0f 45 c7             	cmovne eax,edi
   22be3:	48 8b 95 d8 fe ff ff 	mov    rdx,QWORD PTR [rbp-0x128]
   22bea:	4c 8b bd c0 fe ff ff 	mov    r15,QWORD PTR [rbp-0x140]
   22bf1:	49 89 e8             	mov    r8,rbp
   22bf4:	44 0f b7 52 3a       	movzx  r10d,WORD PTR [rdx+0x3a]
   22bf9:	0f b7 72 3e          	movzx  esi,WORD PTR [rdx+0x3e]
   22bfd:	0f b7 52 40          	movzx  edx,WORD PTR [rdx+0x40]
   22c01:	89 f1                	mov    ecx,esi
   22c03:	44 01 d6             	add    esi,r10d
   22c06:	4c 89 d3             	mov    rbx,r10
   22c09:	01 c6                	add    esi,eax
   22c0b:	49 89 d1             	mov    r9,rdx
   22c0e:	48 63 f6             	movsxd rsi,esi
   22c11:	48 8d 34 72          	lea    rsi,[rdx+rsi*2]
   22c15:	48 c1 e6 03          	shl    rsi,0x3
   22c19:	49 29 f0             	sub    r8,rsi
   22c1c:	4d 3b 87 d0 04 00 00 	cmp    r8,QWORD PTR [r15+0x4d0]
   22c23:	0f 82 d0 07 00 00    	jb     233f9 <JS_CallInternal+0x8f9>
   22c29:	4c 8b bd d8 fe ff ff 	mov    r15,QWORD PTR [rbp-0x128]
   22c30:	4c 8b 9d e0 fe ff ff 	mov    r11,QWORD PTR [rbp-0x120]
   22c37:	48 83 c6 17          	add    rsi,0x17
   22c3b:	45 0f b6 47 10       	movzx  r8d,BYTE PTR [r15+0x10]
   22c40:	44 8b bd bc fe ff ff 	mov    r15d,DWORD PTR [rbp-0x144]
   22c47:	4c 89 9d 08 ff ff ff 	mov    QWORD PTR [rbp-0xf8],r11
   22c4e:	4d 8b 5b 30          	mov    r11,QWORD PTR [r11+0x30]
   22c52:	44 89 85 3c ff ff ff 	mov    DWORD PTR [rbp-0xc4],r8d
   22c59:	49 89 f0             	mov    r8,rsi
   22c5c:	48 81 e6 00 f0 ff ff 	and    rsi,0xfffffffffffff000
   22c63:	44 89 bd 38 ff ff ff 	mov    DWORD PTR [rbp-0xc8],r15d
   22c6a:	4c 8b bd d0 fe ff ff 	mov    r15,QWORD PTR [rbp-0x130]
   22c71:	49 83 e0 f0          	and    r8,0xfffffffffffffff0
   22c75:	4c 89 9d 98 fe ff ff 	mov    QWORD PTR [rbp-0x168],r11
   22c7c:	49 89 e3             	mov    r11,rsp
   22c7f:	49 29 f3             	sub    r11,rsi
   22c82:	4c 89 bd 10 ff ff ff 	mov    QWORD PTR [rbp-0xf0],r15
   22c89:	4c 39 dc             	cmp    rsp,r11
   22c8c:	74 15                	je     22ca3 <JS_CallInternal+0x1a3>
   22c8e:	48 81 ec 00 10 00 00 	sub    rsp,0x1000
   22c95:	48 83 8c 24 f8 0f 00 	or     QWORD PTR [rsp+0xff8],0x0
   22c9c:	00 00 
   22c9e:	4c 39 dc             	cmp    rsp,r11
   22ca1:	75 eb                	jne    22c8e <JS_CallInternal+0x18e>
   22ca3:	41 81 e0 ff 0f 00 00 	and    r8d,0xfff
   22caa:	4c 29 c4             	sub    rsp,r8
   22cad:	4d 85 c0             	test   r8,r8
   22cb0:	74 06                	je     22cb8 <JS_CallInternal+0x1b8>
   22cb2:	4a 83 4c 04 f8 00    	or     QWORD PTR [rsp+r8*1-0x8],0x0
   22cb8:	48 8b b5 a8 fe ff ff 	mov    rsi,QWORD PTR [rbp-0x158]
   22cbf:	4c 8d 5c 24 0f       	lea    r11,[rsp+0xf]
   22cc4:	49 83 e3 f0          	and    r11,0xfffffffffffffff0
   22cc8:	4c 89 9d 30 fe ff ff 	mov    QWORD PTR [rbp-0x1d0],r11
   22ccf:	48 89 b5 90 fe ff ff 	mov    QWORD PTR [rbp-0x170],rsi
   22cd6:	85 c0                	test   eax,eax
   22cd8:	0f 85 3e 61 00 00    	jne    28e1c <JS_CallInternal+0x631c>
   22cde:	48 98                	cdqe
   22ce0:	48 c1 e0 04          	shl    rax,0x4
   22ce4:	4c 01 d8             	add    rax,r11
   22ce7:	48 89 85 b0 fe ff ff 	mov    QWORD PTR [rbp-0x150],rax
   22cee:	48 89 85 20 ff ff ff 	mov    QWORD PTR [rbp-0xe0],rax
   22cf5:	48 8b 85 90 fe ff ff 	mov    rax,QWORD PTR [rbp-0x170]
   22cfc:	48 89 85 18 ff ff ff 	mov    QWORD PTR [rbp-0xe8],rax
   22d03:	45 85 d2             	test   r10d,r10d
   22d06:	74 30                	je     22d38 <JS_CallInternal+0x238>
   22d08:	48 8b bd b0 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x150]
   22d0f:	48 89 de             	mov    rsi,rbx
   22d12:	48 c1 e6 04          	shl    rsi,0x4
   22d16:	48 89 f8             	mov    rax,rdi
   22d19:	48 01 fe             	add    rsi,rdi
   22d1c:	0f 1f 40 00          	nop    DWORD PTR [rax+0x0]
   22d20:	48 c7 00 00 00 00 00 	mov    QWORD PTR [rax],0x0
   22d27:	48 83 c0 10          	add    rax,0x10
   22d2b:	48 c7 40 f8 03 00 00 	mov    QWORD PTR [rax-0x8],0x3
   22d32:	00 
   22d33:	48 39 f0             	cmp    rax,rsi
   22d36:	75 e8                	jne    22d20 <JS_CallInternal+0x220>
   22d38:	0f b7 f9             	movzx  edi,cx
   22d3b:	48 8b 85 b0 fe ff ff 	mov    rax,QWORD PTR [rbp-0x150]
   22d42:	48 c1 e3 04          	shl    rbx,0x4
   22d46:	48 89 f9             	mov    rcx,rdi
   22d49:	48 01 c3             	add    rbx,rax
   22d4c:	48 c1 e1 04          	shl    rcx,0x4
   22d50:	48 8d 3c 0b          	lea    rdi,[rbx+rcx*1]
   22d54:	48 89 bd 28 ff ff ff 	mov    QWORD PTR [rbp-0xd8],rdi
   22d5b:	66 45 85 c9          	test   r9w,r9w
   22d5f:	74 0b                	je     22d6c <JS_CallInternal+0x26c>
   22d61:	48 c1 e2 03          	shl    rdx,0x3
   22d65:	31 f6                	xor    esi,esi
   22d67:	e8 44 ed fe ff       	call   11ab0 <memset@plt>
   22d6c:	48 8b 8d d8 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x128]
   22d73:	48 8b bd c0 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x140]
   22d7a:	48 89 9d 68 fe ff ff 	mov    QWORD PTR [rbp-0x198],rbx
   22d81:	48 8b 41 18          	mov    rax,QWORD PTR [rcx+0x18]
   22d85:	48 8b 49 48          	mov    rcx,QWORD PTR [rcx+0x48]
   22d89:	48 8b 97 f0 04 00 00 	mov    rdx,QWORD PTR [rdi+0x4f0]
   22d90:	48 89 8d e8 fe ff ff 	mov    QWORD PTR [rbp-0x118],rcx
   22d97:	48 8b 8d e0 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x120]
   22d9e:	48 89 95 00 ff ff ff 	mov    QWORD PTR [rbp-0x100],rdx
   22da5:	48 8d 95 00 ff ff ff 	lea    rdx,[rbp-0x100]
   22dac:	48 89 97 f0 04 00 00 	mov    QWORD PTR [rdi+0x4f0],rdx
   22db3:	48 89 8d 60 fe ff ff 	mov    QWORD PTR [rbp-0x1a0],rcx
   22dba:	48 89 95 c8 fe ff ff 	mov    QWORD PTR [rbp-0x138],rdx
   22dc1:	4c 8d 60 01          	lea    r12,[rax+0x1]
   22dc5:	0f b6 00             	movzx  eax,BYTE PTR [rax]
   22dc8:	4c 8d 3d b1 cf 0d 00 	lea    r15,[rip+0xdcfb1]        # ffd80 <dispatch_table.85>
   22dcf:	49 89 c5             	mov    r13,rax
   22dd2:	41 ff 24 c7          	jmp    QWORD PTR [r15+rax*8]
   22dd6:	89 f8                	mov    eax,edi
   22dd8:	e9 06 fe ff ff       	jmp    22be3 <JS_CallInternal+0xe3>
   22ddd:	f3 0f 1e fa          	endbr64
   22de1:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]
   22de8:	f3 0f 1e fa          	endbr64
   22dec:	41 8d 85 4d ff ff ff 	lea    eax,[r13-0xb3]
   22df3:	48 c7 43 08 00 00 00 	mov    QWORD PTR [rbx+0x8],0x0
   22dfa:	00 
   22dfb:	49 83 c4 01          	add    r12,0x1
   22dff:	48 83 c3 10          	add    rbx,0x10
   22e03:	48 89 43 f0          	mov    QWORD PTR [rbx-0x10],rax
   22e07:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   22e0d:	49 89 c5             	mov    r13,rax
   22e10:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   22e14:	ff e0                	jmp    rax
   22e16:	f3 0f 1e fa          	endbr64
   22e1a:	66 0f 1f 44 00 00    	nop    WORD PTR [rax+rax*1+0x0]
   22e20:	f3 0f 1e fa          	endbr64
   22e24:	41 8b 44 24 04       	mov    eax,DWORD PTR [r12+0x4]
   22e29:	f3 0f 6f 53 f0       	movdqu xmm2,XMMWORD PTR [rbx-0x10]
   22e2e:	4d 8d 74 24 09       	lea    r14,[r12+0x9]
   22e33:	41 8b 0c 24          	mov    ecx,DWORD PTR [r12]
   22e37:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   22e3e:	89 85 28 fe ff ff    	mov    DWORD PTR [rbp-0x1d8],eax
   22e44:	41 0f b6 44 24 08    	movzx  eax,BYTE PTR [r12+0x8]
   22e4a:	0f 29 95 50 fe ff ff 	movaps XMMWORD PTR [rbp-0x1b0],xmm2
   22e51:	48 8b 95 58 fe ff ff 	mov    rdx,QWORD PTR [rbp-0x1a8]
   22e58:	88 85 40 fe ff ff    	mov    BYTE PTR [rbp-0x1c0],al
   22e5e:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   22e65:	89 8d 38 fe ff ff    	mov    DWORD PTR [rbp-0x1c8],ecx
   22e6b:	49 89 d4             	mov    r12,rdx
   22e6e:	4c 89 70 30          	mov    QWORD PTR [rax+0x30],r14
   22e72:	48 8b 85 50 fe ff ff 	mov    rax,QWORD PTR [rbp-0x1b0]
   22e79:	48 89 c6             	mov    rsi,rax
   22e7c:	48 89 85 10 fe ff ff 	mov    QWORD PTR [rbp-0x1f0],rax
   22e83:	e8 08 b4 04 00       	call   6e290 <JS_HasProperty>
   22e88:	85 c0                	test   eax,eax
   22e8a:	0f 88 76 07 00 00    	js     23606 <JS_CallInternal+0xb06>
   22e90:	0f 84 95 60 00 00    	je     28f2b <JS_CallInternal+0x642b>
   22e96:	80 bd 40 fe ff ff 00 	cmp    BYTE PTR [rbp-0x1c0],0x0
   22e9d:	0f 85 d9 05 00 00    	jne    2347c <JS_CallInternal+0x97c>
   22ea3:	41 83 ed 71          	sub    r13d,0x71
   22ea7:	41 83 fd 04          	cmp    r13d,0x4
   22eab:	0f 87 20 05 00 00    	ja     233d1 <JS_CallInternal+0x8d1>
   22eb1:	48 8d 15 58 42 0b 00 	lea    rdx,[rip+0xb4258]        # d7110 <qjsc_repl_size+0x444>
   22eb8:	4a 63 04 aa          	movsxd rax,DWORD PTR [rdx+r13*4]
   22ebc:	48 01 d0             	add    rax,rdx
   22ebf:	3e ff e0             	notrack jmp rax
   22ec2:	f3 0f 1e fa          	endbr64
   22ec6:	f3 0f 1e fa          	endbr64
   22eca:	4c 89 a5 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],r12
   22ed1:	45 8d 95 14 ff ff ff 	lea    r10d,[r13-0xec]
   22ed8:	4d 63 da             	movsxd r11,r10d
   22edb:	49 89 de             	mov    r14,rbx
   22ede:	48 8b 8d 50 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x1b0]
   22ee5:	45 89 d1             	mov    r9d,r10d
   22ee8:	49 c1 e3 04          	shl    r11,0x4
   22eec:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   22ef3:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   22efa:	41 b8 03 00 00 00    	mov    r8d,0x3
   22f00:	4d 29 de             	sub    r14,r11
   22f03:	4c 89 9d 38 fe ff ff 	mov    QWORD PTR [rbp-0x1c8],r11
   22f0a:	49 8b 76 f0          	mov    rsi,QWORD PTR [r14-0x10]
   22f0e:	49 8b 56 f8          	mov    rdx,QWORD PTR [r14-0x8]
   22f12:	48 89 48 30          	mov    QWORD PTR [rax+0x30],rcx
   22f16:	31 c9                	xor    ecx,ecx
   22f18:	6a 00                	push   0x0
   22f1a:	4d 8d 66 f0          	lea    r12,[r14-0x10]
   22f1e:	41 56                	push   r14
   22f20:	6a 03                	push   0x3
   22f22:	6a 00                	push   0x0
   22f24:	44 89 95 40 fe ff ff 	mov    DWORD PTR [rbp-0x1c0],r10d
   22f2b:	e8 d0 fb ff ff       	call   22b00 <JS_CallInternal>
   22f30:	48 83 c4 20          	add    rsp,0x20
   22f34:	44 8b 95 40 fe ff ff 	mov    r10d,DWORD PTR [rbp-0x1c0]
   22f3b:	4c 8b 9d 38 fe ff ff 	mov    r11,QWORD PTR [rbp-0x1c8]
   22f42:	83 fa 06             	cmp    edx,0x6
   22f45:	49 89 c1             	mov    r9,rax
   22f48:	49 89 d0             	mov    r8,rdx
   22f4b:	48 89 d1             	mov    rcx,rdx
   22f4e:	0f 84 d8 64 00 00    	je     2942c <JS_CallInternal+0x692c>
   22f54:	41 83 fd 23          	cmp    r13d,0x23
   22f58:	0f 84 95 02 00 00    	je     231f3 <JS_CallInternal+0x6f3>
   22f5e:	4d 01 de             	add    r14,r11
   22f61:	45 85 d2             	test   r10d,r10d
   22f64:	78 77                	js     22fdd <JS_CallInternal+0x4dd>
   22f66:	4d 89 e5             	mov    r13,r12
   22f69:	4d 89 f0             	mov    r8,r14
   22f6c:	48 89 95 38 fe ff ff 	mov    QWORD PTR [rbp-0x1c8],rdx
   22f73:	45 89 d4             	mov    r12d,r10d
   22f76:	49 89 c6             	mov    r14,rax
   22f79:	eb 0e                	jmp    22f89 <JS_CallInternal+0x489>
   22f7b:	0f 1f 44 00 00       	nop    DWORD PTR [rax+rax*1+0x0]
   22f80:	49 83 c5 10          	add    r13,0x10
   22f84:	4d 39 c5             	cmp    r13,r8
   22f87:	74 47                	je     22fd0 <JS_CallInternal+0x4d0>
   22f89:	49 8b 4d 08          	mov    rcx,QWORD PTR [r13+0x8]
   22f8d:	49 8b 75 00          	mov    rsi,QWORD PTR [r13+0x0]
   22f91:	83 f9 f6             	cmp    ecx,0xfffffff6
   22f94:	76 ea                	jbe    22f80 <JS_CallInternal+0x480>
   22f96:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   22f99:	8d 50 ff             	lea    edx,[rax-0x1]
   22f9c:	89 56 fc             	mov    DWORD PTR [rsi-0x4],edx
   22f9f:	85 d2                	test   edx,edx
   22fa1:	7f dd                	jg     22f80 <JS_CallInternal+0x480>
   22fa3:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   22faa:	48 89 ca             	mov    rdx,rcx
   22fad:	4c 89 85 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],r8
   22fb4:	49 83 c5 10          	add    r13,0x10
   22fb8:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   22fbc:	e8 df 98 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   22fc1:	4c 8b 85 40 fe ff ff 	mov    r8,QWORD PTR [rbp-0x1c0]
   22fc8:	4d 39 c5             	cmp    r13,r8
   22fcb:	75 bc                	jne    22f89 <JS_CallInternal+0x489>
   22fcd:	0f 1f 00             	nop    DWORD PTR [rax]
   22fd0:	4c 8b 85 38 fe ff ff 	mov    r8,QWORD PTR [rbp-0x1c8]
   22fd7:	45 89 e2             	mov    r10d,r12d
   22fda:	4d 89 f1             	mov    r9,r14
   22fdd:	41 8d 42 01          	lea    eax,[r10+0x1]
   22fe1:	48 98                	cdqe
   22fe3:	48 c1 e0 04          	shl    rax,0x4
   22fe7:	48 89 c2             	mov    rdx,rax
   22fea:	48 89 d8             	mov    rax,rbx
   22fed:	48 29 d0             	sub    rax,rdx
   22ff0:	4c 89 08             	mov    QWORD PTR [rax],r9
   22ff3:	48 8d 58 10          	lea    rbx,[rax+0x10]
   22ff7:	4c 89 40 08          	mov    QWORD PTR [rax+0x8],r8
   22ffb:	48 8b 85 50 fe ff ff 	mov    rax,QWORD PTR [rbp-0x1b0]
   23002:	4c 8d 60 01          	lea    r12,[rax+0x1]
   23006:	0f b6 00             	movzx  eax,BYTE PTR [rax]
   23009:	49 89 c5             	mov    r13,rax
   2300c:	41 ff 24 c7          	jmp    QWORD PTR [r15+rax*8]
   23010:	f3 0f 1e fa          	endbr64
   23014:	f3 0f 1e fa          	endbr64
   23018:	41 8b 04 24          	mov    eax,DWORD PTR [r12]
   2301c:	31 f6                	xor    esi,esi
   2301e:	b9 01 00 00 00       	mov    ecx,0x1
   23023:	ba 02 00 00 00       	mov    edx,0x2
   23028:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2302f:	45 0f b7 74 24 04    	movzx  r14d,WORD PTR [r12+0x4]
   23035:	89 85 50 fe ff ff    	mov    DWORD PTR [rbp-0x1b0],eax
   2303b:	49 8d 44 24 06       	lea    rax,[r12+0x6]
   23040:	48 89 85 38 fe ff ff 	mov    QWORD PTR [rbp-0x1c8],rax
   23047:	48 8d 43 10          	lea    rax,[rbx+0x10]
   2304b:	48 89 85 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],rax
   23052:	e8 79 59 02 00       	call   489d0 <JS_NewObjectProtoClass>
   23057:	48 89 53 08          	mov    QWORD PTR [rbx+0x8],rdx
   2305b:	83 7b 08 06          	cmp    DWORD PTR [rbx+0x8],0x6
   2305f:	48 89 03             	mov    QWORD PTR [rbx],rax
   23062:	0f 84 23 02 00 00    	je     2328b <JS_CallInternal+0x78b>
   23068:	41 83 fd 78          	cmp    r13d,0x78
   2306c:	0f 85 ed 01 00 00    	jne    2325f <JS_CallInternal+0x75f>
   23072:	48 8b 85 98 fe ff ff 	mov    rax,QWORD PTR [rbp-0x168]
   23079:	4e 8b 2c f0          	mov    r13,QWORD PTR [rax+r14*8]
   2307d:	41 83 45 fc 01       	add    DWORD PTR [r13-0x4],0x1
   23082:	48 8b 33             	mov    rsi,QWORD PTR [rbx]
   23085:	8b 95 50 fe ff ff    	mov    edx,DWORD PTR [rbp-0x1b0]
   2308b:	b9 22 00 00 00       	mov    ecx,0x22
   23090:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   23097:	e8 e4 2f 02 00       	call   46080 <add_property>
   2309c:	48 85 c0             	test   rax,rax
   2309f:	0f 84 31 8f 00 00    	je     2bfd6 <JS_CallInternal+0x94d6>
   230a5:	4c 89 28             	mov    QWORD PTR [rax],r13
   230a8:	8b b5 50 fe ff ff    	mov    esi,DWORD PTR [rbp-0x1b0]
   230ae:	31 d2                	xor    edx,edx
   230b0:	48 83 c3 20          	add    rbx,0x20
   230b4:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   230bb:	49 83 c4 07          	add    r12,0x7
   230bf:	e8 5c 0f 01 00       	call   34020 <__JS_AtomToValue>
   230c4:	48 8b 8d 40 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x1c0]
   230cb:	48 89 01             	mov    QWORD PTR [rcx],rax
   230ce:	48 89 51 08          	mov    QWORD PTR [rcx+0x8],rdx
   230d2:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   230d8:	49 89 c5             	mov    r13,rax
   230db:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   230df:	ff e0                	jmp    rax
   230e1:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]
   230e8:	e8 c3 00 01 00       	call   331b0 <__js_poll_interrupts>
   230ed:	85 c0                	test   eax,eax
   230ef:	0f 84 9f fa ff ff    	je     22b94 <JS_CallInternal+0x94>
   230f5:	31 c0                	xor    eax,eax
   230f7:	ba 06 00 00 00       	mov    edx,0x6
   230fc:	48 8b 4d c8          	mov    rcx,QWORD PTR [rbp-0x38]
   23100:	64 48 2b 0c 25 28 00 	sub    rcx,QWORD PTR fs:0x28
   23107:	00 00 
   23109:	0f 85 05 9c 00 00    	jne    2cd14 <JS_CallInternal+0xa214>
   2310f:	48 8d 65 d8          	lea    rsp,[rbp-0x28]
   23113:	5b                   	pop    rbx
   23114:	41 5c                	pop    r12
   23116:	41 5d                	pop    r13
   23118:	41 5e                	pop    r14
   2311a:	41 5f                	pop    r15
   2311c:	5d                   	pop    rbp
   2311d:	c3                   	ret
   2311e:	66 90                	xchg   ax,ax
   23120:	f6 45 28 04          	test   BYTE PTR [rbp+0x28],0x4
   23124:	0f 84 d6 03 00 00    	je     23500 <JS_CallInternal+0xa00>
   2312a:	48 8b 85 e0 fe ff ff 	mov    rax,QWORD PTR [rbp-0x120]
   23131:	48 8b 48 58          	mov    rcx,QWORD PTR [rax+0x58]
   23135:	48 8b 50 68          	mov    rdx,QWORD PTR [rax+0x68]
   23139:	48 8d 78 50          	lea    rdi,[rax+0x50]
   2313d:	48 89 bd c8 fe ff ff 	mov    QWORD PTR [rbp-0x138],rdi
   23144:	48 8b 59 28          	mov    rbx,QWORD PTR [rcx+0x28]
   23148:	48 89 8d 60 fe ff ff 	mov    QWORD PTR [rbp-0x1a0],rcx
   2314f:	48 8b 49 30          	mov    rcx,QWORD PTR [rcx+0x30]
   23153:	48 89 95 30 fe ff ff 	mov    QWORD PTR [rbp-0x1d0],rdx
   2315a:	48 8b 73 48          	mov    rsi,QWORD PTR [rbx+0x48]
   2315e:	48 89 9d d8 fe ff ff 	mov    QWORD PTR [rbp-0x128],rbx
   23165:	48 89 8d 98 fe ff ff 	mov    QWORD PTR [rbp-0x168],rcx
   2316c:	48 89 c1             	mov    rcx,rax
   2316f:	48 89 b5 e8 fe ff ff 	mov    QWORD PTR [rbp-0x118],rsi
   23176:	48 8b 70 70          	mov    rsi,QWORD PTR [rax+0x70]
   2317a:	0f b7 43 3a          	movzx  eax,WORD PTR [rbx+0x3a]
   2317e:	4c 8b a1 80 00 00 00 	mov    r12,QWORD PTR [rcx+0x80]
   23185:	48 89 b5 b0 fe ff ff 	mov    QWORD PTR [rbp-0x150],rsi
   2318c:	48 8b 99 90 00 00 00 	mov    rbx,QWORD PTR [rcx+0x90]
   23193:	48 c7 81 90 00 00 00 	mov    QWORD PTR [rcx+0x90],0x0
   2319a:	00 00 00 00 
   2319e:	48 c1 e0 04          	shl    rax,0x4
   231a2:	48 01 f0             	add    rax,rsi
   231a5:	48 8b b5 c0 fe ff ff 	mov    rsi,QWORD PTR [rbp-0x140]
   231ac:	48 89 85 68 fe ff ff 	mov    QWORD PTR [rbp-0x198],rax
   231b3:	48 8b 86 f0 04 00 00 	mov    rax,QWORD PTR [rsi+0x4f0]
   231ba:	48 89 41 50          	mov    QWORD PTR [rcx+0x50],rax
   231be:	48 89 be f0 04 00 00 	mov    QWORD PTR [rsi+0x4f0],rdi
   231c5:	8b 79 24             	mov    edi,DWORD PTR [rcx+0x24]
   231c8:	85 ff                	test   edi,edi
   231ca:	0f 84 9d 02 00 00    	je     2346d <JS_CallInternal+0x96d>
   231d0:	48 8b 85 30 fe ff ff 	mov    rax,QWORD PTR [rbp-0x1d0]
   231d7:	48 89 85 90 fe ff ff 	mov    QWORD PTR [rbp-0x170],rax
   231de:	e9 bd 00 00 00       	jmp    232a0 <JS_CallInternal+0x7a0>
   231e3:	f3 0f 1e fa          	endbr64
   231e7:	48 8b 43 f0          	mov    rax,QWORD PTR [rbx-0x10]
   231eb:	48 8b 4b f8          	mov    rcx,QWORD PTR [rbx-0x8]
   231ef:	48 83 eb 10          	sub    rbx,0x10
   231f3:	48 8b bd d8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x128]
   231fa:	66 83 7f 40 00       	cmp    WORD PTR [rdi+0x40],0x0
   231ff:	0f 85 61 6e 00 00    	jne    2a066 <JS_CallInternal+0x7566>
   23205:	4c 8b a5 30 fe ff ff 	mov    r12,QWORD PTR [rbp-0x1d0]
   2320c:	49 39 dc             	cmp    r12,rbx
   2320f:	0f 83 1a 01 00 00    	jae    2332f <JS_CallInternal+0x82f>
   23215:	4c 8b ad e8 fe ff ff 	mov    r13,QWORD PTR [rbp-0x118]
   2321c:	49 89 ce             	mov    r14,rcx
   2321f:	49 89 c7             	mov    r15,rax
   23222:	eb 11                	jmp    23235 <JS_CallInternal+0x735>
   23224:	0f 1f 40 00          	nop    DWORD PTR [rax+0x0]
   23228:	49 83 c4 10          	add    r12,0x10
   2322c:	49 39 dc             	cmp    r12,rbx
   2322f:	0f 83 b9 01 00 00    	jae    233ee <JS_CallInternal+0x8ee>
   23235:	4d 8b 44 24 08       	mov    r8,QWORD PTR [r12+0x8]
   2323a:	49 8b 34 24          	mov    rsi,QWORD PTR [r12]
   2323e:	41 83 f8 f6          	cmp    r8d,0xfffffff6
   23242:	76 e4                	jbe    23228 <JS_CallInternal+0x728>
   23244:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   23247:	8d 50 ff             	lea    edx,[rax-0x1]
   2324a:	89 56 fc             	mov    DWORD PTR [rsi-0x4],edx
   2324d:	85 d2                	test   edx,edx
   2324f:	7f d7                	jg     23228 <JS_CallInternal+0x728>
   23251:	49 8b 7d 10          	mov    rdi,QWORD PTR [r13+0x10]
   23255:	4c 89 c2             	mov    rdx,r8
   23258:	e8 43 96 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2325d:	eb c9                	jmp    23228 <JS_CallInternal+0x728>
   2325f:	31 c9                	xor    ecx,ecx
   23261:	48 8b b5 c8 fe ff ff 	mov    rsi,QWORD PTR [rbp-0x138]
   23268:	41 83 fd 77          	cmp    r13d,0x77
   2326c:	41 0f b7 d6          	movzx  edx,r14w
   23270:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   23277:	0f 94 c1             	sete   cl
   2327a:	e8 41 43 02 00       	call   475c0 <get_var_ref>
   2327f:	49 89 c5             	mov    r13,rax
   23282:	48 85 c0             	test   rax,rax
   23285:	0f 85 f7 fd ff ff    	jne    23082 <JS_CallInternal+0x582>
   2328b:	48 8b 9d 40 fe ff ff 	mov    rbx,QWORD PTR [rbp-0x1c0]
   23292:	4c 8b a5 38 fe ff ff 	mov    r12,QWORD PTR [rbp-0x1c8]
   23299:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]
   232a0:	48 8b 8d c0 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x140]
   232a7:	83 b9 e0 04 00 00 ff 	cmp    DWORD PTR [rcx+0x4e0],0xffffffff
   232ae:	48 8b 81 d8 04 00 00 	mov    rax,QWORD PTR [rcx+0x4d8]
   232b5:	75 39                	jne    232f0 <JS_CallInternal+0x7f0>
   232b7:	66 83 78 12 03       	cmp    WORD PTR [rax+0x12],0x3
   232bc:	75 32                	jne    232f0 <JS_CallInternal+0x7f0>
   232be:	48 8b 48 18          	mov    rcx,QWORD PTR [rax+0x18]
   232c2:	8b 51 18             	mov    edx,DWORD PTR [rcx+0x18]
   232c5:	89 d0                	mov    eax,edx
   232c7:	83 e0 39             	and    eax,0x39
   232ca:	8b 44 81 38          	mov    eax,DWORD PTR [rcx+rax*4+0x38]
   232ce:	48 85 c0             	test   rax,rax
   232d1:	0f 84 0c 68 00 00    	je     29ae3 <JS_CallInternal+0x6fe3>
   232d7:	48 8d 14 95 34 00 00 	lea    rdx,[rdx*4+0x34]
   232de:	00 
   232df:	48 8d 04 c2          	lea    rax,[rdx+rax*8]
   232e3:	48 01 c8             	add    rax,rcx
   232e6:	83 78 04 39          	cmp    DWORD PTR [rax+0x4],0x39
   232ea:	0f 85 e6 67 00 00    	jne    29ad6 <JS_CallInternal+0x6fd6>
   232f0:	48 8b 85 c0 fe ff ff 	mov    rax,QWORD PTR [rbp-0x140]
   232f7:	80 b8 e8 04 00 00 00 	cmp    BYTE PTR [rax+0x4e8],0x0
   232fe:	0f 84 39 01 00 00    	je     2343d <JS_CallInternal+0x93d>
   23304:	48 8b 85 d8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x128]
   2330b:	b9 06 00 00 00       	mov    ecx,0x6
   23310:	f6 40 11 30          	test   BYTE PTR [rax+0x11],0x30
   23314:	b8 00 00 00 00       	mov    eax,0x0
   23319:	0f 84 d4 fe ff ff    	je     231f3 <JS_CallInternal+0x6f3>
   2331f:	90                   	nop
   23320:	48 8b bd c8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x138]
   23327:	4c 89 67 30          	mov    QWORD PTR [rdi+0x30],r12
   2332b:	48 89 5f 40          	mov    QWORD PTR [rdi+0x40],rbx
   2332f:	48 8b 9d c8 fe ff ff 	mov    rbx,QWORD PTR [rbp-0x138]
   23336:	48 8b 13             	mov    rdx,QWORD PTR [rbx]
   23339:	48 8b 9d c0 fe ff ff 	mov    rbx,QWORD PTR [rbp-0x140]
   23340:	48 89 93 f0 04 00 00 	mov    QWORD PTR [rbx+0x4f0],rdx
   23347:	48 89 ca             	mov    rdx,rcx
   2334a:	e9 ad fd ff ff       	jmp    230fc <JS_CallInternal+0x5fc>
   2334f:	48 8b 8d c0 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x140]
   23356:	48 8d 04 80          	lea    rax,[rax+rax*4]
   2335a:	48 c1 e0 03          	shl    rax,0x3
   2335e:	48 03 81 58 04 00 00 	add    rax,QWORD PTR [rcx+0x458]
   23365:	48 8b 40 18          	mov    rax,QWORD PTR [rax+0x18]
   23369:	48 85 c0             	test   rax,rax
   2336c:	0f 84 8e 01 00 00    	je     23500 <JS_CallInternal+0xa00>
   23372:	8b 4d 28             	mov    ecx,DWORD PTR [rbp+0x28]
   23375:	48 8b b5 e0 fe ff ff 	mov    rsi,QWORD PTR [rbp-0x120]
   2337c:	44 8b 8d bc fe ff ff 	mov    r9d,DWORD PTR [rbp-0x144]
   23383:	4c 8b 85 88 fe ff ff 	mov    r8,QWORD PTR [rbp-0x178]
   2338a:	48 8b 95 d0 fe ff ff 	mov    rdx,QWORD PTR [rbp-0x130]
   23391:	48 8b bd a0 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x160]
   23398:	51                   	push   rcx
   23399:	48 8b 8d 78 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x188]
   233a0:	ff b5 a8 fe ff ff    	push   QWORD PTR [rbp-0x158]
   233a6:	ff d0                	call   rax
   233a8:	59                   	pop    rcx
   233a9:	5e                   	pop    rsi
   233aa:	e9 4d fd ff ff       	jmp    230fc <JS_CallInternal+0x5fc>
   233af:	8b b5 38 fe ff ff    	mov    esi,DWORD PTR [rbp-0x1c8]
   233b5:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   233bc:	31 d2                	xor    edx,edx
   233be:	4c 8d 63 10          	lea    r12,[rbx+0x10]
   233c2:	e8 59 0c 01 00       	call   34020 <__JS_AtomToValue>
   233c7:	48 89 03             	mov    QWORD PTR [rbx],rax
   233ca:	48 89 53 08          	mov    QWORD PTR [rbx+0x8],rdx
   233ce:	4c 89 e3             	mov    rbx,r12
   233d1:	8b 85 28 fe ff ff    	mov    eax,DWORD PTR [rbp-0x1d8]
   233d7:	83 e8 05             	sub    eax,0x5
   233da:	48 98                	cdqe
   233dc:	49 01 c6             	add    r14,rax
   233df:	41 0f b6 06          	movzx  eax,BYTE PTR [r14]
   233e3:	4d 8d 66 01          	lea    r12,[r14+0x1]
   233e7:	49 89 c5             	mov    r13,rax
   233ea:	41 ff 24 c7          	jmp    QWORD PTR [r15+rax*8]
   233ee:	4c 89 f1             	mov    rcx,r14
   233f1:	4c 89 f8             	mov    rax,r15
   233f4:	e9 36 ff ff ff       	jmp    2332f <JS_CallInternal+0x82f>
   233f9:	48 8b bd a0 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x160]
   23400:	48 8d 35 a4 a0 0a 00 	lea    rsi,[rip+0xaa0a4]        # cd4ab <_IO_stdin_used+0x4ab>
   23407:	31 c0                	xor    eax,eax
   23409:	e8 22 fc 00 00       	call   33030 <JS_ThrowInternalError>
   2340e:	e9 e9 fc ff ff       	jmp    230fc <JS_CallInternal+0x5fc>
   23413:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2341a:	4c 89 ee             	mov    rsi,r13
   2341d:	4c 89 f2             	mov    rdx,r14
   23420:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   23424:	e8 77 94 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   23429:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]
   23430:	41 83 fe 05          	cmp    r14d,0x5
   23434:	0f 84 ae 61 00 00    	je     295e8 <JS_CallInternal+0x6ae8>
   2343a:	4c 89 fb             	mov    rbx,r15
   2343d:	48 39 9d 68 fe ff ff 	cmp    QWORD PTR [rbp-0x198],rbx
   23444:	0f 83 ba fe ff ff    	jae    23304 <JS_CallInternal+0x804>
   2344a:	4c 8b 73 f8          	mov    r14,QWORD PTR [rbx-0x8]
   2344e:	4c 8d 7b f0          	lea    r15,[rbx-0x10]
   23452:	4c 8b 6b f0          	mov    r13,QWORD PTR [rbx-0x10]
   23456:	41 83 fe f6          	cmp    r14d,0xfffffff6
   2345a:	76 d4                	jbe    23430 <JS_CallInternal+0x930>
   2345c:	41 8b 45 fc          	mov    eax,DWORD PTR [r13-0x4]
   23460:	83 e8 01             	sub    eax,0x1
   23463:	41 89 45 fc          	mov    DWORD PTR [r13-0x4],eax
   23467:	85 c0                	test   eax,eax
   23469:	7f c5                	jg     23430 <JS_CallInternal+0x930>
   2346b:	eb a6                	jmp    23413 <JS_CallInternal+0x913>
   2346d:	48 89 95 90 fe ff ff 	mov    QWORD PTR [rbp-0x170],rdx
   23474:	4c 89 e0             	mov    rax,r12
   23477:	e9 45 f9 ff ff       	jmp    22dc1 <JS_CallInternal+0x2c1>
   2347c:	48 83 ec 08          	sub    rsp,0x8
   23480:	4c 8b 85 50 fe ff ff 	mov    r8,QWORD PTR [rbp-0x1b0]
   23487:	48 8b b5 10 fe ff ff 	mov    rsi,QWORD PTR [rbp-0x1f0]
   2348e:	b9 f1 00 00 00       	mov    ecx,0xf1
   23493:	6a 00                	push   0x0
   23495:	4c 8b 8d 58 fe ff ff 	mov    r9,QWORD PTR [rbp-0x1a8]
   2349c:	4c 89 e2             	mov    rdx,r12
   2349f:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   234a6:	e8 35 99 00 00       	call   2cde0 <JS_GetPropertyInternal>
   234ab:	59                   	pop    rcx
   234ac:	5e                   	pop    rsi
   234ad:	49 89 c0             	mov    r8,rax
   234b0:	49 89 d4             	mov    r12,rdx
   234b3:	83 fa 06             	cmp    edx,0x6
   234b6:	0f 84 4a 01 00 00    	je     23606 <JS_CallInternal+0xb06>
   234bc:	83 fa ff             	cmp    edx,0xffffffff
   234bf:	0f 84 05 5a 00 00    	je     28eca <JS_CallInternal+0x63ca>
   234c5:	83 fa f6             	cmp    edx,0xfffffff6
   234c8:	0f 86 d5 f9 ff ff    	jbe    22ea3 <JS_CallInternal+0x3a3>
   234ce:	8b 40 fc             	mov    eax,DWORD PTR [rax-0x4]
   234d1:	83 e8 01             	sub    eax,0x1
   234d4:	41 89 40 fc          	mov    DWORD PTR [r8-0x4],eax
   234d8:	85 c0                	test   eax,eax
   234da:	0f 8f c3 f9 ff ff    	jg     22ea3 <JS_CallInternal+0x3a3>
   234e0:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   234e7:	4c 89 c6             	mov    rsi,r8
   234ea:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   234ee:	e8 ad 93 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   234f3:	e9 ab f9 ff ff       	jmp    22ea3 <JS_CallInternal+0x3a3>
   234f8:	0f 1f 84 00 00 00 00 	nop    DWORD PTR [rax+rax*1+0x0]
   234ff:	00 
   23500:	48 8b bd a0 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x160]
   23507:	48 8d 35 7a b6 0a 00 	lea    rsi,[rip+0xab67a]        # ceb88 <_IO_stdin_used+0x1b88>
   2350e:	31 c0                	xor    eax,eax
   23510:	e8 3b d7 00 00       	call   30c50 <JS_ThrowTypeError>
   23515:	e9 e2 fb ff ff       	jmp    230fc <JS_CallInternal+0x5fc>
   2351a:	48 8b 85 50 fe ff ff 	mov    rax,QWORD PTR [rbp-0x1b0]
   23521:	48 8b 95 58 fe ff ff 	mov    rdx,QWORD PTR [rbp-0x1a8]
   23528:	8b 8d 38 fe ff ff    	mov    ecx,DWORD PTR [rbp-0x1c8]
   2352e:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   23535:	48 89 c6             	mov    rsi,rax
   23538:	49 89 c5             	mov    r13,rax
   2353b:	49 89 d4             	mov    r12,rdx
   2353e:	e8 4d ad 04 00       	call   6e290 <JS_HasProperty>
   23543:	85 c0                	test   eax,eax
   23545:	0f 88 bb 00 00 00    	js     23606 <JS_CallInternal+0xb06>
   2354b:	b8 03 00 00 00       	mov    eax,0x3
   23550:	b9 00 00 00 00       	mov    ecx,0x0
   23555:	0f 85 dd 76 00 00    	jne    2ac38 <JS_CallInternal+0x8138>
   2355b:	48 89 0b             	mov    QWORD PTR [rbx],rcx
   2355e:	48 83 c3 10          	add    rbx,0x10
   23562:	48 89 43 f8          	mov    QWORD PTR [rbx-0x8],rax
   23566:	e9 66 fe ff ff       	jmp    233d1 <JS_CallInternal+0x8d1>
   2356b:	48 8b 85 50 fe ff ff 	mov    rax,QWORD PTR [rbp-0x1b0]
   23572:	48 8b 95 58 fe ff ff 	mov    rdx,QWORD PTR [rbp-0x1a8]
   23579:	8b 8d 38 fe ff ff    	mov    ecx,DWORD PTR [rbp-0x1c8]
   2357f:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   23586:	48 89 c6             	mov    rsi,rax
   23589:	e8 02 ad 04 00       	call   6e290 <JS_HasProperty>
   2358e:	85 c0                	test   eax,eax
   23590:	0f 8e 54 88 00 00    	jle    2bdea <JS_CallInternal+0x92ea>
   23596:	48 83 ec 08          	sub    rsp,0x8
   2359a:	4c 8b 43 e0          	mov    r8,QWORD PTR [rbx-0x20]
   2359e:	4c 8b 4b e8          	mov    r9,QWORD PTR [rbx-0x18]
   235a2:	4c 8d 63 e0          	lea    r12,[rbx-0x20]
   235a6:	4c 8b 95 50 fe ff ff 	mov    r10,QWORD PTR [rbp-0x1b0]
   235ad:	4c 8b 9d 58 fe ff ff 	mov    r11,QWORD PTR [rbp-0x1a8]
   235b4:	68 00 80 00 00       	push   0x8000
   235b9:	8b 8d 38 fe ff ff    	mov    ecx,DWORD PTR [rbp-0x1c8]
   235bf:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   235c6:	41 53                	push   r11
   235c8:	4c 89 d6             	mov    rsi,r10
   235cb:	4c 89 da             	mov    rdx,r11
   235ce:	41 52                	push   r10
   235d0:	e8 3b a5 00 00       	call   2db10 <JS_SetPropertyInternal>
   235d5:	48 8b 53 f8          	mov    rdx,QWORD PTR [rbx-0x8]
   235d9:	48 8b 73 f0          	mov    rsi,QWORD PTR [rbx-0x10]
   235dd:	48 83 c4 20          	add    rsp,0x20
   235e1:	41 89 c5             	mov    r13d,eax
   235e4:	83 fa f6             	cmp    edx,0xfffffff6
   235e7:	76 11                	jbe    235fa <JS_CallInternal+0xafa>
   235e9:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   235ec:	83 e8 01             	sub    eax,0x1
   235ef:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   235f2:	85 c0                	test   eax,eax
   235f4:	0f 8e 20 88 00 00    	jle    2be1a <JS_CallInternal+0x931a>
   235fa:	4c 89 e3             	mov    rbx,r12
   235fd:	45 85 ed             	test   r13d,r13d
   23600:	0f 89 cb fd ff ff    	jns    233d1 <JS_CallInternal+0x8d1>
   23606:	4d 89 f4             	mov    r12,r14
   23609:	e9 92 fc ff ff       	jmp    232a0 <JS_CallInternal+0x7a0>
   2360e:	48 8b 85 50 fe ff ff 	mov    rax,QWORD PTR [rbp-0x1b0]
   23615:	48 8b 95 58 fe ff ff 	mov    rdx,QWORD PTR [rbp-0x1a8]
   2361c:	8b 8d 38 fe ff ff    	mov    ecx,DWORD PTR [rbp-0x1c8]
   23622:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   23629:	48 89 c6             	mov    rsi,rax
   2362c:	49 89 c5             	mov    r13,rax
   2362f:	49 89 d4             	mov    r12,rdx
   23632:	e8 59 ac 04 00       	call   6e290 <JS_HasProperty>
   23637:	85 c0                	test   eax,eax
   23639:	0f 8e c4 86 00 00    	jle    2bd03 <JS_CallInternal+0x9203>
   2363f:	48 83 ec 08          	sub    rsp,0x8
   23643:	8b 8d 38 fe ff ff    	mov    ecx,DWORD PTR [rbp-0x1c8]
   23649:	4c 89 ee             	mov    rsi,r13
   2364c:	4c 89 e2             	mov    rdx,r12
   2364f:	4c 8b 8d 58 fe ff ff 	mov    r9,QWORD PTR [rbp-0x1a8]
   23656:	4c 8b 85 50 fe ff ff 	mov    r8,QWORD PTR [rbp-0x1b0]
   2365d:	6a 00                	push   0x0
   2365f:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   23666:	e8 75 97 00 00       	call   2cde0 <JS_GetPropertyInternal>
   2366b:	41 59                	pop    r9
   2366d:	41 5a                	pop    r10
   2366f:	48 89 c1             	mov    rcx,rax
   23672:	48 89 d0             	mov    rax,rdx
   23675:	83 fa 06             	cmp    edx,0x6
   23678:	74 8c                	je     23606 <JS_CallInternal+0xb06>
   2367a:	48 8b 53 f8          	mov    rdx,QWORD PTR [rbx-0x8]
   2367e:	48 8b 73 f0          	mov    rsi,QWORD PTR [rbx-0x10]
   23682:	48 89 43 f8          	mov    QWORD PTR [rbx-0x8],rax
   23686:	48 89 4b f0          	mov    QWORD PTR [rbx-0x10],rcx
   2368a:	83 fa f6             	cmp    edx,0xfffffff6
   2368d:	0f 86 3e fd ff ff    	jbe    233d1 <JS_CallInternal+0x8d1>
   23693:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   23696:	83 e8 01             	sub    eax,0x1
   23699:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   2369c:	85 c0                	test   eax,eax
   2369e:	0f 8f 2d fd ff ff    	jg     233d1 <JS_CallInternal+0x8d1>
   236a4:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   236ab:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   236af:	e8 ec 91 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   236b4:	e9 18 fd ff ff       	jmp    233d1 <JS_CallInternal+0x8d1>
   236b9:	48 8b 85 50 fe ff ff 	mov    rax,QWORD PTR [rbp-0x1b0]
   236c0:	8b 8d 38 fe ff ff    	mov    ecx,DWORD PTR [rbp-0x1c8]
   236c6:	45 31 c0             	xor    r8d,r8d
   236c9:	48 8b 95 58 fe ff ff 	mov    rdx,QWORD PTR [rbp-0x1a8]
   236d0:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   236d7:	48 89 c6             	mov    rsi,rax
   236da:	e8 e1 71 02 00       	call   4a8c0 <JS_DeleteProperty>
   236df:	41 89 c4             	mov    r12d,eax
   236e2:	85 c0                	test   eax,eax
   236e4:	0f 88 1c ff ff ff    	js     23606 <JS_CallInternal+0xb06>
   236ea:	48 8b 53 f8          	mov    rdx,QWORD PTR [rbx-0x8]
   236ee:	48 8b 73 f0          	mov    rsi,QWORD PTR [rbx-0x10]
   236f2:	83 fa f6             	cmp    edx,0xfffffff6
   236f5:	76 11                	jbe    23708 <JS_CallInternal+0xc08>
   236f7:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   236fa:	83 e8 01             	sub    eax,0x1
   236fd:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   23700:	85 c0                	test   eax,eax
   23702:	0f 8e cd 86 00 00    	jle    2bdd5 <JS_CallInternal+0x92d5>
   23708:	31 c0                	xor    eax,eax
   2370a:	45 85 e4             	test   r12d,r12d
   2370d:	48 c7 43 f8 01 00 00 	mov    QWORD PTR [rbx-0x8],0x1
   23714:	00 
   23715:	0f 95 c0             	setne  al
   23718:	48 89 43 f0          	mov    QWORD PTR [rbx-0x10],rax
   2371c:	e9 b0 fc ff ff       	jmp    233d1 <JS_CallInternal+0x8d1>
   23721:	f3 0f 1e fa          	endbr64
   23725:	f3 0f 1e fa          	endbr64
   23729:	41 0f b7 04 24       	movzx  eax,WORD PTR [r12]
   2372e:	48 8b 8d 98 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x168]
   23735:	4d 8d 74 24 02       	lea    r14,[r12+0x2]
   2373a:	48 8b 14 c1          	mov    rdx,QWORD PTR [rcx+rax*8]
   2373e:	48 8d 34 c5 00 00 00 	lea    rsi,[rax*8+0x0]
   23745:	00 
   23746:	48 8b 42 18          	mov    rax,QWORD PTR [rdx+0x18]
   2374a:	48 8b 48 08          	mov    rcx,QWORD PTR [rax+0x8]
   2374e:	83 f9 04             	cmp    ecx,0x4
   23751:	0f 84 09 62 00 00    	je     29960 <JS_CallInternal+0x6e60>
   23757:	80 7a 12 00          	cmp    BYTE PTR [rdx+0x12],0x0
   2375b:	0f 85 ff 61 00 00    	jne    29960 <JS_CallInternal+0x6e60>
   23761:	f3 0f 6f 63 f0       	movdqu xmm4,XMMWORD PTR [rbx-0x10]
   23766:	48 8b 30             	mov    rsi,QWORD PTR [rax]
   23769:	0f 11 20             	movups XMMWORD PTR [rax],xmm4
   2376c:	83 f9 f6             	cmp    ecx,0xfffffff6
   2376f:	76 11                	jbe    23782 <JS_CallInternal+0xc82>
   23771:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   23774:	83 e8 01             	sub    eax,0x1
   23777:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   2377a:	85 c0                	test   eax,eax
   2377c:	0f 8e 46 6a 00 00    	jle    2a1c8 <JS_CallInternal+0x76c8>
   23782:	48 83 eb 10          	sub    rbx,0x10
   23786:	41 0f b6 44 24 02    	movzx  eax,BYTE PTR [r12+0x2]
   2378c:	49 83 c4 03          	add    r12,0x3
   23790:	49 89 c5             	mov    r13,rax
   23793:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   23797:	ff e0                	jmp    rax
   23799:	f3 0f 1e fa          	endbr64
   2379d:	f3 0f 1e fa          	endbr64
   237a1:	48 83 ec 08          	sub    rsp,0x8
   237a5:	31 c0                	xor    eax,eax
   237a7:	41 83 fd 54          	cmp    r13d,0x54
   237ab:	41 0f b6 4c 24 04    	movzx  ecx,BYTE PTR [r12+0x4]
   237b1:	0f 94 c0             	sete   al
   237b4:	41 8b 14 24          	mov    edx,DWORD PTR [r12]
   237b8:	48 89 de             	mov    rsi,rbx
   237bb:	4d 8d 74 24 05       	lea    r14,[r12+0x5]
   237c0:	4c 8b 8d c8 fe ff ff 	mov    r9,QWORD PTR [rbp-0x138]
   237c7:	4c 8b 85 98 fe ff ff 	mov    r8,QWORD PTR [rbp-0x168]
   237ce:	50                   	push   rax
   237cf:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   237d6:	e8 45 59 06 00       	call   89120 <js_op_define_class>
   237db:	41 59                	pop    r9
   237dd:	41 5a                	pop    r10
   237df:	85 c0                	test   eax,eax
   237e1:	0f 88 d1 86 00 00    	js     2beb8 <JS_CallInternal+0x93b8>
   237e7:	41 0f b6 44 24 05    	movzx  eax,BYTE PTR [r12+0x5]
   237ed:	49 83 c4 06          	add    r12,0x6
   237f1:	49 89 c5             	mov    r13,rax
   237f4:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   237f8:	ff e0                	jmp    rax
   237fa:	f3 0f 1e fa          	endbr64
   237fe:	f3 0f 1e fa          	endbr64
   23802:	41 83 fd 52          	cmp    r13d,0x52
   23806:	0f 94 c0             	sete   al
   23809:	41 0f 94 c6          	sete   r14b
   2380d:	0f b6 c0             	movzx  eax,al
   23810:	89 85 40 fe ff ff    	mov    DWORD PTR [rbp-0x1c0],eax
   23816:	45 84 f6             	test   r14b,r14b
   23819:	0f 85 41 60 00 00    	jne    29860 <JS_CallInternal+0x6d60>
   2381f:	41 8b 04 24          	mov    eax,DWORD PTR [r12]
   23823:	4d 8d 6c 24 04       	lea    r13,[r12+0x4]
   23828:	89 85 50 fe ff ff    	mov    DWORD PTR [rbp-0x1b0],eax
   2382e:	8b 8d 40 fe ff ff    	mov    ecx,DWORD PTR [rbp-0x1c0]
   23834:	b8 fe ff ff ff       	mov    eax,0xfffffffe
   23839:	41 0f b6 55 00       	movzx  edx,BYTE PTR [r13+0x0]
   2383e:	bf 03 00 00 00       	mov    edi,0x3
   23843:	48 c7 85 38 fe ff ff 	mov    QWORD PTR [rbp-0x1c8],0x0
   2384a:	00 00 00 00 
   2384e:	4c 8d 63 f0          	lea    r12,[rbx-0x10]
   23852:	29 c8                	sub    eax,ecx
   23854:	48 89 bd 18 fe ff ff 	mov    QWORD PTR [rbp-0x1e8],rdi
   2385b:	48 98                	cdqe
   2385d:	48 89 bd e8 fd ff ff 	mov    QWORD PTR [rbp-0x218],rdi
   23864:	48 c7 85 28 fe ff ff 	mov    QWORD PTR [rbp-0x1d8],0x3
   2386b:	03 00 00 00 
   2386f:	48 c1 e0 04          	shl    rax,0x4
   23873:	48 8b 0c 03          	mov    rcx,QWORD PTR [rbx+rax*1]
   23877:	48 8b 44 03 08       	mov    rax,QWORD PTR [rbx+rax*1+0x8]
   2387c:	48 89 85 c0 fd ff ff 	mov    QWORD PTR [rbp-0x240],rax
   23883:	89 d0                	mov    eax,edx
   23885:	83 e0 04             	and    eax,0x4
   23888:	48 89 8d c8 fd ff ff 	mov    QWORD PTR [rbp-0x238],rcx
   2388f:	3c 01                	cmp    al,0x1
   23891:	19 c0                	sbb    eax,eax
   23893:	31 f6                	xor    esi,esi
   23895:	83 e0 fc             	and    eax,0xfffffffc
   23898:	48 89 b5 10 fe ff ff 	mov    QWORD PTR [rbp-0x1f0],rsi
   2389f:	48 89 b5 e0 fd ff ff 	mov    QWORD PTR [rbp-0x220],rsi
   238a6:	05 05 45 00 00       	add    eax,0x4505
   238ab:	83 e2 03             	and    edx,0x3
   238ae:	0f 85 30 57 00 00    	jne    28fe4 <JS_CallInternal+0x64e4>
   238b4:	48 8b 4b f0          	mov    rcx,QWORD PTR [rbx-0x10]
   238b8:	0d 02 22 00 00       	or     eax,0x2202
   238bd:	8b b5 50 fe ff ff    	mov    esi,DWORD PTR [rbp-0x1b0]
   238c3:	89 85 24 fe ff ff    	mov    DWORD PTR [rbp-0x1dc],eax
   238c9:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   238d0:	48 89 8d 38 fe ff ff 	mov    QWORD PTR [rbp-0x1c8],rcx
   238d7:	48 8b 43 f0          	mov    rax,QWORD PTR [rbx-0x10]
   238db:	48 8b 4b f8          	mov    rcx,QWORD PTR [rbx-0x8]
   238df:	48 89 85 d8 fd ff ff 	mov    QWORD PTR [rbp-0x228],rax
   238e6:	48 89 8d 28 fe ff ff 	mov    QWORD PTR [rbp-0x1d8],rcx
   238ed:	48 89 8d d0 fd ff ff 	mov    QWORD PTR [rbp-0x230],rcx
   238f4:	e8 a7 c8 01 00       	call   401a0 <js_get_function_name>
   238f9:	49 89 d1             	mov    r9,rdx
   238fc:	41 83 f9 06          	cmp    r9d,0x6
   23900:	0f 84 9b 69 00 00    	je     2a2a1 <JS_CallInternal+0x77a1>
   23906:	48 83 ec 08          	sub    rsp,0x8
   2390a:	49 89 c0             	mov    r8,rax
   2390d:	b9 3a 00 00 00       	mov    ecx,0x3a
   23912:	48 8b 95 d0 fd ff ff 	mov    rdx,QWORD PTR [rbp-0x230]
   23919:	48 8b b5 d8 fd ff ff 	mov    rsi,QWORD PTR [rbp-0x228]
   23920:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   23927:	6a 01                	push   0x1
   23929:	48 89 95 b8 fd ff ff 	mov    QWORD PTR [rbp-0x248],rdx
   23930:	48 89 b5 b0 fd ff ff 	mov    QWORD PTR [rbp-0x250],rsi
   23937:	e8 94 c4 00 00       	call   2fdd0 <JS_DefinePropertyValue>
   2393c:	41 5b                	pop    r11
   2393e:	5a                   	pop    rdx
   2393f:	85 c0                	test   eax,eax
   23941:	0f 88 5a 69 00 00    	js     2a2a1 <JS_CallInternal+0x77a1>
   23947:	4c 8b 95 c8 fd ff ff 	mov    r10,QWORD PTR [rbp-0x238]
   2394e:	48 8b 85 c0 fd ff ff 	mov    rax,QWORD PTR [rbp-0x240]
   23955:	48 8b b5 b0 fd ff ff 	mov    rsi,QWORD PTR [rbp-0x250]
   2395c:	48 8b 95 b8 fd ff ff 	mov    rdx,QWORD PTR [rbp-0x248]
   23963:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2396a:	4c 89 d1             	mov    rcx,r10
   2396d:	49 89 c0             	mov    r8,rax
   23970:	4c 89 95 d0 fd ff ff 	mov    QWORD PTR [rbp-0x230],r10
   23977:	48 89 85 d8 fd ff ff 	mov    QWORD PTR [rbp-0x228],rax
   2397e:	e8 9d a7 ff ff       	call   1e120 <js_method_set_home_object>
   23983:	8b 85 24 fe ff ff    	mov    eax,DWORD PTR [rbp-0x1dc]
   23989:	48 83 ec 08          	sub    rsp,0x8
   2398d:	8b 8d 50 fe ff ff    	mov    ecx,DWORD PTR [rbp-0x1b0]
   23993:	4c 8b 85 38 fe ff ff 	mov    r8,QWORD PTR [rbp-0x1c8]
   2399a:	4c 8b 8d 28 fe ff ff 	mov    r9,QWORD PTR [rbp-0x1d8]
   239a1:	48 8b b5 d0 fd ff ff 	mov    rsi,QWORD PTR [rbp-0x230]
   239a8:	48 8b 95 d8 fd ff ff 	mov    rdx,QWORD PTR [rbp-0x228]
   239af:	50                   	push   rax
   239b0:	ff b5 e8 fd ff ff    	push   QWORD PTR [rbp-0x218]
   239b6:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   239bd:	ff b5 e0 fd ff ff    	push   QWORD PTR [rbp-0x220]
   239c3:	ff b5 18 fe ff ff    	push   QWORD PTR [rbp-0x1e8]
   239c9:	ff b5 10 fe ff ff    	push   QWORD PTR [rbp-0x1f0]
   239cf:	e8 6c b5 00 00       	call   2ef40 <JS_DefineProperty>
   239d4:	48 83 c4 30          	add    rsp,0x30
   239d8:	89 c1                	mov    ecx,eax
   239da:	49 8b 54 24 08       	mov    rdx,QWORD PTR [r12+0x8]
   239df:	49 8b 34 24          	mov    rsi,QWORD PTR [r12]
   239e3:	83 fa f6             	cmp    edx,0xfffffff6
   239e6:	76 11                	jbe    239f9 <JS_CallInternal+0xef9>
   239e8:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   239eb:	83 e8 01             	sub    eax,0x1
   239ee:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   239f1:	85 c0                	test   eax,eax
   239f3:	0f 8e e7 67 00 00    	jle    2a1e0 <JS_CallInternal+0x76e0>
   239f9:	45 84 f6             	test   r14b,r14b
   239fc:	0f 85 bc 57 00 00    	jne    291be <JS_CallInternal+0x66be>
   23a02:	8b 85 40 fe ff ff    	mov    eax,DWORD PTR [rbp-0x1c0]
   23a08:	4d 8d 65 01          	lea    r12,[r13+0x1]
   23a0c:	83 c0 01             	add    eax,0x1
   23a0f:	48 98                	cdqe
   23a11:	48 c1 e0 04          	shl    rax,0x4
   23a15:	48 29 c3             	sub    rbx,rax
   23a18:	85 c9                	test   ecx,ecx
   23a1a:	0f 88 80 f8 ff ff    	js     232a0 <JS_CallInternal+0x7a0>
   23a20:	41 0f b6 45 01       	movzx  eax,BYTE PTR [r13+0x1]
   23a25:	4d 8d 65 02          	lea    r12,[r13+0x2]
   23a29:	49 89 c5             	mov    r13,rax
   23a2c:	41 ff 24 c7          	jmp    QWORD PTR [r15+rax*8]
   23a30:	f3 0f 1e fa          	endbr64
   23a34:	f3 0f 1e fa          	endbr64
   23a38:	45 0f b7 0c 24       	movzx  r9d,WORD PTR [r12]
   23a3d:	49 89 db             	mov    r11,rbx
   23a40:	49 8d 4c 24 02       	lea    rcx,[r12+0x2]
   23a45:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   23a4c:	48 89 8d 28 fe ff ff 	mov    QWORD PTR [rbp-0x1d8],rcx
   23a53:	4c 89 c8             	mov    rax,r9
   23a56:	44 89 8d 38 fe ff ff 	mov    DWORD PTR [rbp-0x1c8],r9d
   23a5d:	48 c1 e0 04          	shl    rax,0x4
   23a61:	49 29 c3             	sub    r11,rax
   23a64:	48 89 85 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],rax
   23a6b:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   23a72:	49 8b 73 f0          	mov    rsi,QWORD PTR [r11-0x10]
   23a76:	49 8b 53 f8          	mov    rdx,QWORD PTR [r11-0x8]
   23a7a:	4d 8d 73 e0          	lea    r14,[r11-0x20]
   23a7e:	48 89 48 30          	mov    QWORD PTR [rax+0x30],rcx
   23a82:	4d 8b 46 08          	mov    r8,QWORD PTR [r14+0x8]
   23a86:	49 8b 4b e0          	mov    rcx,QWORD PTR [r11-0x20]
   23a8a:	6a 00                	push   0x0
   23a8c:	41 53                	push   r11
   23a8e:	4c 89 9d 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],r11
   23a95:	6a 03                	push   0x3
   23a97:	6a 00                	push   0x0
   23a99:	e8 62 f0 ff ff       	call   22b00 <JS_CallInternal>
   23a9e:	48 83 c4 20          	add    rsp,0x20
   23aa2:	4c 8b 9d 50 fe ff ff 	mov    r11,QWORD PTR [rbp-0x1b0]
   23aa9:	4c 8b 95 40 fe ff ff 	mov    r10,QWORD PTR [rbp-0x1c0]
   23ab0:	83 fa 06             	cmp    edx,0x6
   23ab3:	48 89 d1             	mov    rcx,rdx
   23ab6:	0f 84 6b 68 00 00    	je     2a327 <JS_CallInternal+0x7827>
   23abc:	41 83 fd 25          	cmp    r13d,0x25
   23ac0:	0f 84 2d f7 ff ff    	je     231f3 <JS_CallInternal+0x6f3>
   23ac6:	4f 8d 2c 13          	lea    r13,[r11+r10*1]
   23aca:	48 89 9d 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],rbx
   23ad1:	4c 89 f3             	mov    rbx,r14
   23ad4:	49 89 d6             	mov    r14,rdx
   23ad7:	4c 89 a5 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],r12
   23ade:	4d 89 ec             	mov    r12,r13
   23ae1:	49 89 c5             	mov    r13,rax
   23ae4:	eb 17                	jmp    23afd <JS_CallInternal+0xffd>
   23ae6:	66 2e 0f 1f 84 00 00 	cs nop WORD PTR [rax+rax*1+0x0]
   23aed:	00 00 00 
   23af0:	48 83 c3 10          	add    rbx,0x10
   23af4:	4c 39 e3             	cmp    rbx,r12
   23af7:	0f 84 68 54 00 00    	je     28f65 <JS_CallInternal+0x6465>
   23afd:	48 8b 4b 08          	mov    rcx,QWORD PTR [rbx+0x8]
   23b01:	48 8b 33             	mov    rsi,QWORD PTR [rbx]
   23b04:	83 f9 f6             	cmp    ecx,0xfffffff6
   23b07:	76 e7                	jbe    23af0 <JS_CallInternal+0xff0>
   23b09:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   23b0c:	8d 50 ff             	lea    edx,[rax-0x1]
   23b0f:	89 56 fc             	mov    DWORD PTR [rsi-0x4],edx
   23b12:	85 d2                	test   edx,edx
   23b14:	7f da                	jg     23af0 <JS_CallInternal+0xff0>
   23b16:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   23b1d:	48 89 ca             	mov    rdx,rcx
   23b20:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   23b24:	e8 77 8d ff ff       	call   1c8a0 <__JS_FreeValueRT>
   23b29:	eb c5                	jmp    23af0 <JS_CallInternal+0xff0>
   23b2b:	f3 0f 1e fa          	endbr64
   23b2f:	f3 0f 1e fa          	endbr64
   23b33:	31 c9                	xor    ecx,ecx
   23b35:	b8 02 00 00 00       	mov    eax,0x2
   23b3a:	e9 e1 f7 ff ff       	jmp    23320 <JS_CallInternal+0x820>
   23b3f:	f3 0f 1e fa          	endbr64
   23b43:	f3 0f 1e fa          	endbr64
   23b47:	48 8b 85 d8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x128]
   23b4e:	4c 89 e2             	mov    rdx,r12
   23b51:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   23b58:	44 89 e9             	mov    ecx,r13d
   23b5b:	48 8d 35 ae d2 0a 00 	lea    rsi,[rip+0xad2ae]        # d0e10 <_IO_stdin_used+0x3e10>
   23b62:	48 2b 50 18          	sub    rdx,QWORD PTR [rax+0x18]
   23b66:	31 c0                	xor    eax,eax
   23b68:	83 ea 01             	sub    edx,0x1
   23b6b:	e8 c0 f4 00 00       	call   33030 <JS_ThrowInternalError>
   23b70:	e9 2b f7 ff ff       	jmp    232a0 <JS_CallInternal+0x7a0>
   23b75:	f3 0f 1e fa          	endbr64
   23b79:	f3 0f 1e fa          	endbr64
   23b7d:	41 0f b7 04 24       	movzx  eax,WORD PTR [r12]
   23b82:	48 8b bd 98 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x168]
   23b89:	4d 8d 74 24 02       	lea    r14,[r12+0x2]
   23b8e:	48 8d 0c c5 00 00 00 	lea    rcx,[rax*8+0x0]
   23b95:	00 
   23b96:	48 8b 04 c7          	mov    rax,QWORD PTR [rdi+rax*8]
   23b9a:	48 8b 40 18          	mov    rax,QWORD PTR [rax+0x18]
   23b9e:	48 8b 10             	mov    rdx,QWORD PTR [rax]
   23ba1:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
   23ba5:	83 f8 04             	cmp    eax,0x4
   23ba8:	0f 84 85 67 00 00    	je     2a333 <JS_CallInternal+0x7833>
   23bae:	83 f8 f6             	cmp    eax,0xfffffff6
   23bb1:	76 04                	jbe    23bb7 <JS_CallInternal+0x10b7>
   23bb3:	83 42 fc 01          	add    DWORD PTR [rdx-0x4],0x1
   23bb7:	48 89 13             	mov    QWORD PTR [rbx],rdx
   23bba:	48 89 43 08          	mov    QWORD PTR [rbx+0x8],rax
   23bbe:	41 0f b6 44 24 02    	movzx  eax,BYTE PTR [r12+0x2]
   23bc4:	48 83 c3 10          	add    rbx,0x10
   23bc8:	49 83 c4 03          	add    r12,0x3
   23bcc:	49 89 c5             	mov    r13,rax
   23bcf:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   23bd3:	ff e0                	jmp    rax
   23bd5:	f3 0f 1e fa          	endbr64
   23bd9:	f3 0f 1e fa          	endbr64
   23bdd:	49 8d 44 24 02       	lea    rax,[r12+0x2]
   23be2:	45 0f b7 14 24       	movzx  r10d,WORD PTR [r12]
   23be7:	48 89 85 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],rax
   23bee:	e9 e5 f2 ff ff       	jmp    22ed8 <JS_CallInternal+0x3d8>
   23bf3:	f3 0f 1e fa          	endbr64
   23bf7:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   23bfe:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   23c05:	44 89 ea             	mov    edx,r13d
   23c08:	48 89 de             	mov    rsi,rbx
   23c0b:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   23c0f:	e8 0c 0e 03 00       	call   54a20 <js_binary_arith_slow>
   23c14:	85 c0                	test   eax,eax
   23c16:	0f 85 84 f6 ff ff    	jne    232a0 <JS_CallInternal+0x7a0>
   23c1c:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   23c21:	48 83 eb 10          	sub    rbx,0x10
   23c25:	49 83 c4 01          	add    r12,0x1
   23c29:	49 89 c5             	mov    r13,rax
   23c2c:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   23c30:	ff e0                	jmp    rax
   23c32:	f3 0f 1e fa          	endbr64
   23c36:	45 0f b7 0c 24       	movzx  r9d,WORD PTR [r12]
   23c3b:	49 89 de             	mov    r14,rbx
   23c3e:	4d 8d 54 24 02       	lea    r10,[r12+0x2]
   23c43:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   23c4a:	4c 89 95 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],r10
   23c51:	4c 89 c8             	mov    rax,r9
   23c54:	44 89 8d 40 fe ff ff 	mov    DWORD PTR [rbp-0x1c0],r9d
   23c5b:	48 c1 e0 04          	shl    rax,0x4
   23c5f:	49 29 c6             	sub    r14,rax
   23c62:	48 89 85 38 fe ff ff 	mov    QWORD PTR [rbp-0x1c8],rax
   23c69:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   23c70:	4d 8b 46 f8          	mov    r8,QWORD PTR [r14-0x8]
   23c74:	49 8b 4e f0          	mov    rcx,QWORD PTR [r14-0x10]
   23c78:	4d 8d 6e e0          	lea    r13,[r14-0x20]
   23c7c:	49 8b 76 e0          	mov    rsi,QWORD PTR [r14-0x20]
   23c80:	49 8b 55 08          	mov    rdx,QWORD PTR [r13+0x8]
   23c84:	4c 89 50 30          	mov    QWORD PTR [rax+0x30],r10
   23c88:	6a 00                	push   0x0
   23c8a:	41 56                	push   r14
   23c8c:	e8 4f d3 06 00       	call   90fe0 <JS_CallConstructorInternal>
   23c91:	41 5b                	pop    r11
   23c93:	4c 8b 95 50 fe ff ff 	mov    r10,QWORD PTR [rbp-0x1b0]
   23c9a:	83 fa 06             	cmp    edx,0x6
   23c9d:	49 89 c1             	mov    r9,rax
   23ca0:	49 89 d0             	mov    r8,rdx
   23ca3:	58                   	pop    rax
   23ca4:	0f 84 29 70 00 00    	je     2acd3 <JS_CallInternal+0x81d3>
   23caa:	4c 8b 9d 38 fe ff ff 	mov    r11,QWORD PTR [rbp-0x1c8]
   23cb1:	4d 01 de             	add    r14,r11
   23cb4:	eb 17                	jmp    23ccd <JS_CallInternal+0x11cd>
   23cb6:	66 2e 0f 1f 84 00 00 	cs nop WORD PTR [rax+rax*1+0x0]
   23cbd:	00 00 00 
   23cc0:	49 83 c5 10          	add    r13,0x10
   23cc4:	4d 39 f5             	cmp    r13,r14
   23cc7:	0f 84 89 53 00 00    	je     29056 <JS_CallInternal+0x6556>
   23ccd:	49 8b 55 08          	mov    rdx,QWORD PTR [r13+0x8]
   23cd1:	49 8b 75 00          	mov    rsi,QWORD PTR [r13+0x0]
   23cd5:	83 fa f6             	cmp    edx,0xfffffff6
   23cd8:	76 e6                	jbe    23cc0 <JS_CallInternal+0x11c0>
   23cda:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   23cdd:	83 e8 01             	sub    eax,0x1
   23ce0:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   23ce3:	85 c0                	test   eax,eax
   23ce5:	7f d9                	jg     23cc0 <JS_CallInternal+0x11c0>
   23ce7:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   23cee:	4c 89 85 38 fe ff ff 	mov    QWORD PTR [rbp-0x1c8],r8
   23cf5:	4c 89 8d 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],r9
   23cfc:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   23d00:	e8 9b 8b ff ff       	call   1c8a0 <__JS_FreeValueRT>
   23d05:	4c 8b 85 38 fe ff ff 	mov    r8,QWORD PTR [rbp-0x1c8]
   23d0c:	4c 8b 8d 50 fe ff ff 	mov    r9,QWORD PTR [rbp-0x1b0]
   23d13:	eb ab                	jmp    23cc0 <JS_CallInternal+0x11c0>
   23d15:	f3 0f 1e fa          	endbr64
   23d19:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   23d20:	4c 8b 43 f8          	mov    r8,QWORD PTR [rbx-0x8]
   23d24:	4c 8d 73 f0          	lea    r14,[rbx-0x10]
   23d28:	48 8b 4b f0          	mov    rcx,QWORD PTR [rbx-0x10]
   23d2c:	48 8b 73 e0          	mov    rsi,QWORD PTR [rbx-0x20]
   23d30:	48 8b 53 e8          	mov    rdx,QWORD PTR [rbx-0x18]
   23d34:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   23d3b:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   23d3f:	e8 fc 51 08 00       	call   a8f40 <js_dynamic_import>
   23d44:	49 89 d0             	mov    r8,rdx
   23d47:	83 fa 06             	cmp    edx,0x6
   23d4a:	0f 84 50 f5 ff ff    	je     232a0 <JS_CallInternal+0x7a0>
   23d50:	48 8b 53 e8          	mov    rdx,QWORD PTR [rbx-0x18]
   23d54:	48 8b 73 e0          	mov    rsi,QWORD PTR [rbx-0x20]
   23d58:	83 fa f6             	cmp    edx,0xfffffff6
   23d5b:	76 11                	jbe    23d6e <JS_CallInternal+0x126e>
   23d5d:	8b 4e fc             	mov    ecx,DWORD PTR [rsi-0x4]
   23d60:	83 e9 01             	sub    ecx,0x1
   23d63:	89 4e fc             	mov    DWORD PTR [rsi-0x4],ecx
   23d66:	85 c9                	test   ecx,ecx
   23d68:	0f 8e 2b 6d 00 00    	jle    2aa99 <JS_CallInternal+0x7f99>
   23d6e:	49 8b 56 08          	mov    rdx,QWORD PTR [r14+0x8]
   23d72:	49 8b 36             	mov    rsi,QWORD PTR [r14]
   23d75:	83 fa f6             	cmp    edx,0xfffffff6
   23d78:	76 11                	jbe    23d8b <JS_CallInternal+0x128b>
   23d7a:	8b 4e fc             	mov    ecx,DWORD PTR [rsi-0x4]
   23d7d:	83 e9 01             	sub    ecx,0x1
   23d80:	89 4e fc             	mov    DWORD PTR [rsi-0x4],ecx
   23d83:	85 c9                	test   ecx,ecx
   23d85:	0f 8e 3f 6d 00 00    	jle    2aaca <JS_CallInternal+0x7fca>
   23d8b:	49 89 46 f0          	mov    QWORD PTR [r14-0x10],rax
   23d8f:	4c 89 f3             	mov    rbx,r14
   23d92:	49 83 c4 01          	add    r12,0x1
   23d96:	4d 89 46 f8          	mov    QWORD PTR [r14-0x8],r8
   23d9a:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   23da0:	49 89 c5             	mov    r13,rax
   23da3:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   23da7:	ff e0                	jmp    rax
   23da9:	f3 0f 1e fa          	endbr64
   23dad:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   23db4:	48 8b 73 f0          	mov    rsi,QWORD PTR [rbx-0x10]
   23db8:	48 8b 53 f8          	mov    rdx,QWORD PTR [rbx-0x8]
   23dbc:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   23dc3:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   23dc7:	e8 34 e6 ff ff       	call   22400 <JS_GetPrototype>
   23dcc:	49 89 c6             	mov    r14,rax
   23dcf:	48 89 d1             	mov    rcx,rdx
   23dd2:	83 fa 06             	cmp    edx,0x6
   23dd5:	0f 84 c5 f4 ff ff    	je     232a0 <JS_CallInternal+0x7a0>
   23ddb:	48 8b 53 f8          	mov    rdx,QWORD PTR [rbx-0x8]
   23ddf:	48 8b 73 f0          	mov    rsi,QWORD PTR [rbx-0x10]
   23de3:	83 fa f6             	cmp    edx,0xfffffff6
   23de6:	76 11                	jbe    23df9 <JS_CallInternal+0x12f9>
   23de8:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   23deb:	83 e8 01             	sub    eax,0x1
   23dee:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   23df1:	85 c0                	test   eax,eax
   23df3:	0f 8e 62 6b 00 00    	jle    2a95b <JS_CallInternal+0x7e5b>
   23df9:	4c 89 73 f0          	mov    QWORD PTR [rbx-0x10],r14
   23dfd:	49 83 c4 01          	add    r12,0x1
   23e01:	48 89 4b f8          	mov    QWORD PTR [rbx-0x8],rcx
   23e05:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   23e0b:	49 89 c5             	mov    r13,rax
   23e0e:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   23e12:	ff e0                	jmp    rax
   23e14:	f3 0f 1e fa          	endbr64
   23e18:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   23e1f:	4d 8d 54 24 02       	lea    r10,[r12+0x2]
   23e24:	48 8b 73 d0          	mov    rsi,QWORD PTR [rbx-0x30]
   23e28:	4c 8d 73 e0          	lea    r14,[rbx-0x20]
   23e2c:	45 0f b7 0c 24       	movzx  r9d,WORD PTR [r12]
   23e31:	48 8b 53 d8          	mov    rdx,QWORD PTR [rbx-0x28]
   23e35:	4d 89 f0             	mov    r8,r14
   23e38:	b9 02 00 00 00       	mov    ecx,0x2
   23e3d:	4c 89 50 30          	mov    QWORD PTR [rax+0x30],r10
   23e41:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   23e48:	4c 89 95 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],r10
   23e4f:	e8 ec d7 07 00       	call   a1640 <js_function_apply>
   23e54:	4c 8b 95 50 fe ff ff 	mov    r10,QWORD PTR [rbp-0x1b0]
   23e5b:	83 fa 06             	cmp    edx,0x6
   23e5e:	49 89 c1             	mov    r9,rax
   23e61:	49 89 d0             	mov    r8,rdx
   23e64:	0f 84 7c 74 00 00    	je     2b2e6 <JS_CallInternal+0x87e6>
   23e6a:	48 8b 53 d8          	mov    rdx,QWORD PTR [rbx-0x28]
   23e6e:	48 8b 73 d0          	mov    rsi,QWORD PTR [rbx-0x30]
   23e72:	83 fa f6             	cmp    edx,0xfffffff6
   23e75:	76 11                	jbe    23e88 <JS_CallInternal+0x1388>
   23e77:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   23e7a:	83 e8 01             	sub    eax,0x1
   23e7d:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   23e80:	85 c0                	test   eax,eax
   23e82:	0f 8e 5c 6a 00 00    	jle    2a8e4 <JS_CallInternal+0x7de4>
   23e88:	49 8b 56 08          	mov    rdx,QWORD PTR [r14+0x8]
   23e8c:	49 8b 36             	mov    rsi,QWORD PTR [r14]
   23e8f:	83 fa f6             	cmp    edx,0xfffffff6
   23e92:	76 11                	jbe    23ea5 <JS_CallInternal+0x13a5>
   23e94:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   23e97:	83 e8 01             	sub    eax,0x1
   23e9a:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   23e9d:	85 c0                	test   eax,eax
   23e9f:	0f 8e 70 6a 00 00    	jle    2a915 <JS_CallInternal+0x7e15>
   23ea5:	48 8b 53 f8          	mov    rdx,QWORD PTR [rbx-0x8]
   23ea9:	48 8b 73 f0          	mov    rsi,QWORD PTR [rbx-0x10]
   23ead:	83 fa f6             	cmp    edx,0xfffffff6
   23eb0:	76 11                	jbe    23ec3 <JS_CallInternal+0x13c3>
   23eb2:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   23eb5:	83 e8 01             	sub    eax,0x1
   23eb8:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   23ebb:	85 c0                	test   eax,eax
   23ebd:	0f 8e f0 69 00 00    	jle    2a8b3 <JS_CallInternal+0x7db3>
   23ec3:	4c 89 4b d0          	mov    QWORD PTR [rbx-0x30],r9
   23ec7:	49 83 c4 03          	add    r12,0x3
   23ecb:	4c 89 43 d8          	mov    QWORD PTR [rbx-0x28],r8
   23ecf:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   23ed5:	4c 89 f3             	mov    rbx,r14
   23ed8:	49 89 c5             	mov    r13,rax
   23edb:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   23edf:	ff e0                	jmp    rax
   23ee1:	f3 0f 1e fa          	endbr64
   23ee5:	41 0f b7 14 24       	movzx  edx,WORD PTR [r12]
   23eea:	49 8d 4c 24 02       	lea    rcx,[r12+0x2]
   23eef:	48 89 8d 38 fe ff ff 	mov    QWORD PTR [rbp-0x1c8],rcx
   23ef6:	31 c9                	xor    ecx,ecx
   23ef8:	49 89 d6             	mov    r14,rdx
   23efb:	89 95 50 fe ff ff    	mov    DWORD PTR [rbp-0x1b0],edx
   23f01:	49 c1 e6 04          	shl    r14,0x4
   23f05:	48 89 95 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],rdx
   23f0c:	ba 02 00 00 00       	mov    edx,0x2
   23f11:	4c 29 f3             	sub    rbx,r14
   23f14:	49 89 dd             	mov    r13,rbx
   23f17:	48 8b 9d e8 fe ff ff 	mov    rbx,QWORD PTR [rbp-0x118]
   23f1e:	48 8b 73 30          	mov    rsi,QWORD PTR [rbx+0x30]
   23f22:	48 89 df             	mov    rdi,rbx
   23f25:	83 46 fc 01          	add    DWORD PTR [rsi-0x4],0x1
   23f29:	e8 a2 41 02 00       	call   480d0 <JS_NewObjectFromShape>
   23f2e:	49 89 c0             	mov    r8,rax
   23f31:	48 89 d1             	mov    rcx,rdx
   23f34:	83 fa 06             	cmp    edx,0x6
   23f37:	0f 84 02 76 00 00    	je     2b53f <JS_CallInternal+0x8a3f>
   23f3d:	8b 95 50 fe ff ff    	mov    edx,DWORD PTR [rbp-0x1b0]
   23f43:	85 d2                	test   edx,edx
   23f45:	0f 85 52 59 00 00    	jne    2989d <JS_CallInternal+0x6d9d>
   23f4b:	4d 89 45 00          	mov    QWORD PTR [r13+0x0],r8
   23f4f:	49 8d 5d 10          	lea    rbx,[r13+0x10]
   23f53:	49 83 c4 03          	add    r12,0x3
   23f57:	49 89 4d 08          	mov    QWORD PTR [r13+0x8],rcx
   23f5b:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   23f61:	49 89 c5             	mov    r13,rax
   23f64:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   23f68:	ff e0                	jmp    rax
   23f6a:	f3 0f 1e fa          	endbr64
   23f6e:	41 8b 04 24          	mov    eax,DWORD PTR [r12]
   23f72:	4c 8b 53 f8          	mov    r10,QWORD PTR [rbx-0x8]
   23f76:	4d 8d 5c 24 04       	lea    r11,[r12+0x4]
   23f7b:	48 8b 73 f0          	mov    rsi,QWORD PTR [rbx-0x10]
   23f7f:	4d 8d 34 04          	lea    r14,[r12+rax*1]
   23f83:	41 83 fa ff          	cmp    r10d,0xffffffff
   23f87:	0f 85 4c 72 00 00    	jne    2b1d9 <JS_CallInternal+0x86d9>
   23f8d:	8b 46 10             	mov    eax,DWORD PTR [rsi+0x10]
   23f90:	4c 8b 6e 18          	mov    r13,QWORD PTR [rsi+0x18]
   23f94:	25 08 00 ff ff       	and    eax,0xffff0008
   23f99:	3d 00 00 01 00       	cmp    eax,0x10000
   23f9e:	0f 84 7e 5f 00 00    	je     29f22 <JS_CallInternal+0x7422>
   23fa4:	41 8b 4e 0c          	mov    ecx,DWORD PTR [r14+0xc]
   23fa8:	48 89 f7             	mov    rdi,rsi
   23fab:	0f 1f 44 00 00       	nop    DWORD PTR [rax+rax*1+0x0]
   23fb0:	41 8b 45 18          	mov    eax,DWORD PTR [r13+0x18]
   23fb4:	89 ca                	mov    edx,ecx
   23fb6:	21 c2                	and    edx,eax
   23fb8:	41 8b 54 95 38       	mov    edx,DWORD PTR [r13+rdx*4+0x38]
   23fbd:	48 85 d2             	test   rdx,rdx
   23fc0:	0f 84 36 4e 00 00    	je     28dfc <JS_CallInternal+0x62fc>
   23fc6:	4c 8d 04 85 34 00 00 	lea    r8,[rax*4+0x34]
   23fcd:	00 
   23fce:	49 8d 04 d0          	lea    rax,[r8+rdx*8]
   23fd2:	4c 01 e8             	add    rax,r13
   23fd5:	3b 48 04             	cmp    ecx,DWORD PTR [rax+0x4]
   23fd8:	0f 85 10 4e 00 00    	jne    28dee <JS_CallInternal+0x62ee>
   23fde:	80 78 03 3f          	cmp    BYTE PTR [rax+0x3],0x3f
   23fe2:	0f 87 fb 53 00 00    	ja     293e3 <JS_CallInternal+0x68e3>
   23fe8:	48 c1 e2 04          	shl    rdx,0x4
   23fec:	48 8d 42 f0          	lea    rax,[rdx-0x10]
   23ff0:	48 8b 57 20          	mov    rdx,QWORD PTR [rdi+0x20]
   23ff4:	48 01 c2             	add    rdx,rax
   23ff7:	4c 8b 02             	mov    r8,QWORD PTR [rdx]
   23ffa:	48 8b 52 08          	mov    rdx,QWORD PTR [rdx+0x8]
   23ffe:	83 fa f6             	cmp    edx,0xfffffff6
   24001:	76 05                	jbe    24008 <JS_CallInternal+0x1508>
   24003:	41 83 40 fc 01       	add    DWORD PTR [r8-0x4],0x1
   24008:	48 39 fe             	cmp    rsi,rdi
   2400b:	0f 84 1e 7e 00 00    	je     2be2f <JS_CallInternal+0x932f>
   24011:	4c 89 c0             	mov    rax,r8
   24014:	48 89 03             	mov    QWORD PTR [rbx],rax
   24017:	49 83 c4 05          	add    r12,0x5
   2401b:	48 83 c3 10          	add    rbx,0x10
   2401f:	48 89 53 f8          	mov    QWORD PTR [rbx-0x8],rdx
   24023:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   24029:	49 89 c5             	mov    r13,rax
   2402c:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   24030:	ff e0                	jmp    rax
   24032:	f3 0f 1e fa          	endbr64
   24036:	41 8b 04 24          	mov    eax,DWORD PTR [r12]
   2403a:	4c 8b 53 f8          	mov    r10,QWORD PTR [rbx-0x8]
   2403e:	48 8b 73 f0          	mov    rsi,QWORD PTR [rbx-0x10]
   24042:	4d 8d 34 04          	lea    r14,[r12+rax*1]
   24046:	49 8d 44 24 04       	lea    rax,[r12+0x4]
   2404b:	48 89 85 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],rax
   24052:	41 83 fa ff          	cmp    r10d,0xffffffff
   24056:	0f 85 9e 6d 00 00    	jne    2adfa <JS_CallInternal+0x82fa>
   2405c:	8b 46 10             	mov    eax,DWORD PTR [rsi+0x10]
   2405f:	4c 8b 6e 18          	mov    r13,QWORD PTR [rsi+0x18]
   24063:	25 08 00 ff ff       	and    eax,0xffff0008
   24068:	3d 00 00 01 00       	cmp    eax,0x10000
   2406d:	0f 84 8d 5c 00 00    	je     29d00 <JS_CallInternal+0x7200>
   24073:	41 8b 4e 0c          	mov    ecx,DWORD PTR [r14+0xc]
   24077:	48 89 f2             	mov    rdx,rsi
   2407a:	66 0f 1f 44 00 00    	nop    WORD PTR [rax+rax*1+0x0]
   24080:	41 8b 45 18          	mov    eax,DWORD PTR [r13+0x18]
   24084:	89 cf                	mov    edi,ecx
   24086:	21 c7                	and    edi,eax
   24088:	41 8b 7c bd 38       	mov    edi,DWORD PTR [r13+rdi*4+0x38]
   2408d:	48 85 ff             	test   rdi,rdi
   24090:	0f 84 38 4d 00 00    	je     28dce <JS_CallInternal+0x62ce>
   24096:	4c 8d 04 85 34 00 00 	lea    r8,[rax*4+0x34]
   2409d:	00 
   2409e:	49 8d 04 f8          	lea    rax,[r8+rdi*8]
   240a2:	4c 01 e8             	add    rax,r13
   240a5:	3b 48 04             	cmp    ecx,DWORD PTR [rax+0x4]
   240a8:	0f 85 12 4d 00 00    	jne    28dc0 <JS_CallInternal+0x62c0>
   240ae:	80 78 03 3f          	cmp    BYTE PTR [rax+0x3],0x3f
   240b2:	0f 87 c2 52 00 00    	ja     2937a <JS_CallInternal+0x687a>
   240b8:	48 89 f9             	mov    rcx,rdi
   240bb:	48 8b 7a 20          	mov    rdi,QWORD PTR [rdx+0x20]
   240bf:	48 c1 e1 04          	shl    rcx,0x4
   240c3:	48 83 e9 10          	sub    rcx,0x10
   240c7:	48 01 cf             	add    rdi,rcx
   240ca:	4c 8b 47 08          	mov    r8,QWORD PTR [rdi+0x8]
   240ce:	48 8b 07             	mov    rax,QWORD PTR [rdi]
   240d1:	41 83 f8 f6          	cmp    r8d,0xfffffff6
   240d5:	76 04                	jbe    240db <JS_CallInternal+0x15db>
   240d7:	83 40 fc 01          	add    DWORD PTR [rax-0x4],0x1
   240db:	4c 8d 5b f0          	lea    r11,[rbx-0x10]
   240df:	48 39 f2             	cmp    rdx,rsi
   240e2:	0f 84 56 7c 00 00    	je     2bd3e <JS_CallInternal+0x923e>
   240e8:	49 89 c5             	mov    r13,rax
   240eb:	49 8b 53 08          	mov    rdx,QWORD PTR [r11+0x8]
   240ef:	49 8b 33             	mov    rsi,QWORD PTR [r11]
   240f2:	83 fa f6             	cmp    edx,0xfffffff6
   240f5:	76 11                	jbe    24108 <JS_CallInternal+0x1608>
   240f7:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   240fa:	83 e8 01             	sub    eax,0x1
   240fd:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   24100:	85 c0                	test   eax,eax
   24102:	0f 8e 73 6b 00 00    	jle    2ac7b <JS_CallInternal+0x817b>
   24108:	4c 89 6b f0          	mov    QWORD PTR [rbx-0x10],r13
   2410c:	49 83 c4 05          	add    r12,0x5
   24110:	4c 89 43 f8          	mov    QWORD PTR [rbx-0x8],r8
   24114:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   2411a:	49 89 c5             	mov    r13,rax
   2411d:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   24121:	ff e0                	jmp    rax
   24123:	f3 0f 1e fa          	endbr64
   24127:	48 8b 43 e0          	mov    rax,QWORD PTR [rbx-0x20]
   2412b:	4c 8d 6b e0          	lea    r13,[rbx-0x20]
   2412f:	4c 8d 73 f0          	lea    r14,[rbx-0x10]
   24133:	48 8b 4b f0          	mov    rcx,QWORD PTR [rbx-0x10]
   24137:	49 8b 5e 08          	mov    rbx,QWORD PTR [r14+0x8]
   2413b:	48 89 85 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],rax
   24142:	49 8b 45 08          	mov    rax,QWORD PTR [r13+0x8]
   24146:	48 89 8d 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],rcx
   2414d:	48 89 85 38 fe ff ff 	mov    QWORD PTR [rbp-0x1c8],rax
   24154:	83 fb f9             	cmp    ebx,0xfffffff9
   24157:	0f 85 d3 5f 00 00    	jne    2a130 <JS_CallInternal+0x7630>
   2415d:	83 f8 f9             	cmp    eax,0xfffffff9
   24160:	0f 85 ca 5f 00 00    	jne    2a130 <JS_CallInternal+0x7630>
   24166:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2416d:	ba 12 00 00 00       	mov    edx,0x12
   24172:	48 8d 8d 50 ff ff ff 	lea    rcx,[rbp-0xb0]
   24179:	48 c7 85 50 ff ff ff 	mov    QWORD PTR [rbp-0xb0],0x0
   24180:	00 00 00 00 
   24184:	48 c7 85 58 ff ff ff 	mov    QWORD PTR [rbp-0xa8],0x0
   2418b:	00 00 00 00 
   2418f:	48 8b 77 48          	mov    rsi,QWORD PTR [rdi+0x48]
   24193:	83 46 fc 01          	add    DWORD PTR [rsi-0x4],0x1
   24197:	e8 34 3f 02 00       	call   480d0 <JS_NewObjectFromShape>
   2419c:	83 fa 06             	cmp    edx,0x6
   2419f:	0f 84 a0 5f 00 00    	je     2a145 <JS_CallInternal+0x7645>
   241a5:	f3 0f 7e 85 40 fe ff 	movq   xmm0,QWORD PTR [rbp-0x1c0]
   241ac:	ff 
   241ad:	0f 16 85 50 fe ff ff 	movhps xmm0,QWORD PTR [rbp-0x1b0]
   241b4:	0f 11 40 28          	movups XMMWORD PTR [rax+0x28],xmm0
   241b8:	49 89 45 00          	mov    QWORD PTR [r13+0x0],rax
   241bc:	49 89 55 08          	mov    QWORD PTR [r13+0x8],rdx
   241c0:	41 83 7e f8 06       	cmp    DWORD PTR [r14-0x8],0x6
   241c5:	0f 84 27 6c 00 00    	je     2adf2 <JS_CallInternal+0x82f2>
   241cb:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   241d0:	4c 89 f3             	mov    rbx,r14
   241d3:	49 83 c4 01          	add    r12,0x1
   241d7:	49 89 c5             	mov    r13,rax
   241da:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   241de:	ff e0                	jmp    rax
   241e0:	f3 0f 1e fa          	endbr64
   241e4:	41 0f b7 04 24       	movzx  eax,WORD PTR [r12]
   241e9:	48 8b 53 f0          	mov    rdx,QWORD PTR [rbx-0x10]
   241ed:	48 8d b5 f0 fe ff ff 	lea    rsi,[rbp-0x110]
   241f4:	48 8b 8d c8 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x138]
   241fb:	4c 8b ad e8 fe ff ff 	mov    r13,QWORD PTR [rbp-0x118]
   24202:	66 89 85 38 fe ff ff 	mov    WORD PTR [rbp-0x1c8],ax
   24209:	49 8d 44 24 02       	lea    rax,[r12+0x2]
   2420e:	48 89 41 30          	mov    QWORD PTR [rcx+0x30],rax
   24212:	48 8b 4b f8          	mov    rcx,QWORD PTR [rbx-0x8]
   24216:	4c 89 ef             	mov    rdi,r13
   24219:	48 89 85 10 fe ff ff 	mov    QWORD PTR [rbp-0x1f0],rax
   24220:	48 8d 43 f0          	lea    rax,[rbx-0x10]
   24224:	48 89 85 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],rax
   2422b:	e8 10 08 06 00       	call   84a40 <build_arg_list>
   24230:	49 89 c6             	mov    r14,rax
   24233:	48 85 c0             	test   rax,rax
   24236:	0f 84 fd 67 00 00    	je     2aa39 <JS_CallInternal+0x7f39>
   2423c:	f3 41 0f 6f 9d 70 01 	movdqu xmm3,XMMWORD PTR [r13+0x170]
   24243:	00 00 
   24245:	48 8b 43 e0          	mov    rax,QWORD PTR [rbx-0x20]
   24249:	41 b8 01 00 00 00    	mov    r8d,0x1
   2424f:	4c 8b 6b e8          	mov    r13,QWORD PTR [rbx-0x18]
   24253:	0f 29 9d 40 fe ff ff 	movaps XMMWORD PTR [rbp-0x1c0],xmm3
   2425a:	48 8b 95 40 fe ff ff 	mov    rdx,QWORD PTR [rbp-0x1c0]
   24261:	48 89 c7             	mov    rdi,rax
   24264:	48 8b 8d 48 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x1b8]
   2426b:	4c 89 ee             	mov    rsi,r13
   2426e:	48 89 85 28 fe ff ff 	mov    QWORD PTR [rbp-0x1d8],rax
   24275:	e8 56 62 ff ff       	call   1a4d0 <js_strict_eq2.isra.0>
   2427a:	44 8b 95 f0 fe ff ff 	mov    r10d,DWORD PTR [rbp-0x110]
   24281:	85 c0                	test   eax,eax
   24283:	0f 84 e4 59 00 00    	je     29c6d <JS_CallInternal+0x716d>
   24289:	45 85 d2             	test   r10d,r10d
   2428c:	0f 84 a6 59 00 00    	je     29c38 <JS_CallInternal+0x7138>
   24292:	49 8b 0e             	mov    rcx,QWORD PTR [r14]
   24295:	4d 8b 46 08          	mov    r8,QWORD PTR [r14+0x8]
   24299:	0f b7 85 38 fe ff ff 	movzx  eax,WORD PTR [rbp-0x1c8]
   242a0:	48 83 ec 08          	sub    rsp,0x8
   242a4:	31 f6                	xor    esi,esi
   242a6:	44 89 95 28 fe ff ff 	mov    DWORD PTR [rbp-0x1d8],r10d
   242ad:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   242b4:	41 b9 02 00 00 00    	mov    r9d,0x2
   242ba:	ba 03 00 00 00       	mov    edx,0x3
   242bf:	83 e8 02             	sub    eax,0x2
   242c2:	50                   	push   rax
   242c3:	e8 38 e1 01 00       	call   42400 <JS_EvalObject>
   242c8:	44 8b 95 28 fe ff ff 	mov    r10d,DWORD PTR [rbp-0x1d8]
   242cf:	48 89 85 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],rax
   242d6:	49 89 d5             	mov    r13,rdx
   242d9:	58                   	pop    rax
   242da:	5a                   	pop    rdx
   242db:	45 85 d2             	test   r10d,r10d
   242de:	0f 84 cb 6a 00 00    	je     2adaf <JS_CallInternal+0x82af>
   242e4:	45 89 d0             	mov    r8d,r10d
   242e7:	48 8b 8d e8 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x118]
   242ee:	48 89 9d 38 fe ff ff 	mov    QWORD PTR [rbp-0x1c8],rbx
   242f5:	4c 89 f3             	mov    rbx,r14
   242f8:	49 c1 e0 04          	shl    r8,0x4
   242fc:	4c 89 a5 28 fe ff ff 	mov    QWORD PTR [rbp-0x1d8],r12
   24303:	4d 01 f0             	add    r8,r14
   24306:	48 8b 79 10          	mov    rdi,QWORD PTR [rcx+0x10]
   2430a:	4d 89 c4             	mov    r12,r8
   2430d:	eb 0e                	jmp    2431d <JS_CallInternal+0x181d>
   2430f:	90                   	nop
   24310:	48 83 c3 10          	add    rbx,0x10
   24314:	4c 39 e3             	cmp    rbx,r12
   24317:	0f 84 9f 4d 00 00    	je     290bc <JS_CallInternal+0x65bc>
   2431d:	48 8b 4b 08          	mov    rcx,QWORD PTR [rbx+0x8]
   24321:	48 8b 33             	mov    rsi,QWORD PTR [rbx]
   24324:	83 f9 f6             	cmp    ecx,0xfffffff6
   24327:	76 e7                	jbe    24310 <JS_CallInternal+0x1810>
   24329:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   2432c:	8d 50 ff             	lea    edx,[rax-0x1]
   2432f:	89 56 fc             	mov    DWORD PTR [rsi-0x4],edx
   24332:	85 d2                	test   edx,edx
   24334:	7f da                	jg     24310 <JS_CallInternal+0x1810>
   24336:	48 89 ca             	mov    rdx,rcx
   24339:	e8 62 85 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2433e:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   24345:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   24349:	eb c5                	jmp    24310 <JS_CallInternal+0x1810>
   2434b:	f3 0f 1e fa          	endbr64
   2434f:	41 0f b7 0c 24       	movzx  ecx,WORD PTR [r12]
   24354:	49 89 dd             	mov    r13,rbx
   24357:	41 0f b7 7c 24 02    	movzx  edi,WORD PTR [r12+0x2]
   2435d:	41 b8 01 00 00 00    	mov    r8d,0x1
   24363:	48 89 c8             	mov    rax,rcx
   24366:	89 8d 50 fe ff ff    	mov    DWORD PTR [rbp-0x1b0],ecx
   2436c:	49 8d 4c 24 04       	lea    rcx,[r12+0x4]
   24371:	48 c1 e0 04          	shl    rax,0x4
   24375:	66 89 bd 38 fe ff ff 	mov    WORD PTR [rbp-0x1c8],di
   2437c:	49 29 c5             	sub    r13,rax
   2437f:	49 89 c6             	mov    r14,rax
   24382:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   24389:	48 89 8d 28 fe ff ff 	mov    QWORD PTR [rbp-0x1d8],rcx
   24390:	49 8b 7d f0          	mov    rdi,QWORD PTR [r13-0x10]
   24394:	49 8b 75 f8          	mov    rsi,QWORD PTR [r13-0x8]
   24398:	48 89 48 30          	mov    QWORD PTR [rax+0x30],rcx
   2439c:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   243a3:	f3 0f 6f b8 70 01 00 	movdqu xmm7,XMMWORD PTR [rax+0x170]
   243aa:	00 
   243ab:	0f 29 bd 40 fe ff ff 	movaps XMMWORD PTR [rbp-0x1c0],xmm7
   243b2:	48 8b 95 40 fe ff ff 	mov    rdx,QWORD PTR [rbp-0x1c0]
   243b9:	48 8b 8d 48 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x1b8]
   243c0:	e8 0b 61 ff ff       	call   1a4d0 <js_strict_eq2.isra.0>
   243c5:	85 c0                	test   eax,eax
   243c7:	0f 84 13 58 00 00    	je     29be0 <JS_CallInternal+0x70e0>
   243cd:	8b bd 50 fe ff ff    	mov    edi,DWORD PTR [rbp-0x1b0]
   243d3:	85 ff                	test   edi,edi
   243d5:	0f 84 ee 56 00 00    	je     29ac9 <JS_CallInternal+0x6fc9>
   243db:	49 8b 4d 00          	mov    rcx,QWORD PTR [r13+0x0]
   243df:	4d 8b 45 08          	mov    r8,QWORD PTR [r13+0x8]
   243e3:	0f b7 85 38 fe ff ff 	movzx  eax,WORD PTR [rbp-0x1c8]
   243ea:	48 83 ec 08          	sub    rsp,0x8
   243ee:	41 b9 02 00 00 00    	mov    r9d,0x2
   243f4:	31 f6                	xor    esi,esi
   243f6:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   243fd:	ba 03 00 00 00       	mov    edx,0x3
   24402:	83 e8 02             	sub    eax,0x2
   24405:	50                   	push   rax
   24406:	e8 f5 df 01 00       	call   42400 <JS_EvalObject>
   2440b:	59                   	pop    rcx
   2440c:	5e                   	pop    rsi
   2440d:	49 89 c1             	mov    r9,rax
   24410:	49 89 d0             	mov    r8,rdx
   24413:	49 8d 45 f0          	lea    rax,[r13-0x10]
   24417:	4d 01 f5             	add    r13,r14
   2441a:	49 89 c6             	mov    r14,rax
   2441d:	41 83 f8 06          	cmp    r8d,0x6
   24421:	75 1a                	jne    2443d <JS_CallInternal+0x193d>
   24423:	e9 b3 68 00 00       	jmp    2acdb <JS_CallInternal+0x81db>
   24428:	0f 1f 84 00 00 00 00 	nop    DWORD PTR [rax+rax*1+0x0]
   2442f:	00 
   24430:	49 83 c6 10          	add    r14,0x10
   24434:	4d 39 ee             	cmp    r14,r13
   24437:	0f 84 4c 4c 00 00    	je     29089 <JS_CallInternal+0x6589>
   2443d:	49 8b 56 08          	mov    rdx,QWORD PTR [r14+0x8]
   24441:	49 8b 36             	mov    rsi,QWORD PTR [r14]
   24444:	83 fa f6             	cmp    edx,0xfffffff6
   24447:	76 e7                	jbe    24430 <JS_CallInternal+0x1930>
   24449:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   2444c:	83 e8 01             	sub    eax,0x1
   2444f:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   24452:	85 c0                	test   eax,eax
   24454:	7f da                	jg     24430 <JS_CallInternal+0x1930>
   24456:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2445d:	4c 89 85 38 fe ff ff 	mov    QWORD PTR [rbp-0x1c8],r8
   24464:	4c 89 8d 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],r9
   2446b:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2446f:	e8 2c 84 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   24474:	4c 8b 85 38 fe ff ff 	mov    r8,QWORD PTR [rbp-0x1c8]
   2447b:	4c 8b 8d 40 fe ff ff 	mov    r9,QWORD PTR [rbp-0x1c0]
   24482:	eb ac                	jmp    24430 <JS_CallInternal+0x1930>
   24484:	f3 0f 1e fa          	endbr64
   24488:	41 0f b6 44 24 04    	movzx  eax,BYTE PTR [r12+0x4]
   2448e:	41 8b 34 24          	mov    esi,DWORD PTR [r12]
   24492:	49 83 c4 05          	add    r12,0x5
   24496:	3c 04                	cmp    al,0x4
   24498:	0f 87 96 5f 00 00    	ja     2a434 <JS_CallInternal+0x7934>
   2449e:	48 8d 15 7f 2c 0b 00 	lea    rdx,[rip+0xb2c7f]        # d7124 <qjsc_repl_size+0x458>
   244a5:	48 63 04 82          	movsxd rax,DWORD PTR [rdx+rax*4]
   244a9:	48 01 d0             	add    rax,rdx
   244ac:	3e ff e0             	notrack jmp rax
   244af:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   244b6:	48 8d 35 93 c8 0a 00 	lea    rsi,[rip+0xac893]        # d0d50 <_IO_stdin_used+0x3d50>
   244bd:	31 c0                	xor    eax,eax
   244bf:	e8 7c e8 00 00       	call   32d40 <JS_ThrowReferenceError>
   244c4:	e9 d7 ed ff ff       	jmp    232a0 <JS_CallInternal+0x7a0>
   244c9:	48 8d 15 ca 8f 0a 00 	lea    rdx,[rip+0xa8fca]        # cd49a <_IO_stdin_used+0x49a>
   244d0:	85 f6                	test   esi,esi
   244d2:	0f 85 bb 7c 00 00    	jne    2c193 <JS_CallInternal+0x9693>
   244d8:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   244df:	48 8d 35 10 90 0a 00 	lea    rsi,[rip+0xa9010]        # cd4f6 <_IO_stdin_used+0x4f6>
   244e6:	31 c0                	xor    eax,eax
   244e8:	e8 53 e8 00 00       	call   32d40 <JS_ThrowReferenceError>
   244ed:	e9 ae ed ff ff       	jmp    232a0 <JS_CallInternal+0x7a0>
   244f2:	4c 8b b5 e8 fe ff ff 	mov    r14,QWORD PTR [rbp-0x118]
   244f9:	48 8d 45 80          	lea    rax,[rbp-0x80]
   244fd:	89 f2                	mov    edx,esi
   244ff:	48 89 c6             	mov    rsi,rax
   24502:	49 8b 7e 10          	mov    rdi,QWORD PTR [r14+0x10]
   24506:	e8 05 2e ff ff       	call   17310 <JS_AtomGetStrRT.constprop.0>
   2450b:	48 8d 35 ce 8f 0a 00 	lea    rsi,[rip+0xa8fce]        # cd4e0 <_IO_stdin_used+0x4e0>
   24512:	4c 89 f7             	mov    rdi,r14
   24515:	48 89 c2             	mov    rdx,rax
   24518:	31 c0                	xor    eax,eax
   2451a:	e8 11 c3 00 00       	call   30830 <JS_ThrowSyntaxError>
   2451f:	e9 7c ed ff ff       	jmp    232a0 <JS_CallInternal+0x7a0>
   24524:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2452b:	48 8d 35 46 c8 0a 00 	lea    rsi,[rip+0xac846]        # d0d78 <_IO_stdin_used+0x3d78>
   24532:	31 c0                	xor    eax,eax
   24534:	e8 17 c7 00 00       	call   30c50 <JS_ThrowTypeError>
   24539:	e9 62 ed ff ff       	jmp    232a0 <JS_CallInternal+0x7a0>
   2453e:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   24545:	e8 c6 db 00 00       	call   32110 <JS_ThrowTypeErrorReadOnly.part.0>
   2454a:	e9 51 ed ff ff       	jmp    232a0 <JS_CallInternal+0x7a0>
   2454f:	f3 0f 1e fa          	endbr64
   24553:	48 8b 53 f8          	mov    rdx,QWORD PTR [rbx-0x8]
   24557:	41 0f b7 04 24       	movzx  eax,WORD PTR [r12]
   2455c:	48 8b 4b f0          	mov    rcx,QWORD PTR [rbx-0x10]
   24560:	83 fa f6             	cmp    edx,0xfffffff6
   24563:	76 04                	jbe    24569 <JS_CallInternal+0x1a69>
   24565:	83 41 fc 01          	add    DWORD PTR [rcx-0x4],0x1
   24569:	48 8b bd 90 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x170]
   24570:	48 c1 e0 04          	shl    rax,0x4
   24574:	48 01 f8             	add    rax,rdi
   24577:	4c 8b 40 08          	mov    r8,QWORD PTR [rax+0x8]
   2457b:	48 8b 30             	mov    rsi,QWORD PTR [rax]
   2457e:	48 89 50 08          	mov    QWORD PTR [rax+0x8],rdx
   24582:	48 89 08             	mov    QWORD PTR [rax],rcx
   24585:	41 83 f8 f6          	cmp    r8d,0xfffffff6
   24589:	76 11                	jbe    2459c <JS_CallInternal+0x1a9c>
   2458b:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   2458e:	83 e8 01             	sub    eax,0x1
   24591:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   24594:	85 c0                	test   eax,eax
   24596:	0f 8e f1 61 00 00    	jle    2a78d <JS_CallInternal+0x7c8d>
   2459c:	41 0f b6 44 24 02    	movzx  eax,BYTE PTR [r12+0x2]
   245a2:	49 83 c4 03          	add    r12,0x3
   245a6:	49 89 c5             	mov    r13,rax
   245a9:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   245ad:	ff e0                	jmp    rax
   245af:	f3 0f 1e fa          	endbr64
   245b3:	41 0f b7 04 24       	movzx  eax,WORD PTR [r12]
   245b8:	48 8b 8d 90 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x170]
   245bf:	f3 0f 6f 63 f0       	movdqu xmm4,XMMWORD PTR [rbx-0x10]
   245c4:	48 c1 e0 04          	shl    rax,0x4
   245c8:	48 01 c8             	add    rax,rcx
   245cb:	48 8b 50 08          	mov    rdx,QWORD PTR [rax+0x8]
   245cf:	48 8b 30             	mov    rsi,QWORD PTR [rax]
   245d2:	0f 11 20             	movups XMMWORD PTR [rax],xmm4
   245d5:	83 fa f6             	cmp    edx,0xfffffff6
   245d8:	76 11                	jbe    245eb <JS_CallInternal+0x1aeb>
   245da:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   245dd:	83 e8 01             	sub    eax,0x1
   245e0:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   245e3:	85 c0                	test   eax,eax
   245e5:	0f 8e ba 61 00 00    	jle    2a7a5 <JS_CallInternal+0x7ca5>
   245eb:	41 0f b6 44 24 02    	movzx  eax,BYTE PTR [r12+0x2]
   245f1:	48 83 eb 10          	sub    rbx,0x10
   245f5:	49 83 c4 03          	add    r12,0x3
   245f9:	49 89 c5             	mov    r13,rax
   245fc:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   24600:	ff e0                	jmp    rax
   24602:	f3 0f 1e fa          	endbr64
   24606:	41 0f b7 04 24       	movzx  eax,WORD PTR [r12]
   2460b:	48 8b 8d 90 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x170]
   24612:	48 c1 e0 04          	shl    rax,0x4
   24616:	48 01 c8             	add    rax,rcx
   24619:	48 8b 10             	mov    rdx,QWORD PTR [rax]
   2461c:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
   24620:	83 f8 f6             	cmp    eax,0xfffffff6
   24623:	76 04                	jbe    24629 <JS_CallInternal+0x1b29>
   24625:	83 42 fc 01          	add    DWORD PTR [rdx-0x4],0x1
   24629:	48 89 13             	mov    QWORD PTR [rbx],rdx
   2462c:	49 83 c4 03          	add    r12,0x3
   24630:	48 83 c3 10          	add    rbx,0x10
   24634:	48 89 43 f8          	mov    QWORD PTR [rbx-0x8],rax
   24638:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   2463e:	49 89 c5             	mov    r13,rax
   24641:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   24645:	ff e0                	jmp    rax
   24647:	f3 0f 1e fa          	endbr64
   2464b:	48 8b 53 f8          	mov    rdx,QWORD PTR [rbx-0x8]
   2464f:	41 0f b7 04 24       	movzx  eax,WORD PTR [r12]
   24654:	48 8b 4b f0          	mov    rcx,QWORD PTR [rbx-0x10]
   24658:	83 fa f6             	cmp    edx,0xfffffff6
   2465b:	76 04                	jbe    24661 <JS_CallInternal+0x1b61>
   2465d:	83 41 fc 01          	add    DWORD PTR [rcx-0x4],0x1
   24661:	48 8b bd b0 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x150]
   24668:	48 c1 e0 04          	shl    rax,0x4
   2466c:	48 01 f8             	add    rax,rdi
   2466f:	4c 8b 40 08          	mov    r8,QWORD PTR [rax+0x8]
   24673:	48 8b 30             	mov    rsi,QWORD PTR [rax]
   24676:	48 89 50 08          	mov    QWORD PTR [rax+0x8],rdx
   2467a:	48 89 08             	mov    QWORD PTR [rax],rcx
   2467d:	41 83 f8 f6          	cmp    r8d,0xfffffff6
   24681:	76 11                	jbe    24694 <JS_CallInternal+0x1b94>
   24683:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   24686:	83 e8 01             	sub    eax,0x1
   24689:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   2468c:	85 c0                	test   eax,eax
   2468e:	0f 8e aa 61 00 00    	jle    2a83e <JS_CallInternal+0x7d3e>
   24694:	41 0f b6 44 24 02    	movzx  eax,BYTE PTR [r12+0x2]
   2469a:	49 83 c4 03          	add    r12,0x3
   2469e:	49 89 c5             	mov    r13,rax
   246a1:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   246a5:	ff e0                	jmp    rax
   246a7:	f3 0f 1e fa          	endbr64
   246ab:	41 0f b7 04 24       	movzx  eax,WORD PTR [r12]
   246b0:	48 8b 8d b0 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x150]
   246b7:	f3 0f 6f 4b f0       	movdqu xmm1,XMMWORD PTR [rbx-0x10]
   246bc:	48 c1 e0 04          	shl    rax,0x4
   246c0:	48 01 c8             	add    rax,rcx
   246c3:	48 8b 50 08          	mov    rdx,QWORD PTR [rax+0x8]
   246c7:	48 8b 30             	mov    rsi,QWORD PTR [rax]
   246ca:	0f 11 08             	movups XMMWORD PTR [rax],xmm1
   246cd:	83 fa f6             	cmp    edx,0xfffffff6
   246d0:	76 11                	jbe    246e3 <JS_CallInternal+0x1be3>
   246d2:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   246d5:	83 e8 01             	sub    eax,0x1
   246d8:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   246db:	85 c0                	test   eax,eax
   246dd:	0f 8e 46 61 00 00    	jle    2a829 <JS_CallInternal+0x7d29>
   246e3:	41 0f b6 44 24 02    	movzx  eax,BYTE PTR [r12+0x2]
   246e9:	48 83 eb 10          	sub    rbx,0x10
   246ed:	49 83 c4 03          	add    r12,0x3
   246f1:	49 89 c5             	mov    r13,rax
   246f4:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   246f8:	ff e0                	jmp    rax
   246fa:	f3 0f 1e fa          	endbr64
   246fe:	41 0f b7 04 24       	movzx  eax,WORD PTR [r12]
   24703:	48 8b 8d b0 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x150]
   2470a:	48 c1 e0 04          	shl    rax,0x4
   2470e:	48 01 c8             	add    rax,rcx
   24711:	48 8b 10             	mov    rdx,QWORD PTR [rax]
   24714:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
   24718:	83 f8 f6             	cmp    eax,0xfffffff6
   2471b:	76 04                	jbe    24721 <JS_CallInternal+0x1c21>
   2471d:	83 42 fc 01          	add    DWORD PTR [rdx-0x4],0x1
   24721:	48 89 13             	mov    QWORD PTR [rbx],rdx
   24724:	49 83 c4 03          	add    r12,0x3
   24728:	48 83 c3 10          	add    rbx,0x10
   2472c:	48 89 43 f8          	mov    QWORD PTR [rbx-0x8],rax
   24730:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   24736:	49 89 c5             	mov    r13,rax
   24739:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   2473d:	ff e0                	jmp    rax
   2473f:	f3 0f 1e fa          	endbr64
   24743:	48 8b 85 90 fe ff ff 	mov    rax,QWORD PTR [rbp-0x170]
   2474a:	48 8d 4b 10          	lea    rcx,[rbx+0x10]
   2474e:	48 8b 10             	mov    rdx,QWORD PTR [rax]
   24751:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
   24755:	83 f8 f6             	cmp    eax,0xfffffff6
   24758:	76 04                	jbe    2475e <JS_CallInternal+0x1c5e>
   2475a:	83 42 fc 01          	add    DWORD PTR [rdx-0x4],0x1
   2475e:	48 89 13             	mov    QWORD PTR [rbx],rdx
   24761:	49 83 c4 01          	add    r12,0x1
   24765:	48 89 43 08          	mov    QWORD PTR [rbx+0x8],rax
   24769:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   2476f:	48 89 cb             	mov    rbx,rcx
   24772:	49 89 c5             	mov    r13,rax
   24775:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   24779:	ff e0                	jmp    rax
   2477b:	f3 0f 1e fa          	endbr64
   2477f:	48 8b 43 f8          	mov    rax,QWORD PTR [rbx-0x8]
   24783:	48 8b 53 f0          	mov    rdx,QWORD PTR [rbx-0x10]
   24787:	83 f8 f6             	cmp    eax,0xfffffff6
   2478a:	76 04                	jbe    24790 <JS_CallInternal+0x1c90>
   2478c:	83 42 fc 01          	add    DWORD PTR [rdx-0x4],0x1
   24790:	48 8b bd b0 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x150]
   24797:	48 8b 4f 38          	mov    rcx,QWORD PTR [rdi+0x38]
   2479b:	48 8b 77 30          	mov    rsi,QWORD PTR [rdi+0x30]
   2479f:	48 89 47 38          	mov    QWORD PTR [rdi+0x38],rax
   247a3:	48 89 57 30          	mov    QWORD PTR [rdi+0x30],rdx
   247a7:	83 f9 f6             	cmp    ecx,0xfffffff6
   247aa:	76 11                	jbe    247bd <JS_CallInternal+0x1cbd>
   247ac:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   247af:	83 e8 01             	sub    eax,0x1
   247b2:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   247b5:	85 c0                	test   eax,eax
   247b7:	0f 8e 54 60 00 00    	jle    2a811 <JS_CallInternal+0x7d11>
   247bd:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   247c2:	49 83 c4 01          	add    r12,0x1
   247c6:	49 89 c5             	mov    r13,rax
   247c9:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   247cd:	ff e0                	jmp    rax
   247cf:	f3 0f 1e fa          	endbr64
   247d3:	48 8b 43 f8          	mov    rax,QWORD PTR [rbx-0x8]
   247d7:	48 8b 53 f0          	mov    rdx,QWORD PTR [rbx-0x10]
   247db:	83 f8 f6             	cmp    eax,0xfffffff6
   247de:	76 04                	jbe    247e4 <JS_CallInternal+0x1ce4>
   247e0:	83 42 fc 01          	add    DWORD PTR [rdx-0x4],0x1
   247e4:	48 8b bd b0 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x150]
   247eb:	48 8b 4f 28          	mov    rcx,QWORD PTR [rdi+0x28]
   247ef:	48 8b 77 20          	mov    rsi,QWORD PTR [rdi+0x20]
   247f3:	48 89 47 28          	mov    QWORD PTR [rdi+0x28],rax
   247f7:	48 89 57 20          	mov    QWORD PTR [rdi+0x20],rdx
   247fb:	83 f9 f6             	cmp    ecx,0xfffffff6
   247fe:	76 11                	jbe    24811 <JS_CallInternal+0x1d11>
   24800:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   24803:	83 e8 01             	sub    eax,0x1
   24806:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   24809:	85 c0                	test   eax,eax
   2480b:	0f 8e 72 60 00 00    	jle    2a883 <JS_CallInternal+0x7d83>
   24811:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   24816:	49 83 c4 01          	add    r12,0x1
   2481a:	49 89 c5             	mov    r13,rax
   2481d:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   24821:	ff e0                	jmp    rax
   24823:	f3 0f 1e fa          	endbr64
   24827:	48 8b 43 f8          	mov    rax,QWORD PTR [rbx-0x8]
   2482b:	48 8b 53 f0          	mov    rdx,QWORD PTR [rbx-0x10]
   2482f:	83 f8 f6             	cmp    eax,0xfffffff6
   24832:	76 04                	jbe    24838 <JS_CallInternal+0x1d38>
   24834:	83 42 fc 01          	add    DWORD PTR [rdx-0x4],0x1
   24838:	48 8b bd b0 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x150]
   2483f:	48 8b 4f 18          	mov    rcx,QWORD PTR [rdi+0x18]
   24843:	48 8b 77 10          	mov    rsi,QWORD PTR [rdi+0x10]
   24847:	48 89 47 18          	mov    QWORD PTR [rdi+0x18],rax
   2484b:	48 89 57 10          	mov    QWORD PTR [rdi+0x10],rdx
   2484f:	83 f9 f6             	cmp    ecx,0xfffffff6
   24852:	76 11                	jbe    24865 <JS_CallInternal+0x1d65>
   24854:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   24857:	83 e8 01             	sub    eax,0x1
   2485a:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   2485d:	85 c0                	test   eax,eax
   2485f:	0f 8e 36 60 00 00    	jle    2a89b <JS_CallInternal+0x7d9b>
   24865:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   2486a:	49 83 c4 01          	add    r12,0x1
   2486e:	49 89 c5             	mov    r13,rax
   24871:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   24875:	ff e0                	jmp    rax
   24877:	f3 0f 1e fa          	endbr64
   2487b:	48 8b 43 f8          	mov    rax,QWORD PTR [rbx-0x8]
   2487f:	48 8b 53 f0          	mov    rdx,QWORD PTR [rbx-0x10]
   24883:	83 f8 f6             	cmp    eax,0xfffffff6
   24886:	76 04                	jbe    2488c <JS_CallInternal+0x1d8c>
   24888:	83 42 fc 01          	add    DWORD PTR [rdx-0x4],0x1
   2488c:	48 8b bd b0 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x150]
   24893:	48 8b 4f 08          	mov    rcx,QWORD PTR [rdi+0x8]
   24897:	48 8b 37             	mov    rsi,QWORD PTR [rdi]
   2489a:	48 89 47 08          	mov    QWORD PTR [rdi+0x8],rax
   2489e:	48 89 17             	mov    QWORD PTR [rdi],rdx
   248a1:	83 f9 f6             	cmp    ecx,0xfffffff6
   248a4:	76 11                	jbe    248b7 <JS_CallInternal+0x1db7>
   248a6:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   248a9:	83 e8 01             	sub    eax,0x1
   248ac:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   248af:	85 c0                	test   eax,eax
   248b1:	0f 8e 9f 5f 00 00    	jle    2a856 <JS_CallInternal+0x7d56>
   248b7:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   248bc:	49 83 c4 01          	add    r12,0x1
   248c0:	49 89 c5             	mov    r13,rax
   248c3:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   248c7:	ff e0                	jmp    rax
   248c9:	f3 0f 1e fa          	endbr64
   248cd:	48 8b 85 b0 fe ff ff 	mov    rax,QWORD PTR [rbp-0x150]
   248d4:	f3 0f 6f 5b f0       	movdqu xmm3,XMMWORD PTR [rbx-0x10]
   248d9:	48 83 eb 10          	sub    rbx,0x10
   248dd:	48 8b 50 38          	mov    rdx,QWORD PTR [rax+0x38]
   248e1:	48 8b 70 30          	mov    rsi,QWORD PTR [rax+0x30]
   248e5:	0f 11 58 30          	movups XMMWORD PTR [rax+0x30],xmm3
   248e9:	83 fa f6             	cmp    edx,0xfffffff6
   248ec:	76 11                	jbe    248ff <JS_CallInternal+0x1dff>
   248ee:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   248f1:	83 e8 01             	sub    eax,0x1
   248f4:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   248f7:	85 c0                	test   eax,eax
   248f9:	0f 8e 6f 5f 00 00    	jle    2a86e <JS_CallInternal+0x7d6e>
   248ff:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   24904:	49 83 c4 01          	add    r12,0x1
   24908:	49 89 c5             	mov    r13,rax
   2490b:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   2490f:	ff e0                	jmp    rax
   24911:	f3 0f 1e fa          	endbr64
   24915:	48 8b 85 b0 fe ff ff 	mov    rax,QWORD PTR [rbp-0x150]
   2491c:	f3 0f 6f 7b f0       	movdqu xmm7,XMMWORD PTR [rbx-0x10]
   24921:	48 83 eb 10          	sub    rbx,0x10
   24925:	48 8b 50 28          	mov    rdx,QWORD PTR [rax+0x28]
   24929:	48 8b 70 20          	mov    rsi,QWORD PTR [rax+0x20]
   2492d:	0f 11 78 20          	movups XMMWORD PTR [rax+0x20],xmm7
   24931:	83 fa f6             	cmp    edx,0xfffffff6
   24934:	76 11                	jbe    24947 <JS_CallInternal+0x1e47>
   24936:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   24939:	83 e8 01             	sub    eax,0x1
   2493c:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   2493f:	85 c0                	test   eax,eax
   24941:	0f 8e a0 5e 00 00    	jle    2a7e7 <JS_CallInternal+0x7ce7>
   24947:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   2494c:	49 83 c4 01          	add    r12,0x1
   24950:	49 89 c5             	mov    r13,rax
   24953:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   24957:	ff e0                	jmp    rax
   24959:	f3 0f 1e fa          	endbr64
   2495d:	48 8b 85 b0 fe ff ff 	mov    rax,QWORD PTR [rbp-0x150]
   24964:	f3 0f 6f 73 f0       	movdqu xmm6,XMMWORD PTR [rbx-0x10]
   24969:	48 83 eb 10          	sub    rbx,0x10
   2496d:	48 8b 50 18          	mov    rdx,QWORD PTR [rax+0x18]
   24971:	48 8b 70 10          	mov    rsi,QWORD PTR [rax+0x10]
   24975:	0f 11 70 10          	movups XMMWORD PTR [rax+0x10],xmm6
   24979:	83 fa f6             	cmp    edx,0xfffffff6
   2497c:	76 11                	jbe    2498f <JS_CallInternal+0x1e8f>
   2497e:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   24981:	83 e8 01             	sub    eax,0x1
   24984:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   24987:	85 c0                	test   eax,eax
   24989:	0f 8e 6d 5e 00 00    	jle    2a7fc <JS_CallInternal+0x7cfc>
   2498f:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   24994:	49 83 c4 01          	add    r12,0x1
   24998:	49 89 c5             	mov    r13,rax
   2499b:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   2499f:	ff e0                	jmp    rax
   249a1:	f3 0f 1e fa          	endbr64
   249a5:	48 8b 85 b0 fe ff ff 	mov    rax,QWORD PTR [rbp-0x150]
   249ac:	f3 0f 6f 6b f0       	movdqu xmm5,XMMWORD PTR [rbx-0x10]
   249b1:	48 83 eb 10          	sub    rbx,0x10
   249b5:	48 8b 50 08          	mov    rdx,QWORD PTR [rax+0x8]
   249b9:	48 8b 30             	mov    rsi,QWORD PTR [rax]
   249bc:	0f 11 28             	movups XMMWORD PTR [rax],xmm5
   249bf:	83 fa f6             	cmp    edx,0xfffffff6
   249c2:	76 11                	jbe    249d5 <JS_CallInternal+0x1ed5>
   249c4:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   249c7:	83 e8 01             	sub    eax,0x1
   249ca:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   249cd:	85 c0                	test   eax,eax
   249cf:	0f 8e e5 5d 00 00    	jle    2a7ba <JS_CallInternal+0x7cba>
   249d5:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   249da:	49 83 c4 01          	add    r12,0x1
   249de:	49 89 c5             	mov    r13,rax
   249e1:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   249e5:	ff e0                	jmp    rax
   249e7:	f3 0f 1e fa          	endbr64
   249eb:	48 8b 85 b0 fe ff ff 	mov    rax,QWORD PTR [rbp-0x150]
   249f2:	48 8d 4b 10          	lea    rcx,[rbx+0x10]
   249f6:	48 8b 50 30          	mov    rdx,QWORD PTR [rax+0x30]
   249fa:	48 8b 40 38          	mov    rax,QWORD PTR [rax+0x38]
   249fe:	83 f8 f6             	cmp    eax,0xfffffff6
   24a01:	76 04                	jbe    24a07 <JS_CallInternal+0x1f07>
   24a03:	83 42 fc 01          	add    DWORD PTR [rdx-0x4],0x1
   24a07:	48 89 13             	mov    QWORD PTR [rbx],rdx
   24a0a:	49 83 c4 01          	add    r12,0x1
   24a0e:	48 89 43 08          	mov    QWORD PTR [rbx+0x8],rax
   24a12:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   24a18:	48 89 cb             	mov    rbx,rcx
   24a1b:	49 89 c5             	mov    r13,rax
   24a1e:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   24a22:	ff e0                	jmp    rax
   24a24:	f3 0f 1e fa          	endbr64
   24a28:	48 8b 85 b0 fe ff ff 	mov    rax,QWORD PTR [rbp-0x150]
   24a2f:	48 8d 4b 10          	lea    rcx,[rbx+0x10]
   24a33:	48 8b 50 20          	mov    rdx,QWORD PTR [rax+0x20]
   24a37:	48 8b 40 28          	mov    rax,QWORD PTR [rax+0x28]
   24a3b:	83 f8 f6             	cmp    eax,0xfffffff6
   24a3e:	76 04                	jbe    24a44 <JS_CallInternal+0x1f44>
   24a40:	83 42 fc 01          	add    DWORD PTR [rdx-0x4],0x1
   24a44:	48 89 13             	mov    QWORD PTR [rbx],rdx
   24a47:	49 83 c4 01          	add    r12,0x1
   24a4b:	48 89 43 08          	mov    QWORD PTR [rbx+0x8],rax
   24a4f:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   24a55:	48 89 cb             	mov    rbx,rcx
   24a58:	49 89 c5             	mov    r13,rax
   24a5b:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   24a5f:	ff e0                	jmp    rax
   24a61:	f3 0f 1e fa          	endbr64
   24a65:	48 8b 85 b0 fe ff ff 	mov    rax,QWORD PTR [rbp-0x150]
   24a6c:	48 8d 4b 10          	lea    rcx,[rbx+0x10]
   24a70:	48 8b 50 10          	mov    rdx,QWORD PTR [rax+0x10]
   24a74:	48 8b 40 18          	mov    rax,QWORD PTR [rax+0x18]
   24a78:	83 f8 f6             	cmp    eax,0xfffffff6
   24a7b:	76 04                	jbe    24a81 <JS_CallInternal+0x1f81>
   24a7d:	83 42 fc 01          	add    DWORD PTR [rdx-0x4],0x1
   24a81:	48 89 13             	mov    QWORD PTR [rbx],rdx
   24a84:	49 83 c4 01          	add    r12,0x1
   24a88:	48 89 43 08          	mov    QWORD PTR [rbx+0x8],rax
   24a8c:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   24a92:	48 89 cb             	mov    rbx,rcx
   24a95:	49 89 c5             	mov    r13,rax
   24a98:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   24a9c:	ff e0                	jmp    rax
   24a9e:	f3 0f 1e fa          	endbr64
   24aa2:	48 8b 85 b0 fe ff ff 	mov    rax,QWORD PTR [rbp-0x150]
   24aa9:	48 8d 4b 10          	lea    rcx,[rbx+0x10]
   24aad:	48 8b 10             	mov    rdx,QWORD PTR [rax]
   24ab0:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
   24ab4:	83 f8 f6             	cmp    eax,0xfffffff6
   24ab7:	76 04                	jbe    24abd <JS_CallInternal+0x1fbd>
   24ab9:	83 42 fc 01          	add    DWORD PTR [rdx-0x4],0x1
   24abd:	48 89 13             	mov    QWORD PTR [rbx],rdx
   24ac0:	49 83 c4 01          	add    r12,0x1
   24ac4:	48 89 43 08          	mov    QWORD PTR [rbx+0x8],rax
   24ac8:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   24ace:	48 89 cb             	mov    rbx,rcx
   24ad1:	49 89 c5             	mov    r13,rax
   24ad4:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   24ad8:	ff e0                	jmp    rax
   24ada:	f3 0f 1e fa          	endbr64
   24ade:	48 8b 53 f8          	mov    rdx,QWORD PTR [rbx-0x8]
   24ae2:	48 8b 4b f0          	mov    rcx,QWORD PTR [rbx-0x10]
   24ae6:	83 fa f6             	cmp    edx,0xfffffff6
   24ae9:	76 04                	jbe    24aef <JS_CallInternal+0x1fef>
   24aeb:	83 41 fc 01          	add    DWORD PTR [rcx-0x4],0x1
   24aef:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   24af4:	48 8b bd b0 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x150]
   24afb:	48 c1 e0 04          	shl    rax,0x4
   24aff:	48 01 f8             	add    rax,rdi
   24b02:	4c 8b 40 08          	mov    r8,QWORD PTR [rax+0x8]
   24b06:	48 8b 30             	mov    rsi,QWORD PTR [rax]
   24b09:	48 89 50 08          	mov    QWORD PTR [rax+0x8],rdx
   24b0d:	48 89 08             	mov    QWORD PTR [rax],rcx
   24b10:	41 83 f8 f6          	cmp    r8d,0xfffffff6
   24b14:	76 11                	jbe    24b27 <JS_CallInternal+0x2027>
   24b16:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   24b19:	83 e8 01             	sub    eax,0x1
   24b1c:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   24b1f:	85 c0                	test   eax,eax
   24b21:	0f 8e a8 5c 00 00    	jle    2a7cf <JS_CallInternal+0x7ccf>
   24b27:	41 0f b6 44 24 01    	movzx  eax,BYTE PTR [r12+0x1]
   24b2d:	49 83 c4 02          	add    r12,0x2
   24b31:	49 89 c5             	mov    r13,rax
   24b34:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   24b38:	ff e0                	jmp    rax
   24b3a:	f3 0f 1e fa          	endbr64
   24b3e:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   24b43:	48 8b 8d b0 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x150]
   24b4a:	48 83 eb 10          	sub    rbx,0x10
   24b4e:	f3 0f 6f 13          	movdqu xmm2,XMMWORD PTR [rbx]
   24b52:	48 c1 e0 04          	shl    rax,0x4
   24b56:	48 01 c8             	add    rax,rcx
   24b59:	48 8b 50 08          	mov    rdx,QWORD PTR [rax+0x8]
   24b5d:	48 8b 30             	mov    rsi,QWORD PTR [rax]
   24b60:	0f 11 10             	movups XMMWORD PTR [rax],xmm2
   24b63:	83 fa f6             	cmp    edx,0xfffffff6
   24b66:	76 11                	jbe    24b79 <JS_CallInternal+0x2079>
   24b68:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   24b6b:	83 e8 01             	sub    eax,0x1
   24b6e:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   24b71:	85 c0                	test   eax,eax
   24b73:	0f 8e cd 5a 00 00    	jle    2a646 <JS_CallInternal+0x7b46>
   24b79:	41 0f b6 44 24 01    	movzx  eax,BYTE PTR [r12+0x1]
   24b7f:	49 83 c4 02          	add    r12,0x2
   24b83:	49 89 c5             	mov    r13,rax
   24b86:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   24b8a:	ff e0                	jmp    rax
   24b8c:	f3 0f 1e fa          	endbr64
   24b90:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   24b95:	48 8b 8d b0 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x150]
   24b9c:	48 c1 e0 04          	shl    rax,0x4
   24ba0:	48 01 c8             	add    rax,rcx
   24ba3:	48 8d 4b 10          	lea    rcx,[rbx+0x10]
   24ba7:	48 8b 10             	mov    rdx,QWORD PTR [rax]
   24baa:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
   24bae:	83 f8 f6             	cmp    eax,0xfffffff6
   24bb1:	76 04                	jbe    24bb7 <JS_CallInternal+0x20b7>
   24bb3:	83 42 fc 01          	add    DWORD PTR [rdx-0x4],0x1
   24bb7:	48 89 13             	mov    QWORD PTR [rbx],rdx
   24bba:	49 83 c4 02          	add    r12,0x2
   24bbe:	48 89 43 08          	mov    QWORD PTR [rbx+0x8],rax
   24bc2:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   24bc8:	48 89 cb             	mov    rbx,rcx
   24bcb:	49 89 c5             	mov    r13,rax
   24bce:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   24bd2:	ff e0                	jmp    rax
   24bd4:	f3 0f 1e fa          	endbr64
   24bd8:	41 0f b7 04 24       	movzx  eax,WORD PTR [r12]
   24bdd:	48 8b bd b0 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x150]
   24be4:	4d 8d 6c 24 02       	lea    r13,[r12+0x2]
   24be9:	48 89 c1             	mov    rcx,rax
   24bec:	48 c1 e0 04          	shl    rax,0x4
   24bf0:	48 01 f8             	add    rax,rdi
   24bf3:	48 8b 50 08          	mov    rdx,QWORD PTR [rax+0x8]
   24bf7:	83 fa 04             	cmp    edx,0x4
   24bfa:	0f 84 69 6d 00 00    	je     2b969 <JS_CallInternal+0x8e69>
   24c00:	48 8b 00             	mov    rax,QWORD PTR [rax]
   24c03:	83 fa f6             	cmp    edx,0xfffffff6
   24c06:	76 04                	jbe    24c0c <JS_CallInternal+0x210c>
   24c08:	83 40 fc 01          	add    DWORD PTR [rax-0x4],0x1
   24c0c:	48 89 03             	mov    QWORD PTR [rbx],rax
   24c0f:	49 83 c4 03          	add    r12,0x3
   24c13:	48 83 c3 10          	add    rbx,0x10
   24c17:	48 89 53 f8          	mov    QWORD PTR [rbx-0x8],rdx
   24c1b:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   24c21:	49 89 c5             	mov    r13,rax
   24c24:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   24c28:	ff e0                	jmp    rax
   24c2a:	f3 0f 1e fa          	endbr64
   24c2e:	41 0f b7 04 24       	movzx  eax,WORD PTR [r12]
   24c33:	48 8b bd b0 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x150]
   24c3a:	4d 8d 6c 24 02       	lea    r13,[r12+0x2]
   24c3f:	48 89 c1             	mov    rcx,rax
   24c42:	48 c1 e0 04          	shl    rax,0x4
   24c46:	48 01 f8             	add    rax,rdi
   24c49:	48 8b 50 08          	mov    rdx,QWORD PTR [rax+0x8]
   24c4d:	83 fa 04             	cmp    edx,0x4
   24c50:	0f 84 54 6e 00 00    	je     2baaa <JS_CallInternal+0x8faa>
   24c56:	48 8b 00             	mov    rax,QWORD PTR [rax]
   24c59:	83 fa f6             	cmp    edx,0xfffffff6
   24c5c:	76 04                	jbe    24c62 <JS_CallInternal+0x2162>
   24c5e:	83 40 fc 01          	add    DWORD PTR [rax-0x4],0x1
   24c62:	48 89 03             	mov    QWORD PTR [rbx],rax
   24c65:	49 83 c4 03          	add    r12,0x3
   24c69:	48 83 c3 10          	add    rbx,0x10
   24c6d:	48 89 53 f8          	mov    QWORD PTR [rbx-0x8],rdx
   24c71:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   24c77:	49 89 c5             	mov    r13,rax
   24c7a:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   24c7e:	ff e0                	jmp    rax
   24c80:	f3 0f 1e fa          	endbr64
   24c84:	41 0f b7 04 24       	movzx  eax,WORD PTR [r12]
   24c89:	48 8b 8d b0 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x150]
   24c90:	48 c1 e0 04          	shl    rax,0x4
   24c94:	48 01 c8             	add    rax,rcx
   24c97:	48 8b 50 08          	mov    rdx,QWORD PTR [rax+0x8]
   24c9b:	48 8b 30             	mov    rsi,QWORD PTR [rax]
   24c9e:	48 c7 40 08 04 00 00 	mov    QWORD PTR [rax+0x8],0x4
   24ca5:	00 
   24ca6:	48 c7 00 00 00 00 00 	mov    QWORD PTR [rax],0x0
   24cad:	83 fa f6             	cmp    edx,0xfffffff6
   24cb0:	76 11                	jbe    24cc3 <JS_CallInternal+0x21c3>
   24cb2:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   24cb5:	83 e8 01             	sub    eax,0x1
   24cb8:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   24cbb:	85 c0                	test   eax,eax
   24cbd:	0f 8e 6e 59 00 00    	jle    2a631 <JS_CallInternal+0x7b31>
   24cc3:	41 0f b6 44 24 02    	movzx  eax,BYTE PTR [r12+0x2]
   24cc9:	49 83 c4 03          	add    r12,0x3
   24ccd:	49 89 c5             	mov    r13,rax
   24cd0:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   24cd4:	ff e0                	jmp    rax
   24cd6:	f3 0f 1e fa          	endbr64
   24cda:	41 0f b7 04 24       	movzx  eax,WORD PTR [r12]
   24cdf:	48 8b 8d 98 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x168]
   24ce6:	4d 8d 6c 24 02       	lea    r13,[r12+0x2]
   24ceb:	48 8d 14 c5 00 00 00 	lea    rdx,[rax*8+0x0]
   24cf2:	00 
   24cf3:	48 8b 04 c1          	mov    rax,QWORD PTR [rcx+rax*8]
   24cf7:	48 8b 40 18          	mov    rax,QWORD PTR [rax+0x18]
   24cfb:	83 78 08 04          	cmp    DWORD PTR [rax+0x8],0x4
   24cff:	0f 85 39 61 00 00    	jne    2ae3e <JS_CallInternal+0x833e>
   24d05:	f3 0f 6f 7b f0       	movdqu xmm7,XMMWORD PTR [rbx-0x10]
   24d0a:	49 83 c4 03          	add    r12,0x3
   24d0e:	48 83 eb 10          	sub    rbx,0x10
   24d12:	0f 11 38             	movups XMMWORD PTR [rax],xmm7
   24d15:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   24d1b:	49 89 c5             	mov    r13,rax
   24d1e:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   24d22:	ff e0                	jmp    rax
   24d24:	f3 0f 1e fa          	endbr64
   24d28:	41 0f b7 04 24       	movzx  eax,WORD PTR [r12]
   24d2d:	48 8b bd 98 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x168]
   24d34:	4d 8d 6c 24 02       	lea    r13,[r12+0x2]
   24d39:	48 8d 0c c5 00 00 00 	lea    rcx,[rax*8+0x0]
   24d40:	00 
   24d41:	48 8b 04 c7          	mov    rax,QWORD PTR [rdi+rax*8]
   24d45:	48 8b 40 18          	mov    rax,QWORD PTR [rax+0x18]
   24d49:	48 8b 50 08          	mov    rdx,QWORD PTR [rax+0x8]
   24d4d:	83 fa 04             	cmp    edx,0x4
   24d50:	0f 84 23 69 00 00    	je     2b679 <JS_CallInternal+0x8b79>
   24d56:	f3 0f 6f 73 f0       	movdqu xmm6,XMMWORD PTR [rbx-0x10]
   24d5b:	48 8b 30             	mov    rsi,QWORD PTR [rax]
   24d5e:	0f 11 30             	movups XMMWORD PTR [rax],xmm6
   24d61:	83 fa f6             	cmp    edx,0xfffffff6
   24d64:	76 11                	jbe    24d77 <JS_CallInternal+0x2277>
   24d66:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   24d69:	83 e8 01             	sub    eax,0x1
   24d6c:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   24d6f:	85 c0                	test   eax,eax
   24d71:	0f 8e b2 57 00 00    	jle    2a529 <JS_CallInternal+0x7a29>
   24d77:	41 0f b6 44 24 02    	movzx  eax,BYTE PTR [r12+0x2]
   24d7d:	48 83 eb 10          	sub    rbx,0x10
   24d81:	49 83 c4 03          	add    r12,0x3
   24d85:	49 89 c5             	mov    r13,rax
   24d88:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   24d8c:	ff e0                	jmp    rax
   24d8e:	f3 0f 1e fa          	endbr64
   24d92:	48 8b 73 f0          	mov    rsi,QWORD PTR [rbx-0x10]
   24d96:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   24d9d:	4c 8d 43 f0          	lea    r8,[rbx-0x10]
   24da1:	49 8b 50 08          	mov    rdx,QWORD PTR [r8+0x8]
   24da5:	e8 16 6c ff ff       	call   1b9c0 <js_operator_typeof>
   24daa:	83 f8 1b             	cmp    eax,0x1b
   24dad:	74 61                	je     24e10 <JS_CallInternal+0x2310>
   24daf:	49 8b 50 08          	mov    rdx,QWORD PTR [r8+0x8]
   24db3:	49 8b 30             	mov    rsi,QWORD PTR [r8]
   24db6:	83 fa f6             	cmp    edx,0xfffffff6
   24db9:	76 11                	jbe    24dcc <JS_CallInternal+0x22cc>
   24dbb:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   24dbe:	83 e8 01             	sub    eax,0x1
   24dc1:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   24dc4:	85 c0                	test   eax,eax
   24dc6:	0f 8e 4e 49 00 00    	jle    2971a <JS_CallInternal+0x6c1a>
   24dcc:	48 c7 43 f0 00 00 00 	mov    QWORD PTR [rbx-0x10],0x0
   24dd3:	00 
   24dd4:	49 83 c4 01          	add    r12,0x1
   24dd8:	48 c7 43 f8 01 00 00 	mov    QWORD PTR [rbx-0x8],0x1
   24ddf:	00 
   24de0:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   24de6:	49 89 c5             	mov    r13,rax
   24de9:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   24ded:	ff e0                	jmp    rax
   24def:	f3 0f 1e fa          	endbr64
   24df3:	48 8b 73 f0          	mov    rsi,QWORD PTR [rbx-0x10]
   24df7:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   24dfe:	4c 8d 43 f0          	lea    r8,[rbx-0x10]
   24e02:	49 8b 50 08          	mov    rdx,QWORD PTR [r8+0x8]
   24e06:	e8 b5 6b ff ff       	call   1b9c0 <js_operator_typeof>
   24e0b:	83 f8 49             	cmp    eax,0x49
   24e0e:	75 9f                	jne    24daf <JS_CallInternal+0x22af>
   24e10:	49 8b 50 08          	mov    rdx,QWORD PTR [r8+0x8]
   24e14:	49 8b 30             	mov    rsi,QWORD PTR [r8]
   24e17:	83 fa f6             	cmp    edx,0xfffffff6
   24e1a:	76 11                	jbe    24e2d <JS_CallInternal+0x232d>
   24e1c:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   24e1f:	83 e8 01             	sub    eax,0x1
   24e22:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   24e25:	85 c0                	test   eax,eax
   24e27:	0f 8e 17 69 00 00    	jle    2b744 <JS_CallInternal+0x8c44>
   24e2d:	48 c7 43 f0 01 00 00 	mov    QWORD PTR [rbx-0x10],0x1
   24e34:	00 
   24e35:	49 83 c4 01          	add    r12,0x1
   24e39:	48 c7 43 f8 01 00 00 	mov    QWORD PTR [rbx-0x8],0x1
   24e40:	00 
   24e41:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   24e47:	49 89 c5             	mov    r13,rax
   24e4a:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   24e4e:	ff e0                	jmp    rax
   24e50:	f3 0f 1e fa          	endbr64
   24e54:	31 c9                	xor    ecx,ecx
   24e56:	b8 03 00 00 00       	mov    eax,0x3
   24e5b:	e9 c0 e4 ff ff       	jmp    23320 <JS_CallInternal+0x820>
   24e60:	f3 0f 1e fa          	endbr64
   24e64:	b9 03 00 00 00       	mov    ecx,0x3
   24e69:	31 c0                	xor    eax,eax
   24e6b:	e9 b0 e4 ff ff       	jmp    23320 <JS_CallInternal+0x820>
   24e70:	f3 0f 1e fa          	endbr64
   24e74:	83 7b f8 02          	cmp    DWORD PTR [rbx-0x8],0x2
   24e78:	74 b3                	je     24e2d <JS_CallInternal+0x232d>
   24e7a:	4c 8d 43 f0          	lea    r8,[rbx-0x10]
   24e7e:	e9 2c ff ff ff       	jmp    24daf <JS_CallInternal+0x22af>
   24e83:	f3 0f 1e fa          	endbr64
   24e87:	83 7b f8 03          	cmp    DWORD PTR [rbx-0x8],0x3
   24e8b:	75 ed                	jne    24e7a <JS_CallInternal+0x237a>
   24e8d:	eb 9e                	jmp    24e2d <JS_CallInternal+0x232d>
   24e8f:	f3 0f 1e fa          	endbr64
   24e93:	8b 43 f8             	mov    eax,DWORD PTR [rbx-0x8]
   24e96:	83 e8 02             	sub    eax,0x2
   24e99:	83 f8 01             	cmp    eax,0x1
   24e9c:	77 dc                	ja     24e7a <JS_CallInternal+0x237a>
   24e9e:	eb 8d                	jmp    24e2d <JS_CallInternal+0x232d>
   24ea0:	f3 0f 1e fa          	endbr64
   24ea4:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   24ea9:	49 83 c4 01          	add    r12,0x1
   24ead:	49 89 c5             	mov    r13,rax
   24eb0:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   24eb4:	ff e0                	jmp    rax
   24eb6:	f3 0f 1e fa          	endbr64
   24eba:	31 c9                	xor    ecx,ecx
   24ebc:	b8 01 00 00 00       	mov    eax,0x1
   24ec1:	e9 5a e4 ff ff       	jmp    23320 <JS_CallInternal+0x820>
   24ec6:	f3 0f 1e fa          	endbr64
   24eca:	31 c9                	xor    ecx,ecx
   24ecc:	31 c0                	xor    eax,eax
   24ece:	e9 4d e4 ff ff       	jmp    23320 <JS_CallInternal+0x820>
   24ed3:	f3 0f 1e fa          	endbr64
   24ed7:	e9 44 df ff ff       	jmp    22e20 <JS_CallInternal+0x320>
   24edc:	f3 0f 1e fa          	endbr64
   24ee0:	e9 3b df ff ff       	jmp    22e20 <JS_CallInternal+0x320>
   24ee5:	f3 0f 1e fa          	endbr64
   24ee9:	e9 32 df ff ff       	jmp    22e20 <JS_CallInternal+0x320>
   24eee:	f3 0f 1e fa          	endbr64
   24ef2:	48 8b 43 f8          	mov    rax,QWORD PTR [rbx-0x8]
   24ef6:	83 f8 fa             	cmp    eax,0xfffffffa
   24ef9:	0f 8d 45 46 00 00    	jge    29544 <JS_CallInternal+0x6a44>
   24eff:	83 f8 f8             	cmp    eax,0xfffffff8
   24f02:	0f 8c 44 46 00 00    	jl     2954c <JS_CallInternal+0x6a4c>
   24f08:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   24f0d:	49 83 c4 01          	add    r12,0x1
   24f11:	49 89 c5             	mov    r13,rax
   24f14:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   24f18:	ff e0                	jmp    rax
   24f1a:	f3 0f 1e fa          	endbr64
   24f1e:	83 7b f8 ff          	cmp    DWORD PTR [rbx-0x8],0xffffffff
   24f22:	74 54                	je     24f78 <JS_CallInternal+0x2478>
   24f24:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   24f2b:	48 8b 73 f0          	mov    rsi,QWORD PTR [rbx-0x10]
   24f2f:	48 8b 53 f8          	mov    rdx,QWORD PTR [rbx-0x8]
   24f33:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   24f3a:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   24f3e:	e8 3d 57 02 00       	call   4a680 <JS_ToObject>
   24f43:	49 89 c1             	mov    r9,rax
   24f46:	49 89 d0             	mov    r8,rdx
   24f49:	83 fa 06             	cmp    edx,0x6
   24f4c:	0f 84 4e e3 ff ff    	je     232a0 <JS_CallInternal+0x7a0>
   24f52:	48 8b 53 f8          	mov    rdx,QWORD PTR [rbx-0x8]
   24f56:	48 8b 73 f0          	mov    rsi,QWORD PTR [rbx-0x10]
   24f5a:	83 fa f6             	cmp    edx,0xfffffff6
   24f5d:	76 11                	jbe    24f70 <JS_CallInternal+0x2470>
   24f5f:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   24f62:	83 e8 01             	sub    eax,0x1
   24f65:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   24f68:	85 c0                	test   eax,eax
   24f6a:	0f 8e e2 70 00 00    	jle    2c052 <JS_CallInternal+0x9552>
   24f70:	4c 89 4b f0          	mov    QWORD PTR [rbx-0x10],r9
   24f74:	4c 89 43 f8          	mov    QWORD PTR [rbx-0x8],r8
   24f78:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   24f7d:	49 83 c4 01          	add    r12,0x1
   24f81:	49 89 c5             	mov    r13,rax
   24f84:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   24f88:	ff e0                	jmp    rax
   24f8a:	f3 0f 1e fa          	endbr64
   24f8e:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   24f95:	4d 8d 6c 24 04       	lea    r13,[r12+0x4]
   24f9a:	45 8b 34 24          	mov    r14d,DWORD PTR [r12]
   24f9e:	4c 89 68 30          	mov    QWORD PTR [rax+0x30],r13
   24fa2:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   24fa9:	44 89 f1             	mov    ecx,r14d
   24fac:	48 8b 80 90 01 00 00 	mov    rax,QWORD PTR [rax+0x190]
   24fb3:	48 8b 50 18          	mov    rdx,QWORD PTR [rax+0x18]
   24fb7:	8b 42 18             	mov    eax,DWORD PTR [rdx+0x18]
   24fba:	21 c1                	and    ecx,eax
   24fbc:	8b 4c 8a 38          	mov    ecx,DWORD PTR [rdx+rcx*4+0x38]
   24fc0:	48 85 c9             	test   rcx,rcx
   24fc3:	0f 84 f6 4e 00 00    	je     29ebf <JS_CallInternal+0x73bf>
   24fc9:	48 8d 34 85 34 00 00 	lea    rsi,[rax*4+0x34]
   24fd0:	00 
   24fd1:	48 8d 04 ce          	lea    rax,[rsi+rcx*8]
   24fd5:	48 01 d0             	add    rax,rdx
   24fd8:	44 3b 70 04          	cmp    r14d,DWORD PTR [rax+0x4]
   24fdc:	0f 85 cf 4e 00 00    	jne    29eb1 <JS_CallInternal+0x73b1>
   24fe2:	31 c0                	xor    eax,eax
   24fe4:	48 89 03             	mov    QWORD PTR [rbx],rax
   24fe7:	49 83 c4 05          	add    r12,0x5
   24feb:	48 83 c3 10          	add    rbx,0x10
   24fef:	48 c7 43 f8 01 00 00 	mov    QWORD PTR [rbx-0x8],0x1
   24ff6:	00 
   24ff7:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   24ffd:	49 89 c5             	mov    r13,rax
   25000:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   25004:	ff e0                	jmp    rax
   25006:	f3 0f 1e fa          	endbr64
   2500a:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   25011:	4c 8b 6b f0          	mov    r13,QWORD PTR [rbx-0x10]
   25015:	4c 8b 73 f8          	mov    r14,QWORD PTR [rbx-0x8]
   25019:	48 8b 4b e8          	mov    rcx,QWORD PTR [rbx-0x18]
   2501d:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   25021:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   25028:	4c 89 ee             	mov    rsi,r13
   2502b:	48 8b 43 e0          	mov    rax,QWORD PTR [rbx-0x20]
   2502f:	4c 89 f2             	mov    rdx,r14
   25032:	48 89 8d 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],rcx
   25039:	48 89 85 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],rax
   25040:	e8 cb e4 01 00       	call   43510 <JS_ValueToAtom>
   25045:	89 c1                	mov    ecx,eax
   25047:	85 c0                	test   eax,eax
   25049:	0f 84 51 e2 ff ff    	je     232a0 <JS_CallInternal+0x7a0>
   2504f:	48 8b b5 40 fe ff ff 	mov    rsi,QWORD PTR [rbp-0x1c0]
   25056:	48 8b 95 50 fe ff ff 	mov    rdx,QWORD PTR [rbp-0x1b0]
   2505d:	41 b8 00 80 00 00    	mov    r8d,0x8000
   25063:	89 85 38 fe ff ff    	mov    DWORD PTR [rbp-0x1c8],eax
   25069:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   25070:	e8 4b 58 02 00       	call   4a8c0 <JS_DeleteProperty>
   25075:	8b 8d 38 fe ff ff    	mov    ecx,DWORD PTR [rbp-0x1c8]
   2507b:	41 89 c0             	mov    r8d,eax
   2507e:	81 f9 f2 00 00 00    	cmp    ecx,0xf2
   25084:	0f 8f d6 4e 00 00    	jg     29f60 <JS_CallInternal+0x7460>
   2508a:	45 85 c0             	test   r8d,r8d
   2508d:	0f 88 0d e2 ff ff    	js     232a0 <JS_CallInternal+0x7a0>
   25093:	83 bd 50 fe ff ff f6 	cmp    DWORD PTR [rbp-0x1b0],0xfffffff6
   2509a:	76 1e                	jbe    250ba <JS_CallInternal+0x25ba>
   2509c:	48 8b 8d 40 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x1c0]
   250a3:	8b 41 fc             	mov    eax,DWORD PTR [rcx-0x4]
   250a6:	89 85 38 fe ff ff    	mov    DWORD PTR [rbp-0x1c8],eax
   250ac:	83 e8 01             	sub    eax,0x1
   250af:	89 41 fc             	mov    DWORD PTR [rcx-0x4],eax
   250b2:	85 c0                	test   eax,eax
   250b4:	0f 8e 51 61 00 00    	jle    2b20b <JS_CallInternal+0x870b>
   250ba:	41 83 fe f6          	cmp    r14d,0xfffffff6
   250be:	76 13                	jbe    250d3 <JS_CallInternal+0x25d3>
   250c0:	41 8b 45 fc          	mov    eax,DWORD PTR [r13-0x4]
   250c4:	83 e8 01             	sub    eax,0x1
   250c7:	41 89 45 fc          	mov    DWORD PTR [r13-0x4],eax
   250cb:	85 c0                	test   eax,eax
   250cd:	0f 8e 0f 61 00 00    	jle    2b1e2 <JS_CallInternal+0x86e2>
   250d3:	31 c0                	xor    eax,eax
   250d5:	45 85 c0             	test   r8d,r8d
   250d8:	48 c7 43 e8 01 00 00 	mov    QWORD PTR [rbx-0x18],0x1
   250df:	00 
   250e0:	0f 95 c0             	setne  al
   250e3:	48 83 eb 10          	sub    rbx,0x10
   250e7:	49 83 c4 01          	add    r12,0x1
   250eb:	48 89 43 f0          	mov    QWORD PTR [rbx-0x10],rax
   250ef:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   250f5:	49 89 c5             	mov    r13,rax
   250f8:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   250fc:	ff e0                	jmp    rax
   250fe:	f3 0f 1e fa          	endbr64
   25102:	48 8b 43 d8          	mov    rax,QWORD PTR [rbx-0x28]
   25106:	48 8b 53 d0          	mov    rdx,QWORD PTR [rbx-0x30]
   2510a:	83 f8 f6             	cmp    eax,0xfffffff6
   2510d:	76 04                	jbe    25113 <JS_CallInternal+0x2613>
   2510f:	83 42 fc 01          	add    DWORD PTR [rdx-0x4],0x1
   25113:	48 89 43 08          	mov    QWORD PTR [rbx+0x8],rax
   25117:	48 8b 43 e8          	mov    rax,QWORD PTR [rbx-0x18]
   2511b:	48 89 13             	mov    QWORD PTR [rbx],rdx
   2511e:	48 8b 53 e0          	mov    rdx,QWORD PTR [rbx-0x20]
   25122:	83 f8 f6             	cmp    eax,0xfffffff6
   25125:	76 04                	jbe    2512b <JS_CallInternal+0x262b>
   25127:	83 42 fc 01          	add    DWORD PTR [rdx-0x4],0x1
   2512b:	48 89 43 18          	mov    QWORD PTR [rbx+0x18],rax
   2512f:	48 8b 43 f8          	mov    rax,QWORD PTR [rbx-0x8]
   25133:	48 89 53 10          	mov    QWORD PTR [rbx+0x10],rdx
   25137:	48 8b 53 f0          	mov    rdx,QWORD PTR [rbx-0x10]
   2513b:	83 f8 f6             	cmp    eax,0xfffffff6
   2513e:	76 04                	jbe    25144 <JS_CallInternal+0x2644>
   25140:	83 42 fc 01          	add    DWORD PTR [rdx-0x4],0x1
   25144:	48 89 53 20          	mov    QWORD PTR [rbx+0x20],rdx
   25148:	49 83 c4 01          	add    r12,0x1
   2514c:	48 83 c3 30          	add    rbx,0x30
   25150:	48 89 43 f8          	mov    QWORD PTR [rbx-0x8],rax
   25154:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   2515a:	49 89 c5             	mov    r13,rax
   2515d:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   25161:	ff e0                	jmp    rax
   25163:	f3 0f 1e fa          	endbr64
   25167:	48 8b 43 e8          	mov    rax,QWORD PTR [rbx-0x18]
   2516b:	48 8b 53 e0          	mov    rdx,QWORD PTR [rbx-0x20]
   2516f:	83 f8 f6             	cmp    eax,0xfffffff6
   25172:	76 04                	jbe    25178 <JS_CallInternal+0x2678>
   25174:	83 42 fc 01          	add    DWORD PTR [rdx-0x4],0x1
   25178:	48 89 43 08          	mov    QWORD PTR [rbx+0x8],rax
   2517c:	48 8b 43 f8          	mov    rax,QWORD PTR [rbx-0x8]
   25180:	48 89 13             	mov    QWORD PTR [rbx],rdx
   25183:	48 8b 53 f0          	mov    rdx,QWORD PTR [rbx-0x10]
   25187:	83 f8 f6             	cmp    eax,0xfffffff6
   2518a:	76 04                	jbe    25190 <JS_CallInternal+0x2690>
   2518c:	83 42 fc 01          	add    DWORD PTR [rdx-0x4],0x1
   25190:	48 89 53 10          	mov    QWORD PTR [rbx+0x10],rdx
   25194:	49 83 c4 01          	add    r12,0x1
   25198:	48 83 c3 20          	add    rbx,0x20
   2519c:	48 89 43 f8          	mov    QWORD PTR [rbx-0x8],rax
   251a0:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   251a6:	49 89 c5             	mov    r13,rax
   251a9:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   251ad:	ff e0                	jmp    rax
   251af:	f3 0f 1e fa          	endbr64
   251b3:	48 8b 43 f8          	mov    rax,QWORD PTR [rbx-0x8]
   251b7:	48 8b 53 f0          	mov    rdx,QWORD PTR [rbx-0x10]
   251bb:	83 f8 f6             	cmp    eax,0xfffffff6
   251be:	76 04                	jbe    251c4 <JS_CallInternal+0x26c4>
   251c0:	83 42 fc 01          	add    DWORD PTR [rdx-0x4],0x1
   251c4:	48 89 13             	mov    QWORD PTR [rbx],rdx
   251c7:	49 83 c4 01          	add    r12,0x1
   251cb:	48 83 c3 10          	add    rbx,0x10
   251cf:	48 89 43 f8          	mov    QWORD PTR [rbx-0x8],rax
   251d3:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   251d9:	49 89 c5             	mov    r13,rax
   251dc:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   251e0:	ff e0                	jmp    rax
   251e2:	f3 0f 1e fa          	endbr64
   251e6:	48 8b 53 d8          	mov    rdx,QWORD PTR [rbx-0x28]
   251ea:	48 8b 73 d0          	mov    rsi,QWORD PTR [rbx-0x30]
   251ee:	83 fa f6             	cmp    edx,0xfffffff6
   251f1:	76 11                	jbe    25204 <JS_CallInternal+0x2704>
   251f3:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   251f6:	83 e8 01             	sub    eax,0x1
   251f9:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   251fc:	85 c0                	test   eax,eax
   251fe:	0f 8e ac 53 00 00    	jle    2a5b0 <JS_CallInternal+0x7ab0>
   25204:	f3 0f 6f 73 e0       	movdqu xmm6,XMMWORD PTR [rbx-0x20]
   25209:	f3 0f 6f 7b f0       	movdqu xmm7,XMMWORD PTR [rbx-0x10]
   2520e:	49 83 c4 01          	add    r12,0x1
   25212:	48 83 eb 10          	sub    rbx,0x10
   25216:	0f 11 73 e0          	movups XMMWORD PTR [rbx-0x20],xmm6
   2521a:	0f 11 7b f0          	movups XMMWORD PTR [rbx-0x10],xmm7
   2521e:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   25224:	49 89 c5             	mov    r13,rax
   25227:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   2522b:	ff e0                	jmp    rax
   2522d:	f3 0f 1e fa          	endbr64
   25231:	48 8b 53 e8          	mov    rdx,QWORD PTR [rbx-0x18]
   25235:	48 8b 73 e0          	mov    rsi,QWORD PTR [rbx-0x20]
   25239:	83 fa f6             	cmp    edx,0xfffffff6
   2523c:	76 11                	jbe    2524f <JS_CallInternal+0x274f>
   2523e:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   25241:	83 e8 01             	sub    eax,0x1
   25244:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   25247:	85 c0                	test   eax,eax
   25249:	0f 8e 4c 53 00 00    	jle    2a59b <JS_CallInternal+0x7a9b>
   2524f:	f3 0f 6f 6b f0       	movdqu xmm5,XMMWORD PTR [rbx-0x10]
   25254:	49 83 c4 01          	add    r12,0x1
   25258:	48 83 eb 10          	sub    rbx,0x10
   2525c:	0f 11 6b f0          	movups XMMWORD PTR [rbx-0x10],xmm5
   25260:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   25266:	49 89 c5             	mov    r13,rax
   25269:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   2526d:	ff e0                	jmp    rax
   2526f:	f3 0f 1e fa          	endbr64
   25273:	48 8b 53 f8          	mov    rdx,QWORD PTR [rbx-0x8]
   25277:	48 83 eb 10          	sub    rbx,0x10
   2527b:	48 8b 33             	mov    rsi,QWORD PTR [rbx]
   2527e:	83 fa f6             	cmp    edx,0xfffffff6
   25281:	76 11                	jbe    25294 <JS_CallInternal+0x2794>
   25283:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   25286:	83 e8 01             	sub    eax,0x1
   25289:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   2528c:	85 c0                	test   eax,eax
   2528e:	0f 8e 31 53 00 00    	jle    2a5c5 <JS_CallInternal+0x7ac5>
   25294:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   25299:	49 83 c4 01          	add    r12,0x1
   2529d:	49 89 c5             	mov    r13,rax
   252a0:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   252a4:	ff e0                	jmp    rax
   252a6:	f3 0f 1e fa          	endbr64
   252aa:	8b 8d bc fe ff ff    	mov    ecx,DWORD PTR [rbp-0x144]
   252b0:	41 0f b7 04 24       	movzx  eax,WORD PTR [r12]
   252b5:	4d 8d 6c 24 02       	lea    r13,[r12+0x2]
   252ba:	4c 8d 73 10          	lea    r14,[rbx+0x10]
   252be:	48 8b bd a8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x158]
   252c5:	39 c8                	cmp    eax,ecx
   252c7:	0f 4f c1             	cmovg  eax,ecx
   252ca:	48 63 d0             	movsxd rdx,eax
   252cd:	29 c1                	sub    ecx,eax
   252cf:	48 c1 e2 04          	shl    rdx,0x4
   252d3:	89 ce                	mov    esi,ecx
   252d5:	48 01 fa             	add    rdx,rdi
   252d8:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   252df:	e8 ec 73 02 00       	call   4c6d0 <js_create_array>
   252e4:	48 89 53 08          	mov    QWORD PTR [rbx+0x8],rdx
   252e8:	83 7b 08 06          	cmp    DWORD PTR [rbx+0x8],0x6
   252ec:	48 89 03             	mov    QWORD PTR [rbx],rax
   252ef:	0f 84 0b 65 00 00    	je     2b800 <JS_CallInternal+0x8d00>
   252f5:	41 0f b6 44 24 02    	movzx  eax,BYTE PTR [r12+0x2]
   252fb:	4c 89 f3             	mov    rbx,r14
   252fe:	49 83 c4 03          	add    r12,0x3
   25302:	49 89 c5             	mov    r13,rax
   25305:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   25309:	ff e0                	jmp    rax
   2530b:	f3 0f 1e fa          	endbr64
   2530f:	41 80 3c 24 06       	cmp    BYTE PTR [r12],0x6
   25314:	4d 8d 74 24 01       	lea    r14,[r12+0x1]
   25319:	0f 87 a5 cc fe ff    	ja     11fc4 <JS_CallInternal.cold>
   2531f:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   25324:	48 8d 15 0d 1e 0b 00 	lea    rdx,[rip+0xb1e0d]        # d7138 <qjsc_repl_size+0x46c>
   2532b:	48 63 04 82          	movsxd rax,DWORD PTR [rdx+rax*4]
   2532f:	48 01 d0             	add    rax,rdx
   25332:	3e ff e0             	notrack jmp rax
   25335:	31 f6                	xor    esi,esi
   25337:	b9 01 00 00 00       	mov    ecx,0x1
   2533c:	4c 8d 6b 10          	lea    r13,[rbx+0x10]
   25340:	ba 02 00 00 00       	mov    edx,0x2
   25345:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2534c:	e8 7f 36 02 00       	call   489d0 <JS_NewObjectProtoClass>
   25351:	48 89 53 08          	mov    QWORD PTR [rbx+0x8],rdx
   25355:	83 7b 08 06          	cmp    DWORD PTR [rbx+0x8],0x6
   25359:	48 89 03             	mov    QWORD PTR [rbx],rax
   2535c:	0f 84 e9 00 00 00    	je     2544b <JS_CallInternal+0x294b>
   25362:	4c 89 eb             	mov    rbx,r13
   25365:	41 0f b6 44 24 01    	movzx  eax,BYTE PTR [r12+0x1]
   2536b:	49 83 c4 02          	add    r12,0x2
   2536f:	49 89 c5             	mov    r13,rax
   25372:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   25376:	ff e0                	jmp    rax
   25378:	48 8b 85 60 fe ff ff 	mov    rax,QWORD PTR [rbp-0x1a0]
   2537f:	48 8d 53 10          	lea    rdx,[rbx+0x10]
   25383:	48 8b 40 38          	mov    rax,QWORD PTR [rax+0x38]
   25387:	48 85 c0             	test   rax,rax
   2538a:	0f 84 6d 74 00 00    	je     2c7fd <JS_CallInternal+0x9cfd>
   25390:	83 40 fc 01          	add    DWORD PTR [rax-0x4],0x1
   25394:	48 89 03             	mov    QWORD PTR [rbx],rax
   25397:	48 c7 43 08 ff ff ff 	mov    QWORD PTR [rbx+0x8],0xffffffffffffffff
   2539e:	ff 
   2539f:	48 89 d3             	mov    rbx,rdx
   253a2:	eb c1                	jmp    25365 <JS_CallInternal+0x2865>
   253a4:	83 bd 80 fe ff ff f6 	cmp    DWORD PTR [rbp-0x180],0xfffffff6
   253ab:	48 8d 43 10          	lea    rax,[rbx+0x10]
   253af:	76 0b                	jbe    253bc <JS_CallInternal+0x28bc>
   253b1:	48 8b 8d 70 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x190]
   253b8:	83 41 fc 01          	add    DWORD PTR [rcx-0x4],0x1
   253bc:	48 8b 8d 70 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x190]
   253c3:	48 89 0b             	mov    QWORD PTR [rbx],rcx
   253c6:	48 8b 8d 80 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x180]
   253cd:	48 89 4b 08          	mov    QWORD PTR [rbx+0x8],rcx
   253d1:	48 89 c3             	mov    rbx,rax
   253d4:	eb 8f                	jmp    25365 <JS_CallInternal+0x2865>
   253d6:	48 8b bd c8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x138]
   253dd:	48 8d 4b 10          	lea    rcx,[rbx+0x10]
   253e1:	48 8b 57 10          	mov    rdx,QWORD PTR [rdi+0x10]
   253e5:	48 8b 47 08          	mov    rax,QWORD PTR [rdi+0x8]
   253e9:	83 fa f6             	cmp    edx,0xfffffff6
   253ec:	76 04                	jbe    253f2 <JS_CallInternal+0x28f2>
   253ee:	83 40 fc 01          	add    DWORD PTR [rax-0x4],0x1
   253f2:	48 89 03             	mov    QWORD PTR [rbx],rax
   253f5:	48 89 53 08          	mov    QWORD PTR [rbx+0x8],rdx
   253f9:	48 89 cb             	mov    rbx,rcx
   253fc:	e9 64 ff ff ff       	jmp    25365 <JS_CallInternal+0x2865>
   25401:	48 8b 85 d8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x128]
   25408:	48 8b 8d c8 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x138]
   2540f:	4c 8d 6b 10          	lea    r13,[rbx+0x10]
   25413:	48 8b 95 a8 fe ff ff 	mov    rdx,QWORD PTR [rbp-0x158]
   2541a:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   25421:	44 0f b7 40 38       	movzx  r8d,WORD PTR [rax+0x38]
   25426:	8b 85 bc fe ff ff    	mov    eax,DWORD PTR [rbp-0x144]
   2542c:	41 39 c0             	cmp    r8d,eax
   2542f:	89 c6                	mov    esi,eax
   25431:	44 0f 4f c0          	cmovg  r8d,eax
   25435:	e8 e6 30 02 00       	call   48520 <js_build_mapped_arguments>
   2543a:	48 89 53 08          	mov    QWORD PTR [rbx+0x8],rdx
   2543e:	83 7b 08 06          	cmp    DWORD PTR [rbx+0x8],0x6
   25442:	48 89 03             	mov    QWORD PTR [rbx],rax
   25445:	0f 85 17 ff ff ff    	jne    25362 <JS_CallInternal+0x2862>
   2544b:	4c 89 eb             	mov    rbx,r13
   2544e:	4d 89 f4             	mov    r12,r14
   25451:	e9 4a de ff ff       	jmp    232a0 <JS_CallInternal+0x7a0>
   25456:	48 8b 8d e8 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x118]
   2545d:	8b 85 bc fe ff ff    	mov    eax,DWORD PTR [rbp-0x144]
   25463:	4c 8d 6b 10          	lea    r13,[rbx+0x10]
   25467:	48 c7 85 58 ff ff ff 	mov    QWORD PTR [rbp-0xa8],0x0
   2546e:	00 00 00 00 
   25472:	48 8b 91 58 01 00 00 	mov    rdx,QWORD PTR [rcx+0x158]
   25479:	48 89 85 50 ff ff ff 	mov    QWORD PTR [rbp-0xb0],rax
   25480:	48 8b 81 50 01 00 00 	mov    rax,QWORD PTR [rcx+0x150]
   25487:	83 fa f6             	cmp    edx,0xfffffff6
   2548a:	76 04                	jbe    25490 <JS_CallInternal+0x2990>
   2548c:	83 40 fc 01          	add    DWORD PTR [rax-0x4],0x1
   25490:	48 8b 8d e8 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x118]
   25497:	48 89 85 60 ff ff ff 	mov    QWORD PTR [rbp-0xa0],rax
   2549e:	48 89 95 68 ff ff ff 	mov    QWORD PTR [rbp-0x98],rdx
   254a5:	48 8b 81 60 01 00 00 	mov    rax,QWORD PTR [rcx+0x160]
   254ac:	83 b9 68 01 00 00 f6 	cmp    DWORD PTR [rcx+0x168],0xfffffff6
   254b3:	48 89 85 70 ff ff ff 	mov    QWORD PTR [rbp-0x90],rax
   254ba:	76 04                	jbe    254c0 <JS_CallInternal+0x29c0>
   254bc:	83 40 fc 02          	add    DWORD PTR [rax-0x4],0x2
   254c0:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   254c7:	48 8d 8d 50 ff ff ff 	lea    rcx,[rbp-0xb0]
   254ce:	ba 08 00 00 00       	mov    edx,0x8
   254d3:	48 89 85 78 ff ff ff 	mov    QWORD PTR [rbp-0x88],rax
   254da:	48 8b 77 38          	mov    rsi,QWORD PTR [rdi+0x38]
   254de:	83 46 fc 01          	add    DWORD PTR [rsi-0x4],0x1
   254e2:	e8 e9 2b 02 00       	call   480d0 <JS_NewObjectFromShape>
   254e7:	49 89 c1             	mov    r9,rax
   254ea:	48 89 d1             	mov    rcx,rdx
   254ed:	83 fa 06             	cmp    edx,0x6
   254f0:	0f 84 19 73 00 00    	je     2c80f <JS_CallInternal+0x9d0f>
   254f6:	8b bd bc fe ff ff    	mov    edi,DWORD PTR [rbp-0x144]
   254fc:	31 c0                	xor    eax,eax
   254fe:	85 ff                	test   edi,edi
   25500:	0f 8f 3b 6a 00 00    	jg     2bf41 <JS_CallInternal+0x9441>
   25506:	49 89 41 30          	mov    QWORD PTR [r9+0x30],rax
   2550a:	8b 85 bc fe ff ff    	mov    eax,DWORD PTR [rbp-0x144]
   25510:	41 89 41 38          	mov    DWORD PTR [r9+0x38],eax
   25514:	4c 89 0b             	mov    QWORD PTR [rbx],r9
   25517:	48 89 4b 08          	mov    QWORD PTR [rbx+0x8],rcx
   2551b:	4c 89 eb             	mov    rbx,r13
   2551e:	e9 42 fe ff ff       	jmp    25365 <JS_CallInternal+0x2865>
   25523:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2552a:	31 f6                	xor    esi,esi
   2552c:	4c 8d 6b 10          	lea    r13,[rbx+0x10]
   25530:	e8 7b d4 ff ff       	call   229b0 <JS_GetScriptOrModuleName>
   25535:	85 c0                	test   eax,eax
   25537:	0f 84 88 67 00 00    	je     2bcc5 <JS_CallInternal+0x91c5>
   2553d:	48 8b 8d e8 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x118]
   25544:	48 8b 91 b8 01 00 00 	mov    rdx,QWORD PTR [rcx+0x1b8]
   2554b:	48 81 c1 b0 01 00 00 	add    rcx,0x1b0
   25552:	48 39 d1             	cmp    rcx,rdx
   25555:	75 16                	jne    2556d <JS_CallInternal+0x2a6d>
   25557:	e9 cb 75 00 00       	jmp    2cb27 <JS_CallInternal+0xa027>
   2555c:	0f 1f 40 00          	nop    DWORD PTR [rax+0x0]
   25560:	48 8b 52 08          	mov    rdx,QWORD PTR [rdx+0x8]
   25564:	48 39 d1             	cmp    rcx,rdx
   25567:	0f 84 0e 67 00 00    	je     2bc7b <JS_CallInternal+0x917b>
   2556d:	3b 42 f8             	cmp    eax,DWORD PTR [rdx-0x8]
   25570:	75 ee                	jne    25560 <JS_CallInternal+0x2a60>
   25572:	48 83 ea 18          	sub    rdx,0x18
   25576:	3d f2 00 00 00       	cmp    eax,0xf2
   2557b:	0f 8f 03 67 00 00    	jg     2bc84 <JS_CallInternal+0x9184>
   25581:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   25588:	48 89 d6             	mov    rsi,rdx
   2558b:	e8 f0 d4 ff ff       	call   22a80 <JS_GetImportMeta>
   25590:	48 89 03             	mov    QWORD PTR [rbx],rax
   25593:	48 89 53 08          	mov    QWORD PTR [rbx+0x8],rdx
   25597:	83 fa 06             	cmp    edx,0x6
   2559a:	0f 85 c2 fd ff ff    	jne    25362 <JS_CallInternal+0x2862>
   255a0:	e9 a6 fe ff ff       	jmp    2544b <JS_CallInternal+0x294b>
   255a5:	0f 1f 00             	nop    DWORD PTR [rax]
   255a8:	f3 0f 1e fa          	endbr64
   255ac:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   255b3:	b9 01 00 00 00       	mov    ecx,0x1
   255b8:	4c 8d 73 10          	lea    r14,[rbx+0x10]
   255bc:	48 8b 47 58          	mov    rax,QWORD PTR [rdi+0x58]
   255c0:	48 8b 70 10          	mov    rsi,QWORD PTR [rax+0x10]
   255c4:	48 8b 50 18          	mov    rdx,QWORD PTR [rax+0x18]
   255c8:	e8 03 34 02 00       	call   489d0 <JS_NewObjectProtoClass>
   255cd:	48 89 53 08          	mov    QWORD PTR [rbx+0x8],rdx
   255d1:	83 7b 08 06          	cmp    DWORD PTR [rbx+0x8],0x6
   255d5:	48 89 03             	mov    QWORD PTR [rbx],rax
   255d8:	0f 84 0c 58 00 00    	je     2adea <JS_CallInternal+0x82ea>
   255de:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   255e3:	4c 89 f3             	mov    rbx,r14
   255e6:	49 83 c4 01          	add    r12,0x1
   255ea:	49 89 c5             	mov    r13,rax
   255ed:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   255f1:	ff e0                	jmp    rax
   255f3:	f3 0f 1e fa          	endbr64
   255f7:	48 c7 03 01 00 00 00 	mov    QWORD PTR [rbx],0x1
   255fe:	49 83 c4 01          	add    r12,0x1
   25602:	48 83 c3 10          	add    rbx,0x10
   25606:	48 c7 43 f8 01 00 00 	mov    QWORD PTR [rbx-0x8],0x1
   2560d:	00 
   2560e:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   25614:	49 89 c5             	mov    r13,rax
   25617:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   2561b:	ff e0                	jmp    rax
   2561d:	f3 0f 1e fa          	endbr64
   25621:	48 c7 03 00 00 00 00 	mov    QWORD PTR [rbx],0x0
   25628:	49 83 c4 01          	add    r12,0x1
   2562c:	48 83 c3 10          	add    rbx,0x10
   25630:	48 c7 43 f8 01 00 00 	mov    QWORD PTR [rbx-0x8],0x1
   25637:	00 
   25638:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   2563e:	49 89 c5             	mov    r13,rax
   25641:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   25645:	ff e0                	jmp    rax
   25647:	f3 0f 1e fa          	endbr64
   2564b:	48 8b 85 d8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x128]
   25652:	f6 40 10 01          	test   BYTE PTR [rax+0x10],0x1
   25656:	0f 85 76 3f 00 00    	jne    295d2 <JS_CallInternal+0x6ad2>
   2565c:	83 bd 88 fe ff ff ff 	cmp    DWORD PTR [rbp-0x178],0xffffffff
   25663:	0f 85 9b 69 00 00    	jne    2c004 <JS_CallInternal+0x9504>
   25669:	48 8b 85 78 fe ff ff 	mov    rax,QWORD PTR [rbp-0x188]
   25670:	83 40 fc 01          	add    DWORD PTR [rax-0x4],0x1
   25674:	48 8b 85 88 fe ff ff 	mov    rax,QWORD PTR [rbp-0x178]
   2567b:	48 8b 8d 78 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x188]
   25682:	48 89 0b             	mov    QWORD PTR [rbx],rcx
   25685:	49 83 c4 01          	add    r12,0x1
   25689:	48 83 c3 10          	add    rbx,0x10
   2568d:	48 89 43 f8          	mov    QWORD PTR [rbx-0x8],rax
   25691:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   25697:	49 89 c5             	mov    r13,rax
   2569a:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   2569e:	ff e0                	jmp    rax
   256a0:	f3 0f 1e fa          	endbr64
   256a4:	48 8b 73 e0          	mov    rsi,QWORD PTR [rbx-0x20]
   256a8:	48 8b 7b e8          	mov    rdi,QWORD PTR [rbx-0x18]
   256ac:	48 8b 4b f0          	mov    rcx,QWORD PTR [rbx-0x10]
   256b0:	4c 8b 43 f8          	mov    r8,QWORD PTR [rbx-0x8]
   256b4:	49 89 f5             	mov    r13,rsi
   256b7:	49 89 fe             	mov    r14,rdi
   256ba:	83 ff ff             	cmp    edi,0xffffffff
   256bd:	0f 85 dd 42 00 00    	jne    299a0 <JS_CallInternal+0x6ea0>
   256c3:	45 85 c0             	test   r8d,r8d
   256c6:	0f 85 d4 42 00 00    	jne    299a0 <JS_CallInternal+0x6ea0>
   256cc:	66 83 7e 12 02       	cmp    WORD PTR [rsi+0x12],0x2
   256d1:	0f 85 c9 42 00 00    	jne    299a0 <JS_CallInternal+0x6ea0>
   256d7:	3b 4e 38             	cmp    ecx,DWORD PTR [rsi+0x38]
   256da:	0f 83 c0 42 00 00    	jae    299a0 <JS_CallInternal+0x6ea0>
   256e0:	89 c8                	mov    eax,ecx
   256e2:	48 c1 e0 04          	shl    rax,0x4
   256e6:	48 03 46 30          	add    rax,QWORD PTR [rsi+0x30]
   256ea:	48 8b 08             	mov    rcx,QWORD PTR [rax]
   256ed:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
   256f1:	83 f8 f6             	cmp    eax,0xfffffff6
   256f4:	76 04                	jbe    256fa <JS_CallInternal+0x2bfa>
   256f6:	83 41 fc 01          	add    DWORD PTR [rcx-0x4],0x1
   256fa:	41 83 fe f6          	cmp    r14d,0xfffffff6
   256fe:	76 13                	jbe    25713 <JS_CallInternal+0x2c13>
   25700:	41 8b 7d fc          	mov    edi,DWORD PTR [r13-0x4]
   25704:	8d 57 ff             	lea    edx,[rdi-0x1]
   25707:	41 89 55 fc          	mov    DWORD PTR [r13-0x4],edx
   2570b:	85 d2                	test   edx,edx
   2570d:	0f 8e e8 53 00 00    	jle    2aafb <JS_CallInternal+0x7ffb>
   25713:	48 89 4b e0          	mov    QWORD PTR [rbx-0x20],rcx
   25717:	49 83 c4 01          	add    r12,0x1
   2571b:	48 83 eb 10          	sub    rbx,0x10
   2571f:	48 89 43 f8          	mov    QWORD PTR [rbx-0x8],rax
   25723:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   25729:	49 89 c5             	mov    r13,rax
   2572c:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   25730:	ff e0                	jmp    rax
   25732:	f3 0f 1e fa          	endbr64
   25736:	48 8b 85 98 fe ff ff 	mov    rax,QWORD PTR [rbp-0x168]
   2573d:	f3 0f 6f 73 f0       	movdqu xmm6,XMMWORD PTR [rbx-0x10]
   25742:	48 83 eb 10          	sub    rbx,0x10
   25746:	48 8b 00             	mov    rax,QWORD PTR [rax]
   25749:	48 8b 40 18          	mov    rax,QWORD PTR [rax+0x18]
   2574d:	48 8b 50 08          	mov    rdx,QWORD PTR [rax+0x8]
   25751:	48 8b 30             	mov    rsi,QWORD PTR [rax]
   25754:	0f 11 30             	movups XMMWORD PTR [rax],xmm6
   25757:	83 fa f6             	cmp    edx,0xfffffff6
   2575a:	76 11                	jbe    2576d <JS_CallInternal+0x2c6d>
   2575c:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   2575f:	83 e8 01             	sub    eax,0x1
   25762:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   25765:	85 c0                	test   eax,eax
   25767:	0f 8e d1 4d 00 00    	jle    2a53e <JS_CallInternal+0x7a3e>
   2576d:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   25772:	49 83 c4 01          	add    r12,0x1
   25776:	49 89 c5             	mov    r13,rax
   25779:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   2577d:	ff e0                	jmp    rax
   2577f:	f3 0f 1e fa          	endbr64
   25783:	48 8b 85 98 fe ff ff 	mov    rax,QWORD PTR [rbp-0x168]
   2578a:	48 8d 4b 10          	lea    rcx,[rbx+0x10]
   2578e:	48 8b 40 10          	mov    rax,QWORD PTR [rax+0x10]
   25792:	48 8b 40 18          	mov    rax,QWORD PTR [rax+0x18]
   25796:	48 8b 10             	mov    rdx,QWORD PTR [rax]
   25799:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
   2579d:	83 f8 f6             	cmp    eax,0xfffffff6
   257a0:	76 04                	jbe    257a6 <JS_CallInternal+0x2ca6>
   257a2:	83 42 fc 01          	add    DWORD PTR [rdx-0x4],0x1
   257a6:	48 89 13             	mov    QWORD PTR [rbx],rdx
   257a9:	49 83 c4 01          	add    r12,0x1
   257ad:	48 89 43 08          	mov    QWORD PTR [rbx+0x8],rax
   257b1:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   257b7:	48 89 cb             	mov    rbx,rcx
   257ba:	49 89 c5             	mov    r13,rax
   257bd:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   257c1:	ff e0                	jmp    rax
   257c3:	f3 0f 1e fa          	endbr64
   257c7:	48 8b 85 98 fe ff ff 	mov    rax,QWORD PTR [rbp-0x168]
   257ce:	48 8d 4b 10          	lea    rcx,[rbx+0x10]
   257d2:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
   257d6:	48 8b 40 18          	mov    rax,QWORD PTR [rax+0x18]
   257da:	48 8b 10             	mov    rdx,QWORD PTR [rax]
   257dd:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
   257e1:	83 f8 f6             	cmp    eax,0xfffffff6
   257e4:	76 04                	jbe    257ea <JS_CallInternal+0x2cea>
   257e6:	83 42 fc 01          	add    DWORD PTR [rdx-0x4],0x1
   257ea:	48 89 13             	mov    QWORD PTR [rbx],rdx
   257ed:	49 83 c4 01          	add    r12,0x1
   257f1:	48 89 43 08          	mov    QWORD PTR [rbx+0x8],rax
   257f5:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   257fb:	48 89 cb             	mov    rbx,rcx
   257fe:	49 89 c5             	mov    r13,rax
   25801:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   25805:	ff e0                	jmp    rax
   25807:	f3 0f 1e fa          	endbr64
   2580b:	48 8b 85 98 fe ff ff 	mov    rax,QWORD PTR [rbp-0x168]
   25812:	48 8d 4b 10          	lea    rcx,[rbx+0x10]
   25816:	48 8b 40 18          	mov    rax,QWORD PTR [rax+0x18]
   2581a:	48 8b 40 18          	mov    rax,QWORD PTR [rax+0x18]
   2581e:	48 8b 10             	mov    rdx,QWORD PTR [rax]
   25821:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
   25825:	83 f8 f6             	cmp    eax,0xfffffff6
   25828:	76 04                	jbe    2582e <JS_CallInternal+0x2d2e>
   2582a:	83 42 fc 01          	add    DWORD PTR [rdx-0x4],0x1
   2582e:	48 89 13             	mov    QWORD PTR [rbx],rdx
   25831:	49 83 c4 01          	add    r12,0x1
   25835:	48 89 43 08          	mov    QWORD PTR [rbx+0x8],rax
   25839:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   2583f:	48 89 cb             	mov    rbx,rcx
   25842:	49 89 c5             	mov    r13,rax
   25845:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   25849:	ff e0                	jmp    rax
   2584b:	f3 0f 1e fa          	endbr64
   2584f:	48 8b 85 98 fe ff ff 	mov    rax,QWORD PTR [rbp-0x168]
   25856:	48 8d 4b 10          	lea    rcx,[rbx+0x10]
   2585a:	48 8b 00             	mov    rax,QWORD PTR [rax]
   2585d:	48 8b 40 18          	mov    rax,QWORD PTR [rax+0x18]
   25861:	48 8b 10             	mov    rdx,QWORD PTR [rax]
   25864:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
   25868:	83 f8 f6             	cmp    eax,0xfffffff6
   2586b:	76 04                	jbe    25871 <JS_CallInternal+0x2d71>
   2586d:	83 42 fc 01          	add    DWORD PTR [rdx-0x4],0x1
   25871:	48 89 13             	mov    QWORD PTR [rbx],rdx
   25874:	49 83 c4 01          	add    r12,0x1
   25878:	48 89 43 08          	mov    QWORD PTR [rbx+0x8],rax
   2587c:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   25882:	48 89 cb             	mov    rbx,rcx
   25885:	49 89 c5             	mov    r13,rax
   25888:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   2588c:	ff e0                	jmp    rax
   2588e:	f3 0f 1e fa          	endbr64
   25892:	48 8b 43 f8          	mov    rax,QWORD PTR [rbx-0x8]
   25896:	48 8b 53 f0          	mov    rdx,QWORD PTR [rbx-0x10]
   2589a:	83 f8 f6             	cmp    eax,0xfffffff6
   2589d:	76 04                	jbe    258a3 <JS_CallInternal+0x2da3>
   2589f:	83 42 fc 01          	add    DWORD PTR [rdx-0x4],0x1
   258a3:	48 8b bd 90 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x170]
   258aa:	48 8b 4f 38          	mov    rcx,QWORD PTR [rdi+0x38]
   258ae:	48 8b 77 30          	mov    rsi,QWORD PTR [rdi+0x30]
   258b2:	48 89 47 38          	mov    QWORD PTR [rdi+0x38],rax
   258b6:	48 89 57 30          	mov    QWORD PTR [rdi+0x30],rdx
   258ba:	83 f9 f6             	cmp    ecx,0xfffffff6
   258bd:	76 11                	jbe    258d0 <JS_CallInternal+0x2dd0>
   258bf:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   258c2:	83 e8 01             	sub    eax,0x1
   258c5:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   258c8:	85 c0                	test   eax,eax
   258ca:	0f 8e 83 4c 00 00    	jle    2a553 <JS_CallInternal+0x7a53>
   258d0:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   258d5:	49 83 c4 01          	add    r12,0x1
   258d9:	49 89 c5             	mov    r13,rax
   258dc:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   258e0:	ff e0                	jmp    rax
   258e2:	f3 0f 1e fa          	endbr64
   258e6:	48 8b 43 f8          	mov    rax,QWORD PTR [rbx-0x8]
   258ea:	48 8b 53 f0          	mov    rdx,QWORD PTR [rbx-0x10]
   258ee:	83 f8 f6             	cmp    eax,0xfffffff6
   258f1:	76 04                	jbe    258f7 <JS_CallInternal+0x2df7>
   258f3:	83 42 fc 01          	add    DWORD PTR [rdx-0x4],0x1
   258f7:	48 8b bd 90 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x170]
   258fe:	48 8b 4f 28          	mov    rcx,QWORD PTR [rdi+0x28]
   25902:	48 8b 77 20          	mov    rsi,QWORD PTR [rdi+0x20]
   25906:	48 89 47 28          	mov    QWORD PTR [rdi+0x28],rax
   2590a:	48 89 57 20          	mov    QWORD PTR [rdi+0x20],rdx
   2590e:	83 f9 f6             	cmp    ecx,0xfffffff6
   25911:	76 11                	jbe    25924 <JS_CallInternal+0x2e24>
   25913:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   25916:	83 e8 01             	sub    eax,0x1
   25919:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   2591c:	85 c0                	test   eax,eax
   2591e:	0f 8e 47 4c 00 00    	jle    2a56b <JS_CallInternal+0x7a6b>
   25924:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   25929:	49 83 c4 01          	add    r12,0x1
   2592d:	49 89 c5             	mov    r13,rax
   25930:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   25934:	ff e0                	jmp    rax
   25936:	f3 0f 1e fa          	endbr64
   2593a:	48 8b 43 f8          	mov    rax,QWORD PTR [rbx-0x8]
   2593e:	48 8b 53 f0          	mov    rdx,QWORD PTR [rbx-0x10]
   25942:	83 f8 f6             	cmp    eax,0xfffffff6
   25945:	76 04                	jbe    2594b <JS_CallInternal+0x2e4b>
   25947:	83 42 fc 01          	add    DWORD PTR [rdx-0x4],0x1
   2594b:	48 8b bd 90 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x170]
   25952:	48 8b 4f 18          	mov    rcx,QWORD PTR [rdi+0x18]
   25956:	48 8b 77 10          	mov    rsi,QWORD PTR [rdi+0x10]
   2595a:	48 89 47 18          	mov    QWORD PTR [rdi+0x18],rax
   2595e:	48 89 57 10          	mov    QWORD PTR [rdi+0x10],rdx
   25962:	83 f9 f6             	cmp    ecx,0xfffffff6
   25965:	76 11                	jbe    25978 <JS_CallInternal+0x2e78>
   25967:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   2596a:	83 e8 01             	sub    eax,0x1
   2596d:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   25970:	85 c0                	test   eax,eax
   25972:	0f 8e 0b 4c 00 00    	jle    2a583 <JS_CallInternal+0x7a83>
   25978:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   2597d:	49 83 c4 01          	add    r12,0x1
   25981:	49 89 c5             	mov    r13,rax
   25984:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   25988:	ff e0                	jmp    rax
   2598a:	f3 0f 1e fa          	endbr64
   2598e:	48 8b 43 f8          	mov    rax,QWORD PTR [rbx-0x8]
   25992:	48 8b 53 f0          	mov    rdx,QWORD PTR [rbx-0x10]
   25996:	83 f8 f6             	cmp    eax,0xfffffff6
   25999:	76 04                	jbe    2599f <JS_CallInternal+0x2e9f>
   2599b:	83 42 fc 01          	add    DWORD PTR [rdx-0x4],0x1
   2599f:	48 8b bd 90 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x170]
   259a6:	48 8b 4f 08          	mov    rcx,QWORD PTR [rdi+0x8]
   259aa:	48 8b 37             	mov    rsi,QWORD PTR [rdi]
   259ad:	48 89 47 08          	mov    QWORD PTR [rdi+0x8],rax
   259b1:	48 89 17             	mov    QWORD PTR [rdi],rdx
   259b4:	83 f9 f6             	cmp    ecx,0xfffffff6
   259b7:	76 11                	jbe    259ca <JS_CallInternal+0x2eca>
   259b9:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   259bc:	83 e8 01             	sub    eax,0x1
   259bf:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   259c2:	85 c0                	test   eax,eax
   259c4:	0f 8e 2d 4d 00 00    	jle    2a6f7 <JS_CallInternal+0x7bf7>
   259ca:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   259cf:	49 83 c4 01          	add    r12,0x1
   259d3:	49 89 c5             	mov    r13,rax
   259d6:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   259da:	ff e0                	jmp    rax
   259dc:	f3 0f 1e fa          	endbr64
   259e0:	48 8b 85 90 fe ff ff 	mov    rax,QWORD PTR [rbp-0x170]
   259e7:	f3 0f 6f 4b f0       	movdqu xmm1,XMMWORD PTR [rbx-0x10]
   259ec:	48 83 eb 10          	sub    rbx,0x10
   259f0:	48 8b 50 08          	mov    rdx,QWORD PTR [rax+0x8]
   259f4:	48 8b 30             	mov    rsi,QWORD PTR [rax]
   259f7:	0f 11 08             	movups XMMWORD PTR [rax],xmm1
   259fa:	83 fa f6             	cmp    edx,0xfffffff6
   259fd:	76 11                	jbe    25a10 <JS_CallInternal+0x2f10>
   259ff:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   25a02:	83 e8 01             	sub    eax,0x1
   25a05:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   25a08:	85 c0                	test   eax,eax
   25a0a:	0f 8e d2 4c 00 00    	jle    2a6e2 <JS_CallInternal+0x7be2>
   25a10:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   25a15:	49 83 c4 01          	add    r12,0x1
   25a19:	49 89 c5             	mov    r13,rax
   25a1c:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   25a20:	ff e0                	jmp    rax
   25a22:	f3 0f 1e fa          	endbr64
   25a26:	48 8b 85 90 fe ff ff 	mov    rax,QWORD PTR [rbp-0x170]
   25a2d:	f3 0f 6f 53 f0       	movdqu xmm2,XMMWORD PTR [rbx-0x10]
   25a32:	48 83 eb 10          	sub    rbx,0x10
   25a36:	48 8b 50 28          	mov    rdx,QWORD PTR [rax+0x28]
   25a3a:	48 8b 70 20          	mov    rsi,QWORD PTR [rax+0x20]
   25a3e:	0f 11 50 20          	movups XMMWORD PTR [rax+0x20],xmm2
   25a42:	83 fa f6             	cmp    edx,0xfffffff6
   25a45:	76 11                	jbe    25a58 <JS_CallInternal+0x2f58>
   25a47:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   25a4a:	83 e8 01             	sub    eax,0x1
   25a4d:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   25a50:	85 c0                	test   eax,eax
   25a52:	0f 8e 75 4c 00 00    	jle    2a6cd <JS_CallInternal+0x7bcd>
   25a58:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   25a5d:	49 83 c4 01          	add    r12,0x1
   25a61:	49 89 c5             	mov    r13,rax
   25a64:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   25a68:	ff e0                	jmp    rax
   25a6a:	f3 0f 1e fa          	endbr64
   25a6e:	48 8b 85 90 fe ff ff 	mov    rax,QWORD PTR [rbp-0x170]
   25a75:	48 8d 4b 10          	lea    rcx,[rbx+0x10]
   25a79:	48 8b 50 20          	mov    rdx,QWORD PTR [rax+0x20]
   25a7d:	48 8b 40 28          	mov    rax,QWORD PTR [rax+0x28]
   25a81:	83 f8 f6             	cmp    eax,0xfffffff6
   25a84:	76 04                	jbe    25a8a <JS_CallInternal+0x2f8a>
   25a86:	83 42 fc 01          	add    DWORD PTR [rdx-0x4],0x1
   25a8a:	48 89 13             	mov    QWORD PTR [rbx],rdx
   25a8d:	49 83 c4 01          	add    r12,0x1
   25a91:	48 89 43 08          	mov    QWORD PTR [rbx+0x8],rax
   25a95:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   25a9b:	48 89 cb             	mov    rbx,rcx
   25a9e:	49 89 c5             	mov    r13,rax
   25aa1:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   25aa5:	ff e0                	jmp    rax
   25aa7:	f3 0f 1e fa          	endbr64
   25aab:	48 8b 85 90 fe ff ff 	mov    rax,QWORD PTR [rbp-0x170]
   25ab2:	48 8d 4b 10          	lea    rcx,[rbx+0x10]
   25ab6:	48 8b 50 10          	mov    rdx,QWORD PTR [rax+0x10]
   25aba:	48 8b 40 18          	mov    rax,QWORD PTR [rax+0x18]
   25abe:	83 f8 f6             	cmp    eax,0xfffffff6
   25ac1:	76 04                	jbe    25ac7 <JS_CallInternal+0x2fc7>
   25ac3:	83 42 fc 01          	add    DWORD PTR [rdx-0x4],0x1
   25ac7:	48 89 13             	mov    QWORD PTR [rbx],rdx
   25aca:	49 83 c4 01          	add    r12,0x1
   25ace:	48 89 43 08          	mov    QWORD PTR [rbx+0x8],rax
   25ad2:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   25ad8:	48 89 cb             	mov    rbx,rcx
   25adb:	49 89 c5             	mov    r13,rax
   25ade:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   25ae2:	ff e0                	jmp    rax
   25ae4:	f3 0f 1e fa          	endbr64
   25ae8:	48 8b 85 90 fe ff ff 	mov    rax,QWORD PTR [rbp-0x170]
   25aef:	48 8d 4b 10          	lea    rcx,[rbx+0x10]
   25af3:	48 8b 50 30          	mov    rdx,QWORD PTR [rax+0x30]
   25af7:	48 8b 40 38          	mov    rax,QWORD PTR [rax+0x38]
   25afb:	83 f8 f6             	cmp    eax,0xfffffff6
   25afe:	76 04                	jbe    25b04 <JS_CallInternal+0x3004>
   25b00:	83 42 fc 01          	add    DWORD PTR [rdx-0x4],0x1
   25b04:	48 89 13             	mov    QWORD PTR [rbx],rdx
   25b07:	49 83 c4 01          	add    r12,0x1
   25b0b:	48 89 43 08          	mov    QWORD PTR [rbx+0x8],rax
   25b0f:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   25b15:	48 89 cb             	mov    rbx,rcx
   25b18:	49 89 c5             	mov    r13,rax
   25b1b:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   25b1f:	ff e0                	jmp    rax
   25b21:	f3 0f 1e fa          	endbr64
   25b25:	48 8b 85 90 fe ff ff 	mov    rax,QWORD PTR [rbp-0x170]
   25b2c:	f3 0f 6f 6b f0       	movdqu xmm5,XMMWORD PTR [rbx-0x10]
   25b31:	48 83 eb 10          	sub    rbx,0x10
   25b35:	48 8b 50 38          	mov    rdx,QWORD PTR [rax+0x38]
   25b39:	48 8b 70 30          	mov    rsi,QWORD PTR [rax+0x30]
   25b3d:	0f 11 68 30          	movups XMMWORD PTR [rax+0x30],xmm5
   25b41:	83 fa f6             	cmp    edx,0xfffffff6
   25b44:	76 11                	jbe    25b57 <JS_CallInternal+0x3057>
   25b46:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   25b49:	83 e8 01             	sub    eax,0x1
   25b4c:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   25b4f:	85 c0                	test   eax,eax
   25b51:	0f 8e 61 4b 00 00    	jle    2a6b8 <JS_CallInternal+0x7bb8>
   25b57:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   25b5c:	49 83 c4 01          	add    r12,0x1
   25b60:	49 89 c5             	mov    r13,rax
   25b63:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   25b67:	ff e0                	jmp    rax
   25b69:	f3 0f 1e fa          	endbr64
   25b6d:	48 8b 85 90 fe ff ff 	mov    rax,QWORD PTR [rbp-0x170]
   25b74:	f3 0f 6f 63 f0       	movdqu xmm4,XMMWORD PTR [rbx-0x10]
   25b79:	48 83 eb 10          	sub    rbx,0x10
   25b7d:	48 8b 50 18          	mov    rdx,QWORD PTR [rax+0x18]
   25b81:	48 8b 70 10          	mov    rsi,QWORD PTR [rax+0x10]
   25b85:	0f 11 60 10          	movups XMMWORD PTR [rax+0x10],xmm4
   25b89:	83 fa f6             	cmp    edx,0xfffffff6
   25b8c:	76 11                	jbe    25b9f <JS_CallInternal+0x309f>
   25b8e:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   25b91:	83 e8 01             	sub    eax,0x1
   25b94:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   25b97:	85 c0                	test   eax,eax
   25b99:	0f 8e bc 4a 00 00    	jle    2a65b <JS_CallInternal+0x7b5b>
   25b9f:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   25ba4:	49 83 c4 01          	add    r12,0x1
   25ba8:	49 89 c5             	mov    r13,rax
   25bab:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   25baf:	ff e0                	jmp    rax
   25bb1:	f3 0f 1e fa          	endbr64
   25bb5:	41 0f b7 04 24       	movzx  eax,WORD PTR [r12]
   25bba:	48 8b 8d 98 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x168]
   25bc1:	48 8b 04 c1          	mov    rax,QWORD PTR [rcx+rax*8]
   25bc5:	48 8b 40 18          	mov    rax,QWORD PTR [rax+0x18]
   25bc9:	48 8b 10             	mov    rdx,QWORD PTR [rax]
   25bcc:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
   25bd0:	83 f8 f6             	cmp    eax,0xfffffff6
   25bd3:	76 04                	jbe    25bd9 <JS_CallInternal+0x30d9>
   25bd5:	83 42 fc 01          	add    DWORD PTR [rdx-0x4],0x1
   25bd9:	48 89 13             	mov    QWORD PTR [rbx],rdx
   25bdc:	49 83 c4 03          	add    r12,0x3
   25be0:	48 83 c3 10          	add    rbx,0x10
   25be4:	48 89 43 f8          	mov    QWORD PTR [rbx-0x8],rax
   25be8:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   25bee:	49 89 c5             	mov    r13,rax
   25bf1:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   25bf5:	ff e0                	jmp    rax
   25bf7:	f3 0f 1e fa          	endbr64
   25bfb:	48 8b 53 f8          	mov    rdx,QWORD PTR [rbx-0x8]
   25bff:	48 8b 4b f0          	mov    rcx,QWORD PTR [rbx-0x10]
   25c03:	83 fa f6             	cmp    edx,0xfffffff6
   25c06:	76 04                	jbe    25c0c <JS_CallInternal+0x310c>
   25c08:	83 41 fc 01          	add    DWORD PTR [rcx-0x4],0x1
   25c0c:	48 8b 85 98 fe ff ff 	mov    rax,QWORD PTR [rbp-0x168]
   25c13:	48 8b 40 18          	mov    rax,QWORD PTR [rax+0x18]
   25c17:	48 8b 40 18          	mov    rax,QWORD PTR [rax+0x18]
   25c1b:	4c 8b 40 08          	mov    r8,QWORD PTR [rax+0x8]
   25c1f:	48 8b 30             	mov    rsi,QWORD PTR [rax]
   25c22:	48 89 50 08          	mov    QWORD PTR [rax+0x8],rdx
   25c26:	48 89 08             	mov    QWORD PTR [rax],rcx
   25c29:	41 83 f8 f6          	cmp    r8d,0xfffffff6
   25c2d:	76 11                	jbe    25c40 <JS_CallInternal+0x3140>
   25c2f:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   25c32:	83 e8 01             	sub    eax,0x1
   25c35:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   25c38:	85 c0                	test   eax,eax
   25c3a:	0f 8e 30 4a 00 00    	jle    2a670 <JS_CallInternal+0x7b70>
   25c40:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   25c45:	49 83 c4 01          	add    r12,0x1
   25c49:	49 89 c5             	mov    r13,rax
   25c4c:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   25c50:	ff e0                	jmp    rax
   25c52:	f3 0f 1e fa          	endbr64
   25c56:	48 8b 53 f8          	mov    rdx,QWORD PTR [rbx-0x8]
   25c5a:	48 8b 4b f0          	mov    rcx,QWORD PTR [rbx-0x10]
   25c5e:	83 fa f6             	cmp    edx,0xfffffff6
   25c61:	76 04                	jbe    25c67 <JS_CallInternal+0x3167>
   25c63:	83 41 fc 01          	add    DWORD PTR [rcx-0x4],0x1
   25c67:	48 8b 85 98 fe ff ff 	mov    rax,QWORD PTR [rbp-0x168]
   25c6e:	48 8b 40 10          	mov    rax,QWORD PTR [rax+0x10]
   25c72:	48 8b 40 18          	mov    rax,QWORD PTR [rax+0x18]
   25c76:	4c 8b 40 08          	mov    r8,QWORD PTR [rax+0x8]
   25c7a:	48 8b 30             	mov    rsi,QWORD PTR [rax]
   25c7d:	48 89 50 08          	mov    QWORD PTR [rax+0x8],rdx
   25c81:	48 89 08             	mov    QWORD PTR [rax],rcx
   25c84:	41 83 f8 f6          	cmp    r8d,0xfffffff6
   25c88:	76 11                	jbe    25c9b <JS_CallInternal+0x319b>
   25c8a:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   25c8d:	83 e8 01             	sub    eax,0x1
   25c90:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   25c93:	85 c0                	test   eax,eax
   25c95:	0f 8e ed 49 00 00    	jle    2a688 <JS_CallInternal+0x7b88>
   25c9b:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   25ca0:	49 83 c4 01          	add    r12,0x1
   25ca4:	49 89 c5             	mov    r13,rax
   25ca7:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   25cab:	ff e0                	jmp    rax
   25cad:	f3 0f 1e fa          	endbr64
   25cb1:	48 8b 53 f8          	mov    rdx,QWORD PTR [rbx-0x8]
   25cb5:	48 8b 4b f0          	mov    rcx,QWORD PTR [rbx-0x10]
   25cb9:	83 fa f6             	cmp    edx,0xfffffff6
   25cbc:	76 04                	jbe    25cc2 <JS_CallInternal+0x31c2>
   25cbe:	83 41 fc 01          	add    DWORD PTR [rcx-0x4],0x1
   25cc2:	48 8b 85 98 fe ff ff 	mov    rax,QWORD PTR [rbp-0x168]
   25cc9:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
   25ccd:	48 8b 40 18          	mov    rax,QWORD PTR [rax+0x18]
   25cd1:	4c 8b 40 08          	mov    r8,QWORD PTR [rax+0x8]
   25cd5:	48 8b 30             	mov    rsi,QWORD PTR [rax]
   25cd8:	48 89 50 08          	mov    QWORD PTR [rax+0x8],rdx
   25cdc:	48 89 08             	mov    QWORD PTR [rax],rcx
   25cdf:	41 83 f8 f6          	cmp    r8d,0xfffffff6
   25ce3:	76 11                	jbe    25cf6 <JS_CallInternal+0x31f6>
   25ce5:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   25ce8:	83 e8 01             	sub    eax,0x1
   25ceb:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   25cee:	85 c0                	test   eax,eax
   25cf0:	0f 8e aa 49 00 00    	jle    2a6a0 <JS_CallInternal+0x7ba0>
   25cf6:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   25cfb:	49 83 c4 01          	add    r12,0x1
   25cff:	49 89 c5             	mov    r13,rax
   25d02:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   25d06:	ff e0                	jmp    rax
   25d08:	f3 0f 1e fa          	endbr64
   25d0c:	48 8b 53 f8          	mov    rdx,QWORD PTR [rbx-0x8]
   25d10:	48 8b 4b f0          	mov    rcx,QWORD PTR [rbx-0x10]
   25d14:	83 fa f6             	cmp    edx,0xfffffff6
   25d17:	76 04                	jbe    25d1d <JS_CallInternal+0x321d>
   25d19:	83 41 fc 01          	add    DWORD PTR [rcx-0x4],0x1
   25d1d:	48 8b 85 98 fe ff ff 	mov    rax,QWORD PTR [rbp-0x168]
   25d24:	48 8b 00             	mov    rax,QWORD PTR [rax]
   25d27:	48 8b 40 18          	mov    rax,QWORD PTR [rax+0x18]
   25d2b:	4c 8b 40 08          	mov    r8,QWORD PTR [rax+0x8]
   25d2f:	48 8b 30             	mov    rsi,QWORD PTR [rax]
   25d32:	48 89 50 08          	mov    QWORD PTR [rax+0x8],rdx
   25d36:	48 89 08             	mov    QWORD PTR [rax],rcx
   25d39:	41 83 f8 f6          	cmp    r8d,0xfffffff6
   25d3d:	76 11                	jbe    25d50 <JS_CallInternal+0x3250>
   25d3f:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   25d42:	83 e8 01             	sub    eax,0x1
   25d45:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   25d48:	85 c0                	test   eax,eax
   25d4a:	0f 8e 8a 48 00 00    	jle    2a5da <JS_CallInternal+0x7ada>
   25d50:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   25d55:	49 83 c4 01          	add    r12,0x1
   25d59:	49 89 c5             	mov    r13,rax
   25d5c:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   25d60:	ff e0                	jmp    rax
   25d62:	f3 0f 1e fa          	endbr64
   25d66:	48 8b 85 98 fe ff ff 	mov    rax,QWORD PTR [rbp-0x168]
   25d6d:	f3 0f 6f 5b f0       	movdqu xmm3,XMMWORD PTR [rbx-0x10]
   25d72:	48 83 eb 10          	sub    rbx,0x10
   25d76:	48 8b 40 10          	mov    rax,QWORD PTR [rax+0x10]
   25d7a:	48 8b 40 18          	mov    rax,QWORD PTR [rax+0x18]
   25d7e:	48 8b 50 08          	mov    rdx,QWORD PTR [rax+0x8]
   25d82:	48 8b 30             	mov    rsi,QWORD PTR [rax]
   25d85:	0f 11 18             	movups XMMWORD PTR [rax],xmm3
   25d88:	83 fa f6             	cmp    edx,0xfffffff6
   25d8b:	76 11                	jbe    25d9e <JS_CallInternal+0x329e>
   25d8d:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   25d90:	83 e8 01             	sub    eax,0x1
   25d93:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   25d96:	85 c0                	test   eax,eax
   25d98:	0f 8e 69 48 00 00    	jle    2a607 <JS_CallInternal+0x7b07>
   25d9e:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   25da3:	49 83 c4 01          	add    r12,0x1
   25da7:	49 89 c5             	mov    r13,rax
   25daa:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   25dae:	ff e0                	jmp    rax
   25db0:	f3 0f 1e fa          	endbr64
   25db4:	48 8b 85 98 fe ff ff 	mov    rax,QWORD PTR [rbp-0x168]
   25dbb:	f3 0f 6f 4b f0       	movdqu xmm1,XMMWORD PTR [rbx-0x10]
   25dc0:	48 83 eb 10          	sub    rbx,0x10
   25dc4:	48 8b 40 18          	mov    rax,QWORD PTR [rax+0x18]
   25dc8:	48 8b 40 18          	mov    rax,QWORD PTR [rax+0x18]
   25dcc:	48 8b 50 08          	mov    rdx,QWORD PTR [rax+0x8]
   25dd0:	48 8b 30             	mov    rsi,QWORD PTR [rax]
   25dd3:	0f 11 08             	movups XMMWORD PTR [rax],xmm1
   25dd6:	83 fa f6             	cmp    edx,0xfffffff6
   25dd9:	76 11                	jbe    25dec <JS_CallInternal+0x32ec>
   25ddb:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   25dde:	83 e8 01             	sub    eax,0x1
   25de1:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   25de4:	85 c0                	test   eax,eax
   25de6:	0f 8e 06 48 00 00    	jle    2a5f2 <JS_CallInternal+0x7af2>
   25dec:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   25df1:	49 83 c4 01          	add    r12,0x1
   25df5:	49 89 c5             	mov    r13,rax
   25df8:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   25dfc:	ff e0                	jmp    rax
   25dfe:	f3 0f 1e fa          	endbr64
   25e02:	48 8b 85 98 fe ff ff 	mov    rax,QWORD PTR [rbp-0x168]
   25e09:	f3 0f 6f 7b f0       	movdqu xmm7,XMMWORD PTR [rbx-0x10]
   25e0e:	48 83 eb 10          	sub    rbx,0x10
   25e12:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
   25e16:	48 8b 40 18          	mov    rax,QWORD PTR [rax+0x18]
   25e1a:	48 8b 50 08          	mov    rdx,QWORD PTR [rax+0x8]
   25e1e:	48 8b 30             	mov    rsi,QWORD PTR [rax]
   25e21:	0f 11 38             	movups XMMWORD PTR [rax],xmm7
   25e24:	83 fa f6             	cmp    edx,0xfffffff6
   25e27:	76 11                	jbe    25e3a <JS_CallInternal+0x333a>
   25e29:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   25e2c:	83 e8 01             	sub    eax,0x1
   25e2f:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   25e32:	85 c0                	test   eax,eax
   25e34:	0f 8e e2 47 00 00    	jle    2a61c <JS_CallInternal+0x7b1c>
   25e3a:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   25e3f:	49 83 c4 01          	add    r12,0x1
   25e43:	49 89 c5             	mov    r13,rax
   25e46:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   25e4a:	ff e0                	jmp    rax
   25e4c:	f3 0f 1e fa          	endbr64
   25e50:	48 8b 53 f8          	mov    rdx,QWORD PTR [rbx-0x8]
   25e54:	41 0f b7 04 24       	movzx  eax,WORD PTR [r12]
   25e59:	48 8b 7b f0          	mov    rdi,QWORD PTR [rbx-0x10]
   25e5d:	83 fa f6             	cmp    edx,0xfffffff6
   25e60:	76 04                	jbe    25e66 <JS_CallInternal+0x3366>
   25e62:	83 47 fc 01          	add    DWORD PTR [rdi-0x4],0x1
   25e66:	48 8b 8d 98 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x168]
   25e6d:	48 8b 04 c1          	mov    rax,QWORD PTR [rcx+rax*8]
   25e71:	48 8b 40 18          	mov    rax,QWORD PTR [rax+0x18]
   25e75:	48 8b 48 08          	mov    rcx,QWORD PTR [rax+0x8]
   25e79:	48 8b 30             	mov    rsi,QWORD PTR [rax]
   25e7c:	48 89 50 08          	mov    QWORD PTR [rax+0x8],rdx
   25e80:	48 89 38             	mov    QWORD PTR [rax],rdi
   25e83:	83 f9 f6             	cmp    ecx,0xfffffff6
   25e86:	76 11                	jbe    25e99 <JS_CallInternal+0x3399>
   25e88:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   25e8b:	83 e8 01             	sub    eax,0x1
   25e8e:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   25e91:	85 c0                	test   eax,eax
   25e93:	0f 8e 12 4d 00 00    	jle    2abab <JS_CallInternal+0x80ab>
   25e99:	41 0f b6 44 24 02    	movzx  eax,BYTE PTR [r12+0x2]
   25e9f:	49 83 c4 03          	add    r12,0x3
   25ea3:	49 89 c5             	mov    r13,rax
   25ea6:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   25eaa:	ff e0                	jmp    rax
   25eac:	f3 0f 1e fa          	endbr64
   25eb0:	41 0f b7 04 24       	movzx  eax,WORD PTR [r12]
   25eb5:	48 8b bd 98 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x168]
   25ebc:	4d 8d 6c 24 02       	lea    r13,[r12+0x2]
   25ec1:	48 8d 0c c5 00 00 00 	lea    rcx,[rax*8+0x0]
   25ec8:	00 
   25ec9:	48 8b 04 c7          	mov    rax,QWORD PTR [rdi+rax*8]
   25ecd:	48 8b 40 18          	mov    rax,QWORD PTR [rax+0x18]
   25ed1:	48 8b 10             	mov    rdx,QWORD PTR [rax]
   25ed4:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
   25ed8:	83 f8 04             	cmp    eax,0x4
   25edb:	0f 84 22 4f 00 00    	je     2ae03 <JS_CallInternal+0x8303>
   25ee1:	83 f8 f6             	cmp    eax,0xfffffff6
   25ee4:	76 04                	jbe    25eea <JS_CallInternal+0x33ea>
   25ee6:	83 42 fc 01          	add    DWORD PTR [rdx-0x4],0x1
   25eea:	48 89 13             	mov    QWORD PTR [rbx],rdx
   25eed:	49 83 c4 03          	add    r12,0x3
   25ef1:	48 83 c3 10          	add    rbx,0x10
   25ef5:	48 89 43 f8          	mov    QWORD PTR [rbx-0x8],rax
   25ef9:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   25eff:	49 89 c5             	mov    r13,rax
   25f02:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   25f06:	ff e0                	jmp    rax
   25f08:	f3 0f 1e fa          	endbr64
   25f0c:	41 0f b7 04 24       	movzx  eax,WORD PTR [r12]
   25f11:	48 8b 8d 98 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x168]
   25f18:	f3 0f 6f 63 f0       	movdqu xmm4,XMMWORD PTR [rbx-0x10]
   25f1d:	48 8b 04 c1          	mov    rax,QWORD PTR [rcx+rax*8]
   25f21:	48 8b 40 18          	mov    rax,QWORD PTR [rax+0x18]
   25f25:	48 8b 50 08          	mov    rdx,QWORD PTR [rax+0x8]
   25f29:	48 8b 30             	mov    rsi,QWORD PTR [rax]
   25f2c:	0f 11 20             	movups XMMWORD PTR [rax],xmm4
   25f2f:	83 fa f6             	cmp    edx,0xfffffff6
   25f32:	76 11                	jbe    25f45 <JS_CallInternal+0x3445>
   25f34:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   25f37:	83 e8 01             	sub    eax,0x1
   25f3a:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   25f3d:	85 c0                	test   eax,eax
   25f3f:	0f 8e 7e 4c 00 00    	jle    2abc3 <JS_CallInternal+0x80c3>
   25f45:	41 0f b6 44 24 02    	movzx  eax,BYTE PTR [r12+0x2]
   25f4b:	48 83 eb 10          	sub    rbx,0x10
   25f4f:	49 83 c4 03          	add    r12,0x3
   25f53:	49 89 c5             	mov    r13,rax
   25f56:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   25f5a:	ff e0                	jmp    rax
   25f5c:	f3 0f 1e fa          	endbr64
   25f60:	e9 61 cf ff ff       	jmp    22ec6 <JS_CallInternal+0x3c6>
   25f65:	f3 0f 1e fa          	endbr64
   25f69:	e9 58 cf ff ff       	jmp    22ec6 <JS_CallInternal+0x3c6>
   25f6e:	f3 0f 1e fa          	endbr64
   25f72:	41 8b 04 24          	mov    eax,DWORD PTR [r12]
   25f76:	48 8b 8d d8 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x128]
   25f7d:	48 c1 e0 04          	shl    rax,0x4
   25f81:	48 03 41 50          	add    rax,QWORD PTR [rcx+0x50]
   25f85:	48 8b 50 08          	mov    rdx,QWORD PTR [rax+0x8]
   25f89:	48 8b 30             	mov    rsi,QWORD PTR [rax]
   25f8c:	83 fa f6             	cmp    edx,0xfffffff6
   25f8f:	76 04                	jbe    25f95 <JS_CallInternal+0x3495>
   25f91:	83 46 fc 01          	add    DWORD PTR [rsi-0x4],0x1
   25f95:	4c 8b 85 c8 fe ff ff 	mov    r8,QWORD PTR [rbp-0x138]
   25f9c:	45 31 c9             	xor    r9d,r9d
   25f9f:	4d 8d 6c 24 04       	lea    r13,[r12+0x4]
   25fa4:	4c 8d 73 10          	lea    r14,[rbx+0x10]
   25fa8:	48 8b 8d 98 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x168]
   25faf:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   25fb6:	e8 c5 59 02 00       	call   4b980 <js_closure>
   25fbb:	48 89 53 08          	mov    QWORD PTR [rbx+0x8],rdx
   25fbf:	83 7b 08 06          	cmp    DWORD PTR [rbx+0x8],0x6
   25fc3:	48 89 03             	mov    QWORD PTR [rbx],rax
   25fc6:	0f 84 fc 4c 00 00    	je     2acc8 <JS_CallInternal+0x81c8>
   25fcc:	41 0f b6 44 24 04    	movzx  eax,BYTE PTR [r12+0x4]
   25fd2:	4c 89 f3             	mov    rbx,r14
   25fd5:	49 83 c4 05          	add    r12,0x5
   25fd9:	49 89 c5             	mov    r13,rax
   25fdc:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   25fe0:	ff e0                	jmp    rax
   25fe2:	f3 0f 1e fa          	endbr64
   25fe6:	f3 0f 6f 4b c0       	movdqu xmm1,XMMWORD PTR [rbx-0x40]
   25feb:	f3 0f 6f 43 d0       	movdqu xmm0,XMMWORD PTR [rbx-0x30]
   25ff0:	49 83 c4 01          	add    r12,0x1
   25ff4:	f3 0f 6f 6b e0       	movdqu xmm5,XMMWORD PTR [rbx-0x20]
   25ff9:	f3 0f 6f 73 f0       	movdqu xmm6,XMMWORD PTR [rbx-0x10]
   25ffe:	0f 11 4b e0          	movups XMMWORD PTR [rbx-0x20],xmm1
   26002:	0f 11 6b c0          	movups XMMWORD PTR [rbx-0x40],xmm5
   26006:	0f 11 73 d0          	movups XMMWORD PTR [rbx-0x30],xmm6
   2600a:	0f 11 43 f0          	movups XMMWORD PTR [rbx-0x10],xmm0
   2600e:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   26014:	49 89 c5             	mov    r13,rax
   26017:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   2601b:	ff e0                	jmp    rax
   2601d:	f3 0f 1e fa          	endbr64
   26021:	f3 0f 6f 43 e0       	movdqu xmm0,XMMWORD PTR [rbx-0x20]
   26026:	f3 0f 6f 53 f0       	movdqu xmm2,XMMWORD PTR [rbx-0x10]
   2602b:	49 83 c4 01          	add    r12,0x1
   2602f:	0f 11 53 e0          	movups XMMWORD PTR [rbx-0x20],xmm2
   26033:	0f 11 43 f0          	movups XMMWORD PTR [rbx-0x10],xmm0
   26037:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   2603d:	49 89 c5             	mov    r13,rax
   26040:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   26044:	ff e0                	jmp    rax
   26046:	f3 0f 1e fa          	endbr64
   2604a:	f3 0f 6f 43 e0       	movdqu xmm0,XMMWORD PTR [rbx-0x20]
   2604f:	f3 0f 6f 5b d0       	movdqu xmm3,XMMWORD PTR [rbx-0x30]
   26054:	49 83 c4 01          	add    r12,0x1
   26058:	f3 0f 6f 4b c0       	movdqu xmm1,XMMWORD PTR [rbx-0x40]
   2605d:	f3 0f 6f 63 b0       	movdqu xmm4,XMMWORD PTR [rbx-0x50]
   26062:	0f 11 5b e0          	movups XMMWORD PTR [rbx-0x20],xmm3
   26066:	0f 11 4b d0          	movups XMMWORD PTR [rbx-0x30],xmm1
   2606a:	0f 11 63 c0          	movups XMMWORD PTR [rbx-0x40],xmm4
   2606e:	0f 11 43 b0          	movups XMMWORD PTR [rbx-0x50],xmm0
   26072:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   26078:	49 89 c5             	mov    r13,rax
   2607b:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   2607f:	ff e0                	jmp    rax
   26081:	f3 0f 1e fa          	endbr64
   26085:	f3 0f 6f 43 e0       	movdqu xmm0,XMMWORD PTR [rbx-0x20]
   2608a:	f3 0f 6f 73 d0       	movdqu xmm6,XMMWORD PTR [rbx-0x30]
   2608f:	49 83 c4 01          	add    r12,0x1
   26093:	f3 0f 6f 7b c0       	movdqu xmm7,XMMWORD PTR [rbx-0x40]
   26098:	0f 11 73 e0          	movups XMMWORD PTR [rbx-0x20],xmm6
   2609c:	0f 11 7b d0          	movups XMMWORD PTR [rbx-0x30],xmm7
   260a0:	0f 11 43 c0          	movups XMMWORD PTR [rbx-0x40],xmm0
   260a4:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   260aa:	49 89 c5             	mov    r13,rax
   260ad:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   260b1:	ff e0                	jmp    rax
   260b3:	f3 0f 1e fa          	endbr64
   260b7:	f3 0f 6f 43 f0       	movdqu xmm0,XMMWORD PTR [rbx-0x10]
   260bc:	f3 0f 6f 53 e0       	movdqu xmm2,XMMWORD PTR [rbx-0x20]
   260c1:	49 83 c4 01          	add    r12,0x1
   260c5:	f3 0f 6f 6b d0       	movdqu xmm5,XMMWORD PTR [rbx-0x30]
   260ca:	0f 11 53 f0          	movups XMMWORD PTR [rbx-0x10],xmm2
   260ce:	0f 11 6b e0          	movups XMMWORD PTR [rbx-0x20],xmm5
   260d2:	0f 11 43 d0          	movups XMMWORD PTR [rbx-0x30],xmm0
   260d6:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   260dc:	49 89 c5             	mov    r13,rax
   260df:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   260e3:	ff e0                	jmp    rax
   260e5:	f3 0f 1e fa          	endbr64
   260e9:	f3 0f 6f 43 b0       	movdqu xmm0,XMMWORD PTR [rbx-0x50]
   260ee:	f3 0f 6f 7b c0       	movdqu xmm7,XMMWORD PTR [rbx-0x40]
   260f3:	49 83 c4 01          	add    r12,0x1
   260f7:	f3 0f 6f 5b d0       	movdqu xmm3,XMMWORD PTR [rbx-0x30]
   260fc:	f3 0f 6f 4b e0       	movdqu xmm1,XMMWORD PTR [rbx-0x20]
   26101:	f3 0f 6f 63 f0       	movdqu xmm4,XMMWORD PTR [rbx-0x10]
   26106:	0f 11 7b b0          	movups XMMWORD PTR [rbx-0x50],xmm7
   2610a:	0f 11 5b c0          	movups XMMWORD PTR [rbx-0x40],xmm3
   2610e:	0f 11 4b d0          	movups XMMWORD PTR [rbx-0x30],xmm1
   26112:	0f 11 63 e0          	movups XMMWORD PTR [rbx-0x20],xmm4
   26116:	0f 11 43 f0          	movups XMMWORD PTR [rbx-0x10],xmm0
   2611a:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   26120:	49 89 c5             	mov    r13,rax
   26123:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   26127:	ff e0                	jmp    rax
   26129:	f3 0f 1e fa          	endbr64
   2612d:	f3 0f 6f 43 c0       	movdqu xmm0,XMMWORD PTR [rbx-0x40]
   26132:	f3 0f 6f 63 d0       	movdqu xmm4,XMMWORD PTR [rbx-0x30]
   26137:	49 83 c4 01          	add    r12,0x1
   2613b:	f3 0f 6f 6b e0       	movdqu xmm5,XMMWORD PTR [rbx-0x20]
   26140:	f3 0f 6f 73 f0       	movdqu xmm6,XMMWORD PTR [rbx-0x10]
   26145:	0f 11 63 c0          	movups XMMWORD PTR [rbx-0x40],xmm4
   26149:	0f 11 6b d0          	movups XMMWORD PTR [rbx-0x30],xmm5
   2614d:	0f 11 73 e0          	movups XMMWORD PTR [rbx-0x20],xmm6
   26151:	0f 11 43 f0          	movups XMMWORD PTR [rbx-0x10],xmm0
   26155:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   2615b:	49 89 c5             	mov    r13,rax
   2615e:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   26162:	ff e0                	jmp    rax
   26164:	f3 0f 1e fa          	endbr64
   26168:	f3 0f 6f 43 d0       	movdqu xmm0,XMMWORD PTR [rbx-0x30]
   2616d:	f3 0f 6f 7b e0       	movdqu xmm7,XMMWORD PTR [rbx-0x20]
   26172:	49 83 c4 01          	add    r12,0x1
   26176:	f3 0f 6f 5b f0       	movdqu xmm3,XMMWORD PTR [rbx-0x10]
   2617b:	0f 11 7b d0          	movups XMMWORD PTR [rbx-0x30],xmm7
   2617f:	0f 11 5b e0          	movups XMMWORD PTR [rbx-0x20],xmm3
   26183:	0f 11 43 f0          	movups XMMWORD PTR [rbx-0x10],xmm0
   26187:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   2618d:	49 89 c5             	mov    r13,rax
   26190:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   26194:	ff e0                	jmp    rax
   26196:	f3 0f 1e fa          	endbr64
   2619a:	f3 0f 6f 43 e0       	movdqu xmm0,XMMWORD PTR [rbx-0x20]
   2619f:	f3 0f 6f 73 d0       	movdqu xmm6,XMMWORD PTR [rbx-0x30]
   261a4:	49 83 c4 01          	add    r12,0x1
   261a8:	0f 11 73 e0          	movups XMMWORD PTR [rbx-0x20],xmm6
   261ac:	0f 11 43 d0          	movups XMMWORD PTR [rbx-0x30],xmm0
   261b0:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   261b6:	49 89 c5             	mov    r13,rax
   261b9:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   261bd:	ff e0                	jmp    rax
   261bf:	f3 0f 1e fa          	endbr64
   261c3:	f3 0f 6f 7b f0       	movdqu xmm7,XMMWORD PTR [rbx-0x10]
   261c8:	f3 0f 6f 5b e0       	movdqu xmm3,XMMWORD PTR [rbx-0x20]
   261cd:	f3 0f 6f 63 d0       	movdqu xmm4,XMMWORD PTR [rbx-0x30]
   261d2:	f3 0f 6f 6b c0       	movdqu xmm5,XMMWORD PTR [rbx-0x40]
   261d7:	0f 11 3b             	movups XMMWORD PTR [rbx],xmm7
   261da:	48 8b 43 08          	mov    rax,QWORD PTR [rbx+0x8]
   261de:	48 8b 53 f0          	mov    rdx,QWORD PTR [rbx-0x10]
   261e2:	0f 11 63 e0          	movups XMMWORD PTR [rbx-0x20],xmm4
   261e6:	0f 11 5b f0          	movups XMMWORD PTR [rbx-0x10],xmm3
   261ea:	0f 11 6b d0          	movups XMMWORD PTR [rbx-0x30],xmm5
   261ee:	83 f8 f6             	cmp    eax,0xfffffff6
   261f1:	76 04                	jbe    261f7 <JS_CallInternal+0x36f7>
   261f3:	83 42 fc 01          	add    DWORD PTR [rdx-0x4],0x1
   261f7:	48 89 53 c0          	mov    QWORD PTR [rbx-0x40],rdx
   261fb:	49 83 c4 01          	add    r12,0x1
   261ff:	48 83 c3 10          	add    rbx,0x10
   26203:	48 89 43 b8          	mov    QWORD PTR [rbx-0x48],rax
   26207:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   2620d:	49 89 c5             	mov    r13,rax
   26210:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   26214:	ff e0                	jmp    rax
   26216:	f3 0f 1e fa          	endbr64
   2621a:	f3 0f 6f 63 f0       	movdqu xmm4,XMMWORD PTR [rbx-0x10]
   2621f:	f3 0f 6f 6b e0       	movdqu xmm5,XMMWORD PTR [rbx-0x20]
   26224:	f3 0f 6f 73 d0       	movdqu xmm6,XMMWORD PTR [rbx-0x30]
   26229:	48 8b 53 f0          	mov    rdx,QWORD PTR [rbx-0x10]
   2622d:	0f 11 23             	movups XMMWORD PTR [rbx],xmm4
   26230:	48 8b 43 08          	mov    rax,QWORD PTR [rbx+0x8]
   26234:	0f 11 6b f0          	movups XMMWORD PTR [rbx-0x10],xmm5
   26238:	0f 11 73 e0          	movups XMMWORD PTR [rbx-0x20],xmm6
   2623c:	83 f8 f6             	cmp    eax,0xfffffff6
   2623f:	76 04                	jbe    26245 <JS_CallInternal+0x3745>
   26241:	83 42 fc 01          	add    DWORD PTR [rdx-0x4],0x1
   26245:	48 89 53 d0          	mov    QWORD PTR [rbx-0x30],rdx
   26249:	49 83 c4 01          	add    r12,0x1
   2624d:	48 83 c3 10          	add    rbx,0x10
   26251:	48 89 43 c8          	mov    QWORD PTR [rbx-0x38],rax
   26255:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   2625b:	49 89 c5             	mov    r13,rax
   2625e:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   26262:	ff e0                	jmp    rax
   26264:	f3 0f 1e fa          	endbr64
   26268:	f3 0f 6f 73 f0       	movdqu xmm6,XMMWORD PTR [rbx-0x10]
   2626d:	f3 0f 6f 7b e0       	movdqu xmm7,XMMWORD PTR [rbx-0x20]
   26272:	48 8b 53 f0          	mov    rdx,QWORD PTR [rbx-0x10]
   26276:	0f 11 33             	movups XMMWORD PTR [rbx],xmm6
   26279:	48 8b 43 08          	mov    rax,QWORD PTR [rbx+0x8]
   2627d:	0f 11 7b f0          	movups XMMWORD PTR [rbx-0x10],xmm7
   26281:	83 f8 f6             	cmp    eax,0xfffffff6
   26284:	76 04                	jbe    2628a <JS_CallInternal+0x378a>
   26286:	83 42 fc 01          	add    DWORD PTR [rdx-0x4],0x1
   2628a:	48 89 53 e0          	mov    QWORD PTR [rbx-0x20],rdx
   2628e:	49 83 c4 01          	add    r12,0x1
   26292:	48 83 c3 10          	add    rbx,0x10
   26296:	48 89 43 d8          	mov    QWORD PTR [rbx-0x28],rax
   2629a:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   262a0:	49 89 c5             	mov    r13,rax
   262a3:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   262a7:	ff e0                	jmp    rax
   262a9:	f3 0f 1e fa          	endbr64
   262ad:	f3 0f 6f 6b f0       	movdqu xmm5,XMMWORD PTR [rbx-0x10]
   262b2:	48 8b 43 e8          	mov    rax,QWORD PTR [rbx-0x18]
   262b6:	48 8b 53 e0          	mov    rdx,QWORD PTR [rbx-0x20]
   262ba:	0f 11 2b             	movups XMMWORD PTR [rbx],xmm5
   262bd:	83 f8 f6             	cmp    eax,0xfffffff6
   262c0:	76 04                	jbe    262c6 <JS_CallInternal+0x37c6>
   262c2:	83 42 fc 01          	add    DWORD PTR [rdx-0x4],0x1
   262c6:	48 89 53 f0          	mov    QWORD PTR [rbx-0x10],rdx
   262ca:	49 83 c4 01          	add    r12,0x1
   262ce:	48 83 c3 10          	add    rbx,0x10
   262d2:	48 89 43 e8          	mov    QWORD PTR [rbx-0x18],rax
   262d6:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   262dc:	49 89 c5             	mov    r13,rax
   262df:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   262e3:	ff e0                	jmp    rax
   262e5:	f3 0f 1e fa          	endbr64
   262e9:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   262f0:	48 8b 73 f0          	mov    rsi,QWORD PTR [rbx-0x10]
   262f4:	48 83 eb 10          	sub    rbx,0x10
   262f8:	48 8b 53 08          	mov    rdx,QWORD PTR [rbx+0x8]
   262fc:	e8 2f c0 ff ff       	call   22330 <JS_Throw>
   26301:	e9 9a cf ff ff       	jmp    232a0 <JS_CallInternal+0x7a0>
   26306:	f3 0f 1e fa          	endbr64
   2630a:	48 8b 4b f0          	mov    rcx,QWORD PTR [rbx-0x10]
   2630e:	48 8b 73 e0          	mov    rsi,QWORD PTR [rbx-0x20]
   26312:	4c 8d 6b f0          	lea    r13,[rbx-0x10]
   26316:	4c 8d 73 e0          	lea    r14,[rbx-0x20]
   2631a:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   26321:	49 8b 56 08          	mov    rdx,QWORD PTR [r14+0x8]
   26325:	4d 8b 45 08          	mov    r8,QWORD PTR [r13+0x8]
   26329:	e8 62 03 02 00       	call   46690 <JS_AddBrand>
   2632e:	85 c0                	test   eax,eax
   26330:	0f 88 6a cf ff ff    	js     232a0 <JS_CallInternal+0x7a0>
   26336:	49 8b 56 08          	mov    rdx,QWORD PTR [r14+0x8]
   2633a:	48 8b 73 e0          	mov    rsi,QWORD PTR [rbx-0x20]
   2633e:	83 fa f6             	cmp    edx,0xfffffff6
   26341:	76 11                	jbe    26354 <JS_CallInternal+0x3854>
   26343:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   26346:	83 e8 01             	sub    eax,0x1
   26349:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   2634c:	85 c0                	test   eax,eax
   2634e:	0f 8e 4a 49 00 00    	jle    2ac9e <JS_CallInternal+0x819e>
   26354:	49 8b 55 08          	mov    rdx,QWORD PTR [r13+0x8]
   26358:	49 8b 75 00          	mov    rsi,QWORD PTR [r13+0x0]
   2635c:	83 fa f6             	cmp    edx,0xfffffff6
   2635f:	76 11                	jbe    26372 <JS_CallInternal+0x3872>
   26361:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   26364:	83 e8 01             	sub    eax,0x1
   26367:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   2636a:	85 c0                	test   eax,eax
   2636c:	0f 8e 41 49 00 00    	jle    2acb3 <JS_CallInternal+0x81b3>
   26372:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   26377:	4c 89 f3             	mov    rbx,r14
   2637a:	49 83 c4 01          	add    r12,0x1
   2637e:	49 89 c5             	mov    r13,rax
   26381:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   26385:	ff e0                	jmp    rax
   26387:	f3 0f 1e fa          	endbr64
   2638b:	48 8b 4b f0          	mov    rcx,QWORD PTR [rbx-0x10]
   2638f:	48 8b 73 e0          	mov    rsi,QWORD PTR [rbx-0x20]
   26393:	48 8b 53 e8          	mov    rdx,QWORD PTR [rbx-0x18]
   26397:	4c 8b 43 f8          	mov    r8,QWORD PTR [rbx-0x8]
   2639b:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   263a2:	e8 29 af 00 00       	call   312d0 <JS_CheckBrand>
   263a7:	85 c0                	test   eax,eax
   263a9:	0f 88 f1 ce ff ff    	js     232a0 <JS_CallInternal+0x7a0>
   263af:	0f 84 0f 63 00 00    	je     2c6c4 <JS_CallInternal+0x9bc4>
   263b5:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   263ba:	49 83 c4 01          	add    r12,0x1
   263be:	49 89 c5             	mov    r13,rax
   263c1:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   263c5:	ff e0                	jmp    rax
   263c7:	f3 0f 1e fa          	endbr64
   263cb:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   263d2:	83 bd 80 fe ff ff 03 	cmp    DWORD PTR [rbp-0x180],0x3
   263d9:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   263dd:	0f 84 07 5c 00 00    	je     2bfea <JS_CallInternal+0x94ea>
   263e3:	48 8b b5 e0 fe ff ff 	mov    rsi,QWORD PTR [rbp-0x120]
   263ea:	48 8b 95 d0 fe ff ff 	mov    rdx,QWORD PTR [rbp-0x130]
   263f1:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   263f8:	e8 03 c0 ff ff       	call   22400 <JS_GetPrototype>
   263fd:	49 89 c6             	mov    r14,rax
   26400:	49 89 d5             	mov    r13,rdx
   26403:	83 fa 06             	cmp    edx,0x6
   26406:	0f 84 94 ce ff ff    	je     232a0 <JS_CallInternal+0x7a0>
   2640c:	6a 02                	push   0x2
   2640e:	44 8b 8d bc fe ff ff 	mov    r9d,DWORD PTR [rbp-0x144]
   26415:	48 89 c6             	mov    rsi,rax
   26418:	ff b5 a8 fe ff ff    	push   QWORD PTR [rbp-0x158]
   2641e:	48 8b 8d 70 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x190]
   26425:	4c 8b 85 80 fe ff ff 	mov    r8,QWORD PTR [rbp-0x180]
   2642c:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   26433:	e8 a8 ab 06 00       	call   90fe0 <JS_CallConstructorInternal>
   26438:	41 58                	pop    r8
   2643a:	41 59                	pop    r9
   2643c:	48 89 d1             	mov    rcx,rdx
   2643f:	41 83 fd f6          	cmp    r13d,0xfffffff6
   26443:	76 13                	jbe    26458 <JS_CallInternal+0x3958>
   26445:	41 8b 7e fc          	mov    edi,DWORD PTR [r14-0x4]
   26449:	8d 57 ff             	lea    edx,[rdi-0x1]
   2644c:	41 89 56 fc          	mov    DWORD PTR [r14-0x4],edx
   26450:	85 d2                	test   edx,edx
   26452:	0f 8e 26 45 00 00    	jle    2a97e <JS_CallInternal+0x7e7e>
   26458:	83 f9 06             	cmp    ecx,0x6
   2645b:	0f 84 3f ce ff ff    	je     232a0 <JS_CallInternal+0x7a0>
   26461:	48 89 03             	mov    QWORD PTR [rbx],rax
   26464:	49 83 c4 01          	add    r12,0x1
   26468:	48 83 c3 10          	add    rbx,0x10
   2646c:	48 89 4b f8          	mov    QWORD PTR [rbx-0x8],rcx
   26470:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   26476:	49 89 c5             	mov    r13,rax
   26479:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   2647d:	ff e0                	jmp    rax
   2647f:	f3 0f 1e fa          	endbr64
   26483:	83 bd 80 fe ff ff 03 	cmp    DWORD PTR [rbp-0x180],0x3
   2648a:	0f 84 5a 5b 00 00    	je     2bfea <JS_CallInternal+0x94ea>
   26490:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   26495:	49 83 c4 01          	add    r12,0x1
   26499:	49 89 c5             	mov    r13,rax
   2649c:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   264a0:	ff e0                	jmp    rax
   264a2:	f3 0f 1e fa          	endbr64
   264a6:	48 8b 43 f8          	mov    rax,QWORD PTR [rbx-0x8]
   264aa:	83 f8 ff             	cmp    eax,0xffffffff
   264ad:	0f 84 1f 35 00 00    	je     299d2 <JS_CallInternal+0x6ed2>
   264b3:	83 f8 03             	cmp    eax,0x3
   264b6:	0f 85 2d 5e 00 00    	jne    2c2e9 <JS_CallInternal+0x97e9>
   264bc:	b8 01 00 00 00       	mov    eax,0x1
   264c1:	48 89 03             	mov    QWORD PTR [rbx],rax
   264c4:	49 83 c4 01          	add    r12,0x1
   264c8:	48 83 c3 10          	add    rbx,0x10
   264cc:	48 c7 43 f8 01 00 00 	mov    QWORD PTR [rbx-0x8],0x1
   264d3:	00 
   264d4:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   264da:	49 89 c5             	mov    r13,rax
   264dd:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   264e1:	ff e0                	jmp    rax
   264e3:	f3 0f 1e fa          	endbr64
   264e7:	b9 03 00 00 00       	mov    ecx,0x3
   264ec:	31 c0                	xor    eax,eax
   264ee:	e9 00 cd ff ff       	jmp    231f3 <JS_CallInternal+0x6f3>
   264f3:	f3 0f 1e fa          	endbr64
   264f7:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   264fc:	48 8b 8d d8 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x128]
   26503:	4d 8d 6c 24 01       	lea    r13,[r12+0x1]
   26508:	48 c1 e0 04          	shl    rax,0x4
   2650c:	48 03 41 50          	add    rax,QWORD PTR [rcx+0x50]
   26510:	48 8b 50 08          	mov    rdx,QWORD PTR [rax+0x8]
   26514:	48 8b 30             	mov    rsi,QWORD PTR [rax]
   26517:	83 fa f6             	cmp    edx,0xfffffff6
   2651a:	76 04                	jbe    26520 <JS_CallInternal+0x3a20>
   2651c:	83 46 fc 01          	add    DWORD PTR [rsi-0x4],0x1
   26520:	4c 8b 85 c8 fe ff ff 	mov    r8,QWORD PTR [rbp-0x138]
   26527:	48 8b 8d 98 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x168]
   2652e:	45 31 c9             	xor    r9d,r9d
   26531:	4c 8d 73 10          	lea    r14,[rbx+0x10]
   26535:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2653c:	e8 3f 54 02 00       	call   4b980 <js_closure>
   26541:	48 89 53 08          	mov    QWORD PTR [rbx+0x8],rdx
   26545:	83 7b 08 06          	cmp    DWORD PTR [rbx+0x8],0x6
   26549:	48 89 03             	mov    QWORD PTR [rbx],rax
   2654c:	0f 84 7e 49 00 00    	je     2aed0 <JS_CallInternal+0x83d0>
   26552:	41 0f b6 44 24 01    	movzx  eax,BYTE PTR [r12+0x1]
   26558:	4c 89 f3             	mov    rbx,r14
   2655b:	49 83 c4 02          	add    r12,0x2
   2655f:	49 89 c5             	mov    r13,rax
   26562:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   26566:	ff e0                	jmp    rax
   26568:	f3 0f 1e fa          	endbr64
   2656c:	48 8b 8d d8 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x128]
   26573:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   26578:	48 c1 e0 04          	shl    rax,0x4
   2657c:	48 03 41 50          	add    rax,QWORD PTR [rcx+0x50]
   26580:	48 8d 4b 10          	lea    rcx,[rbx+0x10]
   26584:	48 8b 10             	mov    rdx,QWORD PTR [rax]
   26587:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
   2658b:	83 f8 f6             	cmp    eax,0xfffffff6
   2658e:	76 04                	jbe    26594 <JS_CallInternal+0x3a94>
   26590:	83 42 fc 01          	add    DWORD PTR [rdx-0x4],0x1
   26594:	48 89 13             	mov    QWORD PTR [rbx],rdx
   26597:	49 83 c4 02          	add    r12,0x2
   2659b:	48 89 43 08          	mov    QWORD PTR [rbx+0x8],rax
   2659f:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   265a5:	48 89 cb             	mov    rbx,rcx
   265a8:	49 89 c5             	mov    r13,rax
   265ab:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   265af:	ff e0                	jmp    rax
   265b1:	f3 0f 1e fa          	endbr64
   265b5:	41 0f bf 04 24       	movsx  eax,WORD PTR [r12]
   265ba:	48 83 c3 10          	add    rbx,0x10
   265be:	49 83 c4 03          	add    r12,0x3
   265c2:	48 c7 43 f8 00 00 00 	mov    QWORD PTR [rbx-0x8],0x0
   265c9:	00 
   265ca:	48 89 43 f0          	mov    QWORD PTR [rbx-0x10],rax
   265ce:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   265d4:	49 89 c5             	mov    r13,rax
   265d7:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   265db:	ff e0                	jmp    rax
   265dd:	f3 0f 1e fa          	endbr64
   265e1:	41 0f be 04 24       	movsx  eax,BYTE PTR [r12]
   265e6:	48 83 c3 10          	add    rbx,0x10
   265ea:	49 83 c4 02          	add    r12,0x2
   265ee:	48 c7 43 f8 00 00 00 	mov    QWORD PTR [rbx-0x8],0x0
   265f5:	00 
   265f6:	48 89 43 f0          	mov    QWORD PTR [rbx-0x10],rax
   265fa:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   26600:	49 89 c5             	mov    r13,rax
   26603:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   26607:	ff e0                	jmp    rax
   26609:	f3 0f 1e fa          	endbr64
   2660d:	e9 d6 c7 ff ff       	jmp    22de8 <JS_CallInternal+0x2e8>
   26612:	f3 0f 1e fa          	endbr64
   26616:	e9 cd c7 ff ff       	jmp    22de8 <JS_CallInternal+0x2e8>
   2661b:	f3 0f 1e fa          	endbr64
   2661f:	e9 c4 c7 ff ff       	jmp    22de8 <JS_CallInternal+0x2e8>
   26624:	f3 0f 1e fa          	endbr64
   26628:	e9 bb c7 ff ff       	jmp    22de8 <JS_CallInternal+0x2e8>
   2662d:	f3 0f 1e fa          	endbr64
   26631:	e9 b2 c7 ff ff       	jmp    22de8 <JS_CallInternal+0x2e8>
   26636:	f3 0f 1e fa          	endbr64
   2663a:	e9 a9 c7 ff ff       	jmp    22de8 <JS_CallInternal+0x2e8>
   2663f:	f3 0f 1e fa          	endbr64
   26643:	e9 a0 c7 ff ff       	jmp    22de8 <JS_CallInternal+0x2e8>
   26648:	f3 0f 1e fa          	endbr64
   2664c:	48 8b 8d d8 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x128]
   26653:	41 8b 04 24          	mov    eax,DWORD PTR [r12]
   26657:	48 c1 e0 04          	shl    rax,0x4
   2665b:	48 03 41 50          	add    rax,QWORD PTR [rcx+0x50]
   2665f:	48 8d 4b 10          	lea    rcx,[rbx+0x10]
   26663:	48 8b 10             	mov    rdx,QWORD PTR [rax]
   26666:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
   2666a:	83 f8 f6             	cmp    eax,0xfffffff6
   2666d:	76 04                	jbe    26673 <JS_CallInternal+0x3b73>
   2666f:	83 42 fc 01          	add    DWORD PTR [rdx-0x4],0x1
   26673:	48 89 13             	mov    QWORD PTR [rbx],rdx
   26676:	49 83 c4 05          	add    r12,0x5
   2667a:	48 89 43 08          	mov    QWORD PTR [rbx+0x8],rax
   2667e:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   26684:	48 89 cb             	mov    rbx,rcx
   26687:	49 89 c5             	mov    r13,rax
   2668a:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   2668e:	ff e0                	jmp    rax
   26690:	f3 0f 1e fa          	endbr64
   26694:	49 63 04 24          	movsxd rax,DWORD PTR [r12]
   26698:	48 c7 43 08 07 00 00 	mov    QWORD PTR [rbx+0x8],0x7
   2669f:	00 
   266a0:	49 83 c4 05          	add    r12,0x5
   266a4:	48 83 c3 10          	add    rbx,0x10
   266a8:	48 89 43 f0          	mov    QWORD PTR [rbx-0x10],rax
   266ac:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   266b2:	49 89 c5             	mov    r13,rax
   266b5:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   266b9:	ff e0                	jmp    rax
   266bb:	f3 0f 1e fa          	endbr64
   266bf:	41 8b 04 24          	mov    eax,DWORD PTR [r12]
   266c3:	48 c7 43 08 00 00 00 	mov    QWORD PTR [rbx+0x8],0x0
   266ca:	00 
   266cb:	49 83 c4 05          	add    r12,0x5
   266cf:	48 83 c3 10          	add    rbx,0x10
   266d3:	48 89 43 f0          	mov    QWORD PTR [rbx-0x10],rax
   266d7:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   266dd:	49 89 c5             	mov    r13,rax
   266e0:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   266e4:	ff e0                	jmp    rax
   266e6:	f3 0f 1e fa          	endbr64
   266ea:	48 c7 03 00 00 00 00 	mov    QWORD PTR [rbx],0x0
   266f1:	49 83 c4 01          	add    r12,0x1
   266f5:	48 83 c3 10          	add    rbx,0x10
   266f9:	48 c7 43 f8 02 00 00 	mov    QWORD PTR [rbx-0x8],0x2
   26700:	00 
   26701:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   26707:	49 89 c5             	mov    r13,rax
   2670a:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   2670e:	ff e0                	jmp    rax
   26710:	f3 0f 1e fa          	endbr64
   26714:	48 c7 03 00 00 00 00 	mov    QWORD PTR [rbx],0x0
   2671b:	49 83 c4 01          	add    r12,0x1
   2671f:	48 83 c3 10          	add    rbx,0x10
   26723:	48 c7 43 f8 03 00 00 	mov    QWORD PTR [rbx-0x8],0x3
   2672a:	00 
   2672b:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   26731:	49 89 c5             	mov    r13,rax
   26734:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   26738:	ff e0                	jmp    rax
   2673a:	f3 0f 1e fa          	endbr64
   2673e:	41 8b 34 24          	mov    esi,DWORD PTR [r12]
   26742:	31 d2                	xor    edx,edx
   26744:	4c 8d 73 10          	lea    r14,[rbx+0x10]
   26748:	49 83 c4 05          	add    r12,0x5
   2674c:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   26753:	e8 c8 d8 00 00       	call   34020 <__JS_AtomToValue>
   26758:	48 89 03             	mov    QWORD PTR [rbx],rax
   2675b:	48 89 53 08          	mov    QWORD PTR [rbx+0x8],rdx
   2675f:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   26765:	4c 89 f3             	mov    rbx,r14
   26768:	49 89 c5             	mov    r13,rax
   2676b:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   2676f:	ff e0                	jmp    rax
   26771:	f3 0f 1e fa          	endbr64
   26775:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2677c:	ba 01 00 00 00       	mov    edx,0x1
   26781:	4c 8d 73 10          	lea    r14,[rbx+0x10]
   26785:	49 83 c4 01          	add    r12,0x1
   26789:	be 2f 00 00 00       	mov    esi,0x2f
   2678e:	e8 8d d8 00 00       	call   34020 <__JS_AtomToValue>
   26793:	48 89 03             	mov    QWORD PTR [rbx],rax
   26796:	48 89 53 08          	mov    QWORD PTR [rbx+0x8],rdx
   2679a:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   267a0:	4c 89 f3             	mov    rbx,r14
   267a3:	49 89 c5             	mov    r13,rax
   267a6:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   267aa:	ff e0                	jmp    rax
   267ac:	f3 0f 1e fa          	endbr64
   267b0:	48 8b 53 f8          	mov    rdx,QWORD PTR [rbx-0x8]
   267b4:	0b 53 e8             	or     edx,DWORD PTR [rbx-0x18]
   267b7:	48 8b 43 e0          	mov    rax,QWORD PTR [rbx-0x20]
   267bb:	48 8b 4b f0          	mov    rcx,QWORD PTR [rbx-0x10]
   267bf:	0f 85 32 4d 00 00    	jne    2b4f7 <JS_CallInternal+0x89f7>
   267c5:	21 c8                	and    eax,ecx
   267c7:	48 c7 43 e8 00 00 00 	mov    QWORD PTR [rbx-0x18],0x0
   267ce:	00 
   267cf:	48 83 eb 10          	sub    rbx,0x10
   267d3:	48 89 43 f0          	mov    QWORD PTR [rbx-0x10],rax
   267d7:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   267dc:	49 83 c4 01          	add    r12,0x1
   267e0:	49 89 c5             	mov    r13,rax
   267e3:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   267e7:	ff e0                	jmp    rax
   267e9:	f3 0f 1e fa          	endbr64
   267ed:	48 8b 53 f8          	mov    rdx,QWORD PTR [rbx-0x8]
   267f1:	0b 53 e8             	or     edx,DWORD PTR [rbx-0x18]
   267f4:	48 8b 43 e0          	mov    rax,QWORD PTR [rbx-0x20]
   267f8:	48 8b 4b f0          	mov    rcx,QWORD PTR [rbx-0x10]
   267fc:	0f 85 4b 48 00 00    	jne    2b04d <JS_CallInternal+0x854d>
   26802:	d3 f8                	sar    eax,cl
   26804:	48 c7 43 e8 00 00 00 	mov    QWORD PTR [rbx-0x18],0x0
   2680b:	00 
   2680c:	48 83 eb 10          	sub    rbx,0x10
   26810:	48 89 43 f0          	mov    QWORD PTR [rbx-0x10],rax
   26814:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   26819:	49 83 c4 01          	add    r12,0x1
   2681d:	49 89 c5             	mov    r13,rax
   26820:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   26824:	ff e0                	jmp    rax
   26826:	f3 0f 1e fa          	endbr64
   2682a:	48 8b 53 f8          	mov    rdx,QWORD PTR [rbx-0x8]
   2682e:	0b 53 e8             	or     edx,DWORD PTR [rbx-0x18]
   26831:	48 8b 43 e0          	mov    rax,QWORD PTR [rbx-0x20]
   26835:	48 8b 4b f0          	mov    rcx,QWORD PTR [rbx-0x10]
   26839:	0f 85 34 50 00 00    	jne    2b873 <JS_CallInternal+0x8d73>
   2683f:	d3 e8                	shr    eax,cl
   26841:	85 c0                	test   eax,eax
   26843:	0f 88 41 30 00 00    	js     2988a <JS_CallInternal+0x6d8a>
   26849:	66 0f 6e c0          	movd   xmm0,eax
   2684d:	31 c0                	xor    eax,eax
   2684f:	48 89 43 e8          	mov    QWORD PTR [rbx-0x18],rax
   26853:	48 83 eb 10          	sub    rbx,0x10
   26857:	66 0f d6 43 f0       	movq   QWORD PTR [rbx-0x10],xmm0
   2685c:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   26861:	49 83 c4 01          	add    r12,0x1
   26865:	49 89 c5             	mov    r13,rax
   26868:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   2686c:	ff e0                	jmp    rax
   2686e:	f3 0f 1e fa          	endbr64
   26872:	49 63 04 24          	movsxd rax,DWORD PTR [r12]
   26876:	48 8b 8d d8 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x128]
   2687d:	49 8d 54 24 04       	lea    rdx,[r12+0x4]
   26882:	48 83 c3 10          	add    rbx,0x10
   26886:	2b 51 18             	sub    edx,DWORD PTR [rcx+0x18]
   26889:	4c 01 e0             	add    rax,r12
   2688c:	48 c7 43 f8 00 00 00 	mov    QWORD PTR [rbx-0x8],0x0
   26893:	00 
   26894:	48 89 53 f0          	mov    QWORD PTR [rbx-0x10],rdx
   26898:	4c 8d 60 01          	lea    r12,[rax+0x1]
   2689c:	0f b6 00             	movzx  eax,BYTE PTR [rax]
   2689f:	49 89 c5             	mov    r13,rax
   268a2:	41 ff 24 c7          	jmp    QWORD PTR [r15+rax*8]
   268a6:	f3 0f 1e fa          	endbr64
   268aa:	49 63 04 24          	movsxd rax,DWORD PTR [r12]
   268ae:	48 8b 8d d8 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x128]
   268b5:	48 83 c3 10          	add    rbx,0x10
   268b9:	4c 01 e0             	add    rax,r12
   268bc:	2b 41 18             	sub    eax,DWORD PTR [rcx+0x18]
   268bf:	48 c7 43 f8 05 00 00 	mov    QWORD PTR [rbx-0x8],0x5
   268c6:	00 
   268c7:	49 83 c4 05          	add    r12,0x5
   268cb:	48 89 43 f0          	mov    QWORD PTR [rbx-0x10],rax
   268cf:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   268d5:	49 89 c5             	mov    r13,rax
   268d8:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   268dc:	ff e0                	jmp    rax
   268de:	f3 0f 1e fa          	endbr64
   268e2:	4c 8b 73 e0          	mov    r14,QWORD PTR [rbx-0x20]
   268e6:	4c 8b 4b f0          	mov    r9,QWORD PTR [rbx-0x10]
   268ea:	4c 8b 43 f8          	mov    r8,QWORD PTR [rbx-0x8]
   268ee:	4c 8b 6b e8          	mov    r13,QWORD PTR [rbx-0x18]
   268f2:	4c 89 f7             	mov    rdi,r14
   268f5:	4c 89 ce             	mov    rsi,r9
   268f8:	4c 89 c0             	mov    rax,r8
   268fb:	45 85 ed             	test   r13d,r13d
   268fe:	0f 85 8c 47 00 00    	jne    2b090 <JS_CallInternal+0x8590>
   26904:	45 85 c0             	test   r8d,r8d
   26907:	0f 85 87 2d 00 00    	jne    29694 <JS_CallInternal+0x6b94>
   2690d:	31 c0                	xor    eax,eax
   2690f:	45 39 ce             	cmp    r14d,r9d
   26912:	0f 94 c0             	sete   al
   26915:	83 f8 01             	cmp    eax,0x1
   26918:	48 c7 43 e8 01 00 00 	mov    QWORD PTR [rbx-0x18],0x1
   2691f:	00 
   26920:	0f 95 c0             	setne  al
   26923:	0f b6 c0             	movzx  eax,al
   26926:	48 89 43 e0          	mov    QWORD PTR [rbx-0x20],rax
   2692a:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   2692f:	48 83 eb 10          	sub    rbx,0x10
   26933:	49 83 c4 01          	add    r12,0x1
   26937:	49 89 c5             	mov    r13,rax
   2693a:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   2693e:	ff e0                	jmp    rax
   26940:	f3 0f 1e fa          	endbr64
   26944:	4c 8b 73 e0          	mov    r14,QWORD PTR [rbx-0x20]
   26948:	4c 8b 4b f0          	mov    r9,QWORD PTR [rbx-0x10]
   2694c:	4c 8b 43 f8          	mov    r8,QWORD PTR [rbx-0x8]
   26950:	4c 8b 6b e8          	mov    r13,QWORD PTR [rbx-0x18]
   26954:	4c 89 f7             	mov    rdi,r14
   26957:	4c 89 ce             	mov    rsi,r9
   2695a:	4c 89 c0             	mov    rax,r8
   2695d:	45 85 ed             	test   r13d,r13d
   26960:	0f 85 0d 4e 00 00    	jne    2b773 <JS_CallInternal+0x8c73>
   26966:	45 85 c0             	test   r8d,r8d
   26969:	0f 85 f9 2c 00 00    	jne    29668 <JS_CallInternal+0x6b68>
   2696f:	45 39 ce             	cmp    r14d,r9d
   26972:	0f 94 c0             	sete   al
   26975:	0f b6 c0             	movzx  eax,al
   26978:	48 c7 43 e8 01 00 00 	mov    QWORD PTR [rbx-0x18],0x1
   2697f:	00 
   26980:	48 89 43 e0          	mov    QWORD PTR [rbx-0x20],rax
   26984:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   26989:	48 83 eb 10          	sub    rbx,0x10
   2698d:	49 83 c4 01          	add    r12,0x1
   26991:	49 89 c5             	mov    r13,rax
   26994:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   26998:	ff e0                	jmp    rax
   2699a:	f3 0f 1e fa          	endbr64
   2699e:	48 8b 4b f8          	mov    rcx,QWORD PTR [rbx-0x8]
   269a2:	83 7b d8 ff          	cmp    DWORD PTR [rbx-0x28],0xffffffff
   269a6:	4c 8d 73 e0          	lea    r14,[rbx-0x20]
   269aa:	4c 8b 43 d0          	mov    r8,QWORD PTR [rbx-0x30]
   269ae:	48 8b 73 e0          	mov    rsi,QWORD PTR [rbx-0x20]
   269b2:	4c 8b 6b f0          	mov    r13,QWORD PTR [rbx-0x10]
   269b6:	49 8b 46 08          	mov    rax,QWORD PTR [r14+0x8]
   269ba:	48 89 8d 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],rcx
   269c1:	0f 85 5e 4b 00 00    	jne    2b525 <JS_CallInternal+0x8a25>
   269c7:	83 f8 f8             	cmp    eax,0xfffffff8
   269ca:	0f 85 c0 4a 00 00    	jne    2b490 <JS_CallInternal+0x8990>
   269d0:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   269d7:	4c 89 85 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],r8
   269de:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   269e2:	e8 69 01 ff ff       	call   16b50 <js_get_atom_index>
   269e7:	4c 8b 85 40 fe ff ff 	mov    r8,QWORD PTR [rbp-0x1c0]
   269ee:	89 c6                	mov    esi,eax
   269f0:	49 8b 48 18          	mov    rcx,QWORD PTR [r8+0x18]
   269f4:	89 f2                	mov    edx,esi
   269f6:	8b 41 18             	mov    eax,DWORD PTR [rcx+0x18]
   269f9:	21 c2                	and    edx,eax
   269fb:	8b 54 91 38          	mov    edx,DWORD PTR [rcx+rdx*4+0x38]
   269ff:	48 85 d2             	test   rdx,rdx
   26a02:	0f 84 4d 27 00 00    	je     29155 <JS_CallInternal+0x6655>
   26a08:	48 8d 3c 85 34 00 00 	lea    rdi,[rax*4+0x34]
   26a0f:	00 
   26a10:	48 8d 04 d7          	lea    rax,[rdi+rdx*8]
   26a14:	48 01 c8             	add    rax,rcx
   26a17:	3b 70 04             	cmp    esi,DWORD PTR [rax+0x4]
   26a1a:	0f 85 27 27 00 00    	jne    29147 <JS_CallInternal+0x6647>
   26a20:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   26a27:	48 8d 0d 16 67 0a 00 	lea    rcx,[rip+0xa6716]        # cd144 <_IO_stdin_used+0x144>
   26a2e:	48 8d 15 03 a4 0a 00 	lea    rdx,[rip+0xaa403]        # d0e38 <_IO_stdin_used+0x3e38>
   26a35:	31 c0                	xor    eax,eax
   26a37:	e8 24 a4 00 00       	call   30e60 <__JS_ThrowTypeErrorAtom>
   26a3c:	83 bd 50 fe ff ff f6 	cmp    DWORD PTR [rbp-0x1b0],0xfffffff6
   26a43:	76 13                	jbe    26a58 <JS_CallInternal+0x3f58>
   26a45:	41 8b 45 fc          	mov    eax,DWORD PTR [r13-0x4]
   26a49:	83 e8 01             	sub    eax,0x1
   26a4c:	41 89 45 fc          	mov    DWORD PTR [r13-0x4],eax
   26a50:	85 c0                	test   eax,eax
   26a52:	0f 8e 2f 5c 00 00    	jle    2c687 <JS_CallInternal+0x9b87>
   26a58:	49 8b 56 08          	mov    rdx,QWORD PTR [r14+0x8]
   26a5c:	49 8b 36             	mov    rsi,QWORD PTR [r14]
   26a5f:	4c 89 f3             	mov    rbx,r14
   26a62:	83 fa f6             	cmp    edx,0xfffffff6
   26a65:	0f 86 35 c8 ff ff    	jbe    232a0 <JS_CallInternal+0x7a0>
   26a6b:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   26a6e:	83 e8 01             	sub    eax,0x1
   26a71:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   26a74:	85 c0                	test   eax,eax
   26a76:	0f 8f 24 c8 ff ff    	jg     232a0 <JS_CallInternal+0x7a0>
   26a7c:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   26a83:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   26a87:	e8 14 5e ff ff       	call   1c8a0 <__JS_FreeValueRT>
   26a8c:	e9 0f c8 ff ff       	jmp    232a0 <JS_CallInternal+0x7a0>
   26a91:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]
   26a98:	f3 0f 1e fa          	endbr64
   26a9c:	48 8d 43 e0          	lea    rax,[rbx-0x20]
   26aa0:	4c 8d 73 f0          	lea    r14,[rbx-0x10]
   26aa4:	4c 8b 28             	mov    r13,QWORD PTR [rax]
   26aa7:	48 83 eb 30          	sub    rbx,0x30
   26aab:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
   26aaf:	83 7b 08 ff          	cmp    DWORD PTR [rbx+0x8],0xffffffff
   26ab3:	48 8b 13             	mov    rdx,QWORD PTR [rbx]
   26ab6:	49 8b 36             	mov    rsi,QWORD PTR [r14]
   26ab9:	48 89 85 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],rax
   26ac0:	49 8b 4e 08          	mov    rcx,QWORD PTR [r14+0x8]
   26ac4:	0f 85 e0 49 00 00    	jne    2b4aa <JS_CallInternal+0x89aa>
   26aca:	83 f9 f8             	cmp    ecx,0xfffffff8
   26acd:	0f 85 86 4c 00 00    	jne    2b759 <JS_CallInternal+0x8c59>
   26ad3:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   26ada:	48 89 95 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],rdx
   26ae1:	48 8b 40 10          	mov    rax,QWORD PTR [rax+0x10]
   26ae5:	48 89 c7             	mov    rdi,rax
   26ae8:	48 89 85 38 fe ff ff 	mov    QWORD PTR [rbp-0x1c8],rax
   26aef:	e8 5c 00 ff ff       	call   16b50 <js_get_atom_index>
   26af4:	48 8b 95 40 fe ff ff 	mov    rdx,QWORD PTR [rbp-0x1c0]
   26afb:	89 c6                	mov    esi,eax
   26afd:	48 8b 7a 18          	mov    rdi,QWORD PTR [rdx+0x18]
   26b01:	8b 4f 18             	mov    ecx,DWORD PTR [rdi+0x18]
   26b04:	21 c8                	and    eax,ecx
   26b06:	8b 44 87 38          	mov    eax,DWORD PTR [rdi+rax*4+0x38]
   26b0a:	48 85 c0             	test   rax,rax
   26b0d:	0f 84 cc 4f 00 00    	je     2badf <JS_CallInternal+0x8fdf>
   26b13:	4c 8d 04 8d 34 00 00 	lea    r8,[rcx*4+0x34]
   26b1a:	00 
   26b1b:	49 8d 0c c0          	lea    rcx,[r8+rax*8]
   26b1f:	48 01 f9             	add    rcx,rdi
   26b22:	3b 71 04             	cmp    esi,DWORD PTR [rcx+0x4]
   26b25:	0f 85 a7 4f 00 00    	jne    2bad2 <JS_CallInternal+0x8fd2>
   26b2b:	48 8b 52 20          	mov    rdx,QWORD PTR [rdx+0x20]
   26b2f:	48 c1 e0 04          	shl    rax,0x4
   26b33:	48 8b 8d 50 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x1b0]
   26b3a:	48 8d 44 02 f0       	lea    rax,[rdx+rax*1-0x10]
   26b3f:	48 8b 50 08          	mov    rdx,QWORD PTR [rax+0x8]
   26b43:	48 8b 30             	mov    rsi,QWORD PTR [rax]
   26b46:	48 89 48 08          	mov    QWORD PTR [rax+0x8],rcx
   26b4a:	4c 89 28             	mov    QWORD PTR [rax],r13
   26b4d:	83 fa f6             	cmp    edx,0xfffffff6
   26b50:	76 11                	jbe    26b63 <JS_CallInternal+0x4063>
   26b52:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   26b55:	83 e8 01             	sub    eax,0x1
   26b58:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   26b5b:	85 c0                	test   eax,eax
   26b5d:	0f 8e 83 49 00 00    	jle    2b4e6 <JS_CallInternal+0x89e6>
   26b63:	45 31 ed             	xor    r13d,r13d
   26b66:	48 8b 53 08          	mov    rdx,QWORD PTR [rbx+0x8]
   26b6a:	48 8b 33             	mov    rsi,QWORD PTR [rbx]
   26b6d:	83 fa f6             	cmp    edx,0xfffffff6
   26b70:	76 11                	jbe    26b83 <JS_CallInternal+0x4083>
   26b72:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   26b75:	83 e8 01             	sub    eax,0x1
   26b78:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   26b7b:	85 c0                	test   eax,eax
   26b7d:	0f 8e d6 38 00 00    	jle    2a459 <JS_CallInternal+0x7959>
   26b83:	49 8b 56 08          	mov    rdx,QWORD PTR [r14+0x8]
   26b87:	49 8b 36             	mov    rsi,QWORD PTR [r14]
   26b8a:	83 fa f6             	cmp    edx,0xfffffff6
   26b8d:	76 11                	jbe    26ba0 <JS_CallInternal+0x40a0>
   26b8f:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   26b92:	83 e8 01             	sub    eax,0x1
   26b95:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   26b98:	85 c0                	test   eax,eax
   26b9a:	0f 8e e3 38 00 00    	jle    2a483 <JS_CallInternal+0x7983>
   26ba0:	41 83 fd ff          	cmp    r13d,0xffffffff
   26ba4:	0f 84 f6 c6 ff ff    	je     232a0 <JS_CallInternal+0x7a0>
   26baa:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   26baf:	49 83 c4 01          	add    r12,0x1
   26bb3:	49 89 c5             	mov    r13,rax
   26bb6:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   26bba:	ff e0                	jmp    rax
   26bbc:	f3 0f 1e fa          	endbr64
   26bc0:	44 8b 4b f8          	mov    r9d,DWORD PTR [rbx-0x8]
   26bc4:	48 8b 43 f0          	mov    rax,QWORD PTR [rbx-0x10]
   26bc8:	45 85 c9             	test   r9d,r9d
   26bcb:	0f 85 60 2c 00 00    	jne    29831 <JS_CallInternal+0x6d31>
   26bd1:	3d ff ff ff 7f       	cmp    eax,0x7fffffff
   26bd6:	0f 84 55 2c 00 00    	je     29831 <JS_CallInternal+0x6d31>
   26bdc:	83 c0 01             	add    eax,0x1
   26bdf:	48 c7 43 08 00 00 00 	mov    QWORD PTR [rbx+0x8],0x0
   26be6:	00 
   26be7:	48 89 03             	mov    QWORD PTR [rbx],rax
   26bea:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   26bef:	48 83 c3 10          	add    rbx,0x10
   26bf3:	49 83 c4 01          	add    r12,0x1
   26bf7:	49 89 c5             	mov    r13,rax
   26bfa:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   26bfe:	ff e0                	jmp    rax
   26c00:	f3 0f 1e fa          	endbr64
   26c04:	44 8b 53 f8          	mov    r10d,DWORD PTR [rbx-0x8]
   26c08:	48 8b 43 f0          	mov    rax,QWORD PTR [rbx-0x10]
   26c0c:	45 85 d2             	test   r10d,r10d
   26c0f:	0f 85 7b 2b 00 00    	jne    29790 <JS_CallInternal+0x6c90>
   26c15:	3d 00 00 00 80       	cmp    eax,0x80000000
   26c1a:	0f 84 70 2b 00 00    	je     29790 <JS_CallInternal+0x6c90>
   26c20:	83 e8 01             	sub    eax,0x1
   26c23:	48 c7 43 f8 00 00 00 	mov    QWORD PTR [rbx-0x8],0x0
   26c2a:	00 
   26c2b:	48 89 43 f0          	mov    QWORD PTR [rbx-0x10],rax
   26c2f:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   26c34:	49 83 c4 01          	add    r12,0x1
   26c38:	49 89 c5             	mov    r13,rax
   26c3b:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   26c3f:	ff e0                	jmp    rax
   26c41:	f3 0f 1e fa          	endbr64
   26c45:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   26c4c:	4c 8b 73 f8          	mov    r14,QWORD PTR [rbx-0x8]
   26c50:	48 8b 73 f0          	mov    rsi,QWORD PTR [rbx-0x10]
   26c54:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   26c58:	41 83 fe ff          	cmp    r14d,0xffffffff
   26c5c:	0f 85 c5 56 00 00    	jne    2c327 <JS_CallInternal+0x9827>
   26c62:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   26c69:	48 8d 8d f0 fe ff ff 	lea    rcx,[rbp-0x110]
   26c70:	4c 89 f2             	mov    rdx,r14
   26c73:	48 89 b5 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],rsi
   26c7a:	e8 d1 66 00 00       	call   2d350 <JS_IteratorGetCompleteValue>
   26c7f:	48 89 c1             	mov    rcx,rax
   26c82:	49 89 d5             	mov    r13,rdx
   26c85:	83 fa 06             	cmp    edx,0x6
   26c88:	0f 84 12 c6 ff ff    	je     232a0 <JS_CallInternal+0x7a0>
   26c8e:	48 8b b5 50 fe ff ff 	mov    rsi,QWORD PTR [rbp-0x1b0]
   26c95:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   26c98:	83 e8 01             	sub    eax,0x1
   26c9b:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   26c9e:	85 c0                	test   eax,eax
   26ca0:	0f 8e 4a 3d 00 00    	jle    2a9f0 <JS_CallInternal+0x7ef0>
   26ca6:	8b bd f0 fe ff ff    	mov    edi,DWORD PTR [rbp-0x110]
   26cac:	31 c0                	xor    eax,eax
   26cae:	4c 89 6b f8          	mov    QWORD PTR [rbx-0x8],r13
   26cb2:	48 c7 43 e0 00 00 00 	mov    QWORD PTR [rbx-0x20],0x0
   26cb9:	00 
   26cba:	85 ff                	test   edi,edi
   26cbc:	48 c7 43 e8 05 00 00 	mov    QWORD PTR [rbx-0x18],0x5
   26cc3:	00 
   26cc4:	0f 95 c0             	setne  al
   26cc7:	48 89 4b f0          	mov    QWORD PTR [rbx-0x10],rcx
   26ccb:	49 83 c4 01          	add    r12,0x1
   26ccf:	48 83 c3 10          	add    rbx,0x10
   26cd3:	48 89 43 f0          	mov    QWORD PTR [rbx-0x10],rax
   26cd7:	48 c7 43 f8 01 00 00 	mov    QWORD PTR [rbx-0x8],0x1
   26cde:	00 
   26cdf:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   26ce5:	49 89 c5             	mov    r13,rax
   26ce8:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   26cec:	ff e0                	jmp    rax
   26cee:	f3 0f 1e fa          	endbr64
   26cf2:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   26cf9:	4c 8b 6b e8          	mov    r13,QWORD PTR [rbx-0x18]
   26cfd:	4c 8b 4b e0          	mov    r9,QWORD PTR [rbx-0x20]
   26d01:	4c 8b 73 f8          	mov    r14,QWORD PTR [rbx-0x8]
   26d05:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   26d09:	48 8b 43 f0          	mov    rax,QWORD PTR [rbx-0x10]
   26d0d:	48 89 85 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],rax
   26d14:	41 83 fd ff          	cmp    r13d,0xffffffff
   26d18:	0f 85 fb 5f 00 00    	jne    2cd19 <JS_CallInternal+0xa219>
   26d1e:	41 83 fe ff          	cmp    r14d,0xffffffff
   26d22:	0f 84 b1 2c 00 00    	je     299d9 <JS_CallInternal+0x6ed9>
   26d28:	48 8b b5 50 fe ff ff 	mov    rsi,QWORD PTR [rbp-0x1b0]
   26d2f:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   26d36:	4c 89 f2             	mov    rdx,r14
   26d39:	4c 89 8d 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],r9
   26d40:	e8 cb c7 01 00       	call   43510 <JS_ValueToAtom>
   26d45:	85 c0                	test   eax,eax
   26d47:	0f 84 53 c5 ff ff    	je     232a0 <JS_CallInternal+0x7a0>
   26d4d:	4c 8b 8d 40 fe ff ff 	mov    r9,QWORD PTR [rbp-0x1c0]
   26d54:	89 c2                	mov    edx,eax
   26d56:	49 8b 49 18          	mov    rcx,QWORD PTR [r9+0x18]
   26d5a:	8b 71 18             	mov    esi,DWORD PTR [rcx+0x18]
   26d5d:	21 f2                	and    edx,esi
   26d5f:	8b 54 91 38          	mov    edx,DWORD PTR [rcx+rdx*4+0x38]
   26d63:	48 85 d2             	test   rdx,rdx
   26d66:	0f 84 79 54 00 00    	je     2c1e5 <JS_CallInternal+0x96e5>
   26d6c:	48 8d 34 b5 34 00 00 	lea    rsi,[rsi*4+0x34]
   26d73:	00 
   26d74:	48 8d 14 d6          	lea    rdx,[rsi+rdx*8]
   26d78:	48 01 ca             	add    rdx,rcx
   26d7b:	3b 42 04             	cmp    eax,DWORD PTR [rdx+0x4]
   26d7e:	0f 85 53 54 00 00    	jne    2c1d7 <JS_CallInternal+0x96d7>
   26d84:	3d f2 00 00 00       	cmp    eax,0xf2
   26d89:	0f 8f 49 35 00 00    	jg     2a2d8 <JS_CallInternal+0x77d8>
   26d8f:	48 85 d2             	test   rdx,rdx
   26d92:	0f 95 c0             	setne  al
   26d95:	41 83 fd f6          	cmp    r13d,0xfffffff6
   26d99:	76 13                	jbe    26dae <JS_CallInternal+0x42ae>
   26d9b:	41 8b 49 fc          	mov    ecx,DWORD PTR [r9-0x4]
   26d9f:	8d 51 ff             	lea    edx,[rcx-0x1]
   26da2:	41 89 51 fc          	mov    DWORD PTR [r9-0x4],edx
   26da6:	85 d2                	test   edx,edx
   26da8:	0f 8e 53 37 00 00    	jle    2a501 <JS_CallInternal+0x7a01>
   26dae:	41 83 fe f6          	cmp    r14d,0xfffffff6
   26db2:	76 1e                	jbe    26dd2 <JS_CallInternal+0x42d2>
   26db4:	48 8b 8d 50 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x1b0]
   26dbb:	8b 79 fc             	mov    edi,DWORD PTR [rcx-0x4]
   26dbe:	8d 57 ff             	lea    edx,[rdi-0x1]
   26dc1:	89 bd 40 fe ff ff    	mov    DWORD PTR [rbp-0x1c0],edi
   26dc7:	89 51 fc             	mov    DWORD PTR [rcx-0x4],edx
   26dca:	85 d2                	test   edx,edx
   26dcc:	0f 8e 3d 39 00 00    	jle    2a70f <JS_CallInternal+0x7c0f>
   26dd2:	0f b6 c0             	movzx  eax,al
   26dd5:	48 c7 43 e8 01 00 00 	mov    QWORD PTR [rbx-0x18],0x1
   26ddc:	00 
   26ddd:	49 83 c4 01          	add    r12,0x1
   26de1:	48 83 eb 10          	sub    rbx,0x10
   26de5:	48 89 43 f0          	mov    QWORD PTR [rbx-0x10],rax
   26de9:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   26def:	49 89 c5             	mov    r13,rax
   26df2:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   26df6:	ff e0                	jmp    rax
   26df8:	f3 0f 1e fa          	endbr64
   26dfc:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   26e03:	4c 8b 6b f8          	mov    r13,QWORD PTR [rbx-0x8]
   26e07:	4c 8b 73 e0          	mov    r14,QWORD PTR [rbx-0x20]
   26e0b:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   26e0f:	48 8b 43 e8          	mov    rax,QWORD PTR [rbx-0x18]
   26e13:	48 89 85 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],rax
   26e1a:	48 8b 43 f0          	mov    rax,QWORD PTR [rbx-0x10]
   26e1e:	48 89 85 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],rax
   26e25:	41 83 fd ff          	cmp    r13d,0xffffffff
   26e29:	0f 85 3d 55 00 00    	jne    2c36c <JS_CallInternal+0x986c>
   26e2f:	48 8b 95 50 fe ff ff 	mov    rdx,QWORD PTR [rbp-0x1b0]
   26e36:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   26e3d:	4c 89 f6             	mov    rsi,r14
   26e40:	e8 cb c6 01 00       	call   43510 <JS_ValueToAtom>
   26e45:	89 c1                	mov    ecx,eax
   26e47:	85 c0                	test   eax,eax
   26e49:	0f 84 51 c4 ff ff    	je     232a0 <JS_CallInternal+0x7a0>
   26e4f:	48 8b b5 40 fe ff ff 	mov    rsi,QWORD PTR [rbp-0x1c0]
   26e56:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   26e5d:	4c 89 ea             	mov    rdx,r13
   26e60:	89 85 38 fe ff ff    	mov    DWORD PTR [rbp-0x1c8],eax
   26e66:	e8 25 74 04 00       	call   6e290 <JS_HasProperty>
   26e6b:	8b 8d 38 fe ff ff    	mov    ecx,DWORD PTR [rbp-0x1c8]
   26e71:	41 89 c0             	mov    r8d,eax
   26e74:	81 f9 f2 00 00 00    	cmp    ecx,0xf2
   26e7a:	0f 8f b9 2e 00 00    	jg     29d39 <JS_CallInternal+0x7239>
   26e80:	45 85 c0             	test   r8d,r8d
   26e83:	0f 88 17 c4 ff ff    	js     232a0 <JS_CallInternal+0x7a0>
   26e89:	83 bd 50 fe ff ff f6 	cmp    DWORD PTR [rbp-0x1b0],0xfffffff6
   26e90:	76 13                	jbe    26ea5 <JS_CallInternal+0x43a5>
   26e92:	41 8b 46 fc          	mov    eax,DWORD PTR [r14-0x4]
   26e96:	83 e8 01             	sub    eax,0x1
   26e99:	41 89 46 fc          	mov    DWORD PTR [r14-0x4],eax
   26e9d:	85 c0                	test   eax,eax
   26e9f:	0f 8e a7 47 00 00    	jle    2b64c <JS_CallInternal+0x8b4c>
   26ea5:	41 83 fd f6          	cmp    r13d,0xfffffff6
   26ea9:	76 1e                	jbe    26ec9 <JS_CallInternal+0x43c9>
   26eab:	48 8b 8d 40 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x1c0]
   26eb2:	8b 41 fc             	mov    eax,DWORD PTR [rcx-0x4]
   26eb5:	89 85 50 fe ff ff    	mov    DWORD PTR [rbp-0x1b0],eax
   26ebb:	83 e8 01             	sub    eax,0x1
   26ebe:	89 41 fc             	mov    DWORD PTR [rcx-0x4],eax
   26ec1:	85 c0                	test   eax,eax
   26ec3:	0f 8e 6f 4b 00 00    	jle    2ba38 <JS_CallInternal+0x8f38>
   26ec9:	31 c0                	xor    eax,eax
   26ecb:	45 85 c0             	test   r8d,r8d
   26ece:	48 c7 43 e8 01 00 00 	mov    QWORD PTR [rbx-0x18],0x1
   26ed5:	00 
   26ed6:	0f 95 c0             	setne  al
   26ed9:	48 83 eb 10          	sub    rbx,0x10
   26edd:	49 83 c4 01          	add    r12,0x1
   26ee1:	48 89 43 f0          	mov    QWORD PTR [rbx-0x10],rax
   26ee5:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   26eeb:	49 89 c5             	mov    r13,rax
   26eee:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   26ef2:	ff e0                	jmp    rax
   26ef4:	f3 0f 1e fa          	endbr64
   26ef8:	48 8b 43 f8          	mov    rax,QWORD PTR [rbx-0x8]
   26efc:	48 8b 73 e8          	mov    rsi,QWORD PTR [rbx-0x18]
   26f00:	48 8b 4b e0          	mov    rcx,QWORD PTR [rbx-0x20]
   26f04:	48 8b 53 f0          	mov    rdx,QWORD PTR [rbx-0x10]
   26f08:	89 c7                	mov    edi,eax
   26f0a:	09 f7                	or     edi,esi
   26f0c:	0f 85 6b 4b 00 00    	jne    2ba7d <JS_CallInternal+0x8f7d>
   26f12:	48 63 f2             	movsxd rsi,edx
   26f15:	48 63 c1             	movsxd rax,ecx
   26f18:	48 0f af c6          	imul   rax,rsi
   26f1c:	48 63 f0             	movsxd rsi,eax
   26f1f:	48 39 c6             	cmp    rsi,rax
   26f22:	0f 85 39 4b 00 00    	jne    2ba61 <JS_CallInternal+0x8f61>
   26f28:	48 85 f6             	test   rsi,rsi
   26f2b:	0f 84 cf 4b 00 00    	je     2bb00 <JS_CallInternal+0x9000>
   26f31:	83 e0 ff             	and    eax,0xffffffff
   26f34:	48 8d 53 f0          	lea    rdx,[rbx-0x10]
   26f38:	48 89 43 e0          	mov    QWORD PTR [rbx-0x20],rax
   26f3c:	31 c0                	xor    eax,eax
   26f3e:	48 89 43 e8          	mov    QWORD PTR [rbx-0x18],rax
   26f42:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   26f47:	48 89 d3             	mov    rbx,rdx
   26f4a:	49 83 c4 01          	add    r12,0x1
   26f4e:	49 89 c5             	mov    r13,rax
   26f51:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   26f55:	ff e0                	jmp    rax
   26f57:	f3 0f 1e fa          	endbr64
   26f5b:	48 8b 43 f8          	mov    rax,QWORD PTR [rbx-0x8]
   26f5f:	48 8b 53 e8          	mov    rdx,QWORD PTR [rbx-0x18]
   26f63:	48 8b 7b e0          	mov    rdi,QWORD PTR [rbx-0x20]
   26f67:	48 8b 4b f0          	mov    rcx,QWORD PTR [rbx-0x10]
   26f6b:	89 c6                	mov    esi,eax
   26f6d:	09 d6                	or     esi,edx
   26f6f:	0f 85 64 46 00 00    	jne    2b5d9 <JS_CallInternal+0x8ad9>
   26f75:	89 fa                	mov    edx,edi
   26f77:	48 63 f1             	movsxd rsi,ecx
   26f7a:	48 63 c7             	movsxd rax,edi
   26f7d:	29 ca                	sub    edx,ecx
   26f7f:	48 29 f0             	sub    rax,rsi
   26f82:	48 63 ca             	movsxd rcx,edx
   26f85:	48 39 c1             	cmp    rcx,rax
   26f88:	0f 85 33 46 00 00    	jne    2b5c1 <JS_CallInternal+0x8ac1>
   26f8e:	89 d0                	mov    eax,edx
   26f90:	48 89 43 e0          	mov    QWORD PTR [rbx-0x20],rax
   26f94:	31 c0                	xor    eax,eax
   26f96:	48 8d 53 f0          	lea    rdx,[rbx-0x10]
   26f9a:	48 89 43 e8          	mov    QWORD PTR [rbx-0x18],rax
   26f9e:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   26fa3:	48 89 d3             	mov    rbx,rdx
   26fa6:	49 83 c4 01          	add    r12,0x1
   26faa:	49 89 c5             	mov    r13,rax
   26fad:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   26fb1:	ff e0                	jmp    rax
   26fb3:	f3 0f 1e fa          	endbr64
   26fb7:	45 0f b6 2c 24       	movzx  r13d,BYTE PTR [r12]
   26fbc:	48 8b 85 b0 fe ff ff 	mov    rax,QWORD PTR [rbp-0x150]
   26fc3:	4d 8d 4c 24 01       	lea    r9,[r12+0x1]
   26fc8:	4c 8b 73 f8          	mov    r14,QWORD PTR [rbx-0x8]
   26fcc:	4c 8b 43 f0          	mov    r8,QWORD PTR [rbx-0x10]
   26fd0:	49 c1 e5 04          	shl    r13,0x4
   26fd4:	49 01 c5             	add    r13,rax
   26fd7:	44 89 f1             	mov    ecx,r14d
   26fda:	49 8b 55 08          	mov    rdx,QWORD PTR [r13+0x8]
   26fde:	09 d1                	or     ecx,edx
   26fe0:	0f 85 cb 43 00 00    	jne    2b3b1 <JS_CallInternal+0x88b1>
   26fe6:	49 8b 45 00          	mov    rax,QWORD PTR [r13+0x0]
   26fea:	49 63 c8             	movsxd rcx,r8d
   26fed:	48 63 d0             	movsxd rdx,eax
   26ff0:	44 01 c0             	add    eax,r8d
   26ff3:	48 01 ca             	add    rdx,rcx
   26ff6:	48 63 c8             	movsxd rcx,eax
   26ff9:	48 39 d1             	cmp    rcx,rdx
   26ffc:	0f 85 96 43 00 00    	jne    2b398 <JS_CallInternal+0x8898>
   27002:	89 c0                	mov    eax,eax
   27004:	49 89 45 00          	mov    QWORD PTR [r13+0x0],rax
   27008:	31 c0                	xor    eax,eax
   2700a:	49 89 45 08          	mov    QWORD PTR [r13+0x8],rax
   2700e:	48 83 eb 10          	sub    rbx,0x10
   27012:	41 0f b6 44 24 01    	movzx  eax,BYTE PTR [r12+0x1]
   27018:	49 83 c4 02          	add    r12,0x2
   2701c:	49 89 c5             	mov    r13,rax
   2701f:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   27023:	ff e0                	jmp    rax
   27025:	f3 0f 1e fa          	endbr64
   27029:	48 8b 7b f8          	mov    rdi,QWORD PTR [rbx-0x8]
   2702d:	4c 8b 5b e8          	mov    r11,QWORD PTR [rbx-0x18]
   27031:	4c 8b 43 f0          	mov    r8,QWORD PTR [rbx-0x10]
   27035:	4c 8b 53 e0          	mov    r10,QWORD PTR [rbx-0x20]
   27039:	41 89 fe             	mov    r14d,edi
   2703c:	4c 89 de             	mov    rsi,r11
   2703f:	48 89 f9             	mov    rcx,rdi
   27042:	45 09 de             	or     r14d,r11d
   27045:	4c 89 c0             	mov    rax,r8
   27048:	0f 85 46 42 00 00    	jne    2b294 <JS_CallInternal+0x8794>
   2704e:	49 63 ca             	movsxd rcx,r10d
   27051:	49 63 f0             	movsxd rsi,r8d
   27054:	44 01 d0             	add    eax,r10d
   27057:	48 01 f1             	add    rcx,rsi
   2705a:	48 63 d0             	movsxd rdx,eax
   2705d:	48 39 ca             	cmp    rdx,rcx
   27060:	0f 85 16 42 00 00    	jne    2b27c <JS_CallInternal+0x877c>
   27066:	89 c0                	mov    eax,eax
   27068:	48 89 43 e0          	mov    QWORD PTR [rbx-0x20],rax
   2706c:	31 c0                	xor    eax,eax
   2706e:	48 89 43 e8          	mov    QWORD PTR [rbx-0x18],rax
   27072:	48 83 eb 10          	sub    rbx,0x10
   27076:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   2707b:	49 83 c4 01          	add    r12,0x1
   2707f:	49 89 c5             	mov    r13,rax
   27082:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   27086:	ff e0                	jmp    rax
   27088:	f3 0f 1e fa          	endbr64
   2708c:	8b 7b f8             	mov    edi,DWORD PTR [rbx-0x8]
   2708f:	48 8b 43 f0          	mov    rax,QWORD PTR [rbx-0x10]
   27093:	85 ff                	test   edi,edi
   27095:	0f 85 1a 2b 00 00    	jne    29bb5 <JS_CallInternal+0x70b5>
   2709b:	f7 d0                	not    eax
   2709d:	48 c7 43 f8 00 00 00 	mov    QWORD PTR [rbx-0x8],0x0
   270a4:	00 
   270a5:	48 89 43 f0          	mov    QWORD PTR [rbx-0x10],rax
   270a9:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   270ae:	49 83 c4 01          	add    r12,0x1
   270b2:	49 89 c5             	mov    r13,rax
   270b5:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   270b9:	ff e0                	jmp    rax
   270bb:	f3 0f 1e fa          	endbr64
   270bf:	45 0f b6 2c 24       	movzx  r13d,BYTE PTR [r12]
   270c4:	48 8b 85 b0 fe ff ff 	mov    rax,QWORD PTR [rbp-0x150]
   270cb:	4d 8d 74 24 01       	lea    r14,[r12+0x1]
   270d0:	49 c1 e5 04          	shl    r13,0x4
   270d4:	49 01 c5             	add    r13,rax
   270d7:	f3 41 0f 6f 6d 00    	movdqu xmm5,XMMWORD PTR [r13+0x0]
   270dd:	0f 29 ad f0 fe ff ff 	movaps XMMWORD PTR [rbp-0x110],xmm5
   270e4:	48 8b 95 f8 fe ff ff 	mov    rdx,QWORD PTR [rbp-0x108]
   270eb:	48 8b 85 f0 fe ff ff 	mov    rax,QWORD PTR [rbp-0x110]
   270f2:	85 d2                	test   edx,edx
   270f4:	0f 85 3e 23 00 00    	jne    29438 <JS_CallInternal+0x6938>
   270fa:	3d 00 00 00 80       	cmp    eax,0x80000000
   270ff:	0f 84 33 23 00 00    	je     29438 <JS_CallInternal+0x6938>
   27105:	83 e8 01             	sub    eax,0x1
   27108:	49 c7 45 08 00 00 00 	mov    QWORD PTR [r13+0x8],0x0
   2710f:	00 
   27110:	49 89 45 00          	mov    QWORD PTR [r13+0x0],rax
   27114:	41 0f b6 44 24 01    	movzx  eax,BYTE PTR [r12+0x1]
   2711a:	49 83 c4 02          	add    r12,0x2
   2711e:	49 89 c5             	mov    r13,rax
   27121:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   27125:	ff e0                	jmp    rax
   27127:	f3 0f 1e fa          	endbr64
   2712b:	48 8b 8d e8 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x118]
   27132:	4d 63 2c 24          	movsxd r13,DWORD PTR [r12]
   27136:	8b 81 a8 01 00 00    	mov    eax,DWORD PTR [rcx+0x1a8]
   2713c:	4d 01 e5             	add    r13,r12
   2713f:	89 85 50 fe ff ff    	mov    DWORD PTR [rbp-0x1b0],eax
   27145:	83 e8 01             	sub    eax,0x1
   27148:	89 81 a8 01 00 00    	mov    DWORD PTR [rcx+0x1a8],eax
   2714e:	85 c0                	test   eax,eax
   27150:	0f 8e 43 40 00 00    	jle    2b199 <JS_CallInternal+0x8699>
   27156:	41 0f b6 45 00       	movzx  eax,BYTE PTR [r13+0x0]
   2715b:	4d 8d 65 01          	lea    r12,[r13+0x1]
   2715f:	49 89 c5             	mov    r13,rax
   27162:	41 ff 24 c7          	jmp    QWORD PTR [r15+rax*8]
   27166:	f3 0f 1e fa          	endbr64
   2716a:	48 8b 4b f8          	mov    rcx,QWORD PTR [rbx-0x8]
   2716e:	48 8b 73 e8          	mov    rsi,QWORD PTR [rbx-0x18]
   27172:	48 8b 43 e0          	mov    rax,QWORD PTR [rbx-0x20]
   27176:	48 8b 53 f0          	mov    rdx,QWORD PTR [rbx-0x10]
   2717a:	89 cf                	mov    edi,ecx
   2717c:	09 f7                	or     edi,esi
   2717e:	0f 85 7a 47 00 00    	jne    2b8fe <JS_CallInternal+0x8dfe>
   27184:	39 d0                	cmp    eax,edx
   27186:	48 c7 43 e8 01 00 00 	mov    QWORD PTR [rbx-0x18],0x1
   2718d:	00 
   2718e:	0f 9e c0             	setle  al
   27191:	48 83 eb 10          	sub    rbx,0x10
   27195:	0f b6 c0             	movzx  eax,al
   27198:	48 89 43 f0          	mov    QWORD PTR [rbx-0x10],rax
   2719c:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   271a1:	49 83 c4 01          	add    r12,0x1
   271a5:	49 89 c5             	mov    r13,rax
   271a8:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   271ac:	ff e0                	jmp    rax
   271ae:	f3 0f 1e fa          	endbr64
   271b2:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   271b9:	4c 8b 73 f8          	mov    r14,QWORD PTR [rbx-0x8]
   271bd:	4c 8b 6b f0          	mov    r13,QWORD PTR [rbx-0x10]
   271c1:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   271c5:	41 83 fe ff          	cmp    r14d,0xffffffff
   271c9:	0f 84 65 24 00 00    	je     29634 <JS_CallInternal+0x6b34>
   271cf:	41 83 fe 02          	cmp    r14d,0x2
   271d3:	0f 84 5b 24 00 00    	je     29634 <JS_CallInternal+0x6b34>
   271d9:	41 83 fe f6          	cmp    r14d,0xfffffff6
   271dd:	76 13                	jbe    271f2 <JS_CallInternal+0x46f2>
   271df:	41 8b 45 fc          	mov    eax,DWORD PTR [r13-0x4]
   271e3:	83 e8 01             	sub    eax,0x1
   271e6:	41 89 45 fc          	mov    DWORD PTR [r13-0x4],eax
   271ea:	85 c0                	test   eax,eax
   271ec:	0f 8e e6 39 00 00    	jle    2abd8 <JS_CallInternal+0x80d8>
   271f2:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   271f7:	48 83 eb 10          	sub    rbx,0x10
   271fb:	49 83 c4 01          	add    r12,0x1
   271ff:	49 89 c5             	mov    r13,rax
   27202:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   27206:	ff e0                	jmp    rax
   27208:	f3 0f 1e fa          	endbr64
   2720c:	48 8b 43 f8          	mov    rax,QWORD PTR [rbx-0x8]
   27210:	0b 43 e8             	or     eax,DWORD PTR [rbx-0x18]
   27213:	48 8b 4b e0          	mov    rcx,QWORD PTR [rbx-0x20]
   27217:	48 8b 53 f0          	mov    rdx,QWORD PTR [rbx-0x10]
   2721b:	0f 85 d6 c9 ff ff    	jne    23bf7 <JS_CallInternal+0x10f7>
   27221:	89 c8                	mov    eax,ecx
   27223:	89 d6                	mov    esi,edx
   27225:	85 c9                	test   ecx,ecx
   27227:	0f 88 ca c9 ff ff    	js     23bf7 <JS_CallInternal+0x10f7>
   2722d:	85 d2                	test   edx,edx
   2722f:	0f 8e c2 c9 ff ff    	jle    23bf7 <JS_CallInternal+0x10f7>
   27235:	99                   	cdq
   27236:	48 c7 43 e8 00 00 00 	mov    QWORD PTR [rbx-0x18],0x0
   2723d:	00 
   2723e:	49 83 c4 01          	add    r12,0x1
   27242:	48 83 eb 10          	sub    rbx,0x10
   27246:	f7 fe                	idiv   esi
   27248:	48 63 d2             	movsxd rdx,edx
   2724b:	48 89 53 f0          	mov    QWORD PTR [rbx-0x10],rdx
   2724f:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   27255:	49 89 c5             	mov    r13,rax
   27258:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   2725c:	ff e0                	jmp    rax
   2725e:	f3 0f 1e fa          	endbr64
   27262:	48 8b 43 f8          	mov    rax,QWORD PTR [rbx-0x8]
   27266:	48 8b 53 f0          	mov    rdx,QWORD PTR [rbx-0x10]
   2726a:	a9 f7 ff ff ff       	test   eax,0xfffffff7
   2726f:	74 1b                	je     2728c <JS_CallInternal+0x478c>
   27271:	83 e8 01             	sub    eax,0x1
   27274:	83 f8 01             	cmp    eax,0x1
   27277:	0f 87 2e 30 00 00    	ja     2a2ab <JS_CallInternal+0x77ab>
   2727d:	83 e2 ff             	and    edx,0xffffffff
   27280:	48 c7 43 f8 00 00 00 	mov    QWORD PTR [rbx-0x8],0x0
   27287:	00 
   27288:	48 89 53 f0          	mov    QWORD PTR [rbx-0x10],rdx
   2728c:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   27291:	49 83 c4 01          	add    r12,0x1
   27295:	49 89 c5             	mov    r13,rax
   27298:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   2729c:	ff e0                	jmp    rax
   2729e:	f3 0f 1e fa          	endbr64
   272a2:	48 8b 43 f8          	mov    rax,QWORD PTR [rbx-0x8]
   272a6:	0b 43 e8             	or     eax,DWORD PTR [rbx-0x18]
   272a9:	48 8b 4b e0          	mov    rcx,QWORD PTR [rbx-0x20]
   272ad:	48 8b 53 f0          	mov    rdx,QWORD PTR [rbx-0x10]
   272b1:	0f 85 40 c9 ff ff    	jne    23bf7 <JS_CallInternal+0x10f7>
   272b7:	66 0f ef c0          	pxor   xmm0,xmm0
   272bb:	66 0f ef c9          	pxor   xmm1,xmm1
   272bf:	f2 0f 2a c1          	cvtsi2sd xmm0,ecx
   272c3:	f2 0f 2a ca          	cvtsi2sd xmm1,edx
   272c7:	f2 0f 5e c1          	divsd  xmm0,xmm1
   272cb:	66 0f 2f 05 35 c1 0a 	comisd xmm0,QWORD PTR [rip+0xac135]        # d3408 <__PRETTY_FUNCTION__.0+0xc8>
   272d2:	00 
   272d3:	66 48 0f 7e c0       	movq   rax,xmm0
   272d8:	0f 82 d6 1e 00 00    	jb     291b4 <JS_CallInternal+0x66b4>
   272de:	f2 0f 10 0d 2a c1 0a 	movsd  xmm1,QWORD PTR [rip+0xac12a]        # d3410 <__PRETTY_FUNCTION__.0+0xd0>
   272e5:	00 
   272e6:	66 0f 2f c8          	comisd xmm1,xmm0
   272ea:	0f 82 c4 1e 00 00    	jb     291b4 <JS_CallInternal+0x66b4>
   272f0:	f2 0f 2c c8          	cvttsd2si ecx,xmm0
   272f4:	66 0f ef c9          	pxor   xmm1,xmm1
   272f8:	ba 08 00 00 00       	mov    edx,0x8
   272fd:	f2 0f 2a c9          	cvtsi2sd xmm1,ecx
   27301:	66 48 0f 7e ce       	movq   rsi,xmm1
   27306:	48 39 f0             	cmp    rax,rsi
   27309:	0f 84 7b 4e 00 00    	je     2c18a <JS_CallInternal+0x968a>
   2730f:	48 89 43 e0          	mov    QWORD PTR [rbx-0x20],rax
   27313:	49 83 c4 01          	add    r12,0x1
   27317:	48 83 eb 10          	sub    rbx,0x10
   2731b:	48 89 53 f8          	mov    QWORD PTR [rbx-0x8],rdx
   2731f:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   27325:	49 89 c5             	mov    r13,rax
   27328:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   2732c:	ff e0                	jmp    rax
   2732e:	f3 0f 1e fa          	endbr64
   27332:	44 8b 5b f8          	mov    r11d,DWORD PTR [rbx-0x8]
   27336:	48 8b 43 f0          	mov    rax,QWORD PTR [rbx-0x10]
   2733a:	45 85 db             	test   r11d,r11d
   2733d:	0f 85 ec 23 00 00    	jne    2972f <JS_CallInternal+0x6c2f>
   27343:	3d ff ff ff 7f       	cmp    eax,0x7fffffff
   27348:	0f 84 e1 23 00 00    	je     2972f <JS_CallInternal+0x6c2f>
   2734e:	83 c0 01             	add    eax,0x1
   27351:	48 c7 43 f8 00 00 00 	mov    QWORD PTR [rbx-0x8],0x0
   27358:	00 
   27359:	48 89 43 f0          	mov    QWORD PTR [rbx-0x10],rax
   2735d:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   27362:	49 83 c4 01          	add    r12,0x1
   27366:	49 89 c5             	mov    r13,rax
   27369:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   2736d:	ff e0                	jmp    rax
   2736f:	f3 0f 1e fa          	endbr64
   27373:	48 8b 53 f8          	mov    rdx,QWORD PTR [rbx-0x8]
   27377:	48 8b 43 f0          	mov    rax,QWORD PTR [rbx-0x10]
   2737b:	83 fa 02             	cmp    edx,0x2
   2737e:	0f 87 26 22 00 00    	ja     295aa <JS_CallInternal+0x6aaa>
   27384:	85 c0                	test   eax,eax
   27386:	0f 84 3c 4a 00 00    	je     2bdc8 <JS_CallInternal+0x92c8>
   2738c:	3d 00 00 00 80       	cmp    eax,0x80000000
   27391:	0f 84 14 4b 00 00    	je     2beab <JS_CallInternal+0x93ab>
   27397:	f7 d8                	neg    eax
   27399:	48 c7 43 f8 00 00 00 	mov    QWORD PTR [rbx-0x8],0x0
   273a0:	00 
   273a1:	48 89 43 f0          	mov    QWORD PTR [rbx-0x10],rax
   273a5:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   273aa:	49 83 c4 01          	add    r12,0x1
   273ae:	49 89 c5             	mov    r13,rax
   273b1:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   273b5:	ff e0                	jmp    rax
   273b7:	f3 0f 1e fa          	endbr64
   273bb:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   273c2:	4c 8d 6b f0          	lea    r13,[rbx-0x10]
   273c6:	48 8b 4b c0          	mov    rcx,QWORD PTR [rbx-0x40]
   273ca:	48 c7 85 00 fe ff ff 	mov    QWORD PTR [rbp-0x200],0x0
   273d1:	00 00 00 00 
   273d5:	4c 8b 43 c8          	mov    r8,QWORD PTR [rbx-0x38]
   273d9:	48 8b 73 d0          	mov    rsi,QWORD PTR [rbx-0x30]
   273dd:	41 b9 01 00 00 00    	mov    r9d,0x1
   273e3:	48 c7 85 08 fe ff ff 	mov    QWORD PTR [rbp-0x1f8],0x3
   273ea:	03 00 00 00 
   273ee:	48 8b 53 d8          	mov    rdx,QWORD PTR [rbx-0x28]
   273f2:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   273f9:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   273fd:	6a 02                	push   0x2
   273ff:	41 55                	push   r13
   27401:	ff b5 08 fe ff ff    	push   QWORD PTR [rbp-0x1f8]
   27407:	ff b5 00 fe ff ff    	push   QWORD PTR [rbp-0x200]
   2740d:	e8 ee b6 ff ff       	call   22b00 <JS_CallInternal>
   27412:	48 83 c4 20          	add    rsp,0x20
   27416:	48 89 c1             	mov    rcx,rax
   27419:	49 89 d6             	mov    r14,rdx
   2741c:	83 fa 06             	cmp    edx,0x6
   2741f:	0f 84 7b be ff ff    	je     232a0 <JS_CallInternal+0x7a0>
   27425:	48 8b 53 f8          	mov    rdx,QWORD PTR [rbx-0x8]
   27429:	48 8b 73 f0          	mov    rsi,QWORD PTR [rbx-0x10]
   2742d:	83 fa f6             	cmp    edx,0xfffffff6
   27430:	76 11                	jbe    27443 <JS_CallInternal+0x4943>
   27432:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   27435:	83 e8 01             	sub    eax,0x1
   27438:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   2743b:	85 c0                	test   eax,eax
   2743d:	0f 8e 55 30 00 00    	jle    2a498 <JS_CallInternal+0x7998>
   27443:	48 89 4b f0          	mov    QWORD PTR [rbx-0x10],rcx
   27447:	49 83 c4 01          	add    r12,0x1
   2744b:	4c 89 73 f8          	mov    QWORD PTR [rbx-0x8],r14
   2744f:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   27455:	49 89 c5             	mov    r13,rax
   27458:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   2745c:	ff e0                	jmp    rax
   2745e:	f3 0f 1e fa          	endbr64
   27462:	48 8b 53 e8          	mov    rdx,QWORD PTR [rbx-0x18]
   27466:	4c 8d 6b e0          	lea    r13,[rbx-0x20]
   2746a:	48 8b 73 e0          	mov    rsi,QWORD PTR [rbx-0x20]
   2746e:	83 fa f6             	cmp    edx,0xfffffff6
   27471:	76 11                	jbe    27484 <JS_CallInternal+0x4984>
   27473:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   27476:	83 e8 01             	sub    eax,0x1
   27479:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   2747c:	85 c0                	test   eax,eax
   2747e:	0f 8e 37 30 00 00    	jle    2a4bb <JS_CallInternal+0x79bb>
   27484:	48 8b 43 d8          	mov    rax,QWORD PTR [rbx-0x28]
   27488:	48 83 eb 30          	sub    rbx,0x30
   2748c:	83 f8 03             	cmp    eax,0x3
   2748f:	74 45                	je     274d6 <JS_CallInternal+0x49d6>
   27491:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   27498:	48 8b 33             	mov    rsi,QWORD PTR [rbx]
   2749b:	31 c9                	xor    ecx,ecx
   2749d:	48 8b 53 08          	mov    rdx,QWORD PTR [rbx+0x8]
   274a1:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   274a8:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   274ac:	e8 ef 9a 00 00       	call   30fa0 <JS_IteratorClose>
   274b1:	85 c0                	test   eax,eax
   274b3:	0f 85 1b 58 00 00    	jne    2ccd4 <JS_CallInternal+0xa1d4>
   274b9:	48 8b 53 08          	mov    rdx,QWORD PTR [rbx+0x8]
   274bd:	48 8b 33             	mov    rsi,QWORD PTR [rbx]
   274c0:	83 fa f6             	cmp    edx,0xfffffff6
   274c3:	76 11                	jbe    274d6 <JS_CallInternal+0x49d6>
   274c5:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   274c8:	83 e8 01             	sub    eax,0x1
   274cb:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   274ce:	85 c0                	test   eax,eax
   274d0:	0f 8e 16 4d 00 00    	jle    2c1ec <JS_CallInternal+0x96ec>
   274d6:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   274db:	49 83 c4 01          	add    r12,0x1
   274df:	49 89 c5             	mov    r13,rax
   274e2:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   274e6:	ff e0                	jmp    rax
   274e8:	f3 0f 1e fa          	endbr64
   274ec:	4c 8b 43 f8          	mov    r8,QWORD PTR [rbx-0x8]
   274f0:	48 8b 73 f0          	mov    rsi,QWORD PTR [rbx-0x10]
   274f4:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   274fb:	4c 89 c2             	mov    rdx,r8
   274fe:	e8 bd 44 ff ff       	call   1b9c0 <js_operator_typeof>
   27503:	41 89 c5             	mov    r13d,eax
   27506:	41 83 f8 f6          	cmp    r8d,0xfffffff6
   2750a:	76 11                	jbe    2751d <JS_CallInternal+0x4a1d>
   2750c:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   2750f:	83 e8 01             	sub    eax,0x1
   27512:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   27515:	85 c0                	test   eax,eax
   27517:	0f 8e 98 34 00 00    	jle    2a9b5 <JS_CallInternal+0x7eb5>
   2751d:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   27524:	44 89 ee             	mov    esi,r13d
   27527:	ba 01 00 00 00       	mov    edx,0x1
   2752c:	49 83 c4 01          	add    r12,0x1
   27530:	e8 eb ca 00 00       	call   34020 <__JS_AtomToValue>
   27535:	48 89 43 f0          	mov    QWORD PTR [rbx-0x10],rax
   27539:	48 89 53 f8          	mov    QWORD PTR [rbx-0x8],rdx
   2753d:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   27543:	49 89 c5             	mov    r13,rax
   27546:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   2754a:	ff e0                	jmp    rax
   2754c:	f3 0f 1e fa          	endbr64
   27550:	83 7b f8 ff          	cmp    DWORD PTR [rbx-0x8],0xffffffff
   27554:	0f 85 8d 37 00 00    	jne    2ace7 <JS_CallInternal+0x81e7>
   2755a:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   2755f:	49 83 c4 01          	add    r12,0x1
   27563:	49 89 c5             	mov    r13,rax
   27566:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   2756a:	ff e0                	jmp    rax
   2756c:	f3 0f 1e fa          	endbr64
   27570:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   27577:	48 8b 73 e0          	mov    rsi,QWORD PTR [rbx-0x20]
   2757b:	48 8b 53 e8          	mov    rdx,QWORD PTR [rbx-0x18]
   2757f:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   27586:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   2758a:	48 8d 43 e0          	lea    rax,[rbx-0x20]
   2758e:	48 89 85 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],rax
   27595:	e8 76 bf 01 00       	call   43510 <JS_ValueToAtom>
   2759a:	41 89 c5             	mov    r13d,eax
   2759d:	45 85 ed             	test   r13d,r13d
   275a0:	0f 84 fa bc ff ff    	je     232a0 <JS_CallInternal+0x7a0>
   275a6:	83 7b d8 03          	cmp    DWORD PTR [rbx-0x28],0x3
   275aa:	0f 84 44 3a 00 00    	je     2aff4 <JS_CallInternal+0x84f4>
   275b0:	48 8b 73 d0          	mov    rsi,QWORD PTR [rbx-0x30]
   275b4:	48 8b 53 d8          	mov    rdx,QWORD PTR [rbx-0x28]
   275b8:	44 89 e9             	mov    ecx,r13d
   275bb:	4c 8d 73 d0          	lea    r14,[rbx-0x30]
   275bf:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   275c6:	e8 c5 6c 04 00       	call   6e290 <JS_HasProperty>
   275cb:	85 c0                	test   eax,eax
   275cd:	0f 8e c9 39 00 00    	jle    2af9c <JS_CallInternal+0x849c>
   275d3:	48 83 ec 08          	sub    rsp,0x8
   275d7:	4c 8b 43 f0          	mov    r8,QWORD PTR [rbx-0x10]
   275db:	4c 8b 4b f8          	mov    r9,QWORD PTR [rbx-0x8]
   275df:	44 89 e9             	mov    ecx,r13d
   275e2:	49 8b 36             	mov    rsi,QWORD PTR [r14]
   275e5:	49 8b 56 08          	mov    rdx,QWORD PTR [r14+0x8]
   275e9:	68 00 80 00 00       	push   0x8000
   275ee:	41 ff 76 08          	push   QWORD PTR [r14+0x8]
   275f2:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   275f9:	41 ff 36             	push   QWORD PTR [r14]
   275fc:	e8 0f 65 00 00       	call   2db10 <JS_SetPropertyInternal>
   27601:	48 83 c4 20          	add    rsp,0x20
   27605:	89 c3                	mov    ebx,eax
   27607:	41 81 fd f2 00 00 00 	cmp    r13d,0xf2
   2760e:	0f 8f 89 2a 00 00    	jg     2a09d <JS_CallInternal+0x759d>
   27614:	48 8b 85 50 fe ff ff 	mov    rax,QWORD PTR [rbp-0x1b0]
   2761b:	48 8b 50 08          	mov    rdx,QWORD PTR [rax+0x8]
   2761f:	48 8b 30             	mov    rsi,QWORD PTR [rax]
   27622:	83 fa f6             	cmp    edx,0xfffffff6
   27625:	76 11                	jbe    27638 <JS_CallInternal+0x4b38>
   27627:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   2762a:	83 e8 01             	sub    eax,0x1
   2762d:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   27630:	85 c0                	test   eax,eax
   27632:	0f 8e 74 3f 00 00    	jle    2b5ac <JS_CallInternal+0x8aac>
   27638:	49 8b 56 08          	mov    rdx,QWORD PTR [r14+0x8]
   2763c:	49 8b 36             	mov    rsi,QWORD PTR [r14]
   2763f:	83 fa f6             	cmp    edx,0xfffffff6
   27642:	76 11                	jbe    27655 <JS_CallInternal+0x4b55>
   27644:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   27647:	83 e8 01             	sub    eax,0x1
   2764a:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   2764d:	85 c0                	test   eax,eax
   2764f:	0f 8e 26 3a 00 00    	jle    2b07b <JS_CallInternal+0x857b>
   27655:	85 db                	test   ebx,ebx
   27657:	0f 88 6d 44 00 00    	js     2baca <JS_CallInternal+0x8fca>
   2765d:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   27662:	4c 89 f3             	mov    rbx,r14
   27665:	49 83 c4 01          	add    r12,0x1
   27669:	49 89 c5             	mov    r13,rax
   2766c:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   27670:	ff e0                	jmp    rax
   27672:	f3 0f 1e fa          	endbr64
   27676:	48 8b 53 f8          	mov    rdx,QWORD PTR [rbx-0x8]
   2767a:	0b 53 e8             	or     edx,DWORD PTR [rbx-0x18]
   2767d:	48 8b 43 e0          	mov    rax,QWORD PTR [rbx-0x20]
   27681:	48 8b 4b f0          	mov    rcx,QWORD PTR [rbx-0x10]
   27685:	0f 85 63 3c 00 00    	jne    2b2ee <JS_CallInternal+0x87ee>
   2768b:	d3 e0                	shl    eax,cl
   2768d:	48 c7 43 e8 00 00 00 	mov    QWORD PTR [rbx-0x18],0x0
   27694:	00 
   27695:	48 83 eb 10          	sub    rbx,0x10
   27699:	48 89 43 f0          	mov    QWORD PTR [rbx-0x10],rax
   2769d:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   276a2:	49 83 c4 01          	add    r12,0x1
   276a6:	49 89 c5             	mov    r13,rax
   276a9:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   276ad:	ff e0                	jmp    rax
   276af:	f3 0f 1e fa          	endbr64
   276b3:	48 8b 4b f0          	mov    rcx,QWORD PTR [rbx-0x10]
   276b7:	83 7b f8 03          	cmp    DWORD PTR [rbx-0x8],0x3
   276bb:	4d 8d 6c 24 04       	lea    r13,[r12+0x4]
   276c0:	48 8b 53 f8          	mov    rdx,QWORD PTR [rbx-0x8]
   276c4:	48 89 c8             	mov    rax,rcx
   276c7:	0f 87 d4 24 00 00    	ja     29ba1 <JS_CallInternal+0x70a1>
   276cd:	48 83 eb 10          	sub    rbx,0x10
   276d1:	85 c0                	test   eax,eax
   276d3:	75 0c                	jne    276e1 <JS_CallInternal+0x4be1>
   276d5:	41 8b 04 24          	mov    eax,DWORD PTR [r12]
   276d9:	83 e8 04             	sub    eax,0x4
   276dc:	48 98                	cdqe
   276de:	49 01 c5             	add    r13,rax
   276e1:	48 8b 8d e8 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x118]
   276e8:	8b 81 a8 01 00 00    	mov    eax,DWORD PTR [rcx+0x1a8]
   276ee:	89 85 50 fe ff ff    	mov    DWORD PTR [rbp-0x1b0],eax
   276f4:	83 e8 01             	sub    eax,0x1
   276f7:	89 81 a8 01 00 00    	mov    DWORD PTR [rcx+0x1a8],eax
   276fd:	85 c0                	test   eax,eax
   276ff:	0f 8e 0f 3a 00 00    	jle    2b114 <JS_CallInternal+0x8614>
   27705:	41 0f b6 45 00       	movzx  eax,BYTE PTR [r13+0x0]
   2770a:	4d 8d 65 01          	lea    r12,[r13+0x1]
   2770e:	49 89 c5             	mov    r13,rax
   27711:	41 ff 24 c7          	jmp    QWORD PTR [r15+rax*8]
   27715:	f3 0f 1e fa          	endbr64
   27719:	48 8b 4b f8          	mov    rcx,QWORD PTR [rbx-0x8]
   2771d:	48 8b 73 e8          	mov    rsi,QWORD PTR [rbx-0x18]
   27721:	48 8b 53 e0          	mov    rdx,QWORD PTR [rbx-0x20]
   27725:	48 8b 43 f0          	mov    rax,QWORD PTR [rbx-0x10]
   27729:	89 cf                	mov    edi,ecx
   2772b:	09 f7                	or     edi,esi
   2772d:	0f 85 21 3c 00 00    	jne    2b354 <JS_CallInternal+0x8854>
   27733:	39 c2                	cmp    edx,eax
   27735:	48 c7 43 e8 01 00 00 	mov    QWORD PTR [rbx-0x18],0x1
   2773c:	00 
   2773d:	0f 9d c0             	setge  al
   27740:	48 83 eb 10          	sub    rbx,0x10
   27744:	0f b6 c0             	movzx  eax,al
   27747:	48 89 43 f0          	mov    QWORD PTR [rbx-0x10],rax
   2774b:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   27750:	49 83 c4 01          	add    r12,0x1
   27754:	49 89 c5             	mov    r13,rax
   27757:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   2775b:	ff e0                	jmp    rax
   2775d:	f3 0f 1e fa          	endbr64
   27761:	4c 8b 73 e8          	mov    r14,QWORD PTR [rbx-0x18]
   27765:	41 8b 0c 24          	mov    ecx,DWORD PTR [r12]
   27769:	4d 8d 54 24 04       	lea    r10,[r12+0x4]
   2776e:	48 8b 43 e0          	mov    rax,QWORD PTR [rbx-0x20]
   27772:	48 8b 53 e8          	mov    rdx,QWORD PTR [rbx-0x18]
   27776:	4c 8b 6b e0          	mov    r13,QWORD PTR [rbx-0x20]
   2777a:	41 83 fe ff          	cmp    r14d,0xffffffff
   2777e:	0f 85 af 23 00 00    	jne    29b33 <JS_CallInternal+0x7033>
   27784:	4d 8b 4d 18          	mov    r9,QWORD PTR [r13+0x18]
   27788:	41 8b 79 18          	mov    edi,DWORD PTR [r9+0x18]
   2778c:	89 fe                	mov    esi,edi
   2778e:	21 ce                	and    esi,ecx
   27790:	41 8b 74 b1 38       	mov    esi,DWORD PTR [r9+rsi*4+0x38]
   27795:	48 85 f6             	test   rsi,rsi
   27798:	0f 84 95 23 00 00    	je     29b33 <JS_CallInternal+0x7033>
   2779e:	48 8d 3c bd 34 00 00 	lea    rdi,[rdi*4+0x34]
   277a5:	00 
   277a6:	4c 8d 04 f7          	lea    r8,[rdi+rsi*8]
   277aa:	4d 01 c8             	add    r8,r9
   277ad:	41 39 48 04          	cmp    DWORD PTR [r8+0x4],ecx
   277b1:	0f 85 6d 23 00 00    	jne    29b24 <JS_CallInternal+0x7024>
   277b7:	49 8b 7d 20          	mov    rdi,QWORD PTR [r13+0x20]
   277bb:	48 c1 e6 04          	shl    rsi,0x4
   277bf:	48 8d 7c 37 f0       	lea    rdi,[rdi+rsi*1-0x10]
   277c4:	41 0f b6 70 03       	movzx  esi,BYTE PTR [r8+0x3]
   277c9:	40 c0 ee 02          	shr    sil,0x2
   277cd:	83 e6 3a             	and    esi,0x3a
   277d0:	40 80 fe 02          	cmp    sil,0x2
   277d4:	0f 85 59 23 00 00    	jne    29b33 <JS_CallInternal+0x7033>
   277da:	48 8b 57 08          	mov    rdx,QWORD PTR [rdi+0x8]
   277de:	f3 0f 6f 73 f0       	movdqu xmm6,XMMWORD PTR [rbx-0x10]
   277e3:	48 8b 37             	mov    rsi,QWORD PTR [rdi]
   277e6:	0f 11 37             	movups XMMWORD PTR [rdi],xmm6
   277e9:	83 fa f6             	cmp    edx,0xfffffff6
   277ec:	76 11                	jbe    277ff <JS_CallInternal+0x4cff>
   277ee:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   277f1:	83 e8 01             	sub    eax,0x1
   277f4:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   277f7:	85 c0                	test   eax,eax
   277f9:	0f 8e d7 43 00 00    	jle    2bbd6 <JS_CallInternal+0x90d6>
   277ff:	41 83 fe f6          	cmp    r14d,0xfffffff6
   27803:	76 13                	jbe    27818 <JS_CallInternal+0x4d18>
   27805:	41 8b 45 fc          	mov    eax,DWORD PTR [r13-0x4]
   27809:	83 e8 01             	sub    eax,0x1
   2780c:	41 89 45 fc          	mov    DWORD PTR [r13-0x4],eax
   27810:	85 c0                	test   eax,eax
   27812:	0f 8e d3 43 00 00    	jle    2bbeb <JS_CallInternal+0x90eb>
   27818:	48 83 eb 20          	sub    rbx,0x20
   2781c:	41 0f b6 44 24 04    	movzx  eax,BYTE PTR [r12+0x4]
   27822:	49 83 c4 05          	add    r12,0x5
   27826:	49 89 c5             	mov    r13,rax
   27829:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   2782d:	ff e0                	jmp    rax
   2782f:	f3 0f 1e fa          	endbr64
   27833:	45 0f b6 2c 24       	movzx  r13d,BYTE PTR [r12]
   27838:	48 8b 85 b0 fe ff ff 	mov    rax,QWORD PTR [rbp-0x150]
   2783f:	4d 8d 74 24 01       	lea    r14,[r12+0x1]
   27844:	49 c1 e5 04          	shl    r13,0x4
   27848:	49 01 c5             	add    r13,rax
   2784b:	f3 41 0f 6f 55 00    	movdqu xmm2,XMMWORD PTR [r13+0x0]
   27851:	0f 29 95 f0 fe ff ff 	movaps XMMWORD PTR [rbp-0x110],xmm2
   27858:	48 8b 95 f8 fe ff ff 	mov    rdx,QWORD PTR [rbp-0x108]
   2785f:	48 8b 85 f0 fe ff ff 	mov    rax,QWORD PTR [rbp-0x110]
   27866:	85 d2                	test   edx,edx
   27868:	0f 85 50 1c 00 00    	jne    294be <JS_CallInternal+0x69be>
   2786e:	3d ff ff ff 7f       	cmp    eax,0x7fffffff
   27873:	0f 84 45 1c 00 00    	je     294be <JS_CallInternal+0x69be>
   27879:	83 c0 01             	add    eax,0x1
   2787c:	49 c7 45 08 00 00 00 	mov    QWORD PTR [r13+0x8],0x0
   27883:	00 
   27884:	49 89 45 00          	mov    QWORD PTR [r13+0x0],rax
   27888:	41 0f b6 44 24 01    	movzx  eax,BYTE PTR [r12+0x1]
   2788e:	49 83 c4 02          	add    r12,0x2
   27892:	49 89 c5             	mov    r13,rax
   27895:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   27899:	ff e0                	jmp    rax
   2789b:	f3 0f 1e fa          	endbr64
   2789f:	44 8b 43 f8          	mov    r8d,DWORD PTR [rbx-0x8]
   278a3:	48 8b 43 f0          	mov    rax,QWORD PTR [rbx-0x10]
   278a7:	45 85 c0             	test   r8d,r8d
   278aa:	0f 85 b0 1e 00 00    	jne    29760 <JS_CallInternal+0x6c60>
   278b0:	3d 00 00 00 80       	cmp    eax,0x80000000
   278b5:	0f 84 a5 1e 00 00    	je     29760 <JS_CallInternal+0x6c60>
   278bb:	83 e8 01             	sub    eax,0x1
   278be:	48 c7 43 08 00 00 00 	mov    QWORD PTR [rbx+0x8],0x0
   278c5:	00 
   278c6:	48 89 03             	mov    QWORD PTR [rbx],rax
   278c9:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   278ce:	48 83 c3 10          	add    rbx,0x10
   278d2:	49 83 c4 01          	add    r12,0x1
   278d6:	49 89 c5             	mov    r13,rax
   278d9:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   278dd:	ff e0                	jmp    rax
   278df:	f3 0f 1e fa          	endbr64
   278e3:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   278ea:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   278f1:	31 d2                	xor    edx,edx
   278f3:	48 89 de             	mov    rsi,rbx
   278f6:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   278fa:	e8 51 e2 06 00       	call   95b50 <js_for_of_start>
   278ff:	85 c0                	test   eax,eax
   27901:	0f 85 99 b9 ff ff    	jne    232a0 <JS_CallInternal+0x7a0>
   27907:	48 c7 43 10 00 00 00 	mov    QWORD PTR [rbx+0x10],0x0
   2790e:	00 
   2790f:	49 83 c4 01          	add    r12,0x1
   27913:	48 83 c3 20          	add    rbx,0x20
   27917:	48 c7 43 f8 05 00 00 	mov    QWORD PTR [rbx-0x8],0x5
   2791e:	00 
   2791f:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   27925:	49 89 c5             	mov    r13,rax
   27928:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   2792c:	ff e0                	jmp    rax
   2792e:	f3 0f 1e fa          	endbr64
   27932:	48 8b 53 e0          	mov    rdx,QWORD PTR [rbx-0x20]
   27936:	4c 8b 4b e8          	mov    r9,QWORD PTR [rbx-0x18]
   2793a:	4c 8b 6b f0          	mov    r13,QWORD PTR [rbx-0x10]
   2793e:	4c 8b 73 f8          	mov    r14,QWORD PTR [rbx-0x8]
   27942:	48 89 d7             	mov    rdi,rdx
   27945:	45 85 c9             	test   r9d,r9d
   27948:	0f 85 b3 33 00 00    	jne    2ad01 <JS_CallInternal+0x8201>
   2794e:	45 85 f6             	test   r14d,r14d
   27951:	0f 85 67 1d 00 00    	jne    296be <JS_CallInternal+0x6bbe>
   27957:	31 c0                	xor    eax,eax
   27959:	44 39 ea             	cmp    edx,r13d
   2795c:	0f 95 c0             	setne  al
   2795f:	48 89 43 e0          	mov    QWORD PTR [rbx-0x20],rax
   27963:	49 83 c4 01          	add    r12,0x1
   27967:	48 83 eb 10          	sub    rbx,0x10
   2796b:	48 c7 43 f8 01 00 00 	mov    QWORD PTR [rbx-0x8],0x1
   27972:	00 
   27973:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   27979:	49 89 c5             	mov    r13,rax
   2797c:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   27980:	ff e0                	jmp    rax
   27982:	f3 0f 1e fa          	endbr64
   27986:	48 8b 53 e0          	mov    rdx,QWORD PTR [rbx-0x20]
   2798a:	4c 8b 43 e8          	mov    r8,QWORD PTR [rbx-0x18]
   2798e:	4c 8b 6b f0          	mov    r13,QWORD PTR [rbx-0x10]
   27992:	4c 8b 73 f8          	mov    r14,QWORD PTR [rbx-0x8]
   27996:	48 89 d7             	mov    rdi,rdx
   27999:	45 85 c0             	test   r8d,r8d
   2799c:	0f 85 12 3d 00 00    	jne    2b6b4 <JS_CallInternal+0x8bb4>
   279a2:	45 85 f6             	test   r14d,r14d
   279a5:	0f 85 41 1d 00 00    	jne    296ec <JS_CallInternal+0x6bec>
   279ab:	31 c0                	xor    eax,eax
   279ad:	44 39 ea             	cmp    edx,r13d
   279b0:	0f 94 c0             	sete   al
   279b3:	48 89 43 e0          	mov    QWORD PTR [rbx-0x20],rax
   279b7:	49 83 c4 01          	add    r12,0x1
   279bb:	48 83 eb 10          	sub    rbx,0x10
   279bf:	48 c7 43 f8 01 00 00 	mov    QWORD PTR [rbx-0x8],0x1
   279c6:	00 
   279c7:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   279cd:	49 89 c5             	mov    r13,rax
   279d0:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   279d4:	ff e0                	jmp    rax
   279d6:	f3 0f 1e fa          	endbr64
   279da:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   279e1:	4c 8b 73 f0          	mov    r14,QWORD PTR [rbx-0x10]
   279e5:	4c 8b 6b f8          	mov    r13,QWORD PTR [rbx-0x8]
   279e9:	48 8b 73 e0          	mov    rsi,QWORD PTR [rbx-0x20]
   279ed:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   279f1:	48 8b 53 e8          	mov    rdx,QWORD PTR [rbx-0x18]
   279f5:	4c 89 f1             	mov    rcx,r14
   279f8:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   279ff:	4d 89 e8             	mov    r8,r13
   27a02:	48 89 b5 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],rsi
   27a09:	48 89 95 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],rdx
   27a10:	e8 2b ba 00 00       	call   33440 <JS_IsInstanceOf>
   27a15:	89 c1                	mov    ecx,eax
   27a17:	85 c0                	test   eax,eax
   27a19:	0f 88 81 b8 ff ff    	js     232a0 <JS_CallInternal+0x7a0>
   27a1f:	48 8b 95 50 fe ff ff 	mov    rdx,QWORD PTR [rbp-0x1b0]
   27a26:	83 fa f6             	cmp    edx,0xfffffff6
   27a29:	76 18                	jbe    27a43 <JS_CallInternal+0x4f43>
   27a2b:	48 8b b5 40 fe ff ff 	mov    rsi,QWORD PTR [rbp-0x1c0]
   27a32:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   27a35:	83 e8 01             	sub    eax,0x1
   27a38:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   27a3b:	85 c0                	test   eax,eax
   27a3d:	0f 8e 72 41 00 00    	jle    2bbb5 <JS_CallInternal+0x90b5>
   27a43:	41 83 fd f6          	cmp    r13d,0xfffffff6
   27a47:	76 13                	jbe    27a5c <JS_CallInternal+0x4f5c>
   27a49:	41 8b 46 fc          	mov    eax,DWORD PTR [r14-0x4]
   27a4d:	83 e8 01             	sub    eax,0x1
   27a50:	41 89 46 fc          	mov    DWORD PTR [r14-0x4],eax
   27a54:	85 c0                	test   eax,eax
   27a56:	0f 8e f8 41 00 00    	jle    2bc54 <JS_CallInternal+0x9154>
   27a5c:	31 c0                	xor    eax,eax
   27a5e:	85 c9                	test   ecx,ecx
   27a60:	48 c7 43 e8 01 00 00 	mov    QWORD PTR [rbx-0x18],0x1
   27a67:	00 
   27a68:	0f 95 c0             	setne  al
   27a6b:	48 83 eb 10          	sub    rbx,0x10
   27a6f:	49 83 c4 01          	add    r12,0x1
   27a73:	48 89 43 f0          	mov    QWORD PTR [rbx-0x10],rax
   27a77:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   27a7d:	49 89 c5             	mov    r13,rax
   27a80:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   27a84:	ff e0                	jmp    rax
   27a86:	f3 0f 1e fa          	endbr64
   27a8a:	48 8b 53 f8          	mov    rdx,QWORD PTR [rbx-0x8]
   27a8e:	0b 53 e8             	or     edx,DWORD PTR [rbx-0x18]
   27a91:	48 8b 43 e0          	mov    rax,QWORD PTR [rbx-0x20]
   27a95:	48 8b 4b f0          	mov    rcx,QWORD PTR [rbx-0x10]
   27a99:	0f 85 cc 36 00 00    	jne    2b16b <JS_CallInternal+0x866b>
   27a9f:	31 c8                	xor    eax,ecx
   27aa1:	48 c7 43 e8 00 00 00 	mov    QWORD PTR [rbx-0x18],0x0
   27aa8:	00 
   27aa9:	48 83 eb 10          	sub    rbx,0x10
   27aad:	48 89 43 f0          	mov    QWORD PTR [rbx-0x10],rax
   27ab1:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   27ab6:	49 83 c4 01          	add    r12,0x1
   27aba:	49 89 c5             	mov    r13,rax
   27abd:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   27ac1:	ff e0                	jmp    rax
   27ac3:	f3 0f 1e fa          	endbr64
   27ac7:	48 8b 53 f8          	mov    rdx,QWORD PTR [rbx-0x8]
   27acb:	0b 53 e8             	or     edx,DWORD PTR [rbx-0x18]
   27ace:	48 8b 43 e0          	mov    rax,QWORD PTR [rbx-0x20]
   27ad2:	48 8b 4b f0          	mov    rcx,QWORD PTR [rbx-0x10]
   27ad6:	0f 85 2f 3d 00 00    	jne    2b80b <JS_CallInternal+0x8d0b>
   27adc:	09 c8                	or     eax,ecx
   27ade:	48 c7 43 e8 00 00 00 	mov    QWORD PTR [rbx-0x18],0x0
   27ae5:	00 
   27ae6:	48 83 eb 10          	sub    rbx,0x10
   27aea:	48 89 43 f0          	mov    QWORD PTR [rbx-0x10],rax
   27aee:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   27af3:	49 83 c4 01          	add    r12,0x1
   27af7:	49 89 c5             	mov    r13,rax
   27afa:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   27afe:	ff e0                	jmp    rax
   27b00:	f3 0f 1e fa          	endbr64
   27b04:	41 0f b6 3c 24       	movzx  edi,BYTE PTR [r12]
   27b09:	48 8b 8d c8 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x138]
   27b10:	4d 8d 6c 24 01       	lea    r13,[r12+0x1]
   27b15:	45 31 c9             	xor    r9d,r9d
   27b18:	89 fa                	mov    edx,edi
   27b1a:	89 f8                	mov    eax,edi
   27b1c:	4c 89 69 30          	mov    QWORD PTR [rcx+0x30],r13
   27b20:	c1 fa 02             	sar    edx,0x2
   27b23:	83 e0 03             	and    eax,0x3
   27b26:	83 e2 07             	and    edx,0x7
   27b29:	f7 d0                	not    eax
   27b2b:	f7 d2                	not    edx
   27b2d:	48 98                	cdqe
   27b2f:	48 63 d2             	movsxd rdx,edx
   27b32:	48 c1 e0 04          	shl    rax,0x4
   27b36:	48 c1 e2 04          	shl    rdx,0x4
   27b3a:	48 01 d8             	add    rax,rbx
   27b3d:	48 01 da             	add    rdx,rbx
   27b40:	48 8b 30             	mov    rsi,QWORD PTR [rax]
   27b43:	48 8b 0a             	mov    rcx,QWORD PTR [rdx]
   27b46:	4c 8b 42 08          	mov    r8,QWORD PTR [rdx+0x8]
   27b4a:	48 8b 50 08          	mov    rdx,QWORD PTR [rax+0x8]
   27b4e:	89 f8                	mov    eax,edi
   27b50:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   27b57:	c1 f8 05             	sar    eax,0x5
   27b5a:	f7 d0                	not    eax
   27b5c:	48 98                	cdqe
   27b5e:	48 c1 e0 04          	shl    rax,0x4
   27b62:	ff 74 03 08          	push   QWORD PTR [rbx+rax*1+0x8]
   27b66:	ff 34 03             	push   QWORD PTR [rbx+rax*1]
   27b69:	e8 72 3a 06 00       	call   8b5e0 <JS_CopyDataProperties>
   27b6e:	41 5e                	pop    r14
   27b70:	5a                   	pop    rdx
   27b71:	85 c0                	test   eax,eax
   27b73:	0f 85 57 49 00 00    	jne    2c4d0 <JS_CallInternal+0x99d0>
   27b79:	41 0f b6 44 24 01    	movzx  eax,BYTE PTR [r12+0x1]
   27b7f:	49 83 c4 02          	add    r12,0x2
   27b83:	49 89 c5             	mov    r13,rax
   27b86:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   27b8a:	ff e0                	jmp    rax
   27b8c:	f3 0f 1e fa          	endbr64
   27b90:	48 8b 4b f8          	mov    rcx,QWORD PTR [rbx-0x8]
   27b94:	48 8b 73 e8          	mov    rsi,QWORD PTR [rbx-0x18]
   27b98:	48 8b 53 e0          	mov    rdx,QWORD PTR [rbx-0x20]
   27b9c:	48 8b 43 f0          	mov    rax,QWORD PTR [rbx-0x10]
   27ba0:	89 cf                	mov    edi,ecx
   27ba2:	09 f7                	or     edi,esi
   27ba4:	0f 85 8e 36 00 00    	jne    2b238 <JS_CallInternal+0x8738>
   27baa:	39 c2                	cmp    edx,eax
   27bac:	48 c7 43 e8 01 00 00 	mov    QWORD PTR [rbx-0x18],0x1
   27bb3:	00 
   27bb4:	0f 9f c0             	setg   al
   27bb7:	48 83 eb 10          	sub    rbx,0x10
   27bbb:	0f b6 c0             	movzx  eax,al
   27bbe:	48 89 43 f0          	mov    QWORD PTR [rbx-0x10],rax
   27bc2:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   27bc7:	49 83 c4 01          	add    r12,0x1
   27bcb:	49 89 c5             	mov    r13,rax
   27bce:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   27bd2:	ff e0                	jmp    rax
   27bd4:	f3 0f 1e fa          	endbr64
   27bd8:	48 8b 8d d8 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x128]
   27bdf:	41 0f b7 04 24       	movzx  eax,WORD PTR [r12]
   27be4:	0f b7 51 38          	movzx  edx,WORD PTR [rcx+0x38]
   27be8:	4c 8b 51 28          	mov    r10,QWORD PTR [rcx+0x28]
   27bec:	01 d0                	add    eax,edx
   27bee:	48 98                	cdqe
   27bf0:	48 8d 04 40          	lea    rax,[rax+rax*2]
   27bf4:	49 8d 04 82          	lea    rax,[r10+rax*4]
   27bf8:	44 0f b7 68 0a       	movzx  r13d,WORD PTR [rax+0xa]
   27bfd:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   27c04:	48 8b 48 28          	mov    rcx,QWORD PTR [rax+0x28]
   27c08:	49 c1 e5 03          	shl    r13,0x3
   27c0c:	4c 01 e9             	add    rcx,r13
   27c0f:	4c 8b 31             	mov    r14,QWORD PTR [rcx]
   27c12:	4d 85 f6             	test   r14,r14
   27c15:	74 50                	je     27c67 <JS_CallInternal+0x5167>
   27c17:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   27c1e:	48 8b 7f 10          	mov    rdi,QWORD PTR [rdi+0x10]
   27c22:	f6 40 3c 04          	test   BYTE PTR [rax+0x3c],0x4
   27c26:	0f 85 b5 27 00 00    	jne    2a3e1 <JS_CallInternal+0x78e1>
   27c2c:	49 8b 56 18          	mov    rdx,QWORD PTR [r14+0x18]
   27c30:	48 8b 02             	mov    rax,QWORD PTR [rdx]
   27c33:	48 8b 52 08          	mov    rdx,QWORD PTR [rdx+0x8]
   27c37:	83 fa f6             	cmp    edx,0xfffffff6
   27c3a:	76 04                	jbe    27c40 <JS_CallInternal+0x5140>
   27c3c:	83 40 fc 01          	add    DWORD PTR [rax-0x4],0x1
   27c40:	49 8d 7e 20          	lea    rdi,[r14+0x20]
   27c44:	66 48 0f 6e e0       	movq   xmm4,rax
   27c49:	49 89 56 28          	mov    QWORD PTR [r14+0x28],rdx
   27c4d:	66 48 0f 6e c7       	movq   xmm0,rdi
   27c52:	41 c6 46 10 01       	mov    BYTE PTR [r14+0x10],0x1
   27c57:	66 0f 6c c4          	punpcklqdq xmm0,xmm4
   27c5b:	41 0f 11 46 18       	movups XMMWORD PTR [r14+0x18],xmm0
   27c60:	48 c7 01 00 00 00 00 	mov    QWORD PTR [rcx],0x0
   27c67:	41 0f b6 44 24 02    	movzx  eax,BYTE PTR [r12+0x2]
   27c6d:	49 83 c4 03          	add    r12,0x3
   27c71:	49 89 c5             	mov    r13,rax
   27c74:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   27c78:	ff e0                	jmp    rax
   27c7a:	f3 0f 1e fa          	endbr64
   27c7e:	48 8b 4b f8          	mov    rcx,QWORD PTR [rbx-0x8]
   27c82:	48 8b 73 e8          	mov    rsi,QWORD PTR [rbx-0x18]
   27c86:	48 8b 43 e0          	mov    rax,QWORD PTR [rbx-0x20]
   27c8a:	48 8b 53 f0          	mov    rdx,QWORD PTR [rbx-0x10]
   27c8e:	89 cf                	mov    edi,ecx
   27c90:	09 f7                	or     edi,esi
   27c92:	0f 85 22 3c 00 00    	jne    2b8ba <JS_CallInternal+0x8dba>
   27c98:	39 d0                	cmp    eax,edx
   27c9a:	48 c7 43 e8 01 00 00 	mov    QWORD PTR [rbx-0x18],0x1
   27ca1:	00 
   27ca2:	0f 9c c0             	setl   al
   27ca5:	48 83 eb 10          	sub    rbx,0x10
   27ca9:	0f b6 c0             	movzx  eax,al
   27cac:	48 89 43 f0          	mov    QWORD PTR [rbx-0x10],rax
   27cb0:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   27cb5:	49 83 c4 01          	add    r12,0x1
   27cb9:	49 89 c5             	mov    r13,rax
   27cbc:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   27cc0:	ff e0                	jmp    rax
   27cc2:	f3 0f 1e fa          	endbr64
   27cc6:	83 7b f8 03          	cmp    DWORD PTR [rbx-0x8],0x3
   27cca:	48 8b 53 f0          	mov    rdx,QWORD PTR [rbx-0x10]
   27cce:	48 8b 43 f8          	mov    rax,QWORD PTR [rbx-0x8]
   27cd2:	0f 87 11 20 00 00    	ja     29ce9 <JS_CallInternal+0x71e9>
   27cd8:	31 c0                	xor    eax,eax
   27cda:	85 d2                	test   edx,edx
   27cdc:	0f 95 c0             	setne  al
   27cdf:	85 c0                	test   eax,eax
   27ce1:	48 c7 43 f8 01 00 00 	mov    QWORD PTR [rbx-0x8],0x1
   27ce8:	00 
   27ce9:	0f 94 c0             	sete   al
   27cec:	49 83 c4 01          	add    r12,0x1
   27cf0:	0f b6 c0             	movzx  eax,al
   27cf3:	48 89 43 f0          	mov    QWORD PTR [rbx-0x10],rax
   27cf7:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   27cfd:	49 89 c5             	mov    r13,rax
   27d00:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   27d04:	ff e0                	jmp    rax
   27d06:	f3 0f 1e fa          	endbr64
   27d0a:	45 0f b6 34 24       	movzx  r14d,BYTE PTR [r12]
   27d0f:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   27d16:	4d 8d 6c 24 01       	lea    r13,[r12+0x1]
   27d1b:	4c 8b 43 c0          	mov    r8,QWORD PTR [rbx-0x40]
   27d1f:	4c 8b 4b c8          	mov    r9,QWORD PTR [rbx-0x38]
   27d23:	4c 89 68 30          	mov    QWORD PTR [rax+0x30],r13
   27d27:	44 89 f0             	mov    eax,r14d
   27d2a:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   27d31:	83 e0 01             	and    eax,0x1
   27d34:	4c 89 c6             	mov    rsi,r8
   27d37:	4c 89 ca             	mov    rdx,r9
   27d3a:	3c 01                	cmp    al,0x1
   27d3c:	19 c9                	sbb    ecx,ecx
   27d3e:	48 83 ec 08          	sub    rsp,0x8
   27d42:	6a 00                	push   0x0
   27d44:	83 e1 ef             	and    ecx,0xffffffef
   27d47:	83 c1 17             	add    ecx,0x17
   27d4a:	e8 91 50 00 00       	call   2cde0 <JS_GetPropertyInternal>
   27d4f:	59                   	pop    rcx
   27d50:	5e                   	pop    rsi
   27d51:	83 fa 06             	cmp    edx,0x6
   27d54:	0f 84 f7 26 00 00    	je     2a451 <JS_CallInternal+0x7951>
   27d5a:	8d 72 fe             	lea    esi,[rdx-0x2]
   27d5d:	b9 01 00 00 00       	mov    ecx,0x1
   27d62:	83 fe 01             	cmp    esi,0x1
   27d65:	0f 87 55 1a 00 00    	ja     297c0 <JS_CallInternal+0x6cc0>
   27d6b:	48 89 0b             	mov    QWORD PTR [rbx],rcx
   27d6e:	49 83 c4 02          	add    r12,0x2
   27d72:	48 83 c3 10          	add    rbx,0x10
   27d76:	48 c7 43 f8 01 00 00 	mov    QWORD PTR [rbx-0x8],0x1
   27d7d:	00 
   27d7e:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   27d84:	49 89 c5             	mov    r13,rax
   27d87:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   27d8b:	ff e0                	jmp    rax
   27d8d:	f3 0f 1e fa          	endbr64
   27d91:	4c 8b 6b f0          	mov    r13,QWORD PTR [rbx-0x10]
   27d95:	4c 8d 73 f0          	lea    r14,[rbx-0x10]
   27d99:	48 8b 5b f8          	mov    rbx,QWORD PTR [rbx-0x8]
   27d9d:	4c 39 b5 68 fe ff ff 	cmp    QWORD PTR [rbp-0x198],r14
   27da4:	0f 83 0c 12 00 00    	jae    28fb6 <JS_CallInternal+0x64b6>
   27daa:	48 89 d8             	mov    rax,rbx
   27dad:	4c 89 a5 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],r12
   27db4:	4c 89 f3             	mov    rbx,r14
   27db7:	4c 8b a5 68 fe ff ff 	mov    r12,QWORD PTR [rbp-0x198]
   27dbe:	49 89 c6             	mov    r14,rax
   27dc1:	eb 0e                	jmp    27dd1 <JS_CallInternal+0x52d1>
   27dc3:	0f 1f 44 00 00       	nop    DWORD PTR [rax+rax*1+0x0]
   27dc8:	49 39 dc             	cmp    r12,rbx
   27dcb:	0f 83 d5 11 00 00    	jae    28fa6 <JS_CallInternal+0x64a6>
   27dd1:	83 7b f8 05          	cmp    DWORD PTR [rbx-0x8],0x5
   27dd5:	0f 84 cb 11 00 00    	je     28fa6 <JS_CallInternal+0x64a6>
   27ddb:	48 8b 4b f8          	mov    rcx,QWORD PTR [rbx-0x8]
   27ddf:	48 83 eb 10          	sub    rbx,0x10
   27de3:	48 8b 33             	mov    rsi,QWORD PTR [rbx]
   27de6:	83 f9 f6             	cmp    ecx,0xfffffff6
   27de9:	76 dd                	jbe    27dc8 <JS_CallInternal+0x52c8>
   27deb:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   27dee:	8d 50 ff             	lea    edx,[rax-0x1]
   27df1:	89 56 fc             	mov    DWORD PTR [rsi-0x4],edx
   27df4:	85 d2                	test   edx,edx
   27df6:	7f d0                	jg     27dc8 <JS_CallInternal+0x52c8>
   27df8:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   27dff:	48 89 ca             	mov    rdx,rcx
   27e02:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   27e06:	e8 95 4a ff ff       	call   1c8a0 <__JS_FreeValueRT>
   27e0b:	eb bb                	jmp    27dc8 <JS_CallInternal+0x52c8>
   27e0d:	f3 0f 1e fa          	endbr64
   27e11:	48 8b 43 e8          	mov    rax,QWORD PTR [rbx-0x18]
   27e15:	4c 8b 6b f8          	mov    r13,QWORD PTR [rbx-0x8]
   27e19:	83 f8 ff             	cmp    eax,0xffffffff
   27e1c:	0f 85 d6 1f 00 00    	jne    29df8 <JS_CallInternal+0x72f8>
   27e22:	45 85 ed             	test   r13d,r13d
   27e25:	0f 85 45 36 00 00    	jne    2b470 <JS_CallInternal+0x8970>
   27e2b:	48 8b 53 e0          	mov    rdx,QWORD PTR [rbx-0x20]
   27e2f:	48 8b 43 f0          	mov    rax,QWORD PTR [rbx-0x10]
   27e33:	66 83 7a 12 02       	cmp    WORD PTR [rdx+0x12],0x2
   27e38:	0f 85 2f 20 00 00    	jne    29e6d <JS_CallInternal+0x736d>
   27e3e:	3b 42 38             	cmp    eax,DWORD PTR [rdx+0x38]
   27e41:	0f 83 26 20 00 00    	jae    29e6d <JS_CallInternal+0x736d>
   27e47:	89 c0                	mov    eax,eax
   27e49:	48 c1 e0 04          	shl    rax,0x4
   27e4d:	48 03 42 30          	add    rax,QWORD PTR [rdx+0x30]
   27e51:	48 8b 08             	mov    rcx,QWORD PTR [rax]
   27e54:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
   27e58:	83 f8 f6             	cmp    eax,0xfffffff6
   27e5b:	76 04                	jbe    27e61 <JS_CallInternal+0x5361>
   27e5d:	83 41 fc 01          	add    DWORD PTR [rcx-0x4],0x1
   27e61:	48 89 0b             	mov    QWORD PTR [rbx],rcx
   27e64:	49 83 c4 01          	add    r12,0x1
   27e68:	48 83 c3 10          	add    rbx,0x10
   27e6c:	48 89 43 f8          	mov    QWORD PTR [rbx-0x8],rax
   27e70:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   27e76:	49 89 c5             	mov    r13,rax
   27e79:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   27e7d:	ff e0                	jmp    rax
   27e7f:	f3 0f 1e fa          	endbr64
   27e83:	83 7b e8 ff          	cmp    DWORD PTR [rbx-0x18],0xffffffff
   27e87:	48 8b 73 e0          	mov    rsi,QWORD PTR [rbx-0x20]
   27e8b:	48 8b 4b e8          	mov    rcx,QWORD PTR [rbx-0x18]
   27e8f:	4c 8b 43 f0          	mov    r8,QWORD PTR [rbx-0x10]
   27e93:	48 8b 7b f8          	mov    rdi,QWORD PTR [rbx-0x8]
   27e97:	0f 85 e3 1b 00 00    	jne    29a80 <JS_CallInternal+0x6f80>
   27e9d:	85 ff                	test   edi,edi
   27e9f:	0f 85 db 1b 00 00    	jne    29a80 <JS_CallInternal+0x6f80>
   27ea5:	66 83 7e 12 02       	cmp    WORD PTR [rsi+0x12],0x2
   27eaa:	0f 85 d0 1b 00 00    	jne    29a80 <JS_CallInternal+0x6f80>
   27eb0:	44 3b 46 38          	cmp    r8d,DWORD PTR [rsi+0x38]
   27eb4:	0f 83 c6 1b 00 00    	jae    29a80 <JS_CallInternal+0x6f80>
   27eba:	44 89 c0             	mov    eax,r8d
   27ebd:	48 c1 e0 04          	shl    rax,0x4
   27ec1:	48 03 46 30          	add    rax,QWORD PTR [rsi+0x30]
   27ec5:	48 8b 10             	mov    rdx,QWORD PTR [rax]
   27ec8:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
   27ecc:	83 f8 f6             	cmp    eax,0xfffffff6
   27ecf:	76 04                	jbe    27ed5 <JS_CallInternal+0x53d5>
   27ed1:	83 42 fc 01          	add    DWORD PTR [rdx-0x4],0x1
   27ed5:	48 89 53 f0          	mov    QWORD PTR [rbx-0x10],rdx
   27ed9:	49 83 c4 01          	add    r12,0x1
   27edd:	48 89 43 f8          	mov    QWORD PTR [rbx-0x8],rax
   27ee1:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   27ee7:	49 89 c5             	mov    r13,rax
   27eea:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   27eee:	ff e0                	jmp    rax
   27ef0:	f3 0f 1e fa          	endbr64
   27ef4:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   27efb:	48 8b 73 f0          	mov    rsi,QWORD PTR [rbx-0x10]
   27eff:	4c 8d 73 f0          	lea    r14,[rbx-0x10]
   27f03:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   27f0a:	49 8b 56 08          	mov    rdx,QWORD PTR [r14+0x8]
   27f0e:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   27f12:	e8 f9 b5 01 00       	call   43510 <JS_ValueToAtom>
   27f17:	41 89 c5             	mov    r13d,eax
   27f1a:	45 85 ed             	test   r13d,r13d
   27f1d:	0f 84 7d b3 ff ff    	je     232a0 <JS_CallInternal+0x7a0>
   27f23:	48 83 ec 08          	sub    rsp,0x8
   27f27:	4c 8d 53 e0          	lea    r10,[rbx-0x20]
   27f2b:	48 8d 43 d0          	lea    rax,[rbx-0x30]
   27f2f:	4c 8b 43 d0          	mov    r8,QWORD PTR [rbx-0x30]
   27f33:	4c 89 95 38 fe ff ff 	mov    QWORD PTR [rbp-0x1c8],r10
   27f3a:	4c 8b 4b d8          	mov    r9,QWORD PTR [rbx-0x28]
   27f3e:	44 89 e9             	mov    ecx,r13d
   27f41:	48 8b 73 e0          	mov    rsi,QWORD PTR [rbx-0x20]
   27f45:	48 89 85 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],rax
   27f4c:	48 8b 53 e8          	mov    rdx,QWORD PTR [rbx-0x18]
   27f50:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   27f57:	6a 00                	push   0x0
   27f59:	e8 82 4e 00 00       	call   2cde0 <JS_GetPropertyInternal>
   27f5e:	41 81 fd f2 00 00 00 	cmp    r13d,0xf2
   27f65:	4c 8b 95 38 fe ff ff 	mov    r10,QWORD PTR [rbp-0x1c8]
   27f6c:	48 89 85 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],rax
   27f73:	48 89 d0             	mov    rax,rdx
   27f76:	5a                   	pop    rdx
   27f77:	59                   	pop    rcx
   27f78:	0f 8f 34 1e 00 00    	jg     29db2 <JS_CallInternal+0x72b2>
   27f7e:	83 f8 06             	cmp    eax,0x6
   27f81:	0f 84 19 b3 ff ff    	je     232a0 <JS_CallInternal+0x7a0>
   27f87:	49 8b 56 08          	mov    rdx,QWORD PTR [r14+0x8]
   27f8b:	49 8b 36             	mov    rsi,QWORD PTR [r14]
   27f8e:	83 fa f6             	cmp    edx,0xfffffff6
   27f91:	76 11                	jbe    27fa4 <JS_CallInternal+0x54a4>
   27f93:	8b 4e fc             	mov    ecx,DWORD PTR [rsi-0x4]
   27f96:	83 e9 01             	sub    ecx,0x1
   27f99:	89 4e fc             	mov    DWORD PTR [rsi-0x4],ecx
   27f9c:	85 c9                	test   ecx,ecx
   27f9e:	0f 8e c7 2f 00 00    	jle    2af6b <JS_CallInternal+0x846b>
   27fa4:	49 8b 52 08          	mov    rdx,QWORD PTR [r10+0x8]
   27fa8:	49 8b 32             	mov    rsi,QWORD PTR [r10]
   27fab:	83 fa f6             	cmp    edx,0xfffffff6
   27fae:	76 11                	jbe    27fc1 <JS_CallInternal+0x54c1>
   27fb0:	8b 4e fc             	mov    ecx,DWORD PTR [rsi-0x4]
   27fb3:	83 e9 01             	sub    ecx,0x1
   27fb6:	89 4e fc             	mov    DWORD PTR [rsi-0x4],ecx
   27fb9:	85 c9                	test   ecx,ecx
   27fbb:	0f 8e 48 2f 00 00    	jle    2af09 <JS_CallInternal+0x8409>
   27fc1:	48 8b 8d 50 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x1b0]
   27fc8:	48 8b 51 08          	mov    rdx,QWORD PTR [rcx+0x8]
   27fcc:	48 8b 31             	mov    rsi,QWORD PTR [rcx]
   27fcf:	83 fa f6             	cmp    edx,0xfffffff6
   27fd2:	76 11                	jbe    27fe5 <JS_CallInternal+0x54e5>
   27fd4:	8b 4e fc             	mov    ecx,DWORD PTR [rsi-0x4]
   27fd7:	83 e9 01             	sub    ecx,0x1
   27fda:	89 4e fc             	mov    DWORD PTR [rsi-0x4],ecx
   27fdd:	85 c9                	test   ecx,ecx
   27fdf:	0f 8e 55 2f 00 00    	jle    2af3a <JS_CallInternal+0x843a>
   27fe5:	48 8b 8d 40 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x1c0]
   27fec:	48 89 43 d8          	mov    QWORD PTR [rbx-0x28],rax
   27ff0:	49 83 c4 01          	add    r12,0x1
   27ff4:	48 89 4b d0          	mov    QWORD PTR [rbx-0x30],rcx
   27ff8:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   27ffe:	4c 89 d3             	mov    rbx,r10
   28001:	49 89 c5             	mov    r13,rax
   28004:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   28008:	ff e0                	jmp    rax
   2800a:	f3 0f 1e fa          	endbr64
   2800e:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   28015:	48 8b 73 f0          	mov    rsi,QWORD PTR [rbx-0x10]
   28019:	48 8b 53 f8          	mov    rdx,QWORD PTR [rbx-0x8]
   2801d:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   28024:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   28028:	e8 e3 b4 01 00       	call   43510 <JS_ValueToAtom>
   2802d:	41 89 c5             	mov    r13d,eax
   28030:	45 85 ed             	test   r13d,r13d
   28033:	0f 84 67 b2 ff ff    	je     232a0 <JS_CallInternal+0x7a0>
   28039:	48 8b 53 e8          	mov    rdx,QWORD PTR [rbx-0x18]
   2803d:	83 fa 03             	cmp    edx,0x3
   28040:	0f 84 a2 39 00 00    	je     2b9e8 <JS_CallInternal+0x8ee8>
   28046:	48 8b 73 e0          	mov    rsi,QWORD PTR [rbx-0x20]
   2804a:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   28051:	44 89 e9             	mov    ecx,r13d
   28054:	e8 37 62 04 00       	call   6e290 <JS_HasProperty>
   28059:	85 c0                	test   eax,eax
   2805b:	0f 8e 28 39 00 00    	jle    2b989 <JS_CallInternal+0x8e89>
   28061:	48 83 ec 08          	sub    rsp,0x8
   28065:	4c 8b 43 e0          	mov    r8,QWORD PTR [rbx-0x20]
   28069:	4c 8b 4b e8          	mov    r9,QWORD PTR [rbx-0x18]
   2806d:	44 89 e9             	mov    ecx,r13d
   28070:	6a 00                	push   0x0
   28072:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   28079:	4c 89 c6             	mov    rsi,r8
   2807c:	4c 89 ca             	mov    rdx,r9
   2807f:	e8 5c 4d 00 00       	call   2cde0 <JS_GetPropertyInternal>
   28084:	5e                   	pop    rsi
   28085:	5f                   	pop    rdi
   28086:	48 89 c1             	mov    rcx,rax
   28089:	49 89 d6             	mov    r14,rdx
   2808c:	48 89 d0             	mov    rax,rdx
   2808f:	41 81 fd f2 00 00 00 	cmp    r13d,0xf2
   28096:	0f 8f 7d 1f 00 00    	jg     2a019 <JS_CallInternal+0x7519>
   2809c:	41 83 fe 06          	cmp    r14d,0x6
   280a0:	0f 84 fa b1 ff ff    	je     232a0 <JS_CallInternal+0x7a0>
   280a6:	48 89 0b             	mov    QWORD PTR [rbx],rcx
   280a9:	49 83 c4 01          	add    r12,0x1
   280ad:	48 83 c3 10          	add    rbx,0x10
   280b1:	48 89 43 f8          	mov    QWORD PTR [rbx-0x8],rax
   280b5:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   280bb:	49 89 c5             	mov    r13,rax
   280be:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   280c2:	ff e0                	jmp    rax
   280c4:	f3 0f 1e fa          	endbr64
   280c8:	83 7b d8 ff          	cmp    DWORD PTR [rbx-0x28],0xffffffff
   280cc:	0f 85 41 19 00 00    	jne    29a13 <JS_CallInternal+0x6f13>
   280d2:	44 8b 5b e8          	mov    r11d,DWORD PTR [rbx-0x18]
   280d6:	45 85 db             	test   r11d,r11d
   280d9:	0f 85 34 19 00 00    	jne    29a13 <JS_CallInternal+0x6f13>
   280df:	48 8b 4b d0          	mov    rcx,QWORD PTR [rbx-0x30]
   280e3:	48 8b 43 e0          	mov    rax,QWORD PTR [rbx-0x20]
   280e7:	66 83 79 12 02       	cmp    WORD PTR [rcx+0x12],0x2
   280ec:	0f 85 21 19 00 00    	jne    29a13 <JS_CallInternal+0x6f13>
   280f2:	8b 51 38             	mov    edx,DWORD PTR [rcx+0x38]
   280f5:	39 d0                	cmp    eax,edx
   280f7:	0f 83 18 3a 00 00    	jae    2bb15 <JS_CallInternal+0x9015>
   280fd:	89 c0                	mov    eax,eax
   280ff:	f3 0f 6f 6b f0       	movdqu xmm5,XMMWORD PTR [rbx-0x10]
   28104:	48 c1 e0 04          	shl    rax,0x4
   28108:	48 03 41 30          	add    rax,QWORD PTR [rcx+0x30]
   2810c:	48 8b 50 08          	mov    rdx,QWORD PTR [rax+0x8]
   28110:	48 8b 30             	mov    rsi,QWORD PTR [rax]
   28113:	0f 11 28             	movups XMMWORD PTR [rax],xmm5
   28116:	83 fa f6             	cmp    edx,0xfffffff6
   28119:	76 11                	jbe    2812c <JS_CallInternal+0x562c>
   2811b:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   2811e:	83 e8 01             	sub    eax,0x1
   28121:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   28124:	85 c0                	test   eax,eax
   28126:	0f 8e c2 3b 00 00    	jle    2bcee <JS_CallInternal+0x91ee>
   2812c:	48 8b 53 d8          	mov    rdx,QWORD PTR [rbx-0x28]
   28130:	48 83 eb 30          	sub    rbx,0x30
   28134:	48 8b 33             	mov    rsi,QWORD PTR [rbx]
   28137:	83 fa f6             	cmp    edx,0xfffffff6
   2813a:	76 11                	jbe    2814d <JS_CallInternal+0x564d>
   2813c:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   2813f:	83 e8 01             	sub    eax,0x1
   28142:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   28145:	85 c0                	test   eax,eax
   28147:	0f 8e 53 3a 00 00    	jle    2bba0 <JS_CallInternal+0x90a0>
   2814d:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   28152:	49 83 c4 01          	add    r12,0x1
   28156:	49 89 c5             	mov    r13,rax
   28159:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   2815d:	ff e0                	jmp    rax
   2815f:	f3 0f 1e fa          	endbr64
   28163:	48 8b 4b f0          	mov    rcx,QWORD PTR [rbx-0x10]
   28167:	83 7b f8 03          	cmp    DWORD PTR [rbx-0x8],0x3
   2816b:	4d 8d 6c 24 01       	lea    r13,[r12+0x1]
   28170:	48 8b 53 f8          	mov    rdx,QWORD PTR [rbx-0x8]
   28174:	48 89 c8             	mov    rax,rcx
   28177:	0f 87 dc 1a 00 00    	ja     29c59 <JS_CallInternal+0x7159>
   2817d:	48 83 eb 10          	sub    rbx,0x10
   28181:	85 c0                	test   eax,eax
   28183:	75 0d                	jne    28192 <JS_CallInternal+0x5692>
   28185:	41 0f be 04 24       	movsx  eax,BYTE PTR [r12]
   2818a:	83 e8 01             	sub    eax,0x1
   2818d:	48 98                	cdqe
   2818f:	49 01 c5             	add    r13,rax
   28192:	48 8b 8d e8 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x118]
   28199:	8b 81 a8 01 00 00    	mov    eax,DWORD PTR [rcx+0x1a8]
   2819f:	89 85 50 fe ff ff    	mov    DWORD PTR [rbp-0x1b0],eax
   281a5:	83 e8 01             	sub    eax,0x1
   281a8:	89 81 a8 01 00 00    	mov    DWORD PTR [rcx+0x1a8],eax
   281ae:	85 c0                	test   eax,eax
   281b0:	0f 8e 07 30 00 00    	jle    2b1bd <JS_CallInternal+0x86bd>
   281b6:	41 0f b6 45 00       	movzx  eax,BYTE PTR [r13+0x0]
   281bb:	4d 8d 65 01          	lea    r12,[r13+0x1]
   281bf:	49 89 c5             	mov    r13,rax
   281c2:	41 ff 24 c7          	jmp    QWORD PTR [r15+rax*8]
   281c6:	f3 0f 1e fa          	endbr64
   281ca:	48 8b 4b f0          	mov    rcx,QWORD PTR [rbx-0x10]
   281ce:	83 7b f8 03          	cmp    DWORD PTR [rbx-0x8],0x3
   281d2:	4d 8d 6c 24 01       	lea    r13,[r12+0x1]
   281d7:	48 8b 53 f8          	mov    rdx,QWORD PTR [rbx-0x8]
   281db:	48 89 c8             	mov    rax,rcx
   281de:	0f 87 61 1a 00 00    	ja     29c45 <JS_CallInternal+0x7145>
   281e4:	48 83 eb 10          	sub    rbx,0x10
   281e8:	85 c0                	test   eax,eax
   281ea:	74 0d                	je     281f9 <JS_CallInternal+0x56f9>
   281ec:	41 0f be 04 24       	movsx  eax,BYTE PTR [r12]
   281f1:	83 e8 01             	sub    eax,0x1
   281f4:	48 98                	cdqe
   281f6:	49 01 c5             	add    r13,rax
   281f9:	48 8b 8d e8 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x118]
   28200:	8b 81 a8 01 00 00    	mov    eax,DWORD PTR [rcx+0x1a8]
   28206:	89 85 50 fe ff ff    	mov    DWORD PTR [rbp-0x1b0],eax
   2820c:	83 e8 01             	sub    eax,0x1
   2820f:	89 81 a8 01 00 00    	mov    DWORD PTR [rcx+0x1a8],eax
   28215:	85 c0                	test   eax,eax
   28217:	0f 8e ff 30 00 00    	jle    2b31c <JS_CallInternal+0x881c>
   2821d:	41 0f b6 45 00       	movzx  eax,BYTE PTR [r13+0x0]
   28222:	4d 8d 65 01          	lea    r12,[r13+0x1]
   28226:	49 89 c5             	mov    r13,rax
   28229:	41 ff 24 c7          	jmp    QWORD PTR [r15+rax*8]
   2822d:	f3 0f 1e fa          	endbr64
   28231:	48 8b 8d e8 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x118]
   28238:	4d 0f be 2c 24       	movsx  r13,BYTE PTR [r12]
   2823d:	8b 81 a8 01 00 00    	mov    eax,DWORD PTR [rcx+0x1a8]
   28243:	4d 01 e5             	add    r13,r12
   28246:	89 85 50 fe ff ff    	mov    DWORD PTR [rbp-0x1b0],eax
   2824c:	83 e8 01             	sub    eax,0x1
   2824f:	89 81 a8 01 00 00    	mov    DWORD PTR [rcx+0x1a8],eax
   28255:	85 c0                	test   eax,eax
   28257:	0f 8e e5 36 00 00    	jle    2b942 <JS_CallInternal+0x8e42>
   2825d:	41 0f b6 45 00       	movzx  eax,BYTE PTR [r13+0x0]
   28262:	4d 8d 65 01          	lea    r12,[r13+0x1]
   28266:	49 89 c5             	mov    r13,rax
   28269:	41 ff 24 c7          	jmp    QWORD PTR [r15+rax*8]
   2826d:	f3 0f 1e fa          	endbr64
   28271:	48 8d 43 e0          	lea    rax,[rbx-0x20]
   28275:	83 7b e8 ff          	cmp    DWORD PTR [rbx-0x18],0xffffffff
   28279:	4c 8d 73 f0          	lea    r14,[rbx-0x10]
   2827d:	4c 8b 43 e0          	mov    r8,QWORD PTR [rbx-0x20]
   28281:	4c 8b 6b f0          	mov    r13,QWORD PTR [rbx-0x10]
   28285:	4d 8b 4e 08          	mov    r9,QWORD PTR [r14+0x8]
   28289:	48 89 85 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],rax
   28290:	0f 85 29 2b 00 00    	jne    2adbf <JS_CallInternal+0x82bf>
   28296:	41 83 f9 f8          	cmp    r9d,0xfffffff8
   2829a:	0f 85 a1 2e 00 00    	jne    2b141 <JS_CallInternal+0x8641>
   282a0:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   282a7:	4c 89 ee             	mov    rsi,r13
   282aa:	4c 89 85 38 fe ff ff 	mov    QWORD PTR [rbp-0x1c8],r8
   282b1:	4c 89 8d 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],r9
   282b8:	48 8b 40 10          	mov    rax,QWORD PTR [rax+0x10]
   282bc:	48 89 c7             	mov    rdi,rax
   282bf:	48 89 85 28 fe ff ff 	mov    QWORD PTR [rbp-0x1d8],rax
   282c6:	e8 85 e8 fe ff       	call   16b50 <js_get_atom_index>
   282cb:	4c 8b 85 38 fe ff ff 	mov    r8,QWORD PTR [rbp-0x1c8]
   282d2:	89 c2                	mov    edx,eax
   282d4:	49 8b 70 18          	mov    rsi,QWORD PTR [r8+0x18]
   282d8:	8b 4e 18             	mov    ecx,DWORD PTR [rsi+0x18]
   282db:	21 c8                	and    eax,ecx
   282dd:	8b 44 86 38          	mov    eax,DWORD PTR [rsi+rax*4+0x38]
   282e1:	48 85 c0             	test   rax,rax
   282e4:	0f 84 29 39 00 00    	je     2bc13 <JS_CallInternal+0x9113>
   282ea:	4c 8b 8d 40 fe ff ff 	mov    r9,QWORD PTR [rbp-0x1c0]
   282f1:	48 8d 3c 8d 34 00 00 	lea    rdi,[rcx*4+0x34]
   282f8:	00 
   282f9:	48 8d 0c c7          	lea    rcx,[rdi+rax*8]
   282fd:	48 01 f1             	add    rcx,rsi
   28300:	3b 51 04             	cmp    edx,DWORD PTR [rcx+0x4]
   28303:	0f 85 fd 38 00 00    	jne    2bc06 <JS_CallInternal+0x9106>
   28309:	49 8b 50 20          	mov    rdx,QWORD PTR [r8+0x20]
   2830d:	48 c1 e0 04          	shl    rax,0x4
   28311:	48 8d 44 02 f0       	lea    rax,[rdx+rax*1-0x10]
   28316:	48 8b 10             	mov    rdx,QWORD PTR [rax]
   28319:	48 8b 40 08          	mov    rax,QWORD PTR [rax+0x8]
   2831d:	83 f8 f6             	cmp    eax,0xfffffff6
   28320:	76 04                	jbe    28326 <JS_CallInternal+0x5826>
   28322:	83 42 fc 01          	add    DWORD PTR [rdx-0x4],0x1
   28326:	48 89 d1             	mov    rcx,rdx
   28329:	41 89 c0             	mov    r8d,eax
   2832c:	41 83 f9 f6          	cmp    r9d,0xfffffff6
   28330:	76 13                	jbe    28345 <JS_CallInternal+0x5845>
   28332:	41 8b 7d fc          	mov    edi,DWORD PTR [r13-0x4]
   28336:	8d 57 ff             	lea    edx,[rdi-0x1]
   28339:	41 89 55 fc          	mov    DWORD PTR [r13-0x4],edx
   2833d:	85 d2                	test   edx,edx
   2833f:	0f 8e ae 28 00 00    	jle    2abf3 <JS_CallInternal+0x80f3>
   28345:	48 8b bd 50 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x1b0]
   2834c:	48 8b 57 08          	mov    rdx,QWORD PTR [rdi+0x8]
   28350:	48 8b 37             	mov    rsi,QWORD PTR [rdi]
   28353:	83 fa f6             	cmp    edx,0xfffffff6
   28356:	76 11                	jbe    28369 <JS_CallInternal+0x5869>
   28358:	8b 7e fc             	mov    edi,DWORD PTR [rsi-0x4]
   2835b:	83 ef 01             	sub    edi,0x1
   2835e:	89 7e fc             	mov    DWORD PTR [rsi-0x4],edi
   28361:	85 ff                	test   edi,edi
   28363:	0f 8e f1 26 00 00    	jle    2aa5a <JS_CallInternal+0x7f5a>
   28369:	48 89 4b e0          	mov    QWORD PTR [rbx-0x20],rcx
   2836d:	48 89 43 e8          	mov    QWORD PTR [rbx-0x18],rax
   28371:	4c 89 f3             	mov    rbx,r14
   28374:	41 83 f8 06          	cmp    r8d,0x6
   28378:	0f 84 22 af ff ff    	je     232a0 <JS_CallInternal+0x7a0>
   2837e:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   28383:	49 83 c4 01          	add    r12,0x1
   28387:	49 89 c5             	mov    r13,rax
   2838a:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   2838e:	ff e0                	jmp    rax
   28390:	f3 0f 1e fa          	endbr64
   28394:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   2839b:	48 8b 4b d0          	mov    rcx,QWORD PTR [rbx-0x30]
   2839f:	45 31 c9             	xor    r9d,r9d
   283a2:	48 c7 85 f0 fd ff ff 	mov    QWORD PTR [rbp-0x210],0x0
   283a9:	00 00 00 00 
   283ad:	48 c7 85 f8 fd ff ff 	mov    QWORD PTR [rbp-0x208],0x3
   283b4:	03 00 00 00 
   283b8:	4c 8b 43 d8          	mov    r8,QWORD PTR [rbx-0x28]
   283bc:	48 8b 73 e0          	mov    rsi,QWORD PTR [rbx-0x20]
   283c0:	48 8b 53 e8          	mov    rdx,QWORD PTR [rbx-0x18]
   283c4:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   283c8:	48 c7 43 f0 00 00 00 	mov    QWORD PTR [rbx-0x10],0x0
   283cf:	00 
   283d0:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   283d7:	48 c7 43 f8 03 00 00 	mov    QWORD PTR [rbx-0x8],0x3
   283de:	00 
   283df:	6a 02                	push   0x2
   283e1:	6a 00                	push   0x0
   283e3:	ff b5 f8 fd ff ff    	push   QWORD PTR [rbp-0x208]
   283e9:	ff b5 f0 fd ff ff    	push   QWORD PTR [rbp-0x210]
   283ef:	e8 0c a7 ff ff       	call   22b00 <JS_CallInternal>
   283f4:	48 83 c4 20          	add    rsp,0x20
   283f8:	83 fa 06             	cmp    edx,0x6
   283fb:	0f 84 9f ae ff ff    	je     232a0 <JS_CallInternal+0x7a0>
   28401:	48 89 03             	mov    QWORD PTR [rbx],rax
   28404:	49 83 c4 01          	add    r12,0x1
   28408:	48 83 c3 10          	add    rbx,0x10
   2840c:	48 89 53 f8          	mov    QWORD PTR [rbx-0x8],rdx
   28410:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   28416:	49 89 c5             	mov    r13,rax
   28419:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   2841d:	ff e0                	jmp    rax
   2841f:	f3 0f 1e fa          	endbr64
   28423:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   2842a:	41 0f b6 0c 24       	movzx  ecx,BYTE PTR [r12]
   2842f:	4d 8d 74 24 01       	lea    r14,[r12+0x1]
   28434:	c7 85 f0 fe ff ff 01 	mov    DWORD PTR [rbp-0x110],0x1
   2843b:	00 00 00 
   2843e:	4c 89 70 30          	mov    QWORD PTR [rax+0x30],r14
   28442:	b8 fd ff ff ff       	mov    eax,0xfffffffd
   28447:	29 c8                	sub    eax,ecx
   28449:	48 98                	cdqe
   2844b:	48 c1 e0 04          	shl    rax,0x4
   2844f:	4c 8d 2c 03          	lea    r13,[rbx+rax*1]
   28453:	49 8b 55 08          	mov    rdx,QWORD PTR [r13+0x8]
   28457:	83 fa 03             	cmp    edx,0x3
   2845a:	0f 84 d0 2c 00 00    	je     2b130 <JS_CallInternal+0x8630>
   28460:	b8 fe ff ff ff       	mov    eax,0xfffffffe
   28465:	49 8b 75 00          	mov    rsi,QWORD PTR [r13+0x0]
   28469:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   28470:	4c 8d 8d f0 fe ff ff 	lea    r9,[rbp-0x110]
   28477:	29 c8                	sub    eax,ecx
   28479:	48 98                	cdqe
   2847b:	48 c1 e0 04          	shl    rax,0x4
   2847f:	48 01 d8             	add    rax,rbx
   28482:	48 8b 08             	mov    rcx,QWORD PTR [rax]
   28485:	4c 8b 40 08          	mov    r8,QWORD PTR [rax+0x8]
   28489:	e8 b2 ed 06 00       	call   97240 <JS_IteratorNext.constprop.0>
   2848e:	49 89 d1             	mov    r9,rdx
   28491:	48 89 c7             	mov    rdi,rax
   28494:	48 89 d6             	mov    rsi,rdx
   28497:	83 fa 06             	cmp    edx,0x6
   2849a:	0f 84 01 1b 00 00    	je     29fa1 <JS_CallInternal+0x74a1>
   284a0:	8b 8d f0 fe ff ff    	mov    ecx,DWORD PTR [rbp-0x110]
   284a6:	31 d2                	xor    edx,edx
   284a8:	85 c9                	test   ecx,ecx
   284aa:	0f 85 00 1b 00 00    	jne    29fb0 <JS_CallInternal+0x74b0>
   284b0:	48 89 3b             	mov    QWORD PTR [rbx],rdi
   284b3:	49 83 c4 02          	add    r12,0x2
   284b7:	48 83 c3 20          	add    rbx,0x20
   284bb:	48 89 73 e8          	mov    QWORD PTR [rbx-0x18],rsi
   284bf:	48 89 53 f0          	mov    QWORD PTR [rbx-0x10],rdx
   284c3:	48 c7 43 f8 01 00 00 	mov    QWORD PTR [rbx-0x8],0x1
   284ca:	00 
   284cb:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   284d1:	49 89 c5             	mov    r13,rax
   284d4:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   284d8:	ff e0                	jmp    rax
   284da:	f3 0f 1e fa          	endbr64
   284de:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   284e5:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   284ec:	ba 01 00 00 00       	mov    edx,0x1
   284f1:	48 89 de             	mov    rsi,rbx
   284f4:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   284f8:	e8 53 d6 06 00       	call   95b50 <js_for_of_start>
   284fd:	85 c0                	test   eax,eax
   284ff:	0f 85 9b ad ff ff    	jne    232a0 <JS_CallInternal+0x7a0>
   28505:	48 c7 43 10 00 00 00 	mov    QWORD PTR [rbx+0x10],0x0
   2850c:	00 
   2850d:	49 83 c4 01          	add    r12,0x1
   28511:	48 83 c3 20          	add    rbx,0x20
   28515:	48 c7 43 f8 05 00 00 	mov    QWORD PTR [rbx-0x8],0x5
   2851c:	00 
   2851d:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   28523:	49 89 c5             	mov    r13,rax
   28526:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   2852a:	ff e0                	jmp    rax
   2852c:	f3 0f 1e fa          	endbr64
   28530:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   28537:	48 8b 73 f0          	mov    rsi,QWORD PTR [rbx-0x10]
   2853b:	48 8b 53 f8          	mov    rdx,QWORD PTR [rbx-0x8]
   2853f:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   28546:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   2854a:	e8 81 52 04 00       	call   6d7d0 <build_for_in_iterator>
   2854f:	48 89 53 f8          	mov    QWORD PTR [rbx-0x8],rdx
   28553:	83 7b f8 06          	cmp    DWORD PTR [rbx-0x8],0x6
   28557:	48 89 43 f0          	mov    QWORD PTR [rbx-0x10],rax
   2855b:	0f 84 3f ad ff ff    	je     232a0 <JS_CallInternal+0x7a0>
   28561:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   28566:	49 83 c4 01          	add    r12,0x1
   2856a:	49 89 c5             	mov    r13,rax
   2856d:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   28571:	ff e0                	jmp    rax
   28573:	f3 0f 1e fa          	endbr64
   28577:	44 8b 4b f8          	mov    r9d,DWORD PTR [rbx-0x8]
   2857b:	48 8b 43 f0          	mov    rax,QWORD PTR [rbx-0x10]
   2857f:	45 85 c9             	test   r9d,r9d
   28582:	0f 85 1f 1e 00 00    	jne    2a3a7 <JS_CallInternal+0x78a7>
   28588:	48 8b 8d d8 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x128]
   2858f:	3b 41 20             	cmp    eax,DWORD PTR [rcx+0x20]
   28592:	0f 83 0f 1e 00 00    	jae    2a3a7 <JS_CallInternal+0x78a7>
   28598:	48 8b 8d d8 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x128]
   2859f:	89 c0                	mov    eax,eax
   285a1:	48 83 eb 10          	sub    rbx,0x10
   285a5:	48 03 41 18          	add    rax,QWORD PTR [rcx+0x18]
   285a9:	4c 8d 60 01          	lea    r12,[rax+0x1]
   285ad:	0f b6 00             	movzx  eax,BYTE PTR [rax]
   285b0:	49 89 c5             	mov    r13,rax
   285b3:	41 ff 24 c7          	jmp    QWORD PTR [r15+rax*8]
   285b7:	f3 0f 1e fa          	endbr64
   285bb:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   285c2:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   285c9:	48 89 de             	mov    rsi,rbx
   285cc:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   285d0:	e8 9b 54 04 00       	call   6da70 <js_for_in_next>
   285d5:	85 c0                	test   eax,eax
   285d7:	0f 85 c3 ac ff ff    	jne    232a0 <JS_CallInternal+0x7a0>
   285dd:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   285e2:	48 83 c3 20          	add    rbx,0x20
   285e6:	49 83 c4 01          	add    r12,0x1
   285ea:	49 89 c5             	mov    r13,rax
   285ed:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   285f1:	ff e0                	jmp    rax
   285f3:	f3 0f 1e fa          	endbr64
   285f7:	e9 18 aa ff ff       	jmp    23014 <JS_CallInternal+0x514>
   285fc:	f3 0f 1e fa          	endbr64
   28600:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   28607:	4d 8d 6c 24 04       	lea    r13,[r12+0x4]
   2860c:	41 8b 34 24          	mov    esi,DWORD PTR [r12]
   28610:	48 89 da             	mov    rdx,rbx
   28613:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2861a:	4c 89 68 30          	mov    QWORD PTR [rax+0x30],r13
   2861e:	e8 dd 5d 04 00       	call   6e400 <JS_GetGlobalVarRef>
   28623:	85 c0                	test   eax,eax
   28625:	0f 85 e3 43 00 00    	jne    2ca0e <JS_CallInternal+0x9f0e>
   2862b:	41 0f b6 44 24 04    	movzx  eax,BYTE PTR [r12+0x4]
   28631:	48 83 c3 20          	add    rbx,0x20
   28635:	49 83 c4 05          	add    r12,0x5
   28639:	49 89 c5             	mov    r13,rax
   2863c:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   28640:	ff e0                	jmp    rax
   28642:	f3 0f 1e fa          	endbr64
   28646:	41 0f b7 04 24       	movzx  eax,WORD PTR [r12]
   2864b:	48 8b 8d b0 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x150]
   28652:	4d 8d 6c 24 02       	lea    r13,[r12+0x2]
   28657:	48 89 c2             	mov    rdx,rax
   2865a:	48 c1 e0 04          	shl    rax,0x4
   2865e:	48 01 c8             	add    rax,rcx
   28661:	48 8b 48 08          	mov    rcx,QWORD PTR [rax+0x8]
   28665:	83 f9 04             	cmp    ecx,0x4
   28668:	0f 84 cb 31 00 00    	je     2b839 <JS_CallInternal+0x8d39>
   2866e:	48 8b 53 f8          	mov    rdx,QWORD PTR [rbx-0x8]
   28672:	48 8b 73 f0          	mov    rsi,QWORD PTR [rbx-0x10]
   28676:	83 fa f6             	cmp    edx,0xfffffff6
   28679:	76 04                	jbe    2867f <JS_CallInternal+0x5b7f>
   2867b:	83 46 fc 01          	add    DWORD PTR [rsi-0x4],0x1
   2867f:	4c 8b 00             	mov    r8,QWORD PTR [rax]
   28682:	48 89 50 08          	mov    QWORD PTR [rax+0x8],rdx
   28686:	48 89 30             	mov    QWORD PTR [rax],rsi
   28689:	83 f9 f6             	cmp    ecx,0xfffffff6
   2868c:	76 13                	jbe    286a1 <JS_CallInternal+0x5ba1>
   2868e:	41 8b 40 fc          	mov    eax,DWORD PTR [r8-0x4]
   28692:	83 e8 01             	sub    eax,0x1
   28695:	41 89 40 fc          	mov    DWORD PTR [r8-0x4],eax
   28699:	85 c0                	test   eax,eax
   2869b:	0f 8e 96 20 00 00    	jle    2a737 <JS_CallInternal+0x7c37>
   286a1:	41 0f b6 44 24 02    	movzx  eax,BYTE PTR [r12+0x2]
   286a7:	49 83 c4 03          	add    r12,0x3
   286ab:	49 89 c5             	mov    r13,rax
   286ae:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   286b2:	ff e0                	jmp    rax
   286b4:	f3 0f 1e fa          	endbr64
   286b8:	4c 8b 43 e8          	mov    r8,QWORD PTR [rbx-0x18]
   286bc:	48 8b 4b e0          	mov    rcx,QWORD PTR [rbx-0x20]
   286c0:	4c 8d 73 f0          	lea    r14,[rbx-0x10]
   286c4:	41 83 f8 f6          	cmp    r8d,0xfffffff6
   286c8:	76 04                	jbe    286ce <JS_CallInternal+0x5bce>
   286ca:	83 41 fc 01          	add    DWORD PTR [rcx-0x4],0x1
   286ce:	48 8b 73 d0          	mov    rsi,QWORD PTR [rbx-0x30]
   286d2:	48 8b 53 d8          	mov    rdx,QWORD PTR [rbx-0x28]
   286d6:	41 ff 76 08          	push   QWORD PTR [r14+0x8]
   286da:	41 b9 07 40 00 00    	mov    r9d,0x4007
   286e0:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   286e7:	41 ff 36             	push   QWORD PTR [r14]
   286ea:	e8 b1 af 01 00       	call   436a0 <JS_DefinePropertyValueValue>
   286ef:	59                   	pop    rcx
   286f0:	5e                   	pop    rsi
   286f1:	85 c0                	test   eax,eax
   286f3:	0f 88 bc 2a 00 00    	js     2b1b5 <JS_CallInternal+0x86b5>
   286f9:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   286fe:	4c 89 f3             	mov    rbx,r14
   28701:	49 83 c4 01          	add    r12,0x1
   28705:	49 89 c5             	mov    r13,rax
   28708:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   2870c:	ff e0                	jmp    rax
   2870e:	f3 0f 1e fa          	endbr64
   28712:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   28719:	83 7b d8 ff          	cmp    DWORD PTR [rbx-0x28],0xffffffff
   2871d:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   28721:	0f 85 a8 3b 00 00    	jne    2c2cf <JS_CallInternal+0x97cf>
   28727:	48 8b 73 e0          	mov    rsi,QWORD PTR [rbx-0x20]
   2872b:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   28732:	4c 8d 73 e0          	lea    r14,[rbx-0x20]
   28736:	49 8b 56 08          	mov    rdx,QWORD PTR [r14+0x8]
   2873a:	e8 d1 ad 01 00       	call   43510 <JS_ValueToAtom>
   2873f:	41 89 c5             	mov    r13d,eax
   28742:	45 85 ed             	test   r13d,r13d
   28745:	0f 84 55 ab ff ff    	je     232a0 <JS_CallInternal+0x7a0>
   2874b:	48 83 ec 08          	sub    rsp,0x8
   2874f:	4c 8d 53 d0          	lea    r10,[rbx-0x30]
   28753:	48 8d 43 c0          	lea    rax,[rbx-0x40]
   28757:	4c 8b 43 f0          	mov    r8,QWORD PTR [rbx-0x10]
   2875b:	4c 89 95 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],r10
   28762:	4c 8b 4b f8          	mov    r9,QWORD PTR [rbx-0x8]
   28766:	44 89 e9             	mov    ecx,r13d
   28769:	48 8b 73 d0          	mov    rsi,QWORD PTR [rbx-0x30]
   2876d:	48 8b 53 d8          	mov    rdx,QWORD PTR [rbx-0x28]
   28771:	48 89 85 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],rax
   28778:	68 00 80 00 00       	push   0x8000
   2877d:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   28784:	ff 73 c8             	push   QWORD PTR [rbx-0x38]
   28787:	ff 73 c0             	push   QWORD PTR [rbx-0x40]
   2878a:	e8 81 53 00 00       	call   2db10 <JS_SetPropertyInternal>
   2878f:	48 83 c4 20          	add    rsp,0x20
   28793:	41 81 fd f2 00 00 00 	cmp    r13d,0xf2
   2879a:	4c 8b 95 40 fe ff ff 	mov    r10,QWORD PTR [rbp-0x1c0]
   287a1:	89 c3                	mov    ebx,eax
   287a3:	0f 8f d1 15 00 00    	jg     29d7a <JS_CallInternal+0x727a>
   287a9:	48 8b 85 50 fe ff ff 	mov    rax,QWORD PTR [rbp-0x1b0]
   287b0:	48 8b 50 08          	mov    rdx,QWORD PTR [rax+0x8]
   287b4:	48 8b 30             	mov    rsi,QWORD PTR [rax]
   287b7:	83 fa f6             	cmp    edx,0xfffffff6
   287ba:	76 11                	jbe    287cd <JS_CallInternal+0x5ccd>
   287bc:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   287bf:	83 e8 01             	sub    eax,0x1
   287c2:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   287c5:	85 c0                	test   eax,eax
   287c7:	0f 8e 49 22 00 00    	jle    2aa16 <JS_CallInternal+0x7f16>
   287cd:	49 8b 52 08          	mov    rdx,QWORD PTR [r10+0x8]
   287d1:	49 8b 32             	mov    rsi,QWORD PTR [r10]
   287d4:	83 fa f6             	cmp    edx,0xfffffff6
   287d7:	76 11                	jbe    287ea <JS_CallInternal+0x5cea>
   287d9:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   287dc:	83 e8 01             	sub    eax,0x1
   287df:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   287e2:	85 c0                	test   eax,eax
   287e4:	0f 8e dc 21 00 00    	jle    2a9c6 <JS_CallInternal+0x7ec6>
   287ea:	49 8b 56 08          	mov    rdx,QWORD PTR [r14+0x8]
   287ee:	49 8b 36             	mov    rsi,QWORD PTR [r14]
   287f1:	83 fa f6             	cmp    edx,0xfffffff6
   287f4:	76 11                	jbe    28807 <JS_CallInternal+0x5d07>
   287f6:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   287f9:	83 e8 01             	sub    eax,0x1
   287fc:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   287ff:	85 c0                	test   eax,eax
   28801:	0f 8e d4 21 00 00    	jle    2a9db <JS_CallInternal+0x7edb>
   28807:	85 db                	test   ebx,ebx
   28809:	0f 88 94 41 00 00    	js     2c9a3 <JS_CallInternal+0x9ea3>
   2880f:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   28814:	48 8b 9d 50 fe ff ff 	mov    rbx,QWORD PTR [rbp-0x1b0]
   2881b:	49 83 c4 01          	add    r12,0x1
   2881f:	49 89 c5             	mov    r13,rax
   28822:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   28826:	ff e0                	jmp    rax
   28828:	f3 0f 1e fa          	endbr64
   2882c:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   28833:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2883a:	48 89 de             	mov    rsi,rbx
   2883d:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   28841:	e8 8a 24 07 00       	call   9acd0 <js_append_enumerate>
   28846:	85 c0                	test   eax,eax
   28848:	0f 85 52 aa ff ff    	jne    232a0 <JS_CallInternal+0x7a0>
   2884e:	48 8b 53 f8          	mov    rdx,QWORD PTR [rbx-0x8]
   28852:	48 83 eb 10          	sub    rbx,0x10
   28856:	48 8b 33             	mov    rsi,QWORD PTR [rbx]
   28859:	83 fa f6             	cmp    edx,0xfffffff6
   2885c:	76 11                	jbe    2886f <JS_CallInternal+0x5d6f>
   2885e:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   28861:	83 e8 01             	sub    eax,0x1
   28864:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   28867:	85 c0                	test   eax,eax
   28869:	0f 8e d7 20 00 00    	jle    2a946 <JS_CallInternal+0x7e46>
   2886f:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   28874:	49 83 c4 01          	add    r12,0x1
   28878:	49 89 c5             	mov    r13,rax
   2887b:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   2887f:	ff e0                	jmp    rax
   28881:	f3 0f 1e fa          	endbr64
   28885:	48 8b 4b f0          	mov    rcx,QWORD PTR [rbx-0x10]
   28889:	83 7b f8 03          	cmp    DWORD PTR [rbx-0x8],0x3
   2888d:	4d 8d 6c 24 04       	lea    r13,[r12+0x4]
   28892:	48 8b 53 f8          	mov    rdx,QWORD PTR [rbx-0x8]
   28896:	48 89 c8             	mov    rax,rcx
   28899:	0f 87 36 14 00 00    	ja     29cd5 <JS_CallInternal+0x71d5>
   2889f:	48 83 eb 10          	sub    rbx,0x10
   288a3:	85 c0                	test   eax,eax
   288a5:	74 0c                	je     288b3 <JS_CallInternal+0x5db3>
   288a7:	41 8b 04 24          	mov    eax,DWORD PTR [r12]
   288ab:	83 e8 04             	sub    eax,0x4
   288ae:	48 98                	cdqe
   288b0:	49 01 c5             	add    r13,rax
   288b3:	48 8b 8d e8 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x118]
   288ba:	8b 81 a8 01 00 00    	mov    eax,DWORD PTR [rcx+0x1a8]
   288c0:	89 85 50 fe ff ff    	mov    DWORD PTR [rbp-0x1b0],eax
   288c6:	83 e8 01             	sub    eax,0x1
   288c9:	89 81 a8 01 00 00    	mov    DWORD PTR [rcx+0x1a8],eax
   288cf:	85 c0                	test   eax,eax
   288d1:	0f 8e 61 2a 00 00    	jle    2b338 <JS_CallInternal+0x8838>
   288d7:	41 0f b6 45 00       	movzx  eax,BYTE PTR [r13+0x0]
   288dc:	4d 8d 65 01          	lea    r12,[r13+0x1]
   288e0:	49 89 c5             	mov    r13,rax
   288e3:	41 ff 24 c7          	jmp    QWORD PTR [r15+rax*8]
   288e7:	f3 0f 1e fa          	endbr64
   288eb:	48 8b 8d e8 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x118]
   288f2:	4d 0f bf 2c 24       	movsx  r13,WORD PTR [r12]
   288f7:	8b 81 a8 01 00 00    	mov    eax,DWORD PTR [rcx+0x1a8]
   288fd:	4d 01 e5             	add    r13,r12
   28900:	89 85 50 fe ff ff    	mov    DWORD PTR [rbp-0x1b0],eax
   28906:	83 e8 01             	sub    eax,0x1
   28909:	89 81 a8 01 00 00    	mov    DWORD PTR [rcx+0x1a8],eax
   2890f:	85 c0                	test   eax,eax
   28911:	0f 8e 87 2f 00 00    	jle    2b89e <JS_CallInternal+0x8d9e>
   28917:	41 0f b6 45 00       	movzx  eax,BYTE PTR [r13+0x0]
   2891c:	4d 8d 65 01          	lea    r12,[r13+0x1]
   28920:	49 89 c5             	mov    r13,rax
   28923:	41 ff 24 c7          	jmp    QWORD PTR [r15+rax*8]
   28927:	f3 0f 1e fa          	endbr64
   2892b:	41 8b 0c 24          	mov    ecx,DWORD PTR [r12]
   2892f:	48 8b 73 f0          	mov    rsi,QWORD PTR [rbx-0x10]
   28933:	4d 8d 6c 24 04       	lea    r13,[r12+0x4]
   28938:	48 8b 53 f8          	mov    rdx,QWORD PTR [rbx-0x8]
   2893c:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   28943:	e8 18 bc 00 00       	call   34560 <JS_DefineObjectName.constprop.0>
   28948:	85 c0                	test   eax,eax
   2894a:	0f 88 8e 29 00 00    	js     2b2de <JS_CallInternal+0x87de>
   28950:	41 0f b6 44 24 04    	movzx  eax,BYTE PTR [r12+0x4]
   28956:	49 83 c4 05          	add    r12,0x5
   2895a:	49 89 c5             	mov    r13,rax
   2895d:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   28961:	ff e0                	jmp    rax
   28963:	f3 0f 1e fa          	endbr64
   28967:	41 0f b7 04 24       	movzx  eax,WORD PTR [r12]
   2896c:	48 8b 8d b0 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x150]
   28973:	4d 8d 6c 24 02       	lea    r13,[r12+0x2]
   28978:	48 c1 e0 04          	shl    rax,0x4
   2897c:	48 01 c8             	add    rax,rcx
   2897f:	83 78 08 04          	cmp    DWORD PTR [rax+0x8],0x4
   28983:	0f 85 09 24 00 00    	jne    2ad92 <JS_CallInternal+0x8292>
   28989:	f3 0f 6f 4b f0       	movdqu xmm1,XMMWORD PTR [rbx-0x10]
   2898e:	49 83 c4 03          	add    r12,0x3
   28992:	48 83 eb 10          	sub    rbx,0x10
   28996:	0f 11 08             	movups XMMWORD PTR [rax],xmm1
   28999:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   2899f:	49 89 c5             	mov    r13,rax
   289a2:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   289a6:	ff e0                	jmp    rax
   289a8:	f3 0f 1e fa          	endbr64
   289ac:	48 8b 7b f8          	mov    rdi,QWORD PTR [rbx-0x8]
   289b0:	41 8b 34 24          	mov    esi,DWORD PTR [r12]
   289b4:	4d 8d 6c 24 04       	lea    r13,[r12+0x4]
   289b9:	4c 8b 53 f0          	mov    r10,QWORD PTR [rbx-0x10]
   289bd:	83 ff ff             	cmp    edi,0xffffffff
   289c0:	0f 85 15 09 00 00    	jne    292db <JS_CallInternal+0x67db>
   289c6:	4c 89 d1             	mov    rcx,r10
   289c9:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]
   289d0:	48 8b 51 18          	mov    rdx,QWORD PTR [rcx+0x18]
   289d4:	8b 42 18             	mov    eax,DWORD PTR [rdx+0x18]
   289d7:	41 89 c0             	mov    r8d,eax
   289da:	41 21 f0             	and    r8d,esi
   289dd:	46 8b 44 82 38       	mov    r8d,DWORD PTR [rdx+r8*4+0x38]
   289e2:	4d 85 c0             	test   r8,r8
   289e5:	0f 84 b2 03 00 00    	je     28d9d <JS_CallInternal+0x629d>
   289eb:	4c 8d 0c 85 34 00 00 	lea    r9,[rax*4+0x34]
   289f2:	00 
   289f3:	4b 8d 04 c1          	lea    rax,[r9+r8*8]
   289f7:	48 01 d0             	add    rax,rdx
   289fa:	39 70 04             	cmp    DWORD PTR [rax+0x4],esi
   289fd:	0f 85 8a 03 00 00    	jne    28d8d <JS_CallInternal+0x628d>
   28a03:	80 78 03 3f          	cmp    BYTE PTR [rax+0x3],0x3f
   28a07:	0f 87 ce 08 00 00    	ja     292db <JS_CallInternal+0x67db>
   28a0d:	48 8b 41 20          	mov    rax,QWORD PTR [rcx+0x20]
   28a11:	49 c1 e0 04          	shl    r8,0x4
   28a15:	4a 8d 54 00 f0       	lea    rdx,[rax+r8*1-0x10]
   28a1a:	48 8b 02             	mov    rax,QWORD PTR [rdx]
   28a1d:	48 8b 52 08          	mov    rdx,QWORD PTR [rdx+0x8]
   28a21:	83 fa f6             	cmp    edx,0xfffffff6
   28a24:	76 04                	jbe    28a2a <JS_CallInternal+0x5f2a>
   28a26:	83 40 fc 01          	add    DWORD PTR [rax-0x4],0x1
   28a2a:	48 89 03             	mov    QWORD PTR [rbx],rax
   28a2d:	49 83 c4 05          	add    r12,0x5
   28a31:	48 83 c3 10          	add    rbx,0x10
   28a35:	48 89 53 f8          	mov    QWORD PTR [rbx-0x8],rdx
   28a39:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   28a3f:	49 89 c5             	mov    r13,rax
   28a42:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   28a46:	ff e0                	jmp    rax
   28a48:	f3 0f 1e fa          	endbr64
   28a4c:	41 0f b7 04 24       	movzx  eax,WORD PTR [r12]
   28a51:	48 8b 8d b0 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x150]
   28a58:	4d 8d 6c 24 02       	lea    r13,[r12+0x2]
   28a5d:	48 89 c2             	mov    rdx,rax
   28a60:	48 c1 e0 04          	shl    rax,0x4
   28a64:	48 01 c8             	add    rax,rcx
   28a67:	48 8b 48 08          	mov    rcx,QWORD PTR [rax+0x8]
   28a6b:	83 f9 04             	cmp    ecx,0x4
   28a6e:	0f 84 e2 2d 00 00    	je     2b856 <JS_CallInternal+0x8d56>
   28a74:	f3 0f 6f 5b f0       	movdqu xmm3,XMMWORD PTR [rbx-0x10]
   28a79:	48 8b 30             	mov    rsi,QWORD PTR [rax]
   28a7c:	0f 11 18             	movups XMMWORD PTR [rax],xmm3
   28a7f:	83 f9 f6             	cmp    ecx,0xfffffff6
   28a82:	76 11                	jbe    28a95 <JS_CallInternal+0x5f95>
   28a84:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   28a87:	83 e8 01             	sub    eax,0x1
   28a8a:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   28a8d:	85 c0                	test   eax,eax
   28a8f:	0f 8e bd 1c 00 00    	jle    2a752 <JS_CallInternal+0x7c52>
   28a95:	41 0f b6 44 24 02    	movzx  eax,BYTE PTR [r12+0x2]
   28a9b:	48 83 eb 10          	sub    rbx,0x10
   28a9f:	49 83 c4 03          	add    r12,0x3
   28aa3:	49 89 c5             	mov    r13,rax
   28aa6:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   28aaa:	ff e0                	jmp    rax
   28aac:	f3 0f 1e fa          	endbr64
   28ab0:	48 8b 4b e0          	mov    rcx,QWORD PTR [rbx-0x20]
   28ab4:	48 8b 73 f0          	mov    rsi,QWORD PTR [rbx-0x10]
   28ab8:	49 83 c4 01          	add    r12,0x1
   28abc:	48 8b 53 f8          	mov    rdx,QWORD PTR [rbx-0x8]
   28ac0:	4c 8b 43 e8          	mov    r8,QWORD PTR [rbx-0x18]
   28ac4:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   28acb:	e8 50 56 ff ff       	call   1e120 <js_method_set_home_object>
   28ad0:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   28ad6:	49 89 c5             	mov    r13,rax
   28ad9:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   28add:	ff e0                	jmp    rax
   28adf:	f3 0f 1e fa          	endbr64
   28ae3:	48 8b 4b e0          	mov    rcx,QWORD PTR [rbx-0x20]
   28ae7:	48 8b 73 f0          	mov    rsi,QWORD PTR [rbx-0x10]
   28aeb:	48 8b 53 f8          	mov    rdx,QWORD PTR [rbx-0x8]
   28aef:	4c 8b 43 e8          	mov    r8,QWORD PTR [rbx-0x18]
   28af3:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   28afa:	e8 91 ad 01 00       	call   43890 <JS_DefineObjectNameComputed.constprop.0>
   28aff:	85 c0                	test   eax,eax
   28b01:	0f 88 99 a7 ff ff    	js     232a0 <JS_CallInternal+0x7a0>
   28b07:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   28b0c:	49 83 c4 01          	add    r12,0x1
   28b10:	49 89 c5             	mov    r13,rax
   28b13:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   28b17:	ff e0                	jmp    rax
   28b19:	f3 0f 1e fa          	endbr64
   28b1d:	48 83 ec 08          	sub    rsp,0x8
   28b21:	41 8b 0c 24          	mov    ecx,DWORD PTR [r12]
   28b25:	48 8b 73 e0          	mov    rsi,QWORD PTR [rbx-0x20]
   28b29:	4c 8d 73 f0          	lea    r14,[rbx-0x10]
   28b2d:	4c 8b 43 f0          	mov    r8,QWORD PTR [rbx-0x10]
   28b31:	4c 8b 4b f8          	mov    r9,QWORD PTR [rbx-0x8]
   28b35:	4d 8d 6c 24 04       	lea    r13,[r12+0x4]
   28b3a:	48 8b 53 e8          	mov    rdx,QWORD PTR [rbx-0x18]
   28b3e:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   28b45:	68 07 40 00 00       	push   0x4007
   28b4a:	e8 81 72 00 00       	call   2fdd0 <JS_DefinePropertyValue>
   28b4f:	59                   	pop    rcx
   28b50:	5e                   	pop    rsi
   28b51:	85 c0                	test   eax,eax
   28b53:	0f 88 05 2e 00 00    	js     2b95e <JS_CallInternal+0x8e5e>
   28b59:	41 0f b6 44 24 04    	movzx  eax,BYTE PTR [r12+0x4]
   28b5f:	4c 89 f3             	mov    rbx,r14
   28b62:	49 83 c4 05          	add    r12,0x5
   28b66:	49 89 c5             	mov    r13,rax
   28b69:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   28b6d:	ff e0                	jmp    rax
   28b6f:	f3 0f 1e fa          	endbr64
   28b73:	41 8b 34 24          	mov    esi,DWORD PTR [r12]
   28b77:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   28b7e:	4d 8d 6c 24 04       	lea    r13,[r12+0x4]
   28b83:	e8 b8 af 00 00       	call   33b40 <JS_NewSymbolFromAtom.constprop.0>
   28b88:	83 fa 06             	cmp    edx,0x6
   28b8b:	0f 84 d7 28 00 00    	je     2b468 <JS_CallInternal+0x8968>
   28b91:	48 89 03             	mov    QWORD PTR [rbx],rax
   28b94:	49 83 c4 05          	add    r12,0x5
   28b98:	48 83 c3 10          	add    rbx,0x10
   28b9c:	48 89 53 f8          	mov    QWORD PTR [rbx-0x8],rdx
   28ba0:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   28ba6:	49 89 c5             	mov    r13,rax
   28ba9:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   28bad:	ff e0                	jmp    rax
   28baf:	f3 0f 1e fa          	endbr64
   28bb3:	48 8b 7b f8          	mov    rdi,QWORD PTR [rbx-0x8]
   28bb7:	48 8b 73 f0          	mov    rsi,QWORD PTR [rbx-0x10]
   28bbb:	83 ff ff             	cmp    edi,0xffffffff
   28bbe:	0f 85 57 06 00 00    	jne    2921b <JS_CallInternal+0x671b>
   28bc4:	48 89 f1             	mov    rcx,rsi
   28bc7:	66 0f 1f 84 00 00 00 	nop    WORD PTR [rax+rax*1+0x0]
   28bce:	00 00 
   28bd0:	48 8b 51 18          	mov    rdx,QWORD PTR [rcx+0x18]
   28bd4:	8b 42 18             	mov    eax,DWORD PTR [rdx+0x18]
   28bd7:	41 89 c0             	mov    r8d,eax
   28bda:	41 83 e0 32          	and    r8d,0x32
   28bde:	46 8b 44 82 38       	mov    r8d,DWORD PTR [rdx+r8*4+0x38]
   28be3:	4d 85 c0             	test   r8,r8
   28be6:	0f 84 79 01 00 00    	je     28d65 <JS_CallInternal+0x6265>
   28bec:	4c 8d 0c 85 34 00 00 	lea    r9,[rax*4+0x34]
   28bf3:	00 
   28bf4:	4b 8d 04 c1          	lea    rax,[r9+r8*8]
   28bf8:	48 01 d0             	add    rax,rdx
   28bfb:	83 78 04 32          	cmp    DWORD PTR [rax+0x4],0x32
   28bff:	0f 85 50 01 00 00    	jne    28d55 <JS_CallInternal+0x6255>
   28c05:	80 78 03 3f          	cmp    BYTE PTR [rax+0x3],0x3f
   28c09:	0f 87 0c 06 00 00    	ja     2921b <JS_CallInternal+0x671b>
   28c0f:	48 8b 41 20          	mov    rax,QWORD PTR [rcx+0x20]
   28c13:	49 c1 e0 04          	shl    r8,0x4
   28c17:	4a 8d 44 00 f0       	lea    rax,[rax+r8*1-0x10]
   28c1c:	48 8b 48 08          	mov    rcx,QWORD PTR [rax+0x8]
   28c20:	4c 8b 30             	mov    r14,QWORD PTR [rax]
   28c23:	83 f9 f6             	cmp    ecx,0xfffffff6
   28c26:	76 05                	jbe    28c2d <JS_CallInternal+0x612d>
   28c28:	41 83 46 fc 01       	add    DWORD PTR [r14-0x4],0x1
   28c2d:	4c 8d 6b f0          	lea    r13,[rbx-0x10]
   28c31:	49 8b 55 08          	mov    rdx,QWORD PTR [r13+0x8]
   28c35:	49 8b 75 00          	mov    rsi,QWORD PTR [r13+0x0]
   28c39:	83 fa f6             	cmp    edx,0xfffffff6
   28c3c:	76 11                	jbe    28c4f <JS_CallInternal+0x614f>
   28c3e:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   28c41:	83 e8 01             	sub    eax,0x1
   28c44:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   28c47:	85 c0                	test   eax,eax
   28c49:	0f 8e 1b 1b 00 00    	jle    2a76a <JS_CallInternal+0x7c6a>
   28c4f:	4c 89 73 f0          	mov    QWORD PTR [rbx-0x10],r14
   28c53:	49 83 c4 01          	add    r12,0x1
   28c57:	48 89 4b f8          	mov    QWORD PTR [rbx-0x8],rcx
   28c5b:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   28c61:	49 89 c5             	mov    r13,rax
   28c64:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   28c68:	ff e0                	jmp    rax
   28c6a:	f3 0f 1e fa          	endbr64
   28c6e:	48 8b 7b f8          	mov    rdi,QWORD PTR [rbx-0x8]
   28c72:	41 8b 34 24          	mov    esi,DWORD PTR [r12]
   28c76:	4d 8d 74 24 04       	lea    r14,[r12+0x4]
   28c7b:	4c 8b 53 f0          	mov    r10,QWORD PTR [rbx-0x10]
   28c7f:	83 ff ff             	cmp    edi,0xffffffff
   28c82:	0f 85 9f 06 00 00    	jne    29327 <JS_CallInternal+0x6827>
   28c88:	4c 89 d1             	mov    rcx,r10
   28c8b:	0f 1f 44 00 00       	nop    DWORD PTR [rax+rax*1+0x0]
   28c90:	48 8b 51 18          	mov    rdx,QWORD PTR [rcx+0x18]
   28c94:	8b 42 18             	mov    eax,DWORD PTR [rdx+0x18]
   28c97:	41 89 c0             	mov    r8d,eax
   28c9a:	41 21 f0             	and    r8d,esi
   28c9d:	46 8b 44 82 38       	mov    r8d,DWORD PTR [rdx+r8*4+0x38]
   28ca2:	4d 85 c0             	test   r8,r8
   28ca5:	0f 84 85 00 00 00    	je     28d30 <JS_CallInternal+0x6230>
   28cab:	4c 8d 0c 85 34 00 00 	lea    r9,[rax*4+0x34]
   28cb2:	00 
   28cb3:	4b 8d 04 c1          	lea    rax,[r9+r8*8]
   28cb7:	48 01 d0             	add    rax,rdx
   28cba:	39 70 04             	cmp    DWORD PTR [rax+0x4],esi
   28cbd:	75 65                	jne    28d24 <JS_CallInternal+0x6224>
   28cbf:	80 78 03 3f          	cmp    BYTE PTR [rax+0x3],0x3f
   28cc3:	0f 87 5e 06 00 00    	ja     29327 <JS_CallInternal+0x6827>
   28cc9:	48 8b 41 20          	mov    rax,QWORD PTR [rcx+0x20]
   28ccd:	49 c1 e0 04          	shl    r8,0x4
   28cd1:	4a 8d 54 00 f0       	lea    rdx,[rax+r8*1-0x10]
   28cd6:	4c 8b 42 08          	mov    r8,QWORD PTR [rdx+0x8]
   28cda:	48 8b 02             	mov    rax,QWORD PTR [rdx]
   28cdd:	41 83 f8 f6          	cmp    r8d,0xfffffff6
   28ce1:	76 04                	jbe    28ce7 <JS_CallInternal+0x61e7>
   28ce3:	83 40 fc 01          	add    DWORD PTR [rax-0x4],0x1
   28ce7:	4c 8d 6b f0          	lea    r13,[rbx-0x10]
   28ceb:	49 8b 55 08          	mov    rdx,QWORD PTR [r13+0x8]
   28cef:	49 8b 75 00          	mov    rsi,QWORD PTR [r13+0x0]
   28cf3:	83 fa f6             	cmp    edx,0xfffffff6
   28cf6:	76 11                	jbe    28d09 <JS_CallInternal+0x6209>
   28cf8:	8b 4e fc             	mov    ecx,DWORD PTR [rsi-0x4]
   28cfb:	83 e9 01             	sub    ecx,0x1
   28cfe:	89 4e fc             	mov    DWORD PTR [rsi-0x4],ecx
   28d01:	85 c9                	test   ecx,ecx
   28d03:	0f 8e c7 17 00 00    	jle    2a4d0 <JS_CallInternal+0x79d0>
   28d09:	48 89 43 f0          	mov    QWORD PTR [rbx-0x10],rax
   28d0d:	49 83 c4 05          	add    r12,0x5
   28d11:	4c 89 43 f8          	mov    QWORD PTR [rbx-0x8],r8
   28d15:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   28d1b:	49 89 c5             	mov    r13,rax
   28d1e:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   28d22:	ff e0                	jmp    rax
   28d24:	44 8b 00             	mov    r8d,DWORD PTR [rax]
   28d27:	41 81 e0 ff ff ff 03 	and    r8d,0x3ffffff
   28d2e:	75 83                	jne    28cb3 <JS_CallInternal+0x61b3>
   28d30:	f6 41 10 08          	test   BYTE PTR [rcx+0x10],0x8
   28d34:	0f 85 e3 05 00 00    	jne    2931d <JS_CallInternal+0x681d>
   28d3a:	48 8b 4a 30          	mov    rcx,QWORD PTR [rdx+0x30]
   28d3e:	48 85 c9             	test   rcx,rcx
   28d41:	0f 85 49 ff ff ff    	jne    28c90 <JS_CallInternal+0x6190>
   28d47:	4c 8d 6b f0          	lea    r13,[rbx-0x10]
   28d4b:	41 b8 03 00 00 00    	mov    r8d,0x3
   28d51:	31 c0                	xor    eax,eax
   28d53:	eb 96                	jmp    28ceb <JS_CallInternal+0x61eb>
   28d55:	44 8b 00             	mov    r8d,DWORD PTR [rax]
   28d58:	41 81 e0 ff ff ff 03 	and    r8d,0x3ffffff
   28d5f:	0f 85 8f fe ff ff    	jne    28bf4 <JS_CallInternal+0x60f4>
   28d65:	f6 41 10 08          	test   BYTE PTR [rcx+0x10],0x8
   28d69:	0f 85 a2 04 00 00    	jne    29211 <JS_CallInternal+0x6711>
   28d6f:	48 8b 4a 30          	mov    rcx,QWORD PTR [rdx+0x30]
   28d73:	48 85 c9             	test   rcx,rcx
   28d76:	0f 85 54 fe ff ff    	jne    28bd0 <JS_CallInternal+0x60d0>
   28d7c:	4c 8d 6b f0          	lea    r13,[rbx-0x10]
   28d80:	b9 03 00 00 00       	mov    ecx,0x3
   28d85:	45 31 f6             	xor    r14d,r14d
   28d88:	e9 a4 fe ff ff       	jmp    28c31 <JS_CallInternal+0x6131>
   28d8d:	44 8b 00             	mov    r8d,DWORD PTR [rax]
   28d90:	41 81 e0 ff ff ff 03 	and    r8d,0x3ffffff
   28d97:	0f 85 56 fc ff ff    	jne    289f3 <JS_CallInternal+0x5ef3>
   28d9d:	f6 41 10 08          	test   BYTE PTR [rcx+0x10],0x8
   28da1:	0f 85 2a 05 00 00    	jne    292d1 <JS_CallInternal+0x67d1>
   28da7:	48 8b 4a 30          	mov    rcx,QWORD PTR [rdx+0x30]
   28dab:	48 85 c9             	test   rcx,rcx
   28dae:	0f 85 1c fc ff ff    	jne    289d0 <JS_CallInternal+0x5ed0>
   28db4:	ba 03 00 00 00       	mov    edx,0x3
   28db9:	31 c0                	xor    eax,eax
   28dbb:	e9 6a fc ff ff       	jmp    28a2a <JS_CallInternal+0x5f2a>
   28dc0:	8b 38                	mov    edi,DWORD PTR [rax]
   28dc2:	81 e7 ff ff ff 03    	and    edi,0x3ffffff
   28dc8:	0f 85 d0 b2 ff ff    	jne    2409e <JS_CallInternal+0x159e>
   28dce:	f6 42 10 08          	test   BYTE PTR [rdx+0x10],0x8
   28dd2:	0f 85 98 05 00 00    	jne    29370 <JS_CallInternal+0x6870>
   28dd8:	49 8b 55 30          	mov    rdx,QWORD PTR [r13+0x30]
   28ddc:	48 85 d2             	test   rdx,rdx
   28ddf:	0f 84 3d 16 00 00    	je     2a422 <JS_CallInternal+0x7922>
   28de5:	4c 8b 6a 18          	mov    r13,QWORD PTR [rdx+0x18]
   28de9:	e9 92 b2 ff ff       	jmp    24080 <JS_CallInternal+0x1580>
   28dee:	8b 10                	mov    edx,DWORD PTR [rax]
   28df0:	81 e2 ff ff ff 03    	and    edx,0x3ffffff
   28df6:	0f 85 d2 b1 ff ff    	jne    23fce <JS_CallInternal+0x14ce>
   28dfc:	f6 47 10 08          	test   BYTE PTR [rdi+0x10],0x8
   28e00:	0f 85 d3 05 00 00    	jne    293d9 <JS_CallInternal+0x68d9>
   28e06:	49 8b 7d 30          	mov    rdi,QWORD PTR [r13+0x30]
   28e0a:	48 85 ff             	test   rdi,rdi
   28e0d:	0f 84 c2 15 00 00    	je     2a3d5 <JS_CallInternal+0x78d5>
   28e13:	4c 8b 6f 18          	mov    r13,QWORD PTR [rdi+0x18]
   28e17:	e9 94 b1 ff ff       	jmp    23fb0 <JS_CallInternal+0x14b0>
   28e1c:	8b b5 bc fe ff ff    	mov    esi,DWORD PTR [rbp-0x144]
   28e22:	39 f7                	cmp    edi,esi
   28e24:	41 89 f5             	mov    r13d,esi
   28e27:	44 0f 4e ef          	cmovle r13d,edi
   28e2b:	45 85 ed             	test   r13d,r13d
   28e2e:	0f 8e 2c 14 00 00    	jle    2a260 <JS_CallInternal+0x7760>
   28e34:	4c 8b bd a8 fe ff ff 	mov    r15,QWORD PTR [rbp-0x158]
   28e3b:	4d 63 f5             	movsxd r14,r13d
   28e3e:	4d 8d 43 08          	lea    r8,[r11+0x8]
   28e42:	49 c1 e6 04          	shl    r14,0x4
   28e46:	4c 89 fe             	mov    rsi,r15
   28e49:	4d 01 fe             	add    r14,r15
   28e4c:	0f 1f 40 00          	nop    DWORD PTR [rax+0x0]
   28e50:	4c 8b 66 08          	mov    r12,QWORD PTR [rsi+0x8]
   28e54:	4c 8b 3e             	mov    r15,QWORD PTR [rsi]
   28e57:	41 83 fc f6          	cmp    r12d,0xfffffff6
   28e5b:	76 05                	jbe    28e62 <JS_CallInternal+0x6362>
   28e5d:	41 83 47 fc 01       	add    DWORD PTR [r15-0x4],0x1
   28e62:	48 83 c6 10          	add    rsi,0x10
   28e66:	4d 89 78 f8          	mov    QWORD PTR [r8-0x8],r15
   28e6a:	49 83 c0 10          	add    r8,0x10
   28e6e:	4d 89 60 f0          	mov    QWORD PTR [r8-0x10],r12
   28e72:	4c 39 f6             	cmp    rsi,r14
   28e75:	75 d9                	jne    28e50 <JS_CallInternal+0x6350>
   28e77:	44 39 ef             	cmp    edi,r13d
   28e7a:	7e 3c                	jle    28eb8 <JS_CallInternal+0x63b8>
   28e7c:	44 8d 47 ff          	lea    r8d,[rdi-0x1]
   28e80:	4d 63 e5             	movsxd r12,r13d
   28e83:	45 29 e8             	sub    r8d,r13d
   28e86:	4c 89 e6             	mov    rsi,r12
   28e89:	4d 01 e0             	add    r8,r12
   28e8c:	48 c1 e6 04          	shl    rsi,0x4
   28e90:	49 c1 e0 04          	shl    r8,0x4
   28e94:	4c 01 de             	add    rsi,r11
   28e97:	4f 8d 44 03 10       	lea    r8,[r11+r8*1+0x10]
   28e9c:	0f 1f 40 00          	nop    DWORD PTR [rax+0x0]
   28ea0:	48 c7 06 00 00 00 00 	mov    QWORD PTR [rsi],0x0
   28ea7:	48 83 c6 10          	add    rsi,0x10
   28eab:	48 c7 46 f8 03 00 00 	mov    QWORD PTR [rsi-0x8],0x3
   28eb2:	00 
   28eb3:	4c 39 c6             	cmp    rsi,r8
   28eb6:	75 e8                	jne    28ea0 <JS_CallInternal+0x63a0>
   28eb8:	89 bd 38 ff ff ff    	mov    DWORD PTR [rbp-0xc8],edi
   28ebe:	4c 89 9d 90 fe ff ff 	mov    QWORD PTR [rbp-0x170],r11
   28ec5:	e9 14 9e ff ff       	jmp    22cde <JS_CallInternal+0x1de>
   28eca:	48 83 ec 08          	sub    rsp,0x8
   28ece:	8b 8d 38 fe ff ff    	mov    ecx,DWORD PTR [rbp-0x1c8]
   28ed4:	49 89 d1             	mov    r9,rdx
   28ed7:	48 89 c6             	mov    rsi,rax
   28eda:	6a 00                	push   0x0
   28edc:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   28ee3:	48 89 85 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],rax
   28eea:	e8 f1 3e 00 00       	call   2cde0 <JS_GetPropertyInternal>
   28eef:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   28ef6:	48 89 c6             	mov    rsi,rax
   28ef9:	e8 d2 5b ff ff       	call   1ead0 <JS_ToBoolFree>
   28efe:	4c 8b 85 40 fe ff ff 	mov    r8,QWORD PTR [rbp-0x1c0]
   28f05:	89 c1                	mov    ecx,eax
   28f07:	41 8b 40 fc          	mov    eax,DWORD PTR [r8-0x4]
   28f0b:	83 e8 01             	sub    eax,0x1
   28f0e:	41 89 40 fc          	mov    DWORD PTR [r8-0x4],eax
   28f12:	41 5b                	pop    r11
   28f14:	5a                   	pop    rdx
   28f15:	85 c0                	test   eax,eax
   28f17:	0f 8e fa 36 00 00    	jle    2c617 <JS_CallInternal+0x9b17>
   28f1d:	85 c9                	test   ecx,ecx
   28f1f:	0f 88 e1 a6 ff ff    	js     23606 <JS_CallInternal+0xb06>
   28f25:	0f 84 78 9f ff ff    	je     22ea3 <JS_CallInternal+0x3a3>
   28f2b:	48 8b 53 f8          	mov    rdx,QWORD PTR [rbx-0x8]
   28f2f:	48 83 eb 10          	sub    rbx,0x10
   28f33:	48 8b 33             	mov    rsi,QWORD PTR [rbx]
   28f36:	83 fa f6             	cmp    edx,0xfffffff6
   28f39:	0f 86 a0 a4 ff ff    	jbe    233df <JS_CallInternal+0x8df>
   28f3f:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   28f42:	83 e8 01             	sub    eax,0x1
   28f45:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   28f48:	85 c0                	test   eax,eax
   28f4a:	0f 8f 8f a4 ff ff    	jg     233df <JS_CallInternal+0x8df>
   28f50:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   28f57:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   28f5b:	e8 40 39 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   28f60:	e9 7a a4 ff ff       	jmp    233df <JS_CallInternal+0x8df>
   28f65:	8b 85 38 fe ff ff    	mov    eax,DWORD PTR [rbp-0x1c8]
   28f6b:	48 8b 9d 50 fe ff ff 	mov    rbx,QWORD PTR [rbp-0x1b0]
   28f72:	4c 8b a5 40 fe ff ff 	mov    r12,QWORD PTR [rbp-0x1c0]
   28f79:	83 c0 02             	add    eax,0x2
   28f7c:	48 98                	cdqe
   28f7e:	49 83 c4 03          	add    r12,0x3
   28f82:	48 c1 e0 04          	shl    rax,0x4
   28f86:	48 29 c3             	sub    rbx,rax
   28f89:	48 89 da             	mov    rdx,rbx
   28f8c:	48 8d 5b 10          	lea    rbx,[rbx+0x10]
   28f90:	4c 89 2a             	mov    QWORD PTR [rdx],r13
   28f93:	4c 89 72 08          	mov    QWORD PTR [rdx+0x8],r14
   28f97:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   28f9d:	49 89 c5             	mov    r13,rax
   28fa0:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   28fa4:	ff e0                	jmp    rax
   28fa6:	4c 89 f0             	mov    rax,r14
   28fa9:	4c 8b a5 50 fe ff ff 	mov    r12,QWORD PTR [rbp-0x1b0]
   28fb0:	49 89 de             	mov    r14,rbx
   28fb3:	48 89 c3             	mov    rbx,rax
   28fb6:	48 8b 85 68 fe ff ff 	mov    rax,QWORD PTR [rbp-0x198]
   28fbd:	49 39 c6             	cmp    r14,rax
   28fc0:	0f 84 51 26 00 00    	je     2b617 <JS_CallInternal+0x8b17>
   28fc6:	4d 89 6e f0          	mov    QWORD PTR [r14-0x10],r13
   28fca:	49 83 c4 01          	add    r12,0x1
   28fce:	49 89 5e f8          	mov    QWORD PTR [r14-0x8],rbx
   28fd2:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   28fd8:	4c 89 f3             	mov    rbx,r14
   28fdb:	49 89 c5             	mov    r13,rax
   28fde:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   28fe2:	ff e0                	jmp    rax
   28fe4:	80 fa 01             	cmp    dl,0x1
   28fe7:	0f 84 7b 02 00 00    	je     29268 <JS_CallInternal+0x6768>
   28fed:	80 cc 10             	or     ah,0x10
   28ff0:	f3 0f 6f 53 f0       	movdqu xmm2,XMMWORD PTR [rbx-0x10]
   28ff5:	8b b5 50 fe ff ff    	mov    esi,DWORD PTR [rbp-0x1b0]
   28ffb:	89 85 24 fe ff ff    	mov    DWORD PTR [rbp-0x1dc],eax
   29001:	49 8b 04 24          	mov    rax,QWORD PTR [r12]
   29005:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2900c:	0f 29 95 e0 fd ff ff 	movaps XMMWORD PTR [rbp-0x220],xmm2
   29013:	48 89 85 d8 fd ff ff 	mov    QWORD PTR [rbp-0x228],rax
   2901a:	49 8b 44 24 08       	mov    rax,QWORD PTR [r12+0x8]
   2901f:	48 89 85 d0 fd ff ff 	mov    QWORD PTR [rbp-0x230],rax
   29026:	e8 75 71 01 00       	call   401a0 <js_get_function_name>
   2902b:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   29032:	4c 8d 05 0b 41 0a 00 	lea    r8,[rip+0xa410b]        # cd144 <_IO_stdin_used+0x144>
   29039:	48 8d 35 32 45 0a 00 	lea    rsi,[rip+0xa4532]        # cd572 <_IO_stdin_used+0x572>
   29040:	49 89 d1             	mov    r9,rdx
   29043:	48 89 c2             	mov    rdx,rax
   29046:	4c 89 c9             	mov    rcx,r9
   29049:	e8 e2 6f 01 00       	call   40030 <JS_ConcatString3>
   2904e:	49 89 d1             	mov    r9,rdx
   29051:	e9 a6 a8 ff ff       	jmp    238fc <JS_CallInternal+0xdfc>
   29056:	8b 85 40 fe ff ff    	mov    eax,DWORD PTR [rbp-0x1c0]
   2905c:	49 83 c4 03          	add    r12,0x3
   29060:	83 c0 02             	add    eax,0x2
   29063:	48 98                	cdqe
   29065:	48 c1 e0 04          	shl    rax,0x4
   29069:	48 29 c3             	sub    rbx,rax
   2906c:	48 89 da             	mov    rdx,rbx
   2906f:	48 8d 5b 10          	lea    rbx,[rbx+0x10]
   29073:	4c 89 0a             	mov    QWORD PTR [rdx],r9
   29076:	4c 89 42 08          	mov    QWORD PTR [rdx+0x8],r8
   2907a:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   29080:	49 89 c5             	mov    r13,rax
   29083:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   29087:	ff e0                	jmp    rax
   29089:	8b 85 50 fe ff ff    	mov    eax,DWORD PTR [rbp-0x1b0]
   2908f:	49 83 c4 05          	add    r12,0x5
   29093:	83 c0 01             	add    eax,0x1
   29096:	48 98                	cdqe
   29098:	48 c1 e0 04          	shl    rax,0x4
   2909c:	48 29 c3             	sub    rbx,rax
   2909f:	48 89 da             	mov    rdx,rbx
   290a2:	48 8d 5b 10          	lea    rbx,[rbx+0x10]
   290a6:	4c 89 0a             	mov    QWORD PTR [rdx],r9
   290a9:	4c 89 42 08          	mov    QWORD PTR [rdx+0x8],r8
   290ad:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   290b3:	49 89 c5             	mov    r13,rax
   290b6:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   290ba:	ff e0                	jmp    rax
   290bc:	48 8b 9d 38 fe ff ff 	mov    rbx,QWORD PTR [rbp-0x1c8]
   290c3:	4c 8b a5 28 fe ff ff 	mov    r12,QWORD PTR [rbp-0x1d8]
   290ca:	4c 89 f6             	mov    rsi,r14
   290cd:	e8 ce b9 fe ff       	call   14aa0 <__js_free>
   290d2:	41 83 fd 06          	cmp    r13d,0x6
   290d6:	0f 84 5d 19 00 00    	je     2aa39 <JS_CallInternal+0x7f39>
   290dc:	48 8b 53 e8          	mov    rdx,QWORD PTR [rbx-0x18]
   290e0:	48 8b 73 e0          	mov    rsi,QWORD PTR [rbx-0x20]
   290e4:	83 fa f6             	cmp    edx,0xfffffff6
   290e7:	76 11                	jbe    290fa <JS_CallInternal+0x65fa>
   290e9:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   290ec:	83 e8 01             	sub    eax,0x1
   290ef:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   290f2:	85 c0                	test   eax,eax
   290f4:	0f 8e 4b 19 00 00    	jle    2aa45 <JS_CallInternal+0x7f45>
   290fa:	48 8b 85 50 fe ff ff 	mov    rax,QWORD PTR [rbp-0x1b0]
   29101:	48 8b 50 08          	mov    rdx,QWORD PTR [rax+0x8]
   29105:	48 8b 30             	mov    rsi,QWORD PTR [rax]
   29108:	83 fa f6             	cmp    edx,0xfffffff6
   2910b:	76 11                	jbe    2911e <JS_CallInternal+0x661e>
   2910d:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   29110:	83 e8 01             	sub    eax,0x1
   29113:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   29116:	85 c0                	test   eax,eax
   29118:	0f 8e 50 13 00 00    	jle    2a46e <JS_CallInternal+0x796e>
   2911e:	48 8b 85 40 fe ff ff 	mov    rax,QWORD PTR [rbp-0x1c0]
   29125:	4c 89 6b e8          	mov    QWORD PTR [rbx-0x18],r13
   29129:	49 83 c4 03          	add    r12,0x3
   2912d:	48 89 43 e0          	mov    QWORD PTR [rbx-0x20],rax
   29131:	41 0f b6 44 24 ff    	movzx  eax,BYTE PTR [r12-0x1]
   29137:	48 8b 9d 50 fe ff ff 	mov    rbx,QWORD PTR [rbp-0x1b0]
   2913e:	49 89 c5             	mov    r13,rax
   29141:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   29145:	ff e0                	jmp    rax
   29147:	8b 10                	mov    edx,DWORD PTR [rax]
   29149:	81 e2 ff ff ff 03    	and    edx,0x3ffffff
   2914f:	0f 85 bb d8 ff ff    	jne    26a10 <JS_CallInternal+0x3f10>
   29155:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2915c:	89 f2                	mov    edx,esi
   2915e:	b9 07 00 00 00       	mov    ecx,0x7
   29163:	4c 89 c6             	mov    rsi,r8
   29166:	e8 15 cf 01 00       	call   46080 <add_property>
   2916b:	48 85 c0             	test   rax,rax
   2916e:	0f 84 c8 d8 ff ff    	je     26a3c <JS_CallInternal+0x3f3c>
   29174:	48 8b 8d 50 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x1b0]
   2917b:	4c 89 28             	mov    QWORD PTR [rax],r13
   2917e:	48 89 48 08          	mov    QWORD PTR [rax+0x8],rcx
   29182:	49 8b 56 08          	mov    rdx,QWORD PTR [r14+0x8]
   29186:	49 8b 36             	mov    rsi,QWORD PTR [r14]
   29189:	83 fa f6             	cmp    edx,0xfffffff6
   2918c:	76 11                	jbe    2919f <JS_CallInternal+0x669f>
   2918e:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   29191:	83 e8 01             	sub    eax,0x1
   29194:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   29197:	85 c0                	test   eax,eax
   29199:	0f 8e f8 23 00 00    	jle    2b597 <JS_CallInternal+0x8a97>
   2919f:	41 0f b6 04 24       	movzx  eax,BYTE PTR [r12]
   291a4:	4c 89 f3             	mov    rbx,r14
   291a7:	49 83 c4 01          	add    r12,0x1
   291ab:	49 89 c5             	mov    r13,rax
   291ae:	49 8b 04 c7          	mov    rax,QWORD PTR [r15+rax*8]
   291b2:	ff e0                	jmp    rax
   291b4:	ba 08 00 00 00       	mov    edx,0x8
   291b9:	e9 51 e1 ff ff       	jmp    2730f <JS_CallInternal+0x480f>
   291be:	81 bd 50 fe ff ff f2 	cmp    DWORD PTR [rbp-0x1b0],0xf2
   291c5:	00 00 00 
   291c8:	0f 8f 33 10 00 00    	jg     2a201 <JS_CallInternal+0x7701>
   291ce:	48 8b 53 e8          	mov    rdx,QWORD PTR [rbx-0x18]
   291d2:	48 8b 73 e0          	mov    rsi,QWORD PTR [rbx-0x20]
   291d6:	83 fa f6             	cmp    edx,0xfffffff6
   291d9:	0f 86 23 a8 ff ff    	jbe    23a02 <JS_CallInternal+0xf02>
   291df:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   291e2:	83 e8 01             	sub    eax,0x1
   291e5:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   291e8:	85 c0                	test   eax,eax
   291ea:	0f 8f 12 a8 ff ff    	jg     23a02 <JS_CallInternal+0xf02>
   291f0:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   291f7:	89 8d 50 fe ff ff    	mov    DWORD PTR [rbp-0x1b0],ecx
   291fd:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   29201:	e8 9a 36 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   29206:	8b 8d 50 fe ff ff    	mov    ecx,DWORD PTR [rbp-0x1b0]
   2920c:	e9 f1 a7 ff ff       	jmp    23a02 <JS_CallInternal+0xf02>
   29211:	48 89 ce             	mov    rsi,rcx
   29214:	48 c7 c7 ff ff ff ff 	mov    rdi,0xffffffffffffffff
   2921b:	48 83 ec 08          	sub    rsp,0x8
   2921f:	4c 8b 43 f0          	mov    r8,QWORD PTR [rbx-0x10]
   29223:	4c 8b 4b f8          	mov    r9,QWORD PTR [rbx-0x8]
   29227:	48 89 fa             	mov    rdx,rdi
   2922a:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   29231:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   29238:	b9 32 00 00 00       	mov    ecx,0x32
   2923d:	4c 8d 6b f0          	lea    r13,[rbx-0x10]
   29241:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   29245:	6a 00                	push   0x0
   29247:	e8 94 3b 00 00       	call   2cde0 <JS_GetPropertyInternal>
   2924c:	5f                   	pop    rdi
   2924d:	41 58                	pop    r8
   2924f:	49 89 c6             	mov    r14,rax
   29252:	48 89 d1             	mov    rcx,rdx
   29255:	83 fa 06             	cmp    edx,0x6
   29258:	0f 85 d3 f9 ff ff    	jne    28c31 <JS_CallInternal+0x6131>
   2925e:	e9 3d a0 ff ff       	jmp    232a0 <JS_CallInternal+0x7a0>
   29263:	0f 1f 44 00 00       	nop    DWORD PTR [rax+rax*1+0x0]
   29268:	80 cc 08             	or     ah,0x8
   2926b:	f3 0f 6f 7b f0       	movdqu xmm7,XMMWORD PTR [rbx-0x10]
   29270:	8b b5 50 fe ff ff    	mov    esi,DWORD PTR [rbp-0x1b0]
   29276:	89 85 24 fe ff ff    	mov    DWORD PTR [rbp-0x1dc],eax
   2927c:	49 8b 04 24          	mov    rax,QWORD PTR [r12]
   29280:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   29287:	0f 29 bd 10 fe ff ff 	movaps XMMWORD PTR [rbp-0x1f0],xmm7
   2928e:	48 89 85 d8 fd ff ff 	mov    QWORD PTR [rbp-0x228],rax
   29295:	49 8b 44 24 08       	mov    rax,QWORD PTR [r12+0x8]
   2929a:	48 89 85 d0 fd ff ff 	mov    QWORD PTR [rbp-0x230],rax
   292a1:	e8 fa 6e 01 00       	call   401a0 <js_get_function_name>
   292a6:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   292ad:	4c 8d 05 90 3e 0a 00 	lea    r8,[rip+0xa3e90]        # cd144 <_IO_stdin_used+0x144>
   292b4:	48 8d 35 b2 42 0a 00 	lea    rsi,[rip+0xa42b2]        # cd56d <_IO_stdin_used+0x56d>
   292bb:	49 89 d1             	mov    r9,rdx
   292be:	48 89 c2             	mov    rdx,rax
   292c1:	4c 89 c9             	mov    rcx,r9
   292c4:	e8 67 6d 01 00       	call   40030 <JS_ConcatString3>
   292c9:	49 89 d1             	mov    r9,rdx
   292cc:	e9 2b a6 ff ff       	jmp    238fc <JS_CallInternal+0xdfc>
   292d1:	49 89 ca             	mov    r10,rcx
   292d4:	48 c7 c7 ff ff ff ff 	mov    rdi,0xffffffffffffffff
   292db:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   292e2:	48 83 ec 08          	sub    rsp,0x8
   292e6:	48 89 fa             	mov    rdx,rdi
   292e9:	89 f1                	mov    ecx,esi
   292eb:	4c 8b 4b f8          	mov    r9,QWORD PTR [rbx-0x8]
   292ef:	4c 8b 43 f0          	mov    r8,QWORD PTR [rbx-0x10]
   292f3:	4c 89 d6             	mov    rsi,r10
   292f6:	4c 89 68 30          	mov    QWORD PTR [rax+0x30],r13
   292fa:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   29301:	6a 00                	push   0x0
   29303:	e8 d8 3a 00 00       	call   2cde0 <JS_GetPropertyInternal>
   29308:	41 59                	pop    r9
   2930a:	41 5a                	pop    r10
   2930c:	83 fa 06             	cmp    edx,0x6
   2930f:	0f 85 15 f7 ff ff    	jne    28a2a <JS_CallInternal+0x5f2a>
   29315:	4d 89 ec             	mov    r12,r13
   29318:	e9 83 9f ff ff       	jmp    232a0 <JS_CallInternal+0x7a0>
   2931d:	49 89 ca             	mov    r10,rcx
   29320:	48 c7 c7 ff ff ff ff 	mov    rdi,0xffffffffffffffff
   29327:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   2932e:	48 83 ec 08          	sub    rsp,0x8
   29332:	48 89 fa             	mov    rdx,rdi
   29335:	89 f1                	mov    ecx,esi
   29337:	4c 8b 43 f0          	mov    r8,QWORD PTR [rbx-0x10]
   2933b:	4c 8b 4b f8          	mov    r9,QWORD PTR [rbx-0x8]
   2933f:	4c 89 d6             	mov    rsi,r10
   29342:	4c 8d 6b f0          	lea    r13,[rbx-0x10]
   29346:	4c 89 70 30          	mov    QWORD PTR [rax+0x30],r14
   2934a:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   29351:	6a 00                	push   0x0
   29353:	e8 88 3a 00 00       	call   2cde0 <JS_GetPropertyInternal>
   29358:	41 5b                	pop    r11
   2935a:	49 89 d0             	mov    r8,rdx
   2935d:	5a                   	pop    rdx
   2935e:	41 83 f8 06          	cmp    r8d,0x6
   29362:	0f 85 83 f9 ff ff    	jne    28ceb <JS_CallInternal+0x61eb>
   29368:	4d 89 f4             	mov    r12,r14
   2936b:	e9 30 9f ff ff       	jmp    232a0 <JS_CallInternal+0x7a0>
   29370:	48 89 d6             	mov    rsi,rdx
   29373:	49 c7 c2 ff ff ff ff 	mov    r10,0xffffffffffffffff
   2937a:	48 83 ec 08          	sub    rsp,0x8
   2937e:	4c 8d 5b f0          	lea    r11,[rbx-0x10]
   29382:	4c 8b 43 f0          	mov    r8,QWORD PTR [rbx-0x10]
   29386:	4c 8b 4b f8          	mov    r9,QWORD PTR [rbx-0x8]
   2938a:	48 8b bd 50 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x1b0]
   29391:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   29398:	4c 89 9d 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],r11
   2939f:	4c 89 d2             	mov    rdx,r10
   293a2:	48 89 78 30          	mov    QWORD PTR [rax+0x30],rdi
   293a6:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   293ad:	6a 00                	push   0x0
   293af:	e8 2c 3a 00 00       	call   2cde0 <JS_GetPropertyInternal>
   293b4:	5f                   	pop    rdi
   293b5:	4c 8b 9d 40 fe ff ff 	mov    r11,QWORD PTR [rbp-0x1c0]
   293bc:	83 fa 06             	cmp    edx,0x6
   293bf:	49 89 c5             	mov    r13,rax
   293c2:	49 89 d0             	mov    r8,rdx
   293c5:	41 59                	pop    r9
   293c7:	0f 85 1e ad ff ff    	jne    240eb <JS_CallInternal+0x15eb>
   293cd:	4c 8b a5 50 fe ff ff 	mov    r12,QWORD PTR [rbp-0x1b0]
   293d4:	e9 c7 9e ff ff       	jmp    232a0 <JS_CallInternal+0x7a0>
   293d9:	48 89 fe             	mov    rsi,rdi
   293dc:	49 c7 c2 ff ff ff ff 	mov    r10,0xffffffffffffffff
   293e3:	48 83 ec 08          	sub    rsp,0x8
   293e7:	4c 8b 43 f0          	mov    r8,QWORD PTR [rbx-0x10]
   293eb:	4c 8b 4b f8          	mov    r9,QWORD PTR [rbx-0x8]
   293ef:	4c 89 d2             	mov    rdx,r10
   293f2:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   293f9:	4c 89 9d 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],r11
   29400:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   29407:	4c 89 58 30          	mov    QWORD PTR [rax+0x30],r11
   2940b:	6a 00                	push   0x0
   2940d:	e8 ce 39 00 00       	call   2cde0 <JS_GetPropertyInternal>
   29412:	59                   	pop    rcx
   29413:	4c 8b 9d 50 fe ff ff 	mov    r11,QWORD PTR [rbp-0x1b0]
   2941a:	83 fa 06             	cmp    edx,0x6
   2941d:	5e                   	pop    rsi
   2941e:	0f 85 f0 ab ff ff    	jne    24014 <JS_CallInternal+0x1514>
   29424:	4d 89 dc             	mov    r12,r11
   29427:	e9 74 9e ff ff       	jmp    232a0 <JS_CallInternal+0x7a0>
   2942c:	4c 8b a5 50 fe ff ff 	mov    r12,QWORD PTR [rbp-0x1b0]
   29433:	e9 68 9e ff ff       	jmp    232a0 <JS_CallInternal+0x7a0>
   29438:	48 8b 8d c8 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x138]
   2943f:	4c 89 71 30          	mov    QWORD PTR [rcx+0x30],r14
   29443:	83 fa f6             	cmp    edx,0xfffffff6
   29446:	76 04                	jbe    2944c <JS_CallInternal+0x694c>
   29448:	83 40 fc 01          	add    DWORD PTR [rax-0x4],0x1
   2944c:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   29453:	48 89 95 f8 fe ff ff 	mov    QWORD PTR [rbp-0x108],rdx
   2945a:	48 8d b5 00 ff ff ff 	lea    rsi,[rbp-0x100]
   29461:	ba 8c 00 00 00       	mov    edx,0x8c
   29466:	48 89 85 f0 fe ff ff 	mov    QWORD PTR [rbp-0x110],rax
   2946d:	e8 2e c2 02 00       	call   556a0 <js_unary_arith_slow>
   29472:	85 c0                	test   eax,eax
   29474:	0f 85 67 37 00 00    	jne    2cbe1 <JS_CallInternal+0xa0e1>
   2947a:	49 8b 55 08          	mov    rdx,QWORD PTR [r13+0x8]
   2947e:	66 0f 6f a5 f0 fe ff 	movdqa xmm4,XMMWORD PTR [rbp-0x110]
   29485:	ff 
   29486:	49 8b 75 00          	mov    rsi,QWORD PTR [r13+0x0]
   2948a:	41 0f 11 65 00       	movups XMMWORD PTR [r13+0x0],xmm4
   2948f:	83 fa f6             	cmp    edx,0xfffffff6
   29492:	0f 86 7c dc ff ff    	jbe    27114 <JS_CallInternal+0x4614>
   29498:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   2949b:	83 e8 01             	sub    eax,0x1
   2949e:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   294a1:	85 c0                	test   eax,eax
   294a3:	0f 8f 6b dc ff ff    	jg     27114 <JS_CallInternal+0x4614>
   294a9:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   294b0:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   294b4:	e8 e7 33 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   294b9:	e9 56 dc ff ff       	jmp    27114 <JS_CallInternal+0x4614>
   294be:	48 8b 8d c8 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x138]
   294c5:	4c 89 71 30          	mov    QWORD PTR [rcx+0x30],r14
   294c9:	83 fa f6             	cmp    edx,0xfffffff6
   294cc:	76 04                	jbe    294d2 <JS_CallInternal+0x69d2>
   294ce:	83 40 fc 01          	add    DWORD PTR [rax-0x4],0x1
   294d2:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   294d9:	48 89 95 f8 fe ff ff 	mov    QWORD PTR [rbp-0x108],rdx
   294e0:	48 8d b5 00 ff ff ff 	lea    rsi,[rbp-0x100]
   294e7:	ba 8d 00 00 00       	mov    edx,0x8d
   294ec:	48 89 85 f0 fe ff ff 	mov    QWORD PTR [rbp-0x110],rax
   294f3:	e8 a8 c1 02 00       	call   556a0 <js_unary_arith_slow>
   294f8:	85 c0                	test   eax,eax
   294fa:	0f 85 63 38 00 00    	jne    2cd63 <JS_CallInternal+0xa263>
   29500:	49 8b 55 08          	mov    rdx,QWORD PTR [r13+0x8]
   29504:	66 0f 6f 9d f0 fe ff 	movdqa xmm3,XMMWORD PTR [rbp-0x110]
   2950b:	ff 
   2950c:	49 8b 75 00          	mov    rsi,QWORD PTR [r13+0x0]
   29510:	41 0f 11 5d 00       	movups XMMWORD PTR [r13+0x0],xmm3
   29515:	83 fa f6             	cmp    edx,0xfffffff6
   29518:	0f 86 6a e3 ff ff    	jbe    27888 <JS_CallInternal+0x4d88>
   2951e:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   29521:	83 e8 01             	sub    eax,0x1
   29524:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   29527:	85 c0                	test   eax,eax
   29529:	0f 8f 59 e3 ff ff    	jg     27888 <JS_CallInternal+0x4d88>
   2952f:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   29536:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2953a:	e8 61 33 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2953f:	e9 44 e3 ff ff       	jmp    27888 <JS_CallInternal+0x4d88>
   29544:	85 c0                	test   eax,eax
   29546:	0f 84 bc b9 ff ff    	je     24f08 <JS_CallInternal+0x2408>
   2954c:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   29553:	48 8b 73 f0          	mov    rsi,QWORD PTR [rbx-0x10]
   29557:	b9 01 00 00 00       	mov    ecx,0x1
   2955c:	48 8b 53 f8          	mov    rdx,QWORD PTR [rbx-0x8]
   29560:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   29567:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   2956b:	e8 c0 63 01 00       	call   3f930 <JS_ToStringInternal>
   29570:	48 89 c1             	mov    rcx,rax
   29573:	49 89 d5             	mov    r13,rdx
   29576:	83 fa 06             	cmp    edx,0x6
   29579:	0f 84 21 9d ff ff    	je     232a0 <JS_CallInternal+0x7a0>
   2957f:	48 8b 53 f8          	mov    rdx,QWORD PTR [rbx-0x8]
   29583:	48 8b 73 f0          	mov    rsi,QWORD PTR [rbx-0x10]
   29587:	83 fa f6             	cmp    edx,0xfffffff6
   2958a:	76 11                	jbe    2959d <JS_CallInternal+0x6a9d>
   2958c:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   2958f:	83 e8 01             	sub    eax,0x1
   29592:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   29595:	85 c0                	test   eax,eax
   29597:	0f 8e 93 2b 00 00    	jle    2c130 <JS_CallInternal+0x9630>
   2959d:	48 89 4b f0          	mov    QWORD PTR [rbx-0x10],rcx
   295a1:	4c 89 6b f8          	mov    QWORD PTR [rbx-0x8],r13
   295a5:	e9 5e b9 ff ff       	jmp    24f08 <JS_CallInternal+0x2408>
   295aa:	83 fa 08             	cmp    edx,0x8
   295ad:	0f 85 e8 0b 00 00    	jne    2a19b <JS_CallInternal+0x769b>
   295b3:	66 48 0f 6e c0       	movq   xmm0,rax
   295b8:	66 0f 57 05 e0 14 0b 	xorpd  xmm0,XMMWORD PTR [rip+0xb14e0]        # daaa0 <typed_array_size_log2+0x28>
   295bf:	00 
   295c0:	48 c7 43 f8 08 00 00 	mov    QWORD PTR [rbx-0x8],0x8
   295c7:	00 
   295c8:	f2 0f 11 43 f0       	movsd  QWORD PTR [rbx-0x10],xmm0
   295cd:	e9 d3 dd ff ff       	jmp    273a5 <JS_CallInternal+0x48a5>
   295d2:	83 bd 88 fe ff ff f6 	cmp    DWORD PTR [rbp-0x178],0xfffffff6
   295d9:	0f 86 95 c0 ff ff    	jbe    25674 <JS_CallInternal+0x2b74>
   295df:	e9 85 c0 ff ff       	jmp    25669 <JS_CallInternal+0x2b69>
   295e4:	0f 1f 40 00          	nop    DWORD PTR [rax+0x0]
   295e8:	45 85 ed             	test   r13d,r13d
   295eb:	0f 85 81 2f 00 00    	jne    2c572 <JS_CallInternal+0x9a72>
   295f1:	48 8b 53 e8          	mov    rdx,QWORD PTR [rbx-0x18]
   295f5:	48 8b 73 e0          	mov    rsi,QWORD PTR [rbx-0x20]
   295f9:	4c 8d 6b e0          	lea    r13,[rbx-0x20]
   295fd:	83 fa f6             	cmp    edx,0xfffffff6
   29600:	76 11                	jbe    29613 <JS_CallInternal+0x6b13>
   29602:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   29605:	83 e8 01             	sub    eax,0x1
   29608:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   2960b:	85 c0                	test   eax,eax
   2960d:	0f 8e 2a 2a 00 00    	jle    2c03d <JS_CallInternal+0x953d>
   29613:	48 8b 73 d0          	mov    rsi,QWORD PTR [rbx-0x30]
   29617:	48 8b 53 d8          	mov    rdx,QWORD PTR [rbx-0x28]
   2961b:	b9 01 00 00 00       	mov    ecx,0x1
   29620:	4c 89 eb             	mov    rbx,r13
   29623:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2962a:	e8 71 79 00 00       	call   30fa0 <JS_IteratorClose>
   2962f:	e9 09 9e ff ff       	jmp    2343d <JS_CallInternal+0x93d>
   29634:	48 8b 73 e0          	mov    rsi,QWORD PTR [rbx-0x20]
   29638:	48 8b 53 e8          	mov    rdx,QWORD PTR [rbx-0x18]
   2963c:	4c 89 e9             	mov    rcx,r13
   2963f:	4d 89 f0             	mov    r8,r14
   29642:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   29649:	41 b9 01 00 00 00    	mov    r9d,0x1
   2964f:	e8 ac 2e 01 00       	call   3c500 <JS_SetPrototypeInternal>
   29654:	85 c0                	test   eax,eax
   29656:	0f 89 7d db ff ff    	jns    271d9 <JS_CallInternal+0x46d9>
   2965c:	e9 3f 9c ff ff       	jmp    232a0 <JS_CallInternal+0x7a0>
   29661:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]
   29668:	41 83 f8 08          	cmp    r8d,0x8
   2966c:	0f 85 5c 0a 00 00    	jne    2a0ce <JS_CallInternal+0x75ce>
   29672:	66 0f ef c0          	pxor   xmm0,xmm0
   29676:	66 49 0f 6e d1       	movq   xmm2,r9
   2967b:	ba 00 00 00 00       	mov    edx,0x0
   29680:	f2 41 0f 2a c6       	cvtsi2sd xmm0,r14d
   29685:	66 0f 2e c2          	ucomisd xmm0,xmm2
   29689:	0f 9b c0             	setnp  al
   2968c:	0f 45 c2             	cmovne eax,edx
   2968f:	e9 e1 d2 ff ff       	jmp    26975 <JS_CallInternal+0x3e75>
   29694:	41 83 f8 08          	cmp    r8d,0x8
   29698:	0f 85 62 0a 00 00    	jne    2a100 <JS_CallInternal+0x7600>
   2969e:	66 0f ef c0          	pxor   xmm0,xmm0
   296a2:	66 49 0f 6e f9       	movq   xmm7,r9
   296a7:	31 c0                	xor    eax,eax
   296a9:	f2 41 0f 2a c6       	cvtsi2sd xmm0,r14d
   296ae:	66 0f 2e c7          	ucomisd xmm0,xmm7
   296b2:	0f 9b c0             	setnp  al
   296b5:	41 0f 45 c5          	cmovne eax,r13d
   296b9:	e9 57 d2 ff ff       	jmp    26915 <JS_CallInternal+0x3e15>
   296be:	41 83 fe 08          	cmp    r14d,0x8
   296c2:	0f 85 7c 0b 00 00    	jne    2a244 <JS_CallInternal+0x7744>
   296c8:	66 0f ef c0          	pxor   xmm0,xmm0
   296cc:	66 49 0f 6e f5       	movq   xmm6,r13
   296d1:	31 c0                	xor    eax,eax
   296d3:	f2 0f 2a c2          	cvtsi2sd xmm0,edx
   296d7:	ba 01 00 00 00       	mov    edx,0x1
   296dc:	66 0f 2e c6          	ucomisd xmm0,xmm6
   296e0:	0f 9a c0             	setp   al
   296e3:	48 0f 45 c2          	cmovne rax,rdx
   296e7:	e9 73 e2 ff ff       	jmp    2795f <JS_CallInternal+0x4e5f>
   296ec:	41 83 fe 08          	cmp    r14d,0x8
   296f0:	0f 85 72 0b 00 00    	jne    2a268 <JS_CallInternal+0x7768>
   296f6:	66 0f ef c0          	pxor   xmm0,xmm0
   296fa:	66 49 0f 6e dd       	movq   xmm3,r13
   296ff:	31 c0                	xor    eax,eax
   29701:	f2 0f 2a c2          	cvtsi2sd xmm0,edx
   29705:	ba 00 00 00 00       	mov    edx,0x0
   2970a:	66 0f 2e c3          	ucomisd xmm0,xmm3
   2970e:	0f 9b c0             	setnp  al
   29711:	48 0f 45 c2          	cmovne rax,rdx
   29715:	e9 99 e2 ff ff       	jmp    279b3 <JS_CallInternal+0x4eb3>
   2971a:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   29721:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   29725:	e8 76 31 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2972a:	e9 9d b6 ff ff       	jmp    24dcc <JS_CallInternal+0x22cc>
   2972f:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   29736:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2973d:	44 89 ea             	mov    edx,r13d
   29740:	48 89 de             	mov    rsi,rbx
   29743:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   29747:	e8 54 bf 02 00       	call   556a0 <js_unary_arith_slow>
   2974c:	85 c0                	test   eax,eax
   2974e:	0f 84 09 dc ff ff    	je     2735d <JS_CallInternal+0x485d>
   29754:	e9 47 9b ff ff       	jmp    232a0 <JS_CallInternal+0x7a0>
   29759:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]
   29760:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   29767:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2976e:	44 89 ea             	mov    edx,r13d
   29771:	48 89 de             	mov    rsi,rbx
   29774:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   29778:	e8 c3 c3 02 00       	call   55b40 <js_post_inc_slow>
   2977d:	85 c0                	test   eax,eax
   2977f:	0f 84 44 e1 ff ff    	je     278c9 <JS_CallInternal+0x4dc9>
   29785:	e9 16 9b ff ff       	jmp    232a0 <JS_CallInternal+0x7a0>
   2978a:	66 0f 1f 44 00 00    	nop    WORD PTR [rax+rax*1+0x0]
   29790:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   29797:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2979e:	44 89 ea             	mov    edx,r13d
   297a1:	48 89 de             	mov    rsi,rbx
   297a4:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   297a8:	e8 f3 be 02 00       	call   556a0 <js_unary_arith_slow>
   297ad:	85 c0                	test   eax,eax
   297af:	0f 84 7a d4 ff ff    	je     26c2f <JS_CallInternal+0x412f>
   297b5:	e9 e6 9a ff ff       	jmp    232a0 <JS_CallInternal+0x7a0>
   297ba:	66 0f 1f 44 00 00    	nop    WORD PTR [rax+rax*1+0x0]
   297c0:	41 83 e6 02          	and    r14d,0x2
   297c4:	48 8d 4b c0          	lea    rcx,[rbx-0x40]
   297c8:	48 8b 73 c0          	mov    rsi,QWORD PTR [rbx-0x40]
   297cc:	4c 8b 41 08          	mov    r8,QWORD PTR [rcx+0x8]
   297d0:	0f 84 eb 0b 00 00    	je     2a3c1 <JS_CallInternal+0x78c1>
   297d6:	48 83 ec 08          	sub    rsp,0x8
   297da:	45 31 c9             	xor    r9d,r9d
   297dd:	6a 00                	push   0x0
   297df:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   297e6:	48 89 f1             	mov    rcx,rsi
   297e9:	48 89 c6             	mov    rsi,rax
   297ec:	e8 7f 35 00 00       	call   2cd70 <JS_CallFree>
   297f1:	41 5a                	pop    r10
   297f3:	41 5b                	pop    r11
   297f5:	48 89 c1             	mov    rcx,rax
   297f8:	49 89 d6             	mov    r14,rdx
   297fb:	83 fa 06             	cmp    edx,0x6
   297fe:	0f 84 4d 0c 00 00    	je     2a451 <JS_CallInternal+0x7951>
   29804:	48 8b 53 f8          	mov    rdx,QWORD PTR [rbx-0x8]
   29808:	48 8b 73 f0          	mov    rsi,QWORD PTR [rbx-0x10]
   2980c:	83 fa f6             	cmp    edx,0xfffffff6
   2980f:	76 11                	jbe    29822 <JS_CallInternal+0x6d22>
   29811:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   29814:	83 e8 01             	sub    eax,0x1
   29817:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   2981a:	85 c0                	test   eax,eax
   2981c:	0f 8e 92 29 00 00    	jle    2c1b4 <JS_CallInternal+0x96b4>
   29822:	48 89 4b f0          	mov    QWORD PTR [rbx-0x10],rcx
   29826:	31 c9                	xor    ecx,ecx
   29828:	4c 89 73 f8          	mov    QWORD PTR [rbx-0x8],r14
   2982c:	e9 3a e5 ff ff       	jmp    27d6b <JS_CallInternal+0x526b>
   29831:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   29838:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2983f:	44 89 ea             	mov    edx,r13d
   29842:	48 89 de             	mov    rsi,rbx
   29845:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   29849:	e8 f2 c2 02 00       	call   55b40 <js_post_inc_slow>
   2984e:	85 c0                	test   eax,eax
   29850:	0f 84 94 d3 ff ff    	je     26bea <JS_CallInternal+0x40ea>
   29856:	e9 45 9a ff ff       	jmp    232a0 <JS_CallInternal+0x7a0>
   2985b:	0f 1f 44 00 00       	nop    DWORD PTR [rax+rax*1+0x0]
   29860:	48 8b 73 e0          	mov    rsi,QWORD PTR [rbx-0x20]
   29864:	48 8b 53 e8          	mov    rdx,QWORD PTR [rbx-0x18]
   29868:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2986f:	e8 9c 9c 01 00       	call   43510 <JS_ValueToAtom>
   29874:	89 85 50 fe ff ff    	mov    DWORD PTR [rbp-0x1b0],eax
   2987a:	85 c0                	test   eax,eax
   2987c:	0f 84 1e 9a ff ff    	je     232a0 <JS_CallInternal+0x7a0>
   29882:	4d 89 e5             	mov    r13,r12
   29885:	e9 a4 9f ff ff       	jmp    2382e <JS_CallInternal+0xd2e>
   2988a:	66 0f ef c0          	pxor   xmm0,xmm0
   2988e:	f2 48 0f 2a c0       	cvtsi2sd xmm0,rax
   29893:	b8 08 00 00 00       	mov    eax,0x8
   29898:	e9 b2 cf ff ff       	jmp    2684f <JS_CallInternal+0x3d4f>
   2989d:	4c 89 c6             	mov    rsi,r8
   298a0:	48 89 df             	mov    rdi,rbx
   298a3:	48 89 8d 10 fe ff ff 	mov    QWORD PTR [rbp-0x1f0],rcx
   298aa:	4c 89 85 28 fe ff ff 	mov    QWORD PTR [rbp-0x1d8],r8
   298b1:	e8 3a 23 01 00       	call   3bbf0 <expand_fast_array>
   298b6:	4c 8b 85 28 fe ff ff 	mov    r8,QWORD PTR [rbp-0x1d8]
   298bd:	48 8b 8d 10 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x1f0]
   298c4:	85 c0                	test   eax,eax
   298c6:	0f 88 87 28 00 00    	js     2c153 <JS_CallInternal+0x9653>
   298cc:	8b 85 50 fe ff ff    	mov    eax,DWORD PTR [rbp-0x1b0]
   298d2:	41 89 40 38          	mov    DWORD PTR [r8+0x38],eax
   298d6:	31 c0                	xor    eax,eax
   298d8:	0f 1f 84 00 00 00 00 	nop    DWORD PTR [rax+rax*1+0x0]
   298df:	00 
   298e0:	f3 41 0f 6f 5c 05 00 	movdqu xmm3,XMMWORD PTR [r13+rax*1+0x0]
   298e7:	49 8b 50 30          	mov    rdx,QWORD PTR [r8+0x30]
   298eb:	0f 11 1c 02          	movups XMMWORD PTR [rdx+rax*1],xmm3
   298ef:	48 83 c0 10          	add    rax,0x10
   298f3:	4c 39 f0             	cmp    rax,r14
   298f6:	75 e8                	jne    298e0 <JS_CallInternal+0x6de0>
   298f8:	49 8b 40 20          	mov    rax,QWORD PTR [r8+0x20]
   298fc:	48 8b 9d 40 fe ff ff 	mov    rbx,QWORD PTR [rbp-0x1c0]
   29903:	48 8b 50 08          	mov    rdx,QWORD PTR [rax+0x8]
   29907:	48 8b 30             	mov    rsi,QWORD PTR [rax]
   2990a:	48 c7 40 08 00 00 00 	mov    QWORD PTR [rax+0x8],0x0
   29911:	00 
   29912:	48 89 18             	mov    QWORD PTR [rax],rbx
   29915:	83 fa f6             	cmp    edx,0xfffffff6
   29918:	0f 86 2d a6 ff ff    	jbe    23f4b <JS_CallInternal+0x144b>
   2991e:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   29921:	83 e8 01             	sub    eax,0x1
   29924:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   29927:	85 c0                	test   eax,eax
   29929:	0f 8f 1c a6 ff ff    	jg     23f4b <JS_CallInternal+0x144b>
   2992f:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   29936:	48 89 8d 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],rcx
   2993d:	4c 89 85 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],r8
   29944:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   29948:	e8 53 2f ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2994d:	48 8b 8d 40 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x1c0]
   29954:	4c 8b 85 50 fe ff ff 	mov    r8,QWORD PTR [rbp-0x1b0]
   2995b:	e9 eb a5 ff ff       	jmp    23f4b <JS_CallInternal+0x144b>
   29960:	48 8b bd d8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x128]
   29967:	48 03 77 30          	add    rsi,QWORD PTR [rdi+0x30]
   2996b:	80 7a 11 00          	cmp    BYTE PTR [rdx+0x11],0x0
   2996f:	0f 84 bd 11 00 00    	je     2ab32 <JS_CallInternal+0x8032>
   29975:	41 83 fd 3a          	cmp    r13d,0x3a
   29979:	0f 84 e2 9d ff ff    	je     23761 <JS_CallInternal+0xc61>
   2997f:	8b 76 04             	mov    esi,DWORD PTR [rsi+0x4]
   29982:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   29989:	83 f9 04             	cmp    ecx,0x4
   2998c:	0f 84 5f 32 00 00    	je     2cbf1 <JS_CallInternal+0xa0f1>
   29992:	e8 79 87 00 00       	call   32110 <JS_ThrowTypeErrorReadOnly.part.0>
   29997:	4d 89 f4             	mov    r12,r14
   2999a:	e9 01 99 ff ff       	jmp    232a0 <JS_CallInternal+0x7a0>
   2999f:	90                   	nop
   299a0:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   299a7:	48 89 fa             	mov    rdx,rdi
   299aa:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   299b1:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   299b5:	e8 96 3a 00 00       	call   2d450 <JS_GetPropertyValue>
   299ba:	48 89 c1             	mov    rcx,rax
   299bd:	48 89 d0             	mov    rax,rdx
   299c0:	83 fa 06             	cmp    edx,0x6
   299c3:	0f 85 31 bd ff ff    	jne    256fa <JS_CallInternal+0x2bfa>
   299c9:	48 83 eb 10          	sub    rbx,0x10
   299cd:	e9 ce 98 ff ff       	jmp    232a0 <JS_CallInternal+0x7a0>
   299d2:	31 c0                	xor    eax,eax
   299d4:	e9 e8 ca ff ff       	jmp    264c1 <JS_CallInternal+0x39c1>
   299d9:	48 8b 8d 50 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x1b0]
   299e0:	4d 89 f0             	mov    r8,r14
   299e3:	4c 89 ce             	mov    rsi,r9
   299e6:	4c 89 ea             	mov    rdx,r13
   299e9:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   299f0:	4c 89 8d 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],r9
   299f7:	e8 d4 78 00 00       	call   312d0 <JS_CheckBrand>
   299fc:	85 c0                	test   eax,eax
   299fe:	0f 88 9c 98 ff ff    	js     232a0 <JS_CallInternal+0x7a0>
   29a04:	4c 8b 8d 40 fe ff ff 	mov    r9,QWORD PTR [rbp-0x1c0]
   29a0b:	0f 95 c0             	setne  al
   29a0e:	e9 82 d3 ff ff       	jmp    26d95 <JS_CallInternal+0x4295>
   29a13:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   29a1a:	48 8d 7b f0          	lea    rdi,[rbx-0x10]
   29a1e:	41 b9 00 80 00 00    	mov    r9d,0x8000
   29a24:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   29a28:	48 8d 43 e0          	lea    rax,[rbx-0x20]
   29a2c:	4c 8b 40 08          	mov    r8,QWORD PTR [rax+0x8]
   29a30:	48 83 eb 30          	sub    rbx,0x30
   29a34:	48 8b 33             	mov    rsi,QWORD PTR [rbx]
   29a37:	48 8b 53 08          	mov    rdx,QWORD PTR [rbx+0x8]
   29a3b:	48 8b 08             	mov    rcx,QWORD PTR [rax]
   29a3e:	ff 77 08             	push   QWORD PTR [rdi+0x8]
   29a41:	ff 37                	push   QWORD PTR [rdi]
   29a43:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   29a4a:	e8 d1 4d 00 00       	call   2e820 <JS_SetPropertyValue>
   29a4f:	48 8b 53 08          	mov    rdx,QWORD PTR [rbx+0x8]
   29a53:	5f                   	pop    rdi
   29a54:	48 8b 33             	mov    rsi,QWORD PTR [rbx]
   29a57:	41 89 c5             	mov    r13d,eax
   29a5a:	41 58                	pop    r8
   29a5c:	83 fa f6             	cmp    edx,0xfffffff6
   29a5f:	76 11                	jbe    29a72 <JS_CallInternal+0x6f72>
   29a61:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   29a64:	83 e8 01             	sub    eax,0x1
   29a67:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   29a6a:	85 c0                	test   eax,eax
   29a6c:	0f 8e 4f 25 00 00    	jle    2bfc1 <JS_CallInternal+0x94c1>
   29a72:	45 85 ed             	test   r13d,r13d
   29a75:	0f 89 d2 e6 ff ff    	jns    2814d <JS_CallInternal+0x564d>
   29a7b:	e9 20 98 ff ff       	jmp    232a0 <JS_CallInternal+0x7a0>
   29a80:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   29a87:	48 89 ca             	mov    rdx,rcx
   29a8a:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   29a8e:	4c 89 c0             	mov    rax,r8
   29a91:	49 89 f8             	mov    r8,rdi
   29a94:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   29a9b:	48 89 c1             	mov    rcx,rax
   29a9e:	e8 ad 39 00 00       	call   2d450 <JS_GetPropertyValue>
   29aa3:	48 89 c1             	mov    rcx,rax
   29aa6:	48 89 d0             	mov    rax,rdx
   29aa9:	48 89 ca             	mov    rdx,rcx
   29aac:	83 f8 06             	cmp    eax,0x6
   29aaf:	0f 85 20 e4 ff ff    	jne    27ed5 <JS_CallInternal+0x53d5>
   29ab5:	45 31 c0             	xor    r8d,r8d
   29ab8:	48 c7 43 f8 03 00 00 	mov    QWORD PTR [rbx-0x8],0x3
   29abf:	00 
   29ac0:	4c 89 43 f0          	mov    QWORD PTR [rbx-0x10],r8
   29ac4:	e9 d7 97 ff ff       	jmp    232a0 <JS_CallInternal+0x7a0>
   29ac9:	31 c9                	xor    ecx,ecx
   29acb:	41 b8 03 00 00 00    	mov    r8d,0x3
   29ad1:	e9 0d a9 ff ff       	jmp    243e3 <JS_CallInternal+0x18e3>
   29ad6:	8b 00                	mov    eax,DWORD PTR [rax]
   29ad8:	25 ff ff ff 03       	and    eax,0x3ffffff
   29add:	0f 85 fc 97 ff ff    	jne    232df <JS_CallInternal+0x7df>
   29ae3:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   29aea:	48 83 ec 08          	sub    rsp,0x8
   29aee:	31 c9                	xor    ecx,ecx
   29af0:	45 31 c9             	xor    r9d,r9d
   29af3:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   29afa:	45 31 c0             	xor    r8d,r8d
   29afd:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   29b01:	48 8b 85 c0 fe ff ff 	mov    rax,QWORD PTR [rbp-0x140]
   29b08:	48 8b b0 d8 04 00 00 	mov    rsi,QWORD PTR [rax+0x4d8]
   29b0f:	48 8b 90 e0 04 00 00 	mov    rdx,QWORD PTR [rax+0x4e0]
   29b16:	6a 00                	push   0x0
   29b18:	e8 73 64 00 00       	call   2ff90 <build_backtrace>
   29b1d:	59                   	pop    rcx
   29b1e:	5e                   	pop    rsi
   29b1f:	e9 cc 97 ff ff       	jmp    232f0 <JS_CallInternal+0x7f0>
   29b24:	41 8b 30             	mov    esi,DWORD PTR [r8]
   29b27:	81 e6 ff ff ff 03    	and    esi,0x3ffffff
   29b2d:	0f 85 73 dc ff ff    	jne    277a6 <JS_CallInternal+0x4ca6>
   29b33:	48 83 ec 08          	sub    rsp,0x8
   29b37:	4c 8b 43 f0          	mov    r8,QWORD PTR [rbx-0x10]
   29b3b:	4c 8b 4b f8          	mov    r9,QWORD PTR [rbx-0x8]
   29b3f:	48 89 c6             	mov    rsi,rax
   29b42:	48 8b bd c8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x138]
   29b49:	4c 89 95 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],r10
   29b50:	4c 89 57 30          	mov    QWORD PTR [rdi+0x30],r10
   29b54:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   29b5b:	68 00 80 00 00       	push   0x8000
   29b60:	52                   	push   rdx
   29b61:	50                   	push   rax
   29b62:	e8 a9 3f 00 00       	call   2db10 <JS_SetPropertyInternal>
   29b67:	48 83 c4 20          	add    rsp,0x20
   29b6b:	41 83 fe f6          	cmp    r14d,0xfffffff6
   29b6f:	4c 8b 95 50 fe ff ff 	mov    r10,QWORD PTR [rbp-0x1b0]
   29b76:	89 c1                	mov    ecx,eax
   29b78:	76 13                	jbe    29b8d <JS_CallInternal+0x708d>
   29b7a:	41 8b 45 fc          	mov    eax,DWORD PTR [r13-0x4]
   29b7e:	83 e8 01             	sub    eax,0x1
   29b81:	41 89 45 fc          	mov    DWORD PTR [r13-0x4],eax
   29b85:	85 c0                	test   eax,eax
   29b87:	0f 8e 75 25 00 00    	jle    2c102 <JS_CallInternal+0x9602>
   29b8d:	48 83 eb 20          	sub    rbx,0x20
   29b91:	85 c9                	test   ecx,ecx
   29b93:	0f 89 83 dc ff ff    	jns    2781c <JS_CallInternal+0x4d1c>
   29b99:	4d 89 d4             	mov    r12,r10
   29b9c:	e9 ff 96 ff ff       	jmp    232a0 <JS_CallInternal+0x7a0>
   29ba1:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   29ba8:	48 89 ce             	mov    rsi,rcx
   29bab:	e8 20 4f ff ff       	call   1ead0 <JS_ToBoolFree>
   29bb0:	e9 18 db ff ff       	jmp    276cd <JS_CallInternal+0x4bcd>
   29bb5:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   29bbc:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   29bc3:	48 89 de             	mov    rsi,rbx
   29bc6:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   29bca:	e8 e1 bf 02 00       	call   55bb0 <js_not_slow>
   29bcf:	85 c0                	test   eax,eax
   29bd1:	0f 84 d2 d4 ff ff    	je     270a9 <JS_CallInternal+0x45a9>
   29bd7:	e9 c4 96 ff ff       	jmp    232a0 <JS_CallInternal+0x7a0>
   29bdc:	0f 1f 40 00          	nop    DWORD PTR [rax+0x0]
   29be0:	49 8b 75 f0          	mov    rsi,QWORD PTR [r13-0x10]
   29be4:	49 8b 55 f8          	mov    rdx,QWORD PTR [r13-0x8]
   29be8:	41 b8 03 00 00 00    	mov    r8d,0x3
   29bee:	31 c9                	xor    ecx,ecx
   29bf0:	44 8b 8d 50 fe ff ff 	mov    r9d,DWORD PTR [rbp-0x1b0]
   29bf7:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   29bfe:	48 c7 85 90 fd ff ff 	mov    QWORD PTR [rbp-0x270],0x0
   29c05:	00 00 00 00 
   29c09:	48 c7 85 98 fd ff ff 	mov    QWORD PTR [rbp-0x268],0x3
   29c10:	03 00 00 00 
   29c14:	6a 00                	push   0x0
   29c16:	41 55                	push   r13
   29c18:	ff b5 98 fd ff ff    	push   QWORD PTR [rbp-0x268]
   29c1e:	ff b5 90 fd ff ff    	push   QWORD PTR [rbp-0x270]
   29c24:	e8 d7 8e ff ff       	call   22b00 <JS_CallInternal>
   29c29:	48 83 c4 20          	add    rsp,0x20
   29c2d:	49 89 c1             	mov    r9,rax
   29c30:	49 89 d0             	mov    r8,rdx
   29c33:	e9 db a7 ff ff       	jmp    24413 <JS_CallInternal+0x1913>
   29c38:	31 c9                	xor    ecx,ecx
   29c3a:	41 b8 03 00 00 00    	mov    r8d,0x3
   29c40:	e9 54 a6 ff ff       	jmp    24299 <JS_CallInternal+0x1799>
   29c45:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   29c4c:	48 89 ce             	mov    rsi,rcx
   29c4f:	e8 7c 4e ff ff       	call   1ead0 <JS_ToBoolFree>
   29c54:	e9 8b e5 ff ff       	jmp    281e4 <JS_CallInternal+0x56e4>
   29c59:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   29c60:	48 89 ce             	mov    rsi,rcx
   29c63:	e8 68 4e ff ff       	call   1ead0 <JS_ToBoolFree>
   29c68:	e9 10 e5 ff ff       	jmp    2817d <JS_CallInternal+0x567d>
   29c6d:	48 8b b5 28 fe ff ff 	mov    rsi,QWORD PTR [rbp-0x1d8]
   29c74:	45 89 d1             	mov    r9d,r10d
   29c77:	4c 89 ea             	mov    rdx,r13
   29c7a:	31 c9                	xor    ecx,ecx
   29c7c:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   29c83:	41 b8 03 00 00 00    	mov    r8d,0x3
   29c89:	48 c7 85 a0 fd ff ff 	mov    QWORD PTR [rbp-0x260],0x0
   29c90:	00 00 00 00 
   29c94:	48 c7 85 a8 fd ff ff 	mov    QWORD PTR [rbp-0x258],0x3
   29c9b:	03 00 00 00 
   29c9f:	6a 02                	push   0x2
   29ca1:	41 56                	push   r14
   29ca3:	ff b5 a8 fd ff ff    	push   QWORD PTR [rbp-0x258]
   29ca9:	ff b5 a0 fd ff ff    	push   QWORD PTR [rbp-0x260]
   29caf:	44 89 95 38 fe ff ff 	mov    DWORD PTR [rbp-0x1c8],r10d
   29cb6:	e8 45 8e ff ff       	call   22b00 <JS_CallInternal>
   29cbb:	44 8b 95 38 fe ff ff 	mov    r10d,DWORD PTR [rbp-0x1c8]
   29cc2:	48 83 c4 20          	add    rsp,0x20
   29cc6:	48 89 85 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],rax
   29ccd:	49 89 d5             	mov    r13,rdx
   29cd0:	e9 06 a6 ff ff       	jmp    242db <JS_CallInternal+0x17db>
   29cd5:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   29cdc:	48 89 ce             	mov    rsi,rcx
   29cdf:	e8 ec 4d ff ff       	call   1ead0 <JS_ToBoolFree>
   29ce4:	e9 b6 eb ff ff       	jmp    2889f <JS_CallInternal+0x5d9f>
   29ce9:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   29cf0:	48 89 d6             	mov    rsi,rdx
   29cf3:	48 89 c2             	mov    rdx,rax
   29cf6:	e8 d5 4d ff ff       	call   1ead0 <JS_ToBoolFree>
   29cfb:	e9 df df ff ff       	jmp    27cdf <JS_CallInternal+0x51df>
   29d00:	4d 39 2e             	cmp    QWORD PTR [r14],r13
   29d03:	0f 85 6a a3 ff ff    	jne    24073 <JS_CallInternal+0x1573>
   29d09:	41 8b 46 08          	mov    eax,DWORD PTR [r14+0x8]
   29d0d:	83 f8 ff             	cmp    eax,0xffffffff
   29d10:	0f 84 5d a3 ff ff    	je     24073 <JS_CallInternal+0x1573>
   29d16:	48 c1 e0 04          	shl    rax,0x4
   29d1a:	48 03 46 20          	add    rax,QWORD PTR [rsi+0x20]
   29d1e:	4c 8b 40 08          	mov    r8,QWORD PTR [rax+0x8]
   29d22:	4c 8b 28             	mov    r13,QWORD PTR [rax]
   29d25:	41 83 f8 f6          	cmp    r8d,0xfffffff6
   29d29:	76 05                	jbe    29d30 <JS_CallInternal+0x7230>
   29d2b:	41 83 45 fc 01       	add    DWORD PTR [r13-0x4],0x1
   29d30:	4c 8d 5b f0          	lea    r11,[rbx-0x10]
   29d34:	e9 b2 a3 ff ff       	jmp    240eb <JS_CallInternal+0x15eb>
   29d39:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   29d40:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   29d44:	89 c8                	mov    eax,ecx
   29d46:	48 8b 97 48 04 00 00 	mov    rdx,QWORD PTR [rdi+0x448]
   29d4d:	48 8b 34 c2          	mov    rsi,QWORD PTR [rdx+rax*8]
   29d51:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   29d54:	83 e8 01             	sub    eax,0x1
   29d57:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   29d5a:	85 c0                	test   eax,eax
   29d5c:	0f 8f 1e d1 ff ff    	jg     26e80 <JS_CallInternal+0x4380>
   29d62:	44 89 85 38 fe ff ff 	mov    DWORD PTR [rbp-0x1c8],r8d
   29d69:	e8 92 b6 fe ff       	call   15400 <JS_FreeAtomStruct>
   29d6e:	44 8b 85 38 fe ff ff 	mov    r8d,DWORD PTR [rbp-0x1c8]
   29d75:	e9 06 d1 ff ff       	jmp    26e80 <JS_CallInternal+0x4380>
   29d7a:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   29d81:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   29d85:	48 8b 87 48 04 00 00 	mov    rax,QWORD PTR [rdi+0x448]
   29d8c:	4a 8b 34 e8          	mov    rsi,QWORD PTR [rax+r13*8]
   29d90:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   29d93:	83 e8 01             	sub    eax,0x1
   29d96:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   29d99:	85 c0                	test   eax,eax
   29d9b:	0f 8f 08 ea ff ff    	jg     287a9 <JS_CallInternal+0x5ca9>
   29da1:	e8 5a b6 fe ff       	call   15400 <JS_FreeAtomStruct>
   29da6:	4c 8b 95 40 fe ff ff 	mov    r10,QWORD PTR [rbp-0x1c0]
   29dad:	e9 f7 e9 ff ff       	jmp    287a9 <JS_CallInternal+0x5ca9>
   29db2:	48 8b 8d e8 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x118]
   29db9:	48 8b 79 10          	mov    rdi,QWORD PTR [rcx+0x10]
   29dbd:	48 8b 97 48 04 00 00 	mov    rdx,QWORD PTR [rdi+0x448]
   29dc4:	4a 8b 34 ea          	mov    rsi,QWORD PTR [rdx+r13*8]
   29dc8:	8b 4e fc             	mov    ecx,DWORD PTR [rsi-0x4]
   29dcb:	8d 51 ff             	lea    edx,[rcx-0x1]
   29dce:	89 56 fc             	mov    DWORD PTR [rsi-0x4],edx
   29dd1:	85 d2                	test   edx,edx
   29dd3:	0f 8f a5 e1 ff ff    	jg     27f7e <JS_CallInternal+0x547e>
   29dd9:	48 89 85 28 fe ff ff 	mov    QWORD PTR [rbp-0x1d8],rax
   29de0:	e8 1b b6 fe ff       	call   15400 <JS_FreeAtomStruct>
   29de5:	48 8b 85 28 fe ff ff 	mov    rax,QWORD PTR [rbp-0x1d8]
   29dec:	4c 8b 95 38 fe ff ff 	mov    r10,QWORD PTR [rbp-0x1c8]
   29df3:	e9 86 e1 ff ff       	jmp    27f7e <JS_CallInternal+0x547e>
   29df8:	41 83 fd fa          	cmp    r13d,0xfffffffa
   29dfc:	0f 8d 81 22 00 00    	jge    2c083 <JS_CallInternal+0x9583>
   29e02:	41 83 fd f8          	cmp    r13d,0xfffffff8
   29e06:	7d 65                	jge    29e6d <JS_CallInternal+0x736d>
   29e08:	83 e8 02             	sub    eax,0x2
   29e0b:	83 f8 01             	cmp    eax,0x1
   29e0e:	0f 86 ed 23 00 00    	jbe    2c201 <JS_CallInternal+0x9701>
   29e14:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   29e1b:	48 8b 73 f0          	mov    rsi,QWORD PTR [rbx-0x10]
   29e1f:	b9 01 00 00 00       	mov    ecx,0x1
   29e24:	48 8b 53 f8          	mov    rdx,QWORD PTR [rbx-0x8]
   29e28:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   29e2f:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   29e33:	e8 f8 5a 01 00       	call   3f930 <JS_ToStringInternal>
   29e38:	49 89 d0             	mov    r8,rdx
   29e3b:	49 89 d5             	mov    r13,rdx
   29e3e:	83 fa 06             	cmp    edx,0x6
   29e41:	0f 84 59 94 ff ff    	je     232a0 <JS_CallInternal+0x7a0>
   29e47:	48 8b 53 f8          	mov    rdx,QWORD PTR [rbx-0x8]
   29e4b:	48 8b 73 f0          	mov    rsi,QWORD PTR [rbx-0x10]
   29e4f:	83 fa f6             	cmp    edx,0xfffffff6
   29e52:	76 11                	jbe    29e65 <JS_CallInternal+0x7365>
   29e54:	8b 4e fc             	mov    ecx,DWORD PTR [rsi-0x4]
   29e57:	83 e9 01             	sub    ecx,0x1
   29e5a:	89 4e fc             	mov    DWORD PTR [rsi-0x4],ecx
   29e5d:	85 c9                	test   ecx,ecx
   29e5f:	0f 8e 3a 26 00 00    	jle    2c49f <JS_CallInternal+0x999f>
   29e65:	48 89 43 f0          	mov    QWORD PTR [rbx-0x10],rax
   29e69:	4c 89 43 f8          	mov    QWORD PTR [rbx-0x8],r8
   29e6d:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   29e74:	48 8b 4b f0          	mov    rcx,QWORD PTR [rbx-0x10]
   29e78:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   29e7c:	41 83 fd f6          	cmp    r13d,0xfffffff6
   29e80:	76 04                	jbe    29e86 <JS_CallInternal+0x7386>
   29e82:	83 41 fc 01          	add    DWORD PTR [rcx-0x4],0x1
   29e86:	48 8b 73 e0          	mov    rsi,QWORD PTR [rbx-0x20]
   29e8a:	48 8b 53 e8          	mov    rdx,QWORD PTR [rbx-0x18]
   29e8e:	4d 89 e8             	mov    r8,r13
   29e91:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   29e98:	e8 b3 35 00 00       	call   2d450 <JS_GetPropertyValue>
   29e9d:	48 89 c1             	mov    rcx,rax
   29ea0:	48 89 d0             	mov    rax,rdx
   29ea3:	83 fa 06             	cmp    edx,0x6
   29ea6:	0f 85 b5 df ff ff    	jne    27e61 <JS_CallInternal+0x5361>
   29eac:	e9 ef 93 ff ff       	jmp    232a0 <JS_CallInternal+0x7a0>
   29eb1:	8b 08                	mov    ecx,DWORD PTR [rax]
   29eb3:	81 e1 ff ff ff 03    	and    ecx,0x3ffffff
   29eb9:	0f 85 12 b1 ff ff    	jne    24fd1 <JS_CallInternal+0x24d1>
   29ebf:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   29ec6:	44 89 f1             	mov    ecx,r14d
   29ec9:	48 8b b7 80 01 00 00 	mov    rsi,QWORD PTR [rdi+0x180]
   29ed0:	48 8b 97 88 01 00 00 	mov    rdx,QWORD PTR [rdi+0x188]
   29ed7:	e8 b4 43 04 00       	call   6e290 <JS_HasProperty>
   29edc:	85 c0                	test   eax,eax
   29ede:	0f 88 4f 2e 00 00    	js     2cd33 <JS_CallInternal+0xa233>
   29ee4:	b8 01 00 00 00       	mov    eax,0x1
   29ee9:	0f 84 f5 b0 ff ff    	je     24fe4 <JS_CallInternal+0x24e4>
   29eef:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   29ef6:	45 31 c0             	xor    r8d,r8d
   29ef9:	44 89 f1             	mov    ecx,r14d
   29efc:	48 8b b7 80 01 00 00 	mov    rsi,QWORD PTR [rdi+0x180]
   29f03:	48 8b 97 88 01 00 00 	mov    rdx,QWORD PTR [rdi+0x188]
   29f0a:	e8 b1 09 02 00       	call   4a8c0 <JS_DeleteProperty>
   29f0f:	85 c0                	test   eax,eax
   29f11:	0f 88 4d 24 00 00    	js     2c364 <JS_CallInternal+0x9864>
   29f17:	0f 95 c0             	setne  al
   29f1a:	0f b6 c0             	movzx  eax,al
   29f1d:	e9 c2 b0 ff ff       	jmp    24fe4 <JS_CallInternal+0x24e4>
   29f22:	4d 39 2e             	cmp    QWORD PTR [r14],r13
   29f25:	0f 85 79 a0 ff ff    	jne    23fa4 <JS_CallInternal+0x14a4>
   29f2b:	41 8b 46 08          	mov    eax,DWORD PTR [r14+0x8]
   29f2f:	83 f8 ff             	cmp    eax,0xffffffff
   29f32:	0f 84 6c a0 ff ff    	je     23fa4 <JS_CallInternal+0x14a4>
   29f38:	89 c2                	mov    edx,eax
   29f3a:	48 c1 e2 04          	shl    rdx,0x4
   29f3e:	48 03 56 20          	add    rdx,QWORD PTR [rsi+0x20]
   29f42:	48 8b 02             	mov    rax,QWORD PTR [rdx]
   29f45:	48 8b 52 08          	mov    rdx,QWORD PTR [rdx+0x8]
   29f49:	83 fa f6             	cmp    edx,0xfffffff6
   29f4c:	0f 86 c2 a0 ff ff    	jbe    24014 <JS_CallInternal+0x1514>
   29f52:	83 40 fc 01          	add    DWORD PTR [rax-0x4],0x1
   29f56:	e9 b9 a0 ff ff       	jmp    24014 <JS_CallInternal+0x1514>
   29f5b:	0f 1f 44 00 00       	nop    DWORD PTR [rax+rax*1+0x0]
   29f60:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   29f67:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   29f6b:	89 c8                	mov    eax,ecx
   29f6d:	48 8b 97 48 04 00 00 	mov    rdx,QWORD PTR [rdi+0x448]
   29f74:	48 8b 34 c2          	mov    rsi,QWORD PTR [rdx+rax*8]
   29f78:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   29f7b:	83 e8 01             	sub    eax,0x1
   29f7e:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   29f81:	85 c0                	test   eax,eax
   29f83:	0f 8f 01 b1 ff ff    	jg     2508a <JS_CallInternal+0x258a>
   29f89:	44 89 85 38 fe ff ff 	mov    DWORD PTR [rbp-0x1c8],r8d
   29f90:	e8 6b b4 fe ff       	call   15400 <JS_FreeAtomStruct>
   29f95:	44 8b 85 38 fe ff ff 	mov    r8d,DWORD PTR [rbp-0x1c8]
   29f9c:	e9 e9 b0 ff ff       	jmp    2508a <JS_CallInternal+0x258a>
   29fa1:	c7 85 f0 fe ff ff ff 	mov    DWORD PTR [rbp-0x110],0xffffffff
   29fa8:	ff ff ff 
   29fab:	b9 ff ff ff ff       	mov    ecx,0xffffffff
   29fb0:	4d 8b 45 08          	mov    r8,QWORD PTR [r13+0x8]
   29fb4:	49 8b 75 00          	mov    rsi,QWORD PTR [r13+0x0]
   29fb8:	41 83 f8 f6          	cmp    r8d,0xfffffff6
   29fbc:	76 11                	jbe    29fcf <JS_CallInternal+0x74cf>
   29fbe:	8b 7e fc             	mov    edi,DWORD PTR [rsi-0x4]
   29fc1:	8d 57 ff             	lea    edx,[rdi-0x1]
   29fc4:	89 56 fc             	mov    DWORD PTR [rsi-0x4],edx
   29fc7:	85 d2                	test   edx,edx
   29fc9:	0f 8e c2 20 00 00    	jle    2c091 <JS_CallInternal+0x9591>
   29fcf:	49 c7 45 00 00 00 00 	mov    QWORD PTR [r13+0x0],0x0
   29fd6:	00 
   29fd7:	49 c7 45 08 03 00 00 	mov    QWORD PTR [r13+0x8],0x3
   29fde:	00 
   29fdf:	85 c9                	test   ecx,ecx
   29fe1:	0f 88 d9 2a 00 00    	js     2cac0 <JS_CallInternal+0x9fc0>
   29fe7:	41 83 f9 f6          	cmp    r9d,0xfffffff6
   29feb:	76 11                	jbe    29ffe <JS_CallInternal+0x74fe>
   29fed:	8b 48 fc             	mov    ecx,DWORD PTR [rax-0x4]
   29ff0:	8d 51 ff             	lea    edx,[rcx-0x1]
   29ff3:	89 50 fc             	mov    DWORD PTR [rax-0x4],edx
   29ff6:	85 d2                	test   edx,edx
   29ff8:	0f 8e 0f 1f 00 00    	jle    2bf0d <JS_CallInternal+0x940d>
   29ffe:	44 8b 85 f0 fe ff ff 	mov    r8d,DWORD PTR [rbp-0x110]
   2a005:	31 d2                	xor    edx,edx
   2a007:	be 03 00 00 00       	mov    esi,0x3
   2a00c:	45 85 c0             	test   r8d,r8d
   2a00f:	0f 95 c2             	setne  dl
   2a012:	31 ff                	xor    edi,edi
   2a014:	e9 97 e4 ff ff       	jmp    284b0 <JS_CallInternal+0x59b0>
   2a019:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2a020:	48 8b 7f 10          	mov    rdi,QWORD PTR [rdi+0x10]
   2a024:	48 8b 97 48 04 00 00 	mov    rdx,QWORD PTR [rdi+0x448]
   2a02b:	4a 8b 34 ea          	mov    rsi,QWORD PTR [rdx+r13*8]
   2a02f:	8b 56 fc             	mov    edx,DWORD PTR [rsi-0x4]
   2a032:	83 ea 01             	sub    edx,0x1
   2a035:	89 56 fc             	mov    DWORD PTR [rsi-0x4],edx
   2a038:	85 d2                	test   edx,edx
   2a03a:	0f 8f 5c e0 ff ff    	jg     2809c <JS_CallInternal+0x559c>
   2a040:	48 89 8d 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],rcx
   2a047:	4c 89 b5 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],r14
   2a04e:	e8 ad b3 fe ff       	call   15400 <JS_FreeAtomStruct>
   2a053:	48 8b 8d 40 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x1c0]
   2a05a:	48 8b 85 50 fe ff ff 	mov    rax,QWORD PTR [rbp-0x1b0]
   2a061:	e9 36 e0 ff ff       	jmp    2809c <JS_CallInternal+0x559c>
   2a066:	48 89 fe             	mov    rsi,rdi
   2a069:	48 8b 95 c8 fe ff ff 	mov    rdx,QWORD PTR [rbp-0x138]
   2a070:	48 8b bd c0 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x140]
   2a077:	48 89 85 d0 fe ff ff 	mov    QWORD PTR [rbp-0x130],rax
   2a07e:	48 89 8d e0 fe ff ff 	mov    QWORD PTR [rbp-0x120],rcx
   2a085:	e8 76 63 ff ff       	call   20400 <close_var_refs>
   2a08a:	48 8b 85 d0 fe ff ff 	mov    rax,QWORD PTR [rbp-0x130]
   2a091:	48 8b 8d e0 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x120]
   2a098:	e9 68 91 ff ff       	jmp    23205 <JS_CallInternal+0x705>
   2a09d:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a0a4:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a0a8:	48 8b 87 48 04 00 00 	mov    rax,QWORD PTR [rdi+0x448]
   2a0af:	4a 8b 34 e8          	mov    rsi,QWORD PTR [rax+r13*8]
   2a0b3:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   2a0b6:	83 e8 01             	sub    eax,0x1
   2a0b9:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   2a0bc:	85 c0                	test   eax,eax
   2a0be:	0f 8f 50 d5 ff ff    	jg     27614 <JS_CallInternal+0x4b14>
   2a0c4:	e8 37 b3 fe ff       	call   15400 <JS_FreeAtomStruct>
   2a0c9:	e9 46 d5 ff ff       	jmp    27614 <JS_CallInternal+0x4b14>
   2a0ce:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   2a0d5:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2a0dc:	31 d2                	xor    edx,edx
   2a0de:	48 89 de             	mov    rsi,rbx
   2a0e1:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   2a0e5:	e8 86 12 03 00       	call   5b370 <js_eq_slow>
   2a0ea:	85 c0                	test   eax,eax
   2a0ec:	0f 84 92 c8 ff ff    	je     26984 <JS_CallInternal+0x3e84>
   2a0f2:	e9 a9 91 ff ff       	jmp    232a0 <JS_CallInternal+0x7a0>
   2a0f7:	66 0f 1f 84 00 00 00 	nop    WORD PTR [rax+rax*1+0x0]
   2a0fe:	00 00 
   2a100:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   2a107:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2a10e:	ba 01 00 00 00       	mov    edx,0x1
   2a113:	48 89 de             	mov    rsi,rbx
   2a116:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   2a11a:	e8 51 12 03 00       	call   5b370 <js_eq_slow>
   2a11f:	85 c0                	test   eax,eax
   2a121:	0f 84 03 c8 ff ff    	je     2692a <JS_CallInternal+0x3e2a>
   2a127:	e9 74 91 ff ff       	jmp    232a0 <JS_CallInternal+0x7a0>
   2a12c:	0f 1f 40 00          	nop    DWORD PTR [rax+0x0]
   2a130:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2a137:	48 8d 35 e8 33 0a 00 	lea    rsi,[rip+0xa33e8]        # cd526 <_IO_stdin_used+0x526>
   2a13e:	31 c0                	xor    eax,eax
   2a140:	e8 0b 6b 00 00       	call   30c50 <JS_ThrowTypeError>
   2a145:	83 fb f6             	cmp    ebx,0xfffffff6
   2a148:	76 1e                	jbe    2a168 <JS_CallInternal+0x7668>
   2a14a:	48 8b 8d 50 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x1b0]
   2a151:	8b 41 fc             	mov    eax,DWORD PTR [rcx-0x4]
   2a154:	89 85 28 fe ff ff    	mov    DWORD PTR [rbp-0x1d8],eax
   2a15a:	83 e8 01             	sub    eax,0x1
   2a15d:	89 41 fc             	mov    DWORD PTR [rcx-0x4],eax
   2a160:	85 c0                	test   eax,eax
   2a162:	0f 8e 94 24 00 00    	jle    2c5fc <JS_CallInternal+0x9afc>
   2a168:	83 bd 38 fe ff ff f6 	cmp    DWORD PTR [rbp-0x1c8],0xfffffff6
   2a16f:	76 1e                	jbe    2a18f <JS_CallInternal+0x768f>
   2a171:	48 8b 8d 40 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x1c0]
   2a178:	8b 41 fc             	mov    eax,DWORD PTR [rcx-0x4]
   2a17b:	89 85 50 fe ff ff    	mov    DWORD PTR [rbp-0x1b0],eax
   2a181:	83 e8 01             	sub    eax,0x1
   2a184:	89 41 fc             	mov    DWORD PTR [rcx-0x4],eax
   2a187:	85 c0                	test   eax,eax
   2a189:	0f 8e d9 24 00 00    	jle    2c668 <JS_CallInternal+0x9b68>
   2a18f:	ba 06 00 00 00       	mov    edx,0x6
   2a194:	31 c0                	xor    eax,eax
   2a196:	e9 1d a0 ff ff       	jmp    241b8 <JS_CallInternal+0x16b8>
   2a19b:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   2a1a2:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2a1a9:	44 89 ea             	mov    edx,r13d
   2a1ac:	48 89 de             	mov    rsi,rbx
   2a1af:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   2a1b3:	e8 e8 b4 02 00       	call   556a0 <js_unary_arith_slow>
   2a1b8:	85 c0                	test   eax,eax
   2a1ba:	0f 84 e5 d1 ff ff    	je     273a5 <JS_CallInternal+0x48a5>
   2a1c0:	e9 db 90 ff ff       	jmp    232a0 <JS_CallInternal+0x7a0>
   2a1c5:	0f 1f 00             	nop    DWORD PTR [rax]
   2a1c8:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a1cf:	48 89 ca             	mov    rdx,rcx
   2a1d2:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a1d6:	e8 c5 26 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2a1db:	e9 a2 95 ff ff       	jmp    23782 <JS_CallInternal+0xc82>
   2a1e0:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a1e7:	89 8d 38 fe ff ff    	mov    DWORD PTR [rbp-0x1c8],ecx
   2a1ed:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a1f1:	e8 aa 26 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2a1f6:	8b 8d 38 fe ff ff    	mov    ecx,DWORD PTR [rbp-0x1c8]
   2a1fc:	e9 f8 97 ff ff       	jmp    239f9 <JS_CallInternal+0xef9>
   2a201:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a208:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a20c:	8b 85 50 fe ff ff    	mov    eax,DWORD PTR [rbp-0x1b0]
   2a212:	48 8b 97 48 04 00 00 	mov    rdx,QWORD PTR [rdi+0x448]
   2a219:	48 8b 34 c2          	mov    rsi,QWORD PTR [rdx+rax*8]
   2a21d:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   2a220:	83 e8 01             	sub    eax,0x1
   2a223:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   2a226:	85 c0                	test   eax,eax
   2a228:	0f 8f a0 ef ff ff    	jg     291ce <JS_CallInternal+0x66ce>
   2a22e:	89 8d 50 fe ff ff    	mov    DWORD PTR [rbp-0x1b0],ecx
   2a234:	e8 c7 b1 fe ff       	call   15400 <JS_FreeAtomStruct>
   2a239:	8b 8d 50 fe ff ff    	mov    ecx,DWORD PTR [rbp-0x1b0]
   2a23f:	e9 8a ef ff ff       	jmp    291ce <JS_CallInternal+0x66ce>
   2a244:	41 83 fe f6          	cmp    r14d,0xfffffff6
   2a248:	0f 87 8d 0c 00 00    	ja     2aedb <JS_CallInternal+0x83db>
   2a24e:	b8 01 00 00 00       	mov    eax,0x1
   2a253:	e9 07 d7 ff ff       	jmp    2795f <JS_CallInternal+0x4e5f>
   2a258:	0f 1f 84 00 00 00 00 	nop    DWORD PTR [rax+rax*1+0x0]
   2a25f:	00 
   2a260:	45 31 ed             	xor    r13d,r13d
   2a263:	e9 0f ec ff ff       	jmp    28e77 <JS_CallInternal+0x6377>
   2a268:	41 83 fe f6          	cmp    r14d,0xfffffff6
   2a26c:	76 0f                	jbe    2a27d <JS_CallInternal+0x777d>
   2a26e:	41 8b 45 fc          	mov    eax,DWORD PTR [r13-0x4]
   2a272:	83 e8 01             	sub    eax,0x1
   2a275:	41 89 45 fc          	mov    DWORD PTR [r13-0x4],eax
   2a279:	85 c0                	test   eax,eax
   2a27b:	7e 07                	jle    2a284 <JS_CallInternal+0x7784>
   2a27d:	31 c0                	xor    eax,eax
   2a27f:	e9 2f d7 ff ff       	jmp    279b3 <JS_CallInternal+0x4eb3>
   2a284:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a28b:	4c 89 ee             	mov    rsi,r13
   2a28e:	4c 89 f2             	mov    rdx,r14
   2a291:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a295:	e8 06 26 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2a29a:	31 c0                	xor    eax,eax
   2a29c:	e9 12 d7 ff ff       	jmp    279b3 <JS_CallInternal+0x4eb3>
   2a2a1:	b9 ff ff ff ff       	mov    ecx,0xffffffff
   2a2a6:	e9 2f 97 ff ff       	jmp    239da <JS_CallInternal+0xeda>
   2a2ab:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   2a2b2:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2a2b9:	44 89 ea             	mov    edx,r13d
   2a2bc:	48 89 de             	mov    rsi,rbx
   2a2bf:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   2a2c3:	e8 d8 b3 02 00       	call   556a0 <js_unary_arith_slow>
   2a2c8:	85 c0                	test   eax,eax
   2a2ca:	0f 84 bc cf ff ff    	je     2728c <JS_CallInternal+0x478c>
   2a2d0:	e9 cb 8f ff ff       	jmp    232a0 <JS_CallInternal+0x7a0>
   2a2d5:	0f 1f 00             	nop    DWORD PTR [rax]
   2a2d8:	48 8b 8d e8 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x118]
   2a2df:	89 c0                	mov    eax,eax
   2a2e1:	48 8b 79 10          	mov    rdi,QWORD PTR [rcx+0x10]
   2a2e5:	48 8b 8f 48 04 00 00 	mov    rcx,QWORD PTR [rdi+0x448]
   2a2ec:	48 8b 34 c1          	mov    rsi,QWORD PTR [rcx+rax*8]
   2a2f0:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   2a2f3:	83 e8 01             	sub    eax,0x1
   2a2f6:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   2a2f9:	85 c0                	test   eax,eax
   2a2fb:	0f 8f 8e ca ff ff    	jg     26d8f <JS_CallInternal+0x428f>
   2a301:	4c 89 8d 38 fe ff ff 	mov    QWORD PTR [rbp-0x1c8],r9
   2a308:	48 89 95 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],rdx
   2a30f:	e8 ec b0 fe ff       	call   15400 <JS_FreeAtomStruct>
   2a314:	4c 8b 8d 38 fe ff ff 	mov    r9,QWORD PTR [rbp-0x1c8]
   2a31b:	48 8b 95 40 fe ff ff 	mov    rdx,QWORD PTR [rbp-0x1c0]
   2a322:	e9 68 ca ff ff       	jmp    26d8f <JS_CallInternal+0x428f>
   2a327:	4c 8b a5 28 fe ff ff 	mov    r12,QWORD PTR [rbp-0x1d8]
   2a32e:	e9 6d 8f ff ff       	jmp    232a0 <JS_CallInternal+0x7a0>
   2a333:	48 8b bd d8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x128]
   2a33a:	48 8b 47 30          	mov    rax,QWORD PTR [rdi+0x30]
   2a33e:	48 01 c8             	add    rax,rcx
   2a341:	8b 48 04             	mov    ecx,DWORD PTR [rax+0x4]
   2a344:	f6 00 08             	test   BYTE PTR [rax],0x8
   2a347:	0f 85 8f 29 00 00    	jne    2ccdc <JS_CallInternal+0xa1dc>
   2a34d:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2a354:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   2a35b:	48 83 ec 08          	sub    rsp,0x8
   2a35f:	41 83 ed 37          	sub    r13d,0x37
   2a363:	4c 89 70 30          	mov    QWORD PTR [rax+0x30],r14
   2a367:	4c 8b 87 80 01 00 00 	mov    r8,QWORD PTR [rdi+0x180]
   2a36e:	4c 8b 8f 88 01 00 00 	mov    r9,QWORD PTR [rdi+0x188]
   2a375:	48 8b b7 80 01 00 00 	mov    rsi,QWORD PTR [rdi+0x180]
   2a37c:	48 8b 97 88 01 00 00 	mov    rdx,QWORD PTR [rdi+0x188]
   2a383:	41 55                	push   r13
   2a385:	e8 56 2a 00 00       	call   2cde0 <JS_GetPropertyInternal>
   2a38a:	48 89 53 08          	mov    QWORD PTR [rbx+0x8],rdx
   2a38e:	83 7b 08 06          	cmp    DWORD PTR [rbx+0x8],0x6
   2a392:	48 89 03             	mov    QWORD PTR [rbx],rax
   2a395:	41 5b                	pop    r11
   2a397:	41 5d                	pop    r13
   2a399:	0f 85 1f 98 ff ff    	jne    23bbe <JS_CallInternal+0x10be>
   2a39f:	4d 89 f4             	mov    r12,r14
   2a3a2:	e9 f9 8e ff ff       	jmp    232a0 <JS_CallInternal+0x7a0>
   2a3a7:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2a3ae:	48 8d 35 81 31 0a 00 	lea    rsi,[rip+0xa3181]        # cd536 <_IO_stdin_used+0x536>
   2a3b5:	31 c0                	xor    eax,eax
   2a3b7:	e8 74 8c 00 00       	call   33030 <JS_ThrowInternalError>
   2a3bc:	e9 df 8e ff ff       	jmp    232a0 <JS_CallInternal+0x7a0>
   2a3c1:	48 83 ec 08          	sub    rsp,0x8
   2a3c5:	48 8d 4b f0          	lea    rcx,[rbx-0x10]
   2a3c9:	41 b9 01 00 00 00    	mov    r9d,0x1
   2a3cf:	51                   	push   rcx
   2a3d0:	e9 0a f4 ff ff       	jmp    297df <JS_CallInternal+0x6cdf>
   2a3d5:	ba 03 00 00 00       	mov    edx,0x3
   2a3da:	31 c0                	xor    eax,eax
   2a3dc:	e9 33 9c ff ff       	jmp    24014 <JS_CallInternal+0x1514>
   2a3e1:	48 89 c6             	mov    rsi,rax
   2a3e4:	8b 40 ac             	mov    eax,DWORD PTR [rax-0x54]
   2a3e7:	89 85 50 fe ff ff    	mov    DWORD PTR [rbp-0x1b0],eax
   2a3ed:	83 e8 01             	sub    eax,0x1
   2a3f0:	89 46 ac             	mov    DWORD PTR [rsi-0x54],eax
   2a3f3:	0f 85 33 d8 ff ff    	jne    27c2c <JS_CallInternal+0x512c>
   2a3f9:	80 bf a0 04 00 00 02 	cmp    BYTE PTR [rdi+0x4a0],0x2
   2a400:	0f 84 26 d8 ff ff    	je     27c2c <JS_CallInternal+0x512c>
   2a406:	48 83 ee 50          	sub    rsi,0x50
   2a40a:	e8 31 5f ff ff       	call   20340 <async_func_free.part.0>
   2a40f:	48 8b b5 c8 fe ff ff 	mov    rsi,QWORD PTR [rbp-0x138]
   2a416:	48 8b 4e 28          	mov    rcx,QWORD PTR [rsi+0x28]
   2a41a:	4c 01 e9             	add    rcx,r13
   2a41d:	e9 0a d8 ff ff       	jmp    27c2c <JS_CallInternal+0x512c>
   2a422:	4c 8d 5b f0          	lea    r11,[rbx-0x10]
   2a426:	41 b8 03 00 00 00    	mov    r8d,0x3
   2a42c:	45 31 ed             	xor    r13d,r13d
   2a42f:	e9 b7 9c ff ff       	jmp    240eb <JS_CallInternal+0x15eb>
   2a434:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2a43b:	0f b6 d0             	movzx  edx,al
   2a43e:	31 c0                	xor    eax,eax
   2a440:	48 8d 35 c5 30 0a 00 	lea    rsi,[rip+0xa30c5]        # cd50c <_IO_stdin_used+0x50c>
   2a447:	e8 e4 8b 00 00       	call   33030 <JS_ThrowInternalError>
   2a44c:	e9 4f 8e ff ff       	jmp    232a0 <JS_CallInternal+0x7a0>
   2a451:	4d 89 ec             	mov    r12,r13
   2a454:	e9 47 8e ff ff       	jmp    232a0 <JS_CallInternal+0x7a0>
   2a459:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a460:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a464:	e8 37 24 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2a469:	e9 15 c7 ff ff       	jmp    26b83 <JS_CallInternal+0x4083>
   2a46e:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a475:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a479:	e8 22 24 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2a47e:	e9 9b ec ff ff       	jmp    2911e <JS_CallInternal+0x661e>
   2a483:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a48a:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a48e:	e8 0d 24 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2a493:	e9 08 c7 ff ff       	jmp    26ba0 <JS_CallInternal+0x40a0>
   2a498:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a49f:	48 89 8d 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],rcx
   2a4a6:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a4aa:	e8 f1 23 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2a4af:	48 8b 8d 50 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x1b0]
   2a4b6:	e9 88 cf ff ff       	jmp    27443 <JS_CallInternal+0x4943>
   2a4bb:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a4c2:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a4c6:	e8 d5 23 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2a4cb:	e9 b4 cf ff ff       	jmp    27484 <JS_CallInternal+0x4984>
   2a4d0:	48 89 85 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],rax
   2a4d7:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a4de:	4c 89 85 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],r8
   2a4e5:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a4e9:	e8 b2 23 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2a4ee:	4c 8b 85 40 fe ff ff 	mov    r8,QWORD PTR [rbp-0x1c0]
   2a4f5:	48 8b 85 50 fe ff ff 	mov    rax,QWORD PTR [rbp-0x1b0]
   2a4fc:	e9 08 e8 ff ff       	jmp    28d09 <JS_CallInternal+0x6209>
   2a501:	88 85 40 fe ff ff    	mov    BYTE PTR [rbp-0x1c0],al
   2a507:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a50e:	4c 89 ce             	mov    rsi,r9
   2a511:	4c 89 ea             	mov    rdx,r13
   2a514:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a518:	e8 83 23 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2a51d:	0f b6 85 40 fe ff ff 	movzx  eax,BYTE PTR [rbp-0x1c0]
   2a524:	e9 85 c8 ff ff       	jmp    26dae <JS_CallInternal+0x42ae>
   2a529:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a530:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a534:	e8 67 23 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2a539:	e9 39 a8 ff ff       	jmp    24d77 <JS_CallInternal+0x2277>
   2a53e:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a545:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a549:	e8 52 23 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2a54e:	e9 1a b2 ff ff       	jmp    2576d <JS_CallInternal+0x2c6d>
   2a553:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a55a:	48 89 ca             	mov    rdx,rcx
   2a55d:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a561:	e8 3a 23 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2a566:	e9 65 b3 ff ff       	jmp    258d0 <JS_CallInternal+0x2dd0>
   2a56b:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a572:	48 89 ca             	mov    rdx,rcx
   2a575:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a579:	e8 22 23 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2a57e:	e9 a1 b3 ff ff       	jmp    25924 <JS_CallInternal+0x2e24>
   2a583:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a58a:	48 89 ca             	mov    rdx,rcx
   2a58d:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a591:	e8 0a 23 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2a596:	e9 dd b3 ff ff       	jmp    25978 <JS_CallInternal+0x2e78>
   2a59b:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a5a2:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a5a6:	e8 f5 22 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2a5ab:	e9 9f ac ff ff       	jmp    2524f <JS_CallInternal+0x274f>
   2a5b0:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a5b7:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a5bb:	e8 e0 22 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2a5c0:	e9 3f ac ff ff       	jmp    25204 <JS_CallInternal+0x2704>
   2a5c5:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a5cc:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a5d0:	e8 cb 22 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2a5d5:	e9 ba ac ff ff       	jmp    25294 <JS_CallInternal+0x2794>
   2a5da:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a5e1:	4c 89 c2             	mov    rdx,r8
   2a5e4:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a5e8:	e8 b3 22 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2a5ed:	e9 5e b7 ff ff       	jmp    25d50 <JS_CallInternal+0x3250>
   2a5f2:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a5f9:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a5fd:	e8 9e 22 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2a602:	e9 e5 b7 ff ff       	jmp    25dec <JS_CallInternal+0x32ec>
   2a607:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a60e:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a612:	e8 89 22 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2a617:	e9 82 b7 ff ff       	jmp    25d9e <JS_CallInternal+0x329e>
   2a61c:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a623:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a627:	e8 74 22 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2a62c:	e9 09 b8 ff ff       	jmp    25e3a <JS_CallInternal+0x333a>
   2a631:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a638:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a63c:	e8 5f 22 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2a641:	e9 7d a6 ff ff       	jmp    24cc3 <JS_CallInternal+0x21c3>
   2a646:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a64d:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a651:	e8 4a 22 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2a656:	e9 1e a5 ff ff       	jmp    24b79 <JS_CallInternal+0x2079>
   2a65b:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a662:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a666:	e8 35 22 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2a66b:	e9 2f b5 ff ff       	jmp    25b9f <JS_CallInternal+0x309f>
   2a670:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a677:	4c 89 c2             	mov    rdx,r8
   2a67a:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a67e:	e8 1d 22 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2a683:	e9 b8 b5 ff ff       	jmp    25c40 <JS_CallInternal+0x3140>
   2a688:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a68f:	4c 89 c2             	mov    rdx,r8
   2a692:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a696:	e8 05 22 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2a69b:	e9 fb b5 ff ff       	jmp    25c9b <JS_CallInternal+0x319b>
   2a6a0:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a6a7:	4c 89 c2             	mov    rdx,r8
   2a6aa:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a6ae:	e8 ed 21 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2a6b3:	e9 3e b6 ff ff       	jmp    25cf6 <JS_CallInternal+0x31f6>
   2a6b8:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a6bf:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a6c3:	e8 d8 21 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2a6c8:	e9 8a b4 ff ff       	jmp    25b57 <JS_CallInternal+0x3057>
   2a6cd:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a6d4:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a6d8:	e8 c3 21 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2a6dd:	e9 76 b3 ff ff       	jmp    25a58 <JS_CallInternal+0x2f58>
   2a6e2:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a6e9:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a6ed:	e8 ae 21 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2a6f2:	e9 19 b3 ff ff       	jmp    25a10 <JS_CallInternal+0x2f10>
   2a6f7:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a6fe:	48 89 ca             	mov    rdx,rcx
   2a701:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a705:	e8 96 21 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2a70a:	e9 bb b2 ff ff       	jmp    259ca <JS_CallInternal+0x2eca>
   2a70f:	88 85 40 fe ff ff    	mov    BYTE PTR [rbp-0x1c0],al
   2a715:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a71c:	48 89 ce             	mov    rsi,rcx
   2a71f:	4c 89 f2             	mov    rdx,r14
   2a722:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a726:	e8 75 21 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2a72b:	0f b6 85 40 fe ff ff 	movzx  eax,BYTE PTR [rbp-0x1c0]
   2a732:	e9 9b c6 ff ff       	jmp    26dd2 <JS_CallInternal+0x42d2>
   2a737:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a73e:	4c 89 c6             	mov    rsi,r8
   2a741:	48 89 ca             	mov    rdx,rcx
   2a744:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a748:	e8 53 21 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2a74d:	e9 4f df ff ff       	jmp    286a1 <JS_CallInternal+0x5ba1>
   2a752:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a759:	48 89 ca             	mov    rdx,rcx
   2a75c:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a760:	e8 3b 21 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2a765:	e9 2b e3 ff ff       	jmp    28a95 <JS_CallInternal+0x5f95>
   2a76a:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a771:	48 89 8d 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],rcx
   2a778:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a77c:	e8 1f 21 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2a781:	48 8b 8d 50 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x1b0]
   2a788:	e9 c2 e4 ff ff       	jmp    28c4f <JS_CallInternal+0x614f>
   2a78d:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a794:	4c 89 c2             	mov    rdx,r8
   2a797:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a79b:	e8 00 21 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2a7a0:	e9 f7 9d ff ff       	jmp    2459c <JS_CallInternal+0x1a9c>
   2a7a5:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a7ac:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a7b0:	e8 eb 20 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2a7b5:	e9 31 9e ff ff       	jmp    245eb <JS_CallInternal+0x1aeb>
   2a7ba:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a7c1:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a7c5:	e8 d6 20 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2a7ca:	e9 06 a2 ff ff       	jmp    249d5 <JS_CallInternal+0x1ed5>
   2a7cf:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a7d6:	4c 89 c2             	mov    rdx,r8
   2a7d9:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a7dd:	e8 be 20 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2a7e2:	e9 40 a3 ff ff       	jmp    24b27 <JS_CallInternal+0x2027>
   2a7e7:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a7ee:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a7f2:	e8 a9 20 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2a7f7:	e9 4b a1 ff ff       	jmp    24947 <JS_CallInternal+0x1e47>
   2a7fc:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a803:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a807:	e8 94 20 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2a80c:	e9 7e a1 ff ff       	jmp    2498f <JS_CallInternal+0x1e8f>
   2a811:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a818:	48 89 ca             	mov    rdx,rcx
   2a81b:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a81f:	e8 7c 20 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2a824:	e9 94 9f ff ff       	jmp    247bd <JS_CallInternal+0x1cbd>
   2a829:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a830:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a834:	e8 67 20 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2a839:	e9 a5 9e ff ff       	jmp    246e3 <JS_CallInternal+0x1be3>
   2a83e:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a845:	4c 89 c2             	mov    rdx,r8
   2a848:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a84c:	e8 4f 20 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2a851:	e9 3e 9e ff ff       	jmp    24694 <JS_CallInternal+0x1b94>
   2a856:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a85d:	48 89 ca             	mov    rdx,rcx
   2a860:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a864:	e8 37 20 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2a869:	e9 49 a0 ff ff       	jmp    248b7 <JS_CallInternal+0x1db7>
   2a86e:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a875:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a879:	e8 22 20 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2a87e:	e9 7c a0 ff ff       	jmp    248ff <JS_CallInternal+0x1dff>
   2a883:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a88a:	48 89 ca             	mov    rdx,rcx
   2a88d:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a891:	e8 0a 20 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2a896:	e9 76 9f ff ff       	jmp    24811 <JS_CallInternal+0x1d11>
   2a89b:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a8a2:	48 89 ca             	mov    rdx,rcx
   2a8a5:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a8a9:	e8 f2 1f ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2a8ae:	e9 b2 9f ff ff       	jmp    24865 <JS_CallInternal+0x1d65>
   2a8b3:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a8ba:	4c 89 85 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],r8
   2a8c1:	4c 89 8d 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],r9
   2a8c8:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a8cc:	e8 cf 1f ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2a8d1:	4c 8b 85 40 fe ff ff 	mov    r8,QWORD PTR [rbp-0x1c0]
   2a8d8:	4c 8b 8d 50 fe ff ff 	mov    r9,QWORD PTR [rbp-0x1b0]
   2a8df:	e9 df 95 ff ff       	jmp    23ec3 <JS_CallInternal+0x13c3>
   2a8e4:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a8eb:	4c 89 85 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],r8
   2a8f2:	4c 89 8d 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],r9
   2a8f9:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a8fd:	e8 9e 1f ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2a902:	4c 8b 85 40 fe ff ff 	mov    r8,QWORD PTR [rbp-0x1c0]
   2a909:	4c 8b 8d 50 fe ff ff 	mov    r9,QWORD PTR [rbp-0x1b0]
   2a910:	e9 73 95 ff ff       	jmp    23e88 <JS_CallInternal+0x1388>
   2a915:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a91c:	4c 89 85 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],r8
   2a923:	4c 89 8d 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],r9
   2a92a:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a92e:	e8 6d 1f ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2a933:	4c 8b 85 40 fe ff ff 	mov    r8,QWORD PTR [rbp-0x1c0]
   2a93a:	4c 8b 8d 50 fe ff ff 	mov    r9,QWORD PTR [rbp-0x1b0]
   2a941:	e9 5f 95 ff ff       	jmp    23ea5 <JS_CallInternal+0x13a5>
   2a946:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a94d:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a951:	e8 4a 1f ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2a956:	e9 14 df ff ff       	jmp    2886f <JS_CallInternal+0x5d6f>
   2a95b:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a962:	48 89 8d 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],rcx
   2a969:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a96d:	e8 2e 1f ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2a972:	48 8b 8d 50 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x1b0]
   2a979:	e9 7b 94 ff ff       	jmp    23df9 <JS_CallInternal+0x12f9>
   2a97e:	48 89 85 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],rax
   2a985:	4c 89 f6             	mov    rsi,r14
   2a988:	4c 89 ea             	mov    rdx,r13
   2a98b:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a992:	48 89 8d 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],rcx
   2a999:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a99d:	e8 fe 1e ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2a9a2:	48 8b 8d 40 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x1c0]
   2a9a9:	48 8b 85 50 fe ff ff 	mov    rax,QWORD PTR [rbp-0x1b0]
   2a9b0:	e9 a3 ba ff ff       	jmp    26458 <JS_CallInternal+0x3958>
   2a9b5:	48 8b 7f 10          	mov    rdi,QWORD PTR [rdi+0x10]
   2a9b9:	4c 89 c2             	mov    rdx,r8
   2a9bc:	e8 df 1e ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2a9c1:	e9 57 cb ff ff       	jmp    2751d <JS_CallInternal+0x4a1d>
   2a9c6:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a9cd:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a9d1:	e8 ca 1e ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2a9d6:	e9 0f de ff ff       	jmp    287ea <JS_CallInternal+0x5cea>
   2a9db:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a9e2:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2a9e6:	e8 b5 1e ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2a9eb:	e9 17 de ff ff       	jmp    28807 <JS_CallInternal+0x5d07>
   2a9f0:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2a9f7:	4c 89 f2             	mov    rdx,r14
   2a9fa:	48 89 8d 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],rcx
   2aa01:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2aa05:	e8 96 1e ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2aa0a:	48 8b 8d 50 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x1b0]
   2aa11:	e9 90 c2 ff ff       	jmp    26ca6 <JS_CallInternal+0x41a6>
   2aa16:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2aa1d:	4c 89 95 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],r10
   2aa24:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2aa28:	e8 73 1e ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2aa2d:	4c 8b 95 40 fe ff ff 	mov    r10,QWORD PTR [rbp-0x1c0]
   2aa34:	e9 94 dd ff ff       	jmp    287cd <JS_CallInternal+0x5ccd>
   2aa39:	4c 8b a5 10 fe ff ff 	mov    r12,QWORD PTR [rbp-0x1f0]
   2aa40:	e9 5b 88 ff ff       	jmp    232a0 <JS_CallInternal+0x7a0>
   2aa45:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2aa4c:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2aa50:	e8 4b 1e ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2aa55:	e9 a0 e6 ff ff       	jmp    290fa <JS_CallInternal+0x65fa>
   2aa5a:	48 89 85 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],rax
   2aa61:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2aa68:	44 89 85 38 fe ff ff 	mov    DWORD PTR [rbp-0x1c8],r8d
   2aa6f:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2aa73:	48 89 8d 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],rcx
   2aa7a:	e8 21 1e ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2aa7f:	44 8b 85 38 fe ff ff 	mov    r8d,DWORD PTR [rbp-0x1c8]
   2aa86:	48 8b 85 40 fe ff ff 	mov    rax,QWORD PTR [rbp-0x1c0]
   2aa8d:	48 8b 8d 50 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x1b0]
   2aa94:	e9 d0 d8 ff ff       	jmp    28369 <JS_CallInternal+0x5869>
   2aa99:	48 89 85 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],rax
   2aaa0:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2aaa7:	4c 89 85 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],r8
   2aaae:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2aab2:	e8 e9 1d ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2aab7:	4c 8b 85 40 fe ff ff 	mov    r8,QWORD PTR [rbp-0x1c0]
   2aabe:	48 8b 85 50 fe ff ff 	mov    rax,QWORD PTR [rbp-0x1b0]
   2aac5:	e9 a4 92 ff ff       	jmp    23d6e <JS_CallInternal+0x126e>
   2aaca:	48 89 85 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],rax
   2aad1:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2aad8:	4c 89 85 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],r8
   2aadf:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2aae3:	e8 b8 1d ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2aae8:	4c 8b 85 40 fe ff ff 	mov    r8,QWORD PTR [rbp-0x1c0]
   2aaef:	48 8b 85 50 fe ff ff 	mov    rax,QWORD PTR [rbp-0x1b0]
   2aaf6:	e9 90 92 ff ff       	jmp    23d8b <JS_CallInternal+0x128b>
   2aafb:	48 89 85 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],rax
   2ab02:	4c 89 ee             	mov    rsi,r13
   2ab05:	4c 89 f2             	mov    rdx,r14
   2ab08:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2ab0f:	48 89 8d 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],rcx
   2ab16:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2ab1a:	e8 81 1d ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2ab1f:	48 8b 85 40 fe ff ff 	mov    rax,QWORD PTR [rbp-0x1c0]
   2ab26:	48 8b 8d 50 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x1b0]
   2ab2d:	e9 e1 ab ff ff       	jmp    25713 <JS_CallInternal+0x2c13>
   2ab32:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   2ab39:	8b 4e 04             	mov    ecx,DWORD PTR [rsi+0x4]
   2ab3c:	48 89 b5 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],rsi
   2ab43:	4c 8b ad e8 fe ff ff 	mov    r13,QWORD PTR [rbp-0x118]
   2ab4a:	4c 89 70 30          	mov    QWORD PTR [rax+0x30],r14
   2ab4e:	49 8b b5 80 01 00 00 	mov    rsi,QWORD PTR [r13+0x180]
   2ab55:	49 8b 95 88 01 00 00 	mov    rdx,QWORD PTR [r13+0x188]
   2ab5c:	4c 89 ef             	mov    rdi,r13
   2ab5f:	e8 2c 37 04 00       	call   6e290 <JS_HasProperty>
   2ab64:	85 c0                	test   eax,eax
   2ab66:	0f 88 7d 20 00 00    	js     2cbe9 <JS_CallInternal+0xa0e9>
   2ab6c:	4c 8b 95 50 fe ff ff 	mov    r10,QWORD PTR [rbp-0x1b0]
   2ab73:	0f 85 00 03 00 00    	jne    2ae79 <JS_CallInternal+0x8379>
   2ab79:	49 8b 45 10          	mov    rax,QWORD PTR [r13+0x10]
   2ab7d:	4c 89 ef             	mov    rdi,r13
   2ab80:	48 8b 80 f0 04 00 00 	mov    rax,QWORD PTR [rax+0x4f0]
   2ab87:	48 85 c0             	test   rax,rax
   2ab8a:	0f 84 e9 02 00 00    	je     2ae79 <JS_CallInternal+0x8379>
   2ab90:	f6 40 3c 01          	test   BYTE PTR [rax+0x3c],0x1
   2ab94:	0f 84 df 02 00 00    	je     2ae79 <JS_CallInternal+0x8379>
   2ab9a:	41 8b 72 04          	mov    esi,DWORD PTR [r10+0x4]
   2ab9e:	4d 89 f4             	mov    r12,r14
   2aba1:	e8 ca 82 00 00       	call   32e70 <JS_ThrowReferenceErrorNotDefined>
   2aba6:	e9 f5 86 ff ff       	jmp    232a0 <JS_CallInternal+0x7a0>
   2abab:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2abb2:	48 89 ca             	mov    rdx,rcx
   2abb5:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2abb9:	e8 e2 1c ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2abbe:	e9 d6 b2 ff ff       	jmp    25e99 <JS_CallInternal+0x3399>
   2abc3:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2abca:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2abce:	e8 cd 1c ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2abd3:	e9 6d b3 ff ff       	jmp    25f45 <JS_CallInternal+0x3445>
   2abd8:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2abdf:	4c 89 ee             	mov    rsi,r13
   2abe2:	4c 89 f2             	mov    rdx,r14
   2abe5:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2abe9:	e8 b2 1c ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2abee:	e9 ff c5 ff ff       	jmp    271f2 <JS_CallInternal+0x46f2>
   2abf3:	48 89 85 38 fe ff ff 	mov    QWORD PTR [rbp-0x1c8],rax
   2abfa:	4c 89 ee             	mov    rsi,r13
   2abfd:	4c 89 ca             	mov    rdx,r9
   2ac00:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2ac07:	44 89 85 28 fe ff ff 	mov    DWORD PTR [rbp-0x1d8],r8d
   2ac0e:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2ac12:	48 89 8d 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],rcx
   2ac19:	e8 82 1c ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2ac1e:	44 8b 85 28 fe ff ff 	mov    r8d,DWORD PTR [rbp-0x1d8]
   2ac25:	48 8b 85 38 fe ff ff 	mov    rax,QWORD PTR [rbp-0x1c8]
   2ac2c:	48 8b 8d 40 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x1c0]
   2ac33:	e9 0d d7 ff ff       	jmp    28345 <JS_CallInternal+0x5845>
   2ac38:	48 83 ec 08          	sub    rsp,0x8
   2ac3c:	8b 8d 38 fe ff ff    	mov    ecx,DWORD PTR [rbp-0x1c8]
   2ac42:	4c 89 ee             	mov    rsi,r13
   2ac45:	4c 89 e2             	mov    rdx,r12
   2ac48:	4c 8b 85 50 fe ff ff 	mov    r8,QWORD PTR [rbp-0x1b0]
   2ac4f:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2ac56:	6a 00                	push   0x0
   2ac58:	4c 8b 8d 58 fe ff ff 	mov    r9,QWORD PTR [rbp-0x1a8]
   2ac5f:	e8 7c 21 00 00       	call   2cde0 <JS_GetPropertyInternal>
   2ac64:	5f                   	pop    rdi
   2ac65:	41 58                	pop    r8
   2ac67:	48 89 c1             	mov    rcx,rax
   2ac6a:	48 89 d0             	mov    rax,rdx
   2ac6d:	83 fa 06             	cmp    edx,0x6
   2ac70:	0f 85 e5 88 ff ff    	jne    2355b <JS_CallInternal+0xa5b>
   2ac76:	e9 8b 89 ff ff       	jmp    23606 <JS_CallInternal+0xb06>
   2ac7b:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2ac82:	4c 89 85 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],r8
   2ac89:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2ac8d:	e8 0e 1c ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2ac92:	4c 8b 85 50 fe ff ff 	mov    r8,QWORD PTR [rbp-0x1b0]
   2ac99:	e9 6a 94 ff ff       	jmp    24108 <JS_CallInternal+0x1608>
   2ac9e:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2aca5:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2aca9:	e8 f2 1b ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2acae:	e9 a1 b6 ff ff       	jmp    26354 <JS_CallInternal+0x3854>
   2acb3:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2acba:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2acbe:	e8 dd 1b ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2acc3:	e9 aa b6 ff ff       	jmp    26372 <JS_CallInternal+0x3872>
   2acc8:	4c 89 f3             	mov    rbx,r14
   2accb:	4d 89 ec             	mov    r12,r13
   2acce:	e9 cd 85 ff ff       	jmp    232a0 <JS_CallInternal+0x7a0>
   2acd3:	4d 89 d4             	mov    r12,r10
   2acd6:	e9 c5 85 ff ff       	jmp    232a0 <JS_CallInternal+0x7a0>
   2acdb:	4c 8b a5 28 fe ff ff 	mov    r12,QWORD PTR [rbp-0x1d8]
   2ace2:	e9 b9 85 ff ff       	jmp    232a0 <JS_CallInternal+0x7a0>
   2ace7:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2acee:	48 8d 35 d3 60 0a 00 	lea    rsi,[rip+0xa60d3]        # d0dc8 <_IO_stdin_used+0x3dc8>
   2acf5:	31 c0                	xor    eax,eax
   2acf7:	e8 54 5f 00 00       	call   30c50 <JS_ThrowTypeError>
   2acfc:	e9 9f 85 ff ff       	jmp    232a0 <JS_CallInternal+0x7a0>
   2ad01:	41 83 f9 08          	cmp    r9d,0x8
   2ad05:	0f 84 2d 1c 00 00    	je     2c938 <JS_CallInternal+0x9e38>
   2ad0b:	41 83 f9 ff          	cmp    r9d,0xffffffff
   2ad0f:	0f 84 d9 1b 00 00    	je     2c8ee <JS_CallInternal+0x9dee>
   2ad15:	41 8d 41 fe          	lea    eax,[r9-0x2]
   2ad19:	83 f8 01             	cmp    eax,0x1
   2ad1c:	0f 86 71 1d 00 00    	jbe    2ca93 <JS_CallInternal+0x9f93>
   2ad22:	41 83 f9 f9          	cmp    r9d,0xfffffff9
   2ad26:	0f 85 87 1b 00 00    	jne    2c8b3 <JS_CallInternal+0x9db3>
   2ad2c:	41 83 fe f9          	cmp    r14d,0xfffffff9
   2ad30:	0f 85 7d 1b 00 00    	jne    2c8b3 <JS_CallInternal+0x9db3>
   2ad36:	4c 89 ee             	mov    rsi,r13
   2ad39:	4c 89 8d 38 fe ff ff 	mov    QWORD PTR [rbp-0x1c8],r9
   2ad40:	48 89 95 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],rdx
   2ad47:	e8 c4 d0 fe ff       	call   17e10 <js_string_eq.isra.0>
   2ad4c:	48 8b b5 40 fe ff ff 	mov    rsi,QWORD PTR [rbp-0x1c0]
   2ad53:	4c 8b 8d 38 fe ff ff 	mov    r9,QWORD PTR [rbp-0x1c8]
   2ad5a:	89 85 50 fe ff ff    	mov    DWORD PTR [rbp-0x1b0],eax
   2ad60:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2ad67:	4c 89 ca             	mov    rdx,r9
   2ad6a:	e8 91 1c ff ff       	call   1ca00 <JS_FreeValue>
   2ad6f:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2ad76:	4c 89 ee             	mov    rsi,r13
   2ad79:	4c 89 f2             	mov    rdx,r14
   2ad7c:	e8 7f 1c ff ff       	call   1ca00 <JS_FreeValue>
   2ad81:	31 c0                	xor    eax,eax
   2ad83:	83 bd 50 fe ff ff 01 	cmp    DWORD PTR [rbp-0x1b0],0x1
   2ad8a:	0f 95 c0             	setne  al
   2ad8d:	e9 cd cb ff ff       	jmp    2795f <JS_CallInternal+0x4e5f>
   2ad92:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2ad99:	48 8d 35 00 60 0a 00 	lea    rsi,[rip+0xa6000]        # d0da0 <_IO_stdin_used+0x3da0>
   2ada0:	31 c0                	xor    eax,eax
   2ada2:	4d 89 ec             	mov    r12,r13
   2ada5:	e8 96 7f 00 00       	call   32d40 <JS_ThrowReferenceError>
   2adaa:	e9 f1 84 ff ff       	jmp    232a0 <JS_CallInternal+0x7a0>
   2adaf:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2adb6:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2adba:	e9 0b e3 ff ff       	jmp    290ca <JS_CallInternal+0x65ca>
   2adbf:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2adc6:	48 8d 35 85 27 0a 00 	lea    rsi,[rip+0xa2785]        # cd552 <_IO_stdin_used+0x552>
   2adcd:	31 c0                	xor    eax,eax
   2adcf:	e8 7c 5e 00 00       	call   30c50 <JS_ThrowTypeError>
   2add4:	4d 8b 4e 08          	mov    r9,QWORD PTR [r14+0x8]
   2add8:	4c 8b 6b f0          	mov    r13,QWORD PTR [rbx-0x10]
   2addc:	48 89 c1             	mov    rcx,rax
   2addf:	41 89 d0             	mov    r8d,edx
   2ade2:	48 89 d0             	mov    rax,rdx
   2ade5:	e9 42 d5 ff ff       	jmp    2832c <JS_CallInternal+0x582c>
   2adea:	4c 89 f3             	mov    rbx,r14
   2aded:	e9 ae 84 ff ff       	jmp    232a0 <JS_CallInternal+0x7a0>
   2adf2:	4c 89 f3             	mov    rbx,r14
   2adf5:	e9 a6 84 ff ff       	jmp    232a0 <JS_CallInternal+0x7a0>
   2adfa:	41 8b 4e 0c          	mov    ecx,DWORD PTR [r14+0xc]
   2adfe:	e9 77 e5 ff ff       	jmp    2937a <JS_CallInternal+0x687a>
   2ae03:	48 8b 85 d8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x128]
   2ae0a:	48 8d 15 89 26 0a 00 	lea    rdx,[rip+0xa2689]        # cd49a <_IO_stdin_used+0x49a>
   2ae11:	48 8b 40 30          	mov    rax,QWORD PTR [rax+0x30]
   2ae15:	8b 44 08 04          	mov    eax,DWORD PTR [rax+rcx*1+0x4]
   2ae19:	85 c0                	test   eax,eax
   2ae1b:	0f 85 32 16 00 00    	jne    2c453 <JS_CallInternal+0x9953>
   2ae21:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2ae28:	48 8d 35 c7 26 0a 00 	lea    rsi,[rip+0xa26c7]        # cd4f6 <_IO_stdin_used+0x4f6>
   2ae2f:	31 c0                	xor    eax,eax
   2ae31:	4d 89 ec             	mov    r12,r13
   2ae34:	e8 07 7f 00 00       	call   32d40 <JS_ThrowReferenceError>
   2ae39:	e9 62 84 ff ff       	jmp    232a0 <JS_CallInternal+0x7a0>
   2ae3e:	48 8b 85 d8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x128]
   2ae45:	48 8b 40 30          	mov    rax,QWORD PTR [rax+0x30]
   2ae49:	8b 44 10 04          	mov    eax,DWORD PTR [rax+rdx*1+0x4]
   2ae4d:	48 8d 15 46 26 0a 00 	lea    rdx,[rip+0xa2646]        # cd49a <_IO_stdin_used+0x49a>
   2ae54:	85 c0                	test   eax,eax
   2ae56:	0f 85 57 17 00 00    	jne    2c5b3 <JS_CallInternal+0x9ab3>
   2ae5c:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2ae63:	48 8d 35 8c 26 0a 00 	lea    rsi,[rip+0xa268c]        # cd4f6 <_IO_stdin_used+0x4f6>
   2ae6a:	31 c0                	xor    eax,eax
   2ae6c:	4d 89 ec             	mov    r12,r13
   2ae6f:	e8 cc 7e 00 00       	call   32d40 <JS_ThrowReferenceError>
   2ae74:	e9 27 84 ff ff       	jmp    232a0 <JS_CallInternal+0x7a0>
   2ae79:	48 83 ec 08          	sub    rsp,0x8
   2ae7d:	41 8b 4a 04          	mov    ecx,DWORD PTR [r10+0x4]
   2ae81:	4c 8b 43 f0          	mov    r8,QWORD PTR [rbx-0x10]
   2ae85:	48 83 eb 10          	sub    rbx,0x10
   2ae89:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2ae90:	4c 8b 4b 08          	mov    r9,QWORD PTR [rbx+0x8]
   2ae94:	48 8b b0 80 01 00 00 	mov    rsi,QWORD PTR [rax+0x180]
   2ae9b:	48 8b 90 88 01 00 00 	mov    rdx,QWORD PTR [rax+0x188]
   2aea2:	68 00 80 00 00       	push   0x8000
   2aea7:	48 89 c7             	mov    rdi,rax
   2aeaa:	ff b0 88 01 00 00    	push   QWORD PTR [rax+0x188]
   2aeb0:	ff b0 80 01 00 00    	push   QWORD PTR [rax+0x180]
   2aeb6:	e8 55 2c 00 00       	call   2db10 <JS_SetPropertyInternal>
   2aebb:	48 83 c4 20          	add    rsp,0x20
   2aebf:	85 c0                	test   eax,eax
   2aec1:	0f 89 bf 88 ff ff    	jns    23786 <JS_CallInternal+0xc86>
   2aec7:	4d 89 f4             	mov    r12,r14
   2aeca:	e9 d1 83 ff ff       	jmp    232a0 <JS_CallInternal+0x7a0>
   2aecf:	90                   	nop
   2aed0:	4c 89 f3             	mov    rbx,r14
   2aed3:	4d 89 ec             	mov    r12,r13
   2aed6:	e9 c5 83 ff ff       	jmp    232a0 <JS_CallInternal+0x7a0>
   2aedb:	41 8b 45 fc          	mov    eax,DWORD PTR [r13-0x4]
   2aedf:	83 e8 01             	sub    eax,0x1
   2aee2:	41 89 45 fc          	mov    DWORD PTR [r13-0x4],eax
   2aee6:	85 c0                	test   eax,eax
   2aee8:	0f 8f 60 f3 ff ff    	jg     2a24e <JS_CallInternal+0x774e>
   2aeee:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2aef5:	4c 89 ee             	mov    rsi,r13
   2aef8:	4c 89 f2             	mov    rdx,r14
   2aefb:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2aeff:	e8 9c 19 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2af04:	e9 45 f3 ff ff       	jmp    2a24e <JS_CallInternal+0x774e>
   2af09:	48 89 85 28 fe ff ff 	mov    QWORD PTR [rbp-0x1d8],rax
   2af10:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2af17:	4c 89 95 38 fe ff ff 	mov    QWORD PTR [rbp-0x1c8],r10
   2af1e:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2af22:	e8 79 19 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2af27:	48 8b 85 28 fe ff ff 	mov    rax,QWORD PTR [rbp-0x1d8]
   2af2e:	4c 8b 95 38 fe ff ff 	mov    r10,QWORD PTR [rbp-0x1c8]
   2af35:	e9 87 d0 ff ff       	jmp    27fc1 <JS_CallInternal+0x54c1>
   2af3a:	48 89 85 38 fe ff ff 	mov    QWORD PTR [rbp-0x1c8],rax
   2af41:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2af48:	4c 89 95 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],r10
   2af4f:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2af53:	e8 48 19 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2af58:	48 8b 85 38 fe ff ff 	mov    rax,QWORD PTR [rbp-0x1c8]
   2af5f:	4c 8b 95 50 fe ff ff 	mov    r10,QWORD PTR [rbp-0x1b0]
   2af66:	e9 7a d0 ff ff       	jmp    27fe5 <JS_CallInternal+0x54e5>
   2af6b:	48 89 85 28 fe ff ff 	mov    QWORD PTR [rbp-0x1d8],rax
   2af72:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2af79:	4c 89 95 38 fe ff ff 	mov    QWORD PTR [rbp-0x1c8],r10
   2af80:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2af84:	e8 17 19 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2af89:	48 8b 85 28 fe ff ff 	mov    rax,QWORD PTR [rbp-0x1d8]
   2af90:	4c 8b 95 38 fe ff ff 	mov    r10,QWORD PTR [rbp-0x1c8]
   2af97:	e9 08 d0 ff ff       	jmp    27fa4 <JS_CallInternal+0x54a4>
   2af9c:	0f 85 4d 1d 00 00    	jne    2ccef <JS_CallInternal+0xa1ef>
   2afa2:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2afa9:	48 8b 47 10          	mov    rax,QWORD PTR [rdi+0x10]
   2afad:	48 8b 80 f0 04 00 00 	mov    rax,QWORD PTR [rax+0x4f0]
   2afb4:	48 85 c0             	test   rax,rax
   2afb7:	0f 84 16 c6 ff ff    	je     275d3 <JS_CallInternal+0x4ad3>
   2afbd:	f6 40 3c 01          	test   BYTE PTR [rax+0x3c],0x1
   2afc1:	0f 84 0c c6 ff ff    	je     275d3 <JS_CallInternal+0x4ad3>
   2afc7:	44 89 ee             	mov    esi,r13d
   2afca:	e8 a1 7e 00 00       	call   32e70 <JS_ThrowReferenceErrorNotDefined>
   2afcf:	41 81 fd f2 00 00 00 	cmp    r13d,0xf2
   2afd6:	0f 8e c4 82 ff ff    	jle    232a0 <JS_CallInternal+0x7a0>
   2afdc:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2afe3:	44 89 ee             	mov    esi,r13d
   2afe6:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2afea:	e8 81 e4 fe ff       	call   19470 <JS_FreeAtom.part.0.isra.0>
   2afef:	e9 ac 82 ff ff       	jmp    232a0 <JS_CallInternal+0x7a0>
   2aff4:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2affb:	48 8b 40 10          	mov    rax,QWORD PTR [rax+0x10]
   2afff:	48 8b 80 f0 04 00 00 	mov    rax,QWORD PTR [rax+0x4f0]
   2b006:	48 85 c0             	test   rax,rax
   2b009:	0f 84 b1 0e 00 00    	je     2bec0 <JS_CallInternal+0x93c0>
   2b00f:	f6 40 3c 01          	test   BYTE PTR [rax+0x3c],0x1
   2b013:	0f 84 a7 0e 00 00    	je     2bec0 <JS_CallInternal+0x93c0>
   2b019:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2b020:	44 89 ee             	mov    esi,r13d
   2b023:	e8 48 7e 00 00       	call   32e70 <JS_ThrowReferenceErrorNotDefined>
   2b028:	41 81 fd f2 00 00 00 	cmp    r13d,0xf2
   2b02f:	0f 8e 6b 82 ff ff    	jle    232a0 <JS_CallInternal+0x7a0>
   2b035:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2b03c:	44 89 ee             	mov    esi,r13d
   2b03f:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2b043:	e8 28 e4 fe ff       	call   19470 <JS_FreeAtom.part.0.isra.0>
   2b048:	e9 53 82 ff ff       	jmp    232a0 <JS_CallInternal+0x7a0>
   2b04d:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   2b054:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2b05b:	44 89 ea             	mov    edx,r13d
   2b05e:	48 89 de             	mov    rsi,rbx
   2b061:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   2b065:	e8 e6 ae 02 00       	call   55f50 <js_binary_logic_slow>
   2b06a:	85 c0                	test   eax,eax
   2b06c:	0f 85 2e 82 ff ff    	jne    232a0 <JS_CallInternal+0x7a0>
   2b072:	48 83 eb 10          	sub    rbx,0x10
   2b076:	e9 99 b7 ff ff       	jmp    26814 <JS_CallInternal+0x3d14>
   2b07b:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2b082:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2b086:	e8 15 18 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2b08b:	e9 c5 c5 ff ff       	jmp    27655 <JS_CallInternal+0x4b55>
   2b090:	41 83 fd 08          	cmp    r13d,0x8
   2b094:	0f 84 b0 14 00 00    	je     2c54a <JS_CallInternal+0x9a4a>
   2b09a:	41 83 fd ff          	cmp    r13d,0xffffffff
   2b09e:	0f 84 75 14 00 00    	je     2c519 <JS_CallInternal+0x9a19>
   2b0a4:	41 8d 4d fe          	lea    ecx,[r13-0x2]
   2b0a8:	83 f9 01             	cmp    ecx,0x1
   2b0ab:	0f 86 27 14 00 00    	jbe    2c4d8 <JS_CallInternal+0x99d8>
   2b0b1:	4c 89 85 38 fe ff ff 	mov    QWORD PTR [rbp-0x1c8],r8
   2b0b8:	4c 89 8d 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],r9
   2b0bf:	41 83 fd f9          	cmp    r13d,0xfffffff9
   2b0c3:	0f 85 37 f0 ff ff    	jne    2a100 <JS_CallInternal+0x7600>
   2b0c9:	41 83 f8 f9          	cmp    r8d,0xfffffff9
   2b0cd:	0f 85 2d f0 ff ff    	jne    2a100 <JS_CallInternal+0x7600>
   2b0d3:	e8 38 cd fe ff       	call   17e10 <js_string_eq.isra.0>
   2b0d8:	4c 89 f6             	mov    rsi,r14
   2b0db:	4c 8b b5 e8 fe ff ff 	mov    r14,QWORD PTR [rbp-0x118]
   2b0e2:	4c 89 ea             	mov    rdx,r13
   2b0e5:	89 85 50 fe ff ff    	mov    DWORD PTR [rbp-0x1b0],eax
   2b0eb:	4c 89 f7             	mov    rdi,r14
   2b0ee:	e8 0d 19 ff ff       	call   1ca00 <JS_FreeValue>
   2b0f3:	48 8b b5 40 fe ff ff 	mov    rsi,QWORD PTR [rbp-0x1c0]
   2b0fa:	48 8b 95 38 fe ff ff 	mov    rdx,QWORD PTR [rbp-0x1c8]
   2b101:	4c 89 f7             	mov    rdi,r14
   2b104:	e8 f7 18 ff ff       	call   1ca00 <JS_FreeValue>
   2b109:	8b 85 50 fe ff ff    	mov    eax,DWORD PTR [rbp-0x1b0]
   2b10f:	e9 01 b8 ff ff       	jmp    26915 <JS_CallInternal+0x3e15>
   2b114:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2b11b:	e8 90 80 00 00       	call   331b0 <__js_poll_interrupts>
   2b120:	85 c0                	test   eax,eax
   2b122:	0f 84 dd c5 ff ff    	je     27705 <JS_CallInternal+0x4c05>
   2b128:	4d 89 ec             	mov    r12,r13
   2b12b:	e9 70 81 ff ff       	jmp    232a0 <JS_CallInternal+0x7a0>
   2b130:	ba 01 00 00 00       	mov    edx,0x1
   2b135:	be 03 00 00 00       	mov    esi,0x3
   2b13a:	31 ff                	xor    edi,edi
   2b13c:	e9 6f d3 ff ff       	jmp    284b0 <JS_CallInternal+0x59b0>
   2b141:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2b148:	48 8d 35 11 24 0a 00 	lea    rsi,[rip+0xa2411]        # cd560 <_IO_stdin_used+0x560>
   2b14f:	31 c0                	xor    eax,eax
   2b151:	e8 fa 5a 00 00       	call   30c50 <JS_ThrowTypeError>
   2b156:	4d 8b 4e 08          	mov    r9,QWORD PTR [r14+0x8]
   2b15a:	4d 8b 2e             	mov    r13,QWORD PTR [r14]
   2b15d:	48 89 c1             	mov    rcx,rax
   2b160:	41 89 d0             	mov    r8d,edx
   2b163:	48 89 d0             	mov    rax,rdx
   2b166:	e9 c1 d1 ff ff       	jmp    2832c <JS_CallInternal+0x582c>
   2b16b:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   2b172:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2b179:	44 89 ea             	mov    edx,r13d
   2b17c:	48 89 de             	mov    rsi,rbx
   2b17f:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   2b183:	e8 c8 ad 02 00       	call   55f50 <js_binary_logic_slow>
   2b188:	85 c0                	test   eax,eax
   2b18a:	0f 85 10 81 ff ff    	jne    232a0 <JS_CallInternal+0x7a0>
   2b190:	48 83 eb 10          	sub    rbx,0x10
   2b194:	e9 18 c9 ff ff       	jmp    27ab1 <JS_CallInternal+0x4fb1>
   2b199:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2b1a0:	e8 0b 80 00 00       	call   331b0 <__js_poll_interrupts>
   2b1a5:	85 c0                	test   eax,eax
   2b1a7:	0f 84 a9 bf ff ff    	je     27156 <JS_CallInternal+0x4656>
   2b1ad:	4d 89 ec             	mov    r12,r13
   2b1b0:	e9 eb 80 ff ff       	jmp    232a0 <JS_CallInternal+0x7a0>
   2b1b5:	4c 89 f3             	mov    rbx,r14
   2b1b8:	e9 e3 80 ff ff       	jmp    232a0 <JS_CallInternal+0x7a0>
   2b1bd:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2b1c4:	e8 e7 7f 00 00       	call   331b0 <__js_poll_interrupts>
   2b1c9:	85 c0                	test   eax,eax
   2b1cb:	0f 84 e5 cf ff ff    	je     281b6 <JS_CallInternal+0x56b6>
   2b1d1:	4d 89 ec             	mov    r12,r13
   2b1d4:	e9 c7 80 ff ff       	jmp    232a0 <JS_CallInternal+0x7a0>
   2b1d9:	41 8b 4e 0c          	mov    ecx,DWORD PTR [r14+0xc]
   2b1dd:	e9 01 e2 ff ff       	jmp    293e3 <JS_CallInternal+0x68e3>
   2b1e2:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2b1e9:	4c 89 ee             	mov    rsi,r13
   2b1ec:	4c 89 f2             	mov    rdx,r14
   2b1ef:	44 89 85 50 fe ff ff 	mov    DWORD PTR [rbp-0x1b0],r8d
   2b1f6:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2b1fa:	e8 a1 16 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2b1ff:	44 8b 85 50 fe ff ff 	mov    r8d,DWORD PTR [rbp-0x1b0]
   2b206:	e9 c8 9e ff ff       	jmp    250d3 <JS_CallInternal+0x25d3>
   2b20b:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2b212:	48 8b 95 50 fe ff ff 	mov    rdx,QWORD PTR [rbp-0x1b0]
   2b219:	48 89 ce             	mov    rsi,rcx
   2b21c:	44 89 85 38 fe ff ff 	mov    DWORD PTR [rbp-0x1c8],r8d
   2b223:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2b227:	e8 74 16 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2b22c:	44 8b 85 38 fe ff ff 	mov    r8d,DWORD PTR [rbp-0x1c8]
   2b233:	e9 82 9e ff ff       	jmp    250ba <JS_CallInternal+0x25ba>
   2b238:	83 fe 08             	cmp    esi,0x8
   2b23b:	0f 84 00 11 00 00    	je     2c341 <JS_CallInternal+0x9841>
   2b241:	85 f6                	test   esi,esi
   2b243:	75 09                	jne    2b24e <JS_CallInternal+0x874e>
   2b245:	83 f9 08             	cmp    ecx,0x8
   2b248:	0f 84 cd 0f 00 00    	je     2c21b <JS_CallInternal+0x971b>
   2b24e:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   2b255:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2b25c:	44 89 ea             	mov    edx,r13d
   2b25f:	48 89 de             	mov    rsi,rbx
   2b262:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   2b266:	e8 95 fb 02 00       	call   5ae00 <js_relational_slow>
   2b26b:	85 c0                	test   eax,eax
   2b26d:	0f 85 2d 80 ff ff    	jne    232a0 <JS_CallInternal+0x7a0>
   2b273:	48 83 eb 10          	sub    rbx,0x10
   2b277:	e9 46 c9 ff ff       	jmp    27bc2 <JS_CallInternal+0x50c2>
   2b27c:	66 0f ef c0          	pxor   xmm0,xmm0
   2b280:	b8 08 00 00 00       	mov    eax,0x8
   2b285:	f2 48 0f 2a c1       	cvtsi2sd xmm0,rcx
   2b28a:	f2 0f 11 43 e0       	movsd  QWORD PTR [rbx-0x20],xmm0
   2b28f:	e9 da bd ff ff       	jmp    2706e <JS_CallInternal+0x456e>
   2b294:	41 83 fb 08          	cmp    r11d,0x8
   2b298:	0f 84 65 10 00 00    	je     2c303 <JS_CallInternal+0x9803>
   2b29e:	83 ff 08             	cmp    edi,0x8
   2b2a1:	0f 84 2a 0e 00 00    	je     2c0d1 <JS_CallInternal+0x95d1>
   2b2a7:	83 c6 07             	add    esi,0x7
   2b2aa:	83 fe 01             	cmp    esi,0x1
   2b2ad:	0f 86 93 0f 00 00    	jbe    2c246 <JS_CallInternal+0x9746>
   2b2b3:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   2b2ba:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2b2c1:	48 89 de             	mov    rsi,rbx
   2b2c4:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   2b2c8:	e8 03 b8 02 00       	call   56ad0 <js_add_slow>
   2b2cd:	85 c0                	test   eax,eax
   2b2cf:	0f 85 cb 7f ff ff    	jne    232a0 <JS_CallInternal+0x7a0>
   2b2d5:	48 83 eb 10          	sub    rbx,0x10
   2b2d9:	e9 98 bd ff ff       	jmp    27076 <JS_CallInternal+0x4576>
   2b2de:	4d 89 ec             	mov    r12,r13
   2b2e1:	e9 ba 7f ff ff       	jmp    232a0 <JS_CallInternal+0x7a0>
   2b2e6:	4d 89 d4             	mov    r12,r10
   2b2e9:	e9 b2 7f ff ff       	jmp    232a0 <JS_CallInternal+0x7a0>
   2b2ee:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   2b2f5:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2b2fc:	44 89 ea             	mov    edx,r13d
   2b2ff:	48 89 de             	mov    rsi,rbx
   2b302:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   2b306:	e8 45 ac 02 00       	call   55f50 <js_binary_logic_slow>
   2b30b:	85 c0                	test   eax,eax
   2b30d:	0f 85 8d 7f ff ff    	jne    232a0 <JS_CallInternal+0x7a0>
   2b313:	48 83 eb 10          	sub    rbx,0x10
   2b317:	e9 81 c3 ff ff       	jmp    2769d <JS_CallInternal+0x4b9d>
   2b31c:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2b323:	e8 88 7e 00 00       	call   331b0 <__js_poll_interrupts>
   2b328:	85 c0                	test   eax,eax
   2b32a:	0f 84 ed ce ff ff    	je     2821d <JS_CallInternal+0x571d>
   2b330:	4d 89 ec             	mov    r12,r13
   2b333:	e9 68 7f ff ff       	jmp    232a0 <JS_CallInternal+0x7a0>
   2b338:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2b33f:	e8 6c 7e 00 00       	call   331b0 <__js_poll_interrupts>
   2b344:	85 c0                	test   eax,eax
   2b346:	0f 84 8b d5 ff ff    	je     288d7 <JS_CallInternal+0x5dd7>
   2b34c:	4d 89 ec             	mov    r12,r13
   2b34f:	e9 4c 7f ff ff       	jmp    232a0 <JS_CallInternal+0x7a0>
   2b354:	83 fe 08             	cmp    esi,0x8
   2b357:	0f 84 2b 0f 00 00    	je     2c288 <JS_CallInternal+0x9788>
   2b35d:	85 f6                	test   esi,esi
   2b35f:	75 09                	jne    2b36a <JS_CallInternal+0x886a>
   2b361:	83 f9 08             	cmp    ecx,0x8
   2b364:	0f 84 56 0f 00 00    	je     2c2c0 <JS_CallInternal+0x97c0>
   2b36a:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   2b371:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2b378:	44 89 ea             	mov    edx,r13d
   2b37b:	48 89 de             	mov    rsi,rbx
   2b37e:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   2b382:	e8 79 fa 02 00       	call   5ae00 <js_relational_slow>
   2b387:	85 c0                	test   eax,eax
   2b389:	0f 85 11 7f ff ff    	jne    232a0 <JS_CallInternal+0x7a0>
   2b38f:	48 83 eb 10          	sub    rbx,0x10
   2b393:	e9 b3 c3 ff ff       	jmp    2774b <JS_CallInternal+0x4c4b>
   2b398:	66 0f ef c0          	pxor   xmm0,xmm0
   2b39c:	b8 08 00 00 00       	mov    eax,0x8
   2b3a1:	f2 48 0f 2a c2       	cvtsi2sd xmm0,rdx
   2b3a6:	f2 41 0f 11 45 00    	movsd  QWORD PTR [r13+0x0],xmm0
   2b3ac:	e9 59 bc ff ff       	jmp    2700a <JS_CallInternal+0x450a>
   2b3b1:	48 83 eb 10          	sub    rbx,0x10
   2b3b5:	83 fa 08             	cmp    edx,0x8
   2b3b8:	0f 84 e8 12 00 00    	je     2c6a6 <JS_CallInternal+0x9ba6>
   2b3be:	83 fa f9             	cmp    edx,0xfffffff9
   2b3c1:	0f 84 24 0b 00 00    	je     2beeb <JS_CallInternal+0x93eb>
   2b3c7:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   2b3ce:	4c 89 48 30          	mov    QWORD PTR [rax+0x30],r9
   2b3d2:	49 8b 45 00          	mov    rax,QWORD PTR [r13+0x0]
   2b3d6:	83 fa f6             	cmp    edx,0xfffffff6
   2b3d9:	0f 87 25 0b 00 00    	ja     2bf04 <JS_CallInternal+0x9404>
   2b3df:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2b3e6:	48 8d b5 70 ff ff ff 	lea    rsi,[rbp-0x90]
   2b3ed:	4c 89 8d 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],r9
   2b3f4:	48 89 85 50 ff ff ff 	mov    QWORD PTR [rbp-0xb0],rax
   2b3fb:	48 89 95 58 ff ff ff 	mov    QWORD PTR [rbp-0xa8],rdx
   2b402:	4c 89 85 60 ff ff ff 	mov    QWORD PTR [rbp-0xa0],r8
   2b409:	4c 89 b5 68 ff ff ff 	mov    QWORD PTR [rbp-0x98],r14
   2b410:	e8 bb b6 02 00       	call   56ad0 <js_add_slow>
   2b415:	4c 8b 8d 50 fe ff ff 	mov    r9,QWORD PTR [rbp-0x1b0]
   2b41c:	85 c0                	test   eax,eax
   2b41e:	0f 85 f3 17 00 00    	jne    2cc17 <JS_CallInternal+0xa117>
   2b424:	49 8b 55 08          	mov    rdx,QWORD PTR [r13+0x8]
   2b428:	66 0f 6f bd 50 ff ff 	movdqa xmm7,XMMWORD PTR [rbp-0xb0]
   2b42f:	ff 
   2b430:	49 8b 75 00          	mov    rsi,QWORD PTR [r13+0x0]
   2b434:	41 0f 11 7d 00       	movups XMMWORD PTR [r13+0x0],xmm7
   2b439:	83 fa f6             	cmp    edx,0xfffffff6
   2b43c:	0f 86 d0 bb ff ff    	jbe    27012 <JS_CallInternal+0x4512>
   2b442:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   2b445:	83 e8 01             	sub    eax,0x1
   2b448:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   2b44b:	85 c0                	test   eax,eax
   2b44d:	0f 8f bf bb ff ff    	jg     27012 <JS_CallInternal+0x4512>
   2b453:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2b45a:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2b45e:	e8 3d 14 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2b463:	e9 aa bb ff ff       	jmp    27012 <JS_CallInternal+0x4512>
   2b468:	4d 89 ec             	mov    r12,r13
   2b46b:	e9 30 7e ff ff       	jmp    232a0 <JS_CallInternal+0x7a0>
   2b470:	41 83 fd fa          	cmp    r13d,0xfffffffa
   2b474:	0f 8d 9a e9 ff ff    	jge    29e14 <JS_CallInternal+0x7314>
   2b47a:	41 83 fd f8          	cmp    r13d,0xfffffff8
   2b47e:	0f 8c 90 e9 ff ff    	jl     29e14 <JS_CallInternal+0x7314>
   2b484:	e9 e4 e9 ff ff       	jmp    29e6d <JS_CallInternal+0x736d>
   2b489:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]
   2b490:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2b497:	48 8d 35 c2 20 0a 00 	lea    rsi,[rip+0xa20c2]        # cd560 <_IO_stdin_used+0x560>
   2b49e:	31 c0                	xor    eax,eax
   2b4a0:	e8 ab 57 00 00       	call   30c50 <JS_ThrowTypeError>
   2b4a5:	e9 92 b5 ff ff       	jmp    26a3c <JS_CallInternal+0x3f3c>
   2b4aa:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2b4b1:	48 8d 35 9a 20 0a 00 	lea    rsi,[rip+0xa209a]        # cd552 <_IO_stdin_used+0x552>
   2b4b8:	31 c0                	xor    eax,eax
   2b4ba:	e8 91 57 00 00       	call   30c50 <JS_ThrowTypeError>
   2b4bf:	83 bd 50 fe ff ff f6 	cmp    DWORD PTR [rbp-0x1b0],0xfffffff6
   2b4c6:	76 13                	jbe    2b4db <JS_CallInternal+0x89db>
   2b4c8:	41 8b 45 fc          	mov    eax,DWORD PTR [r13-0x4]
   2b4cc:	83 e8 01             	sub    eax,0x1
   2b4cf:	41 89 45 fc          	mov    DWORD PTR [r13-0x4],eax
   2b4d3:	85 c0                	test   eax,eax
   2b4d5:	0f 8e 72 13 00 00    	jle    2c84d <JS_CallInternal+0x9d4d>
   2b4db:	41 bd ff ff ff ff    	mov    r13d,0xffffffff
   2b4e1:	e9 80 b6 ff ff       	jmp    26b66 <JS_CallInternal+0x4066>
   2b4e6:	48 8b bd 38 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x1c8]
   2b4ed:	e8 ae 13 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2b4f2:	e9 6c b6 ff ff       	jmp    26b63 <JS_CallInternal+0x4063>
   2b4f7:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   2b4fe:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2b505:	44 89 ea             	mov    edx,r13d
   2b508:	48 89 de             	mov    rsi,rbx
   2b50b:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   2b50f:	e8 3c aa 02 00       	call   55f50 <js_binary_logic_slow>
   2b514:	85 c0                	test   eax,eax
   2b516:	0f 85 84 7d ff ff    	jne    232a0 <JS_CallInternal+0x7a0>
   2b51c:	48 83 eb 10          	sub    rbx,0x10
   2b520:	e9 b2 b2 ff ff       	jmp    267d7 <JS_CallInternal+0x3cd7>
   2b525:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2b52c:	48 8d 35 1f 20 0a 00 	lea    rsi,[rip+0xa201f]        # cd552 <_IO_stdin_used+0x552>
   2b533:	31 c0                	xor    eax,eax
   2b535:	e8 16 57 00 00       	call   30c50 <JS_ThrowTypeError>
   2b53a:	e9 fd b4 ff ff       	jmp    26a3c <JS_CallInternal+0x3f3c>
   2b53f:	44 8b 95 50 fe ff ff 	mov    r10d,DWORD PTR [rbp-0x1b0]
   2b546:	45 85 d2             	test   r10d,r10d
   2b549:	74 3d                	je     2b588 <JS_CallInternal+0x8a88>
   2b54b:	4c 8b a5 e8 fe ff ff 	mov    r12,QWORD PTR [rbp-0x118]
   2b552:	4c 89 eb             	mov    rbx,r13
   2b555:	4d 01 ee             	add    r14,r13
   2b558:	eb 09                	jmp    2b563 <JS_CallInternal+0x8a63>
   2b55a:	48 83 c3 10          	add    rbx,0x10
   2b55e:	4c 39 f3             	cmp    rbx,r14
   2b561:	74 25                	je     2b588 <JS_CallInternal+0x8a88>
   2b563:	48 8b 53 08          	mov    rdx,QWORD PTR [rbx+0x8]
   2b567:	48 8b 33             	mov    rsi,QWORD PTR [rbx]
   2b56a:	83 fa f6             	cmp    edx,0xfffffff6
   2b56d:	76 eb                	jbe    2b55a <JS_CallInternal+0x8a5a>
   2b56f:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   2b572:	83 e8 01             	sub    eax,0x1
   2b575:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   2b578:	85 c0                	test   eax,eax
   2b57a:	7f de                	jg     2b55a <JS_CallInternal+0x8a5a>
   2b57c:	49 8b 7c 24 10       	mov    rdi,QWORD PTR [r12+0x10]
   2b581:	e8 1a 13 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2b586:	eb d2                	jmp    2b55a <JS_CallInternal+0x8a5a>
   2b588:	4c 8b a5 38 fe ff ff 	mov    r12,QWORD PTR [rbp-0x1c8]
   2b58f:	4c 89 eb             	mov    rbx,r13
   2b592:	e9 09 7d ff ff       	jmp    232a0 <JS_CallInternal+0x7a0>
   2b597:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2b59e:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2b5a2:	e8 f9 12 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2b5a7:	e9 f3 db ff ff       	jmp    2919f <JS_CallInternal+0x669f>
   2b5ac:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2b5b3:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2b5b7:	e8 e4 12 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2b5bc:	e9 77 c0 ff ff       	jmp    27638 <JS_CallInternal+0x4b38>
   2b5c1:	66 0f ef c0          	pxor   xmm0,xmm0
   2b5c5:	f2 48 0f 2a c0       	cvtsi2sd xmm0,rax
   2b5ca:	b8 08 00 00 00       	mov    eax,0x8
   2b5cf:	f2 0f 11 43 e0       	movsd  QWORD PTR [rbx-0x20],xmm0
   2b5d4:	e9 bd b9 ff ff       	jmp    26f96 <JS_CallInternal+0x4496>
   2b5d9:	83 fa 08             	cmp    edx,0x8
   2b5dc:	0f 84 80 13 00 00    	je     2c962 <JS_CallInternal+0x9e62>
   2b5e2:	83 f8 08             	cmp    eax,0x8
   2b5e5:	0f 85 0c 86 ff ff    	jne    23bf7 <JS_CallInternal+0x10f7>
   2b5eb:	85 d2                	test   edx,edx
   2b5ed:	0f 85 04 86 ff ff    	jne    23bf7 <JS_CallInternal+0x10f7>
   2b5f3:	66 0f ef c0          	pxor   xmm0,xmm0
   2b5f7:	f2 0f 2a c7          	cvtsi2sd xmm0,edi
   2b5fb:	66 48 0f 6e c9       	movq   xmm1,rcx
   2b600:	f2 0f 5c c1          	subsd  xmm0,xmm1
   2b604:	48 8d 53 f0          	lea    rdx,[rbx-0x10]
   2b608:	b8 08 00 00 00       	mov    eax,0x8
   2b60d:	f2 0f 11 43 e0       	movsd  QWORD PTR [rbx-0x20],xmm0
   2b612:	e9 83 b9 ff ff       	jmp    26f9a <JS_CallInternal+0x449a>
   2b617:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2b61e:	31 c0                	xor    eax,eax
   2b620:	48 8d 35 21 1f 0a 00 	lea    rsi,[rip+0xa1f21]        # cd548 <_IO_stdin_used+0x548>
   2b627:	e8 04 7a 00 00       	call   33030 <JS_ThrowInternalError>
   2b62c:	83 fb f6             	cmp    ebx,0xfffffff6
   2b62f:	76 13                	jbe    2b644 <JS_CallInternal+0x8b44>
   2b631:	41 8b 45 fc          	mov    eax,DWORD PTR [r13-0x4]
   2b635:	83 e8 01             	sub    eax,0x1
   2b638:	41 89 45 fc          	mov    DWORD PTR [r13-0x4],eax
   2b63c:	85 c0                	test   eax,eax
   2b63e:	0f 8e 42 0d 00 00    	jle    2c386 <JS_CallInternal+0x9886>
   2b644:	4c 89 f3             	mov    rbx,r14
   2b647:	e9 54 7c ff ff       	jmp    232a0 <JS_CallInternal+0x7a0>
   2b64c:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2b653:	48 8b 95 50 fe ff ff 	mov    rdx,QWORD PTR [rbp-0x1b0]
   2b65a:	4c 89 f6             	mov    rsi,r14
   2b65d:	44 89 85 38 fe ff ff 	mov    DWORD PTR [rbp-0x1c8],r8d
   2b664:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2b668:	e8 33 12 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2b66d:	44 8b 85 38 fe ff ff 	mov    r8d,DWORD PTR [rbp-0x1c8]
   2b674:	e9 2c b8 ff ff       	jmp    26ea5 <JS_CallInternal+0x43a5>
   2b679:	48 8b 85 d8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x128]
   2b680:	48 8d 15 13 1e 0a 00 	lea    rdx,[rip+0xa1e13]        # cd49a <_IO_stdin_used+0x49a>
   2b687:	48 8b 40 30          	mov    rax,QWORD PTR [rax+0x30]
   2b68b:	8b 44 08 04          	mov    eax,DWORD PTR [rax+rcx*1+0x4]
   2b68f:	85 c0                	test   eax,eax
   2b691:	0f 85 ee 12 00 00    	jne    2c985 <JS_CallInternal+0x9e85>
   2b697:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2b69e:	48 8d 35 51 1e 0a 00 	lea    rsi,[rip+0xa1e51]        # cd4f6 <_IO_stdin_used+0x4f6>
   2b6a5:	31 c0                	xor    eax,eax
   2b6a7:	4d 89 ec             	mov    r12,r13
   2b6aa:	e8 91 76 00 00       	call   32d40 <JS_ThrowReferenceError>
   2b6af:	e9 ec 7b ff ff       	jmp    232a0 <JS_CallInternal+0x7a0>
   2b6b4:	41 83 f8 08          	cmp    r8d,0x8
   2b6b8:	0f 84 67 0d 00 00    	je     2c425 <JS_CallInternal+0x9925>
   2b6be:	41 83 f8 ff          	cmp    r8d,0xffffffff
   2b6c2:	0f 84 17 0d 00 00    	je     2c3df <JS_CallInternal+0x98df>
   2b6c8:	41 8d 48 fe          	lea    ecx,[r8-0x2]
   2b6cc:	83 f9 01             	cmp    ecx,0x1
   2b6cf:	0f 86 66 16 00 00    	jbe    2cd3b <JS_CallInternal+0xa23b>
   2b6d5:	41 83 f8 f9          	cmp    r8d,0xfffffff9
   2b6d9:	0f 85 c2 0c 00 00    	jne    2c3a1 <JS_CallInternal+0x98a1>
   2b6df:	41 83 fe f9          	cmp    r14d,0xfffffff9
   2b6e3:	0f 85 b8 0c 00 00    	jne    2c3a1 <JS_CallInternal+0x98a1>
   2b6e9:	4c 89 ee             	mov    rsi,r13
   2b6ec:	48 89 95 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],rdx
   2b6f3:	4c 89 85 38 fe ff ff 	mov    QWORD PTR [rbp-0x1c8],r8
   2b6fa:	e8 11 c7 fe ff       	call   17e10 <js_string_eq.isra.0>
   2b6ff:	48 8b b5 40 fe ff ff 	mov    rsi,QWORD PTR [rbp-0x1c0]
   2b706:	48 8b 95 38 fe ff ff 	mov    rdx,QWORD PTR [rbp-0x1c8]
   2b70d:	89 85 50 fe ff ff    	mov    DWORD PTR [rbp-0x1b0],eax
   2b713:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2b71a:	e8 e1 12 ff ff       	call   1ca00 <JS_FreeValue>
   2b71f:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2b726:	4c 89 ee             	mov    rsi,r13
   2b729:	4c 89 f2             	mov    rdx,r14
   2b72c:	e8 cf 12 ff ff       	call   1ca00 <JS_FreeValue>
   2b731:	8b 85 50 fe ff ff    	mov    eax,DWORD PTR [rbp-0x1b0]
   2b737:	85 c0                	test   eax,eax
   2b739:	0f 95 c0             	setne  al
   2b73c:	0f b6 c0             	movzx  eax,al
   2b73f:	e9 6f c2 ff ff       	jmp    279b3 <JS_CallInternal+0x4eb3>
   2b744:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2b74b:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2b74f:	e8 4c 11 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2b754:	e9 d4 96 ff ff       	jmp    24e2d <JS_CallInternal+0x232d>
   2b759:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2b760:	48 8d 35 f9 1d 0a 00 	lea    rsi,[rip+0xa1df9]        # cd560 <_IO_stdin_used+0x560>
   2b767:	31 c0                	xor    eax,eax
   2b769:	e8 e2 54 00 00       	call   30c50 <JS_ThrowTypeError>
   2b76e:	e9 4c fd ff ff       	jmp    2b4bf <JS_CallInternal+0x89bf>
   2b773:	41 83 fd 08          	cmp    r13d,0x8
   2b777:	0f 84 c8 0f 00 00    	je     2c745 <JS_CallInternal+0x9c45>
   2b77d:	41 83 fd ff          	cmp    r13d,0xffffffff
   2b781:	0f 84 57 0f 00 00    	je     2c6de <JS_CallInternal+0x9bde>
   2b787:	41 8d 4d fe          	lea    ecx,[r13-0x2]
   2b78b:	83 f9 01             	cmp    ecx,0x1
   2b78e:	0f 86 dc 0f 00 00    	jbe    2c770 <JS_CallInternal+0x9c70>
   2b794:	4c 89 85 38 fe ff ff 	mov    QWORD PTR [rbp-0x1c8],r8
   2b79b:	4c 89 8d 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],r9
   2b7a2:	41 83 fd f9          	cmp    r13d,0xfffffff9
   2b7a6:	0f 85 22 e9 ff ff    	jne    2a0ce <JS_CallInternal+0x75ce>
   2b7ac:	41 83 f8 f9          	cmp    r8d,0xfffffff9
   2b7b0:	0f 85 18 e9 ff ff    	jne    2a0ce <JS_CallInternal+0x75ce>
   2b7b6:	e8 55 c6 fe ff       	call   17e10 <js_string_eq.isra.0>
   2b7bb:	4c 89 f6             	mov    rsi,r14
   2b7be:	4c 8b b5 e8 fe ff ff 	mov    r14,QWORD PTR [rbp-0x118]
   2b7c5:	4c 89 ea             	mov    rdx,r13
   2b7c8:	89 85 50 fe ff ff    	mov    DWORD PTR [rbp-0x1b0],eax
   2b7ce:	4c 89 f7             	mov    rdi,r14
   2b7d1:	e8 2a 12 ff ff       	call   1ca00 <JS_FreeValue>
   2b7d6:	48 8b b5 40 fe ff ff 	mov    rsi,QWORD PTR [rbp-0x1c0]
   2b7dd:	48 8b 95 38 fe ff ff 	mov    rdx,QWORD PTR [rbp-0x1c8]
   2b7e4:	4c 89 f7             	mov    rdi,r14
   2b7e7:	e8 14 12 ff ff       	call   1ca00 <JS_FreeValue>
   2b7ec:	8b 85 50 fe ff ff    	mov    eax,DWORD PTR [rbp-0x1b0]
   2b7f2:	85 c0                	test   eax,eax
   2b7f4:	0f 95 c0             	setne  al
   2b7f7:	e9 79 b1 ff ff       	jmp    26975 <JS_CallInternal+0x3e75>
   2b7fc:	0f 1f 40 00          	nop    DWORD PTR [rax+0x0]
   2b800:	4c 89 f3             	mov    rbx,r14
   2b803:	4d 89 ec             	mov    r12,r13
   2b806:	e9 95 7a ff ff       	jmp    232a0 <JS_CallInternal+0x7a0>
   2b80b:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   2b812:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2b819:	44 89 ea             	mov    edx,r13d
   2b81c:	48 89 de             	mov    rsi,rbx
   2b81f:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   2b823:	e8 28 a7 02 00       	call   55f50 <js_binary_logic_slow>
   2b828:	85 c0                	test   eax,eax
   2b82a:	0f 85 70 7a ff ff    	jne    232a0 <JS_CallInternal+0x7a0>
   2b830:	48 83 eb 10          	sub    rbx,0x10
   2b834:	e9 b5 c2 ff ff       	jmp    27aee <JS_CallInternal+0x4fee>
   2b839:	48 8b b5 d8 fe ff ff 	mov    rsi,QWORD PTR [rbp-0x128]
   2b840:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2b847:	31 c9                	xor    ecx,ecx
   2b849:	4d 89 ec             	mov    r12,r13
   2b84c:	e8 7f 76 00 00       	call   32ed0 <JS_ThrowReferenceErrorUninitialized2.isra.0>
   2b851:	e9 4a 7a ff ff       	jmp    232a0 <JS_CallInternal+0x7a0>
   2b856:	48 8b b5 d8 fe ff ff 	mov    rsi,QWORD PTR [rbp-0x128]
   2b85d:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2b864:	31 c9                	xor    ecx,ecx
   2b866:	4d 89 ec             	mov    r12,r13
   2b869:	e8 62 76 00 00       	call   32ed0 <JS_ThrowReferenceErrorUninitialized2.isra.0>
   2b86e:	e9 2d 7a ff ff       	jmp    232a0 <JS_CallInternal+0x7a0>
   2b873:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   2b87a:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2b881:	48 89 de             	mov    rsi,rbx
   2b884:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   2b888:	e8 f3 a4 02 00       	call   55d80 <js_shr_slow>
   2b88d:	85 c0                	test   eax,eax
   2b88f:	0f 85 0b 7a ff ff    	jne    232a0 <JS_CallInternal+0x7a0>
   2b895:	48 83 eb 10          	sub    rbx,0x10
   2b899:	e9 be af ff ff       	jmp    2685c <JS_CallInternal+0x3d5c>
   2b89e:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2b8a5:	e8 06 79 00 00       	call   331b0 <__js_poll_interrupts>
   2b8aa:	85 c0                	test   eax,eax
   2b8ac:	0f 84 65 d0 ff ff    	je     28917 <JS_CallInternal+0x5e17>
   2b8b2:	4d 89 ec             	mov    r12,r13
   2b8b5:	e9 e6 79 ff ff       	jmp    232a0 <JS_CallInternal+0x7a0>
   2b8ba:	83 fe 08             	cmp    esi,0x8
   2b8bd:	0f 84 13 11 00 00    	je     2c9d6 <JS_CallInternal+0x9ed6>
   2b8c3:	83 f9 08             	cmp    ecx,0x8
   2b8c6:	75 08                	jne    2b8d0 <JS_CallInternal+0x8dd0>
   2b8c8:	85 f6                	test   esi,esi
   2b8ca:	0f 84 46 11 00 00    	je     2ca16 <JS_CallInternal+0x9f16>
   2b8d0:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   2b8d7:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2b8de:	44 89 ea             	mov    edx,r13d
   2b8e1:	48 89 de             	mov    rsi,rbx
   2b8e4:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   2b8e8:	e8 13 f5 02 00       	call   5ae00 <js_relational_slow>
   2b8ed:	85 c0                	test   eax,eax
   2b8ef:	0f 85 ab 79 ff ff    	jne    232a0 <JS_CallInternal+0x7a0>
   2b8f5:	48 83 eb 10          	sub    rbx,0x10
   2b8f9:	e9 b2 c3 ff ff       	jmp    27cb0 <JS_CallInternal+0x51b0>
   2b8fe:	83 fe 08             	cmp    esi,0x8
   2b901:	0f 84 65 0f 00 00    	je     2c86c <JS_CallInternal+0x9d6c>
   2b907:	85 f6                	test   esi,esi
   2b909:	75 09                	jne    2b914 <JS_CallInternal+0x8e14>
   2b90b:	83 f9 08             	cmp    ecx,0x8
   2b90e:	0f 84 90 0f 00 00    	je     2c8a4 <JS_CallInternal+0x9da4>
   2b914:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   2b91b:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2b922:	44 89 ea             	mov    edx,r13d
   2b925:	48 89 de             	mov    rsi,rbx
   2b928:	4c 89 60 30          	mov    QWORD PTR [rax+0x30],r12
   2b92c:	e8 cf f4 02 00       	call   5ae00 <js_relational_slow>
   2b931:	85 c0                	test   eax,eax
   2b933:	0f 85 67 79 ff ff    	jne    232a0 <JS_CallInternal+0x7a0>
   2b939:	48 83 eb 10          	sub    rbx,0x10
   2b93d:	e9 5a b8 ff ff       	jmp    2719c <JS_CallInternal+0x469c>
   2b942:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2b949:	e8 62 78 00 00       	call   331b0 <__js_poll_interrupts>
   2b94e:	85 c0                	test   eax,eax
   2b950:	0f 84 07 c9 ff ff    	je     2825d <JS_CallInternal+0x575d>
   2b956:	4d 89 ec             	mov    r12,r13
   2b959:	e9 42 79 ff ff       	jmp    232a0 <JS_CallInternal+0x7a0>
   2b95e:	4c 89 f3             	mov    rbx,r14
   2b961:	4d 89 ec             	mov    r12,r13
   2b964:	e9 37 79 ff ff       	jmp    232a0 <JS_CallInternal+0x7a0>
   2b969:	48 8b b5 d8 fe ff ff 	mov    rsi,QWORD PTR [rbp-0x128]
   2b970:	48 8b bd a0 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x160]
   2b977:	0f b7 d1             	movzx  edx,cx
   2b97a:	31 c9                	xor    ecx,ecx
   2b97c:	4d 89 ec             	mov    r12,r13
   2b97f:	e8 4c 75 00 00       	call   32ed0 <JS_ThrowReferenceErrorUninitialized2.isra.0>
   2b984:	e9 17 79 ff ff       	jmp    232a0 <JS_CallInternal+0x7a0>
   2b989:	0f 85 39 11 00 00    	jne    2cac8 <JS_CallInternal+0x9fc8>
   2b98f:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2b996:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2b99a:	48 8b 87 f0 04 00 00 	mov    rax,QWORD PTR [rdi+0x4f0]
   2b9a1:	48 85 c0             	test   rax,rax
   2b9a4:	0f 84 7e 05 00 00    	je     2bf28 <JS_CallInternal+0x9428>
   2b9aa:	f6 40 3c 01          	test   BYTE PTR [rax+0x3c],0x1
   2b9ae:	0f 84 74 05 00 00    	je     2bf28 <JS_CallInternal+0x9428>
   2b9b4:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2b9bb:	44 89 ee             	mov    esi,r13d
   2b9be:	e8 ad 74 00 00       	call   32e70 <JS_ThrowReferenceErrorNotDefined>
   2b9c3:	41 81 fd f2 00 00 00 	cmp    r13d,0xf2
   2b9ca:	0f 8e d0 78 ff ff    	jle    232a0 <JS_CallInternal+0x7a0>
   2b9d0:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2b9d7:	44 89 ee             	mov    esi,r13d
   2b9da:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2b9de:	e8 8d da fe ff       	call   19470 <JS_FreeAtom.part.0.isra.0>
   2b9e3:	e9 b8 78 ff ff       	jmp    232a0 <JS_CallInternal+0x7a0>
   2b9e8:	4c 8b b5 e8 fe ff ff 	mov    r14,QWORD PTR [rbp-0x118]
   2b9ef:	48 8d 75 80          	lea    rsi,[rbp-0x80]
   2b9f3:	44 89 ea             	mov    edx,r13d
   2b9f6:	49 8b 7e 10          	mov    rdi,QWORD PTR [r14+0x10]
   2b9fa:	e8 11 b9 fe ff       	call   17310 <JS_AtomGetStrRT.constprop.0>
   2b9ff:	48 8d 35 87 1b 0a 00 	lea    rsi,[rip+0xa1b87]        # cd58d <_IO_stdin_used+0x58d>
   2ba06:	4c 89 f7             	mov    rdi,r14
   2ba09:	48 89 c2             	mov    rdx,rax
   2ba0c:	31 c0                	xor    eax,eax
   2ba0e:	e8 2d 73 00 00       	call   32d40 <JS_ThrowReferenceError>
   2ba13:	41 81 fd f2 00 00 00 	cmp    r13d,0xf2
   2ba1a:	0f 8e 80 78 ff ff    	jle    232a0 <JS_CallInternal+0x7a0>
   2ba20:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2ba27:	44 89 ee             	mov    esi,r13d
   2ba2a:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2ba2e:	e8 3d da fe ff       	call   19470 <JS_FreeAtom.part.0.isra.0>
   2ba33:	e9 68 78 ff ff       	jmp    232a0 <JS_CallInternal+0x7a0>
   2ba38:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2ba3f:	48 89 ce             	mov    rsi,rcx
   2ba42:	4c 89 ea             	mov    rdx,r13
   2ba45:	44 89 85 50 fe ff ff 	mov    DWORD PTR [rbp-0x1b0],r8d
   2ba4c:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2ba50:	e8 4b 0e ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2ba55:	44 8b 85 50 fe ff ff 	mov    r8d,DWORD PTR [rbp-0x1b0]
   2ba5c:	e9 68 b4 ff ff       	jmp    26ec9 <JS_CallInternal+0x43c9>
   2ba61:	66 0f ef c0          	pxor   xmm0,xmm0
   2ba65:	f2 48 0f 2a c0       	cvtsi2sd xmm0,rax
   2ba6a:	f2 0f 11 43 e0       	movsd  QWORD PTR [rbx-0x20],xmm0
   2ba6f:	48 8d 53 f0          	lea    rdx,[rbx-0x10]
   2ba73:	b8 08 00 00 00       	mov    eax,0x8
   2ba78:	e9 c1 b4 ff ff       	jmp    26f3e <JS_CallInternal+0x443e>
   2ba7d:	83 fe 08             	cmp    esi,0x8
   2ba80:	0f 84 2c 0d 00 00    	je     2c7b2 <JS_CallInternal+0x9cb2>
   2ba86:	83 f8 08             	cmp    eax,0x8
   2ba89:	0f 85 68 81 ff ff    	jne    23bf7 <JS_CallInternal+0x10f7>
   2ba8f:	85 f6                	test   esi,esi
   2ba91:	0f 85 60 81 ff ff    	jne    23bf7 <JS_CallInternal+0x10f7>
   2ba97:	66 0f ef c9          	pxor   xmm1,xmm1
   2ba9b:	f2 0f 2a c9          	cvtsi2sd xmm1,ecx
   2ba9f:	66 48 0f 6e c2       	movq   xmm0,rdx
   2baa4:	f2 0f 59 c1          	mulsd  xmm0,xmm1
   2baa8:	eb c0                	jmp    2ba6a <JS_CallInternal+0x8f6a>
   2baaa:	48 8b b5 d8 fe ff ff 	mov    rsi,QWORD PTR [rbp-0x128]
   2bab1:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2bab8:	0f b7 d1             	movzx  edx,cx
   2babb:	31 c9                	xor    ecx,ecx
   2babd:	4d 89 ec             	mov    r12,r13
   2bac0:	e8 0b 74 00 00       	call   32ed0 <JS_ThrowReferenceErrorUninitialized2.isra.0>
   2bac5:	e9 d6 77 ff ff       	jmp    232a0 <JS_CallInternal+0x7a0>
   2baca:	4c 89 f3             	mov    rbx,r14
   2bacd:	e9 ce 77 ff ff       	jmp    232a0 <JS_CallInternal+0x7a0>
   2bad2:	8b 01                	mov    eax,DWORD PTR [rcx]
   2bad4:	25 ff ff ff 03       	and    eax,0x3ffffff
   2bad9:	0f 85 3c b0 ff ff    	jne    26b1b <JS_CallInternal+0x401b>
   2badf:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2bae6:	48 8d 0d 57 16 0a 00 	lea    rcx,[rip+0xa1657]        # cd144 <_IO_stdin_used+0x144>
   2baed:	31 c0                	xor    eax,eax
   2baef:	48 8d 15 f2 52 0a 00 	lea    rdx,[rip+0xa52f2]        # d0de8 <_IO_stdin_used+0x3de8>
   2baf6:	e8 65 53 00 00       	call   30e60 <__JS_ThrowTypeErrorAtom>
   2bafb:	e9 bf f9 ff ff       	jmp    2b4bf <JS_CallInternal+0x89bf>
   2bb00:	09 ca                	or     edx,ecx
   2bb02:	0f 89 29 b4 ff ff    	jns    26f31 <JS_CallInternal+0x4431>
   2bb08:	f2 0f 10 05 90 ef 0a 	movsd  xmm0,QWORD PTR [rip+0xaef90]        # daaa0 <typed_array_size_log2+0x28>
   2bb0f:	00 
   2bb10:	e9 55 ff ff ff       	jmp    2ba6a <JS_CallInternal+0x8f6a>
   2bb15:	39 c2                	cmp    edx,eax
   2bb17:	0f 85 f6 de ff ff    	jne    29a13 <JS_CallInternal+0x6f13>
   2bb1d:	0f b6 51 10          	movzx  edx,BYTE PTR [rcx+0x10]
   2bb21:	f7 d2                	not    edx
   2bb23:	83 e2 12             	and    edx,0x12
   2bb26:	0f 85 e7 de ff ff    	jne    29a13 <JS_CallInternal+0x6f13>
   2bb2c:	48 8b 79 18          	mov    rdi,QWORD PTR [rcx+0x18]
   2bb30:	48 8b 57 30          	mov    rdx,QWORD PTR [rdi+0x30]
   2bb34:	48 85 d2             	test   rdx,rdx
   2bb37:	74 0a                	je     2bb43 <JS_CallInternal+0x9043>
   2bb39:	f6 42 10 01          	test   BYTE PTR [rdx+0x10],0x1
   2bb3d:	0f 84 d0 de ff ff    	je     29a13 <JS_CallInternal+0x6f13>
   2bb43:	48 8b 71 20          	mov    rsi,QWORD PTR [rcx+0x20]
   2bb47:	44 8b 56 08          	mov    r10d,DWORD PTR [rsi+0x8]
   2bb4b:	45 85 d2             	test   r10d,r10d
   2bb4e:	0f 85 bf de ff ff    	jne    29a13 <JS_CallInternal+0x6f13>
   2bb54:	8d 50 01             	lea    edx,[rax+0x1]
   2bb57:	39 51 28             	cmp    DWORD PTR [rcx+0x28],edx
   2bb5a:	0f 82 b3 de ff ff    	jb     29a13 <JS_CallInternal+0x6f13>
   2bb60:	39 16                	cmp    DWORD PTR [rsi],edx
   2bb62:	73 1c                	jae    2bb80 <JS_CallInternal+0x9080>
   2bb64:	44 8b 47 18          	mov    r8d,DWORD PTR [rdi+0x18]
   2bb68:	42 f6 44 87 3f 08    	test   BYTE PTR [rdi+r8*4+0x3f],0x8
   2bb6e:	0f 84 9f de ff ff    	je     29a13 <JS_CallInternal+0x6f13>
   2bb74:	89 d7                	mov    edi,edx
   2bb76:	45 31 c9             	xor    r9d,r9d
   2bb79:	48 89 3e             	mov    QWORD PTR [rsi],rdi
   2bb7c:	4c 89 4e 08          	mov    QWORD PTR [rsi+0x8],r9
   2bb80:	89 51 38             	mov    DWORD PTR [rcx+0x38],edx
   2bb83:	89 c0                	mov    eax,eax
   2bb85:	f3 0f 6f 73 f0       	movdqu xmm6,XMMWORD PTR [rbx-0x10]
   2bb8a:	48 c1 e0 04          	shl    rax,0x4
   2bb8e:	48 03 41 30          	add    rax,QWORD PTR [rcx+0x30]
   2bb92:	0f 11 30             	movups XMMWORD PTR [rax],xmm6
   2bb95:	e9 92 c5 ff ff       	jmp    2812c <JS_CallInternal+0x562c>
   2bb9a:	66 0f 1f 44 00 00    	nop    WORD PTR [rax+rax*1+0x0]
   2bba0:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2bba7:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2bbab:	e8 f0 0c ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2bbb0:	e9 98 c5 ff ff       	jmp    2814d <JS_CallInternal+0x564d>
   2bbb5:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2bbbc:	89 8d 50 fe ff ff    	mov    DWORD PTR [rbp-0x1b0],ecx
   2bbc2:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2bbc6:	e8 d5 0c ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2bbcb:	8b 8d 50 fe ff ff    	mov    ecx,DWORD PTR [rbp-0x1b0]
   2bbd1:	e9 6d be ff ff       	jmp    27a43 <JS_CallInternal+0x4f43>
   2bbd6:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2bbdd:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2bbe1:	e8 ba 0c ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2bbe6:	e9 14 bc ff ff       	jmp    277ff <JS_CallInternal+0x4cff>
   2bbeb:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2bbf2:	4c 89 ee             	mov    rsi,r13
   2bbf5:	4c 89 f2             	mov    rdx,r14
   2bbf8:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2bbfc:	e8 9f 0c ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2bc01:	e9 12 bc ff ff       	jmp    27818 <JS_CallInternal+0x4d18>
   2bc06:	8b 01                	mov    eax,DWORD PTR [rcx]
   2bc08:	25 ff ff ff 03       	and    eax,0x3ffffff
   2bc0d:	0f 85 e6 c6 ff ff    	jne    282f9 <JS_CallInternal+0x57f9>
   2bc13:	48 8b bd 28 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x1d8]
   2bc1a:	48 8d 75 80          	lea    rsi,[rbp-0x80]
   2bc1e:	e8 ed b6 fe ff       	call   17310 <JS_AtomGetStrRT.constprop.0>
   2bc23:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2bc2a:	48 8d 35 b7 51 0a 00 	lea    rsi,[rip+0xa51b7]        # d0de8 <_IO_stdin_used+0x3de8>
   2bc31:	48 89 c2             	mov    rdx,rax
   2bc34:	31 c0                	xor    eax,eax
   2bc36:	e8 15 50 00 00       	call   30c50 <JS_ThrowTypeError>
   2bc3b:	4d 8b 4e 08          	mov    r9,QWORD PTR [r14+0x8]
   2bc3f:	4d 8b 2e             	mov    r13,QWORD PTR [r14]
   2bc42:	31 c9                	xor    ecx,ecx
   2bc44:	41 b8 06 00 00 00    	mov    r8d,0x6
   2bc4a:	b8 06 00 00 00       	mov    eax,0x6
   2bc4f:	e9 d8 c6 ff ff       	jmp    2832c <JS_CallInternal+0x582c>
   2bc54:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2bc5b:	4c 89 f6             	mov    rsi,r14
   2bc5e:	4c 89 ea             	mov    rdx,r13
   2bc61:	89 8d 50 fe ff ff    	mov    DWORD PTR [rbp-0x1b0],ecx
   2bc67:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2bc6b:	e8 30 0c ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2bc70:	8b 8d 50 fe ff ff    	mov    ecx,DWORD PTR [rbp-0x1b0]
   2bc76:	e9 e1 bd ff ff       	jmp    27a5c <JS_CallInternal+0x4f5c>
   2bc7b:	3d f2 00 00 00       	cmp    eax,0xf2
   2bc80:	7e 43                	jle    2bcc5 <JS_CallInternal+0x91c5>
   2bc82:	31 d2                	xor    edx,edx
   2bc84:	48 8b 8d e8 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x118]
   2bc8b:	89 c0                	mov    eax,eax
   2bc8d:	48 8b 79 10          	mov    rdi,QWORD PTR [rcx+0x10]
   2bc91:	48 8b 8f 48 04 00 00 	mov    rcx,QWORD PTR [rdi+0x448]
   2bc98:	48 8b 34 c1          	mov    rsi,QWORD PTR [rcx+rax*8]
   2bc9c:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   2bc9f:	83 e8 01             	sub    eax,0x1
   2bca2:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   2bca5:	85 c0                	test   eax,eax
   2bca7:	7f 13                	jg     2bcbc <JS_CallInternal+0x91bc>
   2bca9:	48 89 95 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],rdx
   2bcb0:	e8 4b 97 fe ff       	call   15400 <JS_FreeAtomStruct>
   2bcb5:	48 8b 95 50 fe ff ff 	mov    rdx,QWORD PTR [rbp-0x1b0]
   2bcbc:	48 85 d2             	test   rdx,rdx
   2bcbf:	0f 85 bc 98 ff ff    	jne    25581 <JS_CallInternal+0x2a81>
   2bcc5:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2bccc:	48 8d 35 dd 4f 0a 00 	lea    rsi,[rip+0xa4fdd]        # d0cb0 <_IO_stdin_used+0x3cb0>
   2bcd3:	31 c0                	xor    eax,eax
   2bcd5:	e8 76 4f 00 00       	call   30c50 <JS_ThrowTypeError>
   2bcda:	48 c7 03 00 00 00 00 	mov    QWORD PTR [rbx],0x0
   2bce1:	48 c7 43 08 06 00 00 	mov    QWORD PTR [rbx+0x8],0x6
   2bce8:	00 
   2bce9:	e9 5d 97 ff ff       	jmp    2544b <JS_CallInternal+0x294b>
   2bcee:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2bcf5:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2bcf9:	e8 a2 0b ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2bcfe:	e9 29 c4 ff ff       	jmp    2812c <JS_CallInternal+0x562c>
   2bd03:	0f 85 fd 78 ff ff    	jne    23606 <JS_CallInternal+0xb06>
   2bd09:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2bd10:	48 8b 47 10          	mov    rax,QWORD PTR [rdi+0x10]
   2bd14:	48 8b 80 f0 04 00 00 	mov    rax,QWORD PTR [rax+0x4f0]
   2bd1b:	48 85 c0             	test   rax,rax
   2bd1e:	0f 84 1d 0b 00 00    	je     2c841 <JS_CallInternal+0x9d41>
   2bd24:	f6 40 3c 01          	test   BYTE PTR [rax+0x3c],0x1
   2bd28:	0f 84 13 0b 00 00    	je     2c841 <JS_CallInternal+0x9d41>
   2bd2e:	8b b5 38 fe ff ff    	mov    esi,DWORD PTR [rbp-0x1c8]
   2bd34:	e8 37 71 00 00       	call   32e70 <JS_ThrowReferenceErrorNotDefined>
   2bd39:	e9 c8 78 ff ff       	jmp    23606 <JS_CallInternal+0xb06>
   2bd3e:	8b 52 10             	mov    edx,DWORD PTR [rdx+0x10]
   2bd41:	81 e2 08 00 ff ff    	and    edx,0xffff0008
   2bd47:	81 fa 00 00 01 00    	cmp    edx,0x10000
   2bd4d:	0f 85 95 83 ff ff    	jne    240e8 <JS_CallInternal+0x15e8>
   2bd53:	41 80 7d 10 00       	cmp    BYTE PTR [r13+0x10],0x0
   2bd58:	0f 84 8a 83 ff ff    	je     240e8 <JS_CallInternal+0x15e8>
   2bd5e:	49 8b 36             	mov    rsi,QWORD PTR [r14]
   2bd61:	48 c1 f9 04          	sar    rcx,0x4
   2bd65:	4c 39 ee             	cmp    rsi,r13
   2bd68:	74 55                	je     2bdbf <JS_CallInternal+0x92bf>
   2bd6a:	41 83 45 fc 01       	add    DWORD PTR [r13-0x4],0x1
   2bd6f:	48 85 f6             	test   rsi,rsi
   2bd72:	74 48                	je     2bdbc <JS_CallInternal+0x92bc>
   2bd74:	48 89 85 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],rax
   2bd7b:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2bd82:	48 89 8d 28 fe ff ff 	mov    QWORD PTR [rbp-0x1d8],rcx
   2bd89:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2bd8d:	4c 89 9d 38 fe ff ff 	mov    QWORD PTR [rbp-0x1c8],r11
   2bd94:	4c 89 85 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],r8
   2bd9b:	e8 10 25 ff ff       	call   1e2b0 <js_free_shape>
   2bda0:	48 8b 8d 28 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x1d8]
   2bda7:	4c 8b 9d 38 fe ff ff 	mov    r11,QWORD PTR [rbp-0x1c8]
   2bdae:	48 8b 85 40 fe ff ff 	mov    rax,QWORD PTR [rbp-0x1c0]
   2bdb5:	4c 8b 85 50 fe ff ff 	mov    r8,QWORD PTR [rbp-0x1b0]
   2bdbc:	4d 89 2e             	mov    QWORD PTR [r14],r13
   2bdbf:	41 89 4e 08          	mov    DWORD PTR [r14+0x8],ecx
   2bdc3:	e9 20 83 ff ff       	jmp    240e8 <JS_CallInternal+0x15e8>
   2bdc8:	f2 0f 10 05 d0 ec 0a 	movsd  xmm0,QWORD PTR [rip+0xaecd0]        # daaa0 <typed_array_size_log2+0x28>
   2bdcf:	00 
   2bdd0:	e9 eb d7 ff ff       	jmp    295c0 <JS_CallInternal+0x6ac0>
   2bdd5:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2bddc:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2bde0:	e8 bb 0a ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2bde5:	e9 1e 79 ff ff       	jmp    23708 <JS_CallInternal+0xc08>
   2bdea:	0f 85 16 78 ff ff    	jne    23606 <JS_CallInternal+0xb06>
   2bdf0:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2bdf7:	48 8b 47 10          	mov    rax,QWORD PTR [rdi+0x10]
   2bdfb:	48 8b 80 f0 04 00 00 	mov    rax,QWORD PTR [rax+0x4f0]
   2be02:	48 85 c0             	test   rax,rax
   2be05:	0f 84 8b 77 ff ff    	je     23596 <JS_CallInternal+0xa96>
   2be0b:	f6 40 3c 01          	test   BYTE PTR [rax+0x3c],0x1
   2be0f:	0f 84 81 77 ff ff    	je     23596 <JS_CallInternal+0xa96>
   2be15:	e9 14 ff ff ff       	jmp    2bd2e <JS_CallInternal+0x922e>
   2be1a:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2be21:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2be25:	e8 76 0a ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2be2a:	e9 cb 77 ff ff       	jmp    235fa <JS_CallInternal+0xafa>
   2be2f:	8b 4e 10             	mov    ecx,DWORD PTR [rsi+0x10]
   2be32:	81 e1 08 00 ff ff    	and    ecx,0xffff0008
   2be38:	81 f9 00 00 01 00    	cmp    ecx,0x10000
   2be3e:	0f 85 cd 81 ff ff    	jne    24011 <JS_CallInternal+0x1511>
   2be44:	41 80 7d 10 00       	cmp    BYTE PTR [r13+0x10],0x0
   2be49:	0f 84 c2 81 ff ff    	je     24011 <JS_CallInternal+0x1511>
   2be4f:	49 8b 36             	mov    rsi,QWORD PTR [r14]
   2be52:	48 c1 f8 04          	sar    rax,0x4
   2be56:	4c 39 ee             	cmp    rsi,r13
   2be59:	74 47                	je     2bea2 <JS_CallInternal+0x93a2>
   2be5b:	41 83 45 fc 01       	add    DWORD PTR [r13-0x4],0x1
   2be60:	48 85 f6             	test   rsi,rsi
   2be63:	74 3a                	je     2be9f <JS_CallInternal+0x939f>
   2be65:	48 89 85 38 fe ff ff 	mov    QWORD PTR [rbp-0x1c8],rax
   2be6c:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2be73:	4c 89 85 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],r8
   2be7a:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2be7e:	48 89 95 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],rdx
   2be85:	e8 26 24 ff ff       	call   1e2b0 <js_free_shape>
   2be8a:	48 8b 85 38 fe ff ff 	mov    rax,QWORD PTR [rbp-0x1c8]
   2be91:	4c 8b 85 40 fe ff ff 	mov    r8,QWORD PTR [rbp-0x1c0]
   2be98:	48 8b 95 50 fe ff ff 	mov    rdx,QWORD PTR [rbp-0x1b0]
   2be9f:	4d 89 2e             	mov    QWORD PTR [r14],r13
   2bea2:	41 89 46 08          	mov    DWORD PTR [r14+0x8],eax
   2bea6:	e9 66 81 ff ff       	jmp    24011 <JS_CallInternal+0x1511>
   2beab:	f2 0f 10 05 4d 75 0a 	movsd  xmm0,QWORD PTR [rip+0xa754d]        # d3400 <__PRETTY_FUNCTION__.0+0xc0>
   2beb2:	00 
   2beb3:	e9 08 d7 ff ff       	jmp    295c0 <JS_CallInternal+0x6ac0>
   2beb8:	4d 89 f4             	mov    r12,r14
   2bebb:	e9 e0 73 ff ff       	jmp    232a0 <JS_CallInternal+0x7a0>
   2bec0:	48 8b 8d e8 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x118]
   2bec7:	48 8b 91 88 01 00 00 	mov    rdx,QWORD PTR [rcx+0x188]
   2bece:	48 8b 81 80 01 00 00 	mov    rax,QWORD PTR [rcx+0x180]
   2bed5:	83 fa f6             	cmp    edx,0xfffffff6
   2bed8:	76 04                	jbe    2bede <JS_CallInternal+0x93de>
   2beda:	83 40 fc 01          	add    DWORD PTR [rax-0x4],0x1
   2bede:	48 89 43 d0          	mov    QWORD PTR [rbx-0x30],rax
   2bee2:	48 89 53 d8          	mov    QWORD PTR [rbx-0x28],rdx
   2bee6:	e9 c5 b6 ff ff       	jmp    275b0 <JS_CallInternal+0x4ab0>
   2beeb:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   2bef2:	41 83 fe f9          	cmp    r14d,0xfffffff9
   2bef6:	4c 89 48 30          	mov    QWORD PTR [rax+0x30],r9
   2befa:	0f 84 1f 0d 00 00    	je     2cc1f <JS_CallInternal+0xa11f>
   2bf00:	49 8b 45 00          	mov    rax,QWORD PTR [r13+0x0]
   2bf04:	83 40 fc 01          	add    DWORD PTR [rax-0x4],0x1
   2bf08:	e9 d2 f4 ff ff       	jmp    2b3df <JS_CallInternal+0x88df>
   2bf0d:	48 8b 8d e8 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x118]
   2bf14:	48 89 c6             	mov    rsi,rax
   2bf17:	4c 89 ca             	mov    rdx,r9
   2bf1a:	48 8b 79 10          	mov    rdi,QWORD PTR [rcx+0x10]
   2bf1e:	e8 7d 09 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2bf23:	e9 d6 e0 ff ff       	jmp    29ffe <JS_CallInternal+0x74fe>
   2bf28:	41 81 fd f2 00 00 00 	cmp    r13d,0xf2
   2bf2f:	0f 8f e6 08 00 00    	jg     2c81b <JS_CallInternal+0x9d1b>
   2bf35:	b8 03 00 00 00       	mov    eax,0x3
   2bf3a:	31 c9                	xor    ecx,ecx
   2bf3c:	e9 65 c1 ff ff       	jmp    280a6 <JS_CallInternal+0x55a6>
   2bf41:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2bf48:	48 89 95 38 fe ff ff 	mov    QWORD PTR [rbp-0x1c8],rdx
   2bf4f:	48 63 d7             	movsxd rdx,edi
   2bf52:	48 c1 e2 04          	shl    rdx,0x4
   2bf56:	4c 89 8d 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],r9
   2bf5d:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2bf61:	48 89 d6             	mov    rsi,rdx
   2bf64:	48 89 95 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],rdx
   2bf6b:	e8 e0 89 fe ff       	call   14950 <__js_malloc>
   2bf70:	48 8b 95 50 fe ff ff 	mov    rdx,QWORD PTR [rbp-0x1b0]
   2bf77:	4c 8b 8d 40 fe ff ff 	mov    r9,QWORD PTR [rbp-0x1c0]
   2bf7e:	48 85 c0             	test   rax,rax
   2bf81:	48 8b 8d 38 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x1c8]
   2bf88:	0f 84 5f 0b 00 00    	je     2caed <JS_CallInternal+0x9fed>
   2bf8e:	4c 8b 95 a8 fe ff ff 	mov    r10,QWORD PTR [rbp-0x158]
   2bf95:	31 f6                	xor    esi,esi
   2bf97:	4d 8b 44 32 08       	mov    r8,QWORD PTR [r10+rsi*1+0x8]
   2bf9c:	49 8b 3c 32          	mov    rdi,QWORD PTR [r10+rsi*1]
   2bfa0:	41 83 f8 f6          	cmp    r8d,0xfffffff6
   2bfa4:	76 04                	jbe    2bfaa <JS_CallInternal+0x94aa>
   2bfa6:	83 47 fc 01          	add    DWORD PTR [rdi-0x4],0x1
   2bfaa:	48 89 3c 30          	mov    QWORD PTR [rax+rsi*1],rdi
   2bfae:	4c 89 44 30 08       	mov    QWORD PTR [rax+rsi*1+0x8],r8
   2bfb3:	48 83 c6 10          	add    rsi,0x10
   2bfb7:	48 39 f2             	cmp    rdx,rsi
   2bfba:	75 db                	jne    2bf97 <JS_CallInternal+0x9497>
   2bfbc:	e9 45 95 ff ff       	jmp    25506 <JS_CallInternal+0x2a06>
   2bfc1:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2bfc8:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2bfcc:	e8 cf 08 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2bfd1:	e9 9c da ff ff       	jmp    29a72 <JS_CallInternal+0x6f72>
   2bfd6:	48 8b bd c0 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x140]
   2bfdd:	4c 89 ee             	mov    rsi,r13
   2bfe0:	e8 fb 46 ff ff       	call   206e0 <free_var_ref>
   2bfe5:	e9 a1 72 ff ff       	jmp    2328b <JS_CallInternal+0x78b>
   2bfea:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2bff1:	48 8d 35 28 4d 0a 00 	lea    rsi,[rip+0xa4d28]        # d0d20 <_IO_stdin_used+0x3d20>
   2bff8:	31 c0                	xor    eax,eax
   2bffa:	e8 51 4c 00 00       	call   30c50 <JS_ThrowTypeError>
   2bfff:	e9 9c 72 ff ff       	jmp    232a0 <JS_CallInternal+0x7a0>
   2c004:	8b 85 88 fe ff ff    	mov    eax,DWORD PTR [rbp-0x178]
   2c00a:	83 e8 02             	sub    eax,0x2
   2c00d:	83 f8 01             	cmp    eax,0x1
   2c010:	0f 87 5b 04 00 00    	ja     2c471 <JS_CallInternal+0x9971>
   2c016:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2c01d:	48 8b 88 80 01 00 00 	mov    rcx,QWORD PTR [rax+0x180]
   2c024:	48 8b 80 88 01 00 00 	mov    rax,QWORD PTR [rax+0x188]
   2c02b:	83 f8 f6             	cmp    eax,0xfffffff6
   2c02e:	0f 86 4e 96 ff ff    	jbe    25682 <JS_CallInternal+0x2b82>
   2c034:	83 41 fc 01          	add    DWORD PTR [rcx-0x4],0x1
   2c038:	e9 45 96 ff ff       	jmp    25682 <JS_CallInternal+0x2b82>
   2c03d:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2c044:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2c048:	e8 53 08 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2c04d:	e9 c1 d5 ff ff       	jmp    29613 <JS_CallInternal+0x6b13>
   2c052:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2c059:	4c 89 85 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],r8
   2c060:	4c 89 8d 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],r9
   2c067:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2c06b:	e8 30 08 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2c070:	4c 8b 85 40 fe ff ff 	mov    r8,QWORD PTR [rbp-0x1c0]
   2c077:	4c 8b 8d 50 fe ff ff 	mov    r9,QWORD PTR [rbp-0x1b0]
   2c07e:	e9 ed 8e ff ff       	jmp    24f70 <JS_CallInternal+0x2470>
   2c083:	45 85 ed             	test   r13d,r13d
   2c086:	0f 85 7c dd ff ff    	jne    29e08 <JS_CallInternal+0x7308>
   2c08c:	e9 dc dd ff ff       	jmp    29e6d <JS_CallInternal+0x736d>
   2c091:	48 89 85 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],rax
   2c098:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2c09f:	4c 89 c2             	mov    rdx,r8
   2c0a2:	4c 89 8d 38 fe ff ff 	mov    QWORD PTR [rbp-0x1c8],r9
   2c0a9:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2c0ad:	89 8d 50 fe ff ff    	mov    DWORD PTR [rbp-0x1b0],ecx
   2c0b3:	e8 e8 07 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2c0b8:	4c 8b 8d 38 fe ff ff 	mov    r9,QWORD PTR [rbp-0x1c8]
   2c0bf:	48 8b 85 40 fe ff ff 	mov    rax,QWORD PTR [rbp-0x1c0]
   2c0c6:	8b 8d 50 fe ff ff    	mov    ecx,DWORD PTR [rbp-0x1b0]
   2c0cc:	e9 fe de ff ff       	jmp    29fcf <JS_CallInternal+0x74cf>
   2c0d1:	45 85 db             	test   r11d,r11d
   2c0d4:	0f 85 d9 f1 ff ff    	jne    2b2b3 <JS_CallInternal+0x87b3>
   2c0da:	66 0f ef c9          	pxor   xmm1,xmm1
   2c0de:	f2 41 0f 2a ca       	cvtsi2sd xmm1,r10d
   2c0e3:	66 48 0f 6e c0       	movq   xmm0,rax
   2c0e8:	f2 0f 58 c1          	addsd  xmm0,xmm1
   2c0ec:	48 c7 43 e8 08 00 00 	mov    QWORD PTR [rbx-0x18],0x8
   2c0f3:	00 
   2c0f4:	48 83 eb 10          	sub    rbx,0x10
   2c0f8:	f2 0f 11 43 f0       	movsd  QWORD PTR [rbx-0x10],xmm0
   2c0fd:	e9 74 af ff ff       	jmp    27076 <JS_CallInternal+0x4576>
   2c102:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2c109:	4c 89 ee             	mov    rsi,r13
   2c10c:	4c 89 f2             	mov    rdx,r14
   2c10f:	89 8d 40 fe ff ff    	mov    DWORD PTR [rbp-0x1c0],ecx
   2c115:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2c119:	e8 82 07 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2c11e:	8b 8d 40 fe ff ff    	mov    ecx,DWORD PTR [rbp-0x1c0]
   2c124:	4c 8b 95 50 fe ff ff 	mov    r10,QWORD PTR [rbp-0x1b0]
   2c12b:	e9 5d da ff ff       	jmp    29b8d <JS_CallInternal+0x708d>
   2c130:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2c137:	48 89 8d 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],rcx
   2c13e:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2c142:	e8 59 07 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2c147:	48 8b 8d 50 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x1b0]
   2c14e:	e9 4a d4 ff ff       	jmp    2959d <JS_CallInternal+0x6a9d>
   2c153:	83 f9 f6             	cmp    ecx,0xfffffff6
   2c156:	0f 86 ef f3 ff ff    	jbe    2b54b <JS_CallInternal+0x8a4b>
   2c15c:	41 8b 40 fc          	mov    eax,DWORD PTR [r8-0x4]
   2c160:	83 e8 01             	sub    eax,0x1
   2c163:	41 89 40 fc          	mov    DWORD PTR [r8-0x4],eax
   2c167:	85 c0                	test   eax,eax
   2c169:	0f 8f dc f3 ff ff    	jg     2b54b <JS_CallInternal+0x8a4b>
   2c16f:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2c176:	4c 89 c6             	mov    rsi,r8
   2c179:	48 89 ca             	mov    rdx,rcx
   2c17c:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2c180:	e8 1b 07 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2c185:	e9 c1 f3 ff ff       	jmp    2b54b <JS_CallInternal+0x8a4b>
   2c18a:	89 c8                	mov    eax,ecx
   2c18c:	31 d2                	xor    edx,edx
   2c18e:	e9 7c b1 ff ff       	jmp    2730f <JS_CallInternal+0x480f>
   2c193:	48 8b 8d e8 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x118]
   2c19a:	48 8d 45 80          	lea    rax,[rbp-0x80]
   2c19e:	89 f2                	mov    edx,esi
   2c1a0:	48 89 c6             	mov    rsi,rax
   2c1a3:	48 8b 79 10          	mov    rdi,QWORD PTR [rcx+0x10]
   2c1a7:	e8 64 b1 fe ff       	call   17310 <JS_AtomGetStrRT.constprop.0>
   2c1ac:	48 89 c2             	mov    rdx,rax
   2c1af:	e9 24 83 ff ff       	jmp    244d8 <JS_CallInternal+0x19d8>
   2c1b4:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2c1bb:	48 89 8d 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],rcx
   2c1c2:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2c1c6:	e8 d5 06 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2c1cb:	48 8b 8d 50 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x1b0]
   2c1d2:	e9 4b d6 ff ff       	jmp    29822 <JS_CallInternal+0x6d22>
   2c1d7:	8b 12                	mov    edx,DWORD PTR [rdx]
   2c1d9:	81 e2 ff ff ff 03    	and    edx,0x3ffffff
   2c1df:	0f 85 8f ab ff ff    	jne    26d74 <JS_CallInternal+0x4274>
   2c1e5:	31 d2                	xor    edx,edx
   2c1e7:	e9 98 ab ff ff       	jmp    26d84 <JS_CallInternal+0x4284>
   2c1ec:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2c1f3:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2c1f7:	e8 a4 06 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2c1fc:	e9 d5 b2 ff ff       	jmp    274d6 <JS_CallInternal+0x49d6>
   2c201:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2c208:	48 8d 35 68 13 0a 00 	lea    rsi,[rip+0xa1368]        # cd577 <_IO_stdin_used+0x577>
   2c20f:	31 c0                	xor    eax,eax
   2c211:	e8 3a 4a 00 00       	call   30c50 <JS_ThrowTypeError>
   2c216:	e9 85 70 ff ff       	jmp    232a0 <JS_CallInternal+0x7a0>
   2c21b:	66 0f ef c9          	pxor   xmm1,xmm1
   2c21f:	f2 0f 2a ca          	cvtsi2sd xmm1,edx
   2c223:	66 48 0f 6e c0       	movq   xmm0,rax
   2c228:	31 c0                	xor    eax,eax
   2c22a:	66 0f 2f c8          	comisd xmm1,xmm0
   2c22e:	48 c7 43 e8 01 00 00 	mov    QWORD PTR [rbx-0x18],0x1
   2c235:	00 
   2c236:	0f 97 c0             	seta   al
   2c239:	48 83 eb 10          	sub    rbx,0x10
   2c23d:	48 89 43 f0          	mov    QWORD PTR [rbx-0x10],rax
   2c241:	e9 7c b9 ff ff       	jmp    27bc2 <JS_CallInternal+0x50c2>
   2c246:	83 c1 07             	add    ecx,0x7
   2c249:	83 f9 01             	cmp    ecx,0x1
   2c24c:	0f 87 61 f0 ff ff    	ja     2b2b3 <JS_CallInternal+0x87b3>
   2c252:	4c 89 c1             	mov    rcx,r8
   2c255:	49 89 f8             	mov    r8,rdi
   2c258:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2c25f:	4c 89 d6             	mov    rsi,r10
   2c262:	4c 89 da             	mov    rdx,r11
   2c265:	e8 b6 3f 01 00       	call   40220 <JS_ConcatString>
   2c26a:	48 89 43 e0          	mov    QWORD PTR [rbx-0x20],rax
   2c26e:	48 8d 43 f0          	lea    rax,[rbx-0x10]
   2c272:	48 89 53 e8          	mov    QWORD PTR [rbx-0x18],rdx
   2c276:	83 7b e8 06          	cmp    DWORD PTR [rbx-0x18],0x6
   2c27a:	48 89 c3             	mov    rbx,rax
   2c27d:	0f 85 f3 ad ff ff    	jne    27076 <JS_CallInternal+0x4576>
   2c283:	e9 18 70 ff ff       	jmp    232a0 <JS_CallInternal+0x7a0>
   2c288:	66 48 0f 6e ca       	movq   xmm1,rdx
   2c28d:	83 f9 08             	cmp    ecx,0x8
   2c290:	74 36                	je     2c2c8 <JS_CallInternal+0x97c8>
   2c292:	85 c9                	test   ecx,ecx
   2c294:	0f 85 d0 f0 ff ff    	jne    2b36a <JS_CallInternal+0x886a>
   2c29a:	66 0f ef c0          	pxor   xmm0,xmm0
   2c29e:	f2 0f 2a c0          	cvtsi2sd xmm0,eax
   2c2a2:	31 c0                	xor    eax,eax
   2c2a4:	66 0f 2f c8          	comisd xmm1,xmm0
   2c2a8:	48 c7 43 e8 01 00 00 	mov    QWORD PTR [rbx-0x18],0x1
   2c2af:	00 
   2c2b0:	0f 93 c0             	setae  al
   2c2b3:	48 83 eb 10          	sub    rbx,0x10
   2c2b7:	48 89 43 f0          	mov    QWORD PTR [rbx-0x10],rax
   2c2bb:	e9 8b b4 ff ff       	jmp    2774b <JS_CallInternal+0x4c4b>
   2c2c0:	66 0f ef c9          	pxor   xmm1,xmm1
   2c2c4:	f2 0f 2a ca          	cvtsi2sd xmm1,edx
   2c2c8:	66 48 0f 6e c0       	movq   xmm0,rax
   2c2cd:	eb d3                	jmp    2c2a2 <JS_CallInternal+0x97a2>
   2c2cf:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2c2d6:	48 8d 35 75 12 0a 00 	lea    rsi,[rip+0xa1275]        # cd552 <_IO_stdin_used+0x552>
   2c2dd:	31 c0                	xor    eax,eax
   2c2df:	e8 6c 49 00 00       	call   30c50 <JS_ThrowTypeError>
   2c2e4:	e9 b7 6f ff ff       	jmp    232a0 <JS_CallInternal+0x7a0>
   2c2e9:	48 8b bd a0 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x160]
   2c2f0:	48 8d 35 e9 49 0a 00 	lea    rsi,[rip+0xa49e9]        # d0ce0 <_IO_stdin_used+0x3ce0>
   2c2f7:	31 c0                	xor    eax,eax
   2c2f9:	e8 52 49 00 00       	call   30c50 <JS_ThrowTypeError>
   2c2fe:	e9 9d 6f ff ff       	jmp    232a0 <JS_CallInternal+0x7a0>
   2c303:	66 49 0f 6e ca       	movq   xmm1,r10
   2c308:	83 ff 08             	cmp    edi,0x8
   2c30b:	0f 84 d2 fd ff ff    	je     2c0e3 <JS_CallInternal+0x95e3>
   2c311:	85 ff                	test   edi,edi
   2c313:	0f 85 9a ef ff ff    	jne    2b2b3 <JS_CallInternal+0x87b3>
   2c319:	66 0f ef c0          	pxor   xmm0,xmm0
   2c31d:	f2 41 0f 2a c0       	cvtsi2sd xmm0,r8d
   2c322:	e9 c1 fd ff ff       	jmp    2c0e8 <JS_CallInternal+0x95e8>
   2c327:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2c32e:	48 8d 35 93 4a 0a 00 	lea    rsi,[rip+0xa4a93]        # d0dc8 <_IO_stdin_used+0x3dc8>
   2c335:	31 c0                	xor    eax,eax
   2c337:	e8 14 49 00 00       	call   30c50 <JS_ThrowTypeError>
   2c33c:	e9 5f 6f ff ff       	jmp    232a0 <JS_CallInternal+0x7a0>
   2c341:	66 48 0f 6e ca       	movq   xmm1,rdx
   2c346:	83 f9 08             	cmp    ecx,0x8
   2c349:	0f 84 d4 fe ff ff    	je     2c223 <JS_CallInternal+0x9723>
   2c34f:	85 c9                	test   ecx,ecx
   2c351:	0f 85 f7 ee ff ff    	jne    2b24e <JS_CallInternal+0x874e>
   2c357:	66 0f ef c0          	pxor   xmm0,xmm0
   2c35b:	f2 0f 2a c0          	cvtsi2sd xmm0,eax
   2c35f:	e9 c4 fe ff ff       	jmp    2c228 <JS_CallInternal+0x9728>
   2c364:	4d 89 ec             	mov    r12,r13
   2c367:	e9 34 6f ff ff       	jmp    232a0 <JS_CallInternal+0x7a0>
   2c36c:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2c373:	48 8d 35 27 12 0a 00 	lea    rsi,[rip+0xa1227]        # cd5a1 <_IO_stdin_used+0x5a1>
   2c37a:	31 c0                	xor    eax,eax
   2c37c:	e8 cf 48 00 00       	call   30c50 <JS_ThrowTypeError>
   2c381:	e9 1a 6f ff ff       	jmp    232a0 <JS_CallInternal+0x7a0>
   2c386:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2c38d:	4c 89 ee             	mov    rsi,r13
   2c390:	48 89 da             	mov    rdx,rbx
   2c393:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2c397:	e8 04 05 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2c39c:	e9 a3 f2 ff ff       	jmp    2b644 <JS_CallInternal+0x8b44>
   2c3a1:	4d 89 c1             	mov    r9,r8
   2c3a4:	48 89 d7             	mov    rdi,rdx
   2c3a7:	45 31 c0             	xor    r8d,r8d
   2c3aa:	4c 89 ea             	mov    rdx,r13
   2c3ad:	4c 89 ce             	mov    rsi,r9
   2c3b0:	4c 89 f1             	mov    rcx,r14
   2c3b3:	48 89 bd 38 fe ff ff 	mov    QWORD PTR [rbp-0x1c8],rdi
   2c3ba:	4c 89 8d 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],r9
   2c3c1:	e8 0a e1 fe ff       	call   1a4d0 <js_strict_eq2.isra.0>
   2c3c6:	48 8b b5 38 fe ff ff 	mov    rsi,QWORD PTR [rbp-0x1c8]
   2c3cd:	48 8b 95 40 fe ff ff 	mov    rdx,QWORD PTR [rbp-0x1c0]
   2c3d4:	89 85 50 fe ff ff    	mov    DWORD PTR [rbp-0x1b0],eax
   2c3da:	e9 34 f3 ff ff       	jmp    2b713 <JS_CallInternal+0x8c13>
   2c3df:	31 c0                	xor    eax,eax
   2c3e1:	41 83 fe ff          	cmp    r14d,0xffffffff
   2c3e5:	75 08                	jne    2c3ef <JS_CallInternal+0x98ef>
   2c3e7:	31 c0                	xor    eax,eax
   2c3e9:	4c 39 ea             	cmp    rdx,r13
   2c3ec:	0f 94 c0             	sete   al
   2c3ef:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2c3f6:	48 89 d6             	mov    rsi,rdx
   2c3f9:	4c 89 c2             	mov    rdx,r8
   2c3fc:	89 85 50 fe ff ff    	mov    DWORD PTR [rbp-0x1b0],eax
   2c402:	e8 f9 05 ff ff       	call   1ca00 <JS_FreeValue>
   2c407:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2c40e:	4c 89 ee             	mov    rsi,r13
   2c411:	4c 89 f2             	mov    rdx,r14
   2c414:	e8 e7 05 ff ff       	call   1ca00 <JS_FreeValue>
   2c419:	48 63 85 50 fe ff ff 	movsxd rax,DWORD PTR [rbp-0x1b0]
   2c420:	e9 8e b5 ff ff       	jmp    279b3 <JS_CallInternal+0x4eb3>
   2c425:	45 85 f6             	test   r14d,r14d
   2c428:	0f 85 a3 01 00 00    	jne    2c5d1 <JS_CallInternal+0x9ad1>
   2c42e:	66 0f ef c0          	pxor   xmm0,xmm0
   2c432:	66 48 0f 6e e2       	movq   xmm4,rdx
   2c437:	31 c0                	xor    eax,eax
   2c439:	ba 00 00 00 00       	mov    edx,0x0
   2c43e:	f2 41 0f 2a c5       	cvtsi2sd xmm0,r13d
   2c443:	66 0f 2e c4          	ucomisd xmm0,xmm4
   2c447:	0f 9b c0             	setnp  al
   2c44a:	48 0f 45 c2          	cmovne rax,rdx
   2c44e:	e9 60 b5 ff ff       	jmp    279b3 <JS_CallInternal+0x4eb3>
   2c453:	48 8b 8d e8 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x118]
   2c45a:	89 c2                	mov    edx,eax
   2c45c:	48 8d 75 80          	lea    rsi,[rbp-0x80]
   2c460:	48 8b 79 10          	mov    rdi,QWORD PTR [rcx+0x10]
   2c464:	e8 a7 ae fe ff       	call   17310 <JS_AtomGetStrRT.constprop.0>
   2c469:	48 89 c2             	mov    rdx,rax
   2c46c:	e9 b0 e9 ff ff       	jmp    2ae21 <JS_CallInternal+0x8321>
   2c471:	48 8b b5 78 fe ff ff 	mov    rsi,QWORD PTR [rbp-0x188]
   2c478:	48 8b 95 88 fe ff ff 	mov    rdx,QWORD PTR [rbp-0x178]
   2c47f:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2c486:	e8 f5 e1 01 00       	call   4a680 <JS_ToObject>
   2c48b:	48 89 c1             	mov    rcx,rax
   2c48e:	48 89 d0             	mov    rax,rdx
   2c491:	83 fa 06             	cmp    edx,0x6
   2c494:	0f 85 e8 91 ff ff    	jne    25682 <JS_CallInternal+0x2b82>
   2c49a:	e9 01 6e ff ff       	jmp    232a0 <JS_CallInternal+0x7a0>
   2c49f:	48 89 85 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],rax
   2c4a6:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2c4ad:	4c 89 85 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],r8
   2c4b4:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2c4b8:	e8 e3 03 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2c4bd:	4c 8b 85 40 fe ff ff 	mov    r8,QWORD PTR [rbp-0x1c0]
   2c4c4:	48 8b 85 50 fe ff ff 	mov    rax,QWORD PTR [rbp-0x1b0]
   2c4cb:	e9 95 d9 ff ff       	jmp    29e65 <JS_CallInternal+0x7365>
   2c4d0:	4d 89 ec             	mov    r12,r13
   2c4d3:	e9 c8 6d ff ff       	jmp    232a0 <JS_CallInternal+0x7a0>
   2c4d8:	41 8d 50 fe          	lea    edx,[r8-0x2]
   2c4dc:	83 fa 01             	cmp    edx,0x1
   2c4df:	0f 86 c4 06 00 00    	jbe    2cba9 <JS_CallInternal+0xa0a9>
   2c4e5:	83 c0 01             	add    eax,0x1
   2c4e8:	0f 85 12 dc ff ff    	jne    2a100 <JS_CallInternal+0x7600>
   2c4ee:	41 0f b6 41 11       	movzx  eax,BYTE PTR [r9+0x11]
   2c4f3:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2c4fa:	4c 89 c2             	mov    rdx,r8
   2c4fd:	c0 e8 02             	shr    al,0x2
   2c500:	83 e0 01             	and    eax,0x1
   2c503:	89 85 50 fe ff ff    	mov    DWORD PTR [rbp-0x1b0],eax
   2c509:	e8 f2 04 ff ff       	call   1ca00 <JS_FreeValue>
   2c50e:	8b 85 50 fe ff ff    	mov    eax,DWORD PTR [rbp-0x1b0]
   2c514:	e9 fc a3 ff ff       	jmp    26915 <JS_CallInternal+0x3e15>
   2c519:	41 8d 50 fe          	lea    edx,[r8-0x2]
   2c51d:	83 fa 01             	cmp    edx,0x1
   2c520:	0f 86 8d 06 00 00    	jbe    2cbb3 <JS_CallInternal+0xa0b3>
   2c526:	83 c0 01             	add    eax,0x1
   2c529:	0f 85 d1 db ff ff    	jne    2a100 <JS_CallInternal+0x7600>
   2c52f:	31 c0                	xor    eax,eax
   2c531:	4d 39 ce             	cmp    r14,r9
   2c534:	4c 89 85 38 fe ff ff 	mov    QWORD PTR [rbp-0x1c8],r8
   2c53b:	4c 89 8d 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],r9
   2c542:	0f 94 c0             	sete   al
   2c545:	e9 8e eb ff ff       	jmp    2b0d8 <JS_CallInternal+0x85d8>
   2c54a:	45 85 c0             	test   r8d,r8d
   2c54d:	0f 85 eb 00 00 00    	jne    2c63e <JS_CallInternal+0x9b3e>
   2c553:	66 0f ef c0          	pxor   xmm0,xmm0
   2c557:	66 49 0f 6e ce       	movq   xmm1,r14
   2c55c:	31 d2                	xor    edx,edx
   2c55e:	f2 41 0f 2a c1       	cvtsi2sd xmm0,r9d
   2c563:	66 0f 2e c1          	ucomisd xmm0,xmm1
   2c567:	0f 9b c2             	setnp  dl
   2c56a:	0f 44 c2             	cmove  eax,edx
   2c56d:	e9 a3 a3 ff ff       	jmp    26915 <JS_CallInternal+0x3e15>
   2c572:	48 8b 85 c0 fe ff ff 	mov    rax,QWORD PTR [rbp-0x140]
   2c579:	48 8b 8d d8 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x128]
   2c580:	31 d2                	xor    edx,edx
   2c582:	f3 0f 6f 90 d8 04 00 	movdqu xmm2,XMMWORD PTR [rax+0x4d8]
   2c589:	00 
   2c58a:	0f 11 53 f0          	movups XMMWORD PTR [rbx-0x10],xmm2
   2c58e:	0f 29 95 50 fe ff ff 	movaps XMMWORD PTR [rbp-0x1b0],xmm2
   2c595:	48 89 90 d8 04 00 00 	mov    QWORD PTR [rax+0x4d8],rdx
   2c59c:	48 c7 80 e0 04 00 00 	mov    QWORD PTR [rax+0x4e0],0x4
   2c5a3:	04 00 00 00 
   2c5a7:	49 63 c5             	movsxd rax,r13d
   2c5aa:	48 03 41 18          	add    rax,QWORD PTR [rcx+0x18]
   2c5ae:	e9 0e 68 ff ff       	jmp    22dc1 <JS_CallInternal+0x2c1>
   2c5b3:	48 8b 8d e8 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x118]
   2c5ba:	89 c2                	mov    edx,eax
   2c5bc:	48 8d 75 80          	lea    rsi,[rbp-0x80]
   2c5c0:	48 8b 79 10          	mov    rdi,QWORD PTR [rcx+0x10]
   2c5c4:	e8 47 ad fe ff       	call   17310 <JS_AtomGetStrRT.constprop.0>
   2c5c9:	48 89 c2             	mov    rdx,rax
   2c5cc:	e9 8b e8 ff ff       	jmp    2ae5c <JS_CallInternal+0x835c>
   2c5d1:	41 83 fe 08          	cmp    r14d,0x8
   2c5d5:	0f 85 23 06 00 00    	jne    2cbfe <JS_CallInternal+0xa0fe>
   2c5db:	66 48 0f 6e c2       	movq   xmm0,rdx
   2c5e0:	66 49 0f 6e ed       	movq   xmm5,r13
   2c5e5:	31 c0                	xor    eax,eax
   2c5e7:	ba 00 00 00 00       	mov    edx,0x0
   2c5ec:	66 0f 2e c5          	ucomisd xmm0,xmm5
   2c5f0:	0f 9b c0             	setnp  al
   2c5f3:	48 0f 45 c2          	cmovne rax,rdx
   2c5f7:	e9 b7 b3 ff ff       	jmp    279b3 <JS_CallInternal+0x4eb3>
   2c5fc:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2c603:	48 89 ce             	mov    rsi,rcx
   2c606:	48 89 da             	mov    rdx,rbx
   2c609:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2c60d:	e8 8e 02 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2c612:	e9 51 db ff ff       	jmp    2a168 <JS_CallInternal+0x7668>
   2c617:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2c61e:	4c 89 c6             	mov    rsi,r8
   2c621:	4c 89 e2             	mov    rdx,r12
   2c624:	89 8d 40 fe ff ff    	mov    DWORD PTR [rbp-0x1c0],ecx
   2c62a:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2c62e:	e8 6d 02 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2c633:	8b 8d 40 fe ff ff    	mov    ecx,DWORD PTR [rbp-0x1c0]
   2c639:	e9 df c8 ff ff       	jmp    28f1d <JS_CallInternal+0x641d>
   2c63e:	41 83 f8 08          	cmp    r8d,0x8
   2c642:	0f 85 b8 da ff ff    	jne    2a100 <JS_CallInternal+0x7600>
   2c648:	66 49 0f 6e c6       	movq   xmm0,r14
   2c64d:	66 49 0f 6e d1       	movq   xmm2,r9
   2c652:	31 c0                	xor    eax,eax
   2c654:	ba 00 00 00 00       	mov    edx,0x0
   2c659:	66 0f 2e c2          	ucomisd xmm0,xmm2
   2c65d:	0f 9b c0             	setnp  al
   2c660:	0f 45 c2             	cmovne eax,edx
   2c663:	e9 ad a2 ff ff       	jmp    26915 <JS_CallInternal+0x3e15>
   2c668:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2c66f:	48 8b 95 38 fe ff ff 	mov    rdx,QWORD PTR [rbp-0x1c8]
   2c676:	48 89 ce             	mov    rsi,rcx
   2c679:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2c67d:	e8 1e 02 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2c682:	e9 08 db ff ff       	jmp    2a18f <JS_CallInternal+0x768f>
   2c687:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2c68e:	48 8b 95 50 fe ff ff 	mov    rdx,QWORD PTR [rbp-0x1b0]
   2c695:	4c 89 ee             	mov    rsi,r13
   2c698:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2c69c:	e8 ff 01 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2c6a1:	e9 b2 a3 ff ff       	jmp    26a58 <JS_CallInternal+0x3f58>
   2c6a6:	41 83 fe 08          	cmp    r14d,0x8
   2c6aa:	0f 84 8c 03 00 00    	je     2ca3c <JS_CallInternal+0x9f3c>
   2c6b0:	48 8b 85 c8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x138]
   2c6b7:	4c 89 48 30          	mov    QWORD PTR [rax+0x30],r9
   2c6bb:	49 8b 45 00          	mov    rax,QWORD PTR [r13+0x0]
   2c6bf:	e9 1b ed ff ff       	jmp    2b3df <JS_CallInternal+0x88df>
   2c6c4:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2c6cb:	48 8d 35 f6 0d 0a 00 	lea    rsi,[rip+0xa0df6]        # cd4c8 <_IO_stdin_used+0x4c8>
   2c6d2:	31 c0                	xor    eax,eax
   2c6d4:	e8 77 45 00 00       	call   30c50 <JS_ThrowTypeError>
   2c6d9:	e9 c2 6b ff ff       	jmp    232a0 <JS_CallInternal+0x7a0>
   2c6de:	41 8d 50 fe          	lea    edx,[r8-0x2]
   2c6e2:	83 fa 01             	cmp    edx,0x1
   2c6e5:	0f 86 6f 03 00 00    	jbe    2ca5a <JS_CallInternal+0x9f5a>
   2c6eb:	83 c0 01             	add    eax,0x1
   2c6ee:	0f 85 da d9 ff ff    	jne    2a0ce <JS_CallInternal+0x75ce>
   2c6f4:	4d 39 ce             	cmp    r14,r9
   2c6f7:	4c 89 f6             	mov    rsi,r14
   2c6fa:	4c 8b b5 e8 fe ff ff 	mov    r14,QWORD PTR [rbp-0x118]
   2c701:	4c 89 ea             	mov    rdx,r13
   2c704:	0f 94 c0             	sete   al
   2c707:	4c 89 85 38 fe ff ff 	mov    QWORD PTR [rbp-0x1c8],r8
   2c70e:	4c 89 f7             	mov    rdi,r14
   2c711:	88 85 50 fe ff ff    	mov    BYTE PTR [rbp-0x1b0],al
   2c717:	4c 89 8d 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],r9
   2c71e:	e8 dd 02 ff ff       	call   1ca00 <JS_FreeValue>
   2c723:	48 8b b5 40 fe ff ff 	mov    rsi,QWORD PTR [rbp-0x1c0]
   2c72a:	48 8b 95 38 fe ff ff 	mov    rdx,QWORD PTR [rbp-0x1c8]
   2c731:	4c 89 f7             	mov    rdi,r14
   2c734:	e8 c7 02 ff ff       	call   1ca00 <JS_FreeValue>
   2c739:	0f b6 85 50 fe ff ff 	movzx  eax,BYTE PTR [rbp-0x1b0]
   2c740:	e9 30 a2 ff ff       	jmp    26975 <JS_CallInternal+0x3e75>
   2c745:	45 85 c0             	test   r8d,r8d
   2c748:	0f 85 87 00 00 00    	jne    2c7d5 <JS_CallInternal+0x9cd5>
   2c74e:	66 0f ef c0          	pxor   xmm0,xmm0
   2c752:	66 49 0f 6e ee       	movq   xmm5,r14
   2c757:	ba 00 00 00 00       	mov    edx,0x0
   2c75c:	f2 41 0f 2a c1       	cvtsi2sd xmm0,r9d
   2c761:	66 0f 2e c5          	ucomisd xmm0,xmm5
   2c765:	0f 9b c0             	setnp  al
   2c768:	0f 45 c2             	cmovne eax,edx
   2c76b:	e9 05 a2 ff ff       	jmp    26975 <JS_CallInternal+0x3e75>
   2c770:	41 8d 50 fe          	lea    edx,[r8-0x2]
   2c774:	83 fa 01             	cmp    edx,0x1
   2c777:	0f 86 0c 03 00 00    	jbe    2ca89 <JS_CallInternal+0x9f89>
   2c77d:	83 c0 01             	add    eax,0x1
   2c780:	0f 85 48 d9 ff ff    	jne    2a0ce <JS_CallInternal+0x75ce>
   2c786:	41 0f b6 41 11       	movzx  eax,BYTE PTR [r9+0x11]
   2c78b:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2c792:	4c 89 c2             	mov    rdx,r8
   2c795:	c0 e8 02             	shr    al,0x2
   2c798:	83 e0 01             	and    eax,0x1
   2c79b:	88 85 50 fe ff ff    	mov    BYTE PTR [rbp-0x1b0],al
   2c7a1:	e8 5a 02 ff ff       	call   1ca00 <JS_FreeValue>
   2c7a6:	0f b6 85 50 fe ff ff 	movzx  eax,BYTE PTR [rbp-0x1b0]
   2c7ad:	e9 c3 a1 ff ff       	jmp    26975 <JS_CallInternal+0x3e75>
   2c7b2:	66 48 0f 6e c9       	movq   xmm1,rcx
   2c7b7:	83 f8 08             	cmp    eax,0x8
   2c7ba:	0f 84 df f2 ff ff    	je     2ba9f <JS_CallInternal+0x8f9f>
   2c7c0:	85 c0                	test   eax,eax
   2c7c2:	0f 85 2f 74 ff ff    	jne    23bf7 <JS_CallInternal+0x10f7>
   2c7c8:	66 0f ef c0          	pxor   xmm0,xmm0
   2c7cc:	f2 0f 2a c2          	cvtsi2sd xmm0,edx
   2c7d0:	e9 cf f2 ff ff       	jmp    2baa4 <JS_CallInternal+0x8fa4>
   2c7d5:	41 83 f8 08          	cmp    r8d,0x8
   2c7d9:	0f 85 ef d8 ff ff    	jne    2a0ce <JS_CallInternal+0x75ce>
   2c7df:	66 49 0f 6e c6       	movq   xmm0,r14
   2c7e4:	66 49 0f 6e f1       	movq   xmm6,r9
   2c7e9:	ba 00 00 00 00       	mov    edx,0x0
   2c7ee:	66 0f 2e c6          	ucomisd xmm0,xmm6
   2c7f2:	0f 9b c0             	setnp  al
   2c7f5:	0f 45 c2             	cmovne eax,edx
   2c7f8:	e9 78 a1 ff ff       	jmp    26975 <JS_CallInternal+0x3e75>
   2c7fd:	31 c0                	xor    eax,eax
   2c7ff:	48 c7 43 08 03 00 00 	mov    QWORD PTR [rbx+0x8],0x3
   2c806:	00 
   2c807:	48 89 03             	mov    QWORD PTR [rbx],rax
   2c80a:	e9 90 8b ff ff       	jmp    2539f <JS_CallInternal+0x289f>
   2c80f:	48 89 03             	mov    QWORD PTR [rbx],rax
   2c812:	48 89 53 08          	mov    QWORD PTR [rbx+0x8],rdx
   2c816:	e9 30 8c ff ff       	jmp    2544b <JS_CallInternal+0x294b>
   2c81b:	48 8b 87 48 04 00 00 	mov    rax,QWORD PTR [rdi+0x448]
   2c822:	4a 8b 34 e8          	mov    rsi,QWORD PTR [rax+r13*8]
   2c826:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   2c829:	83 e8 01             	sub    eax,0x1
   2c82c:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   2c82f:	85 c0                	test   eax,eax
   2c831:	0f 8f fe f6 ff ff    	jg     2bf35 <JS_CallInternal+0x9435>
   2c837:	e8 c4 8b fe ff       	call   15400 <JS_FreeAtomStruct>
   2c83c:	e9 f4 f6 ff ff       	jmp    2bf35 <JS_CallInternal+0x9435>
   2c841:	b8 03 00 00 00       	mov    eax,0x3
   2c846:	31 c9                	xor    ecx,ecx
   2c848:	e9 2d 6e ff ff       	jmp    2367a <JS_CallInternal+0xb7a>
   2c84d:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2c854:	48 8b 95 50 fe ff ff 	mov    rdx,QWORD PTR [rbp-0x1b0]
   2c85b:	4c 89 ee             	mov    rsi,r13
   2c85e:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2c862:	e8 39 00 ff ff       	call   1c8a0 <__JS_FreeValueRT>
   2c867:	e9 6f ec ff ff       	jmp    2b4db <JS_CallInternal+0x89db>
   2c86c:	66 48 0f 6e c0       	movq   xmm0,rax
   2c871:	83 f9 08             	cmp    ecx,0x8
   2c874:	74 36                	je     2c8ac <JS_CallInternal+0x9dac>
   2c876:	85 c9                	test   ecx,ecx
   2c878:	0f 85 96 f0 ff ff    	jne    2b914 <JS_CallInternal+0x8e14>
   2c87e:	66 0f ef c9          	pxor   xmm1,xmm1
   2c882:	f2 0f 2a ca          	cvtsi2sd xmm1,edx
   2c886:	31 c0                	xor    eax,eax
   2c888:	66 0f 2f c8          	comisd xmm1,xmm0
   2c88c:	48 c7 43 e8 01 00 00 	mov    QWORD PTR [rbx-0x18],0x1
   2c893:	00 
   2c894:	0f 93 c0             	setae  al
   2c897:	48 83 eb 10          	sub    rbx,0x10
   2c89b:	48 89 43 f0          	mov    QWORD PTR [rbx-0x10],rax
   2c89f:	e9 f8 a8 ff ff       	jmp    2719c <JS_CallInternal+0x469c>
   2c8a4:	66 0f ef c0          	pxor   xmm0,xmm0
   2c8a8:	f2 0f 2a c0          	cvtsi2sd xmm0,eax
   2c8ac:	66 48 0f 6e ca       	movq   xmm1,rdx
   2c8b1:	eb d3                	jmp    2c886 <JS_CallInternal+0x9d86>
   2c8b3:	48 89 d7             	mov    rdi,rdx
   2c8b6:	4c 89 ce             	mov    rsi,r9
   2c8b9:	45 31 c0             	xor    r8d,r8d
   2c8bc:	4c 89 ea             	mov    rdx,r13
   2c8bf:	4c 89 f1             	mov    rcx,r14
   2c8c2:	4c 89 8d 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],r9
   2c8c9:	48 89 bd 38 fe ff ff 	mov    QWORD PTR [rbp-0x1c8],rdi
   2c8d0:	e8 fb db fe ff       	call   1a4d0 <js_strict_eq2.isra.0>
   2c8d5:	48 8b b5 38 fe ff ff 	mov    rsi,QWORD PTR [rbp-0x1c8]
   2c8dc:	4c 8b 8d 40 fe ff ff 	mov    r9,QWORD PTR [rbp-0x1c0]
   2c8e3:	89 85 50 fe ff ff    	mov    DWORD PTR [rbp-0x1b0],eax
   2c8e9:	e9 72 e4 ff ff       	jmp    2ad60 <JS_CallInternal+0x8260>
   2c8ee:	31 c0                	xor    eax,eax
   2c8f0:	41 83 fe ff          	cmp    r14d,0xffffffff
   2c8f4:	75 08                	jne    2c8fe <JS_CallInternal+0x9dfe>
   2c8f6:	31 c0                	xor    eax,eax
   2c8f8:	4c 39 ea             	cmp    rdx,r13
   2c8fb:	0f 94 c0             	sete   al
   2c8fe:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2c905:	48 89 d6             	mov    rsi,rdx
   2c908:	4c 89 ca             	mov    rdx,r9
   2c90b:	89 85 50 fe ff ff    	mov    DWORD PTR [rbp-0x1b0],eax
   2c911:	e8 ea 00 ff ff       	call   1ca00 <JS_FreeValue>
   2c916:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2c91d:	4c 89 ee             	mov    rsi,r13
   2c920:	4c 89 f2             	mov    rdx,r14
   2c923:	e8 d8 00 ff ff       	call   1ca00 <JS_FreeValue>
   2c928:	8b 85 50 fe ff ff    	mov    eax,DWORD PTR [rbp-0x1b0]
   2c92e:	83 f0 01             	xor    eax,0x1
   2c931:	48 98                	cdqe
   2c933:	e9 27 b0 ff ff       	jmp    2795f <JS_CallInternal+0x4e5f>
   2c938:	45 85 f6             	test   r14d,r14d
   2c93b:	75 72                	jne    2c9af <JS_CallInternal+0x9eaf>
   2c93d:	66 0f ef c0          	pxor   xmm0,xmm0
   2c941:	66 48 0f 6e fa       	movq   xmm7,rdx
   2c946:	31 c0                	xor    eax,eax
   2c948:	ba 01 00 00 00       	mov    edx,0x1
   2c94d:	f2 41 0f 2a c5       	cvtsi2sd xmm0,r13d
   2c952:	66 0f 2e c7          	ucomisd xmm0,xmm7
   2c956:	0f 9a c0             	setp   al
   2c959:	48 0f 45 c2          	cmovne rax,rdx
   2c95d:	e9 fd af ff ff       	jmp    2795f <JS_CallInternal+0x4e5f>
   2c962:	66 48 0f 6e c7       	movq   xmm0,rdi
   2c967:	83 f8 08             	cmp    eax,0x8
   2c96a:	0f 84 8b ec ff ff    	je     2b5fb <JS_CallInternal+0x8afb>
   2c970:	85 c0                	test   eax,eax
   2c972:	0f 85 7f 72 ff ff    	jne    23bf7 <JS_CallInternal+0x10f7>
   2c978:	66 0f ef c9          	pxor   xmm1,xmm1
   2c97c:	f2 0f 2a c9          	cvtsi2sd xmm1,ecx
   2c980:	e9 7b ec ff ff       	jmp    2b600 <JS_CallInternal+0x8b00>
   2c985:	48 8b 8d e8 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x118]
   2c98c:	89 c2                	mov    edx,eax
   2c98e:	48 8d 75 80          	lea    rsi,[rbp-0x80]
   2c992:	48 8b 79 10          	mov    rdi,QWORD PTR [rcx+0x10]
   2c996:	e8 75 a9 fe ff       	call   17310 <JS_AtomGetStrRT.constprop.0>
   2c99b:	48 89 c2             	mov    rdx,rax
   2c99e:	e9 f4 ec ff ff       	jmp    2b697 <JS_CallInternal+0x8b97>
   2c9a3:	48 8b 9d 50 fe ff ff 	mov    rbx,QWORD PTR [rbp-0x1b0]
   2c9aa:	e9 f1 68 ff ff       	jmp    232a0 <JS_CallInternal+0x7a0>
   2c9af:	41 83 fe 08          	cmp    r14d,0x8
   2c9b3:	75 70                	jne    2ca25 <JS_CallInternal+0x9f25>
   2c9b5:	66 48 0f 6e c2       	movq   xmm0,rdx
   2c9ba:	66 49 0f 6e cd       	movq   xmm1,r13
   2c9bf:	31 c0                	xor    eax,eax
   2c9c1:	ba 01 00 00 00       	mov    edx,0x1
   2c9c6:	66 0f 2e c1          	ucomisd xmm0,xmm1
   2c9ca:	0f 9a c0             	setp   al
   2c9cd:	48 0f 45 c2          	cmovne rax,rdx
   2c9d1:	e9 89 af ff ff       	jmp    2795f <JS_CallInternal+0x4e5f>
   2c9d6:	66 48 0f 6e c0       	movq   xmm0,rax
   2c9db:	83 f9 08             	cmp    ecx,0x8
   2c9de:	74 3e                	je     2ca1e <JS_CallInternal+0x9f1e>
   2c9e0:	85 c9                	test   ecx,ecx
   2c9e2:	0f 85 e8 ee ff ff    	jne    2b8d0 <JS_CallInternal+0x8dd0>
   2c9e8:	66 0f ef c9          	pxor   xmm1,xmm1
   2c9ec:	f2 0f 2a ca          	cvtsi2sd xmm1,edx
   2c9f0:	31 c0                	xor    eax,eax
   2c9f2:	66 0f 2f c8          	comisd xmm1,xmm0
   2c9f6:	48 c7 43 e8 01 00 00 	mov    QWORD PTR [rbx-0x18],0x1
   2c9fd:	00 
   2c9fe:	0f 97 c0             	seta   al
   2ca01:	48 83 eb 10          	sub    rbx,0x10
   2ca05:	48 89 43 f0          	mov    QWORD PTR [rbx-0x10],rax
   2ca09:	e9 a2 b2 ff ff       	jmp    27cb0 <JS_CallInternal+0x51b0>
   2ca0e:	4d 89 ec             	mov    r12,r13
   2ca11:	e9 8a 68 ff ff       	jmp    232a0 <JS_CallInternal+0x7a0>
   2ca16:	66 0f ef c0          	pxor   xmm0,xmm0
   2ca1a:	f2 0f 2a c0          	cvtsi2sd xmm0,eax
   2ca1e:	66 48 0f 6e ca       	movq   xmm1,rdx
   2ca23:	eb cb                	jmp    2c9f0 <JS_CallInternal+0x9ef0>
   2ca25:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2ca2c:	4c 89 ee             	mov    rsi,r13
   2ca2f:	4c 89 f2             	mov    rdx,r14
   2ca32:	e8 c9 ff fe ff       	call   1ca00 <JS_FreeValue>
   2ca37:	e9 12 d8 ff ff       	jmp    2a24e <JS_CallInternal+0x774e>
   2ca3c:	66 49 0f 6e c0       	movq   xmm0,r8
   2ca41:	f2 41 0f 58 45 00    	addsd  xmm0,QWORD PTR [r13+0x0]
   2ca47:	49 c7 45 08 08 00 00 	mov    QWORD PTR [r13+0x8],0x8
   2ca4e:	00 
   2ca4f:	f2 41 0f 11 45 00    	movsd  QWORD PTR [r13+0x0],xmm0
   2ca55:	e9 b8 a5 ff ff       	jmp    27012 <JS_CallInternal+0x4512>
   2ca5a:	41 0f b6 46 11       	movzx  eax,BYTE PTR [r14+0x11]
   2ca5f:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2ca66:	4c 89 f6             	mov    rsi,r14
   2ca69:	4c 89 ea             	mov    rdx,r13
   2ca6c:	c0 e8 02             	shr    al,0x2
   2ca6f:	83 e0 01             	and    eax,0x1
   2ca72:	88 85 50 fe ff ff    	mov    BYTE PTR [rbp-0x1b0],al
   2ca78:	e8 83 ff fe ff       	call   1ca00 <JS_FreeValue>
   2ca7d:	0f b6 85 50 fe ff ff 	movzx  eax,BYTE PTR [rbp-0x1b0]
   2ca84:	e9 ec 9e ff ff       	jmp    26975 <JS_CallInternal+0x3e75>
   2ca89:	b8 01 00 00 00       	mov    eax,0x1
   2ca8e:	e9 e2 9e ff ff       	jmp    26975 <JS_CallInternal+0x3e75>
   2ca93:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2ca9a:	4c 89 ee             	mov    rsi,r13
   2ca9d:	4c 89 f2             	mov    rdx,r14
   2caa0:	4c 89 8d 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],r9
   2caa7:	e8 54 ff fe ff       	call   1ca00 <JS_FreeValue>
   2caac:	48 8b 8d 50 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x1b0]
   2cab3:	31 c0                	xor    eax,eax
   2cab5:	44 39 f1             	cmp    ecx,r14d
   2cab8:	0f 95 c0             	setne  al
   2cabb:	e9 9f ae ff ff       	jmp    2795f <JS_CallInternal+0x4e5f>
   2cac0:	4d 89 f4             	mov    r12,r14
   2cac3:	e9 d8 67 ff ff       	jmp    232a0 <JS_CallInternal+0x7a0>
   2cac8:	41 81 fd f2 00 00 00 	cmp    r13d,0xf2
   2cacf:	0f 8e cb 67 ff ff    	jle    232a0 <JS_CallInternal+0x7a0>
   2cad5:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2cadc:	44 89 ee             	mov    esi,r13d
   2cadf:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2cae3:	e8 88 c9 fe ff       	call   19470 <JS_FreeAtom.part.0.isra.0>
   2cae8:	e9 b3 67 ff ff       	jmp    232a0 <JS_CallInternal+0x7a0>
   2caed:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2caf4:	4c 8b 60 10          	mov    r12,QWORD PTR [rax+0x10]
   2caf8:	41 80 bc 24 e9 04 00 	cmp    BYTE PTR [r12+0x4e9],0x0
   2caff:	00 00 
   2cb01:	74 62                	je     2cb65 <JS_CallInternal+0xa065>
   2cb03:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2cb0a:	4c 89 ce             	mov    rsi,r9
   2cb0d:	48 89 ca             	mov    rdx,rcx
   2cb10:	e8 eb fe fe ff       	call   1ca00 <JS_FreeValue>
   2cb15:	31 c0                	xor    eax,eax
   2cb17:	48 c7 43 08 06 00 00 	mov    QWORD PTR [rbx+0x8],0x6
   2cb1e:	00 
   2cb1f:	48 89 03             	mov    QWORD PTR [rbx],rax
   2cb22:	e9 24 89 ff ff       	jmp    2544b <JS_CallInternal+0x294b>
   2cb27:	3d f2 00 00 00       	cmp    eax,0xf2
   2cb2c:	0f 8e 93 f1 ff ff    	jle    2bcc5 <JS_CallInternal+0x91c5>
   2cb32:	48 8b 8d e8 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x118]
   2cb39:	89 c0                	mov    eax,eax
   2cb3b:	48 8b 79 10          	mov    rdi,QWORD PTR [rcx+0x10]
   2cb3f:	48 8b 97 48 04 00 00 	mov    rdx,QWORD PTR [rdi+0x448]
   2cb46:	48 8b 34 c2          	mov    rsi,QWORD PTR [rdx+rax*8]
   2cb4a:	8b 46 fc             	mov    eax,DWORD PTR [rsi-0x4]
   2cb4d:	83 e8 01             	sub    eax,0x1
   2cb50:	89 46 fc             	mov    DWORD PTR [rsi-0x4],eax
   2cb53:	85 c0                	test   eax,eax
   2cb55:	0f 8f 6a f1 ff ff    	jg     2bcc5 <JS_CallInternal+0x91c5>
   2cb5b:	e8 a0 88 fe ff       	call   15400 <JS_FreeAtomStruct>
   2cb60:	e9 60 f1 ff ff       	jmp    2bcc5 <JS_CallInternal+0x91c5>
   2cb65:	41 c6 84 24 e9 04 00 	mov    BYTE PTR [r12+0x4e9],0x1
   2cb6c:	00 01 
   2cb6e:	48 89 c7             	mov    rdi,rax
   2cb71:	31 c0                	xor    eax,eax
   2cb73:	48 8d 35 40 09 0a 00 	lea    rsi,[rip+0xa0940]        # cd4ba <_IO_stdin_used+0x4ba>
   2cb7a:	48 89 8d 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],rcx
   2cb81:	4c 89 8d 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],r9
   2cb88:	e8 a3 64 00 00       	call   33030 <JS_ThrowInternalError>
   2cb8d:	48 8b 8d 40 fe ff ff 	mov    rcx,QWORD PTR [rbp-0x1c0]
   2cb94:	41 c6 84 24 e9 04 00 	mov    BYTE PTR [r12+0x4e9],0x0
   2cb9b:	00 00 
   2cb9d:	4c 8b 8d 50 fe ff ff 	mov    r9,QWORD PTR [rbp-0x1b0]
   2cba4:	e9 5a ff ff ff       	jmp    2cb03 <JS_CallInternal+0xa003>
   2cba9:	b8 01 00 00 00       	mov    eax,0x1
   2cbae:	e9 62 9d ff ff       	jmp    26915 <JS_CallInternal+0x3e15>
   2cbb3:	41 0f b6 46 11       	movzx  eax,BYTE PTR [r14+0x11]
   2cbb8:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2cbbf:	4c 89 f6             	mov    rsi,r14
   2cbc2:	4c 89 ea             	mov    rdx,r13
   2cbc5:	c0 e8 02             	shr    al,0x2
   2cbc8:	83 e0 01             	and    eax,0x1
   2cbcb:	89 85 50 fe ff ff    	mov    DWORD PTR [rbp-0x1b0],eax
   2cbd1:	e8 2a fe fe ff       	call   1ca00 <JS_FreeValue>
   2cbd6:	8b 85 50 fe ff ff    	mov    eax,DWORD PTR [rbp-0x1b0]
   2cbdc:	e9 34 9d ff ff       	jmp    26915 <JS_CallInternal+0x3e15>
   2cbe1:	4d 89 f4             	mov    r12,r14
   2cbe4:	e9 b7 66 ff ff       	jmp    232a0 <JS_CallInternal+0x7a0>
   2cbe9:	4d 89 f4             	mov    r12,r14
   2cbec:	e9 af 66 ff ff       	jmp    232a0 <JS_CallInternal+0x7a0>
   2cbf1:	e8 0a 62 00 00       	call   32e00 <JS_ThrowReferenceErrorUninitialized>
   2cbf6:	4d 89 f4             	mov    r12,r14
   2cbf9:	e9 a2 66 ff ff       	jmp    232a0 <JS_CallInternal+0x7a0>
   2cbfe:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2cc05:	4c 89 ee             	mov    rsi,r13
   2cc08:	4c 89 f2             	mov    rdx,r14
   2cc0b:	e8 f0 fd fe ff       	call   1ca00 <JS_FreeValue>
   2cc10:	31 c0                	xor    eax,eax
   2cc12:	e9 9c ad ff ff       	jmp    279b3 <JS_CallInternal+0x4eb3>
   2cc17:	4d 89 cc             	mov    r12,r9
   2cc1a:	e9 81 66 ff ff       	jmp    232a0 <JS_CallInternal+0x7a0>
   2cc1f:	49 8b 75 00          	mov    rsi,QWORD PTR [r13+0x0]
   2cc23:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2cc2a:	4c 89 c2             	mov    rdx,r8
   2cc2d:	4c 89 f1             	mov    rcx,r14
   2cc30:	4c 89 8d 40 fe ff ff 	mov    QWORD PTR [rbp-0x1c0],r9
   2cc37:	4c 89 85 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],r8
   2cc3e:	e8 ed 81 fe ff       	call   14e30 <JS_ConcatStringInPlace>
   2cc43:	4c 8b 85 50 fe ff ff 	mov    r8,QWORD PTR [rbp-0x1b0]
   2cc4a:	4c 8b 8d 40 fe ff ff 	mov    r9,QWORD PTR [rbp-0x1c0]
   2cc51:	85 c0                	test   eax,eax
   2cc53:	75 60                	jne    2ccb5 <JS_CallInternal+0xa1b5>
   2cc55:	49 8b 55 08          	mov    rdx,QWORD PTR [r13+0x8]
   2cc59:	49 8b 75 00          	mov    rsi,QWORD PTR [r13+0x0]
   2cc5d:	83 fa f6             	cmp    edx,0xfffffff6
   2cc60:	76 04                	jbe    2cc66 <JS_CallInternal+0xa166>
   2cc62:	83 46 fc 01          	add    DWORD PTR [rsi-0x4],0x1
   2cc66:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2cc6d:	4c 89 c1             	mov    rcx,r8
   2cc70:	4d 89 f0             	mov    r8,r14
   2cc73:	4c 89 8d 50 fe ff ff 	mov    QWORD PTR [rbp-0x1b0],r9
   2cc7a:	e8 a1 35 01 00       	call   40220 <JS_ConcatString>
   2cc7f:	4c 8b 8d 50 fe ff ff 	mov    r9,QWORD PTR [rbp-0x1b0]
   2cc86:	83 fa 06             	cmp    edx,0x6
   2cc89:	49 89 c0             	mov    r8,rax
   2cc8c:	49 89 d6             	mov    r14,rdx
   2cc8f:	74 3b                	je     2cccc <JS_CallInternal+0xa1cc>
   2cc91:	49 8b 45 00          	mov    rax,QWORD PTR [r13+0x0]
   2cc95:	49 8b 55 08          	mov    rdx,QWORD PTR [r13+0x8]
   2cc99:	4d 89 45 00          	mov    QWORD PTR [r13+0x0],r8
   2cc9d:	4d 89 75 08          	mov    QWORD PTR [r13+0x8],r14
   2cca1:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2cca8:	48 89 c6             	mov    rsi,rax
   2ccab:	e8 50 fd fe ff       	call   1ca00 <JS_FreeValue>
   2ccb0:	e9 5d a3 ff ff       	jmp    27012 <JS_CallInternal+0x4512>
   2ccb5:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2ccbc:	4c 89 c6             	mov    rsi,r8
   2ccbf:	4c 89 f2             	mov    rdx,r14
   2ccc2:	e8 39 fd fe ff       	call   1ca00 <JS_FreeValue>
   2ccc7:	e9 46 a3 ff ff       	jmp    27012 <JS_CallInternal+0x4512>
   2cccc:	4d 89 cc             	mov    r12,r9
   2cccf:	e9 cc 65 ff ff       	jmp    232a0 <JS_CallInternal+0x7a0>
   2ccd4:	4c 89 eb             	mov    rbx,r13
   2ccd7:	e9 c4 65 ff ff       	jmp    232a0 <JS_CallInternal+0x7a0>
   2ccdc:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2cce3:	89 ce                	mov    esi,ecx
   2cce5:	e8 16 61 00 00       	call   32e00 <JS_ThrowReferenceErrorUninitialized>
   2ccea:	e9 b0 d6 ff ff       	jmp    2a39f <JS_CallInternal+0x789f>
   2ccef:	41 81 fd f2 00 00 00 	cmp    r13d,0xf2
   2ccf6:	0f 8e a4 65 ff ff    	jle    232a0 <JS_CallInternal+0x7a0>
   2ccfc:	48 8b 85 e8 fe ff ff 	mov    rax,QWORD PTR [rbp-0x118]
   2cd03:	44 89 ee             	mov    esi,r13d
   2cd06:	48 8b 78 10          	mov    rdi,QWORD PTR [rax+0x10]
   2cd0a:	e8 61 c7 fe ff       	call   19470 <JS_FreeAtom.part.0.isra.0>
   2cd0f:	e9 8c 65 ff ff       	jmp    232a0 <JS_CallInternal+0x7a0>
   2cd14:	e8 b7 4c fe ff       	call   119d0 <__stack_chk_fail@plt>
   2cd19:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2cd20:	48 8d 35 7a 08 0a 00 	lea    rsi,[rip+0xa087a]        # cd5a1 <_IO_stdin_used+0x5a1>
   2cd27:	31 c0                	xor    eax,eax
   2cd29:	e8 22 3f 00 00       	call   30c50 <JS_ThrowTypeError>
   2cd2e:	e9 6d 65 ff ff       	jmp    232a0 <JS_CallInternal+0x7a0>
   2cd33:	4d 89 ec             	mov    r12,r13
   2cd36:	e9 65 65 ff ff       	jmp    232a0 <JS_CallInternal+0x7a0>
   2cd3b:	48 8b bd e8 fe ff ff 	mov    rdi,QWORD PTR [rbp-0x118]
   2cd42:	45 39 f0             	cmp    r8d,r14d
   2cd45:	4c 89 ee             	mov    rsi,r13
   2cd48:	4c 89 f2             	mov    rdx,r14
   2cd4b:	0f 94 85 50 fe ff ff 	sete   BYTE PTR [rbp-0x1b0]
   2cd52:	e8 a9 fc fe ff       	call   1ca00 <JS_FreeValue>
   2cd57:	0f b6 85 50 fe ff ff 	movzx  eax,BYTE PTR [rbp-0x1b0]
   2cd5e:	e9 50 ac ff ff       	jmp    279b3 <JS_CallInternal+0x4eb3>
   2cd63:	4d 89 f4             	mov    r12,r14
   2cd66:	e9 35 65 ff ff       	jmp    232a0 <JS_CallInternal+0x7a0>

Disassembly of section .fini:
