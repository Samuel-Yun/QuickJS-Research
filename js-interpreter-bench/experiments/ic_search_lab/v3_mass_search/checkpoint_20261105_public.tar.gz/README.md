# QuickJS IC mass search

当前状态为 **BLOCKED_TIMING_DRIFT**。14个代表已实际构建、校验并跑过8项pilot；统一N×4后冻结基线仍超15%漂移。234项待构建、40项不支持，没有正式性能确认。见results.md、baseline_drift.csv及next_commands.md。原STOP保留，显式恢复用resume.py，不直接删除STOP继续排名。

本轮从 myx/dafef00c9a5231208253c76329b9d13eb26cc564 开始，独立记录，不引用旧耗时作分母。288 是初始配置数，实际已构建、已校验和已采样数量由 candidates.csv 与 runs.jsonl 给出。

一份 active 源码/构建位置，artifacts 中保留冻结 ELF，不覆盖运行中的程序。原版 A、M、s001 不重建。私有 jwst-compiler 不读取、不打包。模板和生成器是公开 M+s001 的衍生实现，原 MIT LICENSE 随恢复材料保留。

入口为 `python3 search.py prepare|pilot|screen|level2|recheck|analyze|audit`，在本目录运行。构建、采样串行。STOP 文件会在下一个进程前正常停止。每个完成的配置有检查点，可按已有 ID 续跑。分析和审计只读已有记录，无需旧运行时路径。

计时使用冻结的内部 native CLOCK_MONOTONIC，首次 Run 计入，无计时前 workload 预跑。初始 Setup 在计时外，Run 内 GC/builtin/RegExp/动态编译保留。短测只作预算分配，不作为正式性能结果。两项 SunSpider 随机输入限制及 Octane Crypto 原 N 密文门禁沿用。

环境、模板支持边界、实际阶段和结果随真实执行写入 environment.json、protocol.json、template_checks.jsonl、candidates.csv、runs.jsonl 及 results.md。没有完成的阶段明确标注，不能根据 PLANNED 行数声称测试完成。

A 源码归档保留原 CRLF 字节和原始 SHA256。生成 S/A 工作副本时统一将 CRLF 规范化为 LF，再应用模板；seed_A.tar.gz 不改写。生成器首次未处理该差异的失败见 pilot_generator_failure01.json，未被记作引擎崩溃。历史 M/s001 的源码和 binary 均未改写。

raw为UTF-8/LF；runners及templates用Git -text保留精确字节。少量PowerShell产生的环境/控制器JSON保留原始换行，JSON同样禁用Git转换；不把它们的字节hash误作LF规范化hash。
