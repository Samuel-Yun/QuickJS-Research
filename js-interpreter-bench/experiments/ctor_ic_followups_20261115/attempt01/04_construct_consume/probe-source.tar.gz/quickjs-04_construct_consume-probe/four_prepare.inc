static int four_interior_target(JSFunctionBytecode*b,int begin,int end)
{
    for(int p=0;p<b->byte_code_len;){
        int op=b->byte_code_buf[p],fmt=short_opcode_info(op).fmt,target=-1;
        const uint8_t *v=b->byte_code_buf+p;
        if(fmt==OP_FMT_label)target=p+1+(int32_t)get_u32(v+1);
        else if(fmt==OP_FMT_label8)target=p+1+(int8_t)v[1];
        else if(fmt==OP_FMT_label16)target=p+1+(int16_t)get_u16(v+1);
        else if(fmt==OP_FMT_atom_label_u8)target=p+5+(int32_t)get_u32(v+5);
        if(target>begin && target<end)return 1;
        p+=short_opcode_info(op).size;
    }return 0;
}
/* Two fixed straight-line consumers; no general escape analysis. */
static int consume_read_atom(JSFunctionBytecode*b,int pos,JSAtom*a)
{
    if(pos+5>b->byte_code_len || b->byte_code_buf[pos]!=OP_get_field_rdi)return 0;
    uint8_t*p=b->byte_code_buf+pos;ReadICSite*s=(ReadICSite*)(p+1+get_u32(p+1));*a=s->atom;return 1;
}
static int consume_slot(const uint8_t*p,int store,int*index)
{
    int op=*p,base=store?OP_put_loc0:OP_get_loc0;
    if(!store && op==OP_v6_get_loc0)op=OP_get_loc0;
    if(op>=base && op<=base+3){*index=op-base;return 1;}
    if(op==(store?OP_put_loc:OP_get_loc)){*index=get_u16(p+1);return 3;}
    if(op==(store?OP_put_loc8:OP_get_loc8)){*index=p[1];return 2;}
    return 0;
}
static void consume_prepare(JSFunctionBytecode*b,FourSite*s)
{
    int start=s->pc+3,end=start;JSAtom atom;
    if(consume_read_atom(b,start,&atom)){s->consume_kind=1;end+=5;}
    else{
        int index,index2,n,n2;
        if(start>=b->byte_code_len || !(n=consume_slot(b->byte_code_buf+start,1,&index)) ||
           start+n>=b->byte_code_len || !(n2=consume_slot(b->byte_code_buf+start+n,0,&index2)) || index!=index2 ||
           !consume_read_atom(b,start+n+n2,&atom))return;
        /* No debug variable definition / eval / captured local: reject. */
        if(!b->vardefs || index>=b->var_count || b->vardefs[b->arg_count+index].is_captured ||
           b->is_direct_or_indirect_eval || b->var_ref_count)return;
        int touches=0;
        for(int p=0;p<b->byte_code_len;){
            int op=b->byte_code_buf[p],fmt=short_opcode_info(op).fmt,j=-1;
            if(consume_slot(b->byte_code_buf+p,0,&j) || consume_slot(b->byte_code_buf+p,1,&j)){if(j==index)touches++;}
            else if((fmt==OP_FMT_loc || fmt==OP_FMT_loc8) &&
                    (fmt==OP_FMT_loc?get_u16(b->byte_code_buf+p+1):b->byte_code_buf[p+1])==index)return;
            p+=short_opcode_info(op).size;
        }
        if(touches!=2)return;
        s->consume_kind=2;end=start+n+n2+5;
    }
    if(four_interior_target(b,s->pc,end)){s->consume_kind=3;return;}
    s->consume_atom=atom;
}
static size_t four_extra_size(JSFunctionBytecode*b)
{
    unsigned n=0;for(int p=0;p<b->byte_code_len;){int op=b->byte_code_buf[p];n+=op==OP_call_constructor;p+=short_opcode_info(op).size;}
    return n>65535?0:n*sizeof(FourSite);
}
static void four_prepare(JSContext*ctx,JSFunctionBytecode*b)
{
    if(!four_extra_size(b))return;b->four_sites=(FourSite*)(b->read_ic_sites+b->read_ic_count);
    for(int p=0;p<b->byte_code_len;){uint8_t*pc=b->byte_code_buf+p;int op=*pc,n=short_opcode_info(op).size;
        if(op==OP_call_constructor){FourSite*s=&b->four_sites[b->four_count];s->pc=p;s->argc=get_u16(pc+1);
#ifdef FOUR_DIAG
            s->diag=four_dnew(ctx,b,p);
#endif
            consume_prepare(b,s);
            *pc=OP_four_ctor;put_u16(pc+1,b->four_count++);
        }p+=n;
    }
}
