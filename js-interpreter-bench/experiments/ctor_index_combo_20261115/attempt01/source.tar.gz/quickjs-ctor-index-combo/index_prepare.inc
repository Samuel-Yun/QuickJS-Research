static int four_interior_target(JSFunctionBytecode*b,int begin,int end)
{
    for(int p=0;p<b->byte_code_len;){
        int op=b->byte_code_buf[p],fmt=short_opcode_info(op).fmt,target=-1;
        const uint8_t *v=b->byte_code_buf+p;
        if(fmt==OP_FMT_label)target=p+1+(int32_t)get_u32(v+1);
        else if(fmt==OP_FMT_label8)target=p+1+(int8_t)v[1];
        else if(fmt==OP_FMT_label16)target=p+1+(int16_t)get_u16(v+1);
        else if(fmt==OP_FMT_atom_label_u8)target=p+5+(int32_t)get_u32(v+5);
        if(target>begin && target<end)return 1;
        p+=short_opcode_info(op).size;
    }return 0;
}

static int four_index_match(JSFunctionBytecode*b,int pc,int*local,int*end)
{
    uint8_t*p=b->byte_code_buf+pc;
    if(pc+3>b->byte_code_len || p[0]!=OP_get_array_el || p[1]!=OP_add)return 0;
    if(p[2]>=OP_put_loc0 && p[2]<=OP_put_loc3){*local=p[2]-OP_put_loc0;*end=pc+3;}
    else if(pc+4<=b->byte_code_len && p[2]==OP_put_loc8){*local=p[3];*end=pc+4;}
    else return 0;
    return *local<b->var_count && !four_interior_target(b,pc,*end);
}
static size_t index_extra_size(JSFunctionBytecode*b)
{
    unsigned n=0;for(int p=0;p<b->byte_code_len;){int op=b->byte_code_buf[p],local,end;n+=four_index_match(b,p,&local,&end);p+=short_opcode_info(op).size;}
    return n*sizeof(IndexSite);
}
static void index_prepare(JSContext*ctx,JSFunctionBytecode*b)
{
    b->index_sites=(IndexSite*)((uint8_t*)(b->read_ic_sites+b->read_ic_count)+b->four_count*sizeof(FourSite));
    for(int p=0;p<b->byte_code_len;){int op=b->byte_code_buf[p],local,end,n=short_opcode_info(op).size;
        if(four_index_match(b,p,&local,&end)){IndexSite*s=&b->index_sites[b->index_count++];s->pc=p;s->end=end;s->local=local;
#ifdef FOUR_DIAG
            s->diag=four_dnew(ctx,b,p);
#endif
            b->byte_code_buf[p]=OP_four_index;
        }p+=n;
    }
}
